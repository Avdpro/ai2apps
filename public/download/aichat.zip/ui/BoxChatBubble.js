//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HAV6GN710StartDoc*/
import {BoxCodeSeg} from "./BoxCodeSeg.js";
/*}#1HAV6GN710StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxChatBubble=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,txtContent;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	
	/*#{1HA0EVOKU1LocalVals*/
	const app=VFACT.app;
	let isDesktop=true;
	let tracedObj=null;
	let tracePrefix="";
	let tracePostfix="";
	let owner=null;
	/*}#1HA0EVOKU1LocalVals*/
	
	/*#{1HA0EVOKU1PreState*/
	/*}#1HA0EVOKU1PreState*/
	/*#{1HA0EVOKU1PostState*/
	/*}#1HA0EVOKU1PostState*/
	cssVO={
		"hash":"1HA0EVOKU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[10,10,10,10],"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":vo.side==="left"?"flex-x":"flex-xr",
		"traceSize":true,"exposeToAI":true,"descAI":"对话泡泡",
		children:[
			{
				"hash":"1HA0FE4LK0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":32,"h":32,"overflow":1,"padding":vo.pic?0:2,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":vo.iconBG||vo.bgColor,"corner":5,
				children:[
					{
						"hash":"1HA0GFET80",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor,
						"maskImage":icon,"attached":!vo.pic,
					},
					{
						"hash":"1HAV7MICI0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":true,"attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HA0G844M0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":0,"w":"","h":"","margin":[5,10,0,10],"padding":8,"minW":60,"minH":30,"maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":1,
				children:[
					{
						"hash":"1HAV6UF8M0",
						"type":"box","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.bgColor,"corner":vo.side==="left"?[0,12,12,12]:[12,0,12,12],
						"OnClick":function(event){
							/*#{1HAVL72EK0FunctionBody*/
							self.doCopy();
							/*}#1HAVL72EK0FunctionBody*/
						},
					},
					{
						"hash":"1HA0H00DG0",
						"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":280,"maxH":"","styleClass":"","color":vo.textColor,
						"text":vo.text,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
						"OnClick":function(event){
							/*#{1HAVL6H3P0FunctionBody*/
							self.doCopy();
							/*}#1HAVL6H3P0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HA0EVOKU1ExtraCSS*/
		/*}#1HA0EVOKU1ExtraCSS*/
		faces:{
			"left":{
			},"right":{
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;txtContent=self.TxtContent;
			/*#{1HA0EVOKU1Create*/
			self.content=vo.text||vo.content;
			if(vo.render){
				self.renderContents();
			}
			/*}#1HA0EVOKU1Create*/
		},
		/*#{1HA0EVOKU1EndCSS*/
		/*}#1HA0EVOKU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HA0HQH3P0FunctionBody*/
		self.content=vo.text||vo.content;
		/*}#1HA0HQH3P0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HA0IDR1E0FunctionBody*/
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
		/*}#1HA0IDR1E0FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.removeMsg=async function(ask){
		/*#{1IA7H7GG00Start*/
		/*}#1IA7H7GG00Start*/
	};
	/*#{1HA0EVOKU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.renderContents=function(){
		let content,preCode,code,postCode;
		let parsePos,pos,fullLength;
		let textBlk=txtContent;
		parsePos=0;
		content=self.content;
		fullLength=content.length;
		do{
			pos=content.indexOf("```",parsePos);
			if(pos>=0){
				//Precode:
				preCode=content.substring(parsePos,pos);
				if(textBlk){
					textBlk.text=preCode;
					textBlk=null;
				}else{
					if(preCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":preCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				//find Code:
				parsePos=pos+3;
				pos=content.indexOf("```",parsePos);
				if(pos<0){
					pos=fullLength;
				}
				code=content.substring(parsePos,pos);
				if(code.length){
					boxContents.appendNewChild(
						BoxCodeSeg(code,"")
					);
				}
				parsePos=pos+3;
			}else{
				postCode=content.substring(parsePos);
				if(textBlk){
					textBlk.text=postCode;
					textBlk=null;
				}else{
					if(postCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":postCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				parsePos=fullLength;
			}
		}while(parsePos>=0 && parsePos<fullLength);
	};
	
	//------------------------------------------------------------------------
	cssVO.trace=function(obj,prefix="",postfix=""){
		owner=self.parent;
		tracedObj=obj;
		tracePrefix=prefix;
		tracePostfix=postfix;
		obj.on("content",self.OnUpdate);
		obj.on("close",self.OnClose);
	};
	
	function replaceTextContent(text) {
		// 替换所有数字为 "#"
		let result = text.replace(/\d/g, "#");
		// 替换所有拉丁字母为 "*"
		result = result.replace(/[a-zA-Z]/g, "*");
		// 替换所有非ASCII字符（例如中文）为 "■"
		result = result.replace(/[^\x00-\x7F]+/g, "■");
	
		return result;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnUpdate=function(){
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClose=function(){
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCopy=function(){
		navigator.clipboard.writeText(self.content);
		app.showTip(boxContents,"Content copied",boxContents.w/2,0,1,2);
	};
	
	cssVO.constructor=BoxChatBubble;
	/*}#1HA0EVOKU1PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.exposeAI=function(spotVO,ownerNode){
		let exposeVO,opts;
		/*#{1HA0EVOKU1PreAISpot*/
		/*}#1HA0EVOKU1PreAISpot*/
		exposeVO=VFACT.exposeHud(self,spotVO,ownerNode,opts);
		exposeVO.functions=[
			{"name":"removeMsg","description":"删除这条对话信息。","parameters":{"type":"object","properties":{"ask":{"type":"bool","description":"是否询问用户"}}}}
		];
		/*#{1HA0EVOKU1PostAISpot*/
		/*}#1HA0EVOKU1PostAISpot*/
		return exposeVO;
	};
	return cssVO;
};
/*#{1HA0EVOKU1ExCodes*/
/*}#1HA0EVOKU1ExCodes*/

BoxChatBubble.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"vo": {
			"name": "vo", "showName": "vo", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"side": "left", "pic": null, "icon": "/~/-tabos/shared/assets/user.svg", 
				"iconBG": [0,128,0,1], "iconColor": [255,255,255,1], "bgColor": [0,128,0,1], 
				"textColor": [255,255,255,1], "text": "Hello! Hello! Hello!"
			}, 
			"initValText": "#{side:\"left\",pic:null,icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.success,textColor:cfgColor.fontSuccess,text:\"Hello! Hello! Hello!\",}"
		}, 
		"session": {
			"name": "session", "showName": "session", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["left","right"],
	subContainers:{
	},
	/*#{1HAV6GN710ExGearInfo*/
	/*}#1HAV6GN710ExGearInfo*/
};
/*#{1HAV6GN710EndDoc*/
/*}#1HAV6GN710EndDoc*/

export default BoxChatBubble;
export{BoxChatBubble};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAV6GN710",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA0EVOKV0",
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA0EVOKV1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA0EVOKV2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA0EVOKV3",
//			"attrs": {
//				"vo": {
//					"type": "auto",
//					"valText": "#{side:\"left\",pic:null,icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.success,textColor:cfgColor.fontSuccess,text:\"Hello! Hello! Hello!\",}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HA0EVOKV4",
//			"attrs": {
//				"icon": {
//					"type": "url",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/faces.svg\")"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA0EVOKV5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IA7H7GG00",
//					"attrs": {
//						"id": "removeMsg",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "105",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IA7H8BVE0",
//							"attrs": {
//								"ask": {
//									"type": "bool",
//									"valText": "false",
//									"comment": "是否询问用户"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IA7H8BVE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IA7H8BVE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "true",
//						"descAI": "删除这条对话信息。"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA0EVOKV6",
//			"attrs": {
//				"left": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAV7F6660",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAV7F6661",
//							"attrs": {}
//						}
//					}
//				},
//				"right": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAV7F6662",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAV7F6663",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HA9DQK2O0",
//			"attrs": {
//				"AI result": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DQK2O1",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"AI is thinking...\",buttons:true,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				},
//				"User prompt": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DSAG20",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EVOKU1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA0EVOKV7",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "[10,10,10,10]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "#vo.side===\"left\"?\"flex-x\":\"flex-xr\"",
//						"traceSize": "true",
//						"exposeToAI": "true",
//						"descAI": "对话泡泡"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0FE4LK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA0G1M6B0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "32",
//										"h": "32",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#vo.pic?0:2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA0GFET80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA0GHG9I0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!vo.pic"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA0GHG9I1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HA0GHG9I2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA0GHG9J0",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HAV7MICI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAV7NF3H0",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAV7NF3H1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HAV7NF3H2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAV7NF3H3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA0G1M6B1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HA0G1M6B2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA0G1M6B3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0G844M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA0GE7BT0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,10,0,10]",
//										"padding": "8",
//										"minW": "60",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HAV6UF8M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAV71BVC0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.bgColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "#vo.side===\"left\"?[0,12,12,12]:[12,0,12,12]",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAV71BVC1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HAV71BVC2",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAVL72EK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAVL78HC0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAV71BVC3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HA0H00DG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA0H1R0H0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtContent",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "280",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#vo.textColor",
//														"text": "#vo.text",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "true",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA0H1R0H1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HA0H1R0H2",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAVL6H3P0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAVL6NMJ0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HA0H1R0H3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA0GE7BT1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HA0GE7BT2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA0GE7BT3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HA0EVOKV8",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HA0EVOKV9",
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0HQH3P0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1HA0HQP8C0",
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						},
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0IDR1E0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1HA0IE1L70",
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1HA0EVOKV10",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EVOKV11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}