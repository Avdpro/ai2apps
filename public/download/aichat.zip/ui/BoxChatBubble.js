//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HAV6GN710StartDoc*/
import {BoxCodeSeg} from "./BoxCodeSeg.js";
/*}#1HAV6GN710StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxChatBubble=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,txtContent;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	
	/*#{1HA0EVOKU1LocalVals*/
	const app=VFACT.app;
	let isDesktop=true;
	let tracedObj=null;
	let tracePrefix="";
	let tracePostfix="";
	let owner=null;
	/*}#1HA0EVOKU1LocalVals*/
	
	/*#{1HA0EVOKU1PreState*/
	/*}#1HA0EVOKU1PreState*/
	/*#{1HA0EVOKU1PostState*/
	/*}#1HA0EVOKU1PostState*/
	cssVO={
		"hash":"1HA0EVOKU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[10,10,10,10],"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":vo.side==="left"?"flex-x":"flex-xr",
		"traceSize":true,
		children:[
			{
				"hash":"1HA0FE4LK0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":32,"h":32,"overflow":1,"padding":vo.pic?0:2,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":vo.iconBG||vo.bgColor,"corner":5,
				children:[
					{
						"hash":"1HA0GFET80",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor,
						"maskImage":icon,"attached":!vo.pic,
					},
					{
						"hash":"1HAV7MICI0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":true,"attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HA0G844M0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":0,"w":"","h":"","margin":[5,10,0,10],"padding":8,"minW":60,"minH":30,"maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":1,
				children:[
					{
						"hash":"1HAV6UF8M0",
						"type":"box","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.bgColor,"corner":vo.side==="left"?[0,12,12,12]:[12,0,12,12],
						"OnClick":function(event){
							/*#{1HAVL72EK0FunctionBody*/
							self.doCopy();
							/*}#1HAVL72EK0FunctionBody*/
						},
					},
					{
						"hash":"1HA0H00DG0",
						"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":280,"maxH":"","styleClass":"","color":vo.textColor,
						"text":vo.text,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
						"OnClick":function(event){
							/*#{1HAVL6H3P0FunctionBody*/
							self.doCopy();
							/*}#1HAVL6H3P0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HA0EVOKU1ExtraCSS*/
		/*}#1HA0EVOKU1ExtraCSS*/
		faces:{
			"left":{
			},"right":{
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;txtContent=self.TxtContent;
			/*#{1HA0EVOKU1Create*/
			self.content=vo.text||vo.content;
			if(vo.render){
				self.renderContents();
			}
			/*}#1HA0EVOKU1Create*/
		},
		/*#{1HA0EVOKU1EndCSS*/
		/*}#1HA0EVOKU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HA0HQH3P0FunctionBody*/
		self.content=vo.text||vo.content;
		/*}#1HA0HQH3P0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HA0IDR1E0FunctionBody*/
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
		/*}#1HA0IDR1E0FunctionBody*/
	};
	/*#{1HA0EVOKU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.renderContents=function(){
		let content,preCode,code,postCode;
		let parsePos,pos,fullLength;
		let textBlk=txtContent;
		parsePos=0;
		content=self.content;
		fullLength=content.length;
		do{
			pos=content.indexOf("```",parsePos);
			if(pos>=0){
				//Precode:
				preCode=content.substring(parsePos,pos);
				if(textBlk){
					textBlk.text=preCode;
					textBlk=null;
				}else{
					if(preCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":preCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				//find Code:
				parsePos=pos+3;
				pos=content.indexOf("```",parsePos);
				if(pos<0){
					pos=fullLength;
				}
				code=content.substring(parsePos,pos);
				if(code.length){
					boxContents.appendNewChild(
						BoxCodeSeg(code,"")
					);
				}
				parsePos=pos+3;
			}else{
				postCode=content.substring(parsePos);
				if(textBlk){
					textBlk.text=postCode;
					textBlk=null;
				}else{
					if(postCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":postCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				parsePos=fullLength;
			}
		}while(parsePos>=0 && parsePos<fullLength);
	};
	
	//------------------------------------------------------------------------
	cssVO.trace=function(obj,prefix="",postfix=""){
		owner=self.parent;
		tracedObj=obj;
		tracePrefix=prefix;
		tracePostfix=postfix;
		obj.on("content",self.OnUpdate);
		obj.on("close",self.OnClose);
	};
	
	function replaceTextContent(text) {
		// 替换所有数字为 "#"
		let result = text.replace(/\d/g, "#");
		// 替换所有拉丁字母为 "*"
		result = result.replace(/[a-zA-Z]/g, "*");
		// 替换所有非ASCII字符（例如中文）为 "■"
		result = result.replace(/[^\x00-\x7F]+/g, "■");
	
		return result;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnUpdate=function(){
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClose=function(){
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCopy=function(){
		navigator.clipboard.writeText(self.content);
		app.showTip(boxContents,"Content copied",boxContents.w/2,0,1,2);
	};
	/*}#1HA0EVOKU1PostCSSVO*/
	return cssVO;
};
/*#{1HA0EVOKU1ExCodes*/
/*}#1HA0EVOKU1ExCodes*/


export default BoxChatBubble;
export{BoxChatBubble};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAV6GN710",
//	"editVersion": 119,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV0",
//			"editVersion": 18,
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV3",
//			"editVersion": 128,
//			"attrs": {
//				"vo": {
//					"type": "auto",
//					"valText": "#{side:\"left\",pic:null,icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.success,textColor:cfgColor.fontSuccess,text:\"Hello! Hello! Hello!\",}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV4",
//			"editVersion": 10,
//			"attrs": {
//				"icon": {
//					"type": "url",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/faces.svg\")"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HA0EVOKV5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HA0EVOKV6",
//			"editVersion": 12,
//			"attrs": {
//				"left": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAV7F6660",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAV7F6661",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"right": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAV7F6662",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAV7F6663",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HA9DQK2O0",
//			"editVersion": 4,
//			"attrs": {
//				"AI result": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DQK2O1",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 38,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"AI is thinking...\",buttons:true,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"User prompt": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DSAG20",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 54,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EVOKU1",
//			"editVersion": 45,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV7",
//					"editVersion": 308,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "[10,10,10,10]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "#vo.side===\"left\"?\"flex-x\":\"flex-xr\"",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0FE4LK0",
//							"editVersion": 31,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B0",
//									"editVersion": 262,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "32",
//										"h": "32",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#vo.pic?0:2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA0GFET80",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I0",
//													"editVersion": 128,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!vo.pic"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I1",
//													"editVersion": 48,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0GHG9J0",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HAV7MICI0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAV7NF3H0",
//													"editVersion": 92,
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAV7NF3H1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAV7NF3H2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAV7NF3H3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B1",
//									"editVersion": 48,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0G1M6B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0G844M0",
//							"editVersion": 46,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT0",
//									"editVersion": 202,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,10,0,10]",
//										"padding": "8",
//										"minW": "60",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HAV6UF8M0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAV71BVC0",
//													"editVersion": 152,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.bgColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "#vo.side===\"left\"?[0,12,12,12]:[12,0,12,12]",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAV71BVC1",
//													"editVersion": 8,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAV71BVC2",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAVL72EK0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAVL78HC0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAV71BVC3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HA0H00DG0",
//											"editVersion": 50,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H0",
//													"editVersion": 162,
//													"attrs": {
//														"type": "text",
//														"id": "TxtContent",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "280",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#vo.textColor",
//														"text": "#vo.text",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "true",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H1",
//													"editVersion": 48,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H2",
//													"editVersion": 6,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAVL6H3P0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAVL6NMJ0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0H1R0H3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT1",
//									"editVersion": 48,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0GE7BT3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV8",
//					"editVersion": 4,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV9",
//					"editVersion": 4,
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0HQH3P0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0HQP8C0",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0IDR1E0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0IE1L70",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HA0EVOKV10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EVOKV11",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}