//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HAMSORTA0StartDoc*/
import pathLib from "/@path";
import markdownit from "/@markdownit";
import {tabFS} from "/@tabos";
import {BoxAction} from "./BoxAction.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {BoxBreakPoint} from "./BoxBreakPoint.js";
import {BoxGPTCheat} from "./BoxGPTCheat.js";
import {DlgAIWork} from "./DlgAIWork.js";
/*}#1HAMSORTA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIPath=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxActions,boxBreakPoint,txtBreakOn,txtBreakAt,edBreakPointData,boxInfo,boxActionInfo,boxCallVO,edPerferResult,btnAddBreakPoint,btnAddCheat,boxHelp,boxBreaks,boxBPList,boxCheats,boxCheatList;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAMSORTA1LocalVals*/
	const app=VFACT.app;
	let session;
	let cm=null;
	
	//Break point related:
	let breakResumeFunc=null;
	let breakAbortFunc=null;
	let orgBreakData=null;
	let curAction=null;
	/*}#1HAMSORTA1LocalVals*/
	
	/*#{1HAMSORTA1PreState*/
	/*}#1HAMSORTA1PreState*/
	state={
		"hotAction":{
			"type":"GPTCall","chatBot":null,"actor":"default.aichat","prompt":"Hello!","result":"Hello, nice to meet you!","error":"","startTime":0,"endTime":10000,
			"desc":"Bla bla","path":"/aichat/ai/default.aichat"
		},
		"isChatBot":false,
		/*#{1HAMSORTA7ExState*/
		/*}#1HAMSORTA7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAMSORTA1PostState*/
	let hotAction=state.hotAction;
	/*}#1HAMSORTA1PostState*/
	cssVO={
		"hash":"1HAMSORTA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HAMSUGM80",
				"type":"hud","id":"BoxActions","x":0,"y":0,"w":">calc(100% - 380px)","h":"100%","overflow":"auto-y","padding":[10,20,20,20],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAPUVO1O0",
						"type":"box","id":"BoxBreakPoint","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,10,0],"padding":[15,5,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"border":2,"borderColor":cfgColor["error"],"corner":6,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAPV1RBD0",
								"type":"text","id":"TxtBreakOn","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Break on: Setup Run.","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HAPV2TAP0",
								"type":"text","id":"TxtBreakAt","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","color":cfgColor["fontBody"],"text":"Break at: input / output@testfitler.js","fontSize":txtSize.smallPlus,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","ellipsis":true,
							},
							{
								"hash":"1HAPV58FF0",
								"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBodySub"],"text":"Passing data:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HAPV70100",
								"type":"memo","id":"EdBreakPointData","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","margin":[5,0,0,0],"minW":"","minH":30,
								"maxW":"","maxH":200,"styleClass":"","color":[0,0,0],"border":1,"borderColor":[0,0,0,1],
							},
							{
								"hash":"1HAPVAAU60",
								"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","subAlign":1,"contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAPVBV7R0",
										"type":BtnText("success",100,25,"Continue",false,""),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAQE22CL0FunctionBody*/
											self.resumeBreak();
											/*}#1HAQE22CL0FunctionBody*/
										},
									},
									{
										"hash":"1HAPVBF7Q0",
										"type":BtnText("error",100,25,"Abort",false,""),"position":"relative","x":0,"y":0,"margin":[0,0,0,15],
										"OnClick":function(event){
											/*#{1HAQHA9SG0FunctionBody*/
											self.abortBreak();
											/*}#1HAQHA9SG0FunctionBody*/
										},
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1HAMSQ5MU0",
				"type":"box","id":"BoxInfo","x":"100%","y":0,"w":380,"h":"100%","anchorX":2,"overflow":"auto-y","padding":[10,15,20,15],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor["fontSecondarySub"],"border":[0,0,0,1],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAO0T2EK0",
						"type":"hud","id":"BoxActionInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAO106RC0",
								"type":"hud","id":"LineType","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO106RC2",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Type:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAO106RD3",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":$P(()=>(""+state.hotAction.type ),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
									}
								],
							},
							{
								"hash":"1HAO10I2P0",
								"type":"hud","id":"LIneActor","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO10I2P2",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Actor:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAT283940",
										"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":0,"scale":[-1,1],"anchorX":2,"enable":$P(()=>(state.isChatBot),state),
										"tip":"Inspect",
										"OnClick":function(event){
											/*#{1HAT2IQ3T0FunctionBody*/
											session.inspectChatBot(hotAction.path);
											app.showTip(this,"ChatBots loged into browser console.",this.w/2,this.h+5,1,0);
											/*}#1HAT2IQ3T0FunctionBody*/
										},
									},
									{
										"hash":"1HAO10I2P7",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":$P(()=>(state.hotAction.actor),state),
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
									}
								],
							},
							{
								"hash":"1HAO10PF00",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.path),state),"margin":[5,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Source Path:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO10UPT0",
								"type":"text","id":"TxtPath","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.path),state),"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.path),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO113BC0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.desc),state),"margin":[5,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Description:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO117PH0",
								"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.desc),state),"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.desc),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO11BET0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type!=="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Prompt / Input","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO11F680",
								"type":"text","id":"TxtPrompt","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.type!=="GPTCall"),state),
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.prompt),state),"fontSize":txtSize.mid,
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO11IVI0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"GPT Call VO:","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO6F4DL0",
								"type":"box","id":"BoxCallVO","position":"relative","x":0,"y":0,"w":"100%","h":200,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"minW":"","minH":"","maxW":"","maxH":200,"styleClass":"","background":[255,255,255,1],"border":1,
							},
							{
								"hash":"1HAO122KO0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!state.hotAction.error),state),"margin":[10,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Result / Ouput:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO12AQ90",
								"type":"text","id":"TxtResult","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!state.hotAction.error),state),"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.result),state),"fontSize":txtSize.mid,
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO12EN70",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Perfered result:","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO12JH00",
								"type":"memo","id":"EdPerferResult","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"minW":"","minH":30,"maxW":"","maxH":200,"styleClass":"","color":[0,0,0],"background":[250,250,250,1],"outline":0,"border":1,"borderColor":[0,0,0,1],
								"corner":3,
							},
							{
								"hash":"1HAO12TSR0",
								"type":BtnText("primary",160,25,"Get Refine Hints",false,""),"position":"relative","x":"50%","y":0,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"anchorX":1,"margin":[5,0,0,0],
								"OnClick":function(event){
									/*#{1HATEC29M0FunctionBody*/
									self.refinePrompt();
									/*}#1HATEC29M0FunctionBody*/
								},
							},
							{
								"hash":"1HAO132J10",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.error),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Error:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO13D4R0",
								"type":"text","id":"TxtError","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.error),state),"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":[200,0,0,1],"text":$P(()=>(state.hotAction.error),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO1FG4C0",
								"type":"hud","id":"LineTime","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.endTime>0),state),"margin":[20,0,0,0],
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO1FG4D0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Time Cost:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAO1FG4D5",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":$P(()=>(state.hotAction.endTime-state.hotAction.startTime+"ms"),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
										"textDecoration":"","alignV":1,
									}
								],
							},
							{
								"hash":"1HAQJVRTO0",
								"type":BtnText("warning",160,25,"Make a Break Point",false,""),"id":"BtnAddBreakPoint","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[15,0,0,0],
								"enable":$P(()=>(!!state.hotAction.actor),state),
								"OnClick":function(event){
									/*#{1HAQKE1HJ0FunctionBody*/
									self.addBreakPoint();
									/*}#1HAQKE1HJ0FunctionBody*/
								},
							},
							{
								"hash":"1HARNSE1Q0",
								"type":BtnText("success",160,25,"Make a GPT Cheat",false,""),"id":"BtnAddCheat","position":"relative","x":"50%","y":0,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"anchorX":1,"margin":[15,0,0,0],
								"OnClick":function(event){
									/*#{1HARNSE1Q7FunctionBody*/
									self.addGPTCheat();
									/*}#1HARNSE1Q7FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HAO19EEM0",
						"type":"hud","id":"BoxHelp","position":"relative","x":0,"y":0,"w":"125%","h":"","scale":0.8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1HAQJR02T0",
						"type":"hud","id":"BoxBreaks","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"scale":1,"padding":[0,0,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAR4828O0",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1HAR4F0AD0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,
										"tip":"Refresh",
										"OnClick":function(event){
											/*#{1HAR6OLDI0FunctionBody*/
											self.listBreaks();
											/*}#1HAR6OLDI0FunctionBody*/
										},
									},
									{
										"hash":"1HAR4A5O90",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Breakpoints:",
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
									},
									{
										"hash":"1HAR669O00",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAR67DKG0FunctionBody*/
											if(curAction){
												self.showFace("info");
											}else{
												self.showFace("help");
											}
											/*}#1HAR67DKG0FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1HAR4ID1V0",
								"type":"hud","id":"BoxBPList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							}
						],
					},
					{
						"hash":"1HAS5G3LB0",
						"type":"hud","id":"BoxCheats","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"scale":1,"padding":[0,0,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAS5G3LB2",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1HAS5G3LB4",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,"padding":1,
										"tip":"Refresh",
										"OnClick":function(event){
											/*#{1HAS5G3LC2FunctionBody*/
											self.listCheats();
											/*}#1HAS5G3LC2FunctionBody*/
										},
									},
									{
										"hash":"1HAS5GK0I0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/additem.svg",null),"position":"relative","x":0,"y":0,
										"tip":"New cheat",
										"OnClick":function(event){
											/*#{1HAS5GK0I5FunctionBody*/
											self.addNewCheat();
											/*}#1HAS5GK0I5FunctionBody*/
										},
									},
									{
										"hash":"1HAS5G3LC6",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"GPT Cheats:",
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
									},
									{
										"hash":"1HAS5G3LC11",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAS5G3LC16FunctionBody*/
											if(curAction){
												self.showFace("info");
											}else{
												self.showFace("help");
											}
											/*}#1HAS5G3LC16FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1HAS5G3LD4",
								"type":"hud","id":"BoxCheatList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"",
							}
						],
					}
				],
			}
		],
		/*#{1HAMSORTA1ExtraCSS*/
		/*}#1HAMSORTA1ExtraCSS*/
		faces:{
			"help":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":1
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"info":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":1
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"breaks":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":1
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"cheats":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxActions=self.BoxActions;boxBreakPoint=self.BoxBreakPoint;txtBreakOn=self.TxtBreakOn;txtBreakAt=self.TxtBreakAt;edBreakPointData=self.EdBreakPointData;boxInfo=self.BoxInfo;boxActionInfo=self.BoxActionInfo;boxCallVO=self.BoxCallVO;edPerferResult=self.EdPerferResult;btnAddBreakPoint=self.BtnAddBreakPoint;btnAddCheat=self.BtnAddCheat;boxHelp=self.BoxHelp;boxBreaks=self.BoxBreaks;boxBPList=self.BoxBPList;boxCheats=self.BoxCheats;boxCheatList=self.BoxCheatList;
			/*#{1HAMSORTA1Create*/
			boxBreakPoint.hold();
			boxActions.removeChild(boxBreakPoint);
			//Expose component to app:
			app.boxActions=boxActions;
			app.boxBreakPoint=boxBreakPoint;
			
			app.on("NewAction",(action)=>{
				let blk;
				if(session && action.session!==session)
					return;
				if(action.type!=="Log"){
					blk=boxActions.appendNewChild({type:BoxAction(action),position:"relative",margin:[0,0,20,0]});
				}
				VFACT.scrollToShow(blk,boxActions);
			});
			app.on("SessionReady",(_session)=>{
				if(_session.ui===app.boxChats){
					session=_session;
					session.on("NewBreakPoint",(stub)=>{
						self.addNewBreak(stub);
					});
					session.on("NewGPTCheat",(stub)=>{
						self.addNewCheat(stub);
					});
					self.listBreaks();
					self.listCheats();
				}
			});
			app.on("ShowActionInfo",self.showAction);
			//load and show tips:
			let showTip=async function(){
				let dir,path;
				path=(($ln==="CN")?("/-aichat/tip_cn.md"):/*EN*/("/-aichat/tip.md"));
				console.log(path);
				try{
					let text=await tabFS.readFile(path,"utf8");
					text=markdownit().render(text);
					boxHelp.webObj.innerHTML=text;
				}catch(err){
					console.error(err);
				}
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				cm=CodeMirror(boxCallVO.webObj, {
					value:"",
					mode:{name: "javascript", json: true},
					lineNumbers:true,
					undoDepth:20
				});
			}
			showTip();
			
			/*}#1HAMSORTA1Create*/
		},
		/*#{1HAMSORTA1EndCSS*/
		/*}#1HAMSORTA1EndCSS*/
	};
	/*#{1HAMSORTA1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.reset=function(){
		session=null;
		self.showFace("help");
		boxActions.clearChildren();
		//TODO: Clear info:
	};
	
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		self.showFace("help");
		boxActions.clearChildren();
	};
	
	//------------------------------------------------------------------------
	cssVO.showAction=function(action){
		curAction=action;
		hotAction.type=action.type;
		hotAction.actor=action.actor;
		hotAction.startTime=action.startTime;
		hotAction.endTime=action.endTime;
		if(action.type==="GPTCall"){
			let json;
			try{
				json=JSON.parse(action.prompt);
				hotAction.prompt=JSON.stringify(json,null,"\t");
			}catch(err){
				hotAction.prompt=action.prompt;
			}
		}else{
			hotAction.prompt=action.prompt;
		}
		hotAction.result=action.result;
		hotAction.error=action.error;
		hotAction.path=action.path||"";
		hotAction.desc=action.desc||"";
		state.isChatBot=hotAction.path.endsWith(".aichat");
		state.refresh();
		edPerferResult.text="";
		cm.doc.setValue(""+hotAction.prompt);
		self.showFace("info");
	};
	
	//************************************************************************
	//:Breakpoints related:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		cssVO.showBreak=async function(text,phase,reason){
			let pms;
			console.log("Show Break: ",text,phase);
			pms=new Promise((resolve,reject)=>{
				let action;
				app.mainUI.showFace("debug");
				breakResumeFunc=resolve;
				breakAbortFunc=reject;
				action=session.curAction;
				txtBreakOn.text="Break at: "+(reason||"Paused");
				txtBreakAt.text="Break at: "+action.actor+" / Phase: "+phase;
				orgBreakData=text;
				if(typeof(text)!=="string"){
					text=JSON.stringify(text);
				}
				edBreakPointData.text=text;
				//This will cause current action block show the break-point-box inside it:
				action.emit("ShowBreak",text,phase);
			});
			return pms;
		};
	
		//--------------------------------------------------------------------
		cssVO.resumeBreak=function(){
			let text;
			text=edBreakPointData.text;
			if(typeof(orgBreakData)!=="string"){
				try{
					text=JSON.parse(text);
				}catch(err){
					alert("Error to pase text for resume.");
					return;
				}
			}
			boxBreakPoint.parent.removeChild(boxBreakPoint);
			breakResumeFunc(text);
		};
	
		//--------------------------------------------------------------------
		cssVO.abortBreak=function(){
			boxBreakPoint.parent.removeChild(boxBreakPoint);
			breakAbortFunc(Error("Break point abort."));
		};
	
		//--------------------------------------------------------------------
		cssVO.addBreakPoint=async function(){
			let bpPhase,text,item;
			if(!curAction){
				return;
			}
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Break on input phase",code:"input"},
					{text:"Break on output phase",code:"output"},
				]
			});
			if(!item){
				return;
			}
			bpPhase=item.code;
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Don't check value",code:false},
					{text:"Check value",code:true},
				]
			});
			if(!item){
				return;
			}
			if(item.code){
				if(bpPhase=="input"){
					text=curAction.prompt;
				}else{
					text=curAction.result;
				}
			}else{
				text=undefined;
			}
			session.addBreakPoint(curAction.actor,bpPhase,text);
		};
		
		//--------------------------------------------------------------------
		cssVO.listBreaks=function(){
			let list,stub,css;
			boxBPList.clearChildren();
			list=session.getBreakPoints();
			for(stub of list){
				css={type:BoxBreakPoint(stub,session),position:"relative",x:0,y:0};
				boxBPList.appendNewChild(css);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewBreak=function(stub){
			let css={type:BoxBreakPoint(stub,session),position:"relative",x:0,y:0};
			boxBPList.appendNewChild(css);
		};
	}
	
	//************************************************************************
	//:GPTCheat related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.addGPTCheat=async function(){
			let item,text,result;
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Don't check propmt",code:false},
					{text:"Check propmt",code:true},
				]
			});
			if(!item){
				return;
			}
			if(item.code){
				let callVO;
				text=curAction.prompt;
				try{
					callVO=JSON.parse(text);
					text=callVO.messages[callVO.messages.length-1].content;
					result=curAction.result;
				}catch(err){
					return;
				}
			}else{
				text=undefined;
			}
			session.addGPTCheat(curAction.actor,text,result);
		};
	
		//--------------------------------------------------------------------
		cssVO.listCheats=function(){
			let list,stub,css;
			boxCheatList.clearChildren();
			list=session.getGPTCheats();
			for(stub of list){
				css={type:BoxGPTCheat(stub,session),position:"relative",x:0,y:0};
				boxCheatList.appendNewChild(css);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewCheat=async function(stub){
			let css;
			if(!stub){//This is triggered by UI
				let actor;
				actor=await app.modalDlg(DlgFile,{
					mode:"open",
					path:app.openDocPath,
					options:{
						preview:1,
						filter:"*.aichat"
					},
					callback:async function(filePath){
					}
				});
				if(!actor){
					return;
				}
				app.openDocPath=pathLib.dirname(actor);
				actor="/~"+actor;//Make sure it's URL.
				session.addGPTCheat(actor,undefined,"");
				return;
			}
			//This is triggered by session.emit.
			css={type:BoxGPTCheat(stub,session),position:"relative",x:0,y:0};
			boxCheatList.appendNewChild(css);
		};
		
	}
	
	//************************************************************************
	//:Refine prompt related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.refinePrompt=async function(){
			let perferResult,prompt;
			perferResult=edPerferResult.text;
			prompt=`messages:${curAction.prompt}\nI want the last AI response be: ${perferResult}\nPlease complete the following requirements:\n1) Explain why the output of AI has deviated.\n2) How can I fix the system message to fix it?\n3) How can I fix the prompt to fix it?`;
			if($ln==="CN"){
				prompt+="\n Please reply in Chinese.";
			}
			await app.modalDlg(DlgAIWork,{title:"Refine Chat",bot:"/@aichat/ai/refineprompt.aichat",prompt:prompt,waitClose:true});	
			app.emit("CheckCY");
		};
	}
	/*}#1HAMSORTA1PostCSSVO*/
	return cssVO;
};
/*#{1HAMSORTA1ExCodes*/
/*}#1HAMSORTA1ExCodes*/

UIPath.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"UIPath",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","margin","minW","minH","maxW","maxH"],
	faces:["help","info","breaks","cheats"],
	subContainers:{
	},
	/*#{1HAMSORTA0ExGearInfo*/
	/*}#1HAMSORTA0ExGearInfo*/
};
/*#{1HAMSORTA0EndDoc*/
/*}#1HAMSORTA0EndDoc*/

export default UIPath;
export{UIPath};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAMSORTA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HAMSORTA2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HAMSORTA3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HAMSORTA4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HAMSORTA5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HAMSORTA6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HAMSORTA7",
//			"attrs": {
//				"hotAction": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HANSTJIF0",
//					"attrs": {
//						"type": {
//							"type": "string",
//							"valText": "GPTCall"
//						},
//						"chatBot": {
//							"type": "auto",
//							"valText": "null"
//						},
//						"actor": {
//							"type": "string",
//							"valText": "default.aichat"
//						},
//						"prompt": {
//							"type": "string",
//							"valText": "Hello!"
//						},
//						"result": {
//							"type": "string",
//							"valText": "Hello, nice to meet you!"
//						},
//						"error": {
//							"type": "string",
//							"valText": ""
//						},
//						"startTime": {
//							"type": "auto",
//							"valText": "0"
//						},
//						"endTime": {
//							"type": "auto",
//							"valText": "10000"
//						},
//						"desc": {
//							"type": "string",
//							"valText": "Bla bla"
//						},
//						"path": {
//							"type": "string",
//							"valText": "/aichat/ai/default.aichat"
//						}
//					}
//				},
//				"isChatBot": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "UIPath",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HAMSORTA8",
//			"attrs": {
//				"help": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAO1AHD60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAO1AHD61",
//							"attrs": {}
//						}
//					}
//				},
//				"info": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAO1AHD62",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAO1AHD63",
//							"attrs": {}
//						}
//					}
//				},
//				"breaks": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAR45QCO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAR47APT0",
//							"attrs": {}
//						}
//					}
//				},
//				"cheats": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAS60KBJ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAS61P7R0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAMSORTA9",
//			"attrs": {
//				"Chat+Error": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE90",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HAMSORTA5",
//							"attrs": {}
//						},
//						"stateObj": {
//							"jaxId": "1HAMSORTA7",
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": "500: server busy..."
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				},
//				"Chat": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE91",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HAMSORTA5",
//							"attrs": {}
//						},
//						"stateObj": {
//							"jaxId": "1HAMSORTA7",
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": "500: server busy..."
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				},
//				"GPTCall": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE92",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HAMSORTA5",
//							"attrs": {}
//						},
//						"stateObj": {
//							"jaxId": "1HAMSORTA7",
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": ""
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAMSORTA1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HAMSORTA10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAMSUGM80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMSVO5B0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxActions",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%-380",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,20,20,20]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HAPUVO1O0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAPVFRA20",
//													"attrs": {
//														"type": "box",
//														"id": "BoxBreakPoint",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,10,0]",
//														"padding": "[15,5,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "2",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"error\"]",
//														"corner": "6",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV1RBD0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAPV2QOM0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtBreakOn",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Break on: Setup Run.",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAPV2QOM1",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APU3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAPV2QOM2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAPV2QOM3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV2TAP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAPV2TAP1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtBreakAt",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Break at: input / output@testfitler.js",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "true",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAPV2TAQ0",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APU7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R10",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAPV2TAQ1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAPV2TAQ2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV58FF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAPVFRA21",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Passing data:",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAPVFRA22",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APU11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R14",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R16",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAPVFRA23",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAPVFRA24",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAPV70100",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAPVFRA25",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdBreakPointData",
//																		"position": "relative",
//																		"x": "10",
//																		"y": "0",
//																		"w": "100%-20",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "30",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "1",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAPVFRA26",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APU15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R20",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R21",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7R22",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAPVFRA27",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAPVFRA28",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAPVAAU60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAPVFRA29",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxButtons",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"subAlign": "Center",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HAPVBV7R0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAPVBV7R1",
//																					"attrs": {
//																						"style": "success",
//																						"w": "100",
//																						"h": "25",
//																						"text": "Continue",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAPVBV7R2",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"success\",100,25,\"Continue\",false,\"\")",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAPVBV7R3",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APU19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAPVBV7R4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAQE22CL0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAQE299V0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAPVBV7R5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAPVBV7R6",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HAPVBV7R7",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HAPVBF7Q0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAPVBTIS0",
//																					"attrs": {
//																						"style": "error",
//																						"w": "100",
//																						"h": "25",
//																						"text": "Abort",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAPVBTIS1",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"error\",100,25,\"Abort\",false,\"\")",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,0,0,15]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAPVBTIS2",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APU23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAPVBTIS3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAQHA9SG0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAQHAIF80",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAPVBTIS4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAPVBTIS5",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HAPVBTIS6",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAPVFRA210",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APU27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAPVFRA211",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAPVFRA212",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAPVFRA213",
//													"attrs": {
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APU30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR47APU31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7S19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														},
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7S21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAPVFRA214",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAPVFRA215",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMSVO5B1",
//									"attrs": {
//										"1HAO1AHD62": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAR47APU32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAR47APU33",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD62",
//											"faceTagName": "info"
//										},
//										"1HAS60KBJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7S24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAS61P7S25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAS60KBJ0",
//											"faceTagName": "cheats"
//										},
//										"1HAO1AHD60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7S26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAS61P7S27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD60",
//											"faceTagName": "help"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMSVO5B2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMSVO5B3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMSQ5MU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMSU68P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxInfo",
//										"position": "Absolute",
//										"x": "100%",
//										"y": "0",
//										"w": "380",
//										"h": "100%",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,15,20,15]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontSecondarySub\"]",
//										"border": "[0,0,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAO0T2EK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAO0VJE93",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxActionInfo",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO106RC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO106RC1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineType",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO106RC2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO106RC3",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Type:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO106RD0",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APU35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO106RD1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO106RD2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO106RD3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO106RD4",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${\"\"+state.hotAction.type },state",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO106RD5",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APU37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO106RD6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO106RD7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAO106RD8",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO106RD9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO106RD10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO10I2P0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO10I2P1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LIneActor",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO10I2P2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO10I2P3",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Actor:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO10I2P4",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APV3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S51",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO10I2P5",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO10I2P6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAT283940",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAT2D6BN0",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "20",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAT2D6BN1",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/find.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"scale": "[-1,1]",
//																						"anchorH": "Right",
//																						"enable": "${state.isChatBot},state"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAT2D6BN2",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HAT2D6BN3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAT2IQ3T0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAT2JTHO0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAT2D6BN4",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Inspect",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAT2D6BN5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO10I2P7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO10I2P8",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${state.hotAction.actor},state",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO10I2Q0",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APV5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S54",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S55",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO10I2Q1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO10I2Q2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAO10I2Q3",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S62",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S63",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO10I2Q4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO10I2Q5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO10PF00",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO10PF01",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.path},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Source Path:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO10PF10",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO10PF11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO10PF12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO10UPT0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO10UPT1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPath",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.path},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.path},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO10UPT2",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S74",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S75",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO10UPT3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO10UPT4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO113BC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO113BC1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.desc},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Description:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO113BD0",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S78",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S79",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S81",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO113BD1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO113BD2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO117PH0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO117PH1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtDesc",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.desc},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.desc},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO117PI0",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S84",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S85",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S86",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S87",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO117PI1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO117PI2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11BET0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO11BET1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type!==\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Prompt / Input",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO11BET2",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S91",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S92",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S93",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO11BET3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO11BET4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11F680",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO11F681",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPrompt",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type!==\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.prompt},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO11F690",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S96",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S97",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S98",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S99",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO11F691",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO11F692",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11IVI0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO11IVI1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "GPT Call VO:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO11IVI2",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S102",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S103",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S104",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S105",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO11IVI3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO11IVI4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HAO6F4DL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO6F4DL1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxCallVO",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "200",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO6F4DL2",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S108",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S109",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S110",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S111",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO6F4DL3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO6F4DL4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO122KO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO122KO1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Result / Ouput:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO122KP0",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S114",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S115",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S116",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S117",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO122KP1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO122KP2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO12AQ90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO12AQ91",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtResult",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.result},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO12AQ92",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S120",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S121",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO12AQ93",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO12AQ94",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO12EN70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO12EN71",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Perfered result:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO12EN72",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV31",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S126",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S127",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S128",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S129",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO12EN73",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO12EN74",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAO12JH00",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO12JH01",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdPerferResult",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "30",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[250,250,250,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "3",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO12JH02",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S132",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S133",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S134",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S135",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO12JH03",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO12JH04",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAO12TSR0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAO12TSR1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Get Refine Hints",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAO12TSR2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",160,25,\"Get Refine Hints\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[5,0,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO12TSR3",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S138",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S139",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S140",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S141",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO12TSR4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HATEC29M0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HATECE7A0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO12TSR5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAO12TSR6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAO12TSR7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO132J10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO132J11",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Error:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO132J20",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S144",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S145",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S146",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S147",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO132J21",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO132J22",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO13D4R0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO13D4R1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtError",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "[200,0,0,1]",
//																		"text": "${state.hotAction.error},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAO13D4S0",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S150",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S151",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S152",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S153",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO13D4S1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO13D4S2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO1FG4C0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO1FG4C1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineTime",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.endTime>0},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[20,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO1FG4D0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO1FG4D1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Time Cost:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO1FG4D2",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APV41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S156",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S157",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S158",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S159",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO1FG4D3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO1FG4D4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO1FG4D5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAO1FG4D6",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${state.hotAction.endTime-state.hotAction.startTime+\"ms\"},state",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAO1FG4D7",
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAR47APV43",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S162",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S163",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S164",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7S165",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAO1FG4D8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAO1FG4D9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAO1FG4D10",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S168",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S169",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S170",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S171",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAO1FG4D11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAO1FG4D12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAQJVRTO0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAQJVRTO1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Make a Break Point",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAQJVRTO2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",160,25,\"Make a Break Point\",false,\"\")",
//																		"id": "BtnAddBreakPoint",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[15,0,0,0]",
//																		"enable": "${!!state.hotAction.actor},state"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAQJVRTO3",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR47APV47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S174",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S175",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S176",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S177",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAQJVRTP2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAQKE1HJ0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAQKEGUR0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAQJVRTP3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAQJVRTP4",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAQJVRTP5",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HARNSE1Q0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HARNSE1Q1",
//																	"attrs": {
//																		"style": "success",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Make a GPT Cheat",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HARNSE1Q2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",160,25,\"Make a GPT Cheat\",false,\"\")",
//																		"id": "BtnAddCheat",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[15,0,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HARNSE1Q3",
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HARNSE1Q4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HARNSE1Q5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S180",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S181",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S182",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7S183",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HARNSE1Q6",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HARNSE1Q7",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HARNSE1Q8",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HARNSE1Q9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HARNSE1Q10",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HARNSE1Q11",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAO0VJE94",
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI583",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO1MJI584",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI585",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO1MJI586",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR47APV49",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S186",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7T0",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAO0VJE95",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAO0VJE96",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAO19EEM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAO1AHD80",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxHelp",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "125%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.8",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAO1AHD81",
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI587",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO1MJI588",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI589",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAO1MJI590",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR47APV51",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7T2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAO1AHD82",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAO1AHD83",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAQJR02T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQJR02T1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxBreaks",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAR4828O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR4L7HP0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAR4F0AD0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAR4L7HP1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAR4L7HP2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAR4L7HP3",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T4",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T6",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T7",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T8",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAR4L7HP4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAR6OLDI0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAR6OTUK0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAR4L7HP5",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Refresh",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAR4L7HP6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAR4A5O90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAR4L7HP7",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Breakpoints:",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAR4L7HP8",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T11",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T12",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T13",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T14",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T15",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T16",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAR4L7HP9",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAR4L7HP10",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAR669O00",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAR67P600",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAR67P601",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/close.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAR67P602",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T19",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T20",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T21",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T22",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T23",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T24",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAR67P603",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAR67DKG0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAR67P604",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAR67P605",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAR67P606",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAR4L7HP11",
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T27",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T28",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T29",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T30",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T31",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T32",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAR4L7HP12",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAR4L7HP13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAR4ID1V0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR4L7HP14",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxBPList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAR4L7HP15",
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T35",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T36",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T37",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T38",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T39",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T40",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAR4L7HP16",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAR4L7HP17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAQJR02U0",
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQJR02U1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQJR02U2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQJR02U3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQJR02U4",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAR47APV53",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T43",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7T44",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAQJR02U5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAQJR02U6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAS5G3LB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAS5G3LB1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCheats",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAS5G3LB2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS5G3LB3",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5G3LB4",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAS5G3LB5",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAS5G3LB6",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "1"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAS5G3LC0",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T45",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T46",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T47",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T48",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T49",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T50",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAS5G3LC1",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5G3LC2",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAS5G3LC3",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAS5G3LC4",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Refresh",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAS5G3LC5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5GK0I0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAS5GK0I1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAS5GK0I2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAS5GK0I3",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T53",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T54",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T55",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T56",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T57",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T58",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAS5GK0I4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5GK0I5",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAS5GK0I6",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAS5GK0I7",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "New cheat",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAS5GK0I8",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAS5G3LC6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS5G3LC7",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "GPT Cheats:",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAS5G3LC8",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T61",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T62",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T63",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T64",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T65",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T66",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAS5G3LC9",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAS5G3LC10",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5G3LC11",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HAS5G3LC12",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HAS5G3LC13",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/close.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HAS5G3LC14",
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T69",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T70",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T71",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T72",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T73",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAS61P7T74",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAS5G3LC15",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5G3LC16",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HAS5G3LC17",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAS5G3LC18",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HAS5G3LD0",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HAS5G3LD1",
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T77",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T78",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T79",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T80",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T81",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T82",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAS5G3LD2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAS5G3LD3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAS5G3LD4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS5G3LD5",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCheatList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAS5G3LD6",
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T85",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T86",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T87",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T88",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T89",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAS61P7T90",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAS5G3LD7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAS5G3LD8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAS5G3LD9",
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS5G3LD11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS5G3LD13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS5G3LD15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T93",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAS61P7T94",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAS5G3LD16",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAS5G3LD17",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMSU68P1",
//									"attrs": {
//										"1HAO1AHD62": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAR47APV54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAR47APV55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD62",
//											"faceTagName": "info"
//										},
//										"1HAS60KBJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7T95",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAS61P7T96",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAS60KBJ0",
//											"faceTagName": "cheats"
//										},
//										"1HAO1AHD60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7T97",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAS61P7T98",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD60",
//											"faceTagName": "help"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMSU68P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMSU68P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HAMSORTA11",
//					"attrs": {
//						"1HAO1AHD62": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAR47APV56",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAR47APV57",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAO1AHD62",
//							"faceTagName": "info"
//						},
//						"1HAS60KBJ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAS61P7T101",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAS61P7T102",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAS60KBJ0",
//							"faceTagName": "cheats"
//						},
//						"1HAO1AHD60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAS61P7T103",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAS61P7T104",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAO1AHD60",
//							"faceTagName": "help"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HAMSORTA12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HAMSORTA13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMSORTA14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}