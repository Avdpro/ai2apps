//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HAMSORTA0StartDoc*/
import pathLib from "/@path";
import markdownit from "/@markdownit";
import {tabFS} from "/@tabos";
import {BoxAction} from "./BoxAction.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {BoxBreakPoint} from "./BoxBreakPoint.js";
import {BoxGPTCheat} from "./BoxGPTCheat.js";
import {DlgAIWork} from "./DlgAIWork.js";
/*}#1HAMSORTA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIPath=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxActions,boxBreakPoint,txtBreakOn,txtBreakAt,edBreakPointData,boxInfo,boxActionInfo,boxCallVO,edPerferResult,btnAddBreakPoint,btnAddCheat,boxHelp,boxBreaks,boxBPList,boxCheats,boxCheatList;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAMSORTA1LocalVals*/
	const app=VFACT.app;
	let session;
	let cm=null;
	
	//Break point related:
	let breakResumeFunc=null;
	let breakAbortFunc=null;
	let orgBreakData=null;
	let curAction=null;
	/*}#1HAMSORTA1LocalVals*/
	
	/*#{1HAMSORTA1PreState*/
	/*}#1HAMSORTA1PreState*/
	state={
		"hotAction":{
			"type":"GPTCall","chatBot":null,"actor":"default.aichat","prompt":"Hello!","result":"Hello, nice to meet you!","error":"","startTime":0,"endTime":10000,
			"desc":"Bla bla","path":"/aichat/ai/default.aichat"
		},
		"isChatBot":false,
		/*#{1HAMSORTA7ExState*/
		/*}#1HAMSORTA7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAMSORTA1PostState*/
	let hotAction=state.hotAction;
	/*}#1HAMSORTA1PostState*/
	cssVO={
		"hash":"1HAMSORTA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HAMSUGM80",
				"type":"hud","id":"BoxActions","x":0,"y":0,"w":">calc(100% - 380px)","h":"100%","overflow":"auto-y","padding":[10,20,20,20],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAPUVO1O0",
						"type":"box","id":"BoxBreakPoint","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,10,0],"padding":[15,5,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"border":2,"borderColor":cfgColor["error"],"corner":6,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAPV1RBD0",
								"type":"text","id":"TxtBreakOn","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Break on: Setup Run.","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HAPV2TAP0",
								"type":"text","id":"TxtBreakAt","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","color":cfgColor["fontBody"],"text":"Break at: input / output@testfitler.js","fontSize":txtSize.smallPlus,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","ellipsis":true,
							},
							{
								"hash":"1HAPV58FF0",
								"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBodySub"],"text":"Passing data:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HAPV70100",
								"type":"memo","id":"EdBreakPointData","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","margin":[5,0,0,0],"minW":"","minH":30,
								"maxW":"","maxH":200,"styleClass":"","color":[0,0,0],"border":1,"borderColor":[0,0,0,1],
							},
							{
								"hash":"1HAPVAAU60",
								"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","subAlign":1,"contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAPVBV7R0",
										"type":BtnText("success",100,25,"Continue",false,""),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAQE22CL0FunctionBody*/
											self.resumeBreak();
											/*}#1HAQE22CL0FunctionBody*/
										},
									},
									{
										"hash":"1HAPVBF7Q0",
										"type":BtnText("error",100,25,"Abort",false,""),"position":"relative","x":0,"y":0,"margin":[0,0,0,15],
										"OnClick":function(event){
											/*#{1HAQHA9SG0FunctionBody*/
											self.abortBreak();
											/*}#1HAQHA9SG0FunctionBody*/
										},
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1HAMSQ5MU0",
				"type":"box","id":"BoxInfo","x":"100%","y":0,"w":380,"h":"100%","anchorX":2,"overflow":"auto-y","padding":[10,15,20,15],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor["fontSecondarySub"],"border":[0,0,0,1],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAO0T2EK0",
						"type":"hud","id":"BoxActionInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAO106RC0",
								"type":"hud","id":"LineType","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO106RC2",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Type:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAO106RD3",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":$P(()=>(""+state.hotAction.type ),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
									}
								],
							},
							{
								"hash":"1HAO10I2P0",
								"type":"hud","id":"LIneActor","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO10I2P2",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Actor:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAT283940",
										"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":0,"scale":[-1,1],"anchorX":2,"enable":$P(()=>(state.isChatBot),state),
										"tip":"Inspect",
										"OnClick":function(event){
											/*#{1HAT2IQ3T0FunctionBody*/
											session.inspectChatBot(hotAction.path);
											app.showTip(this,"ChatBots loged into browser console.",this.w/2,this.h+5,1,0);
											/*}#1HAT2IQ3T0FunctionBody*/
										},
									},
									{
										"hash":"1HAO10I2P7",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":$P(()=>(state.hotAction.actor),state),
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
									}
								],
							},
							{
								"hash":"1HAO10PF00",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.path),state),"margin":[5,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Source Path:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO10UPT0",
								"type":"text","id":"TxtPath","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.path),state),"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.path),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO113BC0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.desc),state),"margin":[5,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Description:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO117PH0",
								"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.desc),state),"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.desc),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO11BET0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type!=="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Prompt / Input","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO11F680",
								"type":"text","id":"TxtPrompt","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.type!=="GPTCall"),state),
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.prompt),state),"fontSize":txtSize.mid,
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO11IVI0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"GPT Call VO:","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO6F4DL0",
								"type":"box","id":"BoxCallVO","position":"relative","x":0,"y":0,"w":"100%","h":200,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"minW":"","minH":"","maxW":"","maxH":200,"styleClass":"","background":[255,255,255,1],"border":1,
							},
							{
								"hash":"1HAO122KO0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!state.hotAction.error),state),"margin":[10,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Result / Ouput:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO12AQ90",
								"type":"text","id":"TxtResult","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!state.hotAction.error),state),"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.hotAction.result),state),"fontSize":txtSize.mid,
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO12EN70",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Perfered result:","fontSize":txtSize.small,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO12JH00",
								"type":"memo","id":"EdPerferResult","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"minW":"","minH":30,"maxW":"","maxH":200,"styleClass":"","color":[0,0,0],"background":[250,250,250,1],"outline":0,"border":1,"borderColor":[0,0,0,1],
								"corner":3,
							},
							{
								"hash":"1HAO12TSR0",
								"type":BtnText("primary",160,25,"Get Refine Hints",false,""),"position":"relative","x":"50%","y":0,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"anchorX":1,"margin":[5,0,0,0],
								"OnClick":function(event){
									/*#{1HATEC29M0FunctionBody*/
									self.refinePrompt();
									/*}#1HATEC29M0FunctionBody*/
								},
							},
							{
								"hash":"1HAO132J10",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(!!state.hotAction.error),state),"margin":[10,0,0,0],"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":"Error:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,
							},
							{
								"hash":"1HAO13D4R0",
								"type":"text","id":"TxtError","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(!!state.hotAction.error),state),"minW":"",
								"minH":"","maxW":"","maxH":"","styleClass":"","color":[200,0,0,1],"text":$P(()=>(state.hotAction.error),state),"fontSize":txtSize.mid,"fontWeight":"normal",
								"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
							},
							{
								"hash":"1HAO1FG4C0",
								"type":"hud","id":"LineTime","position":"relative","x":0,"y":0,"w":"100%","h":"","display":$P(()=>(state.hotAction.endTime>0),state),"margin":[20,0,0,0],
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								children:[
									{
										"hash":"1HAO1FG4D0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"Time Cost:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1HAO1FG4D5",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":$P(()=>(state.hotAction.endTime-state.hotAction.startTime+"ms"),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
										"textDecoration":"","alignV":1,
									}
								],
							},
							{
								"hash":"1HAQJVRTO0",
								"type":BtnText("warning",160,25,"Make a Break Point",false,""),"id":"BtnAddBreakPoint","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[15,0,0,0],
								"enable":$P(()=>(!!state.hotAction.actor),state),
								"OnClick":function(event){
									/*#{1HAQKE1HJ0FunctionBody*/
									self.addBreakPoint();
									/*}#1HAQKE1HJ0FunctionBody*/
								},
							},
							{
								"hash":"1HARNSE1Q0",
								"type":BtnText("success",160,25,"Make a GPT Cheat",false,""),"id":"BtnAddCheat","position":"relative","x":"50%","y":0,"display":$P(()=>(state.hotAction.type==="GPTCall"),state),
								"anchorX":1,"margin":[15,0,0,0],
								"OnClick":function(event){
									/*#{1HARNSE1Q7FunctionBody*/
									self.addGPTCheat();
									/*}#1HARNSE1Q7FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HAO19EEM0",
						"type":"hud","id":"BoxHelp","position":"relative","x":0,"y":0,"w":"125%","h":"","scale":0.8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1HAQJR02T0",
						"type":"hud","id":"BoxBreaks","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"scale":1,"padding":[0,0,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAR4828O0",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1HAR4F0AD0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,
										"tip":"Refresh",
										"OnClick":function(event){
											/*#{1HAR6OLDI0FunctionBody*/
											self.listBreaks();
											/*}#1HAR6OLDI0FunctionBody*/
										},
									},
									{
										"hash":"1HAR4A5O90",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Breakpoints:",
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
									},
									{
										"hash":"1HAR669O00",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAR67DKG0FunctionBody*/
											if(curAction){
												self.showFace("info");
											}else{
												self.showFace("help");
											}
											/*}#1HAR67DKG0FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1HAR4ID1V0",
								"type":"hud","id":"BoxBPList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							}
						],
					},
					{
						"hash":"1HAS5G3LB0",
						"type":"hud","id":"BoxCheats","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"scale":1,"padding":[0,0,10,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAS5G3LB2",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1HAS5G3LB4",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,"padding":1,
										"tip":"Refresh",
										"OnClick":function(event){
											/*#{1HAS5G3LC2FunctionBody*/
											self.listCheats();
											/*}#1HAS5G3LC2FunctionBody*/
										},
									},
									{
										"hash":"1HAS5GK0I0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/additem.svg",null),"position":"relative","x":0,"y":0,
										"tip":"New cheat",
										"OnClick":function(event){
											/*#{1HAS5GK0I5FunctionBody*/
											self.addNewCheat();
											/*}#1HAS5GK0I5FunctionBody*/
										},
									},
									{
										"hash":"1HAS5G3LC6",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"GPT Cheats:",
										"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
									},
									{
										"hash":"1HAS5G3LC11",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											/*#{1HAS5G3LC16FunctionBody*/
											if(curAction){
												self.showFace("info");
											}else{
												self.showFace("help");
											}
											/*}#1HAS5G3LC16FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1HAS5G3LD4",
								"type":"hud","id":"BoxCheatList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"",
							}
						],
					}
				],
			}
		],
		/*#{1HAMSORTA1ExtraCSS*/
		/*}#1HAMSORTA1ExtraCSS*/
		faces:{
			"help":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":1
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"info":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":1
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"breaks":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":1
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":0
				}
			},"cheats":{
				/*BoxActionInfo*/"#1HAO0T2EK0":{
					"display":0
				},
				/*BoxHelp*/"#1HAO19EEM0":{
					"display":0
				},
				/*BoxBreaks*/"#1HAQJR02T0":{
					"display":0
				},
				/*BoxCheats*/"#1HAS5G3LB0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxActions=self.BoxActions;boxBreakPoint=self.BoxBreakPoint;txtBreakOn=self.TxtBreakOn;txtBreakAt=self.TxtBreakAt;edBreakPointData=self.EdBreakPointData;boxInfo=self.BoxInfo;boxActionInfo=self.BoxActionInfo;boxCallVO=self.BoxCallVO;edPerferResult=self.EdPerferResult;btnAddBreakPoint=self.BtnAddBreakPoint;btnAddCheat=self.BtnAddCheat;boxHelp=self.BoxHelp;boxBreaks=self.BoxBreaks;boxBPList=self.BoxBPList;boxCheats=self.BoxCheats;boxCheatList=self.BoxCheatList;
			/*#{1HAMSORTA1Create*/
			boxBreakPoint.hold();
			boxActions.removeChild(boxBreakPoint);
			//Expose component to app:
			app.boxActions=boxActions;
			app.boxBreakPoint=boxBreakPoint;
			
			app.on("NewAction",(action)=>{
				let blk;
				if(session && action.session!==session)
					return;
				if(action.type!=="Log"){
					blk=boxActions.appendNewChild({type:BoxAction(action),position:"relative",margin:[0,0,20,0]});
				}
				VFACT.scrollToShow(blk,boxActions);
			});
			app.on("SessionReady",(_session)=>{
				if(_session.ui===app.boxChats){
					session=_session;
					session.on("NewBreakPoint",(stub)=>{
						self.addNewBreak(stub);
					});
					session.on("NewGPTCheat",(stub)=>{
						self.addNewCheat(stub);
					});
					self.listBreaks();
					self.listCheats();
				}
			});
			app.on("ShowActionInfo",self.showAction);
			//load and show tips:
			let showTip=async function(){
				let dir,path;
				dir=app.appDir;
				dir=dir.startsWith("//")?dir.substring(1):dir;
				dir=dir.startsWith("/~/")?dir.substring(2):dir;
				path=pathLib.join(dir,(($ln==="CN")?("tip_cn.md"):/*EN*/("tip.md")));
				console.log(path);
				try{
					let text=await tabFS.readFile(path,"utf8");
					text=markdownit().render(text);
					boxHelp.webObj.innerHTML=text;
				}catch(err){
					console.error(err);
				}
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				cm=CodeMirror(boxCallVO.webObj, {
					value:"",
					mode:{name: "javascript", json: true},
					lineNumbers:true,
					undoDepth:20
				});
			}
			showTip();
			
			/*}#1HAMSORTA1Create*/
		},
		/*#{1HAMSORTA1EndCSS*/
		/*}#1HAMSORTA1EndCSS*/
	};
	/*#{1HAMSORTA1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.reset=function(){
		session=null;
		self.showFace("help");
		boxActions.clearChildren();
		//TODO: Clear info:
	};
	
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		self.showFace("help");
		boxActions.clearChildren();
	};
	
	//------------------------------------------------------------------------
	cssVO.showAction=function(action){
		curAction=action;
		hotAction.type=action.type;
		hotAction.actor=action.actor;
		hotAction.startTime=action.startTime;
		hotAction.endTime=action.endTime;
		if(action.type==="GPTCall"){
			let json;
			try{
				json=JSON.parse(action.prompt);
				hotAction.prompt=JSON.stringify(json,null,"\t");
			}catch(err){
				hotAction.prompt=action.prompt;
			}
		}else{
			hotAction.prompt=action.prompt;
		}
		hotAction.result=action.result;
		hotAction.error=action.error;
		hotAction.path=action.path||"";
		hotAction.desc=action.desc||"";
		state.isChatBot=hotAction.path.endsWith(".aichat");
		state.refresh();
		edPerferResult.text="";
		cm.doc.setValue(hotAction.prompt);
		self.showFace("info");
	};
	
	//************************************************************************
	//:Breakpoints related:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		cssVO.showBreak=async function(text,phase,reason){
			let pms;
			console.log("Show Break: ",text,phase);
			pms=new Promise((resolve,reject)=>{
				let action;
				app.mainUI.showFace("debug");
				breakResumeFunc=resolve;
				breakAbortFunc=reject;
				action=session.curAction;
				txtBreakOn.text="Break at: "+(reason||"Paused");
				txtBreakAt.text="Break at: "+action.actor+" / Phase: "+phase;
				orgBreakData=text;
				if(typeof(text)!=="string"){
					text=JSON.stringify(text);
				}
				edBreakPointData.text=text;
				//This will cause current action block show the break-point-box inside it:
				action.emit("ShowBreak",text,phase);
			});
			return pms;
		};
	
		//--------------------------------------------------------------------
		cssVO.resumeBreak=function(){
			let text;
			text=edBreakPointData.text;
			if(typeof(orgBreakData)!=="string"){
				try{
					text=JSON.parse(text);
				}catch(err){
					alert("Error to pase text for resume.");
					return;
				}
			}
			boxBreakPoint.parent.removeChild(boxBreakPoint);
			breakResumeFunc(text);
		};
	
		//--------------------------------------------------------------------
		cssVO.abortBreak=function(){
			boxBreakPoint.parent.removeChild(boxBreakPoint);
			breakAbortFunc(Error("Break point abort."));
		};
	
		//--------------------------------------------------------------------
		cssVO.addBreakPoint=async function(){
			let bpPhase,text,item;
			if(!curAction){
				return;
			}
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Break on input phase",code:"input"},
					{text:"Break on output phase",code:"output"},
				]
			});
			if(!item){
				return;
			}
			bpPhase=item.code;
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Don't check value",code:false},
					{text:"Check value",code:true},
				]
			});
			if(!item){
				return;
			}
			if(item.code){
				if(bpPhase=="input"){
					text=curAction.prompt;
				}else{
					text=curAction.result;
				}
			}else{
				text=undefined;
			}
			session.addBreakPoint(curAction.actor,bpPhase,text);
		};
		
		//--------------------------------------------------------------------
		cssVO.listBreaks=function(){
			let list,stub,css;
			boxBPList.clearChildren();
			list=session.getBreakPoints();
			for(stub of list){
				css={type:BoxBreakPoint(stub,session),position:"relative",x:0,y:0};
				boxBPList.appendNewChild(css);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewBreak=function(stub){
			let css={type:BoxBreakPoint(stub,session),position:"relative",x:0,y:0};
			boxBPList.appendNewChild(css);
		};
	}
	
	//************************************************************************
	//:GPTCheat related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.addGPTCheat=async function(){
			let item,text,result;
			item=await app.modalDlg(DlgMenu,{
				hud:btnAddBreakPoint,
				items:[
					{text:"Don't check propmt",code:false},
					{text:"Check propmt",code:true},
				]
			});
			if(!item){
				return;
			}
			if(item.code){
				let callVO;
				text=curAction.prompt;
				try{
					callVO=JSON.parse(text);
					text=callVO.messages[callVO.messages.length-1].content;
					result=curAction.result;
				}catch(err){
					return;
				}
			}else{
				text=undefined;
			}
			session.addGPTCheat(curAction.actor,text,result);
		};
	
		//--------------------------------------------------------------------
		cssVO.listCheats=function(){
			let list,stub,css;
			boxCheatList.clearChildren();
			list=session.getGPTCheats();
			for(stub of list){
				css={type:BoxGPTCheat(stub,session),position:"relative",x:0,y:0};
				boxCheatList.appendNewChild(css);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewCheat=async function(stub){
			let css;
			if(!stub){//This is triggered by UI
				let actor;
				actor=await app.modalDlg(DlgFile,{
					mode:"open",
					path:app.openDocPath,
					options:{
						preview:1,
						filter:"*.aichat"
					},
					callback:async function(filePath){
					}
				});
				if(!actor){
					return;
				}
				app.openDocPath=pathLib.dirname(actor);
				actor="/~"+actor;//Make sure it's URL.
				session.addGPTCheat(actor,undefined,"");
				return;
			}
			//This is triggered by session.emit.
			css={type:BoxGPTCheat(stub,session),position:"relative",x:0,y:0};
			boxCheatList.appendNewChild(css);
		};
		
	}
	
	//************************************************************************
	//:Refine prompt related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.refinePrompt=async function(){
			let perferResult,prompt;
			perferResult=edPerferResult.text;
			prompt=`messages:${curAction.prompt}\nI want the last AI response be: ${perferResult}\nPlease complete the following requirements:\n1) Explain why the output of AI has deviated.\n2) How can I fix the system message to fix it?\n3) How can I fix the prompt to fix it?`;
			if($ln==="CN"){
				prompt+="\n Please reply in Chinese.";
			}
			await app.modalDlg(DlgAIWork,{title:"Refine Chat",bot:"/@aichat/ai/refineprompt.aichat",prompt:prompt,waitClose:true});	
			app.emit("CheckCY");
		};
	}
	/*}#1HAMSORTA1PostCSSVO*/
	return cssVO;
};
/*#{1HAMSORTA1ExCodes*/
/*}#1HAMSORTA1ExCodes*/

UIPath.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"UIPath",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","margin","minW","minH","maxW","maxH"],
	faces:["help","info","breaks","cheats"],
	subContainers:{
	},
	/*#{1HAMSORTA0ExGearInfo*/
	/*}#1HAMSORTA0ExGearInfo*/
};
export default UIPath;
export{UIPath};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAMSORTA0",
//	"editVersion": 137,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HAMSORTA2",
//			"editVersion": 12,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HAMSORTA3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMSORTA4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMSORTA5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMSORTA6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HAMSORTA7",
//			"editVersion": 81,
//			"attrs": {
//				"hotAction": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HANSTJIF0",
//					"editVersion": 130,
//					"attrs": {
//						"type": {
//							"type": "string",
//							"valText": "GPTCall"
//						},
//						"chatBot": {
//							"type": "auto",
//							"valText": "null"
//						},
//						"actor": {
//							"type": "string",
//							"valText": "default.aichat"
//						},
//						"prompt": {
//							"type": "string",
//							"valText": "Hello!"
//						},
//						"result": {
//							"type": "string",
//							"valText": "Hello, nice to meet you!"
//						},
//						"error": {
//							"type": "string",
//							"valText": ""
//						},
//						"startTime": {
//							"type": "auto",
//							"valText": "0"
//						},
//						"endTime": {
//							"type": "auto",
//							"valText": "10000"
//						},
//						"desc": {
//							"type": "string",
//							"valText": "Bla bla"
//						},
//						"path": {
//							"type": "string",
//							"valText": "/aichat/ai/default.aichat"
//						}
//					}
//				},
//				"isChatBot": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "UIPath",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HAMSORTA8",
//			"editVersion": 8,
//			"attrs": {
//				"help": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAO1AHD60",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAO1AHD61",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"info": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAO1AHD62",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAO1AHD63",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"breaks": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAR45QCO0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAR47APT0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"cheats": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAS60KBJ0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAS61P7R0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAMSORTA9",
//			"editVersion": 6,
//			"attrs": {
//				"Chat+Error": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE90",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA7",
//							"editVersion": 72,
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"editVersion": 116,
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": "500: server busy..."
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				},
//				"Chat": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE91",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA7",
//							"editVersion": 72,
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"editVersion": 116,
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": "500: server busy..."
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				},
//				"GPTCall": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAO0VJE92",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HAMSORTA7",
//							"editVersion": 75,
//							"attrs": {
//								"hotAction": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANSTJIF0",
//									"editVersion": 122,
//									"attrs": {
//										"type": {
//											"type": "string",
//											"valText": "Chat"
//										},
//										"chatBot": {
//											"type": "auto",
//											"valText": "null"
//										},
//										"actor": {
//											"type": "string",
//											"valText": "default.aichat"
//										},
//										"prompt": {
//											"type": "string",
//											"valText": "Hello!"
//										},
//										"result": {
//											"type": "string",
//											"valText": "Hello, nice to meet you!"
//										},
//										"error": {
//											"type": "string",
//											"valText": ""
//										},
//										"startTime": {
//											"type": "auto",
//											"valText": "0"
//										},
//										"endTime": {
//											"type": "auto",
//											"valText": "10000"
//										},
//										"desc": {
//											"type": "string",
//											"valText": "Bla bla"
//										},
//										"path": {
//											"type": "string",
//											"valText": "/aichat/ai/default.aichat"
//										}
//									}
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAMSORTA1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HAMSORTA10",
//					"editVersion": 72,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAMSUGM80",
//							"editVersion": 43,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMSVO5B0",
//									"editVersion": 138,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxActions",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%-380",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,20,20,20]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HAPUVO1O0",
//											"editVersion": 38,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPVFRA20",
//													"editVersion": 158,
//													"attrs": {
//														"type": "box",
//														"id": "BoxBreakPoint",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,10,0]",
//														"padding": "[15,5,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "2",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"error\"]",
//														"corner": "6",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV1RBD0",
//															"editVersion": 39,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPV2QOM0",
//																	"editVersion": 146,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtBreakOn",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Break on: Setup Run.",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAPV2QOM1",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU2",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APU3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R1",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R2",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R3",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R4",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAPV2QOM2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAPV2QOM3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV2TAP0",
//															"editVersion": 40,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPV2TAP1",
//																	"editVersion": 156,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtBreakAt",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Break at: input / output@testfitler.js",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "true",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAPV2TAQ0",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU6",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APU7",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R7",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R8",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R9",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R10",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAPV2TAQ1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAPV2TAQ2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAPV58FF0",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA21",
//																	"editVersion": 142,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Passing data:",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA22",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APU11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R13",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R14",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R15",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R16",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAPVFRA24",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAPV70100",
//															"editVersion": 38,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA25",
//																	"editVersion": 164,
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdBreakPointData",
//																		"position": "relative",
//																		"x": "10",
//																		"y": "0",
//																		"w": "100%-20",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "30",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "1",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA26",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APU15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R19",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R20",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7R21",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7R22",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAPVFRA28",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAPVAAU60",
//															"editVersion": 30,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA29",
//																	"editVersion": 96,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxButtons",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"subAlign": "Center",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HAPVBV7R0",
//																			"editVersion": 39,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAPVBV7R1",
//																					"editVersion": 48,
//																					"attrs": {
//																						"style": "success",
//																						"w": "100",
//																						"h": "25",
//																						"text": "Continue",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAPVBV7R2",
//																					"editVersion": 35,
//																					"attrs": {
//																						"type": "#null#>BtnText(\"success\",100,25,\"Continue\",false,\"\")",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAPVBV7R3",
//																					"editVersion": 18,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU18",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APU19",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S0",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S1",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S2",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAPVBV7R4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAQE22CL0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAQE299V0",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAPVBV7R5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAPVBV7R6",
//																					"editVersion": 2,
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"type": "gearcontainer",
//																							"jaxId": "1HAPVBV7R7",
//																							"editVersion": 4,
//																							"attrs": {
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HAPVBF7Q0",
//																			"editVersion": 37,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAPVBTIS0",
//																					"editVersion": 42,
//																					"attrs": {
//																						"style": "error",
//																						"w": "100",
//																						"h": "25",
//																						"text": "Abort",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAPVBTIS1",
//																					"editVersion": 41,
//																					"attrs": {
//																						"type": "#null#>BtnText(\"error\",100,25,\"Abort\",false,\"\")",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,0,0,15]"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAPVBTIS2",
//																					"editVersion": 18,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU22",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APU23",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S6",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S7",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S8",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S9",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAPVBTIS3",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAQHA9SG0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAQHAIF80",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAPVBTIS4",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAPVBTIS5",
//																					"editVersion": 2,
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"type": "gearcontainer",
//																							"jaxId": "1HAPVBTIS6",
//																							"editVersion": 4,
//																							"attrs": {
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA210",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APU26",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APU27",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAPVFRA211",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAPVFRA212",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAPVFRA213",
//													"editVersion": 18,
//													"attrs": {
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APU30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR47APU31",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7S19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														},
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7S21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAPVFRA214",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAPVFRA215",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAMSVO5B1",
//									"editVersion": 22,
//									"attrs": {
//										"1HAO1AHD62": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAR47APU32",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR47APU33",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD62",
//											"faceTagName": "info"
//										},
//										"1HAS60KBJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7S24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAS61P7S25",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAS60KBJ0",
//											"faceTagName": "cheats"
//										},
//										"1HAO1AHD60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7S26",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAS61P7S27",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD60",
//											"faceTagName": "help"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAMSVO5B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAMSVO5B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMSQ5MU0",
//							"editVersion": 41,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMSU68P0",
//									"editVersion": 174,
//									"attrs": {
//										"type": "box",
//										"id": "BoxInfo",
//										"position": "Absolute",
//										"x": "100%",
//										"y": "0",
//										"w": "380",
//										"h": "100%",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,15,20,15]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontSecondarySub\"]",
//										"border": "[0,0,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAO0T2EK0",
//											"editVersion": 46,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAO0VJE93",
//													"editVersion": 122,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxActionInfo",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO106RC0",
//															"editVersion": 32,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO106RC1",
//																	"editVersion": 80,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineType",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO106RC2",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO106RC3",
//																					"editVersion": 128,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Type:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO106RD0",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU34",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APU35",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S30",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S31",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S32",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S33",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO106RD1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO106RD2",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO106RD3",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO106RD4",
//																					"editVersion": 144,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${\"\"+state.hotAction.type },state",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO106RD5",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APU36",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APU37",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S36",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S37",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S38",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S39",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO106RD6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO106RD7",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO106RD8",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S42",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S43",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S44",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S45",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO106RD9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO106RD10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO10I2P0",
//															"editVersion": 34,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO10I2P1",
//																	"editVersion": 98,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LIneActor",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO10I2P2",
//																			"editVersion": 22,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2P3",
//																					"editVersion": 146,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Actor:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2P4",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV2",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APV3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S48",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S49",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S50",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S51",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2P5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO10I2P6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAT283940",
//																			"editVersion": 31,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAT2D6BN0",
//																					"editVersion": 22,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "20",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAT2D6BN1",
//																					"editVersion": 47,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/find.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"scale": "[-1,1]",
//																						"anchorH": "Right",
//																						"enable": "${state.isChatBot},state"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAT2D6BN2",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAT2D6BN3",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAT2IQ3T0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAT2JTHO0",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAT2D6BN4",
//																					"editVersion": 8,
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Inspect",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAT2D6BN5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO10I2P7",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2P8",
//																					"editVersion": 152,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${state.hotAction.actor},state",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2Q0",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV4",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APV5",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S54",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S55",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S56",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S57",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO10I2Q1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO10I2Q2",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO10I2Q3",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV6",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV7",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S60",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S61",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S62",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S63",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO10I2Q4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO10I2Q5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO10PF00",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO10PF01",
//																	"editVersion": 216,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.path},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Source Path:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO10PF10",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV8",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S66",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S67",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S68",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S69",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO10PF11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO10PF12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO10UPT0",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO10UPT1",
//																	"editVersion": 168,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPath",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.path},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.path},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO10UPT2",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S72",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S73",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S74",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S75",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO10UPT3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO10UPT4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO113BC0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO113BC1",
//																	"editVersion": 206,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.desc},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Description:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO113BD0",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S78",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S79",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S80",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S81",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO113BD1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO113BD2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO117PH0",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO117PH1",
//																	"editVersion": 156,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtDesc",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.desc},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.desc},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO117PI0",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S84",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S85",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S86",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S87",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO117PI1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO117PI2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11BET0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO11BET1",
//																	"editVersion": 188,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type!==\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Prompt / Input",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO11BET2",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV16",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV17",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S90",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S91",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S92",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S93",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO11BET3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO11BET4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11F680",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO11F681",
//																	"editVersion": 140,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPrompt",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type!==\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.prompt},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO11F690",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV18",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV19",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S96",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S97",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S98",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S99",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO11F691",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO11F692",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO11IVI0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO11IVI1",
//																	"editVersion": 198,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "GPT Call VO:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO11IVI2",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV20",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV21",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S102",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S103",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S104",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S105",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO11IVI3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO11IVI4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HAO6F4DL0",
//															"editVersion": 41,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO6F4DL1",
//																	"editVersion": 112,
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxCallVO",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "200",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO6F4DL2",
//																	"editVersion": 18,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV24",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV25",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S108",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S109",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S110",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S111",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO6F4DL3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO6F4DL4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO122KO0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO122KO1",
//																	"editVersion": 188,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Result / Ouput:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO122KP0",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV26",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV27",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S114",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S115",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S116",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S117",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO122KP1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO122KP2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO12AQ90",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO12AQ91",
//																	"editVersion": 144,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtResult",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.hotAction.result},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO12AQ92",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV28",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV29",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S120",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S121",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S122",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S123",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO12AQ93",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO12AQ94",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO12EN70",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO12EN71",
//																	"editVersion": 188,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Perfered result:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO12EN72",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV30",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV31",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S126",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S127",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S128",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S129",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO12EN73",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO12EN74",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAO12JH00",
//															"editVersion": 40,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO12JH01",
//																	"editVersion": 142,
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdPerferResult",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "30",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[250,250,250,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "3",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO12JH02",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV32",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV33",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S132",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S133",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S134",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S135",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO12JH03",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO12JH04",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAO12TSR0",
//															"editVersion": 38,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAO12TSR1",
//																	"editVersion": 36,
//																	"attrs": {
//																		"style": "primary",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Get Refine Hints",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO12TSR2",
//																	"editVersion": 62,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",160,25,\"Get Refine Hints\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[5,0,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO12TSR3",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV34",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV35",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S138",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S139",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S140",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S141",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO12TSR4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HATEC29M0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HATECE7A0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO12TSR5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAO12TSR6",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HAO12TSR7",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO132J10",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO132J11",
//																	"editVersion": 204,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "Error:",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO132J20",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV36",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV37",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S144",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S145",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S146",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S147",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO132J21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO132J22",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAO13D4R0",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO13D4R1",
//																	"editVersion": 160,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtError",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${!!state.hotAction.error},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "[200,0,0,1]",
//																		"text": "${state.hotAction.error},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "true",
//																		"ellipsis": "false",
//																		"select": "true",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO13D4S0",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV38",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV39",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S150",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S151",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S152",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S153",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO13D4S1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO13D4S2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAO1FG4C0",
//															"editVersion": 34,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO1FG4C1",
//																	"editVersion": 98,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineTime",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "${state.hotAction.endTime>0},state",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[20,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO1FG4D0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D1",
//																					"editVersion": 150,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "Time Cost:",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D2",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV40",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APV41",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S156",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S157",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S158",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S159",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO1FG4D4",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAO1FG4D5",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D6",
//																					"editVersion": 148,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "${state.hotAction.endTime-state.hotAction.startTime+\"ms\"},state",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D7",
//																					"editVersion": 22,
//																					"attrs": {
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAR47APV42",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAR47APV43",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						},
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S162",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S163",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7S164",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7S165",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAO1FG4D8",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAO1FG4D9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAO1FG4D10",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV44",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV45",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S168",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S169",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S170",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S171",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAO1FG4D11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAO1FG4D12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAQJVRTO0",
//															"editVersion": 57,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAQJVRTO1",
//																	"editVersion": 48,
//																	"attrs": {
//																		"style": "warning",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Make a Break Point",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAQJVRTO2",
//																	"editVersion": 89,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",160,25,\"Make a Break Point\",false,\"\")",
//																		"id": "BtnAddBreakPoint",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[15,0,0,0]",
//																		"enable": "${!!state.hotAction.actor},state"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAQJVRTO3",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAR47APV46",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR47APV47",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S174",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S175",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S176",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S177",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAQJVRTP2",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAQKE1HJ0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAQKEGUR0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAQJVRTP3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAQJVRTP4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HAQJVRTP5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HARNSE1Q0",
//															"editVersion": 64,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HARNSE1Q1",
//																	"editVersion": 62,
//																	"attrs": {
//																		"style": "success",
//																		"w": "160",
//																		"h": "25",
//																		"text": "Make a GPT Cheat",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HARNSE1Q2",
//																	"editVersion": 97,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",160,25,\"Make a GPT Cheat\",false,\"\")",
//																		"id": "BtnAddCheat",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "${state.hotAction.type===\"GPTCall\"},state",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[15,0,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HARNSE1Q3",
//																	"editVersion": 22,
//																	"attrs": {
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HARNSE1Q4",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HARNSE1Q5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		},
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S180",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S181",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7S182",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7S183",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HARNSE1Q6",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HARNSE1Q7",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HARNSE1Q8",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HARNSE1Q9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HARNSE1Q10",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HARNSE1Q11",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAO0VJE94",
//													"editVersion": 8,
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI583",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO1MJI584",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI585",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO1MJI586",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV48",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR47APV49",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7S186",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7T0",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAO0VJE95",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAO0VJE96",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAO19EEM0",
//											"editVersion": 46,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAO1AHD80",
//													"editVersion": 116,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxHelp",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "125%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.8",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAO1AHD81",
//													"editVersion": 8,
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI587",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO1MJI588",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAO1MJI589",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAO1MJI590",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV50",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR47APV51",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7T2",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAO1AHD82",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAO1AHD83",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAQJR02T0",
//											"editVersion": 51,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAQJR02T1",
//													"editVersion": 180,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxBreaks",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAR4828O0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP0",
//																	"editVersion": 96,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAR4F0AD0",
//																			"editVersion": 35,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAR4L7HP1",
//																					"editVersion": 40,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP2",
//																					"editVersion": 33,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP3",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T3",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T4",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T5",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T6",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T7",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T8",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAR6OLDI0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAR6OTUK0",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAR4L7HP5",
//																					"editVersion": 8,
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Refresh",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAR4A5O90",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP7",
//																					"editVersion": 112,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Breakpoints:",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP8",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T11",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T12",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T13",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T14",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T15",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T16",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAR4L7HP9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAR4L7HP10",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAR669O00",
//																			"editVersion": 32,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAR67P600",
//																					"editVersion": 22,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAR67P601",
//																					"editVersion": 28,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/close.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAR67P602",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T19",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T20",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T21",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T22",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T23",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T24",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAR67P603",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAR67DKG0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAR67P604",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAR67P605",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAR67P606",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP11",
//																	"editVersion": 14,
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T27",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T28",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T29",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T30",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T31",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T32",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAR4L7HP13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAR4ID1V0",
//															"editVersion": 36,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP14",
//																	"editVersion": 86,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxBPList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP15",
//																	"editVersion": 14,
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T35",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T36",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T37",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T38",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T39",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T40",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAR4L7HP16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAR4L7HP17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAQJR02U0",
//													"editVersion": 8,
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQJR02U1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAQJR02U2",
//																	"editVersion": 6,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQJR02U3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAQJR02U4",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAR47APV52",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAR47APV53",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T43",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7T44",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAQJR02U5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAQJR02U6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAS5G3LB0",
//											"editVersion": 55,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAS5G3LB1",
//													"editVersion": 186,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCheats",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,10,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAS5G3LB2",
//															"editVersion": 30,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LB3",
//																	"editVersion": 96,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5G3LB4",
//																			"editVersion": 36,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAS5G3LB5",
//																					"editVersion": 40,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LB6",
//																					"editVersion": 42,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "1"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC0",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T45",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T46",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T47",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T48",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T49",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T50",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC1",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5G3LC2",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAS5G3LC3",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAS5G3LC4",
//																					"editVersion": 8,
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Refresh",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5GK0I0",
//																			"editVersion": 38,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAS5GK0I1",
//																					"editVersion": 46,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS5GK0I2",
//																					"editVersion": 36,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAS5GK0I3",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T53",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T54",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T55",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T56",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T57",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T58",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAS5GK0I4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5GK0I5",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAS5GK0I6",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAS5GK0I7",
//																					"editVersion": 14,
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "New cheat",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAS5GK0I8",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HAS5G3LC6",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC7",
//																					"editVersion": 118,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "GPT Cheats:",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC8",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T61",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T62",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T63",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T64",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T65",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T66",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAS5G3LC10",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HAS5G3LC11",
//																			"editVersion": 33,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1HAS5G3LC12",
//																					"editVersion": 22,
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC13",
//																					"editVersion": 29,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/close.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC14",
//																					"editVersion": 14,
//																					"attrs": {
//																						"1HAS60KBJ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T69",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T70",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAS60KBJ0",
//																							"faceTagName": "cheats"
//																						},
//																						"1HAO1AHD60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T71",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T72",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD60",
//																							"faceTagName": "help"
//																						},
//																						"1HAO1AHD62": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAS61P7T73",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HAS61P7T74",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAO1AHD62",
//																							"faceTagName": "info"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LC15",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HAS5G3LC16",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HAS5G3LC17",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HAS5G3LC18",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1HAS5G3LD0",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD1",
//																	"editVersion": 14,
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T77",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T78",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T79",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T80",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T81",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T82",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAS5G3LD3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAS5G3LD4",
//															"editVersion": 39,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD5",
//																	"editVersion": 92,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCheatList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD6",
//																	"editVersion": 14,
//																	"attrs": {
//																		"1HAS60KBJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T85",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T86",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAS60KBJ0",
//																			"faceTagName": "cheats"
//																		},
//																		"1HAO1AHD60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T87",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T88",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD60",
//																			"faceTagName": "help"
//																		},
//																		"1HAO1AHD62": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAS61P7T89",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAS61P7T90",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAO1AHD62",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAS5G3LD8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAS5G3LD9",
//													"editVersion": 8,
//													"attrs": {
//														"1HAO1AHD60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD11",
//																	"editVersion": 6,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD60",
//															"faceTagName": "help"
//														},
//														"1HAO1AHD62": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD13",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAO1AHD62",
//															"faceTagName": "info"
//														},
//														"1HAR45QCO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS5G3LD14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS5G3LD15",
//																	"editVersion": 6,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAR45QCO0",
//															"faceTagName": "breaks"
//														},
//														"1HAS60KBJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAS61P7T93",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAS61P7T94",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAS60KBJ0",
//															"faceTagName": "cheats"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAS5G3LD16",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAS5G3LD17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAMSU68P1",
//									"editVersion": 22,
//									"attrs": {
//										"1HAO1AHD62": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAR47APV54",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR47APV55",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD62",
//											"faceTagName": "info"
//										},
//										"1HAS60KBJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7T95",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAS61P7T96",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAS60KBJ0",
//											"faceTagName": "cheats"
//										},
//										"1HAO1AHD60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAS61P7T97",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAS61P7T98",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAO1AHD60",
//											"faceTagName": "help"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAMSU68P2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAMSU68P3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HAMSORTA11",
//					"editVersion": 22,
//					"attrs": {
//						"1HAO1AHD62": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAR47APV56",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR47APV57",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAO1AHD62",
//							"faceTagName": "info"
//						},
//						"1HAS60KBJ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAS61P7T101",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAS61P7T102",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAS60KBJ0",
//							"faceTagName": "cheats"
//						},
//						"1HAO1AHD60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAS61P7T103",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAS61P7T104",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAO1AHD60",
//							"faceTagName": "help"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HAMSORTA12",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAMSORTA13",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMSORTA14",
//			"editVersion": 88,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}