//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAISegOutlet} from "./BoxAISegOutlet.js";
/*#{1HBM868OM0StartDoc*/
/*}#1HBM868OM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAISeg=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HBM868OM1LocalVals*/
	/*}#1HBM868OM1LocalVals*/
	
	/*#{1HBM868OM1PreState*/
	/*}#1HBM868OM1PreState*/
	/*#{1HBM868OM1PostState*/
	/*}#1HBM868OM1PostState*/
	cssVO={
		"hash":"1HBM868OM1",nameHost:true,
		"type":"box","x":199,"y":199,"w":"","h":"","anchorY":1,"padding":[5,0,5,20],"minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":2,"corner":[20,8,8,20],"contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HBM88QI00",
				"type":"hud","id":"BoxNames","position":"relative","x":0,"y":0,"w":"","h":"","minW":50,"maxW":100,"styleClass":"","contentLayout":"flex-y","subAlign":1,
				children:[
					{
						"hash":"1HBM8ABRG0",
						"type":"text","id":"TxtId","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"scale":0.75,"maxW":160,"styleClass":"","color":cfgColor["fontBodySub"],
						"text":"SEG01","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HBM8CBMQ0",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"maxW":160,"styleClass":"","color":cfgColor["fontBody"],
						"text":" Ask input Ask","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			},
			{
				"hash":"1HBM8H4NN0",
				"type":"hud","id":"BoxOutlets","position":"relative","x":0,"y":0,"w":"","h":"100%","padding":[0,2,0,5],"minH":30,"styleClass":"","subAlign":1,"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HBM9Q80D0",
						"type":BoxAISegOutlet(),"position":"relative","x":0,"y":0,
					}
				],
			},
			{
				"hash":"1HBM8JQ110",
				"type":"box","id":"BoxEntry","x":16,"y":"50%","w":30,"h":30,"anchorX":2,"anchorY":1,"styleClass":"","background":[255,255,255,1],"border":2,"corner":100,
			}
		],
		/*#{1HBM868OM1ExtraCSS*/
		/*}#1HBM868OM1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HBM868OM1Create*/
			/*}#1HBM868OM1Create*/
		},
		/*#{1HBM868OM1EndCSS*/
		/*}#1HBM868OM1EndCSS*/
	};
	/*#{1HBM868OM1PostCSSVO*/
	/*}#1HBM868OM1PostCSSVO*/
	return cssVO;
};
/*#{1HBM868OM1ExCodes*/
/*}#1HBM868OM1ExCodes*/


export default BoxAISeg;
export{BoxAISeg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HBM868OM0",
//	"editVersion": 50,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HBM868ON0",
//			"editVersion": 12,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HBM868ON1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HBM868ON2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HBM868ON3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HBM868ON4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HBM868ON5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HBM868ON6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HBM868ON7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HBM868OM1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HBM868ON8",
//					"editVersion": 168,
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "199",
//						"y": "199",
//						"w": "",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,0,5,20]",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "[20,8,8,20]",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HBM88QI00",
//							"editVersion": 24,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HBM8FV8B0",
//									"editVersion": 112,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxNames",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "50",
//										"minH": "",
//										"maxW": "100",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"itemsAlign": "Start",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HBM8ABRG0",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B1",
//													"editVersion": 140,
//													"attrs": {
//														"type": "text",
//														"id": "TxtId",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.75",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "160",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "SEG01",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HBM8FV8B4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HBM8CBMQ0",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B5",
//													"editVersion": 158,
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "160",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": " Ask input Ask",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HBM8FV8B7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HBM8FV8B8",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HBM8FV8B9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HBM8FV8B10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HBM8FV8B11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HBM8H4NN0",
//							"editVersion": 23,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HBM8JBJ10",
//									"editVersion": 168,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxOutlets",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,2,0,5]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"subAlign": "Center",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1HBM957PK0",
//											"jaxId": "1HBM9Q80D0",
//											"editVersion": 24,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HBM9STQ90",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBM9STQ91",
//													"editVersion": 24,
//													"attrs": {
//														"type": "#null#>BoxAISegOutlet()",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HBM9STQ92",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HBM9STQ93",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HBM9STQ94",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HBM9STQ95",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HBM8JBJ11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HBM8JBJ12",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HBM8JBJ13",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HBM8JQ110",
//							"editVersion": 21,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HBM9395G0",
//									"editVersion": 184,
//									"attrs": {
//										"type": "box",
//										"id": "BoxEntry",
//										"position": "Absolute",
//										"x": "16",
//										"y": "50%",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Right",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HBM9395G1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HBM9395G2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HBM9395G3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HBM868ON9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HBM868ON10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HBM868ON11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HBM868ON12",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}