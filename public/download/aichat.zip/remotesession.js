import {tabNT} from "/@tabos";
import Base64 from "/@tabos/utils/base64.js";

let RemoteSession,remoteSession;
//----------------------------------------------------------------------------
RemoteSession=function(localSession,sessionId){
	this.session=localSession;
	this.sessionId=sessionId;
	this.ws=null;
	this.isConnected=false;
	
	this.nextCallId=0;
	this.callMap=new Map();
	
	this.execCallback=null;
	this.execErrorCallback=null;
};
remoteSession=RemoteSession.prototype={};

//----------------------------------------------------------------------------
RemoteSession.exec=async function(session,nodeName,agent,input,options){
	let res,startNodeOpts,callAgentOpts;
	if(options){
		startNodeOpts={checkUpdate:options.checkUpdate??false};
		callAgentOpts={fromAgent:options.fromAgent??null,askUpwardSeg:options.askUpwardSeg??null};
	}else{
		startNodeOpts={checkUpdate:true};
		callAgentOpts={};
	}
	await tabNT.checkLogin();
	res=await tabNT.makeCall("StartAgentNode",{name:nodeName,path:options.nodeEntry,options:startNodeOpts,language:session.langauge});
	if(!res || res.code!==200){
		if(res){
			throw Error(`Start AgentNode error: ${res.info}`);
		}else{
			throw Error(`Start AgentNode error`);
		}
	}
	res=await tabNT.makeCall("AhCreateSession",{node:nodeName,language:session.language,globalContext:options.globalContext});
	if(!res || res.code!==200){
		if(res){
			throw Error(`Start AgentNode error: ${res.info}`);
		}else{
			throw Error(`Start AgentNode error`);
		}
	}
	let sessionId=res.sessionId;
	let remoteSsn=new RemoteSession(session,sessionId);
	await remoteSsn.start();
	return await remoteSsn.execAgent(agent,input,callAgentOpts);
};

//----------------------------------------------------------------------------
remoteSession.start=async function(){
	let pms,callback,callerror;
	pms=new Promise((resolve,reject)=>{
		callback=resolve;
		callerror=reject;
	});
	let selector,ws;	
	this.isConnected=false;
	selector=this.sessionId;
	const wsProtocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
	ws=this.ws=new WebSocket(`${wsProtocol}//${document.location.host}`);
	ws.addEventListener('open',()=>{
		ws.send(JSON.stringify({msg:"CONNECT",selector:selector}));
		console.log("Remote session WS connected.");
	});
	ws.addEventListener('message', (msg) => {
		let msgVO,msgCode;
		console.log("Message from remote session:");
		console.log(msg)
		msgVO=JSON.parse(msg.data);
		msgCode=msgVO.msg;
		if(!this.isConnected){
			if(msgCode==="CONNECTED"){
				let call;
				this.isConnected=true;
				//Notify into chat session:
				call=callback;
				if(call){
					callback=null;
					callerror=null;
					call();
				}
				console.log("Remote session ready.");
			}else{
				let handler;
				handler="WSMSG_"+msgCode;
				handler=this[handler]||ws[handler];
				if(handler){
					handler.call(this,msgVO);
				}
				console.log("Message from remote session:");
				console.log()
			}
		}else{
			let handler;
			handler="WSMSG_"+msgCode;
			handler=this[handler]||ws[handler];
			if(handler){
				handler.call(this,msgVO);
			}
		}
	});
	ws.addEventListener('close', (msg) => {
		if(this.isConnected){
			let call;
			this.isConnected=false;
			call=this.execErrorCallback;
			if(call){
				this.execCallback=null;
				this.execErrorCallback=null;
				call("Session end.");
			}
			//Notify not connected...
		}else{
			let call;
			call=callerror;
			if(call){
				callback=null;
				callerror=null;
				call("Session start failed.");
			}
		}
		this.webSocket=null;
		this.sessionId=null;
	});
	ws.addEventListener('error', (msg) => {
		//wsError(msg);
		//TODO: Show error in session?
	});
	
	//Wait remote session ready:
	try{
		await pms;
	}catch(err){
		console.log("RemoteSession start failed:");
		console.error(err);
		return;
	}
};

//----------------------------------------------------------------------------
remoteSession.execAgent=async function(agent,prompt,opts){
	let ws,pms,callback,callerror,result;
	opts=opts||{};
	ws=this.ws;
	if(!ws){
		throw Error("RemoteSession missing websocket to execAgent");
	}
	pms=new Promise((resolve,reject)=>{
		this.execCallback=resolve;
		this.execErrorCallback=reject;
	});
	this.upperAgent=this.fromAgent=opts.fromAgent;
	this.askUpwardSeg=opts.askUpwardSeg;

	//Execute agent:
	ws.send(JSON.stringify({msg:"ExecAgent",sessionId:this.sessionId,agent:agent,prompt:prompt}));
	result=await pms;
	console.log("RemoteSession execute result: ");
	console.log(result);
	return result;
};

//----------------------------------------------------------------------------
remoteSession.send2Remote=async function(msg,vo){
	let ws;
	ws=this.ws;
	if(!ws){
		throw Error("RemoteSession missing websocket to execAgent");
	}
	ws.send(JSON.stringify({msg:"Message",sessionId:this.sessionId,message:{msg:msg,message:vo}}));
};

//----------------------------------------------------------------------------
remoteSession.callRemote=async function(msg,vo){
	let ws,pms,result,callId,stub,callMsg;
	ws=this.ws;
	if(!ws){
		throw Error("RemoteSession missing websocket to execAgent");
	}
	callId=""+(this.nextCallId++);
	stub={
		callback:null,
		callerror:null
	};
	this.callMap.set(callId,stub);
	pms=new Promise((resolve,reject)=>{
		stub.callback=resolve;
		stub.callerror=reject;
	});
	callMsg=JSON.stringify({msg:"Call",sessionId:this.sessionId,callId:callId,message:{msg:msg,message:vo}});
	console.log(callMsg);
	ws.send(callMsg);
	return await pms;
};

//----------------------------------------------------------------------------
//Agent send message to client:
remoteSession.WSMSG_Message=async function(msg){
	let session,callVO,msgCode,msgVO;
	callVO=msg.message;
	msgCode=callVO.msg;
	msgVO=callVO.vo;
	session=this.session;
	switch(msgCode){
		case "ChatBlock":{
			session.addChatBlock(msgVO);
			break;
		}
		case "SetWaitBlockText":{
			await session.setWaitBlockText(msgVO.block||msgVO.blockId,msgVO.text);
			break;
		}
		case "RemoveWaitBlock":{
			await session.removeWaitBlock(msgVO.block);
			break;
		}
		case "DebugLog":{
			await session.OnRemoteDebugLog(msgVO);
			break;
		}
		default:{
			let handler,callObj;
			handler=session["WSCall_"+msgCode];
			if(handler){
				callObj=session;
			}else{
				callObj=this;
				handler=this["WSCall_"+msgCode];
			}
			if(!handler){
				throw Error(`No call-handler for msg: ${msgCode}.`);
			}
			handler.call(callObj,msgVO);
			break;
		}
	}
};

//----------------------------------------------------------------------------
//Agent call client:
remoteSession.WSMSG_Call=async function(msg){
	let session,callVO,callId,msgCode,msgVO,result;
	callId=msg.callId;
	callVO=msg.message;
	msgCode=callVO.msg;
	msgVO=callVO.vo;
	session=this.session;
	try{
		switch(msgCode){
			case "CallAgent":{
				let agent;
				agent=msgVO.agent;
				if(agent[0]!=="/"){
					throw Error(`Backend call frontend agent error: ${agent} is not a absolute path.`);
				}
				result=await session.callAgent(null,msgVO.agent,msgVO.arg||msgVO.input,{...msgVO.options,fromAgent:"$remote",askUpwardSeg:this});
				break;
			}
			case "FindAgent":{
				result=await session.findAgent(msgVO.find,msgVO.opts);
				break;
			}
			case "AskUpward":{
				result=await session.askUpward(this,msgVO.prompt);
				break;
			}
			case "AskChatInput":{
				result=await session.askChatInput(msgVO);
				break;
			}
			case "AskUserRaw":{
				result=await session.askUserRaw(msgVO);
				if(msgVO.type==="input" && msgVO.file){
					let data;
					if(Array.isArray(result)){
						data=result[1];
						if(data && typeof(data)!=="string"){
							result[1]=Base64.encode(data);
						}
					}
				}else if(msgVO.type==="audio"){
					let data;
					if(Array.isArray(result)){
						data=result[1];
						if(data && typeof(data)!=="string"){
							result[1]=Base64.encode(data);
						}
					}
				}
				break;
			}
			case "AskUserDlg":{
				result=await session.askUserDlg(msgVO);
				break;
			}
			case "AskUserView":{
				result=await session.askUserView(msgVO);
				break;
			}
			case "AddWaitBlock":{
				result=await session.addWaitBlock(msgVO.text,msgVO.hide);
				break;
			}
			case "SetWaitBlockText":{
				result=await session.setWaitBlockText(msgVO.block||msgVO.blockId,msgVO.text);
				break;
			}
			case "RemoveWaitBlock":{
				result=await session.removeWaitBlock(msgVO.block);
				break;
			}
			default:{
				let handler,callObj;
				handler=session["WSCall_"+msgCode];
				if(handler){
					callObj=session;
				}else{
					callObj=this;
					handler=this["WSCall_"+msgCode];
				}
				if(!handler){
					throw Error(`No call-handler for msg: ${msgCode}.`);
				}
				result=await handler.call(callObj,msgVO);
				break;
			}
		}
		this.ws.send(JSON.stringify({msg:"CallResult",sessionId:this.sessionId,callId:callId,result:result}));
	}catch(err){
		let errMsg=JSON.stringify({msg:"CallResult",sessionId:this.sessionId,callId:callId,error:""+err});
		this.ws.send(errMsg);
		return;
	}
};

//----------------------------------------------------------------------------
//Agent send message to client:
remoteSession.WSMSG_ExecAgentEnd=async function(msg){
	let session,result,error,call;
	result=msg.result;
	error=msg.error;

	await this.ws.close(1000,"Finish");

	if(error){
		call=this.execErrorCallback;
		if(call){
			this.execCallback=null;
			this.execErrorCallback=null;
			call(error);
		}
	}else{
		call=this.execCallback;
		if(call){
			this.execCallback=null;
			this.execErrorCallback=null;
			call(result);
		}
	}
};

//----------------------------------------------------------------------------
//CallSession result:
remoteSession.WSMSG_CallResult=async function(msg){
	let callId,stub;
	callId=msg.callId;
	stub=this.callMap.get(callId);
	if(!stub){
		return;
	}
	if("error" in msg){
		stub.callerror(msg.error);
	}else{
		stub.callback(msg.result);
	}
	this.callMap.delete(callId);
};

export default RemoteSession;
export {RemoteSession};


