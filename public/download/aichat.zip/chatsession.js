import pathLib from "/@path";
import {tabNT} from "/@tabos/tabos_nt.js";
import {AATools} from "/@tabos/AATools.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {ChatAction} from "./chataction.js";
import {ChatBot} from "./chatbot.js";
import {trimJSON} from "./utils.js";
import {VFACT,sleep} from "/@vfact";
import Base64 from "/@tabos/utils/base64.js";
import HubFileLib from "./hubfile.js";
import RemoteSession from "./remotesession.js";
const $ln=VFACT.lanCode||"EN";

// *****************************************************************************
function getErrorLocation(e) {
	if(e && e.stack) {
		const trace = e.stack.split("\n");
		return trace[trace.length - 1];
	}
	return "NA";
}

//****************************************************************************
//:ChatSession
//****************************************************************************
let ChatSession=function(ui,opts){
	this.ui=ui;
	this.uiApp=ui.app;
	this.notifyApp=ui.notifyApp;
	this.entryBot=null;
	this.agent=null;
	this.entryURL=null;
	this.baseURL=ui.basePath||"";
	this.chatMessages=[];
	this.chatBots=new Map();
	this.chatAgents=new Map();
	this.abortFunc=null;
	this.waitObj={content:""};
	this.hideInternal=0;
	opts=opts||{};
	this.opts=opts;
	this.isWaitingInput=false;
	this.curAction=null;
	this.curAISeg=null;
	this.curAgent=null;
	this.curCallId=0;
	this.breakPointMap=new Map();
	this.gptCheatMap=new Map();
	this.language=$ln;
	this.indent=0;
	if(opts.globalContext){
		this.globalContext=opts.globalContext;
	}else{
		this.globalContext={};
		makeNotify(this.globalContext);
		makeObjEventEmitter(this.globalContext);
	}
	this.aaTools=null;
	
	makeNotify(this);
	makeObjEventEmitter(this);
	makeNotify(this.waitObj);
	makeObjEventEmitter(this.waitObj);
};
let chatSession=ChatSession.prototype={};

//****************************************************************************
//:Execute chat related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.initEntry=async function(url,json){
		let bot,ext,agent,alias;
		
		if(typeof(url)==="object"){
			json=url.json;
			alias=url.alias;
			url=url.url;
		}
		this.entryURL=url;
		ext=pathLib.extname(url);
		if(ext===".aichat"){
			if(json){
				bot=await this.loadJSONBot(url,json);
			}else{
				bot=await this.loadBot(url,alias);
			}
			if(bot){
				this.entryBot=bot;
			}
			return bot;
		}
		if(ext===".js"){
			agent=await this.loadAgent(url,alias);
			if(agent){
				this.entryBot=agent;
				this.agent=agent;
			}
			return agent;
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.execChat=async function(botPath,prompt){
		let bot,ext;
		ext=pathLib.extname(botPath);
		if(ext===".aichat"){
			bot=await this.loadBot(botPath);
			if(bot){
				return await this.execBot(botPath,bot,prompt);
			}
		}
		if(ext===".js"){
			bot=await this.loadAgent(botPath);
			if(bot){
				return await this.execAgent(bot,prompt);
			}
		}
		throw Error((($ln==="CN")?(`无法加载AI聊天: ${botPath}`):/*EN*/(`Can't load AI chat: ${botPath}`)));
	};

	//------------------------------------------------------------------------
	chatSession.execBot=async function(botPath,bot,prompt){
		let ui,blkVO,blk,waitObj,result,curAction;
		curAction=this.curAction;
		ui=this.ui;
		//Add user text prompt:
		blkVO={type:"user",text:prompt};
		ui.appendChatBlock(blkVO);
		ui.incIndent();
		//Add wait block:
		blkVO={type:"wait",text:"AI is thinking..."};
		blk=ui.appendChatBlock(blkVO);
		try{
			//Log actiion:
			//Execute the call
			result=await this.execBotChat(botPath,prompt,blk);
			//Call finished, remove wait-block
			ui.removeChatBlock(blk,true);
			ui.decIndent();
			//Append result block:
			if(result){
				blkVO={type:"assistant",text:result||(($ln==="CN")?("AI 调用完成。"):/*EN*/("AI Call done."))};
				blk=ui.appendChatBlock(blkVO);
			}
			if(bot.filterEndRound){
				let action,text=result;
				action=ChatAction.logFilter(this,bot,"round",bot.filterEndRoundURL,result);
				try{
					text=await this.checkStep(text,"input");
					text=await bot.filterEndRound(text);
					text=await this.checkStep(text,"output");
				}catch(err){
					action.failed(err);
					throw err;
				}
				action.end(text);
			}
		}catch(err){
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			ui.removeChatBlock(blk,true);
			ui.decIndent();
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.indentMore=function(){
		this.indent+=1;
	};

	//------------------------------------------------------------------------
	chatSession.indentLess=function(){
		this.indent-=1;
	};

	//------------------------------------------------------------------------
	chatSession.findAgent=async function(find,opts){
		let tools=this.aaTools;
		if(!tools){
			tools=new AATools();
			await tools.load();
			this.aaTools=tools;
		}
		let tool=tools.findTool(find);
		if(tool){
			let agentNode,path;
			agentNode=tool.agentNode;
			if(agentNode){
				path=pathLib.basename(tool.filePath);
			}else{
				path=tool.filePath;
			}
			return {agentNode,path,filePath:path,capabilities:tool.capabilities,filters:tool.filters,ranks:tool.ranks,meta:tool.meta};
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	chatSession.callAgent=async function(agentNode,agentPath,input,opts){
		let secret,result;
		opts=opts||{};
		secret=opts.secret;
		if(secret){
			this.hideInternal++;
		}
		if(agentPath && agentPath.kind){
			let find=await this.findAgent(agentPath);
			if(find){
				agentNode=find.agentNode;
				agentPath=find.path;
			}else{
				return {status:"Failed",result:"Failted",reason:"Can't find agent by find."}
			}
		}
		if(agentNode){//This is a remote chat
			return await RemoteSession.exec(this,agentNode,agentPath,input,opts);
		}else{
			result=await this.executeAgent(agentPath,input,opts);
			if(secret){
				this.hideInternal--;
			}
			return result;
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.pipeChat=async function(botPath,input,hint,secret=false){
		let ui,ext,blkVO,blk,waitObj,result,action,curAction;
		ext=pathLib.extname(botPath);
		if(ext===".aichat"){
			curAction=this.curAction;
			ui=this.ui;
			//Add wait block:
			blkVO={type:"wait",text:hint||"AI is thinking..."};
			blk=ui.appendChatBlock(blkVO);
			try{
				if(secret){
					this.hideInternal++;
				}
				result=await this.execBotChat(botPath,input,blk);
				ui.removeChatBlock(blk,true);
				if(secret){
					this.hideInternal--;
				}
			}catch(err){
				if(this.curAction){
					this.curAction.failed(err);
				}
				this.curAction=curAction;
				ui.removeChatBlock(blk,true);
				throw err;
			}
			return result;
		}else if(ext===".js"){
			if(secret){
				this.hideInternal++;
			}
			result=await this.execAgent(botPath,input);
			if(secret){
				this.hideInternal--;
			}
			return result;
		}else{
			throw Error(`Session.pipeChat: Unsupport bot file type: ${ext} of url: ${botPath}, only js file supported by now.`);
		}
		return input;
	};

	//------------------------------------------------------------------------
	chatSession.execBotChat=async function(botPath,prompt,blk){
		let chatBot,pms,waitObj,callVO,filtered,functionCall,chatAct,action;

		//Get chatBot:
		chatBot=this.chatBots.get(botPath);
		if(!chatBot){
			chatBot=await this.loadBot(botPath);
		}
		chatAct=ChatAction.logChat(this,chatBot,prompt);
		//Update chatBot memory is needed:
		await chatBot.checkMemory();
		if(!chatBot.sysMsg){
			let result;
			prompt=await this.checkStep(prompt,"input");
			//This bot will not call AI directly, it will happens in it's input/post filters
			try{
				result=await chatBot.execNoAICall(prompt)
				result=await this.checkStep(result,"output");
			}catch(err){
				chatAct.failed(err);
				throw err;
			}
			chatAct.end(result)
			return result;
		}
		//Generate callVO:
		try{
			callVO=await chatBot.genChatCallVO(prompt);
		}catch(err){
			if(typeof(err)==="string"){
				chatAct.end(err)
				return err;
			}
			throw err;
		}

		pms=new Promise(async (resolveFunc,rejectFunc)=>{
			let result,content,functionCall;
			this.abortFunc=rejectFunc;
			try{
				let cheat;
				do{
					//Clear wait obj;
					waitObj=this.waitObj;
					waitObj.content="";
					waitObj.functionCall=null;
					waitObj.inputTokens=0;
					waitObj.outputTokens=0;
					if(blk && blk.trace){
						blk.trace(waitObj);
					}

					//Call NT-API:
					if(chatBot.secretInternal){
						this.hideInternal++
					}
					action=ChatAction.logGPTCall(this,chatBot.url,callVO);
					try{
						let res;
						callVO=await this.checkStep(callVO,"input");
						cheat=this.getGPTCheat(chatBot.url,callVO);
						if(cheat){
							content=cheat.result;
							content=await this.checkStep(content,"output");
							waitObj.content=content;
							if(cheat.funcationCall){
								functionCall=cheat.result;
								functionCall=await this.checkStep(functionCall,"funcion_call");
							}
						}else{
							res=await tabNT.makeCall("AICallStream",callVO,10000);
							//console.log("CallVO:");
							//console.log(JSON.stringify(callVO,null,"\t"));
							if(this.abortFunc!==rejectFunc){//check abort:
								return;
							}
							if(res.code!==200){
								throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
							}

							//Read stream:
							await this.readChatStream(res.streamId,rejectFunc);
							if(chatBot.secretInternal){
								this.hideInternal--;
							}
							if(this.abortFunc!==rejectFunc){//check abort:
								return;
							}
							content=waitObj.content;
							functionCall=waitObj.functionCall;
							content=await this.checkStep(content,"output");
							waitObj.content=content;
							if(functionCall){
								functionCall=await this.checkStep(functionCall,"funcion_call");
							}
						}
					}catch(err){
						action.failed(err);
						rejectFunc(err);
					}
					action.end(content);
					if(functionCall){
						callVO=await chatBot.applyFunctionCall(functionCall,callVO);
					}else{
						callVO=null;
					}
				}while(callVO);

				result=waitObj.content;
				this.abortFunc=null;
				//Apply call result to bot:
				try{
					result=await chatBot.applyAIFeedback(result);
					result=await this.checkStep(result,"output");
				}catch(err){
					if(err==="#END"){
						return result;
					}
					if(typeof(err)==="string"){
						return err;
					}
					rejectFunc(err);
				}

				chatAct.end(result)
				resolveFunc(result);
			}catch(err){
				chatAct.failed(err)
				this.abortFunc=null;
				rejectFunc(err);
			}
		});
		return await pms;
	};

	//------------------------------------------------------------------------
	chatSession.makeAICall=async function(segPath,opts,messages,fromSeg=false){
		let callVO,action,res,result;
		let agent,seg;
		
		agent=this.curAgent;
		seg=this.curAISeg;
		
		callVO={
			platform:opts.platform||"OpenAI",
			model:opts.mode||"gpt-3.5-turbo",
			temperature:opts.temperature,
			max_tokens:opts.maxToken,
			messages:messages,
			top_p:opts.topP>=0?opts.topP:1,
			presence_penalty:opts.prcP>=0?opts.prcP:0,
			frequency_penalty:opts.fqcP>=0?opts.fqcP:0,
			response_format:opts.responseFormat||"text"
		};
		{
			let models=this.globalContext.models||{};
			let name=callVO.model;
			if(name[0]==="$"){
				name=name.substring(1);
				let vo=models[name];
				if(!vo){
					throw Error(`Can't find platform shortcut: ${name}`);
				}
				callVO.platform=vo.platform;
				callVO.model=vo.model;
			}
		}
		if("seed" in opts){
			callVO.seed=opts.seed;
		}
		if(opts.apis){
			callVO.functions=opts.apis.functions;
			if(opts.parallelFunction){
				callVO.parallelFunction=true;
			}
		}
		if(fromSeg && agent && seg && seg.jaxId){
			let prompt;
			prompt=messages[messages.length-1].content;
			this.notifyApp && this.notifyApp.emit("AISegCallLLMInput",agent.jaxId,seg.jaxId,prompt,this.curCallId,opts,messages);
		}
		try{
			action=ChatAction.logGPTCall(this,segPath,callVO);
			res=await tabNT.makeCall("AICall",callVO,60000*5);
			if(!res || res.code!==200){
				if(!res){
					throw Error(`CallAI failed, maybe network error.`);
				}else{
					throw Error(`CallAI error ${res.code}${res.info?(": "+res.info):""}.`);
				}
			}
			result=res.message;
			if(fromSeg && agent && seg && seg.jaxId){
				this.notifyApp && this.notifyApp.emit("AISegCallLLMResult",agent.jaxId,seg.jaxId,result,this.curCallId,{inputTokens:0,outputTokens:0},opts,messages);
			}
			if(opts.responseFormat==="json_object"){
				//Ensure JSON, or maybe retry...
				try{
					result=trimJSON(result);
					result=JSON.stringify(result);
				}catch(err){
					throw `Failed parse JSON from LLM result:\n${result}`;
				}
			}
			action.end(result);
		}catch(err){
			action.failed(result);
			console.warn(err);
			throw err;
		}
		this.notifyApp && this.notifyApp.emit("UpdateTokenGas");
		this.uiApp && this.uiApp.emit("UpdateTokenGas");
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.callSegLLM=async function(segPath,opts,messages,fromSeg=false){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret,seg,agent;

		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:opts.hint||(($ln==="CN")?("AI正在思考中..."):/*EN*/("AI is thinking..."))};
		if(ui){
			blk=ui.appendChatBlock(blkVO);
		}
		try{
			secret=!!opts.secret;
			if(secret){
				this.hideInternal++;
			}
			agent=this.curAgent;
			seg=this.curAISeg;
			if(fromSeg && agent && seg && seg.jaxId){
				let prompt;
				prompt=messages[messages.length-1].content;
				this.notifyApp && this.notifyApp.emit("AISegCallLLMInput",agent.jaxId,seg.jaxId,prompt,this.curCallId,opts,messages);
			}
			result=await this.execLLMChat(segPath,opts,messages,blk);
			if(secret){
				this.hideInternal--;
			}
			if(blk){
				console.log(`LLM usage: ${blk.inputTokens}/${blk.outputTokens}`);
				if(fromSeg && agent && seg && seg.jaxId){
					this.notifyApp && this.notifyApp.emit("AISegCallLLMResult",agent.jaxId,seg.jaxId,result,this.curCallId,{inputTokens:blk.inputTokens,outputTokens:blk.outputTokens},opts,messages);
				}
			}else{
				if(fromSeg && agent && seg && seg.jaxId){
					this.notifyApp && this.notifyApp.emit("AISegCallLLMResult",agent.jaxId,seg.jaxId,result,this.curCallId,{inputTokens:0,outputTokens:0},opts,messages);
				}
			}
			if(blk){
				ui.removeChatBlock(blk,true);
			}
		}catch(err){
			console.error(err);
			if(blk){
				ui.removeChatBlock(blk,true);
			}
			if(fromSeg && ui){
				//TODO: Check gas...
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?(`调用LLM错误: ${err}\n你想再试一次吗?`):/*EN*/(`Call LLM error: ${err}\nWould you like to try again?`)),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.callSegLLM(segPath,opts,messages,fromSeg);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.execLLMChat=async function(callPath,opts,messages,blk){
		let action,callVO,cheat,pms,waitObj,result;
		callVO={
			platform:opts.platform||"OpenAI",
			model:opts.mode||"gpt-3.5-turbo",
			temperature:opts.temperature,
			max_tokens:opts.maxToken,
			messages:messages,
			top_p:opts.topP>=0?opts.topP:1,
			presence_penalty:opts.prcP>=0?opts.prcP:0,
			frequency_penalty:opts.fqcP>=0?opts.fqcP:0,
			response_format:opts.responseFormat||"text"
		};
		{
			let models=this.globalContext.models||{};
			let name=callVO.model;
			if(name[0]==="$"){
				name=name.substring(1);
				let vo=models[name];
				if(!vo){
					throw Error(`Can't find platform shortcut: ${name}`);
				}
				callVO.platform=vo.platform;
				callVO.model=vo.model;
			}
		}
		if("seed" in opts){
			callVO.seed=opts.seed;
		}
		if(opts.apis){
			callVO.functions=opts.apis.functions;
			if(opts.parallelFunction){
				callVO.parallelFunction=true;
			}
		}
		//Clear wait obj;
		waitObj=this.waitObj;
		waitObj.content="";
		waitObj.functionCall=null;
		waitObj.toolCalls=null;
		waitObj.inputTokens=0;
		waitObj.outputTokens=0;
		if(blk){
			blk.trace(waitObj);
		}
		pms=new Promise(async (resolveFunc,rejectFunc)=>{
			let result,content,functionCall,res,toolCalls;
			this.abortFunc=rejectFunc;
			action=ChatAction.logGPTCall(this,callPath,callVO);
			try{
				callVO=await this.checkStep(callVO,"input");
				cheat=this.getGPTCheat(callPath,callVO);
				if(cheat){
					content=cheat.result;
					result=await this.checkStep(content,"output");
					waitObj.content=result;
				}else{
					res=await tabNT.makeCall("AICallStream",callVO,60000);
					if(this.abortFunc!==rejectFunc){//check abort:
						return;
					}
					//TODO: Deal with no gas:
					if(res.code===403){//User info error.
						throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
					}else if(res.code!==200){
						throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
					}

					//Read stream:
					await this.readChatStream(res.streamId,rejectFunc);
					if(this.abortFunc!==rejectFunc){//check abort:
						return;
					}
					content=waitObj.content;
					functionCall=waitObj.functionCall;
					toolCalls=waitObj.toolCalls;
					result=await this.checkStep(content,"output");
					waitObj.content=result;
				}
				action.end(result);
			}catch(err){
				action.failed(err);
				rejectFunc(err);
				return;
			}
			
			if(functionCall||toolCalls){//Call function, call execLLMCall again.
				let callResult,name,stub,func,args,action;
				if(functionCall){
					functionCall=await this.checkStep(functionCall,"funcion_call");
					name=functionCall.name;
					stub=opts.apis.stubs[name];
					if(!stub){
						throw new Error(`API Function: ${name} not found.`);
					}
					func=stub.func;
					args=functionCall["arguments"];
					action=ChatAction.logAPICall(this,name,args,stub);
					try{
						args=await this.checkStep(args,"input");
						callResult=await func.call(this,JSON.parse(args));
						callResult=await this.checkStep(callResult,"output");
					}catch(err){
						action.failed(err);
						rejectFunc(err);
					}
					action.end(callResult);
					callResult=await this.checkStep(callResult,"funcion_result");
					messages=[...messages];
					messages.push({role:"assistant",content:"",function_call:functionCall});
					messages.push({role:"function",name:name,content:callResult});
				}else{//toolCalls
					let i,n,toolCall;
					messages=[...messages];
					messages.push({role:"assistant",content:"",tool_calls:toolCalls});
					n=toolCalls.length;
					for(i=0;i<n;i++){
						toolCall=toolCalls[i];
						functionCall=toolCall.function;
						functionCall=await this.checkStep(functionCall,"funcion_call");
						name=functionCall.name;
						stub=opts.apis.stubs[name];
						if(!stub){
							throw new Error(`API Function: ${name} not found.`);
						}
						func=stub.func;
						args=functionCall["arguments"];
						action=ChatAction.logAPICall(this,name,args,stub);
						try{
							args=await this.checkStep(args,"input");
							callResult=await func.call(this,JSON.parse(args));
							callResult=await this.checkStep(callResult,"output");
						}catch(err){
							action.failed(err);
							rejectFunc(err);
						}
						action.end(callResult);
						callResult=await this.checkStep(callResult,"funcion_result");
						messages.push({tool_call_id:toolCall.id,role:"tool",name:name,content:callResult});
					}
				}
				result=await this.callSegLLM(callPath,opts,messages);
			}
			resolveFunc(result);
		});
		try{
			result=await pms;
			if(opts.responseFormat==="json_object"){
				//Ensure JSON, or maybe retry...
				try{
					result=trimJSON(result);
					result=JSON.stringify(result);
				}catch(err){
					throw `Failed parse JSON from LLM result:\n${result}`;
				}
			}
		}catch(err){
			console.warn(err);
			throw err;
		}
		this.notifyApp && this.notifyApp.emit("UpdateTokenGas");
		this.uiApp && this.uiApp.emit("UpdateTokenGas");
		return result;
	};
	
	//------------------------------------------------------------------------
	ChatSession.execLLMCall=async function(opts,messages){
		async function readChatStream(streamId){
			let res,pmt,streamObj;
			streamObj={};
			pmt="";
			do{
				res=await tabNT.makeCall("readAIChatStream",{streamId:streamId});				
				if(res.code!==200){
					console.log("Read chat stream error: ");
					console.log(res);
					break;
				}
				pmt=res.message;
				streamObj.content=pmt;
				if(res.functionCall){
					streamObj.functionCall=res.functionCall;
				}
				if(res.toolCalls){
					streamObj.toolCalls=res.toolCalls;
				}
				if(res.inputTokens>=0){
					streamObj.inputTokens=res.inputTokens;
				}
				if(res.outputTokens>=0){
					streamObj.outputTokens=res.outputTokens;
				}
			}while(!res.closed);
			return streamObj;
		};

		let action,callVO,res,pms,waitObj,result;
		callVO={
			platform:opts.platform||"OpenAI",
			model:opts.mode||"gpt-3.5-turbo",
			temperature:opts.temperature,
			max_tokens:opts.maxToken,
			messages:messages,
			top_p:opts.topP>=0?opts.topP:1,
			presence_penalty:opts.prcP>=0?opts.prcP:0,
			frequency_penalty:opts.fqcP>=0?opts.fqcP:0,
			response_format:opts.responseFormat||"text"
		};
		if("seed" in opts){
			callVO.seed=opts.seed;
		}
		if(opts.apis){
			callVO.functions=opts.apis.functions;
			if(opts.parallelFunction){
				callVO.parallelFunction=true;
			}
		}
		res=await tabNT.makeCall("AICallStream",callVO,60000);
		if(res.code===403){//User info error.
			throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
		}else if(res.code!==200){
			throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
		}
		//Read stream:
		res=await readChatStream(res.streamId);
		return res;
	};

	//------------------------------------------------------------------------
	chatSession.readChatStream=async function(streamId,rejectFunc){
		let res,pmt,streamObj;
		streamObj=this.waitObj;
		pmt="";
		do{
			res=await tabNT.makeCall("readAIChatStream",{streamId:streamId});				
			if(res.code!==200){
				console.log("Read chat stream error: ");
				console.log(res);
				break;
			}
			pmt=res.message;
			if(this.abortFunc===rejectFunc){
				streamObj.content=pmt;
				if(res.functionCall){
					streamObj.functionCall=res.functionCall;
				}
				if(res.toolCalls){
					streamObj.toolCalls=res.toolCalls;
				}
				if(res.inputTokens>=0){
					streamObj.inputTokens=res.inputTokens;
				}
				if(res.outputTokens>=0){
					streamObj.outputTokens=res.outputTokens;
				}
				streamObj.emit("content");
			}else{
				//Chat canceled?
				streamObj.emit("close");
				return "";
			}
		}while(!res.closed);
		streamObj.emit("close");
		return streamObj.content;
	};

	//------------------------------------------------------------------------
	chatSession.abortChat=function(msg){
		if(this.abortFunc){
			this.abortFunc(msg);
			this.abortFunc=null;
		}
	};

	//------------------------------------------------------------------------
	chatSession.sysCall=async function(msg,callVO,fromSeg,timeout=10000){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret;
		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:(($ln==="CN")?("系统调用中..."):/*EN*/("System calling..."))};
		blk=ui.appendChatBlock(blkVO);
		try{
			result=await tabNT.makeCall(msg,callVO,timeout);
			if(result.code!==200){
				throw `System call error ${result.code}: ${result.info||"Error"}`;
			}
			ui.removeChatBlock(blk,true);
		}catch(err){
			console.error(err);
			ui.removeChatBlock(blk,true);
			if(fromSeg){
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?("Error: "+err+"\n调用系统API错误，你想再试一次吗?"):/*EN*/("Error: "+err+"\nCall System API error, would you like to try again?")),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.sysCall(msg,callVO,fromSeg,timeout);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.webCall=async function(callVO,fromSeg,timeout=10000){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret;

		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:(($ln==="CN")?("Web调用中..."):/*EN*/("Web calling..."))};
		blk=ui.appendChatBlock(blkVO);
		try{
			result=await tabNT.makeCall('webAPICall',callVO,timeout);
			ui.removeChatBlock(blk,true);
		}catch(err){
			console.error(err);
			ui.removeChatBlock(blk,true);
			if(fromSeg){
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?("调用Web错误，你想再试一次吗?"):/*EN*/("Call Web error, would you like to try again?")),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.webCall(callVO,fromSeg,timeout);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.callHub=async function(msg,callVO,timeout){
		return await tabNT.makeCall(msg,callVO,timeout);
	};
}

//****************************************************************************
//:Ask user interactive:
//****************************************************************************
{
	const waitBlockMap=new Map();
	let nextBlockId=0;
	//------------------------------------------------------------------------
	chatSession.askChatInput=async function(vo){
		let ui,pms,action,result;
		ui=this.ui;
		if(!ui.askChatInput){
			throw Error("Chat dialog can't ask user for input chat!");
		}
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			this.isWaitingInput=true;
			result=await ui.askChatInput(vo);
			this.isWaitingInput=false;
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUser=async function(vo){
		let ui,pms,action,result,resultText;
		ui=this.ui;
		if(!ui.askUser){
			throw Error("Chat dialog can't ask user for anyting!");
		}
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			[resultText,result]=await ui.askUserRaw(vo);
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUserRaw=async function(vo){
		let ui,pms,action,result,role;
		ui=this.ui;
		if(!ui.askUser){
			throw Error("Chat dialog can't ask user for anyting!");
		}
		vo.role=vo.role||"assistant";
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			result=await ui.askUserRaw(vo);
			result=await this.checkStep(result,"output");
			if(Array.isArray(result) && result[0]){
				this.addChatText("user",result[0]);
			}
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};

	//------------------------------------------------------------------------
	chatSession.askUserDlg=async function(vo){
		let uiApp,dlgPath,pms,action,result,role;
		uiApp=this.uiApp;
		role=vo.role||"assistant";
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			if(vo.tip){
				this.ui.appendChatBlock({role:role,type:role,text:vo.tip});
			}
			result=await uiApp.modalDlg(vo.dlgPath||vo.dialog,vo.arg);
			if(vo.showOutput && result){
				if(result.chatOutput){
					this.ui.appendChatBlock({role:role,type:role,text:result.chatOutput});
				}else{
					this.ui.appendChatBlock({role:role,type:role,text:result});
				}
			}
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUserView=async function(vo){
		let ui,pms,action,result,role;
		ui=this.ui;
		if(!ui.askUser){
			throw Error("Chat dialog can't ask user for anyting!");
		}
		vo.role=vo.role||"assistant";
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			result=await ui.askUserView(vo);
			result=await this.checkStep(result,"output");
			if(Array.isArray(result) && result[0]){
				this.addChatText("user",result[0]);
			}
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};

	//------------------------------------------------------------------------
	chatSession.addChatText=async function(role,text,opts){
		let orgOpts=opts;
		let ui=this.ui;
		role=role||"event";
		ChatAction.logChatText(this,role,text);
		opts={...opts};
		if(opts.indent>0){
			opts.indent=this.indent+opts.indent;
		}else{
			opts.indent=this.indent;
		}
		if(opts.image && opts.image.startsWith("hub://")){
			opts.image=await this.normURL(opts.image);
		}
		if(opts.audio && opts.audio.startsWith("hub://")){
			opts.audio=await this.normURL(opts.audio);
		}
		opts={role:role,type:role,text:text,...opts};
		if(opts.channel==="Process" && ui.appendProcessBlock){
			this.ui.appendProcessBlock(opts);
		}else{
			this.ui.appendChatBlock(opts);
			this.emit("NewChatBlock",opts);
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.addChatBlock=async function(opts){
		let orgOpts=opts;
		let ui=this.ui;
		opts={...opts};
		if(opts.image && opts.image.startsWith("hub://")){
			opts.image=await this.normURL(opts.image);
		}
		if(opts.audio && opts.audio.startsWith("hub://")){
			opts.audio=await this.normURL(opts.audio);
		}
		if(opts.channel==="Process" && ui.appendProcessBlock){
			ui.appendProcessBlock(opts);
		}else{
			ui.appendChatBlock(opts);
			this.emit("NewChatBlock",opts);
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.addWaitBlock=async function(text,hide,blockId){
		let blkVO,blk;
		blockId=blockId||(""+(nextBlockId++));
		blkVO={type:"wait",text:text||"..."};
		blk=this.ui.appendChatBlock(blkVO);
		blk.hideWaitText=hide||false;
		waitBlockMap.set(blockId,blk);
		return blockId;
	};

	//------------------------------------------------------------------------
	chatSession.setWaitBlockText=async function(blkId,text){
		let blk;
		blk=waitBlockMap.get(blkId);
		if(blk){
			blk.setWaitText(text);
		}
	};

	//------------------------------------------------------------------------
	chatSession.removeWaitBlock=async function(blkId){
		let blk;
		blk=waitBlockMap.get(blkId);
		if(blk){
			this.ui.removeChatBlock(blk);
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.addChatInputAsset=async function(name,url,promptFix,data){
		let ui;
		if(!this.isWaitingInput){
			return;
		}
		if(Array.isArray(name)){
			let vo;
			for(vo of name){
				await this.addChatInputAsset(vo.name,vo.url,vo.promptFix,vo.data);
			}
			return;
		}
		ui=this.ui;
		if(!ui.addChatAsset){
			throw Error("Current AI-Chat-UI doesn't support addChatAsset.");
		}
		await ui.addChatAsset(name,url,promptFix,data);
	};
}

//****************************************************************************
//:Agent related:
//****************************************************************************
{
	let callSeqId=0;
	let frameSeqId=0;
	let loadingAgentURL=null;
	//------------------------------------------------------------------------
	chatSession.loadAgent=async function(url,alias,newAgent=true){
		let md,func,agent,oldURL,sourceDef;
		alias=alias||url;
		if(!newAgent){
			agent=this.chatAgents.get(alias);
			if(agent){
				return agent;
			}
		}
		oldURL=loadingAgentURL;
		loadingAgentURL=url;
		if(url.startsWith("//")){
			url="/~"+url.substring(1);
		}
		md=await import(url);
		func=md.default;
		agent=await func(this);
		agent.url=url;
		agent.alias=alias;
		if(!newAgent){
			this.chatAgents.set(alias,agent);
		}
		loadingAgentURL=oldURL;
		sourceDef=func.sourceDef;
		if(sourceDef){
			agent.sourceDef=sourceDef;
		}else{
			try{
				let code,pos,mark;
				code=await (await fetch(url)).text();
				mark="/*Cody Project Doc*/";
				pos=code.indexOf(mark);
				if(pos>0){
					code=code.substring(pos+mark.length);
					code=code.replaceAll("\n//","\n");
					sourceDef=JSON.parse(code);;
					agent.sourceDef=sourceDef;
					func.sourceDef=sourceDef;
				}
			}catch(e){
				//do nothing;
				agent.sourceDef=null;
			}
		}
		return agent;
	};
	
	//------------------------------------------------------------------------
	chatSession.runSeg=async function(agent,segVO){
		let session,seg,catchSeg,result;
		session=this;
		seg = segVO.seg;
		result=segVO;
		if ("catchSeg" in segVO) {
			catchSeg = segVO.catchSeg;
		}
		try {
			while(seg){
				result=await session.execAISeg(agent,seg,result.input||result?.result||"",result.preSeg,result.outlet);
				seg=result.seg;
				if(seg && result.catchSeg){
					return await session.runSeg(agent,result);
				}
			}
		}catch(err){
			if(catchSeg){
				//Report debug:
				const info = `Caught error: ${err} at ${getErrorLocation(err)}`;
				const catchSegVO = { seg:catchSeg, input:info, preSeg:segVO.seg.jaxId, outlet:segVO.catchlet};
				session.notifyApp && session.notifyApp.emit("AISegCatch",agent.jaxId,agent.agentFrameId,err);
				result=await session.runSeg(agent,catchSegVO);
			}else{
				throw err;
			}
		}
		result=typeof(result)==="string"?result:result?.result||"";
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.runAISeg=async function(agent,seg,input,preSegId,outletId){
		let segVO,result;
		agent=agent||this.curAgent;
		segVO={seg:seg, input:input, preSeg:preSegId, outlet:outletId};
		return await this.runSeg(agent,segVO);
	};
	
	//------------------------------------------------------------------------
	chatSession.execAgent=async function(agent,...args){
		let result,action,orgSeg=null;
		let input=args[0];
		let session=this;
		let oldAgent=this.curAgent;
		let fromAgent=args[1]||oldAgent;
		
		//Load agent and get the entry-seg:
		try{
			if(typeof(agent)==="string"){
				agent=await this.loadAgent(agent);
			}
			agent.upperAgent=fromAgent||null;
			agent.agentFrameId=frameSeqId++;
			this.curAgent=agent;
			action=ChatAction.logAgentExec(this,agent,input);
			input=await this.checkStep(input,"input");
			if(agent.jaxId){//Debug tracing
				this.notifyApp && this.notifyApp.emit("AIAgentExec",agent.jaxId,agent,input);
			}
			result=await agent.execChat(...args);
			result=await this.checkStep(result,"ouput");
		}catch(err){
			action && action.failed(err);
			throw err;
		}

		//Call entry-seg to start:
		try{
			if(result.seg){
				result=await this.runSeg(agent,result);
				if(agent.endChat){
					result=(await agent.endChat(result))||result;
				}
			}
			if(agent.jaxId){//Debug tracing
				this.notifyApp && this.notifyApp.emit("AIAgentEnd",agent.jaxId,agent,typeof(result)==="string"?result:(result?result?.result||"":""));
			}
			this.curAgent=oldAgent;
		}catch(err){
			this.curAgent=oldAgent;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.executeAgent=async function(agent,input,opts){
		let result,action,orgSeg=null;
		let session=this;
		let oldAgent=this.curAgent;
		
		opts=opts||{};
		//Load agent and get the entry-seg:
		try{
			if(typeof(agent)==="string"){
				agent=await this.loadAgent(agent);
			}
			agent.upperAgent=opts.fromAgent||opts.upperAgent||null;
			agent.askUpwardSeg=opts.askUpwardSeg||null;
			agent.agentFrameId=frameSeqId++;
			this.curAgent=agent;
			action=ChatAction.logAgentExec(this,agent,input);
			input=await this.checkStep(input,"input");
			if(agent.jaxId){//Debug tracing
				this.notifyApp && this.notifyApp.emit("AIAgentExec",agent.jaxId,agent,input);
			}
			result=await agent.execChat(input);
			result=await this.checkStep(result,"ouput");
		}catch(err){
			action && action.failed(err);
			throw err;
		}

		//Call entry-seg to start:
		try{
			if(result.seg){
				result=await this.runSeg(agent,result);
				if(agent.endChat){
					result=(await agent.endChat(result))||result;
				}
			}
			if(agent.jaxId){//Debug tracing
				this.notifyApp && this.notifyApp.emit("AIAgentEnd",agent.jaxId,agent,typeof(result)==="string"?result:result?.result||"");
			}
			this.curAgent=oldAgent;
		}catch(err){
			this.curAgent=oldAgent;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.execAISeg=async function(agent,seg,input,fromSegId,outletId){
		let result,action,callId,oldSeg,oldCallId,newResult;
		oldSeg=this.curAISeg;
		callId=callSeqId++;
		oldCallId=this.curCallId;
		this.curCallId=callId;
		try{
			let segAct;
			this.curAISeg=seg;
			action=ChatAction.logAISeg(this,seg,input);
			if(seg.jaxId){
				segAct={
					agent: agent.jaxId,
					name: seg.name || "seg",
					url: seg.url || "",
					jaxId: seg.jaxId || "",
					input: input,
					fromSeg: fromSegId || null,
					fromOutlet: outletId || null,
				};
				this.notifyApp && this.notifyApp.emit("AISegExec",agent.jaxId,fromSegId,outletId,seg.jaxId,input,callId,segAct);
			}
			input=await this.checkStep(input,"input",true);
			result=await seg(input);
			if(seg.jaxId){
				if(result && ("result" in result)){
					segAct.result=result?.result||"";
				}else{
					segAct.result=result;
				}
				this.notifyApp && this.notifyApp.emit("AISegEnd",segAct);
			}
			newResult=await this.checkStep(result,"ouput");
			Object.assign(result,newResult);
			this.curAISeg=oldSeg;
			this.curCallId=oldCallId;
		}catch(err){
			console.log(err);
			action.failed(err);
			this.curAISeg=oldSeg;
			this.curCallId=oldCallId;
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.loadAISegAPIs=async function(list){
		let baseURL,url,i,n,apiList,apiVO,stubs,callList,stub,name,oldStub,idx;
		let self=this;
		apiVO={
			stubs:{},
			functions:[]
		};
		stubs=apiVO.stubs;
		callList=apiVO.functions;
		baseURL=pathLib.dirname(loadingAgentURL);
		n=list.length;
		for(i=0;i<n;i++){
			url=list[i];
			if(url[0]!=="/"){
				url=pathLib.join(baseURL,url);
			}
			try{
				apiList=(await import(url)).ChatAPI;
				if(!Array.isArray(apiList)){
					apiList=[apiList];
				}
				for(stub of apiList){
					name=stub.def.name;
					oldStub=stubs[name];
					if(stub.agent){
						let agent;
						//fix agent to API function:
						agent=await this.loadAgent(url);
						stub.func=async function(...args){
							return await self.execAgent(agent,...args);
						}
					}
					if(oldStub){
						stubs[name]=stub;
						idx=callList.indexOf(oldStub.def);
						if(idx>=0){
							callList.splice(idx,1,stub.def);
						}else{
							callList.push(stub.def);
						}
					}else{
						stubs[name]=stub;
						callList.push(stub.def);
					}
				}
			}catch(err){
			}
		}
		return apiVO;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUpward=async function(agent,prompt){
		let askAgent,askUpwardSeg,result;
		if(agent.name){
			let opts;
			opts={txtHeader:agent.showName||agent.name,icon:"/~/-tabos/shared/assets/ask.svg",iconSize:24,fontSize:12};
			await this.addChatText("assistant",prompt,opts);
		}
		askAgent=agent;
		while(askAgent){
			askUpwardSeg=askAgent.askUpwardSeg;
			askAgent=askAgent.upperAgent;
			if(askAgent && askUpwardSeg){
				break;
			}
		}
		if(askAgent && askUpwardSeg){
			if(askAgent==="$remote"){
				let remoteSession
				remoteSession=askUpwardSeg;
				result=await remoteSession.callRemote("AskUpward",{prompt:prompt});
			}else{
				//Call response upper agent
				result=await this.runAISeg(askAgent,askUpwardSeg,prompt);
			}
		}else{
			//Can't find responsalbe upper agent,
			result=await this.askChatInput({type:"input",text:"",allowFile:true});
			if(typeof(result)==="string"){
				await this.addChatText("user",result);
			}else if(result.assets && result.prompt){
				await this.addChatText("user",`${result.prompt}\n- - -\n${result.assets.join("\n- - -\n")}`,{render:true});
			}else{
				await this.addChatText("user",result.text||result.prompt||result);
			}
		}
		if(typeof(result)!=="string"){
			result=JSON.stringify(result);
		}
		return result;
	};
}

//****************************************************************************
//:Debug related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.callSession=chatSession.callClient=async function(msgCode,msgVO){
		let session=this;
		switch(msgCode){
			case "IndentMore":
				this.indentMore();
				return true;
			case "IndentLess":
				this.indentMore();
				return true;
		}
		let handler=session["WSCall_"+msgCode];
		if(!handler){
			throw Error(`No call-handler for msg: ${msgCode}.`);
		}
		return await handler.call(session,msgVO);
	};
	
	//------------------------------------------------------------------------
	chatSession.setStepRun=function(enable,showBreak){
		this.opts.stepRun=!!enable;
		if(showBreak){
			this.opts.showBreak=showBreak;
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.setSlowMo=function(enable){
		this.opts.slowMo=!!enable;
	};
	
	//------------------------------------------------------------------------
	chatSession.checkStep=async function(input,phase="input",isEnterSeg=false){
		let opts=this.opts;
		let result;
		let showBreak=opts.showBreak;
		if(isEnterSeg){
			if(opts.stepRun){
				if(!showBreak){
					return input;
				}
				result=await showBreak(input,phase,"Step run");
				if(typeof(input)==="object" && typeof(result)==="object"){
					result={...input,...result};
				}
				this.notifyApp && this.notifyApp.emit("AIExecResume");
				if(opts.slowMo){
					await sleep(500);
				}
				return result;
			}else if(opts.slowMo){
				await sleep(500);
			}
		}else{
			let bps=this.breakPointMap;
			let action=this.curAction;
			let actor=action.actor;
			let list=bps.get(actor);
			let checkText=input;
			if(checkText && typeof(checkText)!=="string"){
				try{
					checkText=JSON.stringify(checkText);
				}catch(err){
					checkText=""+checkText;
				}
			}
			if(list){
				let item;
				for(item of list){
					if(!item.enable){
						continue;
					}
					if(item.text!==undefined && item.text!==checkText){
						continue;
					}
					if(item.phase!=="all" && item.phase!==phase){
						continue;
					}
					result= await showBreak(input,phase,"Break point");
					if(typeof(input)==="object" && typeof(result)==="object"){
						result={...input,...result};
					}
					return result;
				}
			}
			return input;
		}
		return input;
	};
	
	//------------------------------------------------------------------------
	chatSession.getBreakPoints=function(){
		let actors,list,actor;
		actors=this.breakPointMap.values();
		list=[];
		for(actor of actors){
			list.push(...actor);
		}
		return list;
	};
	
	//------------------------------------------------------------------------
	chatSession.addBreakPoint=function(actor,phase,text){
		let stub,list,bps;
		stub={
			actor:actor,
			phase:phase,
			text:text,
			enable:true,
		};
		bps=this.breakPointMap;
		if(text && typeof(text)!=="string"){
			try{
				text=JSON.stringify(text);
			}catch(err){
				text=""+text;
			}
		}
		//Check if there is a same break-point:
		{
			list=bps.get(actor);
			if(list){
				let item;
				for(item of list){
					if(item.phase===phase && item.text===text){
						//TODO: not so good:
						alert("Found same break point!");
						return item;						
					}
				}
			}
		}
		list=bps.get(actor);
		if(!list){
			list=[];
			bps.set(actor,list);
		}
		list.push(stub);
		this.emit("NewBreakPoint",stub);
		return stub;
	};
	
	//------------------------------------------------------------------------
	chatSession.disableBreakPoint=function(breakStub){
		breakStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.enableBreakPoint=function(breakStub){
		breakStub.enable=true;
	};

	//------------------------------------------------------------------------
	chatSession.removeBreakPoint=function(breakStub){
		let bps,list;
		bps=this.breakPointMap;
		list=bps.get(breakStub.actor);
		if(list){
			let item,i,n;
			n=list.length;
			for(i=0;i<n;i++){
				item=list[i];
				if(item===breakStub){
					list.splice(i,1);		
					this.emit("RemoveBreakPoint",breakStub);
					return;
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.getGPTCheat=function(actor,callVO){
		let bps=this.gptCheatMap;
		let list=bps.get(actor);
		let checkText,msgs;
		if(!callVO){
			return null;
		}
		msgs=callVO.messages;
		if(!msgs || !msgs[0]){
			return null;
		}
		checkText=msgs[msgs.length-1].content;
		if(list){
			let item;
			for(item of list){
				if(item.enable){
					if(item.prompt===undefined || item.prompt===checkText){
						return item;
					}
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	chatSession.getGPTCheats=function(){
		let actors,list,actor;
		actors=this.gptCheatMap.values();
		list=[];
		for(actor of actors){
			list.push(...actor);
		}
		return list;
	};
	
	//------------------------------------------------------------------------
	chatSession.addGPTCheat=function(actor,prompt,result){
		let stub,list,bps;
		stub={
			actor:actor,
			prompt:prompt,
			result:result,
			funcationCall:false,
			enable:true,
		};
		bps=this.gptCheatMap;
		if(prompt && typeof(prompt)!=="string"){
			try{
				prompt=JSON.stringify(prompt);
			}catch(err){
				prompt=""+prompt;
			}
		}
		//Check if there is a same break-point:
		{
			list=bps.get(actor);
			if(list){
				let item;
				for(item of list){
					if(item.prompt===prompt){
						//TODO: not so good:
						alert("Found same break point!");
						return item;						
					}
				}
			}
		}
		list=bps.get(actor);
		if(!list){
			list=[];
			bps.set(actor,list);
		}
		list.push(stub);
		this.emit("NewGPTCheat",stub);
		return stub;
	};
	
	//------------------------------------------------------------------------
	chatSession.pauseGPTCheat=function(cheatStub){
		cheatStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.resumeGPTCheat=function(cheatStub){
		cheatStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.removeGPTCheat=function(cheatStub){
		let bps,list;
		bps=this.gptCheatMap;
		list=bps.get(cheatStub.actor);
		if(list){
			let item,i,n;
			n=list.length;
			for(i=0;i<n;i++){
				item=list[i];
				if(item===cheatStub){
					list.splice(i,1);		
					this.emit("RemoveGPTCheat",cheatStub);
					return;
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.inspectChatBot=function(botURL){
		let bot,list;
		console.log("ChatSession:");
		console.log(this);
		if(botURL){
			bot=this.chatBots.get(botURL);
			if(bot){
				console.log("ChatBot "+botURL+":");
				console.log(bot);
			}
			return;
		}
		list=this.chatBots.values();
		for(bot of list){
			console.log("ChatBot "+bot.url+":");
			console.log(bot);
		}
	};

	//------------------------------------------------------------------------
	chatSession.debugLog=function(log){
		if(this.curAISeg){
			console.log(`From ${this.curAgent.url}: `);
			this.notifyApp && this.notifyApp.emit("AIDebugLog",this.curAgent.jaxId,this.curAISeg.jaxId,log);
		}
		console.log(log);
	};
	
	//------------------------------------------------------------------------
	chatSession.OnRemoteDebugLog=function(log){
		switch(log.type){
			case "StartAgent":{
				this.notifyApp && this.notifyApp.emit("AIAgentExec",log.agent);
				break;
			}
			case "EndAgent":{
				this.notifyApp && this.notifyApp.emit("AIAgentEnd",log.agent);
				break;
			}
			case "LlmCall":{
				let seg;
				seg=log.seg;
				if(seg.jaxId){
					let messages,text;
					text="OPTIONS-----------------------------\n";
					text+=JSON.stringify(log.options,null,"\t");
					text+="\n\nMESSAGES:------------------------------\n\nMESSAGE---------------------------\n\n";
					messages=log.messages.map(item=>(item.content||"NO-CONTENT"));
					text+=messages.join("\n\nMESSAGE---------------------------\n\n");
					this.notifyApp && this.notifyApp.emit("AISegCallLLMInput",log.agent,seg.jaxId,text,log.callId);
				}
				break;
			}
			case "LlmResult":{
				let seg;
				seg=log.seg;
				if(seg.jaxId){
					this.notifyApp && this.notifyApp.emit("AISegCallLLMResult",log.agent,seg.jaxId,log.result,log.callId);
				}
				break;
			}
			case "StartSeg":{
				let seg;
				seg=log.seg;
				if(seg.jaxId){
					this.notifyApp && this.notifyApp.emit("AISegExec",seg.agent,seg.fromSeg,seg.fromOutlet,seg.jaxId,seg.input,seg.id);
				}
				break;
			}
			case "EndSeg":{
				let seg;
				seg=log.seg;
				if(seg.jaxId){
					this.notifyApp && this.notifyApp.emit("AISegEnd",seg.agent,seg.jaxId,seg.result,seg.id);
				}
				break;
			}
			case "DebugLog":{
				console.log("Remote debug log:");
				console.log(log.log);
				this.notifyApp && this.notifyApp.emit("AIDebugLog",log.agent,log.seg,log.log);
				break;
			}
		}
	};
}

//****************************************************************************
//:I/O related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.loadBot=async function(url,alias=null){
		let bots,baseBot,bot;
		alias=alias||url;
		bots=this.chatBots;
		bot=bots.get(alias);
		if(!bot){
			baseBot=await ChatBot.loadBot(this,url);
			bot=new ChatBot(this);
			await bot.cloneFrom(baseBot,alias);
			bots.set(alias,bot);
		}
		/*if(!this.entryBot){
			this.entryBot=bot;
		}*/
		return bot;
	};
	
	//------------------------------------------------------------------------
	chatSession.loadJSONBot=async function(url,json){
		let bot;
		bot=await ChatBot.loadJSON(this,url,json);
		this.chatBots.set(url,bot);
		return bot;
	};

	//------------------------------------------------------------------------
	chatSession.resetBots=async function(){
		let bots=this.chatBots.values();
		for(let bot of bots){
			await bot.reset();
		}
	};

	//------------------------------------------------------------------------
	chatSession.genSaveVO=function(savePath){
		let vo,dir;
		dir=pathLib.dirname(savePath);//Not used, we use absolute path by now
		vo={};
		//First, entryURL
		vo.entryURL=this.entryURL;
		//Bots
		{
			let chatBots,voBots,urls,url,bot; 
			voBots=vo.bots={};
			chatBots=this.chatBots;
			urls=chatBots.keys();
			for(url of urls){
				bot=chatBots.get(url);
				voBots[url]=bot.genSaveVO();
			}
		}
		//Breakpoints
		{
			let bps,vobps,bp;
			bps=this.getBreakPoints();
			vobps=vo.breaks=[];
			for(bp of bps){
				vobps.push({...bp});
			}
		}
		//GPTCheats
		{
			let cheats,vocheats,cheat;
			cheats=this.getGPTCheats();
			vocheats=vo.cheats=[];
			for(cheat of cheats){
				vocheats.push({...cheat});
			}
		}
		return vo;
	};
	
	//-----------------------------------------------------------------------
	chatSession.loadFromSaveVO=async function(vo,path){
		let dir;
		dir=pathLib.dirname(path);//Not used, we use absolute path by now
		this.initEntry(vo.entryURL);
		//Bots:
		{
			let voBots,url,voBot,bot;
			voBots=vo.bots;
			for(url in voBots){
				voBot=voBots[url];
				bot=await this.loadBot(url);
				await bot.loadFromSaveVO(voBot);
			}
		}
		//Breakpoints:
		{
			let voBreaks,actor,voBreak,bps,list;
			voBreaks=vo.breaks;
			bps=this.breakPointMap;
			for(voBreak of voBreaks){
				list=bps.get(voBreak.actor);
				if(!list){
					list=[];
					bps.set(voBreak.actor,list);
				}
				list.push(voBreak);
			}
			
		}
		//GPTCheats
		{
			let voCheats,actor,voCheat,bps,list;
			voCheats=vo.cheats;
			bps=this.gptCheatMap;
			for(voCheat of voCheats){
				list=bps.get(voCheat.actor);
				if(!list){
					list=[];
					bps.set(voCheat.actor,list);
				}
				list.push(voCheat);
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.saveHubFile=async function(fileName,data){
		let hubName;
		hubName=await HubFileLib.writeFile(fileName,data);
		try{
			this.callSession("NewHubFile",hubName);
		}catch(err){
			//Ignore
		}
		return hubName;
	};
	
	//------------------------------------------------------------------------
	chatSession.loadHubFile=async function(hubFileName){
		return await HubFileLib.readFile(hubFileName);
	};

	//------------------------------------------------------------------------
	chatSession.getHubPath=async function(hubFileName){
		if(hubFileName.startsWith("hub://")){
			hubFileName=hubFileName.substring("hub://".length);
		}
		return await HubFileLib.getFilePath(hubFileName);
	};
	
	//------------------------------------------------------------------------
	chatSession.normURL=async function(url){
		if(url.startsWith("hub://")){
			return await HubFileLib.readDataURL(url);
		}
		return url;
	};
}

//****************************************************************************
//:Helper function:
//****************************************************************************
{
	chatSession.arrayBufferToDataURL=function(fileName,buf){
		let ext,result;
		if(fileName){
			ext=pathLib.extname(fileName);
		}
		result=Base64.encode(buf);
		switch(ext){
			case ".jpg":
				result="data:image/jpeg;base64,"+result;
				break;
			case ".png":
				result="data:image/png;base64,"+result;
				break;
			case ".txt":
				result="data:text/plain;base64,"+result;
				break;
			case ".json":
				result="data:text/json;base64,"+result;
				break;
			case '.pdf':
				result="data:application/pdf;base64,"+result;
				break;
			default:
				result="data:application/octet-stream;base64,"+result;
				break;
		}
		return result;
	};
}
//****************************************************************************
//:Handle WSCalls
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.WSCall_UpdateTokenGas=async function(){
		this.notifyApp && this.notifyApp.emit("UpdateTokenGas");
		this.uiApp && this.uiApp.emit("UpdateTokenGas");
	};
}
//****************************************************************************
//:DummyUI
//****************************************************************************
let DummyChatUI,dummyChatUI;
{
	//------------------------------------------------------------------------
	DummyChatUI=function(app,notifyApp){
		if(!app){
			app=VFACT.app;
		}
		if(!notifyApp){
			notifyApp=app.aiNotifyApp?app.aiNotifyApp:(app.appFrame?app.appFrame.app:app);
		}
		this.app=app;
		this.notifyApp=notifyApp;
	};
	dummyChatUI=DummyChatUI.prototype={};
	
	//------------------------------------------------------------------------
	dummyChatUI.abortChat=
	dummyChatUI.askChatInput=
	dummyChatUI.addChatAsset=
	dummyChatUI.cancelChatInput=
	dummyChatUI.askUserRaw=
	dummyChatUI.askUserView=
	dummyChatUI.askUser=
	dummyChatUI.scrollDown=
	dummyChatUI.decIndent=
	dummyChatUI.incIndent=async function(){
		//Do nothing
	};
	dummyChatUI.appendChatBlock=
	dummyChatUI.removeChatBlock=function(){
		//Do nothing
		return null;
	};
}

//----------------------------------------------------------------------------
ChatSession.findAndExec=ChatSession.execFind=async function(session,find,args={}){
	if(!session){
		let ui;
		ui=new DummyChatUI(null,null);
		session=new ChatSession(ui,{});
	}
	return await session.callAgent(null,find,args,{});
};

//----------------------------------------------------------------------------
ChatSession.execAgent=async function(session,agentNode=null,agentPath="",args={}){
	if(!session){
		let ui;
		ui=new DummyChatUI(null,null);
		session=new ChatSession(ui,{});
		if(!(await tabNT.checkLogin(true))){
		   throw "Not login";
		}
	}
	return await session.callAgent(agentNode,agentPath,args,{});
};

export default ChatSession;
export {ChatSession,DummyChatUI};
