import pathLib from "/@path";
import {tabNT} from "/@tabos/tabos_nt.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {ChatAction} from "./chataction.js";
import {ChatBot} from "./chatbot.js";
import {VFACT} from "/@vfact";
import Base64 from "/@tabos/utils/base64.js";
const $ln=VFACT.lanCode||"EN";

//****************************************************************************
//:ChatSession
//****************************************************************************
let ChatSession=function(ui,opts){
	this.ui=ui;
	this.notifyApp=ui.notifyApp;
	this.entryBot=null;
	this.agent=null;
	this.entryURL=null;
	this.baseURL=ui.basePath||"";
	this.chatMessages=[];
	this.chatBots=new Map();
	this.chatAgents=new Map();
	this.abortFunc=null;
	this.waitObj={content:""};
	this.hideInternal=0;
	this.opts=opts||{};
	this.curAction=null;
	this.breakPointMap=new Map();
	this.gptCheatMap=new Map();
	this.globalContext={};
	makeNotify(this);
	makeObjEventEmitter(this);
	makeNotify(this.waitObj);
	makeObjEventEmitter(this.waitObj);
	makeNotify(this.globalContext);
	makeObjEventEmitter(this.globalContext);
};
let chatSession=ChatSession.prototype={};

//****************************************************************************
//:Execute chat related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.initEntry=async function(url,json){
		let bot,ext,agent,alias;
		
		if(typeof(url)==="object"){
			json=url.json;
			alias=url.alias;
			url=url.url;
		}
		this.entryURL=url;
		ext=pathLib.extname(url);
		if(ext===".aichat"){
			if(json){
				bot=await this.loadJSONBot(url,json);
			}else{
				bot=await this.loadBot(url,alias);
			}
			if(bot){
				this.entryBot=bot;
			}
			return bot;
		}
		if(ext===".js"){
			agent=await this.loadAgent(url,alias);
			if(agent){
				this.entryBot=agent;
				this.agent=agent;
			}
			return agent;
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.execChat=async function(botPath,prompt){
		let bot,ext;
		ext=pathLib.extname(botPath);
		if(ext===".aichat"){
			bot=await this.loadBot(botPath);
			if(bot){
				return await this.execBot(botPath,bot,prompt);
			}
		}
		if(ext===".js"){
			bot=await this.loadAgent(botPath);
			if(bot){
				return await this.execAgent(bot,prompt);
			}
		}
		throw Error((($ln==="CN")?(`无法加载AI聊天: ${botPath}`):/*EN*/(`Can't load AI chat: ${botPath}`)));
	}

	//------------------------------------------------------------------------
	chatSession.execBot=async function(botPath,bot,prompt){
		let ui,blkVO,blk,waitObj,result,curAction;
		curAction=this.curAction;
		ui=this.ui;
		//Add user text prompt:
		blkVO={type:"user",text:prompt};
		ui.appendChatBlock(blkVO);
		ui.incIndent();
		//Add wait block:
		blkVO={type:"wait",text:"AI is thinking..."};
		blk=ui.appendChatBlock(blkVO);
		try{
			//Log actiion:
			//Execute the call
			result=await this.execBotChat(botPath,prompt,blk);
			//Call finished, remove wait-block
			ui.removeChatBlock(blk,true);
			ui.decIndent();
			//Append result block:
			if(result){
				blkVO={type:"assistant",text:result||(($ln==="CN")?("AI 调用完成。"):/*EN*/("AI Call done."))};
				blk=ui.appendChatBlock(blkVO);
			}
			if(bot.filterEndRound){
				let action,text=result;
				action=ChatAction.logFilter(this,bot,"round",bot.filterEndRoundURL,result);
				try{
					text=await this.checkStep(text,"input");
					text=await bot.filterEndRound(text);
					text=await this.checkStep(text,"output");
				}catch(err){
					action.failed(err);
					throw err;
				}
				action.end(text);
			}
		}catch(err){
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			ui.removeChatBlock(blk,true);
			ui.decIndent();
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.pipeChat=async function(botPath,input,hint,secret=false){
		let ui,ext,blkVO,blk,waitObj,result,action,curAction;
		ext=pathLib.extname(botPath);
		if(ext===".aichat"){
			curAction=this.curAction;
			ui=this.ui;
			//Add wait block:
			blkVO={type:"wait",text:hint||"AI is thinking..."};
			blk=ui.appendChatBlock(blkVO);
			try{
				if(secret){
					this.hideInternal++;
				}
				result=await this.execBotChat(botPath,input,blk);
				ui.removeChatBlock(blk,true);
				if(secret){
					this.hideInternal--;
				}
			}catch(err){
				if(this.curAction){
					this.curAction.failed(err);
				}
				this.curAction=curAction;
				ui.removeChatBlock(blk,true);
				throw err;
			}
			return result;
		}else if(ext===".js"){
			if(secret){
				this.hideInternal++;
			}
			result=await this.execAgent(botPath,input);
			if(secret){
				this.hideInternal--;
			}
			return result;
		}
		return input;
	};

	//------------------------------------------------------------------------
	chatSession.execBotChat=async function(botPath,prompt,blk){
		let chatBot,pms,waitObj,callVO,filtered,functionCall,chatAct,action;

		//Get chatBot:
		chatBot=this.chatBots.get(botPath);
		if(!chatBot){
			chatBot=await this.loadBot(botPath);
		}
		chatAct=ChatAction.logChat(this,chatBot,prompt);
		//Update chatBot memory is needed:
		await chatBot.checkMemory();
		if(!chatBot.sysMsg){
			let result;
			prompt=await this.checkStep(prompt,"input");
			//This bot will not call AI directly, it will happens in it's input/post filters
			try{
				result=await chatBot.execNoAICall(prompt)
				result=await this.checkStep(result,"output");
			}catch(err){
				chatAct.failed(err);
				throw err;
			}
			chatAct.end(result)
			return result;
		}
		//Generate callVO:
		try{
			callVO=await chatBot.genChatCallVO(prompt);
		}catch(err){
			if(typeof(err)==="string"){
				chatAct.end(err)
				return err;
			}
			throw err;
		}

		pms=new Promise(async (resolveFunc,rejectFunc)=>{
			let result,content,functionCall;
			this.abortFunc=rejectFunc;
			try{
				let cheat;
				do{
					//Clear wait obj;
					waitObj=this.waitObj;
					waitObj.content="";
					waitObj.functionCall=null;
					if(blk){
						blk.trace(waitObj);
					}

					//Call NT-API:
					if(chatBot.secretInternal){
						this.hideInternal++
					}
					action=ChatAction.logGPTCall(this,chatBot.url,callVO);
					try{
						let res;
						callVO=await this.checkStep(callVO,"input");
						cheat=this.getGPTCheat(chatBot.url,callVO);
						if(cheat){
							content=cheat.result;
							content=await this.checkStep(content,"output");
							waitObj.content=content;
							if(cheat.funcationCall){
								functionCall=cheat.result;
								functionCall=await this.checkStep(functionCall,"funcion_call");
							}
						}else{
							res=await tabNT.makeCall("AICallStream",callVO,10000);
							//console.log("CallVO:");
							//console.log(JSON.stringify(callVO,null,"\t"));
							if(this.abortFunc!==rejectFunc){//check abort:
								return;
							}
							if(res.code!==200){
								throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
							}

							//Read stream:
							await this.readChatStream(res.streamId,rejectFunc);
							if(chatBot.secretInternal){
								this.hideInternal--;
							}
							if(this.abortFunc!==rejectFunc){//check abort:
								return;
							}
							content=waitObj.content;
							functionCall=waitObj.functionCall;
							content=await this.checkStep(content,"output");
							waitObj.content=content;
							if(functionCall){
								functionCall=await this.checkStep(functionCall,"funcion_call");
							}
						}
					}catch(err){
						action.failed(err);
						rejectFunc(err);
					}
					action.end(content);
					if(functionCall){
						callVO=await chatBot.applyFunctionCall(functionCall,callVO);
					}else{
						callVO=null;
					}
				}while(callVO);

				result=waitObj.content;
				this.abortFunc=null;
				//Apply call result to bot:
				try{
					result=await chatBot.applyAIFeedback(result);
					result=await this.checkStep(result,"output");
				}catch(err){
					if(err==="#END"){
						return result;
					}
					if(typeof(err)==="string"){
						return err;
					}
					rejectFunc(err);
				}

				chatAct.end(result)
				resolveFunc(result);
			}catch(err){
				chatAct.failed(err)
				this.abortFunc=null;
				rejectFunc(err);
			}
		});
		return await pms;
	};
	
	//------------------------------------------------------------------------
	chatSession.callSegLLM=async function(segPath,opts,messages,fromSeg=false){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret;

		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:opts.hint||(($ln==="CN")?("AI正在思考中..."):/*EN*/("AI is thinking..."))};
		blk=ui.appendChatBlock(blkVO);
		try{
			secret=!!opts.secret;
			if(secret){
				this.hideInternal++;
			}
			result=await this.execLLMChat(segPath,opts,messages,blk);
			ui.removeChatBlock(blk,true);
			if(secret){
				this.hideInternal--;
			}
		}catch(err){
			console.error(err);
			ui.removeChatBlock(blk,true);
			if(fromSeg){
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?("调用LLM错误，你想再试一次吗?"):/*EN*/("Call LLM error, would you like to try again?")),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.callSegLLM(segPath,opts,messages,fromSeg);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.execLLMChat=async function(callPath,opts,messages,blk){
		let action,callVO,cheat,pms,waitObj,result;
		callVO={
			model:opts.mode||"gpt-3.5-turbo",
			temperature:opts.temperature,
			max_tokens:opts.maxToken,
			messages:messages,
			top_p:opts.topP>=0?opts.topP:1,
			presence_penalty:opts.prcP>=0?opts.prcP:0,
			frequency_penalty:opts.fqcP>=0?opts.fqcP:0,
			response_format:opts.responseFormat||"text"
		};
		if("seed" in opts){
			callVO.seed=opts.seed;
		}
		if(opts.apis){
			callVO.functions=opts.apis.functions;
			if(opts.parallelFunction){
				callVO.parallelFunction=true;
			}
		}
		//Clear wait obj;
		waitObj=this.waitObj;
		waitObj.content="";
		waitObj.functionCall=null;
		waitObj.toolCalls=null;
		if(blk){
			blk.trace(waitObj);
		}
		pms=new Promise(async (resolveFunc,rejectFunc)=>{
			let result,content,functionCall,res,toolCalls;
			this.abortFunc=rejectFunc;
			action=ChatAction.logGPTCall(this,callPath,callVO);
			try{
				callVO=await this.checkStep(callVO,"input");
				cheat=this.getGPTCheat(callPath,callVO);
				if(cheat){
					content=cheat.result;
					result=await this.checkStep(content,"output");
					waitObj.content=result;
				}else{
					res=await tabNT.makeCall("AICallStream",callVO,20000);
					if(this.abortFunc!==rejectFunc){//check abort:
						return;
					}
					if(res.code!==200){
						throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
					}

					//Read stream:
					await this.readChatStream(res.streamId,rejectFunc);
					if(this.abortFunc!==rejectFunc){//check abort:
						return;
					}
					content=waitObj.content;
					functionCall=waitObj.functionCall;
					toolCalls=waitObj.toolCalls;
					result=await this.checkStep(content,"output");
					waitObj.content=result;
				}
				action.end(result);
			}catch(err){
				action.failed(err);
				rejectFunc(err);
			}
			
			if(functionCall||toolCalls){//Call function, call execLLMCall again.
				let callResult,name,stub,func,args,action;
				if(functionCall){
					functionCall=await this.checkStep(functionCall,"funcion_call");
					name=functionCall.name;
					stub=opts.apis.stubs[name];
					if(!stub){
						throw new Error(`API Function: ${name} not found.`);
					}
					func=stub.func;
					args=functionCall["arguments"];
					action=ChatAction.logAPICall(this,name,args,stub);
					try{
						args=await this.checkStep(args,"input");
						callResult=await func.call(this,JSON.parse(args));
						callResult=await this.checkStep(callResult,"output");
					}catch(err){
						action.failed(err);
						rejectFunc(err);
					}
					action.end(callResult);
					callResult=await this.checkStep(callResult,"funcion_result");
					messages=[...messages];
					messages.push({role:"assistant",content:"",function_call:functionCall});
					messages.push({role:"function",name:name,content:callResult});
				}else{//toolCalls
					let i,n,toolCall;
					messages=[...messages];
					messages.push({role:"assistant",content:"",tool_calls:toolCalls});
					n=toolCalls.length;
					for(i=0;i<n;i++){
						toolCall=toolCalls[i];
						functionCall=toolCall.function;
						functionCall=await this.checkStep(functionCall,"funcion_call");
						name=functionCall.name;
						stub=opts.apis.stubs[name];
						if(!stub){
							throw new Error(`API Function: ${name} not found.`);
						}
						func=stub.func;
						args=functionCall["arguments"];
						action=ChatAction.logAPICall(this,name,args,stub);
						try{
							args=await this.checkStep(args,"input");
							callResult=await func.call(this,JSON.parse(args));
							callResult=await this.checkStep(callResult,"output");
						}catch(err){
							action.failed(err);
							rejectFunc(err);
						}
						action.end(callResult);
						callResult=await this.checkStep(callResult,"funcion_result");
						messages.push({tool_call_id:toolCall.id,role:"tool",name:name,content:callResult});
					}
				}
				result=await this.callSegLLM(callPath,opts,messages);
			}
			resolveFunc(result);
		});
		try{
			result=await pms;
			if(opts.responseFormat==="json_object"){
				JSON.parse(result);//Ensure JSON, or maybe retry...
			}
		}catch(err){
			throw err;
		}
		return result;
	};

	//------------------------------------------------------------------------
	chatSession.readChatStream=async function(streamId,rejectFunc){
		let res,pmt,streamObj;
		streamObj=this.waitObj;
		pmt="";
		do{
			res=await tabNT.makeCall("readAIChatStream",{streamId:streamId});				
			if(res.code!==200){
				console.log("Read chat stream error: ");
				console.log(res);
				break;
			}
			pmt=res.message;
			if(this.abortFunc===rejectFunc){
				streamObj.content=pmt;
				if(res.functionCall){
					streamObj.functionCall=res.functionCall;
				}
				if(res.toolCalls){
					streamObj.toolCalls=res.toolCalls;
				}
				streamObj.emit("content");
			}else{
				//Chat canceled?
				streamObj.emit("close");
				return "";
			}
		}while(!res.closed);
		streamObj.emit("close");
		return streamObj.content;
	};

	//------------------------------------------------------------------------
	chatSession.abortChat=function(msg){
		if(this.abortFunc){
			this.abortFunc(msg);
			this.abortFunc=null;
		}
	};

	//------------------------------------------------------------------------
	chatSession.sysCall=async function(msg,callVO,fromSeg,timeout=10000){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret;
		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:(($ln==="CN")?("系统调用中..."):/*EN*/("System calling..."))};
		blk=ui.appendChatBlock(blkVO);
		try{
			result=await tabNT.makeCall(msg,callVO,timeout);
			if(result.code!==200){
				throw `System call error ${result.code}: ${result.info||"Error"}`;
			}
			ui.removeChatBlock(blk,true);
		}catch(err){
			console.error(err);
			ui.removeChatBlock(blk,true);
			if(fromSeg){
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?("Error: "+err+"\n调用系统API错误，你想再试一次吗?"):/*EN*/("Error: "+err+"\nCall System API error, would you like to try again?")),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.sysCall(msg,callVO,fromSeg,timeout);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.webCall=async function(callVO,fromSeg,timeout=10000){
		let ui,blkVO,blk,waitObj,result,action,curAction,secret;

		curAction=this.curAction;
		ui=this.ui;
		//Add wait block:
		blkVO={type:"wait",text:(($ln==="CN")?("Web调用中..."):/*EN*/("Web calling..."))};
		blk=ui.appendChatBlock(blkVO);
		try{
			result=await tabNT.makeCall('webAPICall',callVO,timeout);
			ui.removeChatBlock(blk,true);
		}catch(err){
			console.error(err);
			ui.removeChatBlock(blk,true);
			if(fromSeg){
				let tryAgain=await this.askUser({
					type:"confirm",
					text:(($ln==="CN")?("调用Web错误，你想再试一次吗?"):/*EN*/("Call Web error, would you like to try again?")),
					button1:(($ln==="CN")?("再试一次"):/*EN*/("Try again")),
					button2:(($ln==="CN")?("中止"):/*EN*/("Abort"))
				});
				if(tryAgain){
					return await this.webCall(callVO,fromSeg,timeout);
				}
			}
			if(this.curAction){
				this.curAction.failed(err);
			}
			this.curAction=curAction;
			throw err;
		}
		return result;
	};

}

//****************************************************************************
//:Ask user interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.askChatInput=async function(vo){
		let ui,pms,action,result;
		ui=this.ui;
		if(!ui.askChatInput){
			throw Error("Chat dialog can't ask user for input chat!");
		}
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			result=await ui.askChatInput(vo);
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUser=async function(vo){
		let ui,pms,action,result;
		ui=this.ui;
		if(!ui.askUser){
			throw Error("Chat dialog can't ask user for anyting!");
		}
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			result=await ui.askUser(vo);
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.askUserRaw=async function(vo){
		let ui,pms,action,result;
		ui=this.ui;
		if(!ui.askUser){
			throw Error("Chat dialog can't ask user for anyting!");
		}
		action=ChatAction.logAskUser(this,vo);
		try{
			vo=await this.checkStep(vo,"input");
			result=await ui.askUserRaw(vo);
			result=await this.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		return result;
	};

	//------------------------------------------------------------------------
	chatSession.addChatText=async function(role,text,opts){
		role=role||"event";
		ChatAction.logChatText(this,role,text);
		this.ui.appendChatBlock({type:role,text:text,...opts});
	};
}

//****************************************************************************
//:Agent related:
//****************************************************************************
{
	let callSeqId=0;
	let loadingAgentURL=null;
	//------------------------------------------------------------------------
	chatSession.loadAgent=async function(url,alias,newAgent=false){
		let md,func,agent,oldURL;
		alias=alias||url;
		if(!newAgent){
			agent=this.chatAgents.get(alias);
			if(agent){
				return agent;
			}
		}
		oldURL=loadingAgentURL;
		loadingAgentURL=url;
		md=await import(url);
		func=md.default;
		agent=await func(this);
		agent.url=url;
		agent.alias=alias;
		if(!newAgent){
			this.chatAgents.set(alias,agent);
		}
		loadingAgentURL=oldURL;
		return agent;
	};
	
	//------------------------------------------------------------------------
	chatSession.execAgent=async function(agent,...args){
		let result,action,orgSeg=null;
		let input=args[0];
		let session=this;
		async function runSeg(seg,catchSeg){
			try{
				while(seg){
					result=await session.execAISeg(agent,seg,result.input||result.result,result.preSeg,result.outlet);
					seg=result.seg;
					if(seg && result.catchSeg){
						return await runSeg(seg,result.catchSeg);
					}
				}
			}catch(err){
				if(catchSeg){
					result=await session.execAISeg(agent,catchSeg,err,seg.jaxId,result.catchlet);
				}else{
					throw err;
				}
			}
			return result;
		}
		
		try{
			if(typeof(agent)==="string"){
				agent=await this.loadAgent(agent);
			}
			action=ChatAction.logAgentExec(this,agent,input);
			input=await this.checkStep(input,"input");
			if(agent.jaxId){//Debug tracing
				this.notifyApp.emit("AIAgentExec",agent.jaxId);
			}
			result=await agent.execChat(...args);
			result=await this.checkStep(result,"ouput");
		}catch(err){
			action.failed(err);
			throw err;
		}
		if(result.seg){
			result=await runSeg(result.seg,result.catchSeg);
		}
		/*while(result.seg){
			let seg,catchSeg;
			seg=result.seg;
			catchSeg=result.catchSeg;
			try{
				result=await this.execAISeg(agent,seg,result.input||result.result,result.preSeg,result.outlet);
			}catch(err){
				if(catchSeg){
					result=await this.execAISeg(agent,catchSeg,err,seg.jaxId,result.catchlet);
				}else{
					throw err;
				}
			}
		}
		action.end(result);*/
		//return result;
		return typeof(result)==="string"?result:result.result;
	};
	
	//------------------------------------------------------------------------
	chatSession.execAISeg=async function(agent,seg,input,fromSegId,outletId){
		let result,action,callId;
		callId=callSeqId++;
		try{
			action=ChatAction.logAISeg(this,seg,input);
			input=await this.checkStep(input,"input");
			if(seg.jaxId){
				this.notifyApp.emit("AISegExec",agent.jaxId,fromSegId,outletId,seg.jaxId,input,callId);
			}
			result=await seg(input);
			if(seg.jaxId){
				let log=result;
				if(log && log.result){
					log=log.result;
				}
				this.notifyApp.emit("AISegEnd",agent.jaxId,seg.jaxId,log,callId);
			}
			result=await this.checkStep(result,"ouput");
		}catch(err){
			action.failed(err);
			console.log(err);
			throw err;
		}
		action.end(result);
		return result;
	};
	
	//------------------------------------------------------------------------
	chatSession.loadAISegAPIs=async function(list){
		let baseURL,url,i,n,apiList,apiVO,stubs,callList,stub,name,oldStub,idx;
		let self=this;
		apiVO={
			stubs:{},
			functions:[]
		};
		stubs=apiVO.stubs;
		callList=apiVO.functions;
		baseURL=pathLib.dirname(loadingAgentURL);
		n=list.length;
		for(i=0;i<n;i++){
			url=list[i];
			if(url[0]!=="/"){
				url=pathLib.join(baseURL,url);
			}
			try{
				apiList=(await import(url)).ChatAPI;
				if(!Array.isArray(apiList)){
					apiList=[apiList];
				}
				for(stub of apiList){
					name=stub.def.name;
					oldStub=stubs[name];
					if(stub.agent){
						let agent;
						//fix agent to API function:
						agent=await this.loadAgent(url);
						stub.func=async function(...args){
							return await self.execAgent(agent,...args);
						}
					}
					if(oldStub){
						stubs[name]=stub;
						idx=callList.indexOf(oldStub.def);
						if(idx>=0){
							callList.splice(idx,1,stub.def);
						}else{
							callList.push(stub.def);
						}
					}else{
						stubs[name]=stub;
						callList.push(stub.def);
					}
				}
			}catch(err){
			}
		}
		return apiVO;
	};
}

//****************************************************************************
//:Debug related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.setStepRun=function(enable){
		this.opts.stepRun=!!enable;
	};
	
	//------------------------------------------------------------------------
	chatSession.checkStep=async function(text,phase="input"){
		let opts=this.opts;
		let showBreak=opts.showBreak;
		if(!showBreak){
			return text;
		}
		if(opts.stepRun){
			return await showBreak(text,phase,"Step run");
		}else{
			let bps=this.breakPointMap;
			let action=this.curAction;
			let actor=action.actor;
			let list=bps.get(actor);
			let checkText=text;
			if(checkText && typeof(checkText)!=="string"){
				checkText=JSON.stringify(checkText);
			}
			if(list){
				let item;
				for(item of list){
					if(!item.enable){
						continue;
					}
					if(item.text!==undefined && item.text!==checkText){
						continue;
					}
					if(item.phase!=="all" && item.phase!==phase){
						continue;
					}
					return await showBreak(text,phase,"Break point");
				}
			}
			return text;
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	chatSession.getBreakPoints=function(){
		let actors,list,actor;
		actors=this.breakPointMap.values();
		list=[];
		for(actor of actors){
			list.push(...actor);
		}
		return list;
	};
	
	//------------------------------------------------------------------------
	chatSession.addBreakPoint=function(actor,phase,text){
		let stub,list,bps;
		stub={
			actor:actor,
			phase:phase,
			text:text,
			enable:true,
		};
		bps=this.breakPointMap;
		if(text && typeof(text)!=="string"){
			text=JSON.stringify(text);
		}
		//Check if there is a same break-point:
		{
			list=bps.get(actor);
			if(list){
				let item;
				for(item of list){
					if(item.phase===phase && item.text===text){
						//TODO: not so good:
						alert("Found same break point!");
						return item;						
					}
				}
			}
		}
		list=bps.get(actor);
		if(!list){
			list=[];
			bps.set(actor,list);
		}
		list.push(stub);
		this.emit("NewBreakPoint",stub);
		return stub;
	};
	
	//------------------------------------------------------------------------
	chatSession.disableBreakPoint=function(breakStub){
		breakStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.enableBreakPoint=function(breakStub){
		breakStub.enable=true;
	};

	//------------------------------------------------------------------------
	chatSession.removeBreakPoint=function(breakStub){
		let bps,list;
		bps=this.breakPointMap;
		list=bps.get(breakStub.actor);
		if(list){
			let item,i,n;
			n=list.length;
			for(i=0;i<n;i++){
				item=list[i];
				if(item===breakStub){
					list.splice(i,1);		
					this.emit("RemoveBreakPoint",breakStub);
					return;
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.getGPTCheat=function(actor,callVO){
		let bps=this.gptCheatMap;
		let list=bps.get(actor);
		let checkText,msgs;
		if(!callVO){
			return null;
		}
		msgs=callVO.messages;
		if(!msgs || !msgs[0]){
			return null;
		}
		checkText=msgs[msgs.length-1].content;
		if(list){
			let item;
			for(item of list){
				if(item.enable){
					if(item.prompt===undefined || item.prompt===checkText){
						return item;
					}
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	chatSession.getGPTCheats=function(){
		let actors,list,actor;
		actors=this.gptCheatMap.values();
		list=[];
		for(actor of actors){
			list.push(...actor);
		}
		return list;
	};
	
	//------------------------------------------------------------------------
	chatSession.addGPTCheat=function(actor,prompt,result){
		let stub,list,bps;
		stub={
			actor:actor,
			prompt:prompt,
			result:result,
			funcationCall:false,
			enable:true,
		};
		bps=this.gptCheatMap;
		if(prompt && typeof(prompt)!=="string"){
			prompt=JSON.stringify(prompt);
		}
		//Check if there is a same break-point:
		{
			list=bps.get(actor);
			if(list){
				let item;
				for(item of list){
					if(item.prompt===prompt){
						//TODO: not so good:
						alert("Found same break point!");
						return item;						
					}
				}
			}
		}
		list=bps.get(actor);
		if(!list){
			list=[];
			bps.set(actor,list);
		}
		list.push(stub);
		this.emit("NewGPTCheat",stub);
		return stub;
	};
	
	//------------------------------------------------------------------------
	chatSession.pauseGPTCheat=function(cheatStub){
		cheatStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.resumeGPTCheat=function(cheatStub){
		cheatStub.enable=false;
	};

	//------------------------------------------------------------------------
	chatSession.removeGPTCheat=function(cheatStub){
		let bps,list;
		bps=this.gptCheatMap;
		list=bps.get(cheatStub.actor);
		if(list){
			let item,i,n;
			n=list.length;
			for(i=0;i<n;i++){
				item=list[i];
				if(item===cheatStub){
					list.splice(i,1);		
					this.emit("RemoveGPTCheat",cheatStub);
					return;
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatSession.inspectChatBot=function(botURL){
		let bot,list;
		console.log("ChatSession:");
		console.log(this);
		if(botURL){
			bot=this.chatBots.get(botURL);
			if(bot){
				console.log("ChatBot "+botURL+":");
				console.log(bot);
			}
			return;
		}
		list=this.chatBots.values();
		for(bot of list){
			console.log("ChatBot "+bot.url+":");
			console.log(bot);
		}
	};
}

//****************************************************************************
//:I/O related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatSession.loadBot=async function(url,alias=null){
		let bots,baseBot,bot;
		alias=alias||url;
		bots=this.chatBots;
		bot=bots.get(alias);
		if(!bot){
			baseBot=await ChatBot.loadBot(this,url);
			bot=new ChatBot(this);
			await bot.cloneFrom(baseBot,alias);
			bots.set(alias,bot);
		}
		/*if(!this.entryBot){
			this.entryBot=bot;
		}*/
		return bot;
	};
	
	//------------------------------------------------------------------------
	chatSession.loadJSONBot=async function(url,json){
		let bot;
		bot=await ChatBot.loadJSON(this,url,json);
		this.chatBots.set(url,bot);
		return bot;
	};

	//------------------------------------------------------------------------
	chatSession.resetBots=async function(){
		let bots=this.chatBots.values();
		for(let bot of bots){
			await bot.reset();
		}
	};

	//------------------------------------------------------------------------
	chatSession.genSaveVO=function(savePath){
		let vo,dir;
		dir=pathLib.dirname(savePath);//Not used, we use absolute path by now
		vo={};
		//First, entryURL
		vo.entryURL=this.entryURL;
		//Bots
		{
			let chatBots,voBots,urls,url,bot; 
			voBots=vo.bots={};
			chatBots=this.chatBots;
			urls=chatBots.keys();
			for(url of urls){
				bot=chatBots.get(url);
				voBots[url]=bot.genSaveVO();
			}
		}
		//Breakpoints
		{
			let bps,vobps,bp;
			bps=this.getBreakPoints();
			vobps=vo.breaks=[];
			for(bp of bps){
				vobps.push({...bp});
			}
		}
		//GPTCheats
		{
			let cheats,vocheats,cheat;
			cheats=this.getGPTCheats();
			vocheats=vo.cheats=[];
			for(cheat of cheats){
				vocheats.push({...cheat});
			}
		}
		return vo;
	};
	
	//-----------------------------------------------------------------------
	chatSession.loadFromSaveVO=async function(vo,path){
		let dir;
		dir=pathLib.dirname(path);//Not used, we use absolute path by now
		this.initEntry(vo.entryURL);
		//Bots:
		{
			let voBots,url,voBot,bot;
			voBots=vo.bots;
			for(url in voBots){
				voBot=voBots[url];
				bot=await this.loadBot(url);
				await bot.loadFromSaveVO(voBot);
			}
		}
		//Breakpoints:
		{
			let voBreaks,actor,voBreak,bps,list;
			voBreaks=vo.breaks;
			bps=this.breakPointMap;
			for(voBreak of voBreaks){
				list=bps.get(voBreak.actor);
				if(!list){
					list=[];
					bps.set(voBreak.actor,list);
				}
				list.push(voBreak);
			}
			
		}
		//GPTCheats
		{
			let voCheats,actor,voCheat,bps,list;
			voCheats=vo.cheats;
			bps=this.gptCheatMap;
			for(voCheat of voCheats){
				list=bps.get(voCheat.actor);
				if(!list){
					list=[];
					bps.set(voCheat.actor,list);
				}
				list.push(voCheat);
			}
		}
	};
}

//****************************************************************************
//:Helper function:
//****************************************************************************
{
	chatSession.arrayBufferToDataURL=function(fileName,buf){
		let ext,result;
		if(fileName){
			ext=pathLib.extname(fileName);
		}
		result=Base64.encode(buf);
		switch(ext){
			case ".jpg":
				result="data:image/jpeg;base64,"+result;
				break;
			case ".png":
				result="data:image/png;base64,"+result;
				break;
			case ".txt":
				result="data:text/plain;base64,"+result;
				break;
			case ".json":
				result="data:text/json;base64,"+result;
				break;
			case '.pdf':
				result="data:application/pdf;base64,"+result;
				break;
			default:
				result="data:application/octet-stream;base64,"+result;
				break;
		}
		return result;
	};
}
export default ChatSession;
export {ChatSession};
