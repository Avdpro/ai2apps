### Debugging AI Agent


#### Information Flow:
The left side displays the information flow, which provides a detailed record of the entire AI Agent execution process.
Clicking on the title of each execution phase will open the detailed information for that phase.


#### Setting Breakpoints
In the detailed information of each execution phase, you can set breakpoints and specify the conditions for breakpoint activation.


#### GPT Cheat
During the stage of calling ChatGPT, you can set GPT Cheat. When the conditions for GPT Cheat are met, the GPT call will no longer be made over the network and will instead directly return the result set by GPT Cheat. This can significantly reduce token costs and improve debugging efficiency.