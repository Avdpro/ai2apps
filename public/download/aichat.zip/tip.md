### Debugging AI Agent


#### Information Flow:
The left side displays the information flow, which provides a detailed record of the entire AI Agent execution process.
Clicking on the title of each execution phase will open the detailed information for that phase.


#### Setting Breakpoints
In the detailed information of each execution phase, you can set breakpoints and specify the conditions for breakpoint activation.


#### GPT Mimic
During the stage of calling ChatGPT, you can set GPT Mimic. When the conditions for GPT Mimic are met, the GPT call will no longer be made over the network and will instead directly return the result set by GPT Mimic. This can significantly reduce token costs and improve debugging efficiency.