//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HS4Q7A0V0StartDoc*/
/*}#1HS4Q7A0V0StartDoc*/
let AppData={
	name:"AppData",//1HS4Q7A0V2
	type:"object",
	properties:{
		/*#{1HS4Q7A0V2MoreProperties*/
		/*}#1HS4Q7A0V2MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HS4Q7A0V2MoreFunctions*/
	/*}#1HS4Q7A0V2MoreFunctions*/
};
VFACT.regUITemplate("1HS4Q7A0V2",AppData);
VFACT.regUITemplate("AppData",AppData);
/*#{1HS4Q7A0V2MoreCodes*/
/*}#1HS4Q7A0V2MoreCodes*/
let TMPCreatePrj={
	name:"TMPCreatePrj",//1HS4QQSEP0
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
			label:"Project Name:",
			required:true,
		},
		sysPrompt:{
			name:"sysPrompt",type:"string",
			label:"System prompt:",
		},
		temperature:{
			name:"temperature",type:"number",
			label:"Temperature:",
			defaultValue:0.5,
		},
		greeting:{
			name:"greeting",type:"string",
			label:"Greeting:",
			defaultValue:"Hi, how can I help?",
			required:true,
		},
		/*#{1HS4QQSEP0MoreProperties*/
		/*}#1HS4QQSEP0MoreProperties*/
	},
	layout:["name","sysPrompt",["temperature",[]],"greeting"],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HS4QQSEP0MoreFunctions*/
	/*}#1HS4QQSEP0MoreFunctions*/
};
VFACT.regUITemplate("1HS4QQSEP0",TMPCreatePrj);
VFACT.regUITemplate("TMPCreatePrj",TMPCreatePrj);
/*#{1HS4QQSEP0MoreCodes*/
/*}#1HS4QQSEP0MoreCodes*/

/*#{1HS4Q7A0V0EndDoc*/
/*}#1HS4Q7A0V0EndDoc*/

export{AppData,TMPCreatePrj};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1HS4Q7A0V0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HS4Q7A0V1",
//			"attrs": {
//				"AppData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HS4Q7A0V2",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1HS4Q7A110",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HS4Q7A111",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HS4Q7A112",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template"
//					},
//					"mockups": {}
//				},
//				"TMPCreatePrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HS4QQSEP0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HS4QU8MF0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HS4QU8MF1",
//							"attrs": {
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HS4QU8MF2",
//									"attrs": {
//										"type": "string",
//										"label": "Project Name:",
//										"required": "true"
//									}
//								},
//								"sysPrompt": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HS4QU8MF3",
//									"attrs": {
//										"type": "string",
//										"label": "System prompt:"
//									}
//								},
//								"temperature": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HS4QU8MF4",
//									"attrs": {
//										"type": "number",
//										"label": "Temperature:",
//										"defaultValue": "0.5"
//									}
//								},
//								"greeting": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HS4QU8MF5",
//									"attrs": {
//										"type": "string",
//										"label": "Greeting:",
//										"defaultValue": "Hi, how can I help?",
//										"required": "true"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HS4QU8MF6",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "true",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "name"
//								},
//								{
//									"type": "auto",
//									"valText": "sysPrompt"
//								},
//								{
//									"type": "auto",
//									"valText": "[\"temperature\",[]]"
//								},
//								{
//									"type": "auto",
//									"valText": "greeting"
//								}
//							]
//						}
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}