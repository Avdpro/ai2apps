import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
//----------------------------------------------------------------------------
async function readSystemAIShortcuts(){
	let json;
	try{
		json=await tabFS.readFile("/coke/ai/shortcuts.json","utf8");
		json=JSON.parse(json);
	}catch(err){
		try{
			json=await tabFS.readFile("/-aichat/shortcuts.json","utf8");
			json=JSON.parse(json);
		}catch(err){
			json={version:0,shortcuts:[]};
		}
	}
	return json;
};

//----------------------------------------------------------------------------
async function saveSystemAIShortcuts(json){
	json.version+=1;
	await tabFS.writeFile("/coke/ai/shortcuts.json",JSON.stringify(json,null,"\t"),"utf8");
};

export {readSystemAIShortcuts,saveSystemAIShortcuts};