import {tabNT} from "/@tabos";
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";

//****************************************************************************
//HubFileLib
//****************************************************************************
let HubFileLib;
{
	//------------------------------------------------------------------------
	HubFileLib={};
	
	//------------------------------------------------------------------------
	HubFileLib.writeFile=async function(fileName,data){
		let res;
		if(typeof(data)==="string"){
			if(data.startsWith("data:")){
				let pos=data.indexOf(",");
				data=data.substring(pos+1);
			}
		}else{
			//Convert byteArray to string...
			data=Base64.encode(data);
		}
		res=await tabNT.makeCall("AhFileWrite",{fileName:fileName,data:data});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		return res.fileName;
	};

	//------------------------------------------------------------------------
	HubFileLib.readFile=async function(fileName){
		let res;
		if(fileName.startsWith("hub://")){
			fileName=fileName.substring(6);
		}
		res=await tabNT.makeCall("AhFileRead",{fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		return res.data;
	};

	//------------------------------------------------------------------------
	HubFileLib.readDataURL=async function(fileName){
		let res,data,extName;
		if(fileName.startsWith("hub://")){
			fileName=fileName.substring(6);
		}
		res=await tabNT.makeCall("AhFileRead",{fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		data=res.data;
		extName=pathLib.extname(fileName).toLowerCase();
		switch(extName){
			case ".jpg":
			case ".jpeg":
				data="data:image/jpeg;base64,"+data;
				break;
			case ".png":
				data="data:image/png;base64,"+data;
				break;
			case ".txt":
				data="data:text/plain;base64,"+data;
				break;
			case ".mp3":
				data="data:audio/mpeg;base64,"+data;
				break;
			case ".json":
				data="data:application/json;base64,"+data;
				break;
			case ".js":
			case ".mjs":
				data="data:application/javascript;base64,"+data;
				break;
			default:
				data="data:application/octet-stream;base64,"+data;
				break;
		}
		return data;
	};
}

export default HubFileLib;
export {HubFileLib};