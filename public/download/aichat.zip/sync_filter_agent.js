export default {
	upload:async function(buf){
		let enc,text;
		//Convert ByteArray to text:
		enc = new TextDecoder("utf-8");
		text=enc.decode(buf);
		{
			let pos;
			pos=text.indexOf("let context,globalContext;");
			if(pos>0){
				text=text.replaceAll(`import {$P,VFACT,callAfter,sleep} from "/@vfact";`,`import {$P,VFACT,callAfter,sleep} from "../tabos/vfact.mjs";`);
				text=text.replaceAll(`import pathLib from "/@path";`,`import pathLib from "path";`);
				text=text.replaceAll(`import inherits from "/@inherits";`,`import { inherits } from 'util';`);
				text=text.replaceAll(`import Base64 from "/@tabos/utils/base64.js";`,`import Base64 from "../tabos/utils/base64.js";`);
				text=text.replaceAll(`import {trimJSON} from "/@aichat/utils.js";`,`import {trimJSON} from "../tabos/aichat/utils.js";`);
			}
		}
		//Convert back to ByteArray:
		enc = new TextEncoder();
		return enc.encode(text);
	},
	download:async function(buf){
		//TODO: Code this:
	}
};