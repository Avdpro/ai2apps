import {esprima} from "/@tabos/utils/esprima.mjs";

//----------------------------------------------------------------------------
function fixJSON(text){
	let tokens,token;
	let ps=[];
	try{
		tokens = esprima.tokenize(text);
	}catch(err){
		return null;
	}
	for(token of tokens){
		switch(token.type){
			case "Punctuator":{
				switch(token.value){
					case "{":
						ps.push("{");
						break;
					case "}":
						if(ps[ps.length-1]==="{"){
							ps.pop();
						}
						throw Error("{/} not match");
						break;
					case "[":
						ps.push("[");
						break;
					case "]":
						if(ps[ps.length-1]==="["){
							ps.pop();
						}
						throw Error("[/] not match");
						break;
				}
			}
		}
	}
	if(ps.length>0){
		let i,n;
		n=ps.length;
		for(i=n-1;i>=0;i--){
			if(ps[i]==="{"){
				text+="}";
			}else if(ps[i]==="["){
				text+="]";
			}
		}
	}
	return JSON.parse(text);
};

function trimJSON(text){
	let pos1,pos2,json,jsonText;
	if(typeof(text)==="object"){//Already 
		return text;
	}
	pos1=text.indexOf("{");
	pos2=text.lastIndexOf("}");
	if(pos1>=0 && pos2>0){
		jsonText=text.substring(pos1,pos2+1);
		try{
			json=JSON.parse(jsonText);
		}catch(err){
			try{
				json=fixJSON(jsonText);
				if(!json){
					throw Error(`Can't parse JSON info from: ${text}.`);
				}
			}catch(err){
				throw Error(`Can't parse JSON info from: ${text}.`);
			}
		}
		return json;
	}
	if(pos1>=0){
		jsonText=text.substring(pos1);
		try{
			json=fixJSON(jsonText);
			if(!json){
				throw Error(`Can't parse JSON info from: ${text}.`);
			}
		}catch(err){
			throw Error(`Can't parse JSON info from: ${text}.`);
		}
		return json;
	}
	throw Error(`Can't parse JSON info from: ${text}.`);
};

export {trimJSON,fixJSON};
