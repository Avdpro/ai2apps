function trimJSON(text){
	let pos1,pos2,json;
	pos1=text.indexOf("{");
	pos2=text.lastIndexOf("}");
	if(pos1>=0 && pos2>0){
		json=text.substring(pos1,pos2+1);
		try{
			json=JSON.parse(json);
		}catch(err){
			throw Error(`Can't parse JSON info from: ${text}.`);
		}
		return json;
	}
	throw Error(`Can't find JSON info from: ${text}.`);
};

export {trimJSON};
