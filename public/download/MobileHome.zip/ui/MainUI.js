//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {SlideShow} from "/@StdUI/ui/SlideShow.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {InfoCard} from "/@StdUI/ui/InfoCard.js";
/*#{1GGJKM84D0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {BtnTextIcon} from "/@StdUI/ui/BtnTextIcon.js";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxAgents;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	let shortcuts=[
		{
			"name": "ChatGPT X",
			"icon": "/@aichat/assets/openai.svg",
			"source": "/@aichat/ai/chatgpt_x.js",
			"catalog": "tools",
			"style": "pro"
		},
		{
			"name": "Translator",
			"icon": "/~/-tabos/shared/assets/language.svg",
			"source": "/@aichat/ai/translator.js",
			"catalog": "tools",
			"style": "mini"
		},
		{
			"name": "Guess Game",
			"icon": "/~/-tabos/shared/assets/help.svg",
			"source": "/~/-aichat/ai/guess_game.js",
			"catalog": "relax",
			"style": "chat"
		},
	];
	
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[0,0,30,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HDJUGT970",
				"type":SlideShow(cfgColor["secondary"],5),"position":"relative","x":0,"y":0,"w":"100%","h":150,
				subContainers:{
					"1H4NCVJH60":[
						{
							"hash":"1HDJUKUAU0",
							"type":"hud","id":"Show1","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"padding":20,"minW":"","minH":"","maxW":"","maxH":"",
							"styleClass":"","contentLayout":"flex-y","subAlign":1,
							children:[
								{
									"hash":"1HDJV54BN0",
									"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
									"text":(($ln==="CN")?("创建自己的 AI Agent！"):("Create Your Own AI Agent!")),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
									"wrap":true,
								},
								{
									"hash":"1HDJVA3RP0",
									"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									children:[
										{
											"hash":"1HDJVGSOM0",
											"type":"text","x":120,"y":0,"w":">calc(100% - 140px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
											"text":(($ln==="CN")?("使用强大的桌面网页工具来创建、编辑和调试 AI 代理。"):("Use powerful desktop web tools to create, edit, and debug AI agents.")),"fontSize":txtSize.smallPlus,
											"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"wrap":true,
										},
										{
											"hash":"1HDJVL4UV0",
											"type":"box","x":20,"y":"50%","w":100,"h":100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
											"border":1,"maskImage":appCfg.sharedAssets+"/prj.svg",
										}
									],
								}
							],
						},
						{
							"hash":"1HDJVRM630",
							"type":"hud","id":"Show2","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":0,"padding":20,"minW":"","minH":"","maxW":"","maxH":"",
							"styleClass":"","contentLayout":"flex-y","subAlign":1,
							children:[
								{
									"hash":"1HDJVRM640",
									"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
									"text":(($ln==="CN")?("开发是一种享受！"):("Developing is Joyful!")),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
									"wrap":true,
								},
								{
									"hash":"1HDJVRM645",
									"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									"contentLayout":"flex-x","subAlign":1,"itemsAlign":1,
									children:[
										{
											"hash":"1HDJVRM655",
											"type":"box","position":"relative","x":0,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
											"border":1,"maskImage":appCfg.sharedAssets+"/cklogo.svg",
										},
										{
											"hash":"1HDJVRM650",
											"type":"text","position":"relative","x":0,"y":0,"w":">calc(100% - 150px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
											"text":(($ln==="CN")?("用新一代的所见即所得开发工具，轻松有趣的快速开发各种网页和应用。"):("New generation of WYSWYG dev-tools make it easy and fun to quickly develop websites and applications.")),
											"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"wrap":true,
										}
									],
								}
							],
						},
						{
							"hash":"1HDK017FO0",
							"type":"hud","id":"Show3","position":"relative","x":0,"y":0,"w":"100%","h":"100%","padding":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							"contentLayout":"flex-y","subAlign":1,
							children:[
								{
									"hash":"1HDK017FP0",
									"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
									"text":(($ln==="CN")?("AI Agent 就是App！"):("AI Agents work as Applications")),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal",
									"textDecoration":"","wrap":true,
								},
								{
									"hash":"1HDK017FQ3",
									"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
									"subAlign":1,"itemsAlign":1,
									children:[
										{
											"hash":"1HDK017FS0",
											"type":"box","position":"relative","x":0,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
											"border":1,"maskImage":appCfg.sharedAssets+"/app.svg",
										},
										{
											"hash":"1HDK017FQ5",
											"type":"text","position":"relative","x":0,"y":0,"w":">calc(100% - 140px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
											"color":cfgColor["fontBody"],"text":(($ln==="CN")?("开发好的 AI Agent 可以直接以App的形式使用，也可以嵌入已有的App中。"):("Your AI agent can be used as a standalone app or embedded in existing apps.")),
											"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"wrap":true,
										}
									],
								}
							],
						}
					]
				},
			},
			{
				"hash":"1HDK0JHOO0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":(($ln==="CN")?("AI Agent 样例:"):("AI Agent Samples")),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HDK231P90",
				"type":"hud","id":"BoxAgents","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,20,0,20],"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsWrap":1,
			},
			{
				"hash":"1HDL5GQ020",
				"type":"text","id":"TxtLogin","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","color":[0,0,0],"text":(($ln==="CN")?("请登录或注册以访问AI代理。"):("Please login or sign in to access AI agents.")),"fontWeight":"normal",
				"fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HDL5Q19Q0",
				"type":BtnText("primary",120,28,"Login",false,""),"id":"BtnLogin","position":"relative","x":"50%","y":0,"display":0,"anchorX":1,"margin":[10,0,0,0],
				"OnClick":function(event){
					/*#{1HDNKHJ400FunctionBody*/
					self.doLogin();
					/*}#1HDNKHJ400FunctionBody*/
				},
			},
			{
				"hash":"1HDL2RVAR0",
				"type":InfoCard((($ln==="CN")?("如何开始?"):("How to start?")),(($ln==="CN")?(`在桌面浏览器中打开 ${appCfg.isAI2Apps?"www.ai2apps.com":"www.tab-os.com"}，然后使用项目向导创建代理。`):(`Open ${appCfg.isAI2Apps?"www.ai2apps.com":"www.tab-os.com"} in desktop browser then create agent with project wizard.`)),appCfg.sharedAssets+"/desktop.svg",appCfg.sharedAssets+"/desktop.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HDO35P1A0",
				"type":InfoCard((($ln==="CN")?("极速创建原型"):("Rapid prototype")),(($ln==="CN")?("通过拖拽绘制拓扑图，快速直观的创建 AI Agent 并生成代码。"):("Create AI Agent quickly and intuitively by dragging and dropping to draw topology diagram and generate agent's codes.")),appCfg.sharedAssets+"/cursor_add.svg",appCfg.sharedAssets+"/cursor_add.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HDO4H5F30",
				"type":InfoCard((($ln==="CN")?("强大的开发工具"):("Powerful dev. tools")),(($ln==="CN")?("使用断点，单步执行，GPT伪装等功能快速调试优化Agent。"):("Use breakpoints, step execution, GPT cheat, and other features for fast debugging and optimizing the Agent.")),appCfg.sharedAssets+"/gas.svg",appCfg.sharedAssets+"/gas.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HDOOQLFN0",
				"type":InfoCard((($ln==="CN")?("像专业应用一样交互"):("Interactive like pro App")),(($ln==="CN")?("除了聊天对话，使用按钮、菜单、图表等各种UI形式提高互动效率"):("Besides chats, use various UI components such as buttons, menus, charts, etc. to enhance interaction efficiency")),appCfg.sharedAssets+"/faces.svg",appCfg.sharedAssets+"/faces.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HDT3SF320",
				"type":InfoCard((($ln==="CN")?("支持更多语言？点击即可！"):("Localization? Just click!")),(($ln==="CN")?("只需点击几下，就可以在 AI 的帮助下自动完成多语言支持"):("Just a few clicks, and your agent can support more languages with the help of AI")),appCfg.sharedAssets+"/language.svg",appCfg.sharedAssets+"/language.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HDT5PRAL0",
				"type":InfoCard((($ln==="CN")?("使用插件提升能力"):("Power up with add-on ")),(($ln==="CN")?("插件可以为Agent增加各种能力，例如绘画，语音等。Agent 本身也可以作为插件使用"):("Add-ons can add various capabilities to the Agent, such as drawing, voice, etc. The Agent itself can also be used as an add-on")),appCfg.sharedAssets+"/gears.svg",appCfg.sharedAssets+"/gears.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[10,0,0,0],
			},
			{
				"hash":"1HEG89DS30",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"styleClass":"","color":cfgColor["primary"],"text":"https://github.com/Avdpro/ai2apps",
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"underline","alignH":1,
				"OnClick":function(event){
					/*#{1HEG8O55T0FunctionBody*/
					window.open("https://github.com/Avdpro/ai2apps","");
					/*}#1HEG8O55T0FunctionBody*/
				},
			},
			{
				"hash":"1HDO4B28I0",
				"type":InfoCard((($ln==="CN")?("独立开发运行平台"):("Your own platform")),(($ln==="CN")?("用开源版ai2apps可以建立独立的运行、开发环境。"):("With the open-source version of ai2apps, you can create independent runtime and development environments.")),appCfg.sharedAssets+"/lab.svg",appCfg.sharedAssets+"/lab.svg",50,50),
				"position":"relative","x":"50%","y":0,"w":"90%","anchorX":1,"uiEvent":-1,"margin":[5,0,0,0],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"offline":{
				/*TxtLogin*/"#1HDL5GQ020":{
					"display":1
				},
				/*BtnLogin*/"#1HDL5Q19Q0":{
					"display":1
				}
			},"online":{
				/*TxtLogin*/"#1HDL5GQ020":{
					"display":0
				},
				/*BtnLogin*/"#1HDL5Q19Q0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxAgents=self.BoxAgents;
			/*#{1GGJKM84D1Create*/
			setInterval(()=>{state.counter++},1000);
			self.showAgents();
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showAgents=async function(){
		let chats,chatDef,box;
		if(!await tabNT.checkLogin(false)){
			self.showFace("offline");
		}
		//TODO: Read shortcuts:
		box=boxAgents;
		chats=shortcuts;
		for(chatDef of chats){
			box.appendNewChild({
				type:BtnTextIcon(60,60,chatDef.icon,cfgColor.fontBody,false,false,chatDef.name),chatDef:chatDef,
				position:"relative",x:0,y:0,margin:[0,15,0,0],padding:8,
				OnClick(evt){
					let chatDef=this.chatDef;
					self.startAIChat(chatDef);
				},
				OnContextMenu(evt){}
			});
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startAIChat=function(chatDef){
		window.open(`/@aichat/mobile.html?chat=${encodeURIComponent(chatDef.source)}&style=chatDef.style`,"AIChat_"+chatDef.source,"noreferrer");
	};
	
	//------------------------------------------------------------------------
	cssVO.doLogin=async function(){
		if(await app.modalDlg("/@homekit/ui/DlgLogin.js",{x:app.width/2,y:100,alignH:1})){
			self.showFace("online");
		}
	};
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/


export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"editVersion": 49,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1GGJKM84D2",
//			"editVersion": 36,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "1500",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GGJKM84D3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H90TKKV70",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D4",
//			"editVersion": 16,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D5",
//			"editVersion": 18,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1GGJKM84D6",
//			"editVersion": 4,
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1GGJKM84D7",
//			"editVersion": 4,
//			"attrs": {
//				"offline": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HDLE8P1F0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HDM6P7HN0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"online": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HDLE804M0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HDM6P7HN1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HDJUG9P60",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"editVersion": 16,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1GGJKM84D8",
//					"editVersion": 148,
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,0,30,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/SlideShow.js",
//							"jaxId": "1HDJUGT970",
//							"editVersion": 29,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDJUK94J0",
//									"editVersion": 10,
//									"attrs": {
//										"frontColor": "#cfgColor[\"secondary\"]",
//										"showTime": "5"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDJUK94J1",
//									"editVersion": 63,
//									"attrs": {
//										"type": "#null#>SlideShow(cfgColor[\"secondary\"],5)",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "150"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDJUK94J2",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDJUK94J3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDJUK94J4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDJUK94J5",
//									"editVersion": 2,
//									"attrs": {
//										"Slot1H4NCVJH60": {
//											"type": "gearcontainer",
//											"jaxId": "1HDJUH2SM0",
//											"editVersion": 4,
//											"attrs": {
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HDJUKUAU0",
//															"editVersion": 25,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HDJVFC2B0",
//																	"editVersion": 124,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "Show1",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "20",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HDJV54BN0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B1",
//																					"editVersion": 134,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "创建自己的 AI Agent！",
//																							"localize": {
//																								"EN": "Create Your Own AI Agent!",
//																								"CN": "创建自己的 AI Agent！"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.midPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "true",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B2",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN4",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN5",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN6",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN7",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDJVFC2B4",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HDJVA3RP0",
//																			"editVersion": 22,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B5",
//																					"editVersion": 64,
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HDJVGSOM0",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV0",
//																									"editVersion": 142,
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "120",
//																										"y": "0",
//																										"w": "100%-140",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": {
//																											"type": "string",
//																											"valText": "使用强大的桌面网页工具来创建、编辑和调试 AI 代理。",
//																											"localize": {
//																												"EN": "Use powerful desktop web tools to create, edit, and debug AI agents.",
//																												"CN": "使用强大的桌面网页工具来创建、编辑和调试 AI 代理。"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "true",
//																										"ellipsis": "false",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV1",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN8",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN9",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN10",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN11",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV2",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDJVN0QV3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HDJVL4UV0",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV4",
//																									"editVersion": 110,
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "20",
//																										"y": "50%",
//																										"w": "100",
//																										"h": "100",
//																										"anchorH": "Left",
//																										"anchorV": "Center",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/prj.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV5",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN12",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN13",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN14",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN15",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDJVN0QV6",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDJVN0QV7",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B10",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN16",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN17",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN18",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN19",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDJVFC2B11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDJVFC2B12",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HDJVFC2B13",
//																	"editVersion": 4,
//																	"attrs": {
//																		"1HDLE804M0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN20",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN21",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE804M0",
//																			"faceTagName": "online"
//																		},
//																		"1HDLE8P1F0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN22",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN23",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE8P1F0",
//																			"faceTagName": "offline"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HDJVFC2B14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HDJVFC2B15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HDJVRM630",
//															"editVersion": 27,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HDJVRM631",
//																	"editVersion": 124,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "Show2",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "20",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HDJVRM640",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM641",
//																					"editVersion": 152,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "开发是一种享受！",
//																							"localize": {
//																								"EN": "Developing is Joyful!",
//																								"CN": "开发是一种享受！"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.midPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "true",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM642",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN24",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN25",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN26",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN27",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM643",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDJVRM644",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HDJVRM645",
//																			"editVersion": 22,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM646",
//																					"editVersion": 114,
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "[0,0,0,0]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"subAlign": "Center",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HDJVRM655",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM656",
//																									"editVersion": 154,
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100",
//																										"h": "100",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/cklogo.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM660",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN28",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN29",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN30",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN31",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM661",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDJVRM662",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HDJVRM650",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM651",
//																									"editVersion": 194,
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%-150",
//																										"h": "",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": {
//																											"type": "string",
//																											"valText": "用新一代的所见即所得开发工具，轻松有趣的快速开发各种网页和应用。",
//																											"localize": {
//																												"EN": "New generation of WYSWYG dev-tools make it easy and fun to quickly develop websites and applications.",
//																												"CN": "用新一代的所见即所得开发工具，轻松有趣的快速开发各种网页和应用。"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "true",
//																										"ellipsis": "false",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"flex": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM652",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN32",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN33",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN34",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN35",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDJVRM653",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDJVRM654",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM663",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN36",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN37",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN38",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN39",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDJVRM664",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDJVRM665",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HDJVRM666",
//																	"editVersion": 4,
//																	"attrs": {
//																		"1HDLE804M0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN40",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN41",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE804M0",
//																			"faceTagName": "online"
//																		},
//																		"1HDLE8P1F0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN42",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN43",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE8P1F0",
//																			"faceTagName": "offline"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HDJVRM667",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HDJVRM668",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HDK017FO0",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HDK017FO1",
//																	"editVersion": 104,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "Show3",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "20",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HDK017FP0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDK017FP1",
//																					"editVersion": 140,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "AI Agent 就是App！",
//																							"localize": {
//																								"EN": "AI Agents work as Applications",
//																								"CN": "AI Agent 就是App！"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.midPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "true",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDK017FQ0",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN44",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN45",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN46",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN47",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDK017FQ1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDK017FQ2",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HDK017FQ3",
//																			"editVersion": 22,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDK017FQ4",
//																					"editVersion": 76,
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"subAlign": "Center",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HDK017FS0",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDK017FS1",
//																									"editVersion": 136,
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100",
//																										"h": "100",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/app.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDK017FS2",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN48",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN49",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN50",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN51",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDK017FS3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDK017FS4",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HDK017FQ5",
//																							"editVersion": 20,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDK017FQ6",
//																									"editVersion": 152,
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%-140",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": {
//																											"type": "string",
//																											"valText": "开发好的 AI Agent 可以直接以App的形式使用，也可以嵌入已有的App中。",
//																											"localize": {
//																												"EN": "Your AI agent can be used as a standalone app or embedded in existing apps.",
//																												"CN": "开发好的 AI Agent 可以直接以App的形式使用，也可以嵌入已有的App中。"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "true",
//																										"ellipsis": "false",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"type": "array",
//																									"attrs": []
//																								},
//																								"faces": {
//																									"type": "object",
//																									"jaxId": "1HDK017FQ7",
//																									"editVersion": 4,
//																									"attrs": {
//																										"1HDLE804M0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN52",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN53",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE804M0",
//																											"faceTagName": "online"
//																										},
//																										"1HDLE8P1F0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HDM6P7HN54",
//																											"editVersion": 4,
//																											"attrs": {
//																												"properties": {
//																													"type": "object",
//																													"jaxId": "1HDM6P7HN55",
//																													"editVersion": 0,
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"type": "array",
//																													"def": "Array",
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HDLE8P1F0",
//																											"faceTagName": "offline"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"type": "object",
//																									"jaxId": "1HDK017FQ8",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"type": "object",
//																									"def": "Object",
//																									"jaxId": "1HDK017FQ9",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HDK017FS5",
//																					"editVersion": 4,
//																					"attrs": {
//																						"1HDLE804M0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN56",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN57",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE804M0",
//																							"faceTagName": "online"
//																						},
//																						"1HDLE8P1F0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HDM6P7HN58",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1HDM6P7HN59",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HDLE8P1F0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HDK017FS6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HDK017FS7",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HDK017FS8",
//																	"editVersion": 4,
//																	"attrs": {
//																		"1HDLE804M0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN60",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN61",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE804M0",
//																			"faceTagName": "online"
//																		},
//																		"1HDLE8P1F0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HDM6P7HN62",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HDM6P7HN63",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HDLE8P1F0",
//																			"faceTagName": "offline"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HDK017FS9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HDK017FS10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HDK0JHOO0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDK1BHQP0",
//									"editVersion": 164,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": {
//											"type": "string",
//											"valText": "AI Agent 样例:",
//											"localize": {
//												"EN": "AI Agent Samples",
//												"CN": "AI Agent 样例:"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDK1BHQP1",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN64",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN65",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDK1BHQP2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDK1BHQP3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HDK231P90",
//							"editVersion": 30,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDL4PG7C0",
//									"editVersion": 114,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxAgents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "0",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDL4PG7C1",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN66",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN67",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDL4PG7C2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDL4PG7C3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HDL5GQ020",
//							"editVersion": 26,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDL61PH40",
//									"editVersion": 164,
//									"attrs": {
//										"type": "text",
//										"id": "TxtLogin",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": {
//											"type": "string",
//											"valText": "请登录或注册以访问AI代理。",
//											"localize": {
//												"EN": "Please login or sign in to access AI agents.",
//												"CN": "请登录或注册以访问AI代理。"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "16",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDL61PH41",
//									"editVersion": 4,
//									"attrs": {
//										"1HDLE804M0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN68",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN69",
//													"editVersion": 6,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE804M0",
//											"faceTagName": "online"
//										},
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN70",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN71",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDL61PH42",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDL61PH43",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1HDL5Q19Q0",
//							"editVersion": 38,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDL61PH44",
//									"editVersion": 40,
//									"attrs": {
//										"style": "primary",
//										"w": "120",
//										"h": "28",
//										"text": "Login",
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDL61PH45",
//									"editVersion": 77,
//									"attrs": {
//										"type": "#null#>BtnText(\"primary\",120,28,\"Login\",false,\"\")",
//										"id": "BtnLogin",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "Off",
//										"face": "",
//										"anchorH": "Center",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDL61PH46",
//									"editVersion": 4,
//									"attrs": {
//										"1HDLE804M0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN72",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN73",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE804M0",
//											"faceTagName": "online"
//										},
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN74",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN75",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDL61PH47",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HDNKHJ400",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HDNKHPII0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDL61PH48",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDL61PH49",
//									"editVersion": 2,
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"type": "gearcontainer",
//											"jaxId": "1HDL61PH410",
//											"editVersion": 4,
//											"attrs": {
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDL2RVAR0",
//							"editVersion": 39,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDL34TB70",
//									"editVersion": 56,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "如何开始?",
//											"localize": {
//												"EN": "How to start?",
//												"CN": "如何开始?"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "#`在桌面浏览器中打开 ${appCfg.isAI2Apps?\"www.ai2apps.com\":\"www.tab-os.com\"}，然后使用项目向导创建代理。`",
//											"localize": {
//												"EN": "#`Open ${appCfg.isAI2Apps?\"www.ai2apps.com\":\"www.tab-os.com\"} in desktop browser then create agent with project wizard.`",
//												"CN": "#`在桌面浏览器中打开 ${appCfg.isAI2Apps?\"www.ai2apps.com\":\"www.tab-os.com\"}，然后使用项目向导创建代理。`"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/desktop.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/desktop.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDL34TB71",
//									"editVersion": 101,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"如何开始?\"):(\"How to start?\")),(($ln===\"CN\")?(`在桌面浏览器中打开 ${appCfg.isAI2Apps?\"www.ai2apps.com\":\"www.tab-os.com\"}，然后使用项目向导创建代理。`):(`Open ${appCfg.isAI2Apps?\"www.ai2apps.com\":\"www.tab-os.com\"} in desktop browser then create agent with project wizard.`)),appCfg.sharedAssets+\"/desktop.svg\",appCfg.sharedAssets+\"/desktop.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDL34TB72",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDM6P7HN76",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDM6P7HN77",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDL34TB73",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDL34TB74",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDL34TB75",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDO35P1A0",
//							"editVersion": 53,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDO35P1A1",
//									"editVersion": 106,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "极速创建原型",
//											"localize": {
//												"EN": "Rapid prototype",
//												"CN": "极速创建原型"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "通过拖拽绘制拓扑图，快速直观的创建 AI Agent 并生成代码。",
//											"localize": {
//												"EN": "Create AI Agent quickly and intuitively by dragging and dropping to draw topology diagram and generate agent's codes.",
//												"CN": "通过拖拽绘制拓扑图，快速直观的创建 AI Agent 并生成代码。"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/cursor_add.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/cursor_add.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDO35P1A2",
//									"editVersion": 115,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"极速创建原型\"):(\"Rapid prototype\")),(($ln===\"CN\")?(\"通过拖拽绘制拓扑图，快速直观的创建 AI Agent 并生成代码。\"):(\"Create AI Agent quickly and intuitively by dragging and dropping to draw topology diagram and generate agent's codes.\")),appCfg.sharedAssets+\"/cursor_add.svg\",appCfg.sharedAssets+\"/cursor_add.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDO35P1A3",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDO35P1B0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDO35P1B1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDO35P1B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDO35P1B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDO35P1B4",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDO4H5F30",
//							"editVersion": 56,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDO4H5F31",
//									"editVersion": 130,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "强大的开发工具",
//											"localize": {
//												"EN": "Powerful dev. tools",
//												"CN": "强大的开发工具"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "使用断点，单步执行，GPT伪装等功能快速调试优化Agent。",
//											"localize": {
//												"EN": "Use breakpoints, step execution, GPT cheat, and other features for fast debugging and optimizing the Agent.",
//												"CN": "使用断点，单步执行，GPT伪装等功能快速调试优化Agent。"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/gas.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDO4H5F32",
//									"editVersion": 118,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"强大的开发工具\"):(\"Powerful dev. tools\")),(($ln===\"CN\")?(\"使用断点，单步执行，GPT伪装等功能快速调试优化Agent。\"):(\"Use breakpoints, step execution, GPT cheat, and other features for fast debugging and optimizing the Agent.\")),appCfg.sharedAssets+\"/gas.svg\",appCfg.sharedAssets+\"/gas.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDO4H5F40",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDO4H5F41",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDO4H5F42",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDO4H5F43",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDO4H5F44",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDO4H5F45",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDOOQLFN0",
//							"editVersion": 60,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDOOQLFN1",
//									"editVersion": 126,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "像专业应用一样交互",
//											"localize": {
//												"EN": "Interactive like pro App",
//												"CN": "像专业应用一样交互"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "除了聊天对话，使用按钮、菜单、图表等各种UI形式提高互动效率",
//											"localize": {
//												"EN": "Besides chats, use various UI components such as buttons, menus, charts, etc. to enhance interaction efficiency",
//												"CN": "除了聊天对话，使用按钮、菜单、图表等各种UI形式提高互动效率"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/faces.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDOOQLFN2",
//									"editVersion": 122,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"像专业应用一样交互\"):(\"Interactive like pro App\")),(($ln===\"CN\")?(\"除了聊天对话，使用按钮、菜单、图表等各种UI形式提高互动效率\"):(\"Besides chats, use various UI components such as buttons, menus, charts, etc. to enhance interaction efficiency\")),appCfg.sharedAssets+\"/faces.svg\",appCfg.sharedAssets+\"/faces.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDOOQLFO0",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDOOQLFO1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDOOQLFO2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDOOQLFO3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDOOQLFO4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDOOQLFO5",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDT3SF320",
//							"editVersion": 67,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDT3SF321",
//									"editVersion": 146,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "支持更多语言？点击即可！",
//											"localize": {
//												"EN": "Localization? Just click!",
//												"CN": "支持更多语言？点击即可！"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "只需点击几下，就可以在 AI 的帮助下自动完成多语言支持",
//											"localize": {
//												"EN": "Just a few clicks, and your agent can support more languages with the help of AI",
//												"CN": "只需点击几下，就可以在 AI 的帮助下自动完成多语言支持"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/language.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/language.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDT3SF330",
//									"editVersion": 129,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"支持更多语言？点击即可！\"):(\"Localization? Just click!\")),(($ln===\"CN\")?(\"只需点击几下，就可以在 AI 的帮助下自动完成多语言支持\"):(\"Just a few clicks, and your agent can support more languages with the help of AI\")),appCfg.sharedAssets+\"/language.svg\",appCfg.sharedAssets+\"/language.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDT3SF331",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDT3SF332",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDT3SF333",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDT3SF334",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDT3SF335",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDT3SF336",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDT5PRAL0",
//							"editVersion": 74,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDT5PRAL1",
//									"editVersion": 166,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "使用插件提升能力",
//											"localize": {
//												"EN": "Power up with add-on ",
//												"CN": "使用插件提升能力"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "插件可以为Agent增加各种能力，例如绘画，语音等。Agent 本身也可以作为插件使用",
//											"localize": {
//												"EN": "Add-ons can add various capabilities to the Agent, such as drawing, voice, etc. The Agent itself can also be used as an add-on",
//												"CN": "插件可以为Agent增加各种能力，例如绘画，语音等。Agent 本身也可以作为插件使用"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/gears.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/gears.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDT5PRAL2",
//									"editVersion": 136,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"使用插件提升能力\"):(\"Power up with add-on \")),(($ln===\"CN\")?(\"插件可以为Agent增加各种能力，例如绘画，语音等。Agent 本身也可以作为插件使用\"):(\"Add-ons can add various capabilities to the Agent, such as drawing, voice, etc. The Agent itself can also be used as an add-on\")),appCfg.sharedAssets+\"/gears.svg\",appCfg.sharedAssets+\"/gears.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDT5PRAL3",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDT5PRAL4",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDT5PRAL5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDT5PRAL6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDT5PRAL7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDT5PRAL8",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HEG89DS30",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HEG8BP4S0",
//									"editVersion": 148,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"primary\"]",
//										"text": "https://github.com/Avdpro/ai2apps",
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "true",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HEG8BP4S1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HEG8BP4S2",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HEG8O55T0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HEG8PB290",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HEG8BP4S3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/InfoCard.js",
//							"jaxId": "1HDO4B28I0",
//							"editVersion": 48,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HDO4B28I1",
//									"editVersion": 86,
//									"attrs": {
//										"title": {
//											"type": "string",
//											"valText": "独立开发运行平台",
//											"localize": {
//												"EN": "Your own platform",
//												"CN": "独立开发运行平台"
//											},
//											"localizable": true
//										},
//										"intro": {
//											"type": "string",
//											"valText": "用开源版ai2apps可以建立独立的运行、开发环境。",
//											"localize": {
//												"EN": "With the open-source version of ai2apps, you can create independent runtime and development environments.",
//												"CN": "用开源版ai2apps可以建立独立的运行、开发环境。"
//											},
//											"localizable": true
//										},
//										"pic": "#appCfg.sharedAssets+\"/lab.svg\"",
//										"icon": "#appCfg.sharedAssets+\"/lab.svg\"",
//										"picW": "50",
//										"picH": "50"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDO4B28I2",
//									"editVersion": 128,
//									"attrs": {
//										"type": "#null#>InfoCard((($ln===\"CN\")?(\"独立开发运行平台\"):(\"Your own platform\")),(($ln===\"CN\")?(\"用开源版ai2apps可以建立独立的运行、开发环境。\"):(\"With the open-source version of ai2apps, you can create independent runtime and development environments.\")),appCfg.sharedAssets+\"/lab.svg\",appCfg.sharedAssets+\"/lab.svg\",50,50)",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "90%",
//										"anchorH": "Center",
//										"uiEvent": "Tree Off",
//										"margin": "[5,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HDO4B28I3",
//									"editVersion": 10,
//									"attrs": {
//										"1HDLE8P1F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HDO4B28I4",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HDO4B28I5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HDLE8P1F0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HDO4B28I6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HDO4B28I7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HDO4B28I8",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1GGJKM84D9",
//					"editVersion": 10,
//					"attrs": {
//						"1HDLE8P1F0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HDM6P7HN78",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HDM6P7HN79",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HDLE8P1F0",
//							"faceTagName": "offline"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1GGJKM84D10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJKM84D11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"editVersion": 70,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}