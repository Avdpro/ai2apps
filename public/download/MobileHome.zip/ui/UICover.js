//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HJLN4Q610StartDoc*/
import {tabFS,tabNT} from "/@tabos";
import {installPkgOnDisk} from "/@pkg/pkgUtil.js";
/*}#1HJLN4Q610StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UICover=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtLog;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let diskJSON=null;
	let appInfo=null;
	let appId="";
	let skipedVersion=0;
	
	/*#{1HJLN4Q620LocalVals*/
	/*}#1HJLN4Q620LocalVals*/
	
	/*#{1HJLN4Q620PreState*/
	/*}#1HJLN4Q620PreState*/
	/*#{1HJLN4Q620PostState*/
	/*}#1HJLN4Q620PostState*/
	cssVO={
		"hash":"1HJLN4Q620",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HJLN55A30",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
			},
			{
				"hash":"1HJN9735P0",
				"type":"text","id":"TxtTitle","x":"50%","y":">calc(40% - 150px)","w":"100%","h":"","anchorX":1,"anchorY":2,"minW":"","minH":"","maxW":500,"maxH":"",
				"styleClass":"","color":cfgColor["fontBodyLit"],"text":"Powered by AI2Apps","fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"alignH":1,"wrap":true,
			},
			{
				"hash":"1HJLN5VUP0",
				"type":"box","id":"BoxLogo","x":"50%","y":"40%","w":300,"h":300,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
				"border":1,"maskImage":appCfg.sharedAssets+"/aalogo.svg",
			},
			{
				"hash":"1HJLN9OC20",
				"type":"text","id":"TxtFooter","x":0,"y":">calc(100% - 5px)","w":"100%","h":"","anchorY":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBodySub"],"text":"www.ai2apps.com","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignH":1,
			},
			{
				"hash":"1HJLODRH40",
				"type":"hud","id":"BoxUpdate","x":"50%","y":">calc(40% + 150px)","w":"100%","h":"","anchorX":1,"display":0,"minW":"","minH":"","maxW":500,"maxH":"",
				"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HJLOF2DU0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"New version available, update? ","fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
					},
					{
						"hash":"1HJLOHV9L0",
						"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1HJLOIS2L0",
								"type":BtnText("secondary",100,24,"Cancel",false,""),"id":"BtnCancel","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"OnClick":function(event){
									self.runApp(this,event);
								},
							},
							{
								"hash":"1HJLOJKSH0",
								"type":BtnText("primary",100,24,"Update",false,""),"id":"BtnUpdate","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"OnClick":function(event){
									self.updateApp(this,event);
								},
							},
							{
								"hash":"1HJLOJMKO0",
								"type":BtnText("warning",100,24,"Skip Version",false,""),"id":"BtnSkip","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"OnClick":function(event){
									self.skipVersion(this,event);
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HJN8QFJT0",
				"type":"hud","id":"BoxState","x":"50%","y":">calc(40% + 150px)","w":"100%","h":100,"anchorX":1,"minW":"","minH":"","maxW":500,"maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HJN8S3OQ0",
						"type":"text","id":"TxtState","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Starting Application",
						"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
					},
					{
						"hash":"1HJN8VQQN0",
						"type":"text","id":"TxtLog","x":0,"y":30,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":"","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"wrap":true,
					}
				],
			}
		],
		/*#{1HJLN4Q620ExtraCSS*/
		/*}#1HJLN4Q620ExtraCSS*/
		faces:{
			"init":{
				/*TxtTitle*/"#1HJN9735P0":{
					"display":0
				},
				/*BoxLogo*/"#1HJLN5VUP0":{
					ani:[
						{
							"type":"in","time":500,"alpha":0
						}
					]
				},
				/*BoxUpdate*/"#1HJLODRH40":{
					"display":0
				},
				/*BoxState*/"#1HJN8QFJT0":{
					"display":0
				},
				/*TxtState*/"#1HJN8S3OQ0":{
					"text":(($ln==="CN")?("启动应用程序"):("Starting Application"))
				},"@500":{
					/*TxtTitle*/"#1HJN9735P0":{
						"display":1,
						ani:[
							{
								"type":"in","time":300,"alpha":0
							}
						]
					},
					/*BoxState*/"#1HJN8QFJT0":{
						"display":0
					}
				},"@1500":{
					/*BoxState*/"#1HJN8QFJT0":{
						"display":1
					}
				}
			},"update":{
				/*BoxUpdate*/"#1HJLODRH40":{
					"display":1,
					ani:[
						{
							"type":"in","time":100,"alpha":0,"dy":50
						}
					]
				},
				/*BoxState*/"#1HJN8QFJT0":{
					"display":0
				}
			},"install":{
				/*TxtState*/"#1HJN8S3OQ0":{
					"text":(($ln==="CN")?("正在安装应用程序"):("Installing application"))
				}
			},"doUpdate":{
				/*BoxUpdate*/"#1HJLODRH40":{
					"display":0
				},
				/*BoxState*/"#1HJN8QFJT0":{
					"display":1
				},
				/*TxtState*/"#1HJN8S3OQ0":{
					"text":(($ln==="CN")?("正在升级应用程序......"):("Updating Application..."))
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtLog=self.TxtLog;
			/*#{1HJLN4Q620Create*/
			self.start();
			/*}#1HJLN4Q620Create*/
		},
		/*#{1HJLN4Q620EndCSS*/
		/*}#1HJLN4Q620EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.start=async function(){
		/*#{1HJMEOKD90Start*/
		let urlHost,pts;
		urlHost=document.location.host;
		pts=urlHost.split(".");
		if(pts[1]==="apps"){
			appId=pts[0];
		}else{
			appId=VFACT.appParams["app"];
		}
		if(!appId){
			window.alert((($ln==="CN")?("缺少应用程序 ID."):/*EN*/("Missing application ID.")));
			return;
		}
		skipedVersion=localStorage.getItem("SkipedAppVersion");
		if(skipedVersion){
			skipedVersion=parseInt(skipedVersion)||0;
		}
		/*}#1HJMEOKD90Start*/
		self.showFace("init");
		await sleep(2000);
		
		//Read JSON
		/*#{1HJMEOKD91*/
		try{
			diskJSON=await tabFS.readFile(`/-${appId}/disk.json`,"utf8");
			diskJSON=JSON.parse(diskJSON);
		}catch(err){
			diskJSON=null;
		}
		/*}#1HJMEOKD91*/
		if(!diskJSON){
			self.showFace("install");
			
			//installApp
			/*#{1HJMFEOPN0*/
			await self.installApp();
			/*}#1HJMFEOPN0*/
			return;
		}else{
			//getAppInfo
			/*#{1HJMFEOPN2*/
			let res=await tabNT.makeCall("GetAppInfo",{appId:appId});
			if(!res || res.code!==200){
				appInfo=null;
			}else{
				appInfo=res.info;
			}
			/*}#1HJMFEOPN2*/
			if(appInfo && appInfo.versionIdx>(skipedVersion || diskJSON.appVersionIdx)){
				self.showFace("update");
				return;
			}
			
			//StartApp
			/*#{1HJMFEOPN4*/
			self.runApp();
			/*}#1HJMFEOPN4*/
			return;
		}
	};
	//------------------------------------------------------------------------
	cssVO.skipVersion=async function(sender,event){
		/*#{1HJMFUP2O0Start*/
		skipedVersion=appInfo.versionIdx;
		/*}#1HJMFUP2O0Start*/
		
		//Save Skip
		/*#{1HJMG0SRR0*/
		localStorage.setItem("SkipedAppVersion",""+skipedVersion);
		/*}#1HJMG0SRR0*/
		
		//Run App
		/*#{1HJMG503Q0*/
		self.runApp();
		/*}#1HJMG503Q0*/
	};
	//------------------------------------------------------------------------
	cssVO.runApp=async function(){
		/*#{1HJML6RKU0Start*/
		document.location.href=`/~/-${appId}/app.html`;
		/*}#1HJML6RKU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.installApp=async function(){
		/*#{1HJML84LR0Start*/
		await installPkgOnDisk(self,"coke",appId,{});
		//Clear skip version
		localStorage.setItem("SkipedAppVersion","");
		/*}#1HJML84LR0Start*/
		
		//RunApp
		/*#{1HJMLAC9K0*/
		self.runApp();
		/*}#1HJMLAC9K0*/
	};
	//------------------------------------------------------------------------
	cssVO.textOut=async function(text){
		/*#{1HJMR6QK00Start*/
		txtLog.text=""+text;
		/*}#1HJMR6QK00Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearLine=async function(){
		/*#{1HJMR8M8P0Start*/
		txtLog.text="";
		/*}#1HJMR8M8P0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateApp=async function(){
		/*#{1HJNAUU6F0Start*/
		/*}#1HJNAUU6F0Start*/
		self.showFace("doUpdate");
		
		//Install App
		/*#{1HJNAUU6F1*/
		self.installApp();
		/*}#1HJNAUU6F1*/
	};
	/*#{1HJLN4Q620PostCSSVO*/
	/*}#1HJLN4Q620PostCSSVO*/
	return cssVO;
};
/*#{1HJLN4Q620ExCodes*/
/*}#1HJLN4Q620ExCodes*/


export default UICover;
export{UICover};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1HJLN4Q610",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HJLN4Q630",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HJLN4Q631",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HJLN4Q632",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HJLN4Q633",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HJLN4Q634",
//			"attrs": {
//				"diskJSON": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appInfo": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appId": {
//					"type": "string",
//					"valText": ""
//				},
//				"skipedVersion": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HJLN4Q635",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJMEOKD90",
//					"attrs": {
//						"id": "start",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJMEOKDA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJMEOKDA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HJMEOKDA2",
//									"attrs": {
//										"id": "showFace",
//										"label": "New AI Seg",
//										"x": "320",
//										"y": "170",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "init",
//										"outlet": {
//											"jaxId": "1HJMEOKDA3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJN9VQ230"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMEOKD91",
//									"attrs": {
//										"id": "ReadJSON",
//										"label": "New AI Seg",
//										"x": "740",
//										"y": "170",
//										"desc": "Read JSON",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMEOKDA4",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMF052F0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Condition",
//									"jaxId": "1HJMF052F0",
//									"attrs": {
//										"id": "CheckInstall",
//										"label": "New AI Seg",
//										"x": "970",
//										"y": "170",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "ConditionOutlet",
//													"jaxId": "1HJMERKMF0",
//													"attrs": {
//														"id": "install",
//														"condition": "!diskJSON",
//														"codes": "false",
//														"desc": "条件输出节点。"
//													},
//													"linkedSeg": "1HJNAQGK50"
//												}
//											]
//										},
//										"catchlet": {
//											"jaxId": "1HJMF052E0",
//											"attrs": {
//												"id": "update",
//												"desc": "输出节点。",
//												"codes": "false"
//											},
//											"linkedSeg": "1HJMFEOPN2"
//										},
//										"outlet": {
//											"jaxId": "1HJMF052F1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMFEOPN0",
//									"attrs": {
//										"id": "installApp",
//										"label": "New AI Seg",
//										"x": "1450",
//										"y": "90",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMFEOPQ0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMP6L860"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMFEOPN2",
//									"attrs": {
//										"id": "getAppInfo",
//										"label": "New AI Seg",
//										"x": "1230",
//										"y": "210",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMFEOPQ1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMFEOPQ2"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Condition",
//									"jaxId": "1HJMFEOPQ2",
//									"attrs": {
//										"id": "checkUpdate",
//										"label": "New AI Seg",
//										"x": "1460",
//										"y": "210",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "ConditionOutlet",
//													"jaxId": "1HJMF6H440",
//													"attrs": {
//														"id": "Condition",
//														"condition": "appInfo && appInfo.versionIdx>(skipedVersion || diskJSON.appVersionIdx)",
//														"codes": "false",
//														"desc": "条件输出节点。"
//													},
//													"linkedSeg": "1HJMOS9JG0"
//												}
//											]
//										},
//										"catchlet": {
//											"jaxId": "1HJMFEOPQ3",
//											"attrs": {
//												"id": "else",
//												"desc": "输出节点。",
//												"codes": "false"
//											}
//										},
//										"outlet": {
//											"jaxId": "1HJMFEOPQ4",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMFEOPN4"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMFEOPN4",
//									"attrs": {
//										"id": "StartApp",
//										"label": "New AI Seg",
//										"x": "1740",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMFEOPQ7",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMFEOPQ8"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HJMFEOPQ8",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "1970",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"result": ""
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HJMOS9JG0",
//									"attrs": {
//										"id": "Show update",
//										"label": "New AI Seg",
//										"x": "1740",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "update",
//										"outlet": {
//											"jaxId": "1HJMOS9JG1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMPF0OG0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HJMP6L860",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "1660",
//										"y": "90",
//										"desc": "",
//										"codes": "false",
//										"result": ""
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HJMPF0OG0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "1970",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"result": ""
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Wait",
//									"jaxId": "1HJN9VQ230",
//									"attrs": {
//										"id": "Wait Ani",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "170",
//										"desc": "",
//										"codes": "false",
//										"time": "2000",
//										"outlet": {
//											"jaxId": "1HJN9VQ231",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMEOKD91"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HJNAQGK50",
//									"attrs": {
//										"id": "Show Install",
//										"label": "New AI Seg",
//										"x": "1230",
//										"y": "90",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "install",
//										"outlet": {
//											"jaxId": "1HJNAQGK51",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMFEOPN0"
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HJMEOKDA5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HJMEOKDA2"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJMFUP2O0",
//					"attrs": {
//						"id": "skipVersion",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "270",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJMG0SRV0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJMG0SRV1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMG0SRR0",
//									"attrs": {
//										"id": "Save Skip ",
//										"label": "New AI Seg",
//										"x": "390",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMG0SRV2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJMG503Q0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMG503Q0",
//									"attrs": {
//										"id": "Run App",
//										"label": "New AI Seg",
//										"x": "620",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMG503R0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HJMG0SRV3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HJMG0SRR0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJML6RKU0",
//					"attrs": {
//						"id": "runApp",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "380",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJML6RL80",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJML6RL81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HJML6RL82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJML84LR0",
//					"attrs": {
//						"id": "installApp",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "490",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJML84LU0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJML84LU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJMLAC9K0",
//									"attrs": {
//										"id": "RunApp",
//										"label": "New AI Seg",
//										"x": "370",
//										"y": "490",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJMLAC9O0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HJML84LU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HJMLAC9K0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJMR6QK00",
//					"attrs": {
//						"id": "textOut",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "590",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJMR768V0",
//							"attrs": {
//								"text": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJMR768V1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HJMR768V2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJMR8M8P0",
//					"attrs": {
//						"id": "clearLine",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "670",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJMR8SAN0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJMR8SAN1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HJMR8SAN2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJNAUU6F0",
//					"attrs": {
//						"id": "updateApp",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "760",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJNAUU6I0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HJNAUU6I1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HJNAUU6I2",
//									"attrs": {
//										"id": "Show DoUpdate",
//										"label": "New AI Seg",
//										"x": "360",
//										"y": "760",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "doUpdate",
//										"outlet": {
//											"jaxId": "1HJNAUU6I3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HJNAUU6F1"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HJNAUU6F1",
//									"attrs": {
//										"id": "Install App",
//										"label": "New AI Seg",
//										"x": "610",
//										"y": "760",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HJNAUU6I4",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HJNAUU6I5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HJNAUU6I2"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HJLN4Q636",
//			"attrs": {
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HJLNE3AN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HJLNE3AN1",
//							"attrs": {
//								"1HJNA6O4I0": {
//									"type": "facetag",
//									"def": "FaceTimeTag",
//									"jaxId": "1HJNA6UFB0",
//									"attrs": {
//										"time": "500",
//										"preFunc": "false",
//										"faceFunc": "false"
//									}
//								},
//								"1HJNACKG70": {
//									"type": "facetag",
//									"def": "FaceTimeTag",
//									"jaxId": "1HJNACM5J0",
//									"attrs": {
//										"time": "1500",
//										"preFunc": "false",
//										"faceFunc": "false"
//									}
//								}
//							}
//						}
//					}
//				},
//				"update": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HJMEFB140",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HJMEFB141",
//							"attrs": {}
//						}
//					}
//				},
//				"install": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HJNAK3DV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HJNALD140",
//							"attrs": {}
//						}
//					}
//				},
//				"doUpdate": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HJNANB7B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HJNAOQL90",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HJLN4Q637",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1HJLN4Q620",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HJLN4Q638",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HJLN55A30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJLN5P8Q0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJLN5P8Q1",
//									"attrs": {
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNACTSP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNACTSP1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD141",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD142",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJLN5P8Q2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJLN5P8Q3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HJN9735P0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJN9H8AN0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "40%-150",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "500",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": "Powered by AI2Apps",
//										"font": "",
//										"fontSize": "#txtSize.midPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJN9H8AN1",
//									"attrs": {
//										"1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNA3GLB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNA3GLB1",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJLNE3AN0",
//											"faceTagName": "init"
//										},
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNA7V712",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNA7V713",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": [
//														{
//															"type": "hudani",
//															"def": "In",
//															"jaxId": "1HJNA7V714",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNA7V715",
//																	"attrs": {
//																		"type": "in",
//																		"time": "300",
//																		"alpha": "0"
//																	}
//																},
//																"codes": "false"
//															}
//														}
//													]
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD143",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD144",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJN9H8AN2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJN9H8AN3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HJLN5VUP0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJLNB8QE0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxLogo",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "40%",
//										"w": "300",
//										"h": "300",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/aalogo.svg\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJLNB8QE1",
//									"attrs": {
//										"1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJMEGASM2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJMEGASM3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": [
//														{
//															"type": "hudani",
//															"def": "In",
//															"jaxId": "1HJNA3GLB2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNA3GLB3",
//																	"attrs": {
//																		"type": "in",
//																		"time": "500",
//																		"alpha": "0"
//																	}
//																},
//																"codes": "false"
//															}
//														}
//													]
//												}
//											},
//											"faceTagId": "1HJLNE3AN0",
//											"faceTagName": "init"
//										},
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNACTSP6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNACTSP7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD145",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD146",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJLNB8QE2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJLNB8QE3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HJLN9OC20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJLNB8QE4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-5",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "www.ai2apps.com",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJLNB8QE5",
//									"attrs": {
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNACTSP10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNACTSP11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD147",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD148",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJLNB8QE6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJLNB8QE7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HJLODRH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJLOGD7F0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxUpdate",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "40%+150",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "500",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HJLOF2DU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJLOGD7F1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "New version available, update? ",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HJLOGD7G0",
//													"attrs": {
//														"1HJNA6UFB0@1HJLNE3AN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNACTSP14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNACTSP15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//															"faceTagName": "500@init"
//														},
//														"1HJNAK3DV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNALD149",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNALD1410",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNAK3DV0",
//															"faceTagName": "install"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HJLOGD7G1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HJLOGD7G2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HJLOHV9L0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJLOJNBC0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxButtons",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HJLOIS2L0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HJLOJJ480",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Cancel",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HJLOJJ481",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",100,24,\"Cancel\",false,\"\")",
//																		"id": "BtnCancel",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HJLOJJ490",
//																	"attrs": {
//																		"1HJNA6UFB0@1HJLNE3AN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNACTSP18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNACTSP19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//																			"faceTagName": "500@init"
//																		},
//																		"1HJNAK3DV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNALD1411",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNALD1412",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNAK3DV0",
//																			"faceTagName": "install"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HJLOJJ491",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HJMFGQ7J0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HJMFGQ7K0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HJML6RKU0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HJLOJJ492",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HJLOJJ493",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HJLOJJ494",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HJLOJKSH0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HJLOJKSH1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Update",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HJLOJKSH2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,24,\"Update\",false,\"\")",
//																		"id": "BtnUpdate",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HJLOJKSH3",
//																	"attrs": {
//																		"1HJNA6UFB0@1HJLNE3AN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNACTSP22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNACTSP23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//																			"faceTagName": "500@init"
//																		},
//																		"1HJNAK3DV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNALD1413",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNALD1414",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNAK3DV0",
//																			"faceTagName": "install"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HJLOJKSH4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HJNB0AJP0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HJNB0IK50",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HJNAUU6F0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HJLOJKSH5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HJLOJKSH6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HJLOJKSH7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HJLOJMKO0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HJLOJMKO1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Skip Version",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HJLOJMKO2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,24,\"Skip Version\",false,\"\")",
//																		"id": "BtnSkip",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HJLOJMKP0",
//																	"attrs": {
//																		"1HJNA6UFB0@1HJLNE3AN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNACTSP26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNACTSP27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//																			"faceTagName": "500@init"
//																		},
//																		"1HJNAK3DV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJNALD1415",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJNALD1416",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HJNAK3DV0",
//																			"faceTagName": "install"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HJLOJMKP1",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HJMG0SS00",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HJMG0SS01",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HJMFUP2O0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HJLOJMKP2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HJLOJMKP3",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HJLOJMKP4",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HJLOJNBC1",
//													"attrs": {
//														"1HJNA6UFB0@1HJLNE3AN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNACTSP30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNACTSP31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//															"faceTagName": "500@init"
//														},
//														"1HJNAK3DV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNALD1417",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNALD150",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNAK3DV0",
//															"faceTagName": "install"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HJLOJNBC2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HJLOJNBC3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HJLOGD7G3",
//									"attrs": {
//										"1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJMEGASM18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJMEGASM19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJLNE3AN0",
//											"faceTagName": "init"
//										},
//										"1HJMEFB140": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJMEN7JH16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJMEN7JH17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": [
//														{
//															"type": "hudani",
//															"def": "In",
//															"jaxId": "1HJMEN7JH18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJMEN7JH19",
//																	"attrs": {
//																		"type": "in",
//																		"time": "100",
//																		"alpha": "0",
//																		"dy": "50"
//																	}
//																},
//																"codes": "false"
//															}
//														}
//													]
//												}
//											},
//											"faceTagId": "1HJMEFB140",
//											"faceTagName": "update"
//										},
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNACTSP34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNACTSP35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD151",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD152",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										},
//										"1HJNANB7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNAS5T218",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNAS5T219",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNANB7B0",
//											"faceTagName": "doUpdate"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJLOGD7G4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJLOGD7G5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HJN8QFJT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJN8URTH16",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxState",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "40%+150",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "500",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HJN8S3OQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJN8S3OQ1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtState",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Starting Application",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HJN8S3OR0",
//													"attrs": {
//														"1HJLNE3AN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJN8S3OR1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJN8S3OR2",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "启动应用程序",
//																			"localize": {
//																				"EN": "Starting Application",
//																				"CN": "启动应用程序"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJLNE3AN0",
//															"faceTagName": "init"
//														},
//														"1HJNA6UFB0@1HJLNE3AN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNACTSP38",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNACTSP39",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//															"faceTagName": "500@init"
//														},
//														"1HJNAK3DV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNALD153",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNALD154",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "正在安装应用程序",
//																			"localize": {
//																				"EN": "Installing application",
//																				"CN": "正在安装应用程序"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNAK3DV0",
//															"faceTagName": "install"
//														},
//														"1HJNANB7B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNAOQLA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNAOQLA1",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "正在升级应用程序......",
//																			"localize": {
//																				"EN": "Updating Application...",
//																				"CN": "正在升级应用程序......"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNANB7B0",
//															"faceTagName": "doUpdate"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HJN8S3OR5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HJN8S3OR6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HJN8VQQN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJN93AGT0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLog",
//														"position": "Absolute",
//														"x": "0",
//														"y": "30",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HJN93AGT1",
//													"attrs": {
//														"1HJNA6UFB0@1HJLNE3AN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNACTSP42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNACTSP43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//															"faceTagName": "500@init"
//														},
//														"1HJNAK3DV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJNALD155",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJNALD156",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HJNAK3DV0",
//															"faceTagName": "install"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HJN93AGT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HJN93AGT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HJN8URTH17",
//									"attrs": {
//										"1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJN8URTH18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJN8URTH19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJLNE3AN0",
//											"faceTagName": "init"
//										},
//										"1HJMEFB140": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJN8URTH20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJN8URTH21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJMEFB140",
//											"faceTagName": "update"
//										},
//										"1HJNA6UFB0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNA7V7126",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNA7V7127",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//											"faceTagName": "500@init"
//										},
//										"1HJNACM5J0@1HJLNE3AN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNACTSP46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNACTSP47",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNACM5J0@1HJLNE3AN0",
//											"faceTagName": "1500@init"
//										},
//										"1HJNAK3DV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNALD157",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNALD158",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNAK3DV0",
//											"faceTagName": "install"
//										},
//										"1HJNANB7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJNAS5T222",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJNAS5T223",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HJNANB7B0",
//											"faceTagName": "doUpdate"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HJN8URTH22",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJN8URTH23",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HJLN4Q639",
//					"attrs": {
//						"1HJNA6UFB0@1HJLNE3AN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HJNACTSP48",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJNACTSP49",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HJNA6UFB0@1HJLNE3AN0",
//							"faceTagName": "500@init"
//						},
//						"1HJNAK3DV0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HJNALD159",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJNALD1510",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HJNAK3DV0",
//							"faceTagName": "install"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HJLN4Q6310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HJLN4Q6311",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HJLN4Q6312",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}