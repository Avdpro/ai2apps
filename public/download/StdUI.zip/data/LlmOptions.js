//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IIKEVV3R0StartDoc*/
/*}#1IIKEVV3R0StartDoc*/
let LlmOptions={
	name:"LlmOptions",//1IIKEVV3R2
	type:"object",
	label:undefined,
	properties:{
		platform:{
			name:"platform",type:"string",
		},
		model:{
			name:"model",type:"string",
		},
		temperature:{
			name:"temperature",type:"string",
		},
		max_tokens:{
			name:"max_tokens",type:"number",
		},
		/*#{1IIKEVV3R2MoreProperties*/
		/*}#1IIKEVV3R2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IIKEVV3R2MoreFunctions*/
	/*}#1IIKEVV3R2MoreFunctions*/
};
VFACT.regUITemplate("1IIKEVV3R2",LlmOptions);
VFACT.regUITemplate("LlmOptions",LlmOptions);
/*#{1IIKEVV3R2MoreCodes*/
/*}#1IIKEVV3R2MoreCodes*/

/*#{1IIKEVV3R0EndDoc*/
/*}#1IIKEVV3R0EndDoc*/

export{LlmOptions};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IIKEVV3R0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IIKEVV3R1",
//			"attrs": {
//				"LlmOptions": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IIKEVV3R2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IIKEVV3R3",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IIKEVV3R4",
//							"attrs": {
//								"platform": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIKFFG530",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"model": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIKFFG531",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"temperature": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIKFFG532",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"max_tokens": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIKFFG533",
//									"attrs": {
//										"type": "number"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IIKEVV3R5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}