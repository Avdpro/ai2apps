//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I8SOT99O0StartDoc*/
const $ln=VFACT.lanCode;
/*}#1I8SOT99O0StartDoc*/
let FileInfo={
	name:"FileInfo",//1I8SOT99O2
	type:"object",
	label:undefined,
	properties:{
		size:{
			name:"size",type:"int",
			label:(($ln==="CN")?("文件尺寸"):("File size:")),
		},
		createTime:{
			name:"createTime",type:"string",
			label:(($ln==="CN")?("创建时间:"):("Creation time:")),
		},
		modified:{
			name:"modified",type:"string",
			label:(($ln==="CN")?("是否有变动:"):("Change from base:")),
		},
		modifyTime:{
			name:"modifyTime",type:"string",
			label:(($ln==="CN")?("修改时间:"):("Modified time:")),
		},
		/*#{1I8SOT99O2MoreProperties*/
		/*}#1I8SOT99O2MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I8SOT99O2MoreFunctions*/
	/*}#1I8SOT99O2MoreFunctions*/
};
VFACT.regUITemplate("1I8SOT99O2",FileInfo);
VFACT.regUITemplate("FileInfo",FileInfo);
/*#{1I8SOT99O2MoreCodes*/
/*}#1I8SOT99O2MoreCodes*/
let FolderInfo={
	name:"FolderInfo",//1I8SPCS740
	type:"object",
	label:undefined,
	properties:{
		entryNum:{
			name:"entryNum",type:"int",
			label:(($ln==="CN")?("总计项目:"):("Total items:")),
		},
		size:{
			name:"size",type:"int",
			label:(($ln==="CN")?("总计尺寸:"):("Total size:")),
		},
		createTime:{
			name:"createTime",type:"string",
			label:(($ln==="CN")?("创建时间:"):("Create time:")),
		},
		modifyTime:{
			name:"modifyTime",type:"string",
			label:(($ln==="CN")?("修改时间:"):("Modify time:")),
		},
		/*#{1I8SPCS740MoreProperties*/
		/*}#1I8SPCS740MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I8SPCS740MoreFunctions*/
	/*}#1I8SPCS740MoreFunctions*/
};
VFACT.regUITemplate("1I8SPCS740",FolderInfo);
VFACT.regUITemplate("FolderInfo",FolderInfo);
/*#{1I8SPCS740MoreCodes*/
/*}#1I8SPCS740MoreCodes*/
let CloudInfo={
	name:"CloudInfo",//1I8SV7II70
	type:"object",
	label:undefined,
	properties:{
		diskId:{
			name:"diskId",type:"string",
		},
		version:{
			name:"version",type:"string",
		},
		versionIdx:{
			name:"versionIdx",type:"string",
		},
		/*#{1I8SV7II70MoreProperties*/
		/*}#1I8SV7II70MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I8SV7II70MoreFunctions*/
	/*}#1I8SV7II70MoreFunctions*/
};
VFACT.regUITemplate("1I8SV7II70",CloudInfo);
VFACT.regUITemplate("CloudInfo",CloudInfo);
/*#{1I8SV7II70MoreCodes*/
/*}#1I8SV7II70MoreCodes*/

/*#{1I8SOT99O0EndDoc*/
/*}#1I8SOT99O0EndDoc*/

export{FileInfo,FolderInfo,CloudInfo};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1I8SOT99O0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I8SOT99O1",
//			"attrs": {
//				"FileInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I8SOT99O2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I8SOT99P0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I8SOT99P1",
//							"attrs": {
//								"size": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SP4RSK0",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "File size:",
//											"localize": {
//												"EN": "File size:",
//												"CN": "文件尺寸"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"createTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SUS16T0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Creation time:",
//											"localize": {
//												"EN": "Creation time:",
//												"CN": "创建时间:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"modified": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SP4RSL1",
//									"attrs": {
//										"type": "String",
//										"label": {
//											"type": "string",
//											"valText": "Change from base:",
//											"localize": {
//												"EN": "Change from base:",
//												"CN": "是否有变动:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"modifyTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SP4RSL0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Modified time:",
//											"localize": {
//												"EN": "Modified time:",
//												"CN": "修改时间:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I8SOT99P2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"FolderInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I8SPCS740",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I8SPGIVT0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I8SPGIVT1",
//							"attrs": {
//								"entryNum": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SPGIVT3",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Total items:",
//											"localize": {
//												"EN": "Total items:",
//												"CN": "总计项目:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"size": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SPGIVT2",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Total size:",
//											"localize": {
//												"EN": "Total size:",
//												"CN": "总计尺寸:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"createTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SV09IK0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Create time:",
//											"localize": {
//												"EN": "Create time:",
//												"CN": "创建时间:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"modifyTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SPGIVT4",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Modify time:",
//											"localize": {
//												"EN": "Modify time:",
//												"CN": "修改时间:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I8SPGIVT5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"CloudInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I8SV7II70",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I8SV7LOJ0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I8SV7LOJ1",
//							"attrs": {
//								"diskId": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SVCH3E0",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"version": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SVCH3E1",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"versionIdx": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I8SVCH3E2",
//									"attrs": {
//										"type": "string"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I8SV7LOJ2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}