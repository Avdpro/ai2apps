//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
/*#{1HQTT32780StartDoc*/
/*}#1HQTT32780StartDoc*/
//----------------------------------------------------------------------------
/*#{1HQTT32790Constructor+*/
let AppData=function(){
/*}#1HQTT32790Constructor+*/
	/*#{1HQTT32790PreConstruct*/
	/*}#1HQTT32790PreConstruct*/
	/*#{1HQTT32790Properties+*/
	/*}#1HQTT32790Properties+*/
	/*#{1HQTT32790PostConstruct*/
	/*}#1HQTT32790PostConstruct*/
};
AppData.prototype={};
let _AppData=AppData.prototype;
/*#{1HQTT32790ExCodes*/
/*}#1HQTT32790ExCodes*/


/*#{1HQTT32780EndDoc*/
/*}#1HQTT32780EndDoc*/

export{AppData};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1HQTT32780",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HQTT32781",
//			"attrs": {
//				"AppData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HQTT32790",
//					"attrs": {
//						"exportType": "Data Class",
//						"constructArgs": {
//							"jaxId": "1HQTT327A0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HQTT327A1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HQTT327A2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}