//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I9AJEVK70StartDoc*/
const $ln=VFACT.lanCode;
/*}#1I9AJEVK70StartDoc*/
let CloudInfo={
	name:"CloudInfo",//1I9AJEVK72
	type:"object",
	label:undefined,
	properties:{
		/*#{1I9AJEVK72MoreProperties*/
		/*}#1I9AJEVK72MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9AJEVK72MoreFunctions*/
	/*}#1I9AJEVK72MoreFunctions*/
};
VFACT.regUITemplate("1I9AJEVK72",CloudInfo);
VFACT.regUITemplate("CloudInfo",CloudInfo);
/*#{1I9AJEVK72MoreCodes*/
/*}#1I9AJEVK72MoreCodes*/
let DiskInfoLocal={
	name:"DiskInfoLocal",//1I9AJH5MR0
	type:"object",
	label:undefined,
	properties:{
		version:{
			name:"version",type:"string",
			label:("Version:"),
		},
		versionIdx:{
			name:"versionIdx",type:"int",
			label:(($ln==="CN")?("版本序号:"):("Version index:")),
		},
		/*#{1I9AJH5MR0MoreProperties*/
		/*}#1I9AJH5MR0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9AJH5MR0MoreFunctions*/
	/*}#1I9AJH5MR0MoreFunctions*/
};
VFACT.regUITemplate("1I9AJH5MR0",DiskInfoLocal);
VFACT.regUITemplate("DiskInfoLocal",DiskInfoLocal);
/*#{1I9AJH5MR0MoreCodes*/
/*}#1I9AJH5MR0MoreCodes*/
let DiskInfoCloud={
	name:"DiskInfoCloud",//1I9AJHCPI0
	type:"object",
	label:undefined,
	properties:{
		version:{
			name:"version",type:"string",
			label:(($ln==="CN")?("版本:"):("Version:")),
		},
		versionIdx:{
			name:"versionIdx",type:"int",
			label:(($ln==="CN")?("版本序号:"):("Version index:")),
		},
		/*#{1I9AJHCPI0MoreProperties*/
		/*}#1I9AJHCPI0MoreProperties*/
	},
	layout:[
		"version","versionIdx",{id:"BtnCommit",type:"button",text:(($ln==="CN")?("下载云端更新"):("Pull cloud changes")),w:200, outline:true, style:"front",action:"Update"}
	],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9AJHCPI0MoreFunctions*/
	/*}#1I9AJHCPI0MoreFunctions*/
};
VFACT.regUITemplate("1I9AJHCPI0",DiskInfoCloud);
VFACT.regUITemplate("DiskInfoCloud",DiskInfoCloud);
/*#{1I9AJHCPI0MoreCodes*/
/*}#1I9AJHCPI0MoreCodes*/
let DiskInfoChange={
	name:"DiskInfoChange",//1I9AJHN7R0
	type:"object",
	label:undefined,
	properties:{
		new:{
			name:"new",type:"int",
			label:(($ln==="CN")?("新项目:"):("New items:")),
		},
		change:{
			name:"change",type:"int",
			label:(($ln==="CN")?("已修改项目:"):("Modified items:")),
		},
		delete:{
			name:"delete",type:"int",
			label:(($ln==="CN")?("删除的项目:"):("Deleted items:")),
		},
		conflict:{
			name:"conflict",type:"int",
			label:(($ln==="CN")?("冲突的项目:"):("Conflict items:")),
		},
		/*#{1I9AJHN7R0MoreProperties*/
		/*}#1I9AJHN7R0MoreProperties*/
	},
	layout:[
		"new","change","delete","confilict",{type:"button",text:(($ln==="CN")?("查看/提交更改"):/*EN*/("View / Commit changes")),w:200,outline:true,style:"front",action:"Commit"}
	],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9AJHN7R0MoreFunctions*/
	/*}#1I9AJHN7R0MoreFunctions*/
};
VFACT.regUITemplate("1I9AJHN7R0",DiskInfoChange);
VFACT.regUITemplate("DiskInfoChange",DiskInfoChange);
/*#{1I9AJHN7R0MoreCodes*/
/*}#1I9AJHN7R0MoreCodes*/
let DvtCloudInfo={
	name:"DvtCloudInfo",//1I9AJIMOB0
	type:"object",
	label:undefined,
	properties:{
		diskId:{
			name:"diskId",type:"string",
			label:(($ln==="CN")?("云盘(repo) Id："):("Disk(repo) Id:")),
		},
		local:{
			name:"local",type:"object",
			label:"Local version:",
			class:"1I9AJH5MR0",
		},
		cloud:{
			name:"cloud",type:"object",
			label:"Cloud version:",
			class:"1I9AJHCPI0",
		},
		change:{
			name:"change",type:"object",
			label:"Local changes:",
			class:"1I9AJHN7R0",
		},
		/*#{1I9AJIMOB0MoreProperties*/
		/*}#1I9AJIMOB0MoreProperties*/
	},
	layout:[
		{type:"seg",text:(($ln==="CN")?("版本控制"):/*EN*/("Version Control")),align:1,size:16,color:appCfg.color.fontBody},5,"diskId",5,{id:"NoChange",type:"seg",text:"No local changes",align:1},"change","local","cloud"
	],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9AJIMOB0MoreFunctions*/
	OnShow(dv,data){
		if(data.change){
			dv.hideDecoLine("NoChange");
		}
		if(data.local && ((data.cloud &&data.local.versionIdx===data.cloud.versionIdx)|| !data.cloud)){
			dv.hideDecoLine("cloud.BtnCommit");
		}
	}
	/*}#1I9AJIMOB0MoreFunctions*/
};
VFACT.regUITemplate("1I9AJIMOB0",DvtCloudInfo);
VFACT.regUITemplate("DvtCloudInfo",DvtCloudInfo);
/*#{1I9AJIMOB0MoreCodes*/
/*}#1I9AJIMOB0MoreCodes*/
let DvtNoRepo={
	name:"DvtNoRepo",//1I9CGSNB20
	type:"object",
	label:undefined,
	properties:{
		/*#{1I9CGSNB20MoreProperties*/
		/*}#1I9CGSNB20MoreProperties*/
	},
	layout:[
		{type:"seg",text:(($ln==="CN")?("无版本控制"):/*EN*/("No Version Control")),align:1,size:16,color:appCfg.color.fontBody},10,{type:"button",text:(($ln==="CN")?("加入云版本控制"):/*EN*/("Check in Cloud Repo")),w:200,outline:true,style:"front",action:"CheckIn"}
	],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9CGSNB20MoreFunctions*/
	/*}#1I9CGSNB20MoreFunctions*/
};
VFACT.regUITemplate("1I9CGSNB20",DvtNoRepo);
VFACT.regUITemplate("DvtNoRepo",DvtNoRepo);
/*#{1I9CGSNB20MoreCodes*/
/*}#1I9CGSNB20MoreCodes*/
let DvtCommit={
	name:"DvtCommit",//1I9CVEA2B0
	type:"object",
	label:undefined,
	properties:{
		tag:{
			name:"tag",type:"string",
			label:(($ln==="CN")?("版本标记:"):("Version tag:")),
		},
		note:{
			name:"note",type:"string",
			label:(($ln==="CN")?("提交说明："):("Commit note:")),
			uiMode:"Note",
		},
		/*#{1I9CVEA2B0MoreProperties*/
		/*}#1I9CVEA2B0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I9CVEA2B0MoreFunctions*/
	/*}#1I9CVEA2B0MoreFunctions*/
};
VFACT.regUITemplate("1I9CVEA2B0",DvtCommit);
VFACT.regUITemplate("DvtCommit",DvtCommit);
/*#{1I9CVEA2B0MoreCodes*/
/*}#1I9CVEA2B0MoreCodes*/

/*#{1I9AJEVK70EndDoc*/
/*}#1I9AJEVK70EndDoc*/

export{CloudInfo,DiskInfoLocal,DiskInfoCloud,DiskInfoChange,DvtCloudInfo,DvtNoRepo,DvtCommit};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1I9AJEVK70",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I9AJEVK71",
//			"attrs": {
//				"CloudInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9AJEVK72",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9AJEVK73",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9AJEVK74",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I9AJEVK75",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"DiskInfoLocal": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9AJH5MR0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9ALOPN10",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9ALOPN11",
//							"attrs": {
//								"version": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN13",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Version:",
//											"localize": {
//												"EN": "Version:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"versionIdx": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN14",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Version index:",
//											"localize": {
//												"EN": "Version index:",
//												"CN": "版本序号:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I9ALOPN15",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"DiskInfoCloud": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9AJHCPI0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9ALOPN16",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9ALOPN17",
//							"attrs": {
//								"version": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN18",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Version:",
//											"localize": {
//												"EN": "Version:",
//												"CN": "版本:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"versionIdx": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN19",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Version index:",
//											"localize": {
//												"EN": "Version index:",
//												"CN": "版本序号:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I9ALOPN110",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "version"
//								},
//								{
//									"type": "auto",
//									"valText": "versionIdx"
//								},
//								{
//									"type": "auto",
//									"valText": "#{id:\"BtnCommit\",type:\"button\",text:(($ln===\"CN\")?(\"下载云端更新\"):(\"Pull cloud changes\")),w:200, outline:true, style:\"front\",action:\"Update\"}"
//								}
//							]
//						}
//					},
//					"mockups": {}
//				},
//				"DiskInfoChange": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9AJHN7R0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9ALOPN111",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9ALOPN112",
//							"attrs": {
//								"new": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN114",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "New items:",
//											"localize": {
//												"EN": "New items:",
//												"CN": "新项目:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"change": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN113",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Modified items:",
//											"localize": {
//												"EN": "Modified items:",
//												"CN": "已修改项目:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"delete": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN115",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Deleted items:",
//											"localize": {
//												"EN": "Deleted items:",
//												"CN": "删除的项目:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"conflict": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9ALOPN116",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Conflict items:",
//											"localize": {
//												"EN": "Conflict items:",
//												"CN": "冲突的项目:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I9ALOPN117",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "#\"new\""
//								},
//								{
//									"type": "auto",
//									"valText": "change"
//								},
//								{
//									"type": "auto",
//									"valText": "delete"
//								},
//								{
//									"type": "auto",
//									"valText": "confilict"
//								},
//								{
//									"type": "auto",
//									"valText": "#{type:\"button\",text:(($ln===\"CN\")?(\"查看/提交更改\"):/*EN*/(\"View / Commit changes\")),w:200,outline:true,style:\"front\",action:\"Commit\"}"
//								}
//							]
//						}
//					},
//					"mockups": {}
//				},
//				"DvtCloudInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9AJIMOB0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9ALOPN118",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9ALOPN119",
//							"attrs": {
//								"diskId": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9CCMSVO0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Disk(repo) Id:",
//											"localize": {
//												"EN": "Disk(repo) Id:",
//												"CN": "云盘(repo) Id："
//											},
//											"localizable": true
//										}
//									}
//								},
//								"local": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I9AM8DM10",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I9AJH5MR0\"",
//										"label": "Local version:"
//									}
//								},
//								"cloud": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I9AM8DM11",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I9AJHCPI0\"",
//										"label": "Cloud version:"
//									}
//								},
//								"change": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I9AM8DM12",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I9AJHN7R0\"",
//										"label": "Local changes:"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I9ALOPN120",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "#{type:\"seg\",text:(($ln===\"CN\")?(\"版本控制\"):/*EN*/(\"Version Control\")),align:1,size:16,color:appCfg.color.fontBody}"
//								},
//								{
//									"type": "auto",
//									"valText": "5"
//								},
//								{
//									"type": "auto",
//									"valText": "diskId"
//								},
//								{
//									"type": "auto",
//									"valText": "5"
//								},
//								{
//									"type": "auto",
//									"valText": "#{id:\"NoChange\",type:\"seg\",text:\"No local changes\",align:1}"
//								},
//								{
//									"type": "auto",
//									"valText": "change"
//								},
//								{
//									"type": "auto",
//									"valText": "local"
//								},
//								{
//									"type": "auto",
//									"valText": "cloud"
//								}
//							]
//						}
//					},
//					"mockups": {}
//				},
//				"DvtNoRepo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9CGSNB20",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9CGSPBG0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9CGSPBG1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I9CGSPBG2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "#{type:\"seg\",text:(($ln===\"CN\")?(\"无版本控制\"):/*EN*/(\"No Version Control\")),align:1,size:16,color:appCfg.color.fontBody}"
//								},
//								{
//									"type": "auto",
//									"valText": "10"
//								},
//								{
//									"type": "auto",
//									"valText": "#{type:\"button\",text:(($ln===\"CN\")?(\"加入云版本控制\"):/*EN*/(\"Check in Cloud Repo\")),w:200,outline:true,style:\"front\",action:\"CheckIn\"}"
//								}
//							]
//						}
//					},
//					"mockups": {}
//				},
//				"DvtCommit": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I9CVEA2B0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I9CVJ5BN0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I9CVJ5BN1",
//							"attrs": {
//								"tag": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9CVJ5BN2",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Version tag:",
//											"localize": {
//												"EN": "Version tag:",
//												"CN": "版本标记:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"note": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I9CVJ5BN3",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Commit note:",
//											"localize": {
//												"EN": "Commit note:",
//												"CN": "提交说明："
//											},
//											"localizable": true
//										},
//										"uiMode": "Note"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I9CVJ5BN4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}