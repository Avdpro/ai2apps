//Auto genterated by Cody
import {VFACT} from "/@vfact";
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1GGJKJ2SR0;"
/*#{StartDoc*/
/*}#StartDoc*/
let darkMode=false;
let colors={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1]
};
darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;
VFACT.darkMode=darkMode;
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
/*#{StartObj*/
/*}#StartObj*/
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1GGJKJ2SQ0"
	"darkMode":darkMode,"version":"0.0.1",
	"txtSize":{
		"small":12,"mid":16,"big":20,"smallPlus":14,"midPlus":18,"bigPlus":25,"large":30,"largePlus":35,"huge":40,"hugePlus":50
	},
	"size":{
		"menuLineH":24
	},
	"color":{
		"body":darkMode?[50,50,53,1]:[255,255,255,1.00],"primary":colors.primary,"secondary":colors.secondary,"success":colors.success,"warning":colors.warning,
		"front":darkMode?[255,255,255,1]:[0,0,0,1.00],"error":colors.error,"fontBody":darkMode?[255,255,255,1]:[0,0,0,1.00],"fontBodySub":darkMode?[240,240,240,1.00]:[80,80,80,1.00],
		"fontBodyLit":darkMode?[120,120,120,1]:[180,180,180,1.00],"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors.primary,80],"fontPrimaryLit":[...colors.primary,40],
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors.secondary,80.00],"fontSecondaryLit":[...colors.secondary,40.00],"fontSuccess":[255,255,255,1],
		"fontSuccessSub":[...colors.success,80.00],"fontSuccessLit":[...colors.success,40.00],"fontWarning":[255,255,255,1],"fontWarningSub":[...colors.warning,80],
		"fontWarningLit":[...colors.warning,40],"fontError":[255,255,255,1],"fontErrorSub":[...colors.error,80],"fontErrorLit":[...colors.error,40],"fontFront":darkMode?[0,0,0,1]:[255,255,255,1.00],
		"fontFrontSub":darkMode?[80,80,80,1]:[240,240,240,1.00],"fontFrontLit":darkMode?[240,240,240,1]:[80,80,80,1.00],"lineBody":darkMode?[255,255,255,1]:[0,0,0,1.00],
		"lineBodySub":darkMode?[240,240,240,1.00]:[80,80,80,1.00],"lineBodyLit":darkMode?[120,120,120,1]:[180,180,180,1.00],"itemOver":darkMode?[255,255,255,0.1]:[0,0,0,0.1],
		"itemDown":darkMode?[255,255,255,0.4]:[0,0,0,0.2],"itemFocus":darkMode?[...colors.primary,-20]:[...colors.primary,80],"itemGray":darkMode?[80,80,80,1]:[200,200,200,1.00],
		"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))","subFocus":darkMode?"linear-gradient(to right, rgba(250,250,250,0.2), 50%, rgba(250,250,250,0.05))":"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))",
		"menuBG":darkMode?[12,12,12,1]:[243,243,242,1.00]
	},
	"sharedAssets":"/~/-tabos/shared/assets",
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.lanCode=VFACT.lanCode===null?"EN":(VFACT.lanCode||"EN");
VFACT.lanCode=appCfg.lanCode;
if(!VFACT.appCfg){
	VFACT.appCfg=appCfg;
	window.jaxAppCfg=appCfg;
}
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=VFACT.appCfg||window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};

/*#{EndDoc*/
/*}#EndDoc*/

export{appCfg};
/*Cody Project Doc*/
//{
//	"jaxId": "1GGJKJ2SR0",
//	"attrs": {
//		"localVars": {
//			"jaxId": "1GGJKJ2SR1",
//			"attrs": {
//				"darkMode": "false",
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJM2JI80",
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKJ2SR2",
//			"attrs": {
//				"appCfg": {
//					"jaxId": "1GGJKJ2SQ0",
//					"attrs": {
//						"darkMode": "#darkMode",
//						"version": "0.0.1",
//						"txtSize": {
//							"jaxId": "1GGJKJ2SR3",
//							"attrs": {
//								"small": "12",
//								"mid": "16",
//								"big": "20",
//								"smallPlus": {
//									"type": "int",
//									"valText": "14"
//								},
//								"midPlus": {
//									"type": "int",
//									"valText": "18"
//								},
//								"bigPlus": {
//									"type": "int",
//									"valText": "25"
//								},
//								"large": {
//									"type": "int",
//									"valText": "30"
//								},
//								"largePlus": {
//									"type": "int",
//									"valText": "35"
//								},
//								"huge": {
//									"type": "int",
//									"valText": "40"
//								},
//								"hugePlus": {
//									"type": "int",
//									"valText": "50"
//								}
//							}
//						},
//						"size": {
//							"jaxId": "1GGJKJ2SR4",
//							"attrs": {
//								"menuLineH": {
//									"type": "int",
//									"valText": "24"
//								}
//							}
//						},
//						"color": {
//							"jaxId": "1GGJKJ2SR5",
//							"attrs": {
//								"body": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[50,50,53,1]:[255,255,255,1.00]"
//								},
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"front": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,40]"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80.00]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,40.00]"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80.00]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,40.00]"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,40]"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,40]"
//								},
//								"fontFront": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[0,0,0,1]:[255,255,255,1.00]"
//								},
//								"fontFrontSub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[240,240,240,1.00]"
//								},
//								"fontFrontLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1]:[80,80,80,1.00]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"itemOver": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.1]:[0,0,0,0.1]"
//								},
//								"itemDown": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.4]:[0,0,0,0.2]"
//								},
//								"itemFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[...colors.primary,-20]:[...colors.primary,80]"
//								},
//								"itemGray": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[200,200,200,1.00]"
//								},
//								"gntFocus": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))"
//								},
//								"subFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?\"linear-gradient(to right, rgba(250,250,250,0.2), 50%, rgba(250,250,250,0.05))\":\"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))\""
//								},
//								"menuBG": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[12,12,12,1]:[243,243,242,1.00]"
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "string",
//							"valText": "/~/-tabos/shared/assets"
//						}
//					}
//				}
//			}
//		}
//	}
//}