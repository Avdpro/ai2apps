//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HQ1EDCKJ0StartDoc*/
/*}#1HQ1EDCKJ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLStd=function(box,template,dataObj,property,opts,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxIcon,txtLabel,txtValue,btnMenu,edValue,btnLongEdit,txtError;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let value=dataObj[property];
	let pptTemplate=template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value));
	let edit=true;
	let icon=pptTemplate.icon;
	let labelLine=!!opts.labelLine;
	let description=edit?pptTemplate.desc:null;
	let choices=pptTemplate.choices;
	let valueGap=choices?3:(opts.labelLine?10:3);
	let menuGap=opts.labelLine?6:3;
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":opts?(opts.lineHeight||25):25,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1F1DNF0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":opts?(opts.lineHeight-3):22,"h":opts?(opts.lineHeight-3):22,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-x",
				"itemsWrap":1,"itemsAlign":1,
				children:[
					{
						"hash":"1HQ1GMNN90",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":labelLine?"100%":"","h":"","minW":opts.labelWidth||0,"minH":"","maxW":"","maxH":"",
						"styleClass":"","color":opts.labelColor,"text":title||(pptTemplate.label?pptTemplate.label:(property+":")),"fontSize":opts?(opts.labelSize||12):14,
						"fontWeight":(opts?(opts.labelBold||false):false)?"bold":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HQ1GNGQ60",
						"type":"text","id":"TxtValue","position":"relative","x":0,"y":0,"w":"","h":"","margin":[opts.labelLine?2:0,0,0,opts.labelLine?10:3],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","color":opts.valueColor,"text":(value===undefined)?"":value,"fontSize":opts?(opts.valueSize||16):16,"fontWeight":(opts?(!!opts.valueBold):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"","alignH":2,"attached":!edit,"flex":(!!opts.valueRightAlign)&&(!opts.edit),
					},
					{
						"hash":"1HQ1K18GQ0",
						"type":BtnIcon("front",opts?(opts.valueSize?(opts.valueSize+4):20):20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative",
						"x":0,"y":0,"margin":[0,0,0,menuGap],"attached":(!!choices)&&(!!edit),
						"OnClick":function(event){
							/*#{1HR3FDKUS0FunctionBody*/
							self.showMenu();
							/*}#1HR3FDKUS0FunctionBody*/
						},
					},
					{
						"hash":"1HQ1HIHAP0",
						"type":"edit","id":"EdValue","position":"relative","x":0,"y":0,"w":80,"h":opts?(opts.valueSize?(opts.valueSize+4):20):20,"margin":[0,0,0,valueGap],
						"minW":50,"minH":"","maxW":pptTemplate.shortEdit?60:600,"maxH":"","styleClass":"","inputType":pptTemplate.inputType,"text":(value===undefined)?"":value,
						"placeHolder":(pptTemplate?(pptTemplate.placeHolder||(pptTemplate.required?"Required":"")):""),"color":[0,0,0],"background":[255,255,255,0],"fontSize":opts?(opts.valueSize||16):16,
						"outline":0,"border":[0,0,1,0],"borderColor":cfgColor["fontBody"],"flex":true,"attached":!!edit,"pattern":pptTemplate.inputPattern,
						"OnInput":function(){
							/*#{1HQ213AB70FunctionBody*/
							self.postCheck();
							box._OnEdit && box._OnEdit();
							/*}#1HQ213AB70FunctionBody*/
						},
						"OnKeyDown":function(event){
							/*#{1HQ21481P0FunctionBody*/
							if(event.key==="Enter"){
								if((!event.isComposing) &&(!event.shiftKey)){
									event.stopPropagation();
									event.preventDefault();
									self.commitEdit(edValue.text);
								}
							}else if(event.key==="Tab" && box.focusNextLine){
								if(event.isComposing){
									return;
								}
								event.stopPropagation();
								event.preventDefault();
								if(event.shiftKey && box.focusPreLine){
									box.focusPreLine(self);
								}else{
									box.focusNextLine(self);
								}
							}
							/*}#1HQ21481P0FunctionBody*/
						},
						"OnFocus":function(event){
							/*#{1IIHF7RT80FunctionBody*/
							/*}#1IIHF7RT80FunctionBody*/
						},
						"OnBlur":function(event){
							/*#{1IIHF84NH0FunctionBody*/
							/*}#1IIHF84NH0FunctionBody*/
						},
					},
					{
						"hash":"1IIHEHVQF0",
						"type":BtnIcon("front",opts?(opts.valueSize?(opts.valueSize+4):20):20,0,appCfg.sharedAssets+"/edit.svg",null),"id":"BtnLongEdit","position":"relative",
						"x":0,"y":0,"attached":!!opts.longEdit,
						"tip":(($ln==="CN")?("长文本编辑"):("Long edit")),
						"OnClick":function(event){
							/*#{1IIHFOH3R0FunctionBody*/
							self.longEdit();
							/*}#1IIHFOH3R0FunctionBody*/
						},
					},
					{
						"hash":"1I99T444J0",
						"type":"text","id":"TxtError","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","color":cfgColor["error"],"text":"error","fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","wrap":true,
					},
					{
						"hash":"1HQ1JKTFQ0",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":description,"fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","wrap":true,"attached":!!description,
					}
				],
				"OnMouseInOut":function(isIn,event){
					/*#{1IIHFD1O40FunctionBody*/
					if(btnLongEdit){
						if(isIn){
							btnLongEdit.display=1;
						}else{
							btnLongEdit.display=0;
						}
					}
					/*}#1IIHFD1O40FunctionBody*/
				},
			},
			{
				"hash":"1I9ATINRR0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["subFocus"],"attached":!!opts.gridLine,
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get $$property(){
			return property;
		},
		set $$property(p){
			return property=p;
		},
		template:pptTemplate,
		edit:edit,
		get $$value(){
			if(edValue){
				self.commitEdit(edValue.text);
			}
			return value;
		},
		set $$value(val){
			return self.commitEdit(val);
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
			"error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":cfgColor["error"]
				}
			},"!error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":opts.labelColor
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtValue=self.TxtValue;btnMenu=self.BtnMenu;edValue=self.EdValue;btnLongEdit=self.BtnLongEdit;txtError=self.TxtError;
			/*#{1HQ1EDCKJ1Create*/
			if(btnLongEdit){
				btnLongEdit.display=0;
			}
			self.updateValue();
			//self.postCheck();
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		let changed;
		switch(pptTemplate.type){
			case "auto":{
				let src=val;
				try{
					val=JSON.parse(src);
				}catch(err){
					val=src;
				}
				break;
			}
			case "integer":
			case "int":{
				val=parseInt(val);
				if(isNaN(val)){
					val=undefined;
					changed=true;
				}
				break;
			}
			case "float":
			case "real":
			case "double":
			case "number":{
				val=parseFloat(val);
				if(isNaN(val)){
					val=undefined;
					changed=true;
				}
				break;
			}
			case "string":{
				break;
			}
		}
		if(pptTemplate.checkValue){
			if(!pptTemplate.checkValue(val)){
				val=value;
			}
		}
		if(pptTemplate.choices && pptTemplate.rawEdit!==true){
			//TODO: Check val is in choices:
		}
		if(changed || val!==value){
			value=val;
			self.updateValue();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(){
		let item,items,choices,func;
		func=pptTemplate.getChoices;
		if(func){
			let editedObj;
			editedObj=box.getEditedVO();
			choices=(await func.call(editedObj,editedObj,pptTemplate.name,box))||pptTemplate.choices;
		}else{
			choices=pptTemplate.choices;
		}
		items=[];
		for(let ch of choices){
			if(typeof(ch)==="string"){
				items.push({text:ch,value:ch});
			}else{
				items.push(ch);
			}
		}
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,
			hud:btnMenu
		});
		if(!item){
			return;
		}
		self.commitEdit(item.value);
		box._OnEdit && box._OnEdit();
	}
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		value=dataObj[property];
		self.updateValue();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		switch(pptTemplate.type){
			case "auto":{
				let valText,valType;
				valType=typeof(value);
				switch(valType){
					case "string":
						valText=value;
						break;
					default:
						if(value===undefined){
							valText="";
						}else{
							valText=JSON.stringify(value);
						}
						break;
				}
				if(txtValue){
					txtValue.text=valText;
				}
				if(edValue){
					edValue.text=valText;
				}
				break;
			}
			default:
				if(txtValue){
					txtValue.text=(value===undefined)?"":value;
				}
				if(edValue){
					edValue.text=(value===undefined)?"":value;
				}
				break;
		}
		self.postCheck();
	};
	
	//------------------------------------------------------------------------
	cssVO.postCheck=function(){
		if(edValue){
			if(pptTemplate.required){
				if(!edValue.text){
					self.showFace("error");
				}else{
					self.showFace("!error");
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focus=function(){
		if(edValue){
			edValue.focus();
			return true;
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	cssVO.showErrorTip=function(tip){
		if(tip){
			txtError.text=tip;
			txtError.display=true;
		}
		
		self.showFace("error");
	};
	
	//------------------------------------------------------------------------
	cssVO.clearErrorTip=function(){
		txtError.display=false;
		self.showFace("!error");
	};
	
	//------------------------------------------------------------------------
	cssVO.longEdit=async function(){
		let text=""+value;
		text=await app.modalDlg("/@editkit/ui/DlgLongText.js",{
			title:"Edit value",text:text
		});
		if(text!==null){
			this.commitEdit(text);
		}
	};
	
	/*}#1HQ1EDCKJ1PostCSSVO*/
	cssVO.constructor=DLStd;
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/

//----------------------------------------------------------------------------
DLStd.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HQ1EDCKJ1PreAISpot*/
	/*}#1HQ1EDCKJ1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HQ1EDCKJ1PostAISpot*/
	/*}#1HQ1EDCKJ1PostAISpot*/
	return exposeVO;
};

/*#{1HQ1EDCKJ0EndDoc*/
/*}#1HQ1EDCKJ0EndDoc*/

export default DLStd;
export{DLStd};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQ1EDCKJ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "#{properties:{size:{type:\"int\",label:\"Size\",description:\"This is size\",shortEdit:true}}}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "#{size:50}"
//				},
//				"property": {
//					"type": "string",
//					"valText": "size"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 0, edit:0, longEdit:true,labelWidth:80}"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"value": {
//					"type": "auto",
//					"valText": "#dataObj[property]"
//				},
//				"pptTemplate": {
//					"type": "auto",
//					"valText": "#template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value))"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#null//appCfg.sharedAssets+\"/inc.svg\"#>pptTemplate.icon"
//				},
//				"labelLine": {
//					"type": "bool",
//					"valText": "#!!opts.labelLine"
//				},
//				"description": {
//					"type": "string",
//					"valText": "#edit?pptTemplate.desc:null"
//				},
//				"choices": {
//					"type": "auto",
//					"valText": "#pptTemplate.choices"
//				},
//				"valueGap": {
//					"type": "int",
//					"valText": "#choices?3:(opts.labelLine?10:3)"
//				},
//				"menuGap": {
//					"type": "int",
//					"valText": "#opts.labelLine?6:3"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VN1I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND0",
//							"attrs": {}
//						}
//					}
//				},
//				"!error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VNIQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "#opts?(opts.lineHeight||25):25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ1F1DNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1F383P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#opts?(opts.lineHeight-3):22",
//										"h": "#opts?(opts.lineHeight-3):22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1F383P1",
//									"attrs": {
//										"1HQ20VN1I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQ2126ND2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ2126ND3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VN1I0",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1F383P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1F383P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GMNN90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GMNN91",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "#labelLine?\"100%\":\"\"",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "#opts.labelWidth||0",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.labelColor",
//														"text": "#title||(pptTemplate.label?pptTemplate.label:(property+\":\"))",
//														"font": "",
//														"fontSize": "#opts?(opts.labelSize||12):14",
//														"bold": "#opts?(opts.labelBold||false):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GMNNA0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND5",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"error\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														},
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#opts.labelColor"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GMNNA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GMNNA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GNGQ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GNGQ61",
//													"attrs": {
//														"type": "text",
//														"id": "TxtValue",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "#[opts.labelLine?2:0,0,0,opts.labelLine?10:3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.valueColor",
//														"text": "#(value===undefined)?\"\":value",
//														"font": "",
//														"fontSize": "#opts?(opts.valueSize||16):16",
//														"bold": "#opts?(!!opts.valueBold):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!edit",
//														"flex": "#(!!opts.valueRightAlign)&&(!opts.edit)"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GNGQ62",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GNGQ63",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GNGQ64",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1HQ1K18GQ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HQ1K9EC90",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "#opts?(opts.valueSize?(opts.valueSize+4):20):20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HQ1K9EC91",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",opts?(opts.valueSize?(opts.valueSize+4):20):20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnMenu",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "#[0,0,0,menuGap]",
//														"attach": "#(!!choices)&&(!!edit)"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1K9EC92",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1K9EC93",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HR3FDKUS0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HR3FDT9A0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1K9EC94",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HQ1K9EC95",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HQ1HIHAP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1HQFOL0",
//													"attrs": {
//														"type": "edit",
//														"id": "EdValue",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "80",
//														"h": "#opts?(opts.valueSize?(opts.valueSize+4):20):20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "#[0,0,0,valueGap]",
//														"padding": "",
//														"minW": "50",
//														"minH": "",
//														"maxW": "#pptTemplate.shortEdit?60:600",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "#pptTemplate.inputType",
//														"text": "#(value===undefined)?\"\":value",
//														"placeHolder": {
//															"type": "string",
//															"valText": "#pptTemplate?(pptTemplate.placeHolder||(pptTemplate.required?\"Required\":\"\")):\"\"",
//															"localize": {
//																"EN": "#pptTemplate?(pptTemplate.placeHolder||(pptTemplate.required?\"Required\":\"\")):\"\""
//															},
//															"localizable": true
//														},
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,0.00]",
//														"font": "",
//														"fontSize": "#opts?(opts.valueSize||16):16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true",
//														"attach": "#!!edit",
//														"pattern": "#pptTemplate.inputPattern"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1HQFOL1",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1HQFOL2",
//													"attrs": {
//														"OnInput": {
//															"type": "fixedFunc",
//															"jaxId": "1HQ213AB70",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HQ213PBO0",
//																	"attrs": {}
//																},
//																"seg": ""
//															}
//														},
//														"OnKeyDown": {
//															"type": "fixedFunc",
//															"jaxId": "1HQ21481P0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HQ2168720",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														},
//														"OnFocus": {
//															"type": "fixedFunc",
//															"jaxId": "1IIHF7RT80",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIHF8PB20",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														},
//														"OnBlur": {
//															"type": "fixedFunc",
//															"jaxId": "1IIHF84NH0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIHF8PB21",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1HQFOL3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIHEHVQF0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIHEKJQ70",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "#opts?(opts.valueSize?(opts.valueSize+4):20):20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/edit.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIHEKJQ71",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",opts?(opts.valueSize?(opts.valueSize+4):20):20,0,appCfg.sharedAssets+\"/edit.svg\",null)",
//														"id": "BtnLongEdit",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"attach": "#!!opts.longEdit"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIHEKJQ72",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIHEKJQ73",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIHFOH3R0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIHFOUGH0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIHEKJQ74",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Long edit",
//															"localize": {
//																"EN": "Long edit",
//																"CN": "长文本编辑"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IIHEKJQ75",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I99T444J0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I99T444J1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtError",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"error\"]",
//														"text": "error",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I99T444K0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I99T444K1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I99T444K2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I99T444K3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I99T444K4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1JKTFQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1JO33U0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#description",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!description"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1JO33U1",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1JO33U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1JO33U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {
//										"1HQ20VN1I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQ2126ND16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ2126NE0",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VN1I0",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {
//										"OnMouseInOut": {
//											"type": "fixedFunc",
//											"jaxId": "1IIHFD1O40",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IIHFE14C0",
//													"attrs": {
//														"isIn": "",
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I9ATINRR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9ATM74K0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"subFocus\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!opts.gridLine"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I9ATM74K1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I9ATM74K2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9ATM74K3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {
//						"1HQ20VN1I0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQ2126NE1",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ2126NE2",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQ20VN1I0",
//							"faceTagName": "error"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}