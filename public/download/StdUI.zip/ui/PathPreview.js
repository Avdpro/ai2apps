//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnSwitch} from "./BtnSwitch.js";
import {BtnIcon} from "./BtnIcon.js";
import {DataView} from "./DataView.js";
/*#{1I8R9NI5A0StartDoc*/
import {readPathInfo,readDirInfo} from "../FileUtils.js";
import {FileInfo,FolderInfo,CloudInfo} from "../data/FileInfo.js";
import {DvtCloudInfo,DvtNoRepo} from "../data/CloudInfo.js";
import pathLib from "/@path";
import {getDiskChanges} from "/@disk/utils.js"
import {tabFS,tabNT} from "/@tabos";
import markdownit from "/@markdownit";
/*}#1I8R9NI5A0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let PathPreview=function(options){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let imgIcon,boxIcon,boxImage,imgChecker,imgImage,btnZoom,txtName,txtPath,dvInfo,boxAddOn,boxTextContent,boxText;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I8R9NI5A1LocalVals*/
	const app=VFACT.app;
	let addOn=null;
	let addOnTools=[];
	/*}#1I8R9NI5A1LocalVals*/
	
	/*#{1I8R9NI5A1PreState*/
	let curPath=null;
	let curCloudDisk=null;
	/*}#1I8R9NI5A1PreState*/
	state={
		"imgZoom":1,
		/*#{1I8R9NI5A7ExState*/
		/*}#1I8R9NI5A7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I8R9NI5A1PostState*/
	let escapeHTML=function (htmlStr) {
		let pts,i,n;
		htmlStr=htmlStr.replaceAll("&", "&amp;")
			.replaceAll("<", "&lt;")
			.replaceAll(">", "&gt;")
			.replaceAll('"', "&quot;")
			.replaceAll("'", "&#39;")
			.replaceAll("\r", "");
		/*pts=htmlStr.split("\n");
		n=pts.length;
		if(n>0){
			htmlStr=pts.join("\n<br>\n");
		}*/
		return htmlStr;
	};
	/*}#1I8R9NI5A1PostState*/
	cssVO={
		"hash":"1I8R9NI5A1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[5,10,5,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"traceSize":true,
		children:[
			{
				"hash":"1I8R9RB760",
				"type":"image","id":"ImgIcon","position":"relative","x":"50%","y":0,"w":80,"h":80,"anchorX":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"image":appCfg.sharedAssets+"/folder.svg","fitSize":true,"attached":false,
			},
			{
				"hash":"1IARRIGI30",
				"type":"box","id":"BoxIcon","position":"relative","x":"50%","y":0,"w":80,"h":80,"anchorX":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["fontBody"],"maskImage":appCfg.sharedAssets+"/folder.svg",
			},
			{
				"hash":"1I8SPU1KQ0",
				"type":"hud","id":"BoxImage","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"FW","autoLayout":true,"display":0,"margin":[5,0,10,0],
				"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","aspect":"1","contentLayout":"flex-x","traceSize":true,
				children:[
					{
						"hash":"1I984F6U90",
						"type":"box","id":"BoxImageFrame","x":0,"y":0,"w":"100%","h":"FW","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":[255,255,255,1],"border":1,
						children:[
							{
								"hash":"1I984F6U92",
								"type":"image","id":"ImgChecker","x":0,"y":0,"w":"200%","h":"FH*2","autoLayout":true,"display":0,"scale":0.5,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","image":appCfg.sharedAssets+"/checker.png",
							},
							{
								"hash":"1I984F6UA5",
								"type":"image","id":"ImgImage","x":"50%","y":"50%","w":100,"h":100,"anchorX":1,"anchorY":1,"cursor":"move","minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","fitSize":true,
								"OnLoad":function(){
									/*#{1I984F6UA11FunctionBody*/
									self.fitImageZoom();
									/*}#1I984F6UA11FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1I8SQD5H60",
						"type":BtnSwitch(20,false),"id":"BtnChecker","position":"relative","x":0,"y":">calc(100% - 20px)","margin":[0,3,0,0],"color":[13,110,253,1],"lineColor":cfgColor["fontBody"],
						/*#{1I8SQD5H60Codes*/
						OnCheck(checked){
							imgChecker.display=!!checked;
						}
						/*}#1I8SQD5H60Codes*/
					},
					{
						"hash":"1I8SQJBDR0",
						"type":"text","position":"relative","x":0,"y":">calc(100% - 20px)","w":"","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("棋盘格"):("Checker")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1I8SRI2NA0",
						"type":"hud","position":"relative","x":0,"y":">calc(100% - 20px)","w":10,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
					},
					{
						"hash":"1I8SRFLO40",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnZoom","position":"relative","x":0,"y":">calc(100% - 20px)",
						"OnClick":function(event){
							self.chooseZoom(this,event);
						},
					},
					{
						"hash":"1I8SRGS530",
						"type":"text","id":"TxtZoom","position":"relative","x":0,"y":">calc(100% - 20px)","w":"","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":$P(()=>(`${parseInt(state.imgZoom*100)}%`),state),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1I8RASCCU0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":"stat.json","fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,
			},
			{
				"hash":"1I8RAPJ5D0",
				"type":"text","id":"TxtPath","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":"/doc/start","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
				"ellipsis":true,
			},
			{
				"hash":"1I8SPLN3I0",
				"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":2,"labelSize":txtSize.small,"labelColor":cfgColor["fontBody"],"labelBold":false,"labelLine":false,"valueSize":txtSize.small,"valueColor":cfgColor["fontBody"],"valueBold":true,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12,"autoCollapse":false,"hideCollapse":true,"valueRightAlign":true,"gridLine":true},""),
				"id":"DvInfo","position":"relative","x":0,"y":0,"display":0,
			},
			{
				"hash":"1I8RADEUC0",
				"type":"hud","id":"BoxAddOn","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,"subAlign":4,
			},
			{
				"hash":"1I8RABOE00",
				"type":"hud","id":"BoxTextContent","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"overflow":"auto","margin":[0,0,10,0],"minW":"",
				"minH":30,"maxW":"","maxH":"","styleClass":"minidoc",
			},
			{
				"hash":"1I9DN1BSA0",
				"type":"box","id":"BoxText","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"overflow":"auto-x","padding":[0,5,50,5],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"minidoc","background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"],
				children:[
					{
						"hash":"1I9DN31GP0",
						"type":"hud","id":"BoxTextContent","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
					}
				],
			}
		],
		/*#{1I8R9NI5A1ExtraCSS*/
		/*}#1I8R9NI5A1ExtraCSS*/
		faces:{
			"folder":{
				/*ImgIcon*/"#1I8R9RB760":{
					"display":1
				},
				/*BoxIcon*/"#1IARRIGI30":{
					"display":1
				},
				/*BoxImage*/"#1I8SPU1KQ0":{
					"display":0
				},
				/*TxtName*/"#1I8RASCCU0":{
					"display":1
				},
				/*TxtPath*/"#1I8RAPJ5D0":{
					"display":1
				},
				/*DvInfo*/"#1I8SPLN3I0":{
					"display":0
				},
				/*BoxAddOn*/"#1I8RADEUC0":{
					"display":1
				},
				/*BoxTextContent*/"#1I8RABOE00":{
					"display":0
				},
				/*BoxText*/"#1I9DN1BSA0":{
					"display":0
				},
				/*BoxTextContent*/"#1I9DN31GP0":{
					"display":0
				}
			},"file":{
				/*ImgIcon*/"#1I8R9RB760":{
					"image":appCfg.sharedAssets+"/file.svg","display":1
				},
				/*BoxIcon*/"#1IARRIGI30":{
					"display":1,"maskImage":appCfg.sharedAssets+"/file.svg"
				},
				/*BoxImage*/"#1I8SPU1KQ0":{
					"display":0
				},
				/*TxtName*/"#1I8RASCCU0":{
					"display":1
				},
				/*TxtPath*/"#1I8RAPJ5D0":{
					"display":1
				},
				/*DvInfo*/"#1I8SPLN3I0":{
					"display":1
				},
				/*BoxAddOn*/"#1I8RADEUC0":{
					"display":1
				},
				/*BoxTextContent*/"#1I8RABOE00":{
					"display":0
				},
				/*BoxText*/"#1I9DN1BSA0":{
					"display":0
				},
				/*BoxTextContent*/"#1I9DN31GP0":{
					"display":0
				}
			},"image":{
				/*ImgIcon*/"#1I8R9RB760":{
					"display":0
				},
				/*BoxIcon*/"#1IARRIGI30":{
					"display":0
				},
				/*BoxImage*/"#1I8SPU1KQ0":{
					"display":1
				},
				/*TxtName*/"#1I8RASCCU0":{
					"display":1
				},
				/*TxtPath*/"#1I8RAPJ5D0":{
					"display":1
				},
				/*DvInfo*/"#1I8SPLN3I0":{
					"display":1
				},
				/*BoxAddOn*/"#1I8RADEUC0":{
					"display":1
				},
				/*BoxTextContent*/"#1I8RABOE00":{
					"display":0
				},
				/*BoxText*/"#1I9DN1BSA0":{
					"display":0
				},
				/*BoxTextContent*/"#1I9DN31GP0":{
					"display":0
				}
			},"disk":{
				/*BoxAddOn*/"#1I8RADEUC0":{
					"display":1
				}
			},"readme":{
				/*ImgIcon*/"#1I8R9RB760":{
					"display":0
				},
				/*BoxIcon*/"#1IARRIGI30":{
					"display":0
				},
				/*BoxImage*/"#1I8SPU1KQ0":{
					"display":0
				},
				/*TxtName*/"#1I8RASCCU0":{
					"display":0
				},
				/*TxtPath*/"#1I8RAPJ5D0":{
					"display":0
				},
				/*DvInfo*/"#1I8SPLN3I0":{
					"display":0
				},
				/*BoxAddOn*/"#1I8RADEUC0":{
					"display":0
				},
				/*BoxTextContent*/"#1I8RABOE00":{
					"display":0
				},
				/*BoxText*/"#1I9DN1BSA0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			imgIcon=self.ImgIcon;boxIcon=self.BoxIcon;boxImage=self.BoxImage;imgChecker=self.ImgChecker;imgImage=self.ImgImage;btnZoom=self.BtnZoom;txtName=self.TxtName;txtPath=self.TxtPath;dvInfo=self.DvInfo;boxAddOn=self.BoxAddOn;boxTextContent=self.BoxTextContent;boxText=self.BoxText;boxTextContent=self.BoxTextContent;
			/*#{1I8R9NI5A1Create*/
			VFACT.applyMoveDrag(imgImage,imgImage);
			//Setup addons:
			self.setupAddon();
			/*}#1I8R9NI5A1Create*/
		},
		/*#{1I8R9NI5A1EndCSS*/
		/*}#1I8R9NI5A1EndCSS*/
	};
	//------------------------------------------------------------------------
	/**
	 * Setup addons, fill in boxAddOn.
	 * @returns {void} 
	 */
	cssVO.setupAddon=async function(){
		/*#{1I9L7II410Start*/
		addOn=VFACT.app.addOn;
		if(addOn){
			let slot,call,def;
			slot=addOn.getSlot("EntryPreviewTool");
			for(call of slot){
				def=await call(app,self,boxAddOn);
				addOnTools.push(boxAddOn.appendNewChild(def));
			}
		}
		/*}#1I9L7II410Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * 设置预览路径，加载路径信息并展示。
	 * 
	 * @param {*} entry - Path object.
	 * @returns {void} 无返回值
	 */
	cssVO.setEntry=async function(entry){
		/*#{1I8RTPNVT0Start*/
		let name,path,ext,info,date;
		if(Array.isArray(entry)){
			let list;
			list=entry;
			info={
				size:0,
				entryNum:0,
				modifyTime:0
			};
			curPath=list;
			txtPath.text="";
			txtName.text=(($ln==="CN")?(`${list.length} 个项目`):/*EN*/(`${list.length} items`));
			//imgIcon.image=appCfg.sharedAssets+"/files.svg";
			boxIcon.maskImage=appCfg.sharedAssets+"/file.svg";
			self.showFace("folder");
			for(entry of list){
				if(typeof(entry)==="string"){
					entry=await readPathInfo(entry);
				}
				if(entry && entry.name){
					if(entry.dir){
						await readDirInfo(entry.path,info);
						info.entryNum+=1;
					}else{
						info.size+=entry.size;
						info.entryNum+=1;
						info.modifyTime=entry.modifyTime>info.modifyTime?entry.modifyTime:info.modifyTime;
					}
				}
			}
			date=new Date();
			if(curPath===list){
				info.size=(info.size>1024*1024*10?(parseInt(info.size/(1024*1024)).toLocaleString()+"MB"):(info.size>1024*10?(parseInt(info.size/1024).toLocaleString()+"KB"):(info.size.toLocaleString())));
				info.createTime="- - -";
				date.setTime(entry.modifyTime);
				info.modifyTime=date.toLocaleString();
				dvInfo.setObject(FolderInfo,info,null);
				dvInfo.display=true;
			}
			return;
		}
		if(typeof(entry)==="string"){
			entry=await readPathInfo(entry);
		}
		name=entry.name;
		path=entry.path;
		curPath=path;
		txtPath.text=path;
		txtName.text=name;
		ext=pathLib.extname(name).toLowerCase();
		date=new Date();
		if(entry.dir){
			if(path==="/"){
				//imgIcon.image=appCfg.sharedAssets+"/aalogo.svg";
				boxIcon.maskImage=appCfg.sharedAssets+"/aalogo.svg";
			}else if(entry.disk){
				//imgIcon.image=appCfg.sharedAssets+"/disk.svg";
				boxIcon.maskImage=appCfg.sharedAssets+"/disk.svg";
			}else{
				//imgIcon.image=appCfg.sharedAssets+"/folder.svg";
				boxIcon.maskImage=appCfg.sharedAssets+"/folder.svg";
			}
			self.showFace("folder");
			entry=await readDirInfo(path);
			if(entry && entry.path===curPath){
				info={...entry};
				info.size=(info.size>1024*1024*10?(parseInt(info.size/(1024*1024)).toLocaleString()+"MB"):(info.size>1024*10?(parseInt(info.size/1024).toLocaleString()+"KB"):(info.size.toLocaleString())));
				if(entry.createTime){
					date.setTime(entry.createTime);
					info.createTime=date.toLocaleString();
				}else{
					info.createTime="- - -";
				}
				if(entry.modifyTime){
					date.setTime(entry.modifyTime);
					info.modifyTime=date.toLocaleString();
				}else{
					info.modifyTime="- - -";
				}
				dvInfo.setObject(FolderInfo,info,null);
				dvInfo.display=true;
			}
		}else{
			switch(ext){
				case ".jpg":
				case ".png":
				case ".gif":
				case ".svg":
					if(options.showImage){
						self.showFace("image");
						self.showImage(path);
					}else{
						//imgIcon.image=appCfg.sharedAssets+"/hudimg.svg";
						boxIcon.maskImage=appCfg.sharedAssets+"/hudimg.svg";
						self.showFace("file");
					}
					break;
				case ".md":
					self.showFace("file");
					if(options.showContent){
						self.showMarkdown("/~"+path,path);
					}
					break;
				case ".js":
				case ".json":
				case ".ts":
				case ".html":
				case ".css":
				case ".h":
				case ".c":
				case ".cpp":
				case ".java":
				case ".py":
				case ".xml":
				case ".ini":
				case ".bat":
				case ".log":
				case ".csv":
				case ".tsv":
				case ".txt":
				case ".sh":
				case ".yml":
				case ".yaml":
					//imgIcon.image=appCfg.sharedAssets+"/file.svg";
					boxIcon.maskImage=appCfg.sharedAssets+"/file.svg";
					self.showFace("file");
					if(options.showContent){
						let text;
						try{
							text=await (await fetch("/~"+path)).text();
							if(path===curPath){
								let lines=text.split("\n");
								if(lines.length>200){
									lines=lines.slice(0,200);
									text=lines.join("\n")+"\n...";
								}
								if(text.length>1024*300){
									text=text.substring(0,1024*300)+"...";
								}
								boxText.display=true;
								boxTextContent.webObj.innerHTML=`<pre style="font-size:10px; tab-size:4">\n${ext===".html"?escapeHTML(text):text}\n<pre>`;
								boxTextContent.display=true;
							}
						}catch(err){
							if(path===curPath){
								boxText.display=false;
								boxTextContent.display=false;
							}
						}
					}
					break;
				default:
					//imgIcon.image=appCfg.sharedAssets+"/file.svg";
					boxIcon.maskImage=appCfg.sharedAssets+"/file.svg";
					self.showFace("file");
					break;
			}
			info={
				size:entry.size,
			};
			info.size=info.size.toLocaleString();
			date.setTime(entry.modifyTime);
			info.modifyTime=date.toLocaleString();
			date.setTime(entry.createTime);
			info.createTime=date.toLocaleString();
			dvInfo.setObject(FileInfo,info,null);
			dvInfo.display=true;
		}
		for(let ad of addOnTools){
			ad.setEntry && ad.setEntry(entry);
		}
		/*}#1I8RTPNVT0Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * Get disk's cloud version contral infomation.
	 * 
	 * @param {string} diskName - Local disk(root foler) name. 
	 * @returns {Object} Disk's cloud version control meta info.
	 *    Including repo-id; local and cloud version; and local changes.
	 *    If disk is not version controled, return null.
	 */
	cssVO.getCloudInfo=async function(diskName){
		/*#{1I8RUTP4D0Start*/
		let localInfo,diskId,localVsnIdx,cloudInfo,changeInfo,res;
		
		//Get local info:
		localInfo=await tabFS.getDiskInfo(diskName);
		if(!localInfo){
		return null;//No cloud info.
		}
		if(curCloudDisk!==diskName){
		return null;
		}
		localVsnIdx=localInfo.versionIdx;
		diskId=localInfo.diskId;
		
		//Get change info:
		changeInfo=await getDiskChanges(diskName);
		if(curCloudDisk!==diskName){
		return null;
		}
		if(changeInfo){
		changeInfo={
		new:(changeInfo.newDirs?changeInfo.newDirs.length:0)+(changeInfo.newFiles?changeInfo.newFiles.length:0),
		change:changeInfo.files?changeInfo.files.length:0,
		delete:changeInfo.deleteItems?changeInfo.deleteItems.length:0,
		conflict:changeInfo.conflict?changeInfo.conflict.length:0
		};
		}else{
		changeInfo=undefined;
		}
		
		//Make sure we login before get cloud info:
		if(!tabNT.loginDone){
		if(! await tabNT.checkLogin(false)){
		return {local:localInfo,cloud:null,change:changeInfo};
		}
		}
		
		res=await tabNT.makeCall("diskInfo",{diskId:diskId});
		if(!res || res.code!==200){
		return {local:localInfo,cloud:null,change:changeInfo};
		}
		if(curCloudDisk!==diskName){
		return null;
		}
		cloudInfo=res;
		return {diskId:diskId,local:localInfo,cloud:cloudInfo,change:changeInfo};
		/*}#1I8RUTP4D0Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * Show image preview
	 * 
	 * @param {string} path - Image file path(not URL) of Tab-FS.
	 * @returns {void} 
	 */
	cssVO.showImage=async function(path){
		/*#{1I8RUV6D60Start*/
		imgImage.display=true;
		imgImage.image="/~"+path;
		/*}#1I8RUV6D60Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * Show current path's text file's content preview.
	 * 
	 * @returns {void} 
	 */
	cssVO.showFileText=async function(){
		/*#{1I8RUVLBG0Start*/
		/*}#1I8RUVLBG0Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * Adjust image's display zoom to fit the show area.
	 * @returns {void} 
	 */
	cssVO.fitImageZoom=async function(){
		/*#{1I8SRP27V0Start*/
		let fw,fh,w,h,changed;
		fw=imgImage.father.clientW;
		fh=imgImage.father.clientH||fw;
		w=imgImage.imgW;h=imgImage.imgH;
		imgImage.x=fw*0.5;
		imgImage.y=fh*0.5;
		if(w>0 && h>0){
			changed=false;
			if(w>fw){
				h=h*fw/w;
				w=fw;
				changed=true;
			}
			if(h>fh){
				w=w*fh/h;
				h=fh;
				changed=true;
			}
			imgImage.w=w;
			imgImage.h=h;
			imgImage.display=true;
			if(changed){
				state.imgZoom=w/imgImage.imgW;
			}else{
				state.imgZoom=1;
			}
		}else{
			imgImage.display=false;
			state.imgZoom=1;
		}
		/*}#1I8SRP27V0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseZoom=async function(){
		/*#{1I8SRPOC80Start*/
		let items,item;
		items=[
			{text:(($ln==="CN")?("自动适应"):/*EN*/("Auto size")),zoom:0},
			{text:"10%",zoom:0.1},
			{text:"20%",zoom:0.2},
			{text:"30%",zoom:0.3},
			{text:"50%",zoom:0.5},
			{text:"75%",zoom:0.75},
			{text:"100%",zoom:1},
			{text:"125%",zoom:1.25},
			{text:"150%",zoom:1.5},
			{text:"200%",zoom:2},
			{text:"300%",zoom:3},
			{text:"400%",zoom:5},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:btnZoom,
			items:items
		});
		if(!item){
			return;
		}
		if(!item.zoom){
			await self.fitImageZoom();
		}else{
			imgImage.w=imgImage.imgW*item.zoom;
			imgImage.h=imgImage.imgH*item.zoom;
			state.imgZoom=item.zoom;
		}
		/*}#1I8SRPOC80Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * Show markdown format text content.
	 * Also used to show App's readme info on start.
	 * 
	 * @param {string} url - URL of markdown file.
	 * @param {*} path - 
	 * @param {bool} mdOnly - If true, preview box will only show text content block and hide all other blocks like file size etc. 
	 *    Used to show App's readme.
	 * @returns {void} 
	 */
	cssVO.showMarkdown=async function(url,path,mdOnly){
		/*#{1I9DNGD7K0Start*/
		let text;
		if(mdOnly){
			self.showFace("readme");
		}
		try{
			text=await (await fetch(url)).text();
			if((!path && !curPath) || path===curPath || mdOnly){
				text=markdownit().render(text);
				boxTextContent.webObj.innerHTML=text;
				boxText.display=true;
				boxTextContent.display=true;
			}
		}catch(err){
			if(path===curPath){
				boxText.display=false;
				boxTextContent.display=false;
			}
		}
		/*}#1I9DNGD7K0Start*/
	};
	/*#{1I8R9NI5A1PostCSSVO*/
	/*}#1I8R9NI5A1PostCSSVO*/
	cssVO.constructor=PathPreview;
	return cssVO;
};
/*#{1I8R9NI5A1ExCodes*/
/*}#1I8R9NI5A1ExCodes*/

//----------------------------------------------------------------------------
PathPreview.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I8R9NI5A1PreAISpot*/
	/*}#1I8R9NI5A1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I8R9NI5A1PostAISpot*/
	/*}#1I8R9NI5A1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
PathPreview.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"readOnly": {
						"name": "readOnly", "showName": "readOnly", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"showImage": {
						"name": "showImage", "showName": "showImage", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"showContent": {
						"name": "showContent", "showName": "showContent", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"showVersion": {
						"name": "showVersion", "showName": "showVersion", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"showCloud": {
						"name": "showCloud", "showName": "showCloud", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"showTool": {
						"name": "showTool", "showName": "showTool", "type": "bool", "key": true, "fixed": true, "initVal": false
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","filter","zIndex","flex","margin","traceSize","minW","minH","maxW","maxH"],
	faces:["folder","file","image","disk","readme"],
	subContainers:{
	},
	/*#{1I8R9NI5A0ExGearInfo*/
	/*}#1I8R9NI5A0ExGearInfo*/
};
/*#{1I8R9NI5A0EndDoc*/
/*}#1I8R9NI5A0EndDoc*/

export default PathPreview;
export{PathPreview};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I8R9NI5A0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I8R9NI5A2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor[\"menuBG\"]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I8R9NI5A3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I8R9NI5A4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I8R9NI5A5",
//			"attrs": {
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I8RA27910",
//					"attrs": {
//						"readOnly": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"showImage": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"showContent": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"showVersion": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"showCloud": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"showTool": {
//							"type": "bool",
//							"valText": "false"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I8R9NI5A6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I8R9NI5A7",
//			"attrs": {
//				"imgZoom": {
//					"type": "int",
//					"valText": "1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9L7II410",
//					"attrs": {
//						"id": "setupAddon",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "70",
//						"desc": "Setup addons, fill in boxAddOn.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9LA52PE0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9LA52PE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9LA52PE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8RTPNVT0",
//					"attrs": {
//						"id": "setEntry",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "160",
//						"desc": "设置预览路径，加载路径信息并展示。",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8RTQ0GT0",
//							"attrs": {
//								"entry": {
//									"type": "auto",
//									"valText": "",
//									"comment": "Path object."
//								}
//							}
//						},
//						"async": "true",
//						"returnType": {
//							"type": "string",
//							"valText": "void",
//							"comment": "无返回值"
//						},
//						"localVars": {
//							"jaxId": "1I8RTQ0GT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8RTQ0GT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false",
//						"aiToolCall": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8RUTP4D0",
//					"attrs": {
//						"id": "getCloudInfo",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "415",
//						"desc": "Get disk's cloud version contral infomation.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8RUU95L0",
//							"attrs": {
//								"diskName": {
//									"type": "string",
//									"valText": "",
//									"comment": "Local disk(root foler) name. "
//								}
//							}
//						},
//						"async": "true",
//						"returnType": {
//							"type": "string",
//							"valText": "Object",
//							"comment": "Disk's cloud version control meta info.\nIncluding repo-id; local and cloud version; and local changes.\nIf disk is not version controled, return null."
//						},
//						"localVars": {
//							"jaxId": "1I8RUU95L1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8RUU95L2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8RUV6D60",
//					"attrs": {
//						"id": "showImage",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "240",
//						"desc": "Show image preview",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8S0E0EV0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": "",
//									"comment": "Image file path(not URL) of Tab-FS."
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8S0E0EV1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8S0E0EV2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8RUVLBG0",
//					"attrs": {
//						"id": "showFileText",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "325",
//						"desc": "Show current path's text file's content preview.\n",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8S0E0EV3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8S0E0EV4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8S0E0EV5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8SRP27V0",
//					"attrs": {
//						"id": "fitImageZoom",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "500",
//						"desc": "Adjust image's display zoom to fit the show area.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8SRQ3OU0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8SRQ3OU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8SRQ3OU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8SRPOC80",
//					"attrs": {
//						"id": "chooseZoom",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "585",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8SRQ3OU3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8SRQ3OU4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8SRQ3OU5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9DNGD7K0",
//					"attrs": {
//						"id": "showMarkdown",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "675",
//						"desc": "Show markdown format text content.\nAlso used to show App's readme info on start.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9DNGVF60",
//							"attrs": {
//								"url": {
//									"type": "string",
//									"valText": "",
//									"comment": "URL of markdown file."
//								},
//								"path": {
//									"type": "auto",
//									"valText": ""
//								},
//								"mdOnly": {
//									"type": "bool",
//									"valText": "false",
//									"comment": "If true, preview box will only show text content block and hide all other blocks like file size etc. \nUsed to show App's readme."
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9DNGVF61",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9DNGVF62",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I8R9NI5A8",
//			"attrs": {
//				"folder": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8SQTOF90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8SR33SF0",
//							"attrs": {}
//						}
//					}
//				},
//				"file": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8SQUFL20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8SR33SF1",
//							"attrs": {}
//						}
//					}
//				},
//				"image": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8SQUQ6L0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8SR33SF2",
//							"attrs": {}
//						}
//					}
//				},
//				"disk": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I9A94S630",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I9A95FSG0",
//							"attrs": {}
//						}
//					}
//				},
//				"readme": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I9DNE3290",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I9DNFOKK0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I8R9NI5B0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I8R9NI5A1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I8R9NI5B1",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,10,5,10]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"subAlign": "Start",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1I8R9RB760",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8RA05J70",
//									"attrs": {
//										"type": "image",
//										"id": "ImgIcon",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "80",
//										"h": "80",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "#appCfg.sharedAssets+\"/folder.svg\"",
//										"autoSize": "false",
//										"fitSize": "Fit",
//										"repeat": "true",
//										"alignX": "Left",
//										"alignY": "Top",
//										"attach": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8RA05J71",
//									"attrs": {
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG48",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG49",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG51",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG53",
//													"attrs": {
//														"image": {
//															"type": "file",
//															"valText": "#appCfg.sharedAssets+\"/file.svg\""
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKK1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKK2",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8RA05J72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8RA05J73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IARRIGI30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IARRKKB30",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "80",
//										"h": "80",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/folder.svg\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IARRKKB31",
//									"attrs": {
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IARRSN4M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IARRSN4M1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IARRSN4M2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IARRSN4M3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"maskImage": {
//															"type": "file",
//															"valText": "#appCfg.sharedAssets+\"/file.svg\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IARRSN4M4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IARRSN4M5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IARRSN4M6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IARRSN4M7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IARRKKB32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IARRKKB33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I8SPU1KQ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8SPVMON0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxImage",
//										"position": "relative",
//										"x": "10",
//										"y": "0",
//										"w": "100%-20",
//										"h": "FW",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,10,0]",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"aspect": "1",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"traceSize": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I984F6U90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I984F6U91",
//													"attrs": {
//														"type": "box",
//														"id": "BoxImageFrame",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "#\"FW\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"traceSize": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1I984F6U92",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I984F6U93",
//																	"attrs": {
//																		"type": "image",
//																		"id": "ImgChecker",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "200%",
//																		"h": "\"FH*2\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "0.5",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "#appCfg.sharedAssets+\"/checker.png\"",
//																		"autoSize": "false",
//																		"fitSize": "auto",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I984F6UA0",
//																	"attrs": {
//																		"1I8SQUQ6L0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IARRV8A40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IARRV8A41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I8SQUQ6L0",
//																			"faceTagName": "image"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I984F6UA3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I984F6UA4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1I984F6UA5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I984F6UA6",
//																	"attrs": {
//																		"type": "image",
//																		"id": "ImgImage",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "50%",
//																		"w": "100",
//																		"h": "100",
//																		"anchorH": "Center",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "move",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "",
//																		"autoSize": "false",
//																		"fitSize": "Fit",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I984F6UA7",
//																	"attrs": {
//																		"1I8SQUQ6L0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IARRV8A42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IARRV8A43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I8SQUQ6L0",
//																			"faceTagName": "image"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I984F6UA10",
//																	"attrs": {
//																		"OnLoad": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I984F6UA11",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I984F6UA12",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I984F6UB0",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I984F6UB1",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I984F6UB2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I984F6UB3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1LFSMBH0",
//											"jaxId": "1I8SQD5H60",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8SQJ0GT0",
//													"attrs": {
//														"size": "20",
//														"check": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1I8SQJ0GT1",
//													"attrs": {
//														"type": "#null#>BtnSwitch(20,false)",
//														"id": "BtnChecker",
//														"position": "Relative",
//														"x": "0",
//														"y": "100%-20",
//														"display": "On",
//														"face": "",
//														"margin": "[0,3,0,0]",
//														"color": {
//															"type": "colorRGBA",
//															"valText": "[13,110,253,1.00]"
//														},
//														"lineColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8SQJ0GT2",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A46",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A47",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8SQJ0GT3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8SQJ0GT4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I8SQJ0GT5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I8SQJBDR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SQKV980",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "100%-20",
//														"w": "",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "Checker",
//															"localize": {
//																"EN": "Checker",
//																"CN": "棋盘格"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8SQKV981",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8SQKV982",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8SQKV983",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I8SRI2NA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SRJP380",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "100%-20",
//														"w": "10",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8SRJP381",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A410",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A411",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8SRJP382",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8SRJP383",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1I8SRFLO40",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8SRJP384",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I8SRJP385",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnZoom",
//														"position": "relative",
//														"x": "0",
//														"y": "100%-20",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8SRJP386",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8SRJP387",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8T01F1P0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8T01F1P1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I8SRPOC80"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8SRJP388",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8SRJP389",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I8SRGS530",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SRGS531",
//													"attrs": {
//														"type": "text",
//														"id": "TxtZoom",
//														"position": "relative",
//														"x": "0",
//														"y": "100%-20",
//														"w": "",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${`${parseInt(state.imgZoom*100)}%`},state",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8SRGS540",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IARRV8A52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IARRV8A53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8SRGS545",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8SRGS546",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I8SPVMON1",
//									"attrs": {
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG42",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG43",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG44",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG45",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG47",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKK3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKK4",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8SPVMON2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8SPVMON3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I8RASCCU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8RB1DRD4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "stat.json",
//										"font": "",
//										"fontSize": "#txtSize.midPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8RB1DRD5",
//									"attrs": {
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKK5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKK6",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9RRD1IR16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9RRD1IR17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8RB1DRD6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8RB1DRD7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I8RAPJ5D0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8RB1DRD0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtPath",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "/doc/start",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8RB1DRD1",
//									"attrs": {
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP13",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKK7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKK8",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9RRD1IR18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9RRD1IR19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8RB1DRD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8RB1DRD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HQ1M47LD0",
//							"jaxId": "1I8SPLN3I0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I8SPQ0O60",
//									"attrs": {
//										"box": "null",
//										"template": "null",
//										"dataObj": "null",
//										"property": "",
//										"options": {
//											"jaxId": "1I8SPQ0O61",
//											"attrs": {
//												"titleHeight": "30",
//												"titleSize": "18",
//												"titleColor": "#cfgColor[\"fontBody\"]",
//												"titleBold": "true",
//												"lineHeight": "20",
//												"lineGap": "2",
//												"labelSize": "#txtSize.small",
//												"labelColor": "#cfgColor[\"fontBody\"]",
//												"labelBold": "false",
//												"labelLine": "false",
//												"valueSize": "#txtSize.small",
//												"valueColor": "#cfgColor[\"fontBody\"]",
//												"valueBold": "true",
//												"segHeight": "20",
//												"segSize": "14",
//												"segBold": "true",
//												"segColor": "#cfgColor[\"fontBody\"]",
//												"trace": "false",
//												"edit": "false",
//												"noteSize": "12",
//												"autoCollapse": "false",
//												"hideCollapse": "true",
//												"valueRightAlign": "true",
//												"gridLine": "true"
//											}
//										},
//										"title": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1I8SPQ0O62",
//									"attrs": {
//										"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":2,\"labelSize\":txtSize.small,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":false,\"labelLine\":false,\"valueSize\":txtSize.small,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":true,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":true,\"valueRightAlign\":true,\"gridLine\":true},\"\")",
//										"id": "DvInfo",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "Off",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8SPQ0O63",
//									"attrs": {
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG57",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG59",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8T4CDNT24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8T4CDNT25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKL1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8SPQ0O64",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8SPQ0O65",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1I8SPQ0O66",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I8RADEUC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8RAG5E64",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxAddOn",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"subAlign": "Space Evenly"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8RAG5E65",
//									"attrs": {
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG78",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG79",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG81",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG82",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG83",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I9A94S630": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP31",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9A94S630",
//											"faceTagName": "disk"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKL6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKL7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8RAG5E66",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8RAG5E67",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I8RABOE00",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8RAG5E60",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTextContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "minidoc"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8RAG5E61",
//									"attrs": {
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG61",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG63",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8SR33SG64",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8SR33SG65",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKL4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKL5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8RAG5E62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8RAG5E63",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I9DN1BSA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9DN4VCP32",
//									"attrs": {
//										"type": "box",
//										"id": "BoxText",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Auto Scroll X",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,50,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "minidoc",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I9DN31GP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN31GP1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTextContent",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9DN31GP2",
//													"attrs": {
//														"1I8SQUQ6L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9DN31GP3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9DN31GP4",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUQ6L0",
//															"faceTagName": "image"
//														},
//														"1I8SQTOF90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9DN31GP5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9DN31GP6",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQTOF90",
//															"faceTagName": "folder"
//														},
//														"1I8SQUFL20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9DN31GP7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9DN31GP8",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8SQUFL20",
//															"faceTagName": "file"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9DN31GP9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9DN31GP10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I9DN4VCP35",
//									"attrs": {
//										"1I8SQUFL20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP36",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP37",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUFL20",
//											"faceTagName": "file"
//										},
//										"1I8SQTOF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP38",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP39",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQTOF90",
//											"faceTagName": "folder"
//										},
//										"1I8SQUQ6L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DN4VCP42",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DN4VCP43",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8SQUQ6L0",
//											"faceTagName": "image"
//										},
//										"1I9DNE3290": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9DNFOKL8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9DNFOKL9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9DNE3290",
//											"faceTagName": "readme"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I9DN4VCP44",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9DN4VCP45",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I8R9NI5B2",
//					"attrs": {
//						"1I8SQUQ6L0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IARRV8A54",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IARRV8A55",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8SQUQ6L0",
//							"faceTagName": "image"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I8R9NI5B3",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I8R9NI5B4",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I8R9NI5B5",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}