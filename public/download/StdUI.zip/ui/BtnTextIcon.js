//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1RPOAH90StartDoc*/
/*}#1H1RPOAH90StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnTextIcon=function(w,h,icon,color,hasMark,hasCheck,text){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1KJQ5RK1LocalVals*/
	let checked=false;
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":false,"text":text,"fontSize":txtSize.small,"markNum":1,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":26,"y":15,"w":"","h":"","cursor":"pointer","padding":[0,3,0,3],"minW":w,"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
				"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H60UF7OR0",
				"type":"hud","position":"relative","x":"50%","y":0,"w":w-15,"h":(h||w)-15,"anchorX":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1H60UGMSN0",
						"type":"box","position":"relative","x":"50%","y":0,"w":(h||w)-15,"h":(h||w)-15,"anchorX":1,"uiEvent":-1,"alpha":hasCheck?0.5:1,"margin":[0,3,0,0],
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":color,"attached":icon,"maskImage":icon,
					},
					{
						"hash":"1H60ULCF00",
						"type":"hud","id":"Overlays","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1H60UO9EL0",
						"type":"box","id":"BoxMark","x":"100%","y":0,"w":"","h":"","anchorX":1,"display":$P(()=>(!!state.markNum),state),"padding":[2,5,2,5],"minW":15,"minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor.error,"corner":100,"contentLayout":"flex-x","subAlign":1,"attached":!!hasMark,
						children:[
							{
								"hash":"1H60UO9EM0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontError,
								"text":$P(()=>(state.markNum),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					}
				],
			},
			{
				"hash":"1H1RPTGKE0",
				"type":"text","position":"relative","x":"50%","y":0,"w":"","h":"","anchorX":1,"alpha":hasCheck?0.5:1,"margin":[Math.floor(w/15),0,0,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","color":color,"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal",
				"fontStyle":"normal","textDecoration":"","alignH":1,
			}
		],
		get $$markNum(){return state["markNum"]},
		set $$markNum(v){
			state["markNum"]=v;
			/*#{1H1KJQ5RK1SetmarkNum*/
			/*}#1H1KJQ5RK1SetmarkNum*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1KK1Q1R0PreCode*/
				$(){
					return !checked;
				},
				/*}#1H1KK1Q1R0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"y":0,"borderColor":color
				},
				"#1H60UGMSN0":{
					"background":color,"y":0,"alpha":hasCheck?0.5:1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":hasCheck?0.5:1
				}
			},"over":{
				/*#{1H1KK1SU60PreCode*/
				$(){
					return !checked;
				},
				/*}#1H1KK1SU60PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemOver,"y":0,"alpha":1
				},
				"#1H60UGMSN0":{
					"background":color,"y":0,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"down":{
				/*#{1H1KK1M7O0PreCode*/
				$(){
					return !checked;
				},
				/*}#1H1KK1M7O0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemDown,"y":1
				},
				"#1H60UGMSN0":{
					"background":color,"y":1,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"gray":{
				/*#{1H1KK26UE3PreCode*/
				$(){
					return !checked;
				},
				/*}#1H1KK26UE3PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H60UGMSN0":{
					"background":color,"alpha":0.3
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":0.3
				}
			},"focus":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0]
				},
				"#1H60UGMSN0":{
					"alpha":1
				},
				"#1H1RPTGKE0":{
					"alpha":1
				},
				/*#{1H1UIV5040Code*/
				$(){
					self.uiEvent=-1;
					checked=true;
				}
				/*}#1H1UIV5040Code*/
			},"blur":{
				"#1H60UGMSN0":{
					"alpha":0.5
				},
				"#1H1RPTGKE0":{
					"alpha":0.5
				},
				/*#{1H1UIVME70Code*/
				$(){
					self.uiEvent=1;
					checked=false;
				}
				/*}#1H1UIVME70Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxMark=self.BoxMark;
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	if(hasCheck){
		cssVO.OnClick=function(){
			let owner=this.parent;
			owner.focusBtn && owner.focusBtn(self);
		};
	}
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnTextIcon.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("带文本图标"):("Icon with Text")),icon:"btn_icon.svg",previewImg:"./IconText.png",
	fixPose:false,initW:40,initH:40,
	"desc":"Icon button with a text footer, a optional message number mark.",
	catalog:"Buttons",
	args: {
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 48
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 48
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg", "initValText": "#appCfg.sharedAssets+\"/lab.svg\""
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"hasMark": {
			"name": "hasMark", "showName": "hasMark", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"hasCheck": {
			"name": "hasCheck", "showName": "hasCheck", "type": "bool", "key": true, "fixed": true, "initVal": true
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Icon button", "localizable": true
		}
	},
	state:{
		markNum:{name:"markNum",type:"int",initVal:1}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","padding","enable","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
		"1H60ULCF00":{"showName":"Overlays"}
	},
	/*#{1H1RPOAH90ExGearInfo*/
	/*}#1H1RPOAH90ExGearInfo*/
};
/*#{1H1RPOAH90EndDoc*/
/*}#1H1RPOAH90EndDoc*/

export default BtnTextIcon;
export{BtnTextIcon};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1RPOAH90",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1KJQ5RK2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1KJQ5RK3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H60TTP5B0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1KJQ5RK4",
//			"attrs": {
//				"w": {
//					"type": "int",
//					"valText": "48"
//				},
//				"h": {
//					"type": "int",
//					"valText": "48"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/lab.svg\""
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"hasMark": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"hasCheck": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Icon button",
//					"localizable": true
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1KJQ5RK5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1KJQ5RK6",
//			"attrs": {
//				"corner": {
//					"type": "int",
//					"valText": "3"
//				},
//				"border": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"text": {
//					"type": "string",
//					"valText": "#text"
//				},
//				"fontSize": {
//					"type": "int",
//					"valText": "#txtSize.small"
//				},
//				"markNum": {
//					"type": "int",
//					"valText": "1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Icon with Text",
//			"localize": {
//				"EN": "Icon with Text",
//				"CN": "带文本图标"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_icon.svg",
//		"gearW": "40",
//		"gearH": "40",
//		"gearCatalog": "Buttons",
//		"description": "Icon button with a text footer, a optional message number mark.",
//		"fixPose": "false",
//		"previewImg": "./IconText.png",
//		"faceTags": {
//			"jaxId": "1H1KJQ5RK7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1Q1R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1SU60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1M7O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE2",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK26UE3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE4",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1UIV5040",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1UJUFF20",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1UIVME70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1UJUFF21",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HBD35G5M0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1KJQ5RK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1KJQ5RK8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "26",
//						"y": "15",
//						"w": "\"\"",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,3,0,3]",
//						"minW": "#w",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KK7EMK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KK7EMK1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#color",
//										"corner": "${state.corner},state",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KK7EML0",
//									"attrs": {
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML2",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML4",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.itemOver"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML6",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.itemDown"
//														},
//														"y": {
//															"type": "length",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML8",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemGray\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										},
//										"1H1UIV5040": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1UJUFF22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1UJUFF23",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1UIV5040",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KK7EMM0",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KK7EMM1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H60UF7OR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H60UMEG90",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "#w-15",
//										"h": "#(h||w)-15",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H60UGMSN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UGMSN1",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "#(h||w)-15",
//														"h": "#(h||w)-15",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "#hasCheck?0.5:1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#color",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"attach": "#icon",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H60UGMSO0",
//													"attrs": {
//														"1H1KK1SU60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSO1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSO2",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#color"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1SU60",
//															"faceTagName": "over"
//														},
//														"1H1KK1M7O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSO3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSO4",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#color"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "1"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1M7O0",
//															"faceTagName": "down"
//														},
//														"1H1KK1Q1R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSO5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSO6",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#color"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "#hasCheck?0.5:1",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1Q1R0",
//															"faceTagName": "up"
//														},
//														"1H1KK26UE3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSP1",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#color"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.3",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK26UE3",
//															"faceTagName": "gray"
//														},
//														"1H1UIVME70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSP2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSP3",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.5",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1UIVME70",
//															"faceTagName": "blur"
//														},
//														"1H1UIV5040": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UGMSP4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UGMSP5",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1UIV5040",
//															"faceTagName": "focus"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H60UGMSP6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H60UGMSP7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H60ULCF00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UMEG91",
//													"attrs": {
//														"type": "hud",
//														"id": "Overlays",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H60UMEG92",
//													"attrs": {
//														"1H1UIV5040": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H6EKCS1L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H6EKCS1L1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1UIV5040",
//															"faceTagName": "focus"
//														},
//														"1H1KK1Q1R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H6EKDAA50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H6EKDAA51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1Q1R0",
//															"faceTagName": "up"
//														},
//														"1H1KK26UE3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I927T6M70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I927T6M71",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK26UE3",
//															"faceTagName": "gray"
//														},
//														"1H1KK1M7O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I927T6M72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I927T6M73",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1M7O0",
//															"faceTagName": "down"
//														},
//														"1H1KK1SU60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I927T6M74",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I927T6M75",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1SU60",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H60UMEG93",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H60UMEG94",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H60UO9EL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UO9EL1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxMark",
//														"position": "Absolute",
//														"x": "100%",
//														"y": "0",
//														"w": "\"\"",
//														"h": "\"\"",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "${!!state.markNum},state",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[2,5,2,5]",
//														"minW": "15",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.error",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "100",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"attach": "#!!hasMark"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1H60UO9EM0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UO9EM1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "\"\"",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor.fontError",
//																		"text": "${state.markNum},state",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "false",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H60UO9EN0",
//																	"attrs": {
//																		"1H1KK26UE3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H60UO9EN3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H60UO9EN4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H1KK26UE3",
//																			"faceTagName": "gray"
//																		},
//																		"1H1KK1SU60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H60UO9EN7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H60UO9EN8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H1KK1SU60",
//																			"faceTagName": "over"
//																		},
//																		"1H1KK1M7O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H60UO9EN9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H60UO9EN10",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H1KK1M7O0",
//																			"faceTagName": "down"
//																		},
//																		"1H1UIV5040": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H6EKCS1L2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H6EKCS1L3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H1UIV5040",
//																			"faceTagName": "focus"
//																		},
//																		"1H1KK1Q1R0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H6EKDAA52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H6EKDAA53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H1KK1Q1R0",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H60UO9EN11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H60UO9EN12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1H60UO9EN13",
//													"attrs": {
//														"1H1KK26UE3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UO9EN16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UO9EN17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK26UE3",
//															"faceTagName": "gray"
//														},
//														"1H1KK1SU60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UO9EO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UO9EO1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1SU60",
//															"faceTagName": "over"
//														},
//														"1H1KK1M7O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H60UO9EO2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H60UO9EO3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1M7O0",
//															"faceTagName": "down"
//														},
//														"1H1UIV5040": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H6EKCS1L4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H6EKCS1L5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1UIV5040",
//															"faceTagName": "focus"
//														},
//														"1H1KK1Q1R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H6EKDAA54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H6EKDAA55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1KK1Q1R0",
//															"faceTagName": "up"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H60UO9EO4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H60UO9EO5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H60UMEG95",
//									"attrs": {
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H60UMEG96",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UMEG97",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H60UMEG98",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UMEG99",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H60UMEG910",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H60UMEG911",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										},
//										"1H1UIV5040": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H6EKCS1L6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H6EKCS1L7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1UIV5040",
//											"faceTagName": "focus"
//										},
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H6EKDAA56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H6EKDAA57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H60UMEG916",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H60UMEG917",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1RPTGKE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1RQ1M110",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Relative",
//										"x": "50%",
//										"y": "0",
//										"w": "\"\"",
//										"h": "\"\"",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "#hasCheck?0.5:1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "#[Math.floor(w/15),0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#color",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1RQ1M111",
//									"attrs": {
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1RQ1M112",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1RQ1M113",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#color"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.3",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										},
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1RQ2O590",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1RQ2O591",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#color"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1RQ2O592",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1RQ2O593",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#color"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "#hasCheck?0.5:1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1RQ2O594",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1RQ2O595",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#color"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1UIVME70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1UJUFF210",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1UJUFF211",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1UIVME70",
//											"faceTagName": "blur"
//										},
//										"1H1UIV5040": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1UJUFF212",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1UJUFF213",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1UIV5040",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1RQ1M114",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1RQ1M115",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1KJQ5RK9",
//					"attrs": {
//						"1H1KK26UE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1UMD5U716",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1UMD5U717",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK26UE3",
//							"faceTagName": "gray"
//						},
//						"1H1KK1SU60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H60UMEGA4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H60UMEGA5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1SU60",
//							"faceTagName": "over"
//						},
//						"1H1KK1M7O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H60UMEGA6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H60UMEGA7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1M7O0",
//							"faceTagName": "down"
//						},
//						"1H1UIV5040": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H6EKCS1L8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H6EKCS1L9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1UIV5040",
//							"faceTagName": "focus"
//						},
//						"1H1KK1Q1R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H6EKDAA58",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H6EKDAA59",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1Q1R0",
//							"faceTagName": "up"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1KJQ5RK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1KJQ5RK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1KJQ5RK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "markNum"
//				}
//			]
//		}
//	}
//}