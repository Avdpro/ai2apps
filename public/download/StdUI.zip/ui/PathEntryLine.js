//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "./BtnCheck.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1I8JCA41H0StartDoc*/
import {tabFS} from "/@tabos";
import {readPath,applyFileMenu,applyFileDrag,applyFileDrop} from "../FileUtils.js";
/*}#1I8JCA41H0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let PathEntryLine=function(viewBox,treeNode,entryObj,indent,options){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnCheck,txtName,txtFileSize;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let isFocused=false;
	let isSelect=false;
	
	/*#{1H1O4B7OK1LocalVals*/
	let app,path;
	path=entryObj.path;
	app=VFACT.app;
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":options.fontSize||txtSize.smallPlus,"icon":appCfg.sharedAssets+(entryObj.disk?"/disk.svg":(entryObj.dir?"/folder.svg":"/file.svg")),"fileSize":entryObj.size,
		"path":entryObj.path,"pathEntry":entryObj,"isExpand":false,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":options.height||24,"cursor":"pointer","padding":[0,5,0,5+indent*options.indentSize],
		"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","enable":entryObj.enable===false?false:true,"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"treeNode":treeNode,"entry":entryObj,"path":entryObj.path,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
			},
			{
				"hash":"1HAAHR1A50",
				"type":BtnCheck((options.height||24)-6,"",entryObj.checked,false),"id":"BtnCheck","position":"relative","x":0,"y":0,"margin":[0,2,0,0],"attached":!!options.checkBox,
			},
			{
				"hash":"1I8JDJIIC0",
				"type":BtnIcon("front",options.fontSize,0,appCfg.sharedAssets+"/zhankai.svg",null),"id":"BtnExpand","position":"relative","x":options.fontSize*0.5,
				"y":options.fontSize*0.5,"attached":options.expandBtn && entryObj.dir,"anchorX":1,"anchorY":1,
				"OnClick":function(event){
					/*#{1I8NL0B6J0FunctionBody*/
					if(state.isExpand){
						self.collapse();
					}else{
						self.expand();
					}
					/*}#1I8NL0B6J0FunctionBody*/
				},
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":"","h":options.iconSize||((options.height||24)-4),"uiEvent":-1,"margin":[0,2,0,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":options.color||cfgColor.fontBody,"maskImage":$P(()=>(state.icon),state),"aspect":"1",
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":options.color||cfgColor.fontBody,"text":entryObj.name,"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"flex":true,
			},
			{
				"hash":"1I8JF4C5K0",
				"type":"text","id":"TxtFileSize","position":"relative","x":"","y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":options.color||cfgColor.fontBody,"text":entryObj.size>=0?(entryObj.size.toLocaleString()):"","fontSize":txtSize.small,"fontWeight":"normal",
				"fontStyle":"normal","textDecoration":"","alignV":1,"attached":options.fileSize && (!entryObj.dir),
			}
		],
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1O4B7OK1SetfontSize*/
			/*}#1H1O4B7OK1SetfontSize*/
		},
		get $$path(){return state["path"]},
		set $$path(v){
			state["path"]=v;
			/*#{1H1O4B7OK1Setpath*/
			/*}#1H1O4B7OK1Setpath*/
		},
		get $$pathEntry(){return state["pathEntry"]},
		set $$pathEntry(v){
			state["pathEntry"]=v;
			/*#{1H1O4B7OK1SetpathEntry*/
			/*}#1H1O4B7OK1SetpathEntry*/
		},
		get $$isExpand(){return state["isExpand"]},
		set $$isExpand(v){
			state["isExpand"]=v;
			/*#{1H1O4B7OK1SetisExpand*/
			/*}#1H1O4B7OK1SetisExpand*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1O6SN0K0PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6SN0K0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"over":{
				/*#{1H1O6SMEQ0PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6SMEQ0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				/*#{1H1O6TNKJ2PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6TNKJ2PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				/*#{1H1O6TNKJ4PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6TNKJ4PreCode*/
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"focus":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["gntFocus"]
				},
				/*BtnCheck*/"#1HAAHR1A50":{
					"color":[0,0,0,1]
				},
				/*#{1I8JCALLE0Code*/
				$(){
					isFocused=true;
				}
				/*}#1I8JCALLE0Code*/
			},"blur":{
				/*#{1I8JCAQ1N0PreCode*/
				$(){
					isFocused=false;
					isSelect=false;
					/*if(isSelect){
						self.showFace("select");
						return false;
					}*/
				},
				/*}#1I8JCAQ1N0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				},
				/*#{1I8JCAQ1N0Code*/
				/*}#1I8JCAQ1N0Code*/
			},"select":{
				/*#{1I8JCBPMG0PreCode*/
				$(){
					isSelect=true;
					if(isFocused){
						return false;
					}
				},
				/*}#1I8JCBPMG0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				},
				/*#{1I8JCBPMG0Code*/
				$(){
					isSelect=true;
				},
				/*}#1I8JCBPMG0Code*/
			},"!select":{
				/*#{1I8JEIOMF0PreCode*/
				$(){
					isSelect=false;
					if(isFocused){
						return false;
					}
				},
				/*}#1I8JEIOMF0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"empty":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"enable":true,"alpha":0.3
				}
			},"!empty":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"enable":true,"alpha":1
				}
			},"expand":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"rotate":90
				},
				/*#{1I8JDO4IK0Code*/
				$(){
					state.isExpand=true;
				}
				/*}#1I8JDO4IK0Code*/
			},"collapse":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"rotate":0
				},
				/*#{1I8JDOBVF0Code*/
				$(){
					state.isExpand=false;
				}
				/*}#1I8JDOBVF0Code*/
			},"subFocus":{
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["subFocus"]
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnCheck=self.BtnCheck;txtName=self.TxtName;txtFileSize=self.TxtFileSize;
			/*#{1H1O4B7OK1Create*/
			this.preferW=this.webObj.scrollWidth;
			if(entryObj.check){
				this.preferW+=25;
			}
			if(options.fileMenu){
				applyFileMenu(this,options);
			}else{
				self.webObj.addEventListener('contextmenu', e => {
					e.preventDefault();
				});
			}
			if(options.allowDrag && (!entryObj.disk)){
				applyFileDrag(this,viewBox);
			}
			if(options.allowDrop && entryObj.dir){
				self.allowDrop=true;
				applyFileDrop(this,options);
			}
			if(entryObj.dir){
				callAfter(()=>{
					tabFS.getEntries(entryObj.path).then((list)=>{
						let cnt;
						if(!self.webObj){
							return;
						}
						if(list===null){
							tabFS.del(entryObj.path,true,true);
							viewBox.deleteDirNode(treeNode);
							//self.showFace("empty");
							return;
						}
						if(options.dirOnly){
							if(!list || !list.length || !list.some((item)=>{return item.dir})){
								self.showFace("empty");
								return;
							}
						}else{
							if(!list || !list.length){
								self.showFace("empty");
								return;
							}
						}
					});
				},100);
			}
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.rename=async function(newName){
		/*#{1I8LTASUD0Start*/
		txtName.text=newName;
		state.entryPath=entryObj.path;
		/*}#1I8LTASUD0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.expand=async function(){
		/*#{1I8NKV6H60Start*/
		if(options.expand){
			self.enable=false;
			await options.expand(this,treeNode);
			self.showFace("expand");
			self.enable=true;
		}else{
			self.enable=false;
			await viewBox.expandDirNode(treeNode);
			self.showFace("expand");
			self.enable=true;
		}
		/*}#1I8NKV6H60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.collapse=async function(){
		/*#{1I8NKVKRO0Start*/
		if(options.collapse){
			self.enable=false;
			await options.collapse(this,treeNode);
			self.showFace("collapse");
			self.enable=true;
		}else{
			self.enable=false;
			await viewBox.collapseDirNode(treeNode);
			self.showFace("collapse");
			self.enable=true;
		}
		/*}#1I8NKVKRO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnDropFile=async function(files){
		/*#{1I8U5DTBB0Start*/
		app.showTip(self,(($ln==="CN")?(`${files.length}个文件已加入`):/*EN*/(`${files.length} file${files.length>0?"s":""} dropped.`)));
		/*if(options.OnDropFile){
			options.OnDropFile(files);
		}*/
		/*}#1I8U5DTBB0Start*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	cssVO.constructor=PathEntryLine;
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

//----------------------------------------------------------------------------
PathEntryLine.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1O4B7OK1PreAISpot*/
	/*}#1H1O4B7OK1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("路径对象行"):("Path entry line"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1O4B7OK1PostAISpot*/
	/*}#1H1O4B7OK1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
PathEntryLine.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("路径对象行"):("Path entry line")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:24,
	catalog:"Buttons",
	args: {
		"viewBox": {
			"name": "viewBox", "showName": "viewBox", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"treeNode": {
			"name": "treeNode", "showName": "treeNode", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"entryObj": {
			"name": "entryObj", "showName": "entryObj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"text": "Object", "name": "disk.json", "path": "/tabos/disk.json", "dir": 0, "size": 1023023
			}, 
			"initValText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
		}, 
		"indent": {
			"name": "indent", "showName": "indent", "type": "int", "key": true, "fixed": true, "initVal": 1
		}, 
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 14
					}, 
					"allowDrop": {
						"name": "allowDrop", "showName": "allowDrop", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"allowDrag": {
						"name": "allowDrag", "showName": "allowDrag", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"height": {
						"name": "height", "showName": "height", "type": "int", "key": true, "fixed": true, "initVal": 24
					}, 
					"iconSize": {
						"name": "iconSize", "showName": "iconSize", "type": "number", "key": true, "fixed": true, "initVal": 20
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"checkBox": {
						"name": "checkBox", "showName": "checkBox", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"expandBtn": {
						"name": "expandBtn", "showName": "expandBtn", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"indentSize": {
						"name": "indentSize", "showName": "indentSize", "type": "int", "key": true, "fixed": true, "initVal": 15
					}, 
					"fileSize": {
						"name": "fileSize", "showName": "fileSize", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"fileMenu": {
						"name": "fileMenu", "showName": "fileMenu", "type": "bool", "key": true, "fixed": true, "initVal": true
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		fontSize:{name:"fontSize",type:"int",initVal:14,editType:"fontSize"},
		path:{name:"path",type:"string",initVal:"/tabos/disk.json"},
		pathEntry:{name:"pathEntry",type:"string",initVal:{"text":"Object","name":"disk.json","path":"/tabos/disk.json","dir":0,"size":1023023}},
		isExpand:{name:"isExpand",type:"bool",initVal:false}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:["up","over","down","gray","focus","blur","select","!select","empty","!empty","expand","collapse","subFocus"],
	subContainers:{
	},
	/*#{1I8JCA41H0ExGearInfo*/
	/*}#1I8JCA41H0ExGearInfo*/
};
/*#{1I8JCA41H0EndDoc*/
/*}#1I8JCA41H0EndDoc*/

export default PathEntryLine;
export{PathEntryLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1I8JCA41H0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1O4B7OL0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1O4B7OL1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5VFJH9A0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1O4B7OL2",
//			"attrs": {
//				"viewBox": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"treeNode": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"entryObj": {
//					"type": "auto",
//					"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
//				},
//				"indent": {
//					"type": "int",
//					"valText": "1"
//				},
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I8JCGLTP0",
//					"attrs": {
//						"fontSize": {
//							"type": "int",
//							"valText": "14"
//						},
//						"allowDrop": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"allowDrag": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"iconSize": {
//							"type": "number",
//							"valText": "20"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"checkBox": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"expandBtn": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						},
//						"fileSize": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"fileMenu": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1O4B7OL3",
//			"attrs": {
//				"isFocused": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"isSelect": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1O4B7OL4",
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#options.fontSize||txtSize.smallPlus",
//					"editType": "fontSize"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+(entryObj.disk?\"/disk.svg\":(entryObj.dir?\"/folder.svg\":\"/file.svg\"))"
//				},
//				"fileSize": {
//					"type": "int",
//					"valText": "#entryObj.size"
//				},
//				"path": {
//					"type": "string",
//					"valText": "#entryObj.path"
//				},
//				"pathEntry": {
//					"type": "string",
//					"valText": "#entryObj"
//				},
//				"isExpand": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LTASUD0",
//					"attrs": {
//						"id": "rename",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LTB69F0",
//							"attrs": {
//								"newName": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LTB69F1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LTB69F2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NKV6H60",
//					"attrs": {
//						"id": "expand",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "140",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NKVVL40",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NKVVL41",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NKVVL42",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NKVKRO0",
//					"attrs": {
//						"id": "collapse",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "220",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NKVVL43",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NKVVL44",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NKVVL45",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8U5DTBB0",
//					"attrs": {
//						"id": "OnDropFile",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "315",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8U5EOT00",
//							"attrs": {
//								"files": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8U5EOT01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8U5EOT02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Path entry line",
//			"localize": {
//				"EN": "Path entry line",
//				"CN": "路径对象行"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "24",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1O4B7OL5",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SN0K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SMEQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ3",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ5",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCALLE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP1",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCAQ1N0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP2",
//							"attrs": {}
//						}
//					}
//				},
//				"select": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCBPMG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP3",
//							"attrs": {}
//						}
//					}
//				},
//				"!select": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JEIOMF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JEJC910",
//							"attrs": {}
//						}
//					}
//				},
//				"empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCC7TB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP4",
//							"attrs": {}
//						}
//					}
//				},
//				"!empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCCITS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP5",
//							"attrs": {}
//						}
//					}
//				},
//				"expand": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JDO4IK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JDP1NQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"collapse": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JDOBVF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JDP1NR0",
//							"attrs": {}
//						}
//					}
//				},
//				"subFocus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I94OT6950",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I94OT9BM0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAHAJUP0",
//			"attrs": {
//				"CheckBox": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCTKRA0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:false,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"Folder": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCTKRA1",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:1,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"FileWithSize": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCV44M0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"FileWithoutSize": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCVU550",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1O4B7OK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1O4B7OL6",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "#options.height||24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "#[0,5,0,5+indent*options.indentSize]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "#entryObj.enable===false?false:true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O6BJ290",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6PGCJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O6PGCJ1",
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ7",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ9",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"gntFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG21",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"subFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O6PGCJ2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O6PGCJ3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1LD0QTJ0",
//							"jaxId": "1HAAHR1A50",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HAAHR1A51",
//									"attrs": {
//										"size": "#(options.height||24)-6",
//										"text": "",
//										"checked": "#entryObj.checked",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HAAHR1A52",
//									"attrs": {
//										"type": "#null#>BtnCheck((options.height||24)-6,\"\",entryObj.checked,false)",
//										"id": "BtnCheck",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,2,0,0]",
//										"attach": "#!!options.checkBox"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HAAHR1A53",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JD740T6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JD740T7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JESTFF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JESTFF1",
//													"attrs": {
//														"color": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,1.00]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LF1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94R79820",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94R79821",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAAHR1A54",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAAHR1A55",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HAAHR1A56",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1I8JDJIIC0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I8JDNVDK0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "#options.fontSize",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/zhankai.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1I8JDNVDK1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",options.fontSize,0,appCfg.sharedAssets+\"/zhankai.svg\",null)",
//										"id": "BtnExpand",
//										"position": "relative",
//										"x": "#options.fontSize*0.5",
//										"y": "#options.fontSize*0.5",
//										"display": "On",
//										"face": "",
//										"attach": "#options.expandBtn && entryObj.dir",
//										"anchorH": "Center",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8JDNVDK2",
//									"attrs": {
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO5",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO7",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q27",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q29",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.3",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LF3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94R79824",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94R79825",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8JDNVDK3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I8NL0B6J0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I8NL1PQH4",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I8JDNVDK4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I8JDNVDK5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O5PAKH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "#options.iconSize||((options.height||24)-4)",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,2,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#options.color||cfgColor.fontBody",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "true",
//										"maskImage": "${state.icon},state",
//										"aspect": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG1",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LG1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94R79828",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94R79829",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1O5T0HD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#options.color||cfgColor.fontBody",
//										"text": "#entryObj.name",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG5",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q41",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LG2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LG3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94R798212",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94R798213",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I8JF4C5K0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JF4C5K1",
//									"attrs": {
//										"type": "text",
//										"id": "TxtFileSize",
//										"position": "relative",
//										"x": "",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#options.color||cfgColor.fontBody",
//										"text": "#entryObj.size>=0?(entryObj.size.toLocaleString()):\"\"",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"attach": "#options.fileSize && (!entryObj.dir)"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8JF4C5L0",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF4C5L3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF4C5L4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF4C5L5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF4C5L6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF4C5L7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF4C5L8",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF4C5L13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF4C5L14",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LG4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LG5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94R798216",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94R798217",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8JF4C5L15",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8JF4C5L16",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1O4B7OL7",
//					"attrs": {
//						"1H1O6SMEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O6TNKJ16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6TNKJ17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SMEQ0",
//							"faceTagName": "over"
//						},
//						"1H1O6SN0K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SN0K0",
//							"faceTagName": "up"
//						},
//						"1H1O6TNKJ2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU19",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ2",
//							"faceTagName": "down"
//						},
//						"1H1O6TNKJ4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU21",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ4",
//							"faceTagName": "gray"
//						},
//						"1I8JDO4IK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JDT6HO12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JDT6HO13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JDO4IK0",
//							"faceTagName": "expand"
//						},
//						"1I8JCBPMG0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JEF06Q46",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JEF06Q47",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCBPMG0",
//							"faceTagName": "select"
//						},
//						"1I8JEIOMF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JF1QG30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JF1QG31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JEIOMF0",
//							"faceTagName": "!select"
//						},
//						"1I8JCAQ1N0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8NCO6LG6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8NCO6LG7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCAQ1N0",
//							"faceTagName": "blur"
//						},
//						"1I8JCALLE0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I94PHCSE12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I94PHCSE13",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCALLE0",
//							"faceTagName": "focus"
//						},
//						"1I8JDOBVF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I94PHCSE14",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I94PHCSE15",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JDOBVF0",
//							"faceTagName": "collapse"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1O4B7OL8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1O4B7OL9",
//					"attrs": {
//						"treeNode": {
//							"type": "auto",
//							"valText": "#treeNode"
//						},
//						"entry": {
//							"type": "auto",
//							"valText": "#entryObj"
//						},
//						"path": {
//							"type": "string",
//							"valText": "#entryObj.path"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O4B7OL10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "fontSize"
//				},
//				{
//					"type": "string",
//					"valText": "path"
//				},
//				{
//					"type": "string",
//					"valText": "pathEntry"
//				},
//				{
//					"type": "string",
//					"valText": "isExpand"
//				}
//			]
//		}
//	}
//}