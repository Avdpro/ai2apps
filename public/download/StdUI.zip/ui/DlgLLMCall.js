//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "./BtnText.js";
/*#{1IIK75VL90StartDoc*/
import {BoxLllmMessage} from "./BoxLllmMessage.js";
import {ChatSession} from "/@aichat/chatsession.js";
/*}#1IIK75VL90StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgLLMCall=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,boxCode,boxMessages,boxButtons,btnExec,btnClose;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO,callLog,options,messages;
	app=window.tabOSApp;
	dlgVO=null;
	callLog=null;
	options=null;
	messages=null;
	let cm=null;
	let cmDoc=null;
	let curCode="";
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":"Call LLM",
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":"50%","w":600,"h":"","anchorX":1,"anchorY":1,"padding":10,"minW":"","minH":"","maxW":"90%","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1IIKG5LGK0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":500,"overflow":"auto","padding":5,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1IIKFFUV50",
						"type":"box","id":"BoxOptions","position":"relative","x":0,"y":0,"w":"100%","h":240,"margin":[0,0,10,0],"styleClass":"","background":cfgColor["body"],
						"border":1,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1IIKFI0H40",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":20,"padding":[0,5,0,5],"styleClass":"","background":cfgColor["secondary"],"contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1IIKFINML0",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","styleClass":"","color":cfgColor["fontSecondary"],"text":"Options","fontSize":txtSize.smallPlus,
										"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									}
								],
							},
							{
								"hash":"1IIKFM9270",
								"type":"hud","id":"BoxCode","position":"relative","x":2,"y":0,"w":">calc(100% - 4px)","h":">calc(100% - 22px)","styleClass":"",
							}
						],
					},
					{
						"hash":"1IIKFPQFC0",
						"type":"hud","id":"BoxMessages","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":30,"styleClass":"",
					}
				],
			},
			{
				"hash":"1IIKG5V3Q0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("success",120,24,(($ln==="CN")?("调用LLM"):("Call LLM")),false,""),"id":"BtnExec","position":"relative","x":0,"y":"50%","anchorY":1,
						"margin":[0,50,0,0],
						"OnClick":function(event){
							self.makeCall(this,event);
						},
					},
					{
						"hash":"1IIKFQIGN0",
						"type":BtnText("primary",80,24,(($ln==="CN")?("关闭"):("Close")),false,""),"id":"BtnClose","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1IIKFQIGN5FunctionBody*/
							self.close();
							/*}#1IIKFQIGN5FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxCode=self.BoxCode;boxMessages=self.BoxMessages;boxButtons=self.BoxButtons;btnExec=self.BtnExec;btnClose=self.BtnClose;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showOpts=async function(){
		/*#{1IIKG9KBM0Start*/
		let pos,mode,code;
		code=JSON.stringify(options,null,"\t");
		if(cm){
			boxCode.webObj.innerHTML="";
			cm=null;
		}
		if(!window.CodeMirror){
			//import CodeMirror
			await VFACT.appendScript("/@codemirror/lib/codemirror.js");
			await VFACT.appendCSS("/@codemirror/lib/codemirror.css");
		}
		curCode=code;
		mode="javascript";
		await VFACT.appendScript("/@codemirror/mode/javascript.js");
		await VFACT.appendCSS("/@codemirror/mode/javascript.css");
		//Create code mirror;
		cm=CodeMirror(boxCode.webObj, {
			value:code,
			mode:mode,
			undoDepth:5
		});
		cmDoc=cm.getDoc();
		/*}#1IIKG9KBM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showMessages=async function(){
		/*#{1IIKGA0DE0Start*/
		let msg,css;
		boxMessages.clearChildren();
		for(msg of messages){
			css=BoxLllmMessage(app,msg,self);
			boxMessages.appendNewChild(css);
		}
		/*}#1IIKGA0DE0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doAddMsg=function(block,btn,message,code){
		/*#{1IIKGA7MT0Start*/
		let msg,index;
		message=message||{"role":"user","content":""};
		if(block){
			msg=block.msg;
			index=messages.indexOf(msg);
			if(index>=0){
				messages.splice(index+1,0,message);
				return boxMessages.insertNewBefore(BoxLllmMessage(app,message,self,code),block.nextSibling);
			}
		}
		messages.push(message);
		return boxMessages.appendNewChild(BoxLllmMessage(app,message,self,code));
		/*}#1IIKGA7MT0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doCloneMsg=function(block,btn){
		/*#{1IIKGBUH10Start*/
		let msg,message,index;
		msg=block.msg;
		message={...msg};
		index=messages.indexOf(msg);
		if(index>=0){
			boxMessages.insertNewBefore(BoxLllmMessage(app,message,self),block.nextSibling);
		}
		return block;
		/*}#1IIKGBUH10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doDelMsg=function(block){
		/*#{1IIKGCGHB0Start*/
		let msg,index;
		msg=block.msg;
		if(!window.confirm((($ln==="CN")?("您确定要删除此消息吗?"):/*EN*/("Are you sure to delete this message?")))){
			return;
		}
		index=messages.indexOf(msg);
		if(index>=0){
			messages.splice(index,1);
		}
		boxMessages.removeChild(block);
		/*}#1IIKGCGHB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.moveMsgDown=function(block){
		/*#{1IIKGCQI20Start*/
		let msg,index,next;
		msg=block.msg;
		index=messages.indexOf(msg);
		if(index>=0 && index<(messages.length-1)){
			messages.splice(index,1);
			messages.splice(index+1,0,msg);
			next=block.nextSibling;
			next.hold();
			boxMessages.removeChild(next);
			boxMessages.insertBefore(next,block);
		}
		/*}#1IIKGCQI20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.moveMsgUp=function(block){
		/*#{1IIKGD3RI0Start*/
		let msg,index,pre;
		msg=block.msg;
		index=messages.indexOf(msg);
		if(index>0){
			messages.splice(index,1);
			messages.splice(index-1,0,msg);
			pre=block.previousSibling;
			block.hold();
			boxMessages.removeChild(block);
			boxMessages.insertBefore(block,pre);
		}
		/*}#1IIKGD3RI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.aboutChangeDoc=async function(){
		/*#{1IIKGFQKD0Start*/
		/*}#1IIKGFQKD0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.msgChanged=async function(){
		/*#{1IIKGGRDI0Start*/
		/*}#1IIKGGRDI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.askToken=async function(){
		/*#{1IIKGI6I80Start*/
		/*}#1IIKGI6I80Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showCode=async function(){
		/*#{1IIKGK8720Start*/
		/*}#1IIKGK8720Start*/
	};
	//------------------------------------------------------------------------
	cssVO.makeCall=async function(){
		/*#{1IIKHDM300Start*/
		let callOpts,res;
		try{
			callOpts=cmDoc.getValue();
			callOpts=JSON.parse(callOpts);
		}catch(err){
			window.alert((($ln==="CN")?("解析Options错误。"):/*EN*/("Parse options error.")));
			return;
		}
		btnExec.enable=false;
		try{
			let result;
			res=await ChatSession.execLLMCall(callOpts,messages.map((msg)=>{return {role:msg.role,content:msg.content};}));
			result=res.content.trim();
			if(result.startsWith("{") && result.endsWith("}")){
				try{
					let vo;
					vo=JSON.parse(result);
					result=JSON.stringify(vo,null,"\t");
				}catch(err){
				}
			}
			self.doAddMsg(null,null,{role:"assistant",content:result},true);
		}catch(err){
			self.doAddMsg(null,null,{role:"error",content:""+err});
		}
		btnExec.enable=true;
		/*}#1IIKHDM300Start*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		state.title=vo.title||(($ln==="CN")?("调用LLM"):/*EN*/("Call LLM"))
		callLog=vo.log;
		options=callLog.options;
		messages=callLog.messages;
		if(callLog.result){
			messages=[
				...messages,
				{role:"assistant",content:callLog.result}
			];
		}
		self.showOpts();
		self.showMessages();
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	cssVO.constructor=DlgLLMCall;
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

//----------------------------------------------------------------------------
DlgLLMCall.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1T7ISV51PreAISpot*/
	/*}#1H1T7ISV51PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("标准对话框"):("Standard Dialog"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1T7ISV51PostAISpot*/
	/*}#1H1T7ISV51PostAISpot*/
	return exposeVO;
};

/*#{1IIK75VL90EndDoc*/
/*}#1IIK75VL90EndDoc*/

export default DlgLLMCall;
export{DlgLLMCall};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IIK75VL90",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Call LLM",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKG9KBM0",
//					"attrs": {
//						"id": "showOpts",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGA0DE0",
//					"attrs": {
//						"id": "showMessages",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "165",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BP3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BP4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BP5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGA7MT0",
//					"attrs": {
//						"id": "doAddMsg",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BP6",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": ""
//								},
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								},
//								"message": {
//									"type": "auto",
//									"valText": ""
//								},
//								"code": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BP7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BP8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGBUH10",
//					"attrs": {
//						"id": "doCloneMsg",
//						"label": "New AI Seg",
//						"x": "360",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGCFP90",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": ""
//								},
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGCFP91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGCFP92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGCGHB0",
//					"attrs": {
//						"id": "doDelMsg",
//						"label": "New AI Seg",
//						"x": "610",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGCGHB1",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGCGHB2",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGCGHB3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGCQI20",
//					"attrs": {
//						"id": "moveMsgDown",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGCQI21",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGCQI22",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGCQI23",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGD3RI0",
//					"attrs": {
//						"id": "moveMsgUp",
//						"label": "New AI Seg",
//						"x": "360",
//						"y": "365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGD3RI1",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGD3RI2",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGD3RI3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGFQKD0",
//					"attrs": {
//						"id": "aboutChangeDoc",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "475",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BP9",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BP10",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BP11",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGGRDI0",
//					"attrs": {
//						"id": "msgChanged",
//						"label": "New AI Seg",
//						"x": "360",
//						"y": "475",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGGRDJ0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGGRDJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGGRDJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGI6I80",
//					"attrs": {
//						"id": "askToken",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "565",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BP12",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BP13",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BP14",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKGK8720",
//					"attrs": {
//						"id": "showCode",
//						"label": "New AI Seg",
//						"x": "360",
//						"y": "565",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKGL6BQ0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKGL6BQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKGL6BQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKHDM300",
//					"attrs": {
//						"id": "makeCall",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "675",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKHE0690",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKHE0691",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIKHE0692",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I8OEIDG90",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "600",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "90%",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIKG5LGK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKG5LGK1",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIKG5LGL0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIKG5LGL1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKG5LGL2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "500",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IIKFFUV50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKFKJBM0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxOptions",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "240",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,10,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IIKFI0H40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIKFKJBM1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,5,0,5]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"secondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1IIKFINML0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIKFKJBM2",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontSecondary\"]",
//																						"text": "Options",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IIKFKJBM3",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1IIKFKJBM4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IIKFKJBM5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IIKFKJBM6",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IIKFKJBM7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIKFKJBM8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IIKFM9270",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIKFTB4D0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCode",
//																		"position": "Relative",
//																		"x": "2",
//																		"y": "0",
//																		"w": "100%-4",
//																		"h": "100%-22",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIKFTB4D1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IIKFTB4D2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIKFTB4D3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IIKFKJBM9",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKFKJBM10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKFKJBM11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IIKFPQFC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKFTB4D4",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMessages",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKFTB4D5",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKFTB4D6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKFTB4D7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIKG5V3Q0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKG5V3Q1",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIKG5V3R0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIKG5V3R1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKG5V3R2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "success",
//														"w": "120",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Call LLM",
//															"localize": {
//																"EN": "Call LLM",
//																"CN": "调用LLM"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"success\",120,24,(($ln===\"CN\")?(\"调用LLM\"):(\"Call LLM\")),false,\"\")",
//														"id": "BtnExec",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,50,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIKHDM300"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1IIKFQIGN0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKFQIGN1",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Close",
//															"localize": {
//																"EN": "Close",
//																"CN": "关闭"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKFQIGN2",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,(($ln===\"CN\")?(\"关闭\"):(\"Close\")),false,\"\")",
//														"id": "BtnClose",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKFQIGN3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKFQIGN4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKFQIGN5",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKFQIGN6",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKFQIGN7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IIKFQIGN8",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IIKFQIGN9",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}