//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1IIKNSD0L0StartDoc*/
/*}#1IIKNSD0L0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxLllmMessage=function(app,msg,ui,code){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtRole,edText,boxCode;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IIKNSD0L1LocalVals*/
	let cm=null,cmDoc=null;;
	/*}#1IIKNSD0L1LocalVals*/
	
	/*#{1IIKNSD0L1PreState*/
	/*}#1IIKNSD0L1PreState*/
	/*#{1IIKNSD0L1PostState*/
	/*}#1IIKNSD0L1PostState*/
	cssVO={
		"hash":"1IIKNSD0L1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"msg":msg,
		children:[
			{
				"hash":"1IIKNUHAU0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":24,"padding":[0,5,0,5],"styleClass":"","background":cfgColor["secondary"],"contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1IIKO4TL80",
						"type":BtnIcon(appCfg.color.fontSecondary,22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnRole","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
						"OnClick":function(event){
							self.chooseRole(this,event);
						},
					},
					{
						"hash":"1IIKNVEON0",
						"type":"text","id":"TxtRole","position":"relative","x":0,"y":0,"w":"","h":"","styleClass":"","color":cfgColor["fontSecondary"],"text":msg.role,"fontSize":txtSize.smallPlus,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
					}
				],
			},
			{
				"hash":"1IIKOPV7U0",
				"type":"memo","id":"EdText","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":50,"maxH":200,"styleClass":"","text":msg.content,"color":[0,0,0],
				"fontSize":txtSize.small,"outline":0,"borderColor":cfgColor["fontBody"],
				"OnChange":function(){
					/*#{1IIKQE68F0FunctionBody*/
					msg.content=this.text;
					/*}#1IIKQE68F0FunctionBody*/
				},
				"OnInput":function(){
					/*#{1IIKQECOI0FunctionBody*/
					msg.content=this.text;
					/*}#1IIKQECOI0FunctionBody*/
				},
				"OnBlur":function(event){
					/*#{1IIKQEV8C0FunctionBody*/
					msg.content=this.text;
					/*}#1IIKQEV8C0FunctionBody*/
				},
			},
			{
				"hash":"1IIKRUN3Q0",
				"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":240,"display":0,"styleClass":"",
			},
			{
				"hash":"1IIKOEE1D0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":24,"padding":[0,5,0,5],"styleClass":"","background":cfgColor["menuBG"],"border":[0,0,1,0],
				"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsAlign":1,"subAlign":2,
				children:[
					{
						"hash":"1IIKROPAU0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/tab_css.svg",null),"id":"BtnCodeMode","position":"relative","x":0,"y":0,"padding":2,
						"OnClick":function(event){
							self.showCode(this,event);
						},
					},
					{
						"hash":"1IIKRNU3Q0",
						"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"100%","styleClass":"","flex":true,
					},
					{
						"hash":"1IIKP1JQT0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddMessage","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1IIKPITEM0FunctionBody*/
							ui.doAddMsg(self,this);
							/*}#1IIKPITEM0FunctionBody*/
						},
					},
					{
						"hash":"1IIKP2ME90",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowup.svg",null),"id":"BtnMoveUp","position":"relative","x":0,"y":0,"padding":2,
						"OnClick":function(event){
							/*#{1IIKPITEM1FunctionBody*/
							ui.moveMsgUp(self,this);
							/*}#1IIKPITEM1FunctionBody*/
						},
					},
					{
						"hash":"1IIKP39960",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowdown.svg",null),"id":"BtnMoveDown","position":"relative","x":0,"y":0,"padding":2,
						"OnClick":function(event){
							/*#{1IIKPITEM2FunctionBody*/
							ui.moveMsgDown(self,this);
							/*}#1IIKPITEM2FunctionBody*/
						},
					},
					{
						"hash":"1IIKP3ADV0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDelMessage","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1IIKPITEM3FunctionBody*/
							ui.doDelMsg(self,this);
							/*}#1IIKPITEM3FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1IIKNSD0L1ExtraCSS*/
		/*}#1IIKNSD0L1ExtraCSS*/
		faces:{
			"text":{
				/*EdText*/"#1IIKOPV7U0":{
					"display":1
				},
				/*BoxCode*/"#1IIKRUN3Q0":{
					"display":0
				},
				/*BtnCodeMode*/"#1IIKROPAU0":{
					"enable":true
				}
			},"code":{
				/*EdText*/"#1IIKOPV7U0":{
					"display":0
				},
				/*BoxCode*/"#1IIKRUN3Q0":{
					"display":1
				},
				/*BtnCodeMode*/"#1IIKROPAU0":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtRole=self.TxtRole;edText=self.EdText;boxCode=self.BoxCode;
			/*#{1IIKNSD0L1Create*/
			if(code || msg.role==="system"){
				self.showCode();
			}
			/*}#1IIKNSD0L1Create*/
		},
		/*#{1IIKNSD0L1EndCSS*/
		/*}#1IIKNSD0L1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseRole=async function(sender){
		/*#{1IIKQ18EM0Start*/
		/*}#1IIKQ18EM0Start*/
		{
			let $items,$item;
			$items=[
				{id:"assistant",text:"assistant"},
				{id:"user",text:"user"},
				{id:"system",text:"system"}
			];
			/*#{1IIKQ95MR0Items*/
			/*}#1IIKQ95MR0Items*/
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="assistant"){
					/*#{1IIKQ2KLH0*/
					msg.role=$item.id;
					/*}#1IIKQ2KLH0*/
				}else if($item.id==="user"){
					/*#{1IIKQ2KLH1*/
					msg.role=$item.id;
					/*}#1IIKQ2KLH1*/
				}else if($item.id==="system"){
					/*#{1IIKQ2KLH2*/
					msg.role=$item.id;
					/*}#1IIKQ2KLH2*/
				}
			}
			/*#{1IIKQ95MR0Post*/
			txtRole.text=msg.role;
			/*}#1IIKQ95MR0Post*/
		}
	};
	//------------------------------------------------------------------------
	cssVO.showCode=async function(){
		/*#{1IIKS409I0Start*/
		/*}#1IIKS409I0Start*/
		self.showFace("code");
		
		//InitCM
		/*#{1IIKS4TC30*/
		let pos,mode,code;
		code=msg.content;
		if(cm){
			boxCode.webObj.innerHTML="";
			cm=null;
		}
		if(!window.CodeMirror){
			//import CodeMirror
			await VFACT.appendScript("/@codemirror/lib/codemirror.js");
			await VFACT.appendCSS("/@codemirror/lib/codemirror.css");
		}
		mode="javascript";
		mode="text/plain";
		//Create code mirror;
		cm=CodeMirror(boxCode.webObj, {
			value:code,
			mode:mode,
			undoDepth:5
		});
		cmDoc=cm.getDoc();
		cmDoc.on("changes", () => {
			msg.content=cmDoc.getValue();
		});
		/*}#1IIKS4TC30*/
	};
	/*#{1IIKNSD0L1PostCSSVO*/
	/*}#1IIKNSD0L1PostCSSVO*/
	cssVO.constructor=BoxLllmMessage;
	return cssVO;
};
/*#{1IIKNSD0L1ExCodes*/
/*}#1IIKNSD0L1ExCodes*/

//----------------------------------------------------------------------------
BoxLllmMessage.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IIKNSD0L1PreAISpot*/
	/*}#1IIKNSD0L1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IIKNSD0L1PostAISpot*/
	/*}#1IIKNSD0L1PostAISpot*/
	return exposeVO;
};

/*#{1IIKNSD0L0EndDoc*/
/*}#1IIKNSD0L0EndDoc*/

export default BoxLllmMessage;
export{BoxLllmMessage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IIKNSD0L0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IIKNSD0L2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IIKNSD0L3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IIKNSD0L4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IIKNSD0L5",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": ""
//				},
//				"msg": {
//					"type": "auto",
//					"valText": "#{role:\"system\",content:\"hello\"}"
//				},
//				"ui": {
//					"type": "auto",
//					"valText": ""
//				},
//				"code": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IIKNSD0L6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IIKNSD0L7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKQ18EM0",
//					"attrs": {
//						"id": "chooseRole",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKQ95MS0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKQ95MS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1IIKQ95MR0",
//									"attrs": {
//										"id": "RoleMenu",
//										"label": "New AI Seg",
//										"x": "285",
//										"y": "260",
//										"desc": "",
//										"codes": "true",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1IIKQ2KLH0",
//													"attrs": {
//														"id": "assistant",
//														"text": "assistant",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1IIKQ2KLH1",
//													"attrs": {
//														"id": "user",
//														"text": "user",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1IIKQ2KLH2",
//													"attrs": {
//														"id": "system",
//														"text": "system",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1IIKQ95MS2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IIKQ95MS3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IIKQ95MR0"
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIKS409I0",
//					"attrs": {
//						"id": "showCode",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "90",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIKS46UP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIKS46UP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IIKS54NG0",
//									"attrs": {
//										"id": "ShowFace",
//										"label": "New AI Seg",
//										"x": "270",
//										"y": "90",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "code",
//										"outlet": {
//											"jaxId": "1IIKS54NG1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1IIKS4TC30"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1IIKS4TC30",
//									"attrs": {
//										"id": "InitCM",
//										"label": "New AI Seg",
//										"x": "470",
//										"y": "90",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1IIKS54NG2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IIKS46UP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IIKS54NG0"
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IIKNSD0L8",
//			"attrs": {
//				"text": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIKS0A750",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIKS1E920",
//							"attrs": {}
//						}
//					}
//				},
//				"code": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIKS0K5L0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIKS1E921",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IIKNSD0L9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IIKNSD0L1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IIKNSD0L10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIKNUHAU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKP4O0S0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKO4TL80",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKOCEG60",
//													"attrs": {
//														"style": "#appCfg.color.fontSecondary",
//														"w": "22",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKOCEG61",
//													"attrs": {
//														"type": "#null#>BtnIcon(appCfg.color.fontSecondary,22,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnRole",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKOCEG62",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKOCEG63",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKRN98F0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKRN98F1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIKQ18EM0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKOCEG64",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKOCEG65",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IIKNVEON0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKP4O0T0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtRole",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontSecondary\"]",
//														"text": "#msg.role",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKP4O0T1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKP4O0T2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKP4O0T3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IIKP4O0T4",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIKP4O0T5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKP4O0T6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "memo",
//							"jaxId": "1IIKOPV7U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKORKUD0",
//									"attrs": {
//										"type": "memo",
//										"id": "EdText",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "200",
//										"face": "",
//										"styleClass": "",
//										"text": "#msg.content",
//										"color": "[0,0,0]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"outline": "0",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "0",
//										"readOnly": "false",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIKORKUD1",
//									"attrs": {
//										"1IIKS0K5L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIKS1E928",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKS1E929",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIKS0K5L0",
//											"faceTagName": "code"
//										},
//										"1IIKS0A750": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIKS3I3B0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKS3I3B1",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIKS0A750",
//											"faceTagName": "text"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IIKORKUD2",
//									"attrs": {
//										"OnChange": {
//											"type": "fixedFunc",
//											"jaxId": "1IIKQE68F0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IIKQEOR70",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										},
//										"OnInput": {
//											"type": "fixedFunc",
//											"jaxId": "1IIKQECOI0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IIKQEOR71",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										},
//										"OnBlur": {
//											"type": "fixedFunc",
//											"jaxId": "1IIKQEV8C0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IIKQF41O0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKORKUD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IIKRUN3Q0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKS1E9210",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "240",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIKS1E9211",
//									"attrs": {
//										"1IIKS0K5L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIKS1E9212",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKS1E9213",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIKS0K5L0",
//											"faceTagName": "code"
//										},
//										"1IIKS0A750": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIKS3I3B2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKS3I3B3",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIKS0A750",
//											"faceTagName": "text"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IIKS1E9214",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKS1E9215",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIKOEE1D0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIKP4O0T7",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"menuBG\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "End"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKROPAU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKROPAU1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/tab_css.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKROPAU2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/tab_css.svg\",null)",
//														"id": "BtnCodeMode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKROPAU3",
//													"attrs": {
//														"1IIKS0K5L0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIKS1E9216",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIKS1E9217",
//																	"attrs": {
//																		"enable": "false"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIKS0K5L0",
//															"faceTagName": "code"
//														},
//														"1IIKS0A750": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIKS3I3B4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIKS3I3B5",
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIKS0A750",
//															"faceTagName": "text"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIKROPAU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKROPAV0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKROPAV1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIKS409I0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKROPAV2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKROPAV3",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IIKRNU3Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIKS1E9218",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKS1E9219",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKS1E9222",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKS1E9223",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKP1JQT0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKP2LQ80",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKP2LQ81",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//														"id": "BtnAddMessage",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKP2LQ82",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKP2LQ83",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKPITEM0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKPITEN0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKP2LQ84",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKP2LQ85",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKP2ME90",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKP2ME91",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/arrowup.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKP2ME92",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowup.svg\",null)",
//														"id": "BtnMoveUp",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKP2ME93",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKP2ME94",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKPITEM1",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKPITEN1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKP2ME95",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKP2ME96",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKP39960",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKP39961",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/arrowdown.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKP39962",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowdown.svg\",null)",
//														"id": "BtnMoveDown",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKP39970",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKP39971",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKPITEM2",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKPITEN2",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKP39972",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKP39973",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1IIKP3ADV0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIKP3ADV1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIKP3AE00",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//														"id": "BtnDelMessage",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIKP3AE01",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIKP3AE02",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIKPITEM3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIKPITEN3",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIKP3AE03",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIKP3AE04",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IIKP4O0T8",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIKP4O0T9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIKP4O0T10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IIKNSD0L11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IIKNSD0L12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IIKNSD0L13",
//					"attrs": {
//						"msg": {
//							"type": "auto",
//							"valText": "#msg"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IIKNSD0L14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}