//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnText} from "./BtnText.js";
/*#{1I1Q0U6CA0StartDoc*/
import {BtnObject} from "./BtnObject.js";
/*}#1I1Q0U6CA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgSelect=function(title,closeIcon,buttons,items){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,boxButtons,btnYes,btnNo,btn3rd;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	buttons=buttons||[(($ln==="CN")?("取消"):/*EN*/("Cancel")),(($ln==="CN")?("确认"):/*EN*/("OK"))]
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":"30%","w":360,"h":"","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":16,"shadowBlur":10,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"display":!!closeIcon,"padding":3,
				"attached":!!closeIcon,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					self.close(false);
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
				children:[
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"display":$P(()=>(!!state.buttons),state),"margin":[5,0,0,0],"padding":0,
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,(($ln==="CN")?("确定"):("OK")),false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							self.close(true);
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(false);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":!!(buttons&&buttons[2]),
						"anchorY":1,"attached":!!(buttons&&buttons[2]),
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;btn3rd=self.Btn3rd;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let list,orgHud,x,y,i,n,item,maxW,w,h,mx,my;
		dlgVO=vo;
		orgHud=vo.hud;
		txtTitle.text=vo.title||(($ln==="CN")?("请选择"):/*EN*/("Please choose"));
		if(orgHud){
			let webObj,rect,asW,asH;
			webObj=orgHud.webObj;
			rect=webObj.getBoundingClientRect();
			asW=orgHud.w>=0?(rect.width/orgHud.w):1;
			asH=orgHud.h>=0?(rect.height/orgHud.h):1;
			x=rect.left+(vo.x*asW||0);
			y=rect.top+(vo.y*asH||orgHud.h*asH);
	
			self.w=vo.width||vo.w||(orgHud.w>120?orgHud.w:120);
		}else{
			x=vo.x||0;
			y=vo.y||0;
			self.w=vo.width||vo.w||120;
		}
		maxW=200;
		list=vo.items||[];
		n=list.length;
		boxContent.clearChildren();
		for(i=0;i<n;i++){
			item=list[i];
			if(item==="_"){
				boxContent.appendNewChild({
					type:"box",x:"50%",y:0,w:"90",h:1,position:"relative",anchorX:1,margin:[5,0,5,0],background:cfgColor.lineBodySub
				});				
			}else{
				if(typeof(item)==="string"){
					item={text:item,code:item};
				}
				if(item){
					item=boxContent.appendNewChild({
						type:BtnObject(item,dlgVO.converter),x:0,y:0,item:item,position:"relative",
						OnClick:function(e){
							self.OnClick(this.item,e);
							return 1;
						}
					});
					if(item.preferW>maxW){//TODO: Replace with webObj.scrollWidth?
						maxW=item.preferW;
					}
				}
			}
		}
		if(self.w<maxW+20){
			self.w=maxW+20;
		}
		w=self.w;
		h=self.h;
		mx=app.clientW-10;
		my=app.clientH-10;
		switch(vo.alignX){
			case 0:
				break;
			case 1:
				x-=w*0.5;
				break;
			case 2:
				x-=w;
				break;
		}
		x=x<0?0:(x+w>mx?(mx-w):x);
		y=y<0?0:(y+h>my?(my-h):y);
		self.x=x;self.y=y-10;
		boxContent.maxH=vo.maxH||500;
		//TODO: init/update your dialog based on vo
		state.buttons=vo.buttons||false;
		self.animate({type:"pose",y:y,time:80});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(item,evt){
		app.closeDlg(self,item);
		if(item.OnMenuItemClick){
			item.OnMenuItemClick();
			return;
		}
		window.setTimeout(()=>{
			dlgVO.callback && dlgVO.callback(item,evt);
		},0);
	}
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Escape"){
			app.closeDlg(self);
			dlgVO.callback && dlgVO.callback(null);
			return true;
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DlgSelect.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("标准对话框"):("Standard Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"buttons": {
			"name": "buttons", "showName": "buttons", "type": "auto", "key": true, "fixed": true, 
			"initVal": []
		}, 
		"items": {
			"name": "items", "showName": "items", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent"}
	},
	/*#{1I1Q0U6CA0ExGearInfo*/
	/*}#1I1Q0U6CA0ExGearInfo*/
};
/*#{1I1Q0U6CA0EndDoc*/
/*}#1I1Q0U6CA0EndDoc*/

export default DlgSelect;
export{DlgSelect};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I1Q0U6CA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				},
//				"items": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#buttons"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I1Q0U6CP0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "10",
//						"y": "30%",
//						"w": "360",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "16",
//										"shadowBlur": "10",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1T84P6A0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H1T88CE90",
//									"attrs": {
//										"style": "front",
//										"w": "28",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H1T88CE91",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "Absolute",
//										"x": "100%-36",
//										"y": "5",
//										"display": "#!!closeIcon",
//										"face": "",
//										"padding": "3",
//										"attach": "#!!closeIcon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T88CE92",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T88CE93",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1T8K68O0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H1T8KC4H0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T88CE94",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H211US3V0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H1T8B4370",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1T8DM3N0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtMockup",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodyLit",
//														"text": "Add your components here.",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T8DM3N1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T8DM3N2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T8DM3N3",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "${!!state.buttons},state",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "OK",
//															"localize": {
//																"EN": "OK",
//																"CN": "确定"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,(($ln===\"CN\")?(\"确定\"):(\"OK\")),false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T820FU1",
//													"attrs": {
//														"style": "warning",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Cancel",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T820FU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",80,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T820FU3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T820FU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JQQ40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T820FU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V2",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H25185U60",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H25185U61",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[2]",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H25185U62",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,state.buttons[2],false,\"\")",
//														"id": "Btn3rd",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "#!!(buttons&&buttons[2])",
//														"face": "",
//														"anchorV": "Center",
//														"attach": "#!!(buttons&&buttons[2])"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H25185U70",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H25185U71",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H25185U72",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H25185U73",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H25185U74",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H25185U75",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}