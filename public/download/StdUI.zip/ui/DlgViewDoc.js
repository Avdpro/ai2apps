//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnText} from "./BtnText.js";
/*#{1I8G5V6AE0StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import markdownit from "/@markdownit";
import {tabFS} from "/@tabos";
/*}#1I8G5V6AE0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgViewDoc=function(title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContentFrame,boxContent,boxButtons,btnSave,btnDownload,btnClose;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO,pageFrame;
	app=window.tabOSApp;
	dlgVO=null;
	pageFrame=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":30,"w":360,"h":600,"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"padding":3,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					self.close(false);
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":">calc(100% - 30px)","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContentFrame","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","flex":true,
				children:[
					{
						"hash":"1I8GB98M70",
						"type":"hud","id":"BoxContent","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1I8GBSP3C0",
						"type":BtnText("secondary",80,24,(($ln==="CN")?("另存为"):("Save As")),false,""),"id":"BtnSave","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1I8GBSP3C5FunctionBody*/
							self.saveDoc();
							/*}#1I8GBSP3C5FunctionBody*/
						},
					},
					{
						"hash":"1H1T802O00",
						"type":BtnText("secondary",80,24,(($ln==="CN")?("下载"):("Download")),false,""),"id":"BtnDownload","position":"relative","x":0,"y":"50%","anchorY":1,
						"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							self.download();
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1I8G7PBC30",
						"type":BtnText("primary",80,24,(($ln==="CN")?("关闭"):("Close")),false,""),"id":"BtnClose","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1I8G7PBC35FunctionBody*/
							self.close(true);
							/*}#1I8G7PBC35FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContentFrame=self.BoxContentFrame;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnSave=self.BtnSave;btnDownload=self.BtnDownload;btnClose=self.BtnClose;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let mode,hud,x,y,w,h,ax;
		dlgVO=vo;
		hud=vo.hud;
		if(vo.title){
			txtTitle.text=vo.title;
		}else if(vo.fileName){
			txtTitle.text=vo.fileName;
		}else if(vo.path){
			txtTitle.text=pathLib.basename(vo.path);
		}else{
			txtTitle.text=(($ln==="CN")?("查看文档"):/*EN*/("View document"));
		}
		self.w=vo.width||vo.w||360;
		boxContent.webObj.innerHTML="";//Clear
		if(hud){
			let webObj,rect,asW,asH;
			webObj=hud.webObj;
			rect=webObj.getBoundingClientRect();
			asW=hud.w>=0?(rect.width/hud.w):1;
			asH=hud.h>=0?(rect.height/hud.h):1;
			x=rect.left+(vo.x*asW||0);
			y=rect.top+(vo.y*asH||hud.h*asH);
		}else{
			x=vo.x||0;
			y=vo.y||30;
		}
		w=self.w;
		h=vo.height||580;
		self.h=h;
		self.y=y;//For ani
		ax=vo.alignX||vo.anchorH||vo.anchorX||0;
		switch(ax){
			case 0:
			default:
				break;
			case 1:
				x-=w*0.5;
				break;
			case 2:
				x-=w;
				break;
		}
		self.x=x;
		self.showConent(vo);
		btnDownload.display=!!vo.content;
		btnSave.display=!!vo.content;
		self.animate({type:"in",alpha:0,dy:-30,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.showConent=async function(vo){
		let mode,path,content;
		mode=(vo.mode||"html").toLowerCase();
		pageFrame=null;
		if(mode==="html"){
			let pos1,pos2,code;
			boxContent.webObj.innerHTML=vo.content;
		}else if(mode==="markdown"){
			let htmlCode,webObj,list,i,n,blk;
			content=vo.content;
			if(!content){
				path=vo.path||vo.url;
				if(!path){
					return;
				}
				if(path[0]==="/" && path[1]!=="/" && path[1]!=="~"){
					path="/~"+path;
				}
				content=await (await fetch(path)).text();
			}
			htmlCode=markdownit().render(content);
			webObj=boxContent.webObj;
			webObj.style.fontSize="14px";
			webObj.innerHTML=htmlCode;
			//First, fix tab-border
			list=webObj.querySelectorAll("table");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				blk.style.border="1px solid black";
				blk.style.borderSpacing="0px";
			}
			//First, fix tab-border
			list=webObj.querySelectorAll("table");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				blk.style.border="1px solid black";
			}
			list=webObj.querySelectorAll("th");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				blk.style.border="1px solid black";
			}
			list=webObj.querySelectorAll("td");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				blk.style.border="1px solid gray";
			}
			list=webObj.querySelectorAll("img");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				blk.style.maxWidth="100%";
			}
		}else{
			//TODO: Code this:
		}
	};

	//------------------------------------------------------------------------
	cssVO.saveDoc=async function(){
		let path,mode;
		mode=(dlgVO.mode||"html").toLowerCase();
		path="/doc";
		path=await app.modalDlg("/@homekit/ui/DlgFile.js",{
			path:path,
			mode:"save",
			filter:mode==="html"?"*.html":(mode==="markdown"?"*.md":undefined)
		});
		if(!path){
			return;
		}
		if(mode==="html"){
			if(pathLib.extname(path)!==".html"){
				path+=".html";
			}
		}else if(mode==="markdown"){
			if(pathLib.extname(path)!==".md"){
				path+=".md";
			}
		}
		await tabFS.writeFile(path,dlgVO.content);
	};

	//------------------------------------------------------------------------
	cssVO.download=function(){
		let fileName,fileData;
		function downloadFile(data){
			let e,blob,url;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
	
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
	
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		if(!dlgVO.content){
			return;
		}
		if(dlgVO.fileName){
			fileName=dlgVO.fileName;
		}else if((""+dlgVO.mode).toLowerCase()==="html"){
			fileName=(dlgVO.title||"HTMLDocument")+".html";
		}else if((""+dlgVO.mode).toLowerCase()==="markdown"){
			let idx;
			fileName=dlgVO.content.trimLeft();
			idx=fileName.indexOf("\n");
			fileName=fileName.substring(0,idx);
			if(fileName.length>256){
				fileName=fileName.substring(0,256);
			}
			fileName+=".md";
		}
		let encoder = new TextEncoder();
		let byteAry = encoder.encode(dlgVO.content);
		downloadFile(byteAry);
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DlgViewDoc.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("查看文档对话框"):("Doc-View Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContentFrame"}
	},
	/*#{1I8G5V6AE0ExGearInfo*/
	/*}#1I8G5V6AE0ExGearInfo*/
};
/*#{1I8G5V6AE0EndDoc*/
/*}#1I8G5V6AE0EndDoc*/

export default DlgViewDoc;
export{DlgViewDoc};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I8G5V6AE0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Doc-View Dialog",
//			"localize": {
//				"EN": "Doc-View Dialog",
//				"CN": "查看文档对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I8G5V6AS0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "10",
//						"y": "30",
//						"w": "360",
//						"h": "600",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1T84P6A0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H1T88CE90",
//									"attrs": {
//										"style": "front",
//										"w": "28",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H1T88CE91",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "Absolute",
//										"x": "100%-36",
//										"y": "5",
//										"display": "On",
//										"face": "",
//										"padding": "3",
//										"attach": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T88CE92",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T88CE93",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1T8K68O0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H1T8KC4H0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T88CE94",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H211US3V0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%-30",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContentFrame",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I8GB98M70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8GBA34R0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxContent",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8GBA34R1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I8GBA34R2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8GBA34R3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1I8GBSP3C0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8GBSP3C1",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Save As",
//															"localize": {
//																"EN": "Save As",
//																"CN": "另存为"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I8GBSP3C2",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,(($ln===\"CN\")?(\"另存为\"):(\"Save As\")),false,\"\")",
//														"id": "BtnSave",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8GBSP3C3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I8GBSP3C4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8GBSP3C5",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8GBSP3C6",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8GBSP3C7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8GBSP3C8",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I8GBSP3C9",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Download",
//															"localize": {
//																"EN": "Download",
//																"CN": "下载"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,(($ln===\"CN\")?(\"下载\"):(\"Download\")),false,\"\")",
//														"id": "BtnDownload",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1I8G7PBC30",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8G7PBC31",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Close",
//															"localize": {
//																"EN": "Close",
//																"CN": "关闭"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I8G7PBC32",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,(($ln===\"CN\")?(\"关闭\"):(\"Close\")),false,\"\")",
//														"id": "BtnClose",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8G7PBC33",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I8G7PBC34",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8G7PBC35",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8G7PBC36",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8G7PBC37",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8G7PBC38",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I8G7PBC39",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}