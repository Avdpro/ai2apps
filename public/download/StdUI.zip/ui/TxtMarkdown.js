//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HFMH37H510StartDoc*/
import markdownit from "/@markdownit";
/*}#1HFMH37H510StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TxtMarkdown=function(markdown,baseFontSize){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxMD;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let txtMarkdown="null";
	let curScale=1;
	
	/*#{1HFMFGE201LocalVals*/
	baseFontSize=baseFontSize>=12?baseFontSize:15;
	/*}#1HFMFGE201LocalVals*/
	
	/*#{1HFMFGE201PreState*/
	/*}#1HFMFGE201PreState*/
	state={
		"markdown":markdown,
		/*#{1HFMFGE215ExState*/
		/*}#1HFMFGE215ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HFMFGE201PostState*/
	/*}#1HFMFGE201PostState*/
	cssVO={
		"hash":"1HFMFGE201",nameHost:true,
		"type":"hud","x":0,"y":0,"w":200,"h":"","padding":5,"minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HFMFQ5C00",
				"type":"hud","id":"BoxMD","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		get $$markdown(){return state["markdown"]},
		set $$markdown(v){
			state["markdown"]=v;
			/*#{1HFMFGE201Setmarkdown*/
			/*}#1HFMFGE201Setmarkdown*/
		},
		/*#{1HFMFGE201ExtraCSS*/
		/*}#1HFMFGE201ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxMD=self.BoxMD;
			/*#{1HFMFGE201Create*/
			state.onChange(self.updateMarkdown);
			self.updateMarkdown();
			/*}#1HFMFGE201Create*/
		},
		/*#{1HFMFGE201EndCSS*/
		/*}#1HFMFGE201EndCSS*/
	};
	/*#{1HFMFGE201PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.updateMarkdown=function(mdText){
		mdText=mdText||state.markdown;
		if(txtMarkdown!==mdText){
			let content,webObj,blk,pNode;
			let list,i,n;
			txtMarkdown=mdText;
			content=markdownit().render(txtMarkdown);
			webObj=boxMD.webObj;
			webObj.innerHTML=content;
			webObj.style.fontSize=baseFontSize+"px";
			
			list=webObj.querySelectorAll("img");
			n=list.length;
			for(i=0;i<n;i++){
				blk=list[i];
				pNode=blk.parentNode;
				if(pNode && pNode.children && pNode.children.length===1){
					pNode.styleWidth="100%";
					blk.style.maxWidth="100%";
				}
			}
		}
	};
	/*}#1HFMFGE201PostCSSVO*/
	return cssVO;
};
/*#{1HFMFGE201ExCodes*/
/*}#1HFMFGE201ExCodes*/

TxtMarkdown.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"Markdown",icon:"filemd.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	"desc":(($ln==="CN")?("显示Markdown文本的组件"):("Component to display Markdown text")),
	catalog:"Texts",
	args: {
		"markdown": {
			"name": "markdown", "showName": "markdown", "type": "string", "key": true, "fixed": true, "initVal": "# Hello markdown", "initValText": "#\"# Hello markdown\"", 
			"localizable": true
		}, 
		"baseFontSize": {
			"name": "baseFontSize", "showName": "baseFontSize", "type": "int", "key": true, "fixed": true, "initVal": 15
		}
	},
	state:{
		markdown:{name:"markdown",type:"string",initVal:"# Hello markdown",localizable:true}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","scale","cursor","zIndex","margin","padding","minH","maxW","maxH","styleClass"],
	faces:[],
	subContainers:{
	},
	/*#{1HFMH37H510ExGearInfo*/
	/*}#1HFMH37H510ExGearInfo*/
};
export default TxtMarkdown;
export{TxtMarkdown};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HFMH37H510",
//	"editVersion": 133,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HFMFGE210",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HFMFGE211",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HFMFGE212",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HFMFGE213",
//			"editVersion": 34,
//			"attrs": {
//				"markdown": {
//					"type": "string",
//					"valText": "#\"# Hello markdown\"",
//					"localizable": true
//				},
//				"baseFontSize": {
//					"type": "int",
//					"valText": "15"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HFMFGE214",
//			"editVersion": 24,
//			"attrs": {
//				"txtMarkdown": {
//					"type": "string",
//					"valText": "null"
//				},
//				"curScale": {
//					"type": "number",
//					"valText": "1"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HFMFGE215",
//			"editVersion": 32,
//			"attrs": {
//				"markdown": {
//					"type": "string",
//					"valText": "#markdown",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "Markdown",
//		"gearIcon": "filemd.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Texts",
//		"description": {
//			"type": "string",
//			"valText": "Component to display Markdown text",
//			"localize": {
//				"EN": "Component to display Markdown text",
//				"CN": "显示Markdown文本的组件"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HFMFGE216",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HFMFGE217",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HFMFGE201",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HFMFGE218",
//					"editVersion": 88,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "200",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "5",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HFMFQ5C00",
//							"editVersion": 32,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HFMFU4NC0",
//									"editVersion": 118,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMD",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HFMFU4NC1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HFMFU4NC2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HFMFU4NC3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HFMFGE220",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HFMFGE221",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HFMFGE222",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HFMFGE223",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "markdown"
//				}
//			]
//		}
//	}
//}