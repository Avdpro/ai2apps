//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G931M4I30StartDoc*/
/*}#1G931M4I30StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let ListBox=function(lineDef,cellDef,cellSize,opts,lineOpts,cellOpts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G931M4I37LocalVals*/
	let selected=new Set();
	let hotItem=null;
	let multiSelect=opts.multiSelect;
	let showMode="";
	let gridLineGap=opts.gridLineGap||10;
	opts=opts||{w:80,fontSize:txtSize.small,color:cfgColor.fontBody};
	/*}#1G931M4I37LocalVals*/
	
	/*#{1G931M4I37PreState*/
	/*}#1G931M4I37PreState*/
	/*#{1G931M4I37PostState*/
	/*}#1G931M4I37PostState*/
	cssVO={
		"hash":"1G931M4I37",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","overflow":"auto-y","padding":[0,0,50,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		/*#{1G931M4I37ExtraCSS*/
		/*}#1G931M4I37ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G931M4I37Create*/
			self.setShowMode(opts.mode||"line");
			/*}#1G931M4I37Create*/
		},
		/*#{1G931M4I37EndCSS*/
		get $$selected(){
			return selected;
		},
		get $$hotItem(){
			return hotItem;
		},
		set $$hotItem(item){
			if(self){
				self.setHotItem(item,false);
			}
		},
		get $$showMode(){
			return showMode;
		},
		set $$showMode(mode){
			if(self){
				mode=mode==="line"?"line":"grid";
				self.setShowMode(mode);
			}
		},
		get $$items(){
			return self && self.children;
		},
		/*}#1G931M4I37EndCSS*/
	};
	/*#{1G931M4I37PostCSSVO*/
	let muteCounter=0;
	let pandingMuteSelectCall=0;
	//------------------------------------------------------------------------
	cssVO.setShowMode=function(mode){
		let list,items,item,i,n,hotObj;
		if(mode===showMode){
			return;
		}
		showMode=mode;
		list=[];
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			list.push(items[i].itemObj);
		}
		hotObj=hotItem?hotItem.itemObj:null;
		hotItem=null;
		self.clearChildren();
		self.clearSelect();
		if(mode==="line"){
			self.contentLayout="flex-y";
		}else{
			self.contentLayout="grid";
			self.gridConfig=[`repeat(auto-fill, ${cellSize}px)`,`repeat(auto-fill, ${cellSize+gridLineGap}px)`];
		}
		self.addItems(list);
		item=self.getItemOfObj(hotObj);
		if(item){
			self.setHotItem(item,0);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.addItem=function(obj){
		let def,item;
		if(showMode==="line"){
			def=lineDef(obj,self);
		}else{
			def=cellDef(obj,self);
		}
		def.position="relative";
		item=self.appendNewChild(def);
		item.itemObj=obj;
		return item;
	};
	
	//------------------------------------------------------------------------
	cssVO.addItems=function(list){
		let defFunc,frg,obj,def,item;
		if(showMode==="line"){
			defFunc=lineDef;
		}else{
			defFunc=cellDef;
		}
		//Make it a bit faster:
		frg=VFACT.createFragDummy(self);
		for(obj of list){
			def=defFunc(obj,self);
			def.position="relative";
			item=VFACT.createObj(def,frg);
			item.itemObj=obj;
		}
		VFACT.appendFragDummy(frg);
	};
	
	//------------------------------------------------------------------------
	cssVO.insertItem=function(obj,curItem){
		let def,item;
		if(showMode==="line"){
			def=lineDef(obj,self);
		}else{
			def=cellDef(obj,self);
		}
		def.position="relative";
		item=self.insertNewBefore(def,curItem);
		item.itemObj=obj;
		return item;
	};
	
	//------------------------------------------------------------------------
	cssVO.insertItems=function(list,curItem){
		let defFunc,frg,obj,def,item;
		if(showMode==="line"){
			defFunc=lineDef;
		}else{
			defFunc=cellDef;
		}
		//Make it a bit faster:
		frg=VFACT.createFragDummy(self);
		for(obj of list){
			def=defFunc(obj,self);
			def.position="relative";
			item=VFACT.createObj(def,frg);
			item.itemObj=obj;
		}
		VFACT.appendFragDummy(frg,self,curItem);
	};
	
	//------------------------------------------------------------------------
	cssVO.removeItem=function(item){
		selected.delete(item);
		if(item===hotItem){
			self.setHotItem(null);
		}
		self.removeChild(item);
	};
	
	//------------------------------------------------------------------------
	cssVO.getItemNum=function(){
		return self.children.length;
	};
	
	//------------------------------------------------------------------------
	cssVO.getItemOfObj=function(obj){
		let items,i,n,item;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(item.itemObj===obj){
				return item;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	cssVO.getItemIndex=cssVO.indexOfItem=function(chkItem){
		let items,i,n,item;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(item===chkItem){
				return i;
			}
		}
		return -1;
	};
	
	//------------------------------------------------------------------------
	cssVO.getItemByIndex=function(idx){
		let items,i,n,item;
		items=self.children;
		return items[idx];
	};
	
	//------------------------------------------------------------------------
	cssVO.findItem=function(chkFunc){
		let items,i,n,item;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(chkFunc(item)){
				return item;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	cssVO.findItemIdx=function(chkFunc){
		let items,i,n,item;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(chkFunc(item)){
				return i;
			}
		}
		return -1;
	};
	
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		self.clearSelect();
		self.setHotItem(null);
		self.clearChildren();
	};
	
	//------------------------------------------------------------------------
	cssVO.setHotItem=function(item,addSelect){
		if(item===hotItem){
			return;
		}
		/*if(addSelect && selected.has(item)){
			return self.deselectItem(item);
		}*/
		if(hotItem){
			if(addSelect){
				hotItem.showFace("select");
			}else{
				hotItem.showFace("blur");
			}
		}
		hotItem=item;
		if(hotItem){
			if(addSelect){
				selected.add(hotItem);
				(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
			}else{
				if(this.selected.size>0){
					for(let l of selected){
						l.showFace("blur");
					}
					selected.clear();
				}
				selected.add(hotItem);
				(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
			}
			item.showFace("focus");
		}
		(!muteCounter) && self.OnHotItemChange && self.OnHotItemChange(hotItem);
	};
	
	//------------------------------------------------------------------------
	cssVO.selectItem=function(item){
		if(selected.has(item)){
			return;
		}else{
			selected.add(item);
			if(item!==hotItem){
				item.showFace("select");
			}
		}
		(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.selectAll=function(){
		let items,i,n,item;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			selected.add(item);
			if(item!==hotItem){
				item.showFace("select");
			}
		}
		(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.deselectItem=function(item){
		if(!selected.has(item)){
			return;
		}else{
			selected.delete(item);
			if(item===hotItem){
				hotItem=null;
				item.showFace("blur");
				(!muteCounter) && self.OnHotItemChange && self.OnHotItemChange(hotItem);
			}else{
				item.showFace("blur");
			}
		}
		(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.isItemSelected=function(item){
		return selected.has(item);
	};
	
	//------------------------------------------------------------------------
	cssVO.clearSelect=cssVO.clearSelects=function(){
		if(!selected.size){
			return;
		}
		for(let l of selected){
			l.showFace("blur");
		}
		selected.clear();
		(!muteCounter) && self.OnSelItemChange && self.OnSelItemChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.moveItemUp=function(item){
		let pre;
		pre=item.previousSibling;
		if(pre){
			self.insertBefore(item,pre);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.moveItemDown=function(item){
		let nxt;
		nxt=item.nextSibling;
		if(nxt){
			self.insertBefore(nxt,item);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.muteCallback=cssVO.muteSelect=function(){
		muteCounter++;
	};
	
	//------------------------------------------------------------------------
	cssVO.unmuteCallback=cssVO.unmuteSelect=function(notify){
		muteCounter--;
		if(muteCounter===0 && notify && pandingMuteSelectCall){
			self.OnSelItemChange && self.OnSelItemChange();
		}
		pandingMuteSelectCall=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.scrollShowItem=function(item){
		if(item){
			VFACT.scrollToShow(item,self,{y:true});
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.sortItems=function(list){
		let items,item,i,n;
		items=self.children;
		n=items.length;
		for(i=0;i<n;i++){
			items[i].itemIdx=i;
		}
		list.sort((a,b)=>{
			return a.itemIdx-b.itemIdx;
		});
		return list;
	};
	/*}#1G931M4I37PostCSSVO*/
	return cssVO;
};
/*#{1G931M4I37ExCodes*/
/*}#1G931M4I37ExCodes*/

ListBox.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"ListBox",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:200,initH:300,
	"desc":"ListBox can show items by lines or grids",
	catalog:"Views",
	args: {
		"lineDef": {
			"name": "lineDef", "showName": "lineDef", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"cellDef": {
			"name": "cellDef", "showName": "cellDef", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"cellSize": {
			"name": "cellSize", "showName": "cellSize", "type": "int", "key": true, "fixed": true, "initVal": 50
		}, 
		"opts": {
			"type": "object", "name": "opts", "showName": "opts", "icon": undefined, 
			"def": {
				"attrs": {
					"multiSelect": {
						"name": "multiSelect", "showName": "multiSelect", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"gridLineGap": {
						"name": "gridLineGap", "showName": "gridLineGap", "type": "int", "key": true, "fixed": true, "initVal": 10
					}, 
					"mode": {
						"name": "mode", "showName": "mode", "type": "string", "key": true, "fixed": true, "initVal": "line"
					}, 
					"allowDrop": {
						"name": "allowDrop", "showName": "allowDrop", "type": "bool", "key": true, "fixed": true, "initVal": false
					}
				}
			}, 
			"key": true, "fixed": true
		}, 
		"lineOpts": {
			"type": "object", "name": "lineOpts", "showName": "lineOpts", "icon": undefined, 
			"def": {
				"attrs": {
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 14, "initValText": "#txtSize.smallPlus"
					}, 
					"allowDrop": {
						"name": "allowDrop", "showName": "allowDrop", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"allowDrag": {
						"name": "allowDrag", "showName": "allowDrag", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"height": {
						"name": "height", "showName": "height", "type": "int", "key": true, "fixed": true, "initVal": 24
					}, 
					"iconSize": {
						"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 20
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor.fontBody"
					}, 
					"checkBox": {
						"name": "checkBox", "showName": "checkBox", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"expandBtn": {
						"name": "expandBtn", "showName": "expandBtn", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"indentSize": {
						"name": "indentSize", "showName": "indentSize", "type": "int", "key": true, "fixed": true, "initVal": 15
					}, 
					"fileSize": {
						"name": "fileSize", "showName": "fileSize", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"fileMenu": {
						"name": "fileMenu", "showName": "fileMenu", "type": "bool", "key": true, "fixed": true, "initVal": true
					}
				}
			}, 
			"key": true, "fixed": true
		}, 
		"cellOpts": {
			"type": "object", "name": "cellOpts", "showName": "cellOpts", "icon": undefined, 
			"def": {
				"attrs": {
					"w": {
						"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 60
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "number", "key": true, "fixed": true, "initVal": 12, "initValText": "#txtSize.small"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","cursor","zIndex","margin","padding","attach"],
	faces:[],
	subContainers:{
	},
	/*#{1G931M4I30ExGearInfo*/
	/*}#1G931M4I30ExGearInfo*/
};
/*#{1G931M4I30EndDoc*/
/*}#1G931M4I30EndDoc*/

export default ListBox;
export{ListBox};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G931M4I30",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G931M4I31",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G931M4I32",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I91N9I440",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G931M4I33",
//			"attrs": {
//				"lineDef": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"cellDef": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"cellSize": {
//					"type": "int",
//					"valText": "50"
//				},
//				"opts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I927AEOS0",
//					"attrs": {
//						"multiSelect": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"gridLineGap": {
//							"type": "int",
//							"valText": "10"
//						},
//						"mode": {
//							"type": "string",
//							"valText": "line"
//						},
//						"allowDrop": {
//							"type": "bool",
//							"valText": "false"
//						}
//					}
//				},
//				"lineOpts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I927AEOS1",
//					"attrs": {
//						"fontSize": {
//							"type": "int",
//							"valText": "#txtSize.smallPlus"
//						},
//						"allowDrop": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"allowDrag": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"iconSize": {
//							"type": "int",
//							"valText": "20"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor.fontBody"
//						},
//						"checkBox": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"expandBtn": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						},
//						"fileSize": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"fileMenu": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				},
//				"cellOpts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I927HED00",
//					"attrs": {
//						"w": {
//							"type": "int",
//							"valText": "60"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"fontSize": {
//							"type": "number",
//							"valText": "#txtSize.small"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G931M4I34",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G931M4I35",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "ListBox",
//		"gearIcon": "gears.svg",
//		"gearW": "200",
//		"gearH": "300",
//		"gearCatalog": "Views",
//		"description": "ListBox can show items by lines or grids",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G931M4I36",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I91N9I441",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G931M4I37",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G931M4I38",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "[0,0,50,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": []
//				},
//				"faces": {
//					"jaxId": "1G931M4I39",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G931M4I310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GG213P190",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G931M4I311",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}