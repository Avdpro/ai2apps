//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HL4OQGS40StartDoc*/
/*}#1HL4OQGS40StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let NaviToolBar=function(tabBG){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxMark,boxBtns;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let hotItem=null;
	
	/*#{1HL4OQGS41LocalVals*/
	/*}#1HL4OQGS41LocalVals*/
	
	/*#{1HL4OQGS41PreState*/
	/*}#1HL4OQGS41PreState*/
	/*#{1HL4OQGS41PostState*/
	/*}#1HL4OQGS41PostState*/
	cssVO={
		"hash":"1HL4OQGS41",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HL4ORE9V0",
				"type":"box","id":"BoxMark","x":5,"y":-1,"w":100,"h":">calc(100% - 3px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,1,1,1],"corner":[0,0,6,6],
			},
			{
				"hash":"1HL4P0I9P0",
				"type":"hud","id":"BoxBtns","x":0,"y":1,"w":"100%","h":">calc(100% - 5px)","padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
			}
		],
		/*#{1HL4OQGS41ExtraCSS*/
		/*}#1HL4OQGS41ExtraCSS*/
		faces:{
			"bottom":{
				/*BoxMark*/"#1HL4ORE9V0":{
					"y":-1,"border":[0,1,1,1],"corner":[0,0,6,6]
				},
				/*BoxBtns*/"#1HL4P0I9P0":{
					"y":1
				}
			},"top":{
				/*BoxMark*/"#1HL4ORE9V0":{
					"y":3,"border":[1,1,0,1],"corner":[6,6,0,0]
				},
				/*BoxBtns*/"#1HL4P0I9P0":{
					"y":5
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxMark=self.BoxMark;boxBtns=self.BoxBtns;
			/*#{1HL4OQGS41Create*/
			let i,n,list;
			list=boxBtns.children;
			n=list.length;
			for(i=0;i<n;i++){
				self.addItem(list[i]);
			}
			callAfter(()=>{
				boxMark.display=tabBG;
				if(!hotItem){
					self.focusOn(0);
				}
			},200);
			/*}#1HL4OQGS41Create*/
		},
		/*#{1HL4OQGS41EndCSS*/
		/*}#1HL4OQGS41EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.focusOn=function(item){
		/*#{1HL4P71SM0Start*/
		let oldHotItem;
		oldHotItem=hotItem;
		boxMark.display=tabBG;
		/*}#1HL4P71SM0Start*/
		
		//GetItem
		/*#{1HL4PGFNK0*/
		if(item>=0){
			item=boxBtns.children[item];
		}
		if(!item){
			return;
		}
		/*}#1HL4PGFNK0*/
		if(item===hotItem){
			/*#{1HL4PGFNL2*/
			self.moveTab(false);
			/*}#1HL4PGFNL2*/
			return;
		}
		
		//SetHotItem
		/*#{1HL4PGFNK2*/
		if(hotItem){
			hotItem.showFace("blur");
		}
		hotItem=item;
		if(hotItem){
			hotItem.showFace("focus");
		}
		/*}#1HL4PGFNK2*/
		
		//AniMark
		/*#{1HL4PGFNK3*/
		self.moveTab(!!oldHotItem);
		/*}#1HL4PGFNK3*/
	};
	//------------------------------------------------------------------------
	cssVO.moveTab=function(ani){
		/*#{1HNBJMGIC0Start*/
		let itemRect,selfRect;
		if(!hotItem){
			return;
		}
		selfRect=self.getBoundingClientRect();
		itemRect=hotItem.getBoundingClientRect();
		if(ani){
			boxMark.animate({type:"pose",x:itemRect.x-selfRect.x-5,w:itemRect.width+10,time:50});
		}else{
			boxMark.x=itemRect.x-selfRect.x-5;
			boxMark.w=itemRect.width+10;
		}
		/*}#1HNBJMGIC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addItem=function(sub){
		/*#{1HL4Q8AF00Start*/
		if(!sub.webObj){
			sub=boxBtns.appendNewChild(sub);
		}
		sub.oldOnClick=sub.OnClick;
		sub.OnClick=function(evt){
			self.focusOn(this);
			this.oldOnClick && this.oldOnClick(evt);
		}
		sub.showFace("blur");
		return sub;
		/*}#1HL4Q8AF00Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getFocusedItem=function(){
		/*#{1IQ7Q8SAC0Start*/
		return hotItem;
		/*}#1IQ7Q8SAC0Start*/
	};
	/*#{1HL4OQGS41PostCSSVO*/
	/*}#1HL4OQGS41PostCSSVO*/
	cssVO.constructor=NaviToolBar;
	return cssVO;
};
/*#{1HL4OQGS41ExCodes*/
/*}#1HL4OQGS41ExCodes*/

//----------------------------------------------------------------------------
NaviToolBar.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HL4OQGS41PreAISpot*/
	/*}#1HL4OQGS41PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="Navi Buttons";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HL4OQGS41PostAISpot*/
	/*}#1HL4OQGS41PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
NaviToolBar.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"Navi Buttons",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:30,
	"desc":(($ln==="CN")?("用于指示/选择活跃按钮的按钮条。"):("Button bar used to indicate/select active buttons.")),
	catalog:"Views",
	args: {
		"tabBG": {
			"name": "tabBG", "showName": "tabBG", "type": "bool", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:["bottom","top"],
	subContainers:{
		"1HL4P0I9P0":{"showName":"BoxBtns","contentLayout":"flex-x"}
	},
	/*#{1HL4OQGS40ExGearInfo*/
	/*}#1HL4OQGS40ExGearInfo*/
};
/*#{1HL4OQGS40EndDoc*/
/*}#1HL4OQGS40EndDoc*/

export default NaviToolBar;
export{NaviToolBar};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HL4OQGS40",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL4OQGS50",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "30",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL4OQGS51",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL4OQGS52",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL4OQGS53",
//			"attrs": {
//				"tabBG": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL4OQGS54",
//			"attrs": {
//				"hotItem": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL4OQGS55",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL4P71SM0",
//					"attrs": {
//						"id": "focusOn",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL4P71SO0",
//							"attrs": {
//								"item": {
//									"type": "auto",
//									"valText": "0"
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL4P71SO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL4PGFNK0",
//									"attrs": {
//										"id": "GetItem",
//										"label": "New AI Seg",
//										"x": "290",
//										"y": "160",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL4PGFNL0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL4PGFNL1"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Condition",
//									"jaxId": "1HL4PGFNL1",
//									"attrs": {
//										"id": "CheckItem",
//										"label": "New AI Seg",
//										"x": "500",
//										"y": "160",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "ConditionOutlet",
//													"jaxId": "1HL4PCO730",
//													"attrs": {
//														"id": "Same",
//														"condition": "item===hotItem",
//														"codes": "false",
//														"desc": "条件输出节点。"
//													},
//													"linkedSeg": "1HL4PGFNL2"
//												}
//											]
//										},
//										"catchlet": {
//											"jaxId": "1HL4PGFNK1",
//											"attrs": {
//												"id": "else",
//												"desc": "输出节点。",
//												"codes": "false"
//											}
//										},
//										"outlet": {
//											"jaxId": "1HL4PGFNL3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL4PGFNK2"
//										}
//									},
//									"icon": "condition.svg",
//									"reverseOutlets": true
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HL4PGFNL2",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "720",
//										"y": "130",
//										"desc": "",
//										"codes": "true",
//										"result": ""
//									},
//									"icon": "flag.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL4PGFNK2",
//									"attrs": {
//										"id": "SetHotItem",
//										"label": "New AI Seg",
//										"x": "740",
//										"y": "190",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL4PGFNL4",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL4PGFNK3"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL4PGFNK3",
//									"attrs": {
//										"id": "AniMark",
//										"label": "New AI Seg",
//										"x": "970",
//										"y": "190",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL4PGFNL5",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL4P71SO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL4PGFNK0"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HNBJMGIC0",
//					"attrs": {
//						"id": "moveTab",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HNBJMTPJ0",
//							"attrs": {
//								"ani": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HNBJMTPJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HNBJMTPJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL4Q8AF00",
//					"attrs": {
//						"id": "addItem",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "340",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL4Q9A8P0",
//							"attrs": {
//								"sub": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL4Q9A8P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HL4Q9A8P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IQ7Q8SAC0",
//					"attrs": {
//						"id": "getFocusedItem",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "430",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IQ7Q9UPJ0",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IQ7Q9UPJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IQ7Q9UPJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "Navi Buttons",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "30",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "Button bar used to indicate/select active buttons.",
//			"localize": {
//				"EN": "Button bar used to indicate/select active buttons.",
//				"CN": "用于指示/选择活跃按钮的按钮条。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL4OQGS56",
//			"attrs": {
//				"bottom": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I4OPC8FI0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I4OPFJLO0",
//							"attrs": {}
//						}
//					}
//				},
//				"top": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I4OPCDCH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I4OPFJLO1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL4OQGS57",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HL4OQGS41",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL4OQGS58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL4ORE9V0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL4P28AI0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMark",
//										"position": "Absolute",
//										"x": "5",
//										"y": "-1",
//										"w": "100",
//										"h": "100%-3",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,1,1,1]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "[0,0,6,6]",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL4P28AI1",
//									"attrs": {
//										"1I4OPCDCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I4OPFJLP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4OPFJLP1",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "3"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[1,1,0,1]",
//															"editMode": "edges"
//														},
//														"corner": {
//															"type": "auto",
//															"valText": "[6,6,0,0]",
//															"editMode": "corners"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I4OPCDCH0",
//											"faceTagName": "top"
//										},
//										"1I4OPC8FI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I4OPFJLP2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4OPFJLP3",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "-1"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[0,1,1,1]",
//															"editMode": "edges"
//														},
//														"corner": {
//															"type": "auto",
//															"valText": "[0,0,6,6]",
//															"editMode": "corners"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I4OPC8FI0",
//											"faceTagName": "bottom"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL4P28AI2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL4P28AI3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HL4P0I9P0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL4P28AI4",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBtns",
//										"position": "Absolute",
//										"x": "0",
//										"y": "1",
//										"w": "100%",
//										"h": "100%-5",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL4P28AI5",
//									"attrs": {
//										"1I4OPCDCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I4OPFJLP4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4OPFJLP5",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "5"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I4OPCDCH0",
//											"faceTagName": "top"
//										},
//										"1I4OPC8FI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I4OQ29GN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4OQ29GN1",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I4OPC8FI0",
//											"faceTagName": "bottom"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL4P28AI6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL4P28AI7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL4OQGS59",
//					"attrs": {
//						"1I4OPC8FI0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I4OQ29GN2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I4OQ29GN3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I4OPC8FI0",
//							"faceTagName": "bottom"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HL4OQGS510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL4OQGS511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL4OQGS512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}