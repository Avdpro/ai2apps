//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LD0QTJ0StartDoc*/
/*}#1H1LD0QTJ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnCheck=function(size,text,checked,radio){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LD0QTJ1LocalVals*/
	/*}#1H1LD0QTJ1LocalVals*/
	
	/*#{1H1LD0QTJ1PreState*/
	/*}#1H1LD0QTJ1PreState*/
	state={
		"fontSize":size>0?(size>17?size-5:12):16,"text":text,"checked":checked,"color":cfgColor.fontBody,
		/*#{1H1LD0QTK4ExState*/
		/*}#1H1LD0QTK4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LD0QTJ1PostState*/
	/*}#1H1LD0QTJ1PostState*/
	cssVO={
		"hash":"1H1LD0QTJ1",nameHost:true,
		"type":"button","x":138,"y":165,"w":"","h":size,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"itemsAlign":1,
		"traceSize":true,
		children:[
			{
				"hash":"1H1LDAK720",
				"type":"box","id":"BoxSlot","position":"relative","x":0,"y":0,"w":"","h":"100%","autoLayout":true,"uiEvent":-1,"padding":radio?3:0,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],"border":2,"borderColor":$P(()=>(state.color),state),"corner":radio?100:0,"aspect":"1",
				children:[
					{
						"hash":"1H1LDP68F0",
						"type":"box","id":"BoxMark","position":"relative","x":-1,"y":-1,"w":">calc(100% + 2px)","h":">calc(100% + 2px)","display":$P(()=>(!!state.checked),state),
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.color),state),"corner":radio?100:0,"maskImage":radio?"":appCfg.sharedAssets+"/check_fat.svg",
					}
				],
			},
			{
				"hash":"1H1LDI5G40",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":$P(()=>(state.color),state),"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"attached":!!text,
			}
		],
		get $$checked(){return state["checked"]},
		set $$checked(v){
			state["checked"]=v;
			/*#{1H1LD0QTJ1Setchecked*/
			/*}#1H1LD0QTJ1Setchecked*/
		},
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1LD0QTJ1Settext*/
			/*}#1H1LD0QTJ1Settext*/
		},
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1LD0QTJ1SetfontSize*/
			/*}#1H1LD0QTJ1SetfontSize*/
		},
		get $$color(){return state["color"]},
		set $$color(v){
			state["color"]=v;
			/*#{1H1LD0QTJ1Setcolor*/
			/*}#1H1LD0QTJ1Setcolor*/
		},
		/*#{1H1LD0QTJ1ExtraCSS*/
		/*}#1H1LD0QTJ1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[0,0,0,0]
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[...cfgColor.primary,80]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[...cfgColor.primary,-20]
				}
			},"gray":{
				"#self":{
					"alpha":0.6
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1LD0QTJ1Create*/
			/*}#1H1LD0QTJ1Create*/
		},
		/*#{1H1LD0QTJ1EndCSS*/
		/*}#1H1LD0QTJ1EndCSS*/
	};
	/*#{1H1LD0QTJ1PostCSSVO*/
	cssVO.OnClick=function(){
		state.checked=!state.checked;
		if(this.OnCheck){
			this.OnCheck(state.checked);
		}
	};
	/*}#1H1LD0QTJ1PostCSSVO*/
	return cssVO;
};
/*#{1H1LD0QTJ1ExCodes*/
/*}#1H1LD0QTJ1ExCodes*/

BtnCheck.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("选择/单选"):("Check / Raido")),icon:"btn_check.svg",previewImg:"./CheckBtn.png",
	fixPose:false,initW:100,initH:20,
	"desc":"Check or radio button with text",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Check button", "localizable": true
		}, 
		"checked": {
			"name": "checked", "showName": "checked", "type": "bool", "key": true, "fixed": true, "initVal": true
		}, 
		"radio": {
			"name": "radio", "showName": "radio", "type": "bool", "key": true, "fixed": true, "initVal": false
		}
	},
	state:{
		checked:{name:"checked",type:"bool",initVal:true},
		text:{name:"text",type:"string",initVal:"Check button",localizable:true},
		fontSize:{name:"fontSize",type:"int",initVal:15},
		color:{name:"color",type:"colorRGBA",initVal:[0,0,0,1]}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","padding","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1LD0QTJ0ExGearInfo*/
	/*}#1H1LD0QTJ0ExGearInfo*/
};
/*#{1H1LD0QTJ0EndDoc*/
/*}#1H1LD0QTJ0EndDoc*/

export default BtnCheck;
export{BtnCheck};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1LD0QTJ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1LD0QTK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1LD0QTK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8GLJIRJ0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1LD0QTK2",
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "20"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Check button",
//					"localizable": true
//				},
//				"checked": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"radio": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1LD0QTK3",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1LD0QTK4",
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#size>0?(size>17?size-5:12):16"
//				},
//				"text": {
//					"type": "string",
//					"valText": "#text",
//					"localizable": true
//				},
//				"checked": {
//					"type": "bool",
//					"valText": "#checked"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.fontBody"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Check / Raido",
//			"localize": {
//				"EN": "Check / Raido",
//				"CN": "选择/单选"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_check.svg",
//		"gearW": "100",
//		"gearH": "20",
//		"gearCatalog": "Buttons",
//		"description": "Check or radio button with text",
//		"fixPose": "false",
//		"previewImg": "./CheckBtn.png",
//		"faceTags": {
//			"jaxId": "1H1LD0QTK5",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LEB2U81",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U82",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LEB2U83",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U84",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LEB2U85",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U86",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LEB2U87",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAUA6DP0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1LD0QTJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1LD0QTK6",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "138",
//						"y": "165",
//						"w": "\"\"",
//						"h": "#size",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1LDAK720",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LEB2U88",
//									"attrs": {
//										"type": "box",
//										"id": "BoxSlot",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#radio?3:0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "${state.color},state",
//										"corner": "#radio?100:0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H1LDP68F0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LEB2U89",
//													"attrs": {
//														"type": "box",
//														"id": "BoxMark",
//														"position": "Relative",
//														"x": "-1",
//														"y": "-1",
//														"w": "100%+2",
//														"h": "100%+2",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "${!!state.checked},state",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "${state.color},state",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "#radio?100:0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#radio?\"\":appCfg.sharedAssets+\"/check_fat.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1LEB2U810",
//													"attrs": {
//														"1H1LEB2U80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LET8380",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LET8381",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U80",
//															"faceTagName": "up"
//														},
//														"1H1LEB2U82": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LET8382",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LET8383",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U82",
//															"faceTagName": "over"
//														},
//														"1H1LEB2U84": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LRH88B0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LRH88B1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U84",
//															"faceTagName": "down"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1LEB2U811",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H1LEB2U812",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1LEB2U813",
//									"attrs": {
//										"1H1LEB2U80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8384",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LET8385",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U80",
//											"faceTagName": "up"
//										},
//										"1H1LEB2U82": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8386",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LET8387",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.primary,80]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U82",
//											"faceTagName": "over"
//										},
//										"1H1LEB2U84": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8388",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LET8389",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.primary,-20]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U84",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1LEB2U814",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1LEB2U815",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1LDI5G40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LEB2U816",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,3]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "${state.color},state",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"attach": "#!!text"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1LEB2U817",
//									"attrs": {
//										"1H1LEB2U80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET83810",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LET83811",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U80",
//											"faceTagName": "up"
//										},
//										"1H1LEB2U82": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET83812",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LET83813",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U82",
//											"faceTagName": "over"
//										},
//										"1H1LEB2U84": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LRH88B2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LRH88B3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U84",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1LEB2U818",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1LEB2U819",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1LD0QTK7",
//					"attrs": {
//						"1H1LEB2U80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83814",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LET83815",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U80",
//							"faceTagName": "up"
//						},
//						"1H1LEB2U82": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83816",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LET83817",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U82",
//							"faceTagName": "over"
//						},
//						"1H1LEB2U84": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83818",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LET83819",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U84",
//							"faceTagName": "down"
//						},
//						"1H1LEB2U86": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83820",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LET83821",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.6",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U86",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1LD0QTK8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1LD0QTK9",
//					"attrs": {
//						"traceSize": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LD0QTK10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "checked"
//				},
//				{
//					"type": "string",
//					"valText": "text"
//				},
//				{
//					"type": "string",
//					"valText": "fontSize"
//				},
//				{
//					"type": "string",
//					"valText": "color"
//				}
//			]
//		}
//	}
//}