//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G6VV9J680StartDoc*/
/*}#1G6VV9J680StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnTabLabel=function(text,minSize,trkH){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let colors=appCfg.darkMode?appCfg.colorDK:appCfg.color ;
	
	/*#{1G6VV9J687LocalVals*/
	let focused=0;
	/*}#1G6VV9J687LocalVals*/
	
	/*#{1G6VV9J687PreState*/
	/*}#1G6VV9J687PreState*/
	/*#{1G6VV9J687PostState*/
	/*}#1G6VV9J687PostState*/
	cssVO={
		"hash":"1G6VV9J687",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":minSize,"h":trkH,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G6VVHUHO0",
				"type":"box","x":5,"y":3,"w":"FW-10","h":trkH-3,"autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
				"border":[1,1,0,1],"borderColor":[0,0,0,0],"shadowX":0,"shadowY":0,"shadowBlur":4,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1G6VVNQNU0",
				"type":"text","id":"TxtText","x":0,"y":4,"w":"FW","h":"FH-3","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodySub,"text":text,"fontSize":(trkH>=30)?trkH-15:15,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
				"alignV":1,
			}
		],
		/*#{1G6VV9J687ExtraCSS*/
		/*}#1G6VV9J687ExtraCSS*/
		faces:{
			"up":{
				/*#{1G6VVQM9F0PreCode*/
				$(){
					return !focused;
				},
				/*}#1G6VVQM9F0PreCode*/
				"#1G6VVHUHO0":{
					"background":[0,0,0,0]
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor["fontBodySub"]
				}
			},"over":{
				/*#{1G6VVQQRM0PreCode*/
				$(){
					return !focused;
				},
				/*}#1G6VVQQRM0PreCode*/
				"#1G6VVHUHO0":{
					"background":[0,0,0,0]
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor["fontBody"]
				}
			},"down":{
				/*#{1G6VVQU5L0PreCode*/
				$(){
					return !focused;
				},
				/*}#1G6VVQU5L0PreCode*/
				"#1G6VVHUHO0":{
					"background":[0,0,0,0]
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor["fontBody"]
				}
			},"gray":{
				"#1G6VVHUHO0":{
					"background":[0,0,0,0]
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor.fontBodyLit
				}
			},"focus":{
				"#1G6VVHUHO0":{
					"shadow":true,"borderColor":cfgColor.lineBodySub,"background":cfgColor.body
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor["fontBody"]
				},
				/*#{1G6VVRA6O0Code*/
				$(){
					focused=1;
				},
				/*}#1G6VVRA6O0Code*/
			},"blur":{
				"#1G6VVHUHO0":{
					"shadow":false,"borderColor":[0,0,0,0],"background":[0,0,0,0]
				},
				/*TxtText*/"#1G6VVNQNU0":{
					"color":cfgColor["fontBodySub"]
				},
				/*#{1G6VVREA50Code*/
				$(){
					focused=0;
				},
				/*}#1G6VVREA50Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G6VV9J687Create*/
			let w;
			w=self.TxtText.textW;
			w+=20;
			if(w>minSize){
				self.w=w;
			}
			/*}#1G6VV9J687Create*/
		},
		/*#{1G6VV9J687EndCSS*/
		/*}#1G6VV9J687EndCSS*/
	};
	/*#{1G6VV9J687PostCSSVO*/
	/*}#1G6VV9J687PostCSSVO*/
	return cssVO;
};
/*#{1G6VV9J687ExCodes*/
/*}#1G6VV9J687ExCodes*/

BtnTabLabel.gearExport={
	framework: "vfact",
	hudType: "button",
	"showName":"BtnTabLabel",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Conifg"
		}, 
		"minSize": {
			"name": "minSize", "showName": "minSize", "type": "int", "key": true, "fixed": true, "initVal": 120
		}, 
		"trkH": {
			"name": "trkH", "showName": "trkH", "type": "int", "key": true, "fixed": true, "initVal": 24
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1G6VV9J680ExGearInfo*/
	/*}#1G6VV9J680ExGearInfo*/
};
/*#{1G6VV9J680EndDoc*/
/*}#1G6VV9J680EndDoc*/

export default BtnTabLabel;
export{BtnTabLabel};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G6VV9J680",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G6VV9J681",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "50",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G6VV9J682",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA304ICI0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G6VV9J683",
//			"attrs": {
//				"text": {
//					"type": "string",
//					"valText": "Conifg"
//				},
//				"minSize": {
//					"type": "int",
//					"valText": "120"
//				},
//				"trkH": {
//					"type": "int",
//					"valText": "24"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G6VV9J684",
//			"attrs": {
//				"colors": {
//					"type": "auto",
//					"valText": "#appCfg.darkMode?appCfg.colorDK:appCfg.color "
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G6VV9J685",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "BtnTabLabel",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G6VV9J686",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVQM9F0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6190",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVQQRM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6191",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVQU5L0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6192",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVR2GN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6193",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVRA6O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6194",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G6VVREA50",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G700C6195",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA3056CM0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G6VV9J687",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G6VV9J688",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "#minSize",
//						"h": "#trkH",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G6VVHUHO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G6VVLK8C0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "5",
//										"y": "3",
//										"w": "\"FW-10\"",
//										"h": "#trkH-3",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "[1,1,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,0]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "0",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G6VVLK8C1",
//									"attrs": {
//										"1G6VVQQRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C6196",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C6197",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQQRM0",
//											"faceTagName": "over"
//										},
//										"1G6VVQU5L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C6198",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C6199",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQU5L0",
//											"faceTagName": "down"
//										},
//										"1G6VVQM9F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61910",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61911",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQM9F0",
//											"faceTagName": "up"
//										},
//										"1G6VVR2GN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61912",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61913",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVR2GN0",
//											"faceTagName": "gray"
//										},
//										"1G6VVRA6O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61914",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61915",
//													"attrs": {
//														"shadow": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodySub"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.body"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVRA6O0",
//											"faceTagName": "focus"
//										},
//										"1G6VVREA50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61916",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61917",
//													"attrs": {
//														"shadow": {
//															"type": "bool",
//															"valText": "false"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVREA50",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G6VVLK8C2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA3056CM1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G6VVNQNU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G700C61918",
//									"attrs": {
//										"type": "text",
//										"id": "TxtText",
//										"position": "Absolute",
//										"x": "0",
//										"y": "4",
//										"w": "\"FW\"",
//										"h": "\"FH-3\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#(trkH>=30)?trkH-15:15",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G700C61919",
//									"attrs": {
//										"1G6VVQU5L0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61922",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61923",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQU5L0",
//											"faceTagName": "down"
//										},
//										"1G6VVQM9F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61924",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61925",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQM9F0",
//											"faceTagName": "up"
//										},
//										"1G6VVR2GN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61926",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61927",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor.fontBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVR2GN0",
//											"faceTagName": "gray"
//										},
//										"1G6VVRA6O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61928",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61929",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVRA6O0",
//											"faceTagName": "focus"
//										},
//										"1G6VVREA50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G700C61930",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G700C61931",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVREA50",
//											"faceTagName": "blur"
//										},
//										"1G6VVQQRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA3056CM2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA3056CM3",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G6VVQQRM0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G700C61932",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA3056CM4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G6VV9J689",
//					"attrs": {
//						"1G6VVQU5L0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G700C61935",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G700C61936",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G6VVQU5L0",
//							"faceTagName": "down"
//						},
//						"1G6VVREA50": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G8UBQSFT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G8UBQSFT1",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G6VVREA50",
//							"faceTagName": "blur"
//						},
//						"1G6VVQM9F0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G8UBQSFT4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G8UBQSFT5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G6VVQM9F0",
//							"faceTagName": "up"
//						},
//						"1G6VVR2GN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA3056CM5",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA3056CM6",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G6VVR2GN0",
//							"faceTagName": "gray"
//						},
//						"1G6VVQQRM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA3056CM7",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA3056CM8",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G6VVQQRM0",
//							"faceTagName": "over"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G6VV9J6810",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IA3056CM9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G6VV9J6811",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}