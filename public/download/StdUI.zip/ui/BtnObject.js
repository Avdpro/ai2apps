//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "./BtnCheck.js";
/*#{1H1O4B7OK0StartDoc*/
/*}#1H1O4B7OK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnObject=function(obj,converter){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnCheck;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O4B7OK1LocalVals*/
	let focused=false;
	if(converter){
		obj=converter(obj);
	}
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":txtSize.smallPlus,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":obj.height||obj.h||24,"cursor":"pointer","padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","enable":(obj.enable===false || obj.enable===0)?false:true,"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"obj":obj,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":obj.iconSize*0.5||"(FH-4)*0.5","y":obj.iconSize*0.5||"(FH-4)*0.5","w":obj.iconSize||"FH-4","h":obj.iconSize||"FH-4",
				"anchorX":1,"anchorY":1,"autoLayout":true,"uiEvent":-1,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":obj.iconColor||obj.color||cfgColor.fontBody,
				"border":obj.icon===""?1:0,"borderColor":obj.color||cfgColor.fontBody,"attached":(!!obj.icon)&&(obj.icon!=="")&&(!obj.emoji),"maskImage":obj.icon,
			},
			{
				"hash":"1HAAHR1A50",
				"type":BtnCheck(state.fontSize+4,"",obj.checked,false),"id":"BtnCheck","position":"relative","x":0,"y":0,"margin":[0,5,0,0],"attached":!!obj.selectable,
			},
			{
				"hash":"1I9L6A25J0",
				"type":"box","position":"relative","x":0,"y":0,"w":obj.iconSize||"FH-4","h":obj.iconSize||"FH-4","margin":[0,3,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":[255,255,255,1],"attached":(!!obj.iconColor)&&(obj.icon===""),
				children:[
					{
						"hash":"1I9L6C4CL0",
						"type":"image","id":"ImgColorBG","position":"relative","x":0,"y":0,"w":"100%","h":"100%","alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"image":appCfg.sharedAssets+"/checker.svg","fitSize":true,
					},
					{
						"hash":"1I9L6FRHN0",
						"type":"box","id":"BoxColor","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":obj.iconColor,
						"border":1,"attached":(!!obj.iconColor)&&(obj.icon===""),
					}
				],
			},
			{
				"hash":"1IIU52RKJ0",
				"type":"text","id":"TxtEmoji","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"styleClass":"","color":[0,0,0],"text":obj.emoji,
				"fontSize":$P(()=>(state.fontSize+8),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":obj.emoji,
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":obj.color||cfgColor.fontBody,"text":obj.text,"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,
			},
			{
				"hash":"1H1O640F30",
				"type":"box","id":"BoxCheck","x":">calc(100% - 5px)","y":"50%","w":"FH-6","h":"FH-6","anchorX":2,"anchorY":1,"display":(!!obj.check&&(!obj.selectable)),
				"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":obj.color||cfgColor.fontBody,"border":1,"maskImage":appCfg.sharedAssets+"/check_fat.svg",
				"attached":("check" in obj),
			}
		],
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1O4B7OK1SetfontSize*/
			/*}#1H1O4B7OK1SetfontSize*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		get $$checked(){
			if(btnCheck){
				return btnCheck.checked;
			}
			return !!obj.check;
		},
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1O6SN0K0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1O6SN0K0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"over":{
				/*#{1H1O6SMEQ0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1O6SMEQ0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				/*#{1H1O6TNKJ2PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1O6TNKJ2PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"focus":{
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["gntFocus"]
				},
				/*#{1IA0K9VTV0Code*/
				$(){
					focused=true;
				}
				/*}#1IA0K9VTV0Code*/
			},"blur":{
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				},
				/*#{1IA0KA6QE0Code*/
				$(){
					focused=false;
				}
				/*}#1IA0KA6QE0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnCheck=self.BtnCheck;
			/*#{1H1O4B7OK1Create*/
			this.preferW=this.webObj.scrollWidth;
			if(obj.check){
				this.preferW+=25;
			}
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	cssVO.constructor=BtnObject;
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

//----------------------------------------------------------------------------
BtnObject.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1O4B7OK1PreAISpot*/
	/*}#1H1O4B7OK1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("对象行"):("Object Line"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1O4B7OK1PostAISpot*/
	/*}#1H1O4B7OK1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnObject.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("对象行"):("Object Line")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:24,
	catalog:"Buttons",
	args: {
		"obj": {
			"name": "obj", "showName": "obj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"text": "Object", "icon": "/~/-tabos/shared/assets/prj.svg", "iconColor": [0,0,0,1], "emoji": "😧"
			}, 
			"initValText": "#{\"text\":\"Object\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1],emoji:\"😧\"}"
		}, 
		"converter": {
			"name": "converter", "showName": "converter", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
		fontSize:{name:"fontSize",type:"int",initVal:14,editType:"fontSize"}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1H1O4B7OK0ExGearInfo*/
	/*}#1H1O4B7OK0ExGearInfo*/
};
/*#{1H1O4B7OK0EndDoc*/
/*}#1H1O4B7OK0EndDoc*/

export default BtnObject;
export{BtnObject};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1O4B7OK0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1O4B7OL0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1O4B7OL1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5VFJH9A0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1O4B7OL2",
//			"attrs": {
//				"obj": {
//					"type": "auto",
//					"valText": "#{\"text\":\"Object\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1],emoji:\"😧\"}"
//				},
//				"converter": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1O4B7OL3",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1O4B7OL4",
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#txtSize.smallPlus",
//					"editType": "fontSize"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Object Line",
//			"localize": {
//				"EN": "Object Line",
//				"CN": "对象行"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "24",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1O4B7OL5",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SN0K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SMEQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ3",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ5",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IA0K9VTV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IA0KC4440",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IA0KA6QE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IA0KC4441",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAHAJUP0",
//			"attrs": {
//				"Text Only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAHPAT91",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\"}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Icon with text": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAI4JQ00",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1]}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Color and checked": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAHPAT90",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1],\"check\":true,\"enable\":false}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Selectable": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAI4JQ01",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",selectable:true,checked:false}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"emoji": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1IIU5F14I0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1],emoji:\"😧\"}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1O4B7OK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1O4B7OL6",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "#obj.height||obj.h||24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "#(obj.enable===false || obj.enable===0)?false:true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O6BJ290",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6PGCJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O6PGCJ1",
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ7",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ9",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0K9VTV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC4442",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC4443",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"gntFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0K9VTV0",
//											"faceTagName": "focus"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC4444",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC4445",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O6PGCJ2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O6PGCJ3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O5PAKH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "#obj.iconSize*0.5||\"(FH-4)*0.5\"",
//										"y": "#obj.iconSize*0.5||\"(FH-4)*0.5\"",
//										"w": "#obj.iconSize||\"FH-4\"",
//										"h": "#obj.iconSize||\"FH-4\"",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#obj.iconColor||obj.color||cfgColor.fontBody",
//										"border": "#obj.icon===\"\"?1:0",
//										"borderStyle": "Solid",
//										"borderColor": "#obj.color||cfgColor.fontBody",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#(!!obj.icon)&&(obj.icon!==\"\")&&(!obj.emoji)",
//										"maskImage": "#obj.icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG1",
//									"attrs": {
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC4446",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC4447",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC4448",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC4449",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44412",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44413",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1LD0QTJ0",
//							"jaxId": "1HAAHR1A50",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HAAHR1A51",
//									"attrs": {
//										"size": "#state.fontSize+4",
//										"text": "",
//										"checked": "#obj.checked",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HAAHR1A52",
//									"attrs": {
//										"type": "#null#>BtnCheck(state.fontSize+4,\"\",obj.checked,false)",
//										"id": "BtnCheck",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,5,0,0]",
//										"attach": "#!!obj.selectable"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HAAHR1A53",
//									"attrs": {
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44414",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44415",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44416",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44417",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44418",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44419",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44420",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44421",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44424",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44425",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAAHR1A54",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAAHR1A55",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HAAHR1A56",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I9L6A25J0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9L6CKPM0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#obj.iconSize||\"FH-4\"",
//										"h": "#obj.iconSize||\"FH-4\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#(!!obj.iconColor)&&(obj.icon===\"\")"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1I9L6C4CL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9L6C4CL1",
//													"attrs": {
//														"type": "image",
//														"id": "ImgColorBG",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "0.5",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#appCfg.sharedAssets+\"/checker.svg\"",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9L6C4CM5",
//													"attrs": {
//														"1H1O6SN0K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC4450",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC4451",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6SN0K0",
//															"faceTagName": "up"
//														},
//														"1H1O6SMEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC4452",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC4453",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6SMEQ0",
//															"faceTagName": "over"
//														},
//														"1H1O6TNKJ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC4454",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC4455",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6TNKJ2",
//															"faceTagName": "down"
//														},
//														"1H1O6TNKJ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC4456",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC4457",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6TNKJ4",
//															"faceTagName": "gray"
//														},
//														"1IA0KA6QE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44510",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44511",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IA0KA6QE0",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9L6C4CM6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9L6C4CM7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I9L6FRHN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9L6FRHN1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxColor",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#obj.iconColor",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"attach": "#(!!obj.iconColor)&&(obj.icon===\"\")"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9L6FRHO0",
//													"attrs": {
//														"1H1O6SN0K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44512",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44513",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6SN0K0",
//															"faceTagName": "up"
//														},
//														"1H1O6SMEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44514",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44515",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6SMEQ0",
//															"faceTagName": "over"
//														},
//														"1H1O6TNKJ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44516",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44517",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6TNKJ2",
//															"faceTagName": "down"
//														},
//														"1H1O6TNKJ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44518",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44519",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1O6TNKJ4",
//															"faceTagName": "gray"
//														},
//														"1IA0KA6QE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA0KC44522",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA0KC44523",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IA0KA6QE0",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9L6FRHO1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9L6FRHO2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I9L6CKPM1",
//									"attrs": {
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44524",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44525",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44526",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44527",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44528",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44529",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44530",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44531",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44534",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44535",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I9L6CKPM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9L6CKPM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1IIU52RKJ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIU58OTI0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtEmoji",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#obj.emoji",
//										"font": "",
//										"fontSize": "${state.fontSize+8},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"attach": "#obj.emoji"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIU58OTI1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIU58OTI2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIU58OTI3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1O5T0HD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#obj.color||cfgColor.fontBody",
//										"text": "#obj.text",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG5",
//									"attrs": {
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44536",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44537",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44538",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44539",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44542",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44543",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O640F30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG8",
//									"attrs": {
//										"type": "box",
//										"id": "BoxCheck",
//										"position": "Absolute",
//										"x": "100%-5",
//										"y": "50%",
//										"w": "\"FH-6\"",
//										"h": "\"FH-6\"",
//										"anchorH": "Right",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "#(!!obj.check&&(!obj.selectable))",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#obj.color||cfgColor.fontBody",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/check_fat.svg\"",
//										"attach": "#(\"check\" in obj)"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG9",
//									"attrs": {
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44544",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44545",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44546",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44547",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1IA0KA6QE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0KC44550",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0KC44551",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA0KA6QE0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1O4B7OL7",
//					"attrs": {
//						"1H1O6SMEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O6TNKJ16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6TNKJ17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SMEQ0",
//							"faceTagName": "over"
//						},
//						"1H1O6SN0K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SN0K0",
//							"faceTagName": "up"
//						},
//						"1H1O6TNKJ2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU19",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ2",
//							"faceTagName": "down"
//						},
//						"1H1O6TNKJ4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU21",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ4",
//							"faceTagName": "gray"
//						},
//						"1IA0KA6QE0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA0KC44554",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA0KC44555",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IA0KA6QE0",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1O4B7OL8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1O4B7OL9",
//					"attrs": {
//						"obj": {
//							"type": "auto",
//							"valText": "#obj"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O4B7OL10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "fontSize"
//				}
//			]
//		}
//	}
//}