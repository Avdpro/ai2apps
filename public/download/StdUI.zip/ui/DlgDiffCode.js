//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnSwitch} from "./BtnSwitch.js";
import {BtnText} from "./BtnText.js";
/*#{1IHQMM9UM0StartDoc*/
/*
This is a template for standard dialog.
*/
/*}#1IHQMM9UM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgDiffCode=function(title,closeIcon,buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,boxButtons,btnDiffOnly,btnYes,btnNo,btn3rd;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO,orgCode,newCode,cm;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":["确定","取消"],
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":">calc(50% - 20px)","w":720,"h":"","anchorX":1,"anchorY":1,"padding":10,"minW":"","minH":"","maxW":"90%","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"display":!!closeIcon,"padding":3,
				"attached":!!closeIcon,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					self.close(false);
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":400,"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1IHQN55EB0",
						"type":BtnSwitch(20,false),"id":"BtnDiffOnly","position":"relative","x":0,"y":0,"margin":[0,5,0,20],
						/*#{1IHQN55EB0Codes*/
						OnCheck(checked){
							self.showCode();
						}
						/*}#1IHQN55EB0Codes*/
					},
					{
						"hash":"1IHQN76M80",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","styleClass":"","color":[0,0,0],"text":(($ln==="CN")?("只显示不同"):("Diff only")),"fontWeight":"normal",
						"fontStyle":"normal","textDecoration":"","flex":true,
					},
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,"OK",false,""),"id":"BtnYes","position":"relative","x":0,"y":0,"display":$P(()=>(!!state.buttons[0]),state),"margin":[0,15,0,0],
						"text":$P(()=>(state.buttons[0]),state),
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							newCode=cm?cm.doc.getValue():newCode;
							self.close(newCode);
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,"Cancel",false,""),"id":"BtnNo","position":"relative","x":0,"y":0,"display":$P(()=>(!!state.buttons[1]),state),"margin":[0,15,0,0],
						"text":$P(()=>(state.buttons[1]),state),
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(null);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":$P(()=>(state.buttons[2]),state),
						"anchorY":1,"attached":false,"text":$P(()=>(state.buttons[2]),state),
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							newCode=cm?cm.doc.getValue():newCode;
							self.close({newCode:newCode,orgCode:orgCode});
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnDiffOnly=self.BtnDiffOnly;btnYes=self.BtnYes;btnNo=self.BtnNo;btn3rd=self.Btn3rd;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		state.title=dlgVO.title||dlgVO.caption||(($ln==="CN")?("审查修改"):/*EN*/("Review modify"))
		if(dlgVO.buttons){
			state.buttons[0]=dlgVO.buttons[0];
			state.buttons[1]=dlgVO.buttons[1]||null;
			state.buttons[2]=dlgVO.buttons[2]||null;
		}else if(dlgVO.button1){
			state.buttons[0]=dlgVO.button1;
			state.buttons[1]=dlgVO.button2||null;
			state.buttons[2]=dlgVO.button3||null;
		}else{
			state.buttons[0]=(($ln==="CN")?("确定"):/*EN*/("OK"));
			state.buttons[1]=(($ln==="CN")?("取消"):/*EN*/("Cancel"));
			state.buttons[2]=null;
		}
		btnDiffOnly.checked=!!vo.diffOnly;
		orgCode=vo.orgCode||"";
		newCode=vo.newCode||"";
		//Show codes:
		self.showCode();
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showCode=async function(){
		let dv,code;
		let target = boxContent.webObj;
		await VFACT.appendScript("/@codemirror/extern/diff_match_patch.js");
		await VFACT.appendScript("/@codemirror/addon/merge.js");
		if(cm){
			newCode=cm?cm.doc.getValue():newCode;
		}
		target.innerHTML = "";
		dv = CodeMirror.MergeView(target, {
			value: newCode,
			orig: orgCode,
			lineNumbers: true,
			mode: "text",
			highlightDifferences: true,
			connect: true,
			collapseIdentical: btnDiffOnly.checked?5:false
		});
		cm=dv.edit;
	};
	
	/*}#1H1T7ISV51PostCSSVO*/
	cssVO.constructor=DlgDiffCode;
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

//----------------------------------------------------------------------------
DlgDiffCode.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1T7ISV51PreAISpot*/
	/*}#1H1T7ISV51PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("标准对话框"):("Standard Dialog"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1T7ISV51PostAISpot*/
	/*}#1H1T7ISV51PostAISpot*/
	return exposeVO;
};

/*#{1IHQMM9UM0EndDoc*/
/*}#1IHQMM9UM0EndDoc*/

export default DlgDiffCode;
export{DlgDiffCode};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IHQMM9UM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#[\"确定\",\"取消\"]"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I8OEIDG90",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%-20",
//						"w": "720",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "90%",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1T84P6A0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H1T88CE90",
//									"attrs": {
//										"style": "front",
//										"w": "28",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H1T88CE91",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "Absolute",
//										"x": "100%-36",
//										"y": "5",
//										"display": "#!!closeIcon",
//										"face": "",
//										"padding": "3",
//										"attach": "#!!closeIcon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T88CE92",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T88CE93",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1T8K68O0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H1T8KC4H0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T88CE94",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H211US3V0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "400",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1LFSMBH0",
//											"jaxId": "1IHQN55EB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHQNEONE0",
//													"attrs": {
//														"size": "20",
//														"check": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IHQNEONE1",
//													"attrs": {
//														"type": "#null#>BtnSwitch(20,false)",
//														"id": "BtnDiffOnly",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,20]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHQNEONE2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHQNEONE3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHQNEONE4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IHQNEONE5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IHQN76M80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHQNEONE6",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "Diff only",
//															"localize": {
//																"EN": "Diff only",
//																"CN": "只显示不同"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHQNEONE7",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHQNEONE8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHQNEONE9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": "OK",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,\"OK\",false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "${!!state.buttons[0]},state",
//														"face": "",
//														"anchorV": "Top",
//														"margin": "[0,15,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "${state.buttons[0]},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T820FU1",
//													"attrs": {
//														"style": "warning",
//														"w": "80",
//														"h": "24",
//														"text": "Cancel",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T820FU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",80,24,\"Cancel\",false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "${!!state.buttons[1]},state",
//														"face": "",
//														"anchorV": "Top",
//														"margin": "[0,15,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "${state.buttons[1]},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T820FU3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T820FU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JQQ40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T820FU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V2",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H25185U60",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H25185U61",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[2]",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H25185U62",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,state.buttons[2],false,\"\")",
//														"id": "Btn3rd",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "${state.buttons[2]},state",
//														"face": "",
//														"anchorV": "Center",
//														"attach": "false",
//														"text": {
//															"type": "string",
//															"valText": "${state.buttons[2]},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H25185U70",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H25185U71",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H25185U72",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H25185U73",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H25185U74",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H25185U75",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}