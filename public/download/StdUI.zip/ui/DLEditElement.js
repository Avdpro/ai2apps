//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HQSTVR7J0StartDoc*/
/*}#1HQSTVR7J0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLEditElement=function(box,lineDef,opts,def){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxLine,btnMenu;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let mode=def?(def.mode||""):"";
	let icon=(def&&def.icon)?def.icon:(appCfg.sharedAssets+"/menu.svg");
	let tip=(def&&def.tip)?def.tip:((($ln==="CN")?("编辑"):/*EN*/("Edit")));
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	let line=null;
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":25,"maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","id":"BoxLine","position":"relative","x":0,"y":0,"w":">calc(100% - 28px)","h":"","minW":"","minH":25,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,
				/*#{1HQ1GLVEK0Codes*/
				children:[lineDef]
				/*}#1HQ1GLVEK0Codes*/
			},
			{
				"hash":"1HQSU12AU0",
				"type":BtnIcon("front",25,0,icon,null),"id":"BtnMenu","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
				"tip":tip,
				"OnClick":function(event){
					/*#{1HQU6ITKC0FunctionBody*/
					self.showMenu(this);
					/*}#1HQU6ITKC0FunctionBody*/
				},
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		dataView:box,
		get $$property(){
			return line?line.property:"";
		},
		set $$property(p){
			return line?(line.property=p):"";
		},
		get $$template(){
			return line?line.template:null;
		},
		get $$value(){
			return line?line.value:null;
		},
		get $$line(){
			return line;
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxLine=self.BoxLine;btnMenu=self.BtnMenu;
			/*#{1HQ1EDCKJ1Create*/
			line=boxLine.firstChild;
			if(line.waitCreate){
				self.waitCreate=line.waitCreate;
			}
			//Proxy some functions:
			self.getMissing=line.getMissing?line.getMissing.bind(line):null;
			self.clearErrorTips=line.clearErrorTips?line.clearErrorTips.bind(line):null;
			self.showErrorTip=line.showErrorTip?line.showErrorTip.bind(line):null;
			self.clearErrorTip=line.clearErrorTip?line.clearErrorTip.bind(line):null;
			self.getPptLine=line.getPptLine?line.getPptLine.bind(line):null;
			self.getDecoLine=line.getDecoLine?line.getDecoLine.bind(line):null;
			self.getPptValue=line.getPptValue?line.getPptValue.bind(line):null;
			self.showAllLines=line.showAllLines?line.showAllLines.bind(line):null;
			self.showPptLine=line.showPptLine?line.showPptLine.bind(line):null;
			self.hidePptLine=line.hidePptLine?line.hidePptLine.bind(line):null;
			self.showDecoLine=line.showDecoLine?line.showDecoLine.bind(line):null;
			self.hideDecoLine=line.hideDecoLine?line.hideDecoLine.bind(line):null;
			self.showErrorTip=line.showErrorTip?line.showErrorTip.bind(line):null;
			self.clearErrorTip=line.clearErrorTip?line.clearErrorTip.bind(line):null;
			self.getEditedVO=line.getEditedVO?line.getEditedVO.bind(line):null;
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		return line && line.commitEdit(val);
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(btn){
		if(mode==="action"){
			box.OnPptAction && box.OnPptAction(self,btn,def?def.action:null);
		}else if(box.showElementMenu){
			box.showElementMenu(self,btn);
		}
	}
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		line && line.OnDataChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		line && line.updateLabel(label);
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		line && line.updateValue();
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/


/*#{1HQSTVR7J0EndDoc*/
/*}#1HQSTVR7J0EndDoc*/

export default DLEditElement;
export{DLEditElement};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQSTVR7J0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"lineDef": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 1, edit:0}"
//				},
//				"def": {
//					"type": "auto",
//					"valText": "#{mode:\"action\"}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"mode": {
//					"type": "string",
//					"valText": "#def?(def.mode||\"\"):\"\""
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#(def&&def.icon)?def.icon:(appCfg.sharedAssets+\"/menu.svg\")"
//				},
//				"tip": {
//					"type": "string",
//					"valText": "#(def&&def.tip)?def.tip:((($ln===\"CN\")?(\"编辑\"):/*EN*/(\"Edit\")))"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxLine",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%-28",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "25",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "false",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1HQSU12AU0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HQSUULPC0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "25",
//										"h": "0",
//										"icon": "#icon",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HQSUULPC1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",25,0,icon,null)",
//										"id": "BtnMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQSUULPC2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HQSUULPC3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HQU6ITKC0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HQU6ITKF0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HQSUULPC4",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "#tip"
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HQSUULPC5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}