//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1O8E46I0StartDoc*/
import {BtnObject} from "./BtnObject.js";
/*}#1H1O8E46I0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgMenu=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let contents;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O8E46I1LocalVals*/
	let dlgVO=null;
	let app=window.tabOSApp;
	/*}#1H1O8E46I1LocalVals*/
	
	/*#{1H1O8E46I1PreState*/
	/*}#1H1O8E46I1PreState*/
	/*#{1H1O8E46I1PostState*/
	/*}#1H1O8E46I1PostState*/
	cssVO={
		"hash":"1H1O8E46I1",nameHost:true,
		"type":"box","x":42,"y":38,"w":100,"h":"","overflow":"auto-y","padding":10,"minW":"","minH":30,"maxW":"","maxH":500,"styleClass":"","background":cfgColor["menuBG"],
		"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":8,"shadow":true,"shadowX":3,"shadowY":5,"shadowBlur":10,"shadowColor":[0,0,0,0.2],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H2CN3UCE0",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
			}
		],
		/*#{1H1O8E46I1ExtraCSS*/
		/*}#1H1O8E46I1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			contents=self.Contents;
			/*#{1H1O8E46I1Create*/
			let items,item,i,n;
			items=contents.children;
			n=items.length;
			for(i=0;i<n;i++){
				item=items[i];
				item.OnMenuItemClick=item.OnClick;
				item.OnClick=function(evt){
					self.OnClick(this,evt);
				};
			}
			/*}#1H1O8E46I1Create*/
		},
		/*#{1H1O8E46I1EndCSS*/
		/*}#1H1O8E46I1EndCSS*/
	};
	/*#{1H1O8E46I1PostCSSVO*/
	cssVO.showDlg=function(vo){
		let x,y,w,h,list,i,n,item,mx,my,maxW,clkEvt,anyCheck;
		let orgHud=vo.hud;
		dlgVO=vo;
		list=vo.items;
		clkEvt=vo.event;
		if(list){
			if(clkEvt){
				x=clkEvt.x;
				y=clkEvt.y;
				self.w=vo.width||vo.w||120;
			}else if(orgHud){
				let webObj,rect,asW,asH;
				webObj=orgHud.webObj;
				rect=webObj.getBoundingClientRect();
				asW=orgHud.w>=0?(rect.width/orgHud.w):1;
				asH=orgHud.h>=0?(rect.height/orgHud.h):1;
				x=rect.left+(vo.x*asW||0);
				y=rect.top+(vo.y*asH||orgHud.h*asH);
	
				self.w=vo.width||vo.w||(orgHud.w>120?orgHud.w:120);
			}else{
				x=vo.x||0;
				y=vo.y||0;
				self.w=vo.width||vo.w||120;
			}
			contents.clearChildren();
			n=list.length;
			if(vo.maxLines){
				if(n>vo.maxLines){
					self.overflow=[0,2];
				}else{
					self.overflow=[0,0];
				}
			}else{
				self.overflow=[0,0];
			}
			maxW=0;
			anyCheck=false;
			for(i=0;i<n;i++){
				item=list[i];
				if(item==="_"){
					contents.appendNewChild({
						type:"box",x:"50%",y:0,w:"90%",h:1,position:"relative",anchorX:1,margin:[5,0,5,0],background:cfgColor.lineBodyLit
					});				
				}else{
					anyCheck|=item.check;
					if(typeof(item)==="string"){
						item={text:item,code:item};
					}
					if(item){
						item=contents.appendNewChild({
							type:BtnObject(item,dlgVO.converter),x:0,y:0,item:item,position:"relative",
							OnClick:function(e){
								self.OnClick(this.item,e);
								return 1;
							}
						});
						if(item.preferW>maxW){//TODO: Replace with webObj.scrollWidth?
							maxW=item.preferW;
						}
					}
				}
			}
			if(anyCheck){
				maxW+=25;
			}
			if(self.w<maxW+25){
				self.w=maxW+25;
			}
		}
		w=self.w;
		h=contents.h;
		self.h=h-5;//For ani
		switch(vo.anchorH){
			case 0:
			default:
				break;
			case 1:
				x-=w*0.5;
				break;
			case 2:
				x-=w;
				break;
		}
		switch(vo.anchorV){
			case 0:
			default:
				break;
			case 1:
				y-=h*0.5;
				break;
			case 2:
				y-=h;
				break;
		}
		h=h>500?500:h;
		mx=app.clientW-30;
		my=app.clientH-30;
		x=x<0?0:(x+w>mx?(mx-w):x);
		y=y<0?0:(y+h>my?(my-h):y);
		self.x=x;self.y=y;
		self.animate({type:"pose",h:h+20,time:80});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(item,evt){
		app.closeDlg(self,item);
		if(item.OnMenuItemClick){
			item.OnMenuItemClick();
			return;
		}
		window.setTimeout(()=>{
			dlgVO.callback && dlgVO.callback(item,evt);
		},0);
	}
	
	//------------------------------------------------------------------------
	cssVO.OnBGClick=function(){
		app.closeDlg(self,null);
		dlgVO.callback && dlgVO.callback(null);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnKeyDown=function(key,evt){
		if(key==="Escape"){
			app.closeDlg(self,null);
			dlgVO.callback && dlgVO.callback(null);
			return true;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Escape"){
			app.closeDlg(self,null);
			dlgVO.callback && dlgVO.callback(null);
			return true;
		}
	};
	/*}#1H1O8E46I1PostCSSVO*/
	return cssVO;
};
/*#{1H1O8E46I1ExCodes*/
/*}#1H1O8E46I1ExCodes*/

DlgMenu.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":(($ln==="CN")?("菜单"):("Menu")),icon:"menu.svg",previewImg:false,
	fixPose:false,initW:100,initH:30,
	"desc":(($ln==="CN")?("菜单框架"):("Menu frame")),
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","padding","minW","minH","maxW","maxH","styleClass","background","border","borderStyle","borderColor","corner","attach"],
	faces:[],
	subContainers:{
		"1H2CN3UCE0":{"showName":"Contents","contentLayout":"flex-y"}
	},
	/*#{1H1O8E46I0ExGearInfo*/
	/*}#1H1O8E46I0ExGearInfo*/
};
/*#{1H1O8E46I0EndDoc*/
/*}#1H1O8E46I0EndDoc*/

export default DlgMenu;
export{DlgMenu};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1H1O8E46I0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1O8E46I2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1O8E46I3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5NSV4CM0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1O8E46I4",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1H1O8E46I5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1O8E46I6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Menu",
//			"localize": {
//				"EN": "Menu",
//				"CN": "菜单"
//			},
//			"localizable": true
//		},
//		"gearIcon": "menu.svg",
//		"gearW": "100",
//		"gearH": "30",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "Menu frame",
//			"localize": {
//				"EN": "Menu frame",
//				"CN": "菜单框架"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1O8E46I7",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HAQLDDQR0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1H1O8E46I1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1O8E46I8",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "42",
//						"y": "38",
//						"w": "100",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "500",
//						"face": "",
//						"styleClass": "",
//						"background": "#cfgColor[\"menuBG\"]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor[\"fontBodyLit\"]",
//						"corner": "8",
//						"shadow": "true",
//						"shadowX": "3",
//						"shadowY": "5",
//						"shadowBlur": "10",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.2]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2CN3UCE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2CN67VD0",
//									"attrs": {
//										"type": "hud",
//										"id": "Contents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H2CN67VD1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H2CN67VD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H2CN67VD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1O8E46I9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1O8E46I10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1O8E46I11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O8E46I12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "true",
//				"background": "true",
//				"color": "false",
//				"gradient": "false",
//				"border": "true",
//				"borders": "false",
//				"borderStyle": "true",
//				"borderColor": "true",
//				"borderColors": "false",
//				"corner": "true",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}