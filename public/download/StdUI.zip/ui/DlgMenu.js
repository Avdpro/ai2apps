//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1O8E46I0StartDoc*/
import {BtnObject} from "./BtnObject.js";
/*}#1H1O8E46I0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgMenu=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let contents;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O8E46I1LocalVals*/
	let dlgVO=null;
	let app=window.tabOSApp;
	/*}#1H1O8E46I1LocalVals*/
	
	/*#{1H1O8E46I1PreState*/
	/*}#1H1O8E46I1PreState*/
	/*#{1H1O8E46I1PostState*/
	/*}#1H1O8E46I1PostState*/
	cssVO={
		"hash":"1H1O8E46I1",nameHost:true,
		"type":"box","x":42,"y":38,"w":100,"h":"","overflow":1,"padding":5,"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
		"border":1,"borderColor":cfgColor.lineBody,"shadow":true,"shadowX":3,"shadowY":5,"shadowBlur":6,"shadowSpread":2,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H2CN3UCE0",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
			}
		],
		/*#{1H1O8E46I1ExtraCSS*/
		/*}#1H1O8E46I1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			contents=self.Contents;
			/*#{1H1O8E46I1Create*/
			let items,item,i,n;
			items=contents.children;
			n=items.length;
			for(i=0;i<n;i++){
				item=items[i];
				item.OnMenuItemClick=item.OnClick;
				item.OnClick=function(evt){
					self.OnClick(this,evt);
				};
			}
			/*}#1H1O8E46I1Create*/
		},
		/*#{1H1O8E46I1EndCSS*/
		/*}#1H1O8E46I1EndCSS*/
	};
	/*#{1H1O8E46I1PostCSSVO*/
	cssVO.showDlg=function(vo){
		let x,y,w,h,list,i,n,item,mx,my,maxW;
		let orgHud=vo.hud;
		dlgVO=vo;
		list=vo.items;
		if(list){
			if(orgHud){
				let webObj,rect,asW,asH;
				webObj=orgHud.webObj;
				rect=webObj.getBoundingClientRect();
				asW=orgHud.w>=0?(rect.width/orgHud.w):1;
				asH=orgHud.h>=0?(rect.height/orgHud.h):1;
				x=rect.left+(vo.x*asW||0);
				y=rect.top+(vo.y*asH||orgHud.h*asH);
	
				self.w=vo.w||(orgHud.w>120?orgHud.w:120);
			}else{
				x=vo.x||0;
				y=vo.y||0;
				self.w=vo.w||120;
			}
			contents.clearChildren();
			n=list.length;
			if(vo.maxLines){
				if(n>vo.maxLines){
					self.overflow=[0,2];
				}else{
					self.overflow=[0,0];
				}
			}else{
				self.overflow=[0,0];
			}
			maxW=0;
			for(i=0;i<n;i++){
				item=list[i];
				if(item==="_"){
					contents.appendNewChild({
						type:"box",x:"50%",y:0,w:"90",h:1,position:"relative",anchorX:1,margin:[5,0,5,0],background:cfgColor.lineBodySub
					});				
				}else{
					if(typeof(item)==="string"){
						item={text:item,code:item};
					}
					if(item){
						item=contents.appendNewChild({
							type:BtnObject(item,dlgVO.converter),x:0,y:0,item:item,position:"relative",
							OnClick:function(e){
								self.OnClick(this.item,e);
								return 1;
							}
						});
						if(item.preferW>maxW){//TODO: Replace with webObj.scrollWidth?
							maxW=item.preferW;
						}
					}
				}
			}
			if(self.w<maxW+20){
				self.w=maxW+20;
			}
		}
		w=self.w;
		h=contents.h;
		self.h=h-5;//For ani
		switch(vo.anchorH){
			case 0:
			default:
				break;
			case 1:
				x-=w*0.5;
				break;
			case 2:
				x-=w;
				break;
		}
		switch(vo.anchorV){
			case 0:
			default:
				break;
			case 1:
				y-=h*0.5;
				break;
			case 2:
				y-=h;
				break;
		}
		mx=app.clientW-10;
		my=app.clientH-10;
		x=x<0?0:(x+w>mx?(mx-w):x);
		y=y<0?0:(y+h>my?(my-h):y);
		self.x=x;self.y=y;
		self.animate({type:"pose",h:h+10,time:80});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(item,evt){
		app.closeDlg(self,item);
		if(item.OnMenuItemClick){
			item.OnMenuItemClick();
			return;
		}
		window.setTimeout(()=>{
			dlgVO.callback && dlgVO.callback(item,evt);
		},0);
	}
	
	//------------------------------------------------------------------------
	cssVO.OnBGClick=function(){
		app.closeDlg(self,null);
		dlgVO.callback && dlgVO.callback(null);
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Escape"){
			app.closeDlg(self);
			dlgVO.callback && dlgVO.callback(null);
			return true;
		}
	};
	/*}#1H1O8E46I1PostCSSVO*/
	return cssVO;
};
/*#{1H1O8E46I1ExCodes*/
/*}#1H1O8E46I1ExCodes*/

DlgMenu.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":(($ln==="CN")?("菜单"):("Menu")),icon:"menu.svg",previewImg:false,
	fixPose:false,initW:100,initH:30,
	"desc":(($ln==="CN")?("菜单框架"):("Menu frame")),
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","padding","minW","minH","maxW","maxH","styleClass","background","border","borderStyle","borderColor","corner","attach"],
	faces:[],
	subContainers:{
		"1H2CN3UCE0":{"showName":"Contents","contentLayout":"flex-y"}
	},
	/*#{1H1O8E46I0ExGearInfo*/
	/*}#1H1O8E46I0ExGearInfo*/
};
export default DlgMenu;
export{DlgMenu};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1H1O8E46I0",
//	"editVersion": 88,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1O8E46I2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1O8E46I3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5NSV4CM0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1O8E46I4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1O8E46I5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1O8E46I6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Menu",
//			"localize": {
//				"EN": "Menu",
//				"CN": "菜单"
//			},
//			"localizable": true
//		},
//		"gearIcon": "menu.svg",
//		"gearW": "100",
//		"gearH": "30",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "Menu frame",
//			"localize": {
//				"EN": "Menu frame",
//				"CN": "菜单框架"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1O8E46I7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAQLDDQR0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1H1O8E46I1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1O8E46I8",
//					"editVersion": 236,
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "42",
//						"y": "38",
//						"w": "100",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "5",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "#cfgColor.body",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor.lineBody",
//						"corner": "0",
//						"shadow": "true",
//						"shadowX": "3",
//						"shadowY": "5",
//						"shadowBlur": "6",
//						"shadowSpread": "2",
//						"shadowColor": "[0,0,0,0.3]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2CN3UCE0",
//							"editVersion": 42,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2CN67VD0",
//									"editVersion": 92,
//									"attrs": {
//										"type": "hud",
//										"id": "Contents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2CN67VD1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2CN67VD2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2CN67VD3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1O8E46I9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1O8E46I10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1O8E46I11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O8E46I12",
//			"editVersion": 182,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "true",
//				"background": "true",
//				"color": "false",
//				"gradient": "false",
//				"border": "true",
//				"borders": "false",
//				"borderStyle": "true",
//				"borderColor": "true",
//				"borderColors": "false",
//				"corner": "true",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}