//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "./BtnCheck.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1I9Q06C5B0StartDoc*/
import {readPath,applyFileMenu,applyFileDrag,applyFileDrop} from "../FileUtils.js";
/*}#1I9Q06C5B0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnGroup=function(entryObj,options){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnCheck,txtName;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let isFocused=false;
	let isSelect=false;
	
	/*#{1H1O4B7OK1LocalVals*/
	let app,path;
	path=entryObj.path;
	app=VFACT.app;
	options=options||{};
	options={
		height:24,iconSize:20,
		color:cfgColor.fontBody,
		fontSize:txtSize.smallPlus,
		indentSize:15,
		...options
	};
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":options.fontSize||txtSize.smallPlus,"icon":entryObj.icon,"isExpand":false,"text":entryObj.text||entryObj.name,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	let icon=entryObj.icon;
	if(icon && icon[0]!=="/" && icon[0]!=="."){
		icon=appCfg.sharedAssets+"/"+icon;
		state.icon=icon;
	}
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":options.height||24,"cursor":"pointer","padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","enable":entryObj.enable===false?false:true,"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"entry":entryObj,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":options.btnBG,
			},
			{
				"hash":"1HAAHR1A50",
				"type":BtnCheck((options.height||24)-6,"",entryObj.checked,false),"id":"BtnCheck","position":"relative","x":0,"y":0,"margin":[0,2,0,0],"attached":!!options.checkBox,
			},
			{
				"hash":"1I8JDJIIC0",
				"type":BtnIcon("front",options.fontSize,0,appCfg.sharedAssets+"/zhankai.svg",null),"id":"BtnExpand","position":"relative","x":options.fontSize*0.5,
				"y":options.fontSize*0.5,"anchorX":1,"anchorY":1,
				"OnClick":function(event){
					/*#{1I8NL0B6J0FunctionBody*/
					if(state.isExpand){
						self.collapse();
					}else{
						self.expand();
					}
					/*}#1I8NL0B6J0FunctionBody*/
				},
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":"","h":options.iconSize||((options.height||24)-4),"display":!!entryObj.icon,"uiEvent":-1,
				"margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":options.color||cfgColor.fontBody,"attached":entryObj.icon,
				"maskImage":$P(()=>(state.icon),state),"aspect":"1",
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":options.color||cfgColor.fontBody,"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"flex":true,
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1O4B7OK1Settext*/
			/*}#1H1O4B7OK1Settext*/
		},
		get $$isExpand(){return state["isExpand"]},
		set $$isExpand(v){
			state["isExpand"]=v;
			/*#{1H1O4B7OK1SetisExpand*/
			/*}#1H1O4B7OK1SetisExpand*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1O6SN0K0PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6SN0K0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":options.btnBG
				}
			},"over":{
				/*#{1H1O6SMEQ0PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6SMEQ0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				/*#{1H1O6TNKJ2PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6TNKJ2PreCode*/
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				/*#{1H1O6TNKJ4PreCode*/
				$(){
					if(isSelect||isFocused){
						return false;
					}
				},
				/*}#1H1O6TNKJ4PreCode*/
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":options.btnBG
				}
			},"focus":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["gntFocus"]
				},
				/*BtnCheck*/"#1HAAHR1A50":{
					"color":[0,0,0,1]
				},
				/*#{1I8JCALLE0Code*/
				$(){
					isFocused=true;
				}
				/*}#1I8JCALLE0Code*/
			},"blur":{
				/*#{1I8JCAQ1N0PreCode*/
				$(){
					isFocused=false;
					isSelect=false;
					/*if(isSelect){
						self.showFace("select");
						return false;
					}*/
				},
				/*}#1I8JCAQ1N0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":options.btnBG
				},
				/*#{1I8JCAQ1N0Code*/
				/*}#1I8JCAQ1N0Code*/
			},"select":{
				/*#{1I8JCBPMG0PreCode*/
				$(){
					isSelect=true;
					if(isFocused){
						return false;
					}
				},
				/*}#1I8JCBPMG0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				},
				/*#{1I8JCBPMG0Code*/
				$(){
					isSelect=true;
				},
				/*}#1I8JCBPMG0Code*/
			},"!select":{
				/*#{1I8JEIOMF0PreCode*/
				$(){
					isSelect=false;
					if(isFocused){
						return false;
					}
				},
				/*}#1I8JEIOMF0PreCode*/
				/*BoxBG*/"#1H1O6BJ290":{
					"background":options.btnBG
				}
			},"empty":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"enable":true,"alpha":0.3
				}
			},"!empty":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"enable":true,"alpha":1
				}
			},"expand":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"rotate":90
				},
				/*#{1I8JDO4IK0Code*/
				$(){
					state.isExpand=true;
				}
				/*}#1I8JDO4IK0Code*/
			},"collapse":{
				/*BtnExpand*/"#1I8JDJIIC0":{
					"rotate":0
				},
				/*#{1I8JDOBVF0Code*/
				$(){
					state.isExpand=false;
				}
				/*}#1I8JDOBVF0Code*/
			},"subFocus":{
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["subFocus"]
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnCheck=self.BtnCheck;txtName=self.TxtName;
			/*#{1H1O4B7OK1Create*/
			this.preferW=this.webObj.scrollWidth;
			if(entryObj.check){
				this.preferW+=25;
			}
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.expand=async function(){
		/*#{1I8NKV6H60Start*/
		let owner;
		owner=this.parent;
		if(owner.expand){
			owner.expand();
		}else{
			self.showFace("expand");
		}
		/*}#1I8NKV6H60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.collapse=async function(){
		/*#{1I8NKVKRO0Start*/
		let owner;
		owner=this.parent;
		if(owner.collapse){
			owner.collapse();
		}else{
			self.showFace("collapse");
		}
		/*}#1I8NKVKRO0Start*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

BtnGroup.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("群组按钮"):("Group Button")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:24,
	catalog:"Buttons",
	args: {
		"entryObj": {
			"name": "entryObj", "showName": "entryObj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"text":"Object"}, "initValText": "#{\"text\":\"Object\"}"
		}, 
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 14
					}, 
					"height": {
						"name": "height", "showName": "height", "type": "int", "key": true, "fixed": true, "initVal": 24
					}, 
					"iconSize": {
						"name": "iconSize", "showName": "iconSize", "type": "number", "key": true, "fixed": true, "initVal": 20
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"checkBox": {
						"name": "checkBox", "showName": "checkBox", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"indentSize": {
						"name": "indentSize", "showName": "indentSize", "type": "int", "key": true, "fixed": true, "initVal": 15
					}, 
					"btnBG": {
						"name": "btnBG", "showName": "btnBG", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [243,243,242,1], "initValText": "#cfgColor[\"menuBG\"]"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"Object"},
		isExpand:{name:"isExpand",type:"bool",initVal:false}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:["up","over","down","gray","focus","blur","select","!select","empty","!empty","expand","collapse","subFocus"],
	subContainers:{
	},
	/*#{1I9Q06C5B0ExGearInfo*/
	/*}#1I9Q06C5B0ExGearInfo*/
};
/*#{1I9Q06C5B0EndDoc*/
/*}#1I9Q06C5B0EndDoc*/

export default BtnGroup;
export{BtnGroup};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1I9Q06C5B0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1O4B7OL0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1O4B7OL1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5VFJH9A0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1O4B7OL2",
//			"attrs": {
//				"entryObj": {
//					"type": "auto",
//					"valText": "#{\"text\":\"Object\"}"
//				},
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I8JCGLTP0",
//					"attrs": {
//						"fontSize": {
//							"type": "int",
//							"valText": "14"
//						},
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"iconSize": {
//							"type": "number",
//							"valText": "20"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"checkBox": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						},
//						"btnBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"menuBG\"]"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1O4B7OL3",
//			"attrs": {
//				"isFocused": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"isSelect": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1O4B7OL4",
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#options.fontSize||txtSize.smallPlus",
//					"editType": "fontSize"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#entryObj.icon"
//				},
//				"isExpand": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"text": {
//					"type": "string",
//					"valText": "#entryObj.text||entryObj.name"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NKV6H60",
//					"attrs": {
//						"id": "expand",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "140",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NKVVL40",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NKVVL41",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NKVVL42",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NKVKRO0",
//					"attrs": {
//						"id": "collapse",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "220",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NKVVL43",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NKVVL44",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NKVVL45",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Group Button",
//			"localize": {
//				"EN": "Group Button",
//				"CN": "群组按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "24",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1O4B7OL5",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SN0K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SMEQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ3",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1O6TNKJ5",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCALLE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP1",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCAQ1N0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP2",
//							"attrs": {}
//						}
//					}
//				},
//				"select": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCBPMG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP3",
//							"attrs": {}
//						}
//					}
//				},
//				"!select": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JEIOMF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JEJC910",
//							"attrs": {}
//						}
//					}
//				},
//				"empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCC7TB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP4",
//							"attrs": {}
//						}
//					}
//				},
//				"!empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JCCITS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JCGLTP5",
//							"attrs": {}
//						}
//					}
//				},
//				"expand": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JDO4IK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JDP1NQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"collapse": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8JDOBVF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8JDP1NR0",
//							"attrs": {}
//						}
//					}
//				},
//				"subFocus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I94OT6950",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I94OT9BM0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAHAJUP0",
//			"attrs": {
//				"CheckBox": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCTKRA0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:false,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"Folder": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCTKRA1",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:1,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"FileWithSize": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCV44M0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				},
//				"FileWithoutSize": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I8NCVU550",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1O4B7OL2",
//							"attrs": {
//								"viewBox": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"treeNode": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",name:\"disk.json\",path:\"/tabos/disk.json\",dir:0,size:1023023}"
//								},
//								"indent": {
//									"type": "int",
//									"valText": "1"
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8JCGLTP0",
//									"attrs": {
//										"fontSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"allowDrop": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"allowDrag": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"height": {
//											"type": "int",
//											"valText": "24"
//										},
//										"iconSize": {
//											"type": "number",
//											"valText": "20"
//										},
//										"color": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"checkBox": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"expandBtn": {
//											"type": "bool",
//											"valText": "true"
//										},
//										"indentSize": {
//											"type": "int",
//											"valText": "15"
//										},
//										"fileSize": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"fileMenu": {
//											"type": "bool",
//											"valText": "true"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1O4B7OL4",
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#options.fontSize||txtSize.smallPlus",
//									"editType": "fontSize"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+(obj.dir?\"/folder.svg\":\"/file.svg\")"
//								},
//								"fileSize": {
//									"type": "int",
//									"valText": "#obj.size"
//								},
//								"path": {
//									"type": "string",
//									"valText": "#obj.path"
//								},
//								"pathEntry": {
//									"type": "string",
//									"valText": "#obj"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1O4B7OK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1O4B7OL6",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "#options.height||24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "#[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "#entryObj.enable===false?false:true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O6BJ290",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6PGCJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#options.btnBG",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O6PGCJ1",
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ7",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O6TNKJ9",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#options.btnBG"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#options.btnBG"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"gntFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#options.btnBG"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG21",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#options.btnBG"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"subFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG01",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG02",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG03",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O6PGCJ2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O6PGCJ3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1LD0QTJ0",
//							"jaxId": "1HAAHR1A50",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HAAHR1A51",
//									"attrs": {
//										"size": "#(options.height||24)-6",
//										"text": "",
//										"checked": "#entryObj.checked",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HAAHR1A52",
//									"attrs": {
//										"type": "#null#>BtnCheck((options.height||24)-6,\"\",entryObj.checked,false)",
//										"id": "BtnCheck",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,2,0,0]",
//										"attach": "#!!options.checkBox"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HAAHR1A53",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JD740T6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JD740T7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JESTFF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JESTFF1",
//													"attrs": {
//														"color": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,1.00]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LF1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG04",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG05",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG06",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG07",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG08",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG09",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG010",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG011",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q3BPJ50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q3BPJ51",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAAHR1A54",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAAHR1A55",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HAAHR1A56",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1I8JDJIIC0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I8JDNVDK0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "#options.fontSize",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/zhankai.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1I8JDNVDK1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",options.fontSize,0,appCfg.sharedAssets+\"/zhankai.svg\",null)",
//										"id": "BtnExpand",
//										"position": "relative",
//										"x": "#options.fontSize*0.5",
//										"y": "#options.fontSize*0.5",
//										"display": "On",
//										"face": "",
//										"attach": "true",
//										"anchorH": "Center",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8JDNVDK2",
//									"attrs": {
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO5",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO7",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q27",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q29",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.3",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LF3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSD6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSD7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG012",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG013",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG014",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG015",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q3BPJ52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q3BPJ53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8JDNVDK3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I8NL0B6J0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I8NL1PQH4",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I8JDNVDK4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I8JDNVDK5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O5PAKH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "#options.iconSize||((options.height||24)-4)",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "#!!entryObj.icon",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,2,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#options.color||cfgColor.fontBody",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#entryObj.icon",
//										"maskImage": "${state.icon},state",
//										"aspect": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG1",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LG1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG016",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG017",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG018",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG019",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG020",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG021",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG022",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG023",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q3BPJ54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q3BPJ55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1O5T0HD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O657LG4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#options.color||cfgColor.fontBody",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1O657LG5",
//									"attrs": {
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1O7E6EU11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1I8JDO4IK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JDT6HO10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JDT6HO11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDO4IK0",
//											"faceTagName": "expand"
//										},
//										"1I8JCBPMG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JEF06Q40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JEF06Q41",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCBPMG0",
//											"faceTagName": "select"
//										},
//										"1I8JEIOMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8JF1QG28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8JF1QG29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JEIOMF0",
//											"faceTagName": "!select"
//										},
//										"1I8JCAQ1N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8NCO6LG2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8NCO6LG3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCAQ1N0",
//											"faceTagName": "blur"
//										},
//										"1I8JCALLE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCALLE0",
//											"faceTagName": "focus"
//										},
//										"1I8JDOBVF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I94PHCSE6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I94PHCSE7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JDOBVF0",
//											"faceTagName": "collapse"
//										},
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG024",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG025",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG026",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG027",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										},
//										"1I8JCC7TB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCC7TB0",
//											"faceTagName": "empty"
//										},
//										"1I8JCCITS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q0FAG12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q0FAG13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8JCCITS0",
//											"faceTagName": "!empty"
//										},
//										"1I94OT6950": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q3BPJ56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q3BPJ57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I94OT6950",
//											"faceTagName": "subFocus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1O657LG6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1O657LG7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1O4B7OL7",
//					"attrs": {
//						"1H1O6SMEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O6TNKJ16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O6TNKJ17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SMEQ0",
//							"faceTagName": "over"
//						},
//						"1H1O6SN0K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SN0K0",
//							"faceTagName": "up"
//						},
//						"1H1O6TNKJ2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU19",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ2",
//							"faceTagName": "down"
//						},
//						"1H1O6TNKJ4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1O7E6EU21",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ4",
//							"faceTagName": "gray"
//						},
//						"1I8JDO4IK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JDT6HO12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JDT6HO13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JDO4IK0",
//							"faceTagName": "expand"
//						},
//						"1I8JCBPMG0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JEF06Q46",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JEF06Q47",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCBPMG0",
//							"faceTagName": "select"
//						},
//						"1I8JEIOMF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8JF1QG30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JF1QG31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JEIOMF0",
//							"faceTagName": "!select"
//						},
//						"1I8JCAQ1N0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8NCO6LG6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8NCO6LG7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCAQ1N0",
//							"faceTagName": "blur"
//						},
//						"1I8JCALLE0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I94PHCSE12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I94PHCSE13",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCALLE0",
//							"faceTagName": "focus"
//						},
//						"1I8JDOBVF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I94PHCSE14",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I94PHCSE15",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JDOBVF0",
//							"faceTagName": "collapse"
//						},
//						"1I8JCC7TB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9Q0FAG14",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9Q0FAG15",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCC7TB0",
//							"faceTagName": "empty"
//						},
//						"1I8JCCITS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9Q0FAG16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9Q0FAG17",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8JCCITS0",
//							"faceTagName": "!empty"
//						},
//						"1I94OT6950": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9Q3BPJ58",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9Q3BPJ59",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I94OT6950",
//							"faceTagName": "subFocus"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1O4B7OL8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1O4B7OL9",
//					"attrs": {
//						"entry": {
//							"type": "auto",
//							"valText": "#entryObj"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O4B7OL10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "text"
//				},
//				{
//					"type": "string",
//					"valText": "isExpand"
//				}
//			]
//		}
//	}
//}