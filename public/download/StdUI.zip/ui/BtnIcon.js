//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1KJQ5RK0StartDoc*/
/*}#1H1KJQ5RK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnIcon=function(style,w,h,icon,colorBG){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let color=Array.isArray(style)?(style):(cfgColor[style]);
	
	/*#{1H1KJQ5RK1LocalVals*/
	const app=VFACT.app;
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":0,"icon":icon,"color":color,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":w,"h":h||w,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":colorBG||[0,0,0,0],
				"border":$P(()=>(state.border||0),state),"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KKD55C0",
				"type":"box","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"uiEvent":-1,"margin":[0,3,0,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.color),state),"attached":icon,"maskImage":$P(()=>(state.icon),state),
			}
		],
		get $$border(){return state["border"]},
		set $$border(v){
			state["border"]=v;
			/*#{1H1KJQ5RK1Setborder*/
			/*}#1H1KJQ5RK1Setborder*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KJQ5RK1Setcorner*/
			/*}#1H1KJQ5RK1Setcorner*/
		},
		get $$icon(){return state["icon"]},
		set $$icon(v){
			state["icon"]=v;
			/*#{1H1KJQ5RK1Seticon*/
			/*}#1H1KJQ5RK1Seticon*/
		},
		get $$color(){return state["color"]},
		set $$color(v){
			state["color"]=v;
			/*#{1H1KJQ5RK1Setcolor*/
			/*}#1H1KJQ5RK1Setcolor*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG||[0,0,0,0],"y":0,"alpha":1
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%","alpha":1
				}
			},"over":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"down":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"w":">calc(100% - 2px)","h":">calc(100% - 2px)"
				}
			},"gray":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"alpha":0.25
				},
				"#1H1KKD55C0":{
					"w":"100%","h":"100%","alpha":0.25
				}
			},"focus":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"border":3,"borderColor":cfgColor["primary"],"w":">calc(100% + 2px)","h":">calc(100% + 2px)","x":-1,"y":-1
				}
			},"blur":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"border":$P(()=>(state.border||0),state),"borderColor":color,"w":"100%","h":"100%","x":0,"y":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		OnButtonDown:function(){
			if(self.tip && app.showTip){
				app.abortTip(self);
			}		
		},
		OnMouseInOut:function(isIn){
			if(self.tip && app.showTip){
				if(isIn){
					let x,y,ax,ay;
					switch(self.tipDir){
						case 0:
						case "up":
						case "u":
							x=self.w/2;y=-5;ax=1;ay=2;
							break;
						case 1:
						case "right":
						case "r":
							x=self.w+5;y=self.h/2;ax=0;ay=1;
							break;
						case 2:
						case "bottom":
						case "b":
						default:
							x=self.w/2;y=self.h+5;ax=1;ay=0;
							break;
						case 3:
						case "left":
						case "l":
							x=-5;y=self.h/2;ax=2;ay=1;
							break;
					}
					app.showTip(self,self.tip,x,y,ax,ay);
				}else{
					app.abortTip(self);
				}
			}
		}
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	cssVO.constructor=BtnIcon;
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

//----------------------------------------------------------------------------
BtnIcon.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1KJQ5RK1PreAISpot*/
	/*}#1H1KJQ5RK1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("图标按钮"):("Icon Button"));
	exposeVO.typeDescription="Icon button";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1KJQ5RK1PostAISpot*/
	/*}#1H1KJQ5RK1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnIcon.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("图标按钮"):("Icon Button")),icon:"btn_icon.svg",previewImg:false,
	fixPose:false,initW:30,initH:30,
	"desc":"Icon button",
	catalog:"Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "auto", "key": true, "fixed": true, "initVal": "front"
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 30
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 0
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg", "initValText": "#appCfg.sharedAssets+\"/lab.svg\""
		}, 
		"colorBG": {
			"name": "colorBG", "showName": "colorBG", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
		border:{name:"border",type:"int",initVal:0},
		corner:{name:"corner",type:"int",initVal:3},
		icon:{name:"icon",type:"string",initVal:"/~/-tabos/shared/assets/lab.svg"},
		color:{name:"color",type:"colorRGBA",initVal:[0,0,0,1]}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","padding","enable","drag","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1H1KJQ5RK0ExGearInfo*/
	/*}#1H1KJQ5RK0ExGearInfo*/
};
/*#{1H1KJQ5RK0EndDoc*/
/*}#1H1KJQ5RK0EndDoc*/

export default BtnIcon;
export{BtnIcon};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1KJQ5RK0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1KJQ5RK2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1KJQ5RK3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H65TK1PU0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1KJQ5RK4",
//			"attrs": {
//				"style": {
//					"type": "auto",
//					"valText": "\"front\""
//				},
//				"w": {
//					"type": "int",
//					"valText": "30"
//				},
//				"h": {
//					"type": "int",
//					"valText": "0"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/lab.svg\""
//				},
//				"colorBG": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1KJQ5RK5",
//			"attrs": {
//				"color": {
//					"type": "auto",
//					"valText": "#Array.isArray(style)?(style):(cfgColor[style])"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1KJQ5RK6",
//			"attrs": {
//				"corner": {
//					"type": "int",
//					"valText": "3"
//				},
//				"border": {
//					"type": "int",
//					"valText": "0"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#icon"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#color"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Icon Button",
//			"localize": {
//				"EN": "Icon Button",
//				"CN": "图标按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_icon.svg",
//		"gearW": "30",
//		"gearH": "30",
//		"gearCatalog": "Buttons",
//		"description": "Icon button",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1KJQ5RK7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1Q1R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1SU60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1M7O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE2",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK26UE3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KK26UE4",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IA4TRQRQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IA4TVS8A0",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IA4TS1G20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IA4TVS8A1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAT16DTK0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "Icon button",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1KJQ5RK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1KJQ5RK8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "#w",
//						"h": "#h||w",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KK7EMK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KK7EMK1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#colorBG||[0,0,0,0]",
//										"border": "${state.border||0},state",
//										"borderStyle": "Solid",
//										"borderColor": "#color",
//										"corner": "${state.corner},state",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KK7EML0",
//									"attrs": {
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML2",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG||[0,0,0,0]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML4",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25])"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML6",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15])"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KK7EML8",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.25",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										},
//										"1IA4TRQRQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4TVS8A2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4TVS8A3",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "3",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"primary\"]"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%+2"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%+2"
//														},
//														"x": {
//															"type": "length",
//															"valText": "-1"
//														},
//														"y": {
//															"type": "length",
//															"valText": "-1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA4TRQRQ0",
//											"faceTagName": "focus"
//										},
//										"1IA4TS1G20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4TVS8A4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4TVS8A5",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "${state.border||0},state",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA4TS1G20",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KK7EMM0",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KK7EMM1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KKD55C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KKD55C1",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "50%",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "${state.color},state",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#icon",
//										"maskImage": "${state.icon},state"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KKD55D0",
//									"attrs": {
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KKD55D2",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KKD55D4",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%-2"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%-2"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KKD55D6",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KKD55D8",
//													"attrs": {
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.25",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										},
//										"1IA4TRQRQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4TVS8A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4TVS8A7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IA4TRQRQ0",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KKD55D9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KKD55D10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1KJQ5RK9",
//					"attrs": {
//						"1H1KK1SU60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HO1QNH2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2HO1QNH3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1SU60",
//							"faceTagName": "over"
//						},
//						"1H1KK1M7O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HQBDT20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2HQBDT21",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1M7O0",
//							"faceTagName": "down"
//						},
//						"1IA4TRQRQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA4TVS8A10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA4TVS8A11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IA4TRQRQ0",
//							"faceTagName": "focus"
//						},
//						"1H1KK1Q1R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA529FU30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA529FU31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1Q1R0",
//							"faceTagName": "up"
//						},
//						"1H1KK26UE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA529FU32",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA529FU33",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK26UE3",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1KJQ5RK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1KJQ5RK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1KJQ5RK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "true",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "border"
//				},
//				{
//					"type": "string",
//					"valText": "corner"
//				},
//				{
//					"type": "string",
//					"valText": "icon"
//				},
//				{
//					"type": "string",
//					"valText": "color"
//				}
//			]
//		}
//	}
//}