//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1KJQ5RK0StartDoc*/
/*}#1H1KJQ5RK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnIcon=function(style,w,h,icon,colorBG){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let color=Array.isArray(style)?(style):(cfgColor[style]);
	
	/*#{1H1KJQ5RK1LocalVals*/
	const app=VFACT.app;
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":0,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":w,"h":h||w,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":colorBG||[0,0,0,0],
				"border":$P(()=>(state.border||0),state),"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KKD55C0",
				"type":"box","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"uiEvent":-1,"margin":[0,3,0,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":color,"attached":icon,"maskImage":icon,
			}
		],
		get $$border(){return state["border"]},
		set $$border(v){
			state["border"]=v;
			/*#{1H1KJQ5RK1Setborder*/
			/*}#1H1KJQ5RK1Setborder*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KJQ5RK1Setcorner*/
			/*}#1H1KJQ5RK1Setcorner*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG||[0,0,0,0],"y":0,"borderColor":cfgColor[style]
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"over":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"down":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"w":">calc(100% - 2px)","h":">calc(100% - 2px)"
				}
			},"gray":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H1KKD55C0":{
					"background":[color[0],color[1],color[2],color[3]*0.25],"w":"100%","h":"100%"
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		OnButtonDown:function(){
			if(self.tip && app.showTip){
				app.abortTip(self);
			}		
		},
		OnMouseInOut:function(isIn){
			if(self.tip && app.showTip){
				if(isIn){
					let x,y,ax,ay;
					switch(self.tipDir){
						case 0:
						case "up":
						case "u":
							x=self.w/2;y=-5;ax=1;ay=2;
							break;
						case 1:
						case "right":
						case "r":
							x=self.w+5;y=self.h/2;ax=0;ay=1;
							break;
						case 2:
						case "bottom":
						case "b":
						default:
							x=self.w/2;y=self.h+5;ax=1;ay=0;
							break;
						case 3:
						case "left":
						case "l":
							x=-5;y=self.h/2;ax=2;ay=1;
							break;
					}
					app.showTip(self,self.tip,x,y,ax,ay);
				}else{
					app.abortTip(self);
				}
			}
		}
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnIcon.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("图标按钮"):("Icon Button")),icon:"btn_icon.svg",previewImg:false,
	fixPose:false,initW:30,initH:30,
	"desc":"Icon button",
	catalog:"Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "auto", "key": true, "fixed": true, "initVal": "front"
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 30
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 0
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg"
		}, 
		"colorBG": {
			"name": "colorBG", "showName": "colorBG", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
		border:{name:"border",type:"int",initVal:0},
		corner:{name:"corner",type:"int",initVal:3}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","padding","enable","drag","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1KJQ5RK0ExGearInfo*/
	/*}#1H1KJQ5RK0ExGearInfo*/
};
export default BtnIcon;
export{BtnIcon};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1KJQ5RK0",
//	"editVersion": 217,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1KJQ5RK2",
//			"editVersion": 16,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1KJQ5RK3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H65TK1PU0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1KJQ5RK4",
//			"editVersion": 158,
//			"attrs": {
//				"style": {
//					"type": "auto",
//					"valText": "\"front\""
//				},
//				"w": {
//					"type": "int",
//					"valText": "30"
//				},
//				"h": {
//					"type": "int",
//					"valText": "0"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/lab.svg\""
//				},
//				"colorBG": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1KJQ5RK5",
//			"editVersion": 36,
//			"attrs": {
//				"color": {
//					"type": "auto",
//					"valText": "#Array.isArray(style)?(style):(cfgColor[style])"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1KJQ5RK6",
//			"editVersion": 56,
//			"attrs": {
//				"corner": {
//					"type": "int",
//					"valText": "3"
//				},
//				"border": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Icon Button",
//			"localize": {
//				"EN": "Icon Button",
//				"CN": "图标按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_icon.svg",
//		"gearW": "30",
//		"gearH": "30",
//		"gearCatalog": "Buttons",
//		"description": "Icon button",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1KJQ5RK7",
//			"editVersion": 14,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1Q1R0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1KK26UE0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1SU60",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1KK26UE1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK1M7O0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1KK26UE2",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KK26UE3",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1KK26UE4",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAT16DTK0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1KJQ5RK1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1KJQ5RK8",
//					"editVersion": 76,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "#w",
//						"h": "#h||w",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KK7EMK0",
//							"editVersion": 102,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1KK7EMK1",
//									"editVersion": 186,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#colorBG||[0,0,0,0]",
//										"border": "${state.border||0},state",
//										"borderStyle": "Solid",
//										"borderColor": "#color",
//										"corner": "${state.corner},state",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1KK7EML0",
//									"editVersion": 16,
//									"attrs": {
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KK7EML2",
//													"editVersion": 18,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG||[0,0,0,0]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[style]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML3",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KK7EML4",
//													"editVersion": 36,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25])"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML5",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KK7EML6",
//													"editVersion": 54,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15])"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KK7EML7",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KK7EML8",
//													"editVersion": 36,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):[0,0,0,0]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemGray\"]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1KK7EMM0",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1KK7EMM1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KKD55C0",
//							"editVersion": 67,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1KKD55C1",
//									"editVersion": 194,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "50%",
//										"y": "50%",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1KKD55D0",
//									"editVersion": 36,
//									"attrs": {
//										"1H1KK1SU60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KKD55D2",
//													"editVersion": 22,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1SU60",
//											"faceTagName": "over"
//										},
//										"1H1KK1M7O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D3",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KKD55D4",
//													"editVersion": 72,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%-2"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%-2"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1M7O0",
//											"faceTagName": "down"
//										},
//										"1H1KK1Q1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D5",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KKD55D6",
//													"editVersion": 22,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#color"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK1Q1R0",
//											"faceTagName": "up"
//										},
//										"1H1KK26UE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KKD55D7",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1KKD55D8",
//													"editVersion": 18,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[color[0],color[1],color[2],color[3]*0.25]"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KK26UE3",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1KKD55D9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1KKD55D10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1KJQ5RK9",
//					"editVersion": 60,
//					"attrs": {
//						"1H1KK1Q1R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HO1QNH0",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2HO1QNH1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1Q1R0",
//							"faceTagName": "up"
//						},
//						"1H1KK1SU60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HO1QNH2",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2HO1QNH3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1SU60",
//							"faceTagName": "over"
//						},
//						"1H1KK1M7O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HQBDT20",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2HQBDT21",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK1M7O0",
//							"faceTagName": "down"
//						},
//						"1H1KK26UE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HQBDT22",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2HQBDT23",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KK26UE3",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1KJQ5RK10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1KJQ5RK11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1KJQ5RK12",
//			"editVersion": 108,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "true",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "border"
//				},
//				{
//					"type": "string",
//					"valText": "corner"
//				}
//			]
//		}
//	}
//}