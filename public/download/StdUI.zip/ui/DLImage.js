//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HQMMJ09H0StartDoc*/
/*}#1HQMMJ09H0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLImage=function(box,template,dataObj,property,opts,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxIcon,txtLabel,txtPlaceHolder,imgImage;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let value=dataObj[property];
	let pptTemplate=template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value));
	let edit=(!pptTemplate.readOnly) && opts.edit && (box && box.edit);
	let icon=pptTemplate.icon;
	let labelLine=!!opts.labelLine;
	let choices=pptTemplate.choices||["No","Yes"];
	let description=edit?pptTemplate.description:null;
	let valueGap=choices?3:(opts.labelLine?6:3);
	let menuGap=opts.labelLine?6:3;
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	let imgW=0;
	let imgH=0;
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":opts?(opts.lineHeight||25):25,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1F1DNF0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":opts?(opts.lineHeight-3):22,"h":opts?(opts.lineHeight-3):22,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-y",
				"itemsWrap":1,
				children:[
					{
						"hash":"1HQ1GMNN90",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":opts.labelColor,
						"text":title||(pptTemplate.label?pptTemplate.label:(property+":")),"fontSize":opts?(opts.labelSize||12):14,"fontWeight":(opts?(opts.labelBold||false):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HQ1GNGQ60",
						"type":"text","id":"TxtPlaceHolder","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","margin":[2,0,0,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":opts.valueColor,"text":pptTemplate.placeHolder||"Image","fontSize":opts?(opts.valueSize||16):16,"fontWeight":(opts?(!!opts.valueBold):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,"wrap":true,"attached":!edit,
					},
					{
						"hash":"1HQMMK6QK0",
						"type":"image","id":"ImgImage","position":"relative","x":"50%","y":0,"w":50,"h":50,"anchorX":1,"cursor":"pointer","margin":[3,0,0,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","fitSize":true,
						children:[
							{
								"hash":"1HQN8DTK60",
								"type":"image","x":"50%","y":"50%","w":50,"h":50,"anchorX":1,"anchorY":1,"uiEvent":-1,"alpha":0.2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"image":edit?(appCfg.sharedAssets+"/folder.svg"):(appCfg.sharedAssets+"/hudimg.svg"),"fitSize":true,
							}
						],
						"OnLoad":function(){
							/*#{1HQMMV3NR0FunctionBody*/
							let maxW,maxH,scale,sW,sH;
							imgW=this.imageW;
							imgH=this.imageH;
							maxW=box.w*0.9;
							maxH=box.w*2;
							sW=1;sH=1;
							if(imgW>maxW){
								sW=maxW/imgW;
							}
							if(imgH>maxH){
								sH=maxH/imgH;
							}
							scale=sW<sH?sW:sH;
							this.w=imgW*scale;
							this.h=imgH*scale;
							self.showFace("ready");
							/*}#1HQMMV3NR0FunctionBody*/
						},
						"OnClick":function(event){
							/*#{1HQN8PNIE0FunctionBody*/
							if(!edit){
								return;
							}
							//TODO: Open dialog
							/*}#1HQN8PNIE0FunctionBody*/
						},
						"OnError":function(){
							/*#{1HQNC22V50FunctionBody*/
							self.showFace("loadError");
							/*}#1HQNC22V50FunctionBody*/
						},
					},
					{
						"hash":"1HQ1JKTFQ0",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":description,"fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignH":1,"wrap":true,"attached":!!description,
					}
				],
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get $$property(){
			return property;
		},
		set $$property(p){
			return property=p;
		},
		template:pptTemplate,
		get $$value(){
			return value;
		},
		set $$value(val){
			return self.commitEdit(val);
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
			"error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":cfgColor["error"]
				}
			},"!error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":opts.labelColor
				}
			},"load":{
				"#1HQN8DTK60":{
					"display":1
				}
			},"ready":{
				"#1HQN8DTK60":{
					"display":0
				}
			},"loadError":{
			}
		},
		OnCreate:function(){
			self=this;
			boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtPlaceHolder=self.TxtPlaceHolder;imgImage=self.ImgImage;
			/*#{1HQ1EDCKJ1Create*/
			self.postCheck();
			self.showFace("load");
			if(value){
				imgImage.image=value;
			}
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		if(pptTemplate.checkValue){
			if(!pptTemplate.checkValue(val)){
				val=value;
			}
		}
		if(val!==value){
			value=val;
			self.updateValue();
		}
		return value;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		value=dataObj[property];
		self.updateValue();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		self.showFace("load");
		imgImage.image=value;
		self.postCheck();
	};
	
	//------------------------------------------------------------------------
	cssVO.postCheck=function(){
		if(pptTemplate.required){
			if(!value){
				self.showFace("error");
			}else{
				self.showFace("!error");
			}
		}
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/


/*#{1HQMMJ09H0EndDoc*/
/*}#1HQMMJ09H0EndDoc*/

export default DLImage;
export{DLImage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQMMJ09H0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "#{properties:{size:{type:\"int\",label:\"Size\",description:\"This is size\"}}}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "#{size:50}"
//				},
//				"property": {
//					"type": "string",
//					"valText": "size"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 1, edit:1}"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"value": {
//					"type": "auto",
//					"valText": "#dataObj[property]"
//				},
//				"pptTemplate": {
//					"type": "auto",
//					"valText": "#template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value))"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "#(!pptTemplate.readOnly) && opts.edit && (box && box.edit)"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#null//appCfg.sharedAssets+\"/inc.svg\"#>pptTemplate.icon"
//				},
//				"labelLine": {
//					"type": "bool",
//					"valText": "#!!opts.labelLine"
//				},
//				"choices": {
//					"type": "auto",
//					"valText": "#pptTemplate.choices||[\"No\",\"Yes\"]"
//				},
//				"description": {
//					"type": "string",
//					"valText": "#edit?pptTemplate.description:null"
//				},
//				"valueGap": {
//					"type": "int",
//					"valText": "#choices?3:(opts.labelLine?6:3)"
//				},
//				"menuGap": {
//					"type": "int",
//					"valText": "#opts.labelLine?6:3"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VN1I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND0",
//							"attrs": {}
//						}
//					}
//				},
//				"!error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VNIQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND1",
//							"attrs": {}
//						}
//					}
//				},
//				"load": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQN8I0B30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQN8I0B31",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQN8I0B32",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQN8I0B33",
//							"attrs": {}
//						}
//					}
//				},
//				"loadError": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQN8I0B34",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQN8I0B35",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "#opts?(opts.lineHeight||25):25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ1F1DNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1F383P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#opts?(opts.lineHeight-3):22",
//										"h": "#opts?(opts.lineHeight-3):22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1F383P1",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HJ1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										},
//										"1HQN8I0B30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQNC3K7A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQNC3K7A1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQN8I0B30",
//											"faceTagName": "load"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1F383P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1F383P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GMNN90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GMNN91",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.labelColor",
//														"text": "#title||(pptTemplate.label?pptTemplate.label:(property+\":\"))",
//														"font": "",
//														"fontSize": "#opts?(opts.labelSize||12):14",
//														"bold": "#opts?(opts.labelBold||false):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GMNNA0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND5",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"error\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														},
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#opts.labelColor"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														},
//														"1HQN8I0B30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQNC3K7A2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQNC3K7A3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQN8I0B30",
//															"faceTagName": "load"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GMNNA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GMNNA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GNGQ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GNGQ61",
//													"attrs": {
//														"type": "text",
//														"id": "TxtPlaceHolder",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "#[2,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.valueColor",
//														"text": "#pptTemplate.placeHolder||\"Image\"",
//														"font": "",
//														"fontSize": "#opts?(opts.valueSize||16):16",
//														"bold": "#opts?(!!opts.valueBold):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!edit"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GNGQ62",
//													"attrs": {
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQMCM8HJ2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQMCM8HJ3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														},
//														"1HQN8I0B30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQNC3K7A4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQNC3K7A5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQN8I0B30",
//															"faceTagName": "load"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GNGQ63",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GNGQ64",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HQMMK6QK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMML6CG0",
//													"attrs": {
//														"type": "image",
//														"id": "ImgImage",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "50",
//														"h": "50",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1HQN8DTK60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQN8G3SC0",
//																	"attrs": {
//																		"type": "image",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "50%",
//																		"w": "50",
//																		"h": "50",
//																		"anchorH": "Center",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "0.20",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "#edit?(appCfg.sharedAssets+\"/folder.svg\"):(appCfg.sharedAssets+\"/hudimg.svg\")",
//																		"autoSize": "false",
//																		"fitSize": "Fit",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HQN8G3SC1",
//																	"attrs": {
//																		"1HQN8I0B30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HQNC3K7B0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HQNC3K7B1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HQN8I0B30",
//																			"faceTagName": "load"
//																		},
//																		"1HQN8I0B32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HQNC3K7B2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HQNC3K7B3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HQN8I0B32",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HQN8G3SC2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HQN8G3SC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HQMML6CG1",
//													"attrs": {
//														"1HQN8I0B30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQNC3K7B4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQNC3K7B5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQN8I0B30",
//															"faceTagName": "load"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQMML6CG2",
//													"attrs": {
//														"OnLoad": {
//															"type": "fixedFunc",
//															"jaxId": "1HQMMV3NR0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HQMMV3NS0",
//																	"attrs": {}
//																},
//																"seg": ""
//															}
//														},
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HQN8PNIE0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HQN8PNIL0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														},
//														"OnError": {
//															"type": "fixedFunc",
//															"jaxId": "1HQNC22V50",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HQNC2JVK0",
//																	"attrs": {}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HQMML6CG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1JKTFQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1JO33U0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#description",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!description"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1JO33U1",
//													"attrs": {
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQMCM8HK2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQMCM8HK3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														},
//														"1HQN8I0B30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQNC3K7A6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQNC3K7A7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQN8I0B30",
//															"faceTagName": "load"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1JO33U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1JO33U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HK4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HK5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										},
//										"1HQN8I0B30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQNC3K7B6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQNC3K7B7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQN8I0B30",
//											"faceTagName": "load"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {
//						"1HQ20VNIQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQMCM8HK6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQMCM8HK7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQ20VNIQ0",
//							"faceTagName": "!error"
//						},
//						"1HQN8I0B30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQNC3K7B8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQNC3K7B9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQN8I0B30",
//							"faceTagName": "load"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}