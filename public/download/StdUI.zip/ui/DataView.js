//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HQ1M47LD0StartDoc*/
import {DLStd} from "./DLStd.js";
import {DLBool} from "./DLBool.js";
import {DLEditElement} from "./DLEditElement.js";
import {DlgMenu} from "./DlgMenu.js";
import {BtnText} from "./BtnText.js";

VFACT.regDataViewLine("Path","./DLPath.js");
VFACT.regDataViewLine("Note","./DLNote.js");
VFACT.regDataViewLine("Selects","./DLSelects.js");
VFACT.regDataViewLine("Code","./DLCode.js");
VFACT.regDataViewLine("Image","./DLImage.js");
/*}#1HQ1M47LD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DataView=function(box,template,dataObj,property,options,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxLabel,boxIcon,txtLabel,txtDesc,boxPpts;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=null;
	let label=null;
	let isArray=false;
	let edit=false;
	let fixedOrder=false;
	
	/*#{1HQ1M47LD1LocalVals*/
	let app=VFACT.app;
	let lineWaits=null;
	let lines=[];
	let pptLines={};
	let decoLines={};
	let traced=false;
	let collapsed=false;
	
	options=options||{};
	if(typeof(template)==="string"){
		template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
	}
	if(property || property===0){
		if(template){
			template=template.element||(template.properties?template.properties[property]:null);
			if(template && template.class){
				let clsType=typeof(template.class);
				if(clsType==="string"){
					template=VFACT.getEditUITemplate(template.class)||VFACT.getUITemplate(template.class);
				}else if(clsType==="object"){
					template=template.class;
				}
			}else if(template.type==="object"){
				template=null;
			}
		}
		if(dataObj){
			dataObj=dataObj[property];
		}
	}
	if(dataObj){
		if(!template){
			template=VFACT.genTemplateByObject(dataObj);
		}
	}else{
		if(template && template.newObject){
			dataObj=template.newObject();
		}
	}
	dataObj=dataObj||{};
	isArray=template?(template.type==="array"):false;
	icon=template?(template.icon):null;
	label=title||(template?(template.label||template.name):"Missing object");
	edit=(options.edit) && (template && !template.readOnly) && (!box || (box.edit));
	fixedOrder=!!(template && template.fixedOrder);
	/*}#1HQ1M47LD1LocalVals*/
	
	/*#{1HQ1M47LD1PreState*/
	/*}#1HQ1M47LD1PreState*/
	/*#{1HQ1M47LD1PostState*/
	/*}#1HQ1M47LD1PostState*/
	cssVO={
		"hash":"1HQ1M47LD1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":box?[0,0,10,0]:[0,0,options.lineGap||5,0],"padding":[0,0,0,0],"minW":"","minH":16,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HQ25L9CK0",
				"type":"box","id":"BoxLabel","position":"relative","x":0,"y":0,"w":"100%","h":box?(options.segHeight||30):(options.titleHeight||30),"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,"attached":!!title,
				children:[
					{
						"hash":"1I8ITRQIO0",
						"type":BtnIcon("front",15,0,appCfg.sharedAssets+"/zhankai.svg",null),"id":"BtnOpen","position":"relative","x":7,"y":7,"anchorX":1,"anchorY":1,"attached":(!!box)&&(!options.hideCollapse),
						"OnClick":function(event){
							self.openOrCollapse(this,event);
						},
					},
					{
						"hash":"1HQ25PQ6Q0",
						"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":box?(options?(options.segHeight-3):22):(options?(options.titleHeight-3):22),"h":box?(options?(options.segHeight-3):22):(options?(options.titleHeight-3):22),
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":box?(options?(options.segColor||cfgColor["fontBody"]):cfgColor["fontBody"]):(options?(options.titleColor||cfgColor["fontBody"]):cfgColor["fontBody"]),
						"border":1,"attached":!!icon,"maskImage":icon,
					},
					{
						"hash":"1HQ25MEIR0",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":box?(options?(options.segColor||cfgColor["fontBody"]):cfgColor["fontBody"]):(options?(options.titleColor||cfgColor["fontBody"]):cfgColor["fontBody"]),
						"text":title,"fontSize":box?(options?(options.segSize||14):14):(options?(options.titleSize||14):14),"fontWeight":(box?(options?(!!options.segBold):true):(options?(!!options.titleBold):true))?"bold":"normal",
						"fontStyle":"normal","textDecoration":"","attached":!!title,
					}
				],
			},
			{
				"hash":"1I85M02450",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1I85M382O0",
						"type":"box","id":"BoxBG","x":10,"y":0,"w":">calc(100% - 10px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
						"border":[0,0,0,1],"borderColor":cfgColor["fontBodyLit"],"attached":!!box,
					},
					{
						"hash":"1I85M28760",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","display":(template && template.desc),"margin":[0,0,5,0],"minW":"",
						"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":template?template.desc:"","fontSize":options?(options.descSize||12):12,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					},
					{
						"hash":"1I85M2IB20",
						"type":"hud","id":"BoxPpts","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":box?[5,5,5,15]:[5,5,5,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-y",
					},
					{
						"hash":"1I85M2MA00",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddElement","position":"relative","x":10,"y":0,"attached":(!!isArray)&&(edit)&&(!fixedOrder),
						"OnClick":function(event){
							/*#{1I85M2MA12FunctionBody*/
							self.newElement(true,null);
							/*}#1I85M2MA12FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HQ1M47LD1ExtraCSS*/
		/*}#1HQ1M47LD1ExtraCSS*/
		faces:{
			"open":{
				/*BtnOpen*/"#1I8ITRQIO0":{
					"rotate":90
				},
				"#1I85M02450":{
					"display":1
				},
				/*#{1I8ITFQH20Code*/
				$(){
					collapsed=false;
				}
				/*}#1I8ITFQH20Code*/
			},"close":{
				/*BtnOpen*/"#1I8ITRQIO0":{
					"rotate":0
				},
				"#1I85M02450":{
					"display":0
				},
				/*#{1I8ITFUDA0Code*/
				$(){
					collapsed=true;
				}
				/*}#1I8ITFUDA0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxLabel=self.BoxLabel;boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtDesc=self.TxtDesc;boxPpts=self.BoxPpts;
			/*#{1HQ1M47LD1Create*/
			self.orgOptions=options;
			self.ownerDataView=box;
			if(!box){
				self.topDataView=self;
			}else{
				self.topDataView=box.topDataView;
			}
			if(box){
				self.showElementMenu=box.showElementMenu;
			}
			if(box && options.autoCollapse){
				self.showFace("close");
			}else{
				self.showFace("open");
			}
			self.waitCreate=self.listPpts();
			/*}#1HQ1M47LD1Create*/
		},
		/*#{1HQ1M47LD1EndCSS*/
		template:template,
		get $$dataObj(){
			return dataObj;
		},
		get $$property(){
			return property;
		},
		get $$lines(){
			return lines;
		},
		get pptLines(){
			return pptLines;
		},
		set $$property(p){
			return property=p;
		},
		edit:edit,
		get $$readOnly(){
			return (!edit)||(template.readOnly);
		},
		OnFree(){
			if(traced){
				if(dataObj.onNotify){
					dataObj.offNotify("Changed",self.OnTrace);
				}else if(dataObj.on){
					dataObj.off("Changed",self.OnTrace);
				}
			}
		}
		/*}#1HQ1M47LD1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.openOrCollapse=async function(){
		/*#{1I8IVOP9I0Start*/
		if(collapsed){
			self.showFace("open");
		}else{
			self.showFace("close");
		}
		/*}#1I8IVOP9I0Start*/
	};
	/*#{1HQ1M47LD1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.setObject=async function(tmp,obj,opts){
		if(traced){
			if(dataObj.onNotify){
				dataObj.offNotify("Changed",self.OnTrace);
			}else if(dataObj.on){
				dataObj.off("Changed",self.OnTrace);
			}
			traced=false;
		}
		if(!tmp && !obj){
			boxPpts.clearChildren();
			return;
		};
		
		template=(tmp===null||tmp)?tmp:template;
		if(template && !obj &&template.newObject){
			obj=template.newObject();
		}
		dataObj=obj||dataObj;
		if(opts){
			options={...self.orgOptions,...opts};
		}
		isArray=template?(template.type==="array"):false;
		icon=template?template.icon:null;
		label=template?(template.label??template.name):"";
		edit=(options.edit) && (template && !template.readOnly) && (!box || (box.edit));
		this.edit=edit;
		fixedOrder=!!(template && template.fixedOrder);
		txtDesc.text=template?(template.desc||""):"";
		txtDesc.display=template?(!!template.desc):false;
		if(boxIcon){
			boxIcon.maskImage=icon;
		}
		if(boxLabel){
			boxLabel.display=!!label;
			txtLabel.text=label;
		}
		await self.listPpts();
	};
	
	//------------------------------------------------------------------------
	cssVO.genPptCSS=async function(ppts,pptName){
		let pptTemplate,pptType,uiMode,pptCSS,pptLine,title;
		let value;
		pptTemplate=ppts[pptName];
		if(!pptTemplate){
			return null;
		}
		pptType=pptTemplate.type;
		uiMode=pptTemplate.uiMode;
		title=null;
		if(!options.edit && !pptTemplate.required && dataObj[pptName]===undefined){
			return null;
		}
		if(uiMode){
			let path,mod;
			//Choose css by uiMode:
			if(typeof(uiMode)==="string"){
				if(uiMode.endsWith(".js")){
					path=uiMode;
				}else{
					path=VFACT.getDataViewLine(uiMode);
				}
				try{
					mod=await import(path);
					pptCSS=mod.default;
				}catch(err){
					console.eror(err);
				}
			}else if(path instanceof Function){
				pptCSS=path;
			}else{
				console.eror(`uiMode: "${uiMode}" not registered.`);
			}
		}else{
			//Choose css by pptType:
			switch(pptType){
				case "object":
				case "array":
					pptCSS=DataView;
					title=pptTemplate.label||pptTemplate.name;
					break;
				case "bool":
				case "boolean":
					pptCSS=DLBool;
					break;
				default:
					pptCSS=DLStd;
					break;
			}
		}
		if(pptCSS){
			return pptCSS(self,template,dataObj,pptName,options,title);
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	cssVO.fillPpt=async function(pBox,ppts,pptName){
		let pptCSS,pptLine;
		pptCSS=await self.genPptCSS(ppts,pptName);
		if(pptCSS){
			pptLine=pBox.appendNewChild({
				type:pptCSS,position:"relative",
			});
			pptLines[pptName]=pptLine;
			lines.push(pptLine);
			if(pptLine.waitCreate && lineWaits){
				lineWaits.push(pptLine.waitCreate);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.fillVBox=async function(vBox,pptList,ppts){
		let pptName,pptTemplate,pptType,uiMode,pptCSS,pptLine;
		let i,n;
		n=pptList.length;
		for(i=0;i<n;i++){
			pptName=pptList[i];
			if(Array.isArray(pptName)){
				let hList,hBox,totalGap,num,segW,i,subVBox,subPpt;
				hList=pptName;
				num=hList.length;
				if(num>0){
					totalGap=(num-1)*5;
					segW=(100/num);
					segW=segW.toFixed(2)+"%";
					hBox=vBox.appendNewChild({
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","contentLayout":"flex-x","itemsWrap":1,
					});
					for(i=0;i<num;i++){
						subVBox=hBox.appendNewChild({
							"type":"hud","position":"relative","x":0,"y":0,"w":segW,"padding":[0,5,0,0],"h":"","contentLayout":"flex-v",
						});
						subPpt=hList[i];
						if(subPpt){
							if(!Array.isArray(subPpt)){
								subPpt=[subPpt];
							}
							await self.fillVBox(subVBox,subPpt,ppts);
						}
					}
				}
			}else if(typeof(pptName)==="object"){
				let decoVO=pptName;
				switch(decoVO.type){
					case "line":
						pptLine=vBox.appendNewChild({
							"type":"box",id:decoVO.id||"","position":"relative","x":0,"y":0,"w":"100%","h":decoVO.h||decoVO.height||1,margin:[0,0,options.lineGap||5,0],
							background:decoVO.color||options.labelColor||cfgColor["fontBodySub"],border:0
						});
						if(decoVO.id){
							decoLines[decoVO.id]=pptLine;
						}
						break;
					case "seg":
					case "segment":
						if(decoVO.background){
							pptLine=vBox.appendNewChild({
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"",margin:[0,0,options.lineGap||5,0],
								background:decoVO.background,border:0,
								children:[
									{
										"type":"text",id:decoVO.id||"","position":"relative","x":0,"y":0,"w":"100%","h":decoVO.height||decoVO.h||options.segHeight||"","padding":[0,0,0,0],text:decoVO.text,
										"color":decoVO.color||options.descColor||cfgColor["fontBodySub"],"fontSize":decoVO.size||options.segSize||12,"fontWeight":options.segBold?"bold":"normal",alignH:decoVO.align||0,alignV:1
									}
								]
							});
						}else{
							pptLine=vBox.appendNewChild({
								"type":"text",id:decoVO.id||"","position":"relative","x":0,"y":0,"w":"100%","h":decoVO.height||decoVO.h||options.segHeight||"","padding":[0,0,0,0],margin:[0,0,options.lineGap||5,0],text:decoVO.text,
								"color":decoVO.color||options.descColor||cfgColor["fontBodySub"],"fontSize":decoVO.size||options.segSize||12,"fontWeight":options.segBold?"bold":"normal",alignH:decoVO.align||0,alignV:1
							});
						}
						if(decoVO.id){
							decoLines[decoVO.id]=pptLine;
						}
						break;
					case "btnPpt":
					case "actPpt":
					case "acttionPpt":{
						let def,pptCSS,pptName;
						def={mode:"action",icon:decoVO.icon||null,tip:decoVO.tip||null};
						pptName=decoVO.ppt||decoVO.property;
						pptCSS=await self.genPptCSS(ppts,pptName);
						if(pptCSS){
							pptLine=boxPpts.appendNewChild({
								type:DLEditElement(self,pptCSS,options,def),position:"relative",
							});
							pptLines[pptName]=pptLine;
							lines.push(pptLine);
							if(pptLine.waitCreate && lineWaits){
								lineWaits.push(pptLine.waitCreate);
							}
						}
						break;
					}
					case "button":{
						let def=decoVO;
						pptLine=vBox.appendNewChild({
							type:BtnText(decoVO.style||"primary",decoVO.w||120,decoVO.h||24,decoVO.text||"Button",decoVO.outline||false,decoVO.icon||null),
							position:"relative",x:"50%",anchorX:1,y:0,margin:[3,0,options.lineGap,0],
							OnClick(){
								if(self.OnPptAction){
									self.OnPptAction(this,this,def.action);
								}
							}
						});
						if(decoVO.id){
							decoLines[decoVO.id]=pptLine;
						}
						break;
					}
					case "hint":
						pptLine=vBox.appendNewChild({
							"type":"text",id:decoVO.id||"","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,5,0,0],margin:[0,0,options.lineGap||5,0],text:decoVO.text,
							"color":decoVO.color||options.descColor||cfgColor["fontBodySub"],"fontSize":options.descSize||12,"wrap":true,
						});
						if(decoVO.id){
							decoLines[decoVO.id]=pptLine;
						}
						break;
					case "space":
						pptLine=vBox.appendNewChild({
							"type":"hud",id:decoVO.id||"","position":"relative","x":0,"y":0,"w":"100%","h":decoVO.space||decoVO.h||decoVO.height||10,
						});
						if(decoVO.id){
							decoLines[decoVO.id]=pptLine;
						}
						break;
				};
			}else if(typeof(pptName)==="number" && pptName>0){
				vBox.appendNewChild({
					"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":pptName
				});
			}else{
				await self.fillPpt(vBox,ppts,pptName);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.listPpts=async function(){
		let ppts,pptName,pptTemplate,pptType,uiMode,pptCSS,pptLine,title;
		lineWaits=[];
		boxPpts.clearChildren();
		lines.splice(0);
		pptLines={};
		decoLines={};
		if(!template || !dataObj){
			return null;
		}
		if(typeof(template)==="string"){
			template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
		}
		if(!template){
			return;
		}
		if(template.type==="array"){
			let i,n,subType,label,labelFunc;
			pptTemplate=template.element||{type:"auto"};
			if(pptTemplate){
				pptType=pptTemplate.type;
				uiMode=pptTemplate.uiMode;
			}else{
				pptType=null;
				uiMode=null;
			}
			ppts=dataObj;
			label=pptTemplate.label;
			if(label){
				if(label.indexOf("###")>=0){
					labelFunc=(idx)=>{return label.replace("###",""+(idx+1));};
				}else{
					labelFunc=new Function("idx","obj","return (`"+label+"`);");
				}
			}else{
				labelFunc=(idx)=>{return (idx+1)+":"};
			}
			n=dataObj.length;
			for(i=0;i<n;i++){
				title=labelFunc(i,dataObj);
				if(uiMode){
					let path,mod;
					//Choose css by uiMode:
					if(typeof(uiMode)==="string"){
						if(uiMode.endsWith(".js")){
							path=uiMode;
						}else{
							path=VFACT.getDataViewLine(uiMode);
						}
						try{
							mod=await import(path);
							pptCSS=mod.default;
						}catch(err){
							console.eror(err);
						}
					}else if(path instanceof Function){
						pptCSS=path;
					}else{
						console.eror(`uiMode: "${uiMode}" not registered.`);
					}
				}else{
					//Choose css by pptType:
					subType=pptType||typeof(dataObj[i]);
					switch(pptType){
						case "object":
							pptCSS=DataView;
							break;
						case "bool":
						case "boolean":
							pptCSS=DLBool;
							break;
						default:
							pptCSS=DLStd;
							break;
					}
				}
				//pptCSS=pptCSS||DLStd;
				if(pptCSS){
					if(edit){
						pptLine=boxPpts.appendNewChild({
							type:DLEditElement(self,pptCSS(self,template,dataObj,i,options,title),options),position:"relative",
						});
					}else{
						pptLine=boxPpts.appendNewChild({
							type:pptCSS(self,template,dataObj,i,options,title),position:"relative",
						});
					}
					pptLines[pptName]=pptLine;
					lines.push(pptLine);
					if(pptLine.waitCreate && lineWaits){
						lineWaits.push(pptLine.waitCreate);
					}
				}
			}
		}else{
			let layout;
			ppts=template.properties;
			layout=template.layout||Object.keys(ppts);
			await self.fillVBox(boxPpts,layout,ppts);
		}
		if(options.trace){
			if(dataObj.onNotify){
				dataObj.onNotify("Changed",self.OnTrace);
				traced=true;
			}else if(dataObj.on){
				dataObj.on("Changed",self.OnTrace);
				traced=true;
			}
		}
		if(lineWaits && lineWaits.length>0){
			await Promise.all(lineWaits);
			lineWaits=null;
		}
		if(template.OnShow){
			template.OnShow(self,dataObj);
		}
		if(edit){
			if(template.OnEdit){
				template.OnEdit(self);
			}
			if(self.OnEdit){
				self.OnEdit();
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnTrace=function(){
		for(let line of lines){
			line.OnDataChange&&line.OnDataChange();
		}
		if(box){
			box.OnTrace();
		}
		if(template.OnChange){
			template.OnChange();
		}
		if(self.OnDataChange){
			self.OnDataChange();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getEditObj=
	cssVO.getDataObj=
	cssVO.getEditedVO=function(){
		let vo=isArray?[]:{};
		for(let line of lines){
			if(line.getEditedVO){
				vo[line.property]=line.getEditedVO();
			}else{
				vo[line.property]=line.value;
			}
		}
		if(template.wrapObject){
			return template.wrapObject(vo);
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO._OnEdit=function(){
		if(template.OnEdit){
			template.OnEdit(self,dataObj);
		}
		if(box && box._OnEdit){
			box._OnEdit();
		}
		if(self.OnEdit){
			self.OnEdit();
		}
		if(self.emitNotify){
			self.emitNotify("Changed");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focus=function(){
		let line;
		for(line of lines){
			if(line.focus){
				if(line.focus()){
					return true;
				}
			}
		}
		return false;
	};
	
	//************************************************************************
	//Property/line helpers:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.orderArray=function(){
			let list,i,n,line;
			let pptTemplate,label,labelFunc;
			pptTemplate=template.element||{type:"auto"};
			label=pptTemplate.label;
			if(label){
				if(label.indexOf("###")>=0){
					labelFunc=(idx)=>{return label.replace("###",""+(idx+1));};
				}else{
					labelFunc=new Function("idx","return (`"+label+"`);");
				}
			}else{
				labelFunc=(idx)=>{return (idx+1)+":"};
			}
			lines.splice(0);
			list=boxPpts.children;
			n=list.length;
			for(i=0;i<n;i++){
				line=list[i];
				line.property=i;
				line.updateLabel && line.updateLabel(labelFunc(i));
				lines[i]=line;
				pptLines[i]=line;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.newElement=async function(doOrder,tmpt){
			let pptTmp,pptType,uiMode,idx,pptCSS,pptLine;
			if(tmpt){
				pptTmp=tmpt;
			}else{
				pptTmp=template.element||{type:"auto"};
				if(!pptTmp){
					pptLine=lines[lines.length-1];
					if(pptLine){
						pptTmp=pptLine.template;
					}else{
						pptTmp={type:"auto"};
					}
				}
			}
			pptType=pptTmp.type;
			uiMode=pptTmp.uiMode;
			idx=boxPpts.children.length;
			title=pptTmp.label;
			if(title){
				title=title.replace("###",""+idx);
			}else{
				title=idx+":";
			}
			if(uiMode){
				let path,mod;
				//Choose css by uiMode:
				if(uiMode.endsWith(".js")){
					path=uiMode;
				}else{
					path=VFACT.getDataViewLine(uiMode);
				}
				if(typeof(path)==="string"){
					try{
						mod=await import(path);
						pptCSS=mod.default;
					}catch(err){
						console.eror(err);
					}
				}else if(path instanceof Function){
					pptCSS=path;
				}else{
					console.eror(`uiMode: "${uiMode}" not registered.`);
				}
			}else{
				//Choose css by pptType:
				switch(pptType){
					case "object":
						pptCSS=DataView;
						break;
					case "bool":
					case "boolean":
						pptCSS=DLBool;
						break;
					default:
						pptCSS=DLStd;
						break;
				}
			}
			//Append at last:
			if(pptCSS){
				if(edit){
					pptLine=boxPpts.appendNewChild({
						type:DLEditElement(self,pptCSS(self,template,dataObj,idx,options,title),options),position:"relative",
					});
				}else{
					pptLine=boxPpts.appendNewChild({
						type:pptCSS(self,template,dataObj,idx,options,title),position:"relative",
					});
				}
			}
			if(doOrder){
				self.orderArray();
			}
			self._OnEdit && self._OnEdit();
			return pptLine;
		};
	
		//--------------------------------------------------------------------
		cssVO.showElementMenu=async function(line,btn){
			let item,dataView;
			item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
				hud:btn,
				items:[
					{text:"Add element",code:"Add"},
					{text:"Remove",code:"Remove"},
					{text:"Move up",code:"MoveUp"},
					{text:"Move down",code:"MoveDown"},
				]
			});
			if(!item){
				return;
			}
			dataView=line.dataView;
			switch(item.code){
				case "Add":{
					let parent,pptLine;
					parent=line.parent;
					pptLine=await dataView.newElement(false,line.template);
					//Adjust order:
					parent.insertBefore(pptLine,line);
					dataView.orderArray();
					self._OnEdit && self._OnEdit();
					break;
				}
				case "Remove":{
					let parent;
					parent=line.parent;
					parent.removeChild(line);
					dataView.orderArray();
					self._OnEdit && self._OnEdit();
					break;
				}
				case "MoveUp":{
					let pre,parent;
					parent=line.parent;
					pre=line.previousSibling;
					if(pre){
						parent.insertBefore(line,pre);
					}
					dataView.orderArray();
					self._OnEdit && self._OnEdit();
					break;
				}
				case "MoveDown":{
					let nxt,parent;
					parent=line.parent;
					nxt=line.nextSibling;
					if(nxt){
						parent.insertBefore(nxt,line);
					}
					dataView.orderArray();
					self._OnEdit && self._OnEdit();
					break;
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnPptAction=function(line,btn,action){
			box.OnPptAction && box.OnPptAction(line,btn,action);
		};
	
		//--------------------------------------------------------------------
		cssVO.getPptLine=function(pptName){
			let line;
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.getPptLine){
						pts.shift();
						return line.getPptLine(pts.join("."));
					}
					return null;
				}
			}
			return pptLines[pptName];
		};
	
		//--------------------------------------------------------------------
		cssVO.getDecoLine=function(pptName){
			let line;
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.getDecoLine){
						pts.shift();
						return line.getDecoLine(pts.join("."));
					}
					return null;
				}
			}
			return decoLines[pptName];
		};
	
		//--------------------------------------------------------------------
		cssVO.getPptValue=function(pptName){
			let line;
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.getPptValue){
						pts.shift();
						return line.getPptValue(pts.join("."));
					}
					return undefined;
				}else{
					line=pptLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line){
				return line.value;
			}
			return undefined;
		};
	
		//--------------------------------------------------------------------
		cssVO.setPptValue=function(pptName,value){
			let line;
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.getPptValue){
						pts.shift();
						return line.setPptValue(pts.join("."),value);
					}
					return false;
				}else{
					line=pptLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line && line.commitEdit){
				line.commitEdit(value);
				return true;
			}
			return false;
		};
	
		//--------------------------------------------------------------------
		cssVO.showAllLines=function(){
			let line;
			for(line of lines){
				line.display=true;
				if(line.errorTip){
					line.errorTip.display=true;
				}
				if(line.showAllLines){
					line.showAllLines();
				}
			}
			for(let name in decoLines){
				line=decoLines[name];
				line.display=true;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.showPptLine=function(pptName){
			let line;
			if(Array.isArray(pptName)){
				for(line of pptName){
					self.showPptLine(line);
				}
				return;
			}
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.showPptLine){
						pts.shift();
						return line.showPptLine(pts.join("."));
					}
					return;
				}else{
					line=pptLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line){
				line.display=true;
				if(line.errorTip){
					line.errorTip.display=true;
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.hidePptLine=function(pptName){
			let line;
			if(Array.isArray(pptName)){
				for(line of pptName){
					self.hidePptLine(line);
				}
				return;
			}
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.hidePptLine){
						pts.shift();
						return line.hidePptLine(pts.join("."));
					}
					return;
				}else{
					line=pptLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line){
				line.display=false;
				if(line.errorTip){
					line.errorTip.display=false;
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.showDecoLine=function(pptName){
			let line;
			if(Array.isArray(pptName)){
				for(line of pptName){
					self.showDecoLine(line);
				}
				return;
			}
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.showDecoLine){
						pts.shift();
						return line.showDecoLine(pts.join("."));
					}
					return;
				}else{
					line=decoLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line){
				line.display=true;
				if(line.errorTip){
					line.errorTip.display=true;
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.hideDecoLine=function(pptName){
			let line;
			if(Array.isArray(pptName)){
				for(line of pptName){
					self.hideDecoLine(line);
				}
				return;
			}
			if(typeof(pptName)==="string"){
				let pts;
				pts=pptName.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.hideDecoLine){
						pts.shift();
						return line.hideDecoLine(pts.join("."));
					}
					return;
				}else{
					line=decoLines[pptName];
				}
			}else{
				line=pptName;
			}
			if(line){
				line.display=false;
				if(line.errorTip){
					line.errorTip.display=false;
				}
			}
		};
	}
	
	//************************************************************************
	//Error helpers:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.getMissing=function(tips,missing){
			let val,valType,req;
			if(tips){
				self.clearErrorTips();
			}
			missing=missing||[];
			for(let line of lines){
				req=line.template.required;
				if(req){
					valType=line.template.type;
					val=line.value;
					switch(valType){
						case "string":
							if(val==="" || val===undefined){
								missing.push(line.property);
								if(tips){
									self.showErrorTip(line,(($ln==="CN")?("必填。"):/*EN*/("Required.")));
								}
								line.showFace("error");
							}
							break;
						case "int":
						case "number":
							if(!isFinite(val)){
								missing.push(line.property);
								if(tips){
									self.showErrorTip(line,(($ln==="CN")?("必填。"):/*EN*/("Required.")));
								}
								line.showFace("error");
							}
							break;
						case "array":{
							let ary=line.getEditedVO();
							if(!ary || !ary.length){
								missing.push(line.property);
								if(tips){
									self.showErrorTip(line,(($ln==="CN")?("必填。"):/*EN*/("Required.")));
								}
								line.showFace("error");
							}
							break;
						}
						case "object":
							if(line.getMissing){
								line.getMissing(tips,missing);
							}
							break;
						default:
							if(val==="" || val===undefined){
								missing.push(line.property);
								if(tips){
									self.showErrorTip(line,(($ln==="CN")?("必填。"):/*EN*/("Required.")));
								}
								line.showFace("error");
							}
							break;
					}
				}
			}
			return missing.length>0;
		};
		
		//--------------------------------------------------------------------
		cssVO.clearErrorTips=function(){
			for(let line of lines){
				if(line.errorTip){
					boxPpts.removeChild(line.errorTip);
					line.errorTip=null;
				}
				if(line.clearErrorTips){
					line.clearErrorTips();
				}else if(line.clearErrorTip){
					line.clearErrorTip();
				}
				line.showFace("!error");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.showErrorTip=function(line,tip){
			if(typeof(line)==="string"){
				let pts;
				pts=line.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.showErrorTip){
						pts.shift();
						return line.showErrorTip(pts.join("."));
					}
					return;
				}else{
					line=pptLines[line];
				}
			}
			if(!line){
				return;
			}
			if(line.showErrorTip){
				line.showErrorTip(tip);
				return;
			}
			line.showFace("error");
			if(line.errorTip){
				line.errorTip.text=tip;
				return;
			}
			line.errorTip=boxPpts.insertNewBefore({
				"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"100%","h":"","color":cfgColor.error,"text":tip,"fontSize":options?(options.labelSize||12):12,"wrap":true,
			},line);
		};
	
		//--------------------------------------------------------------------
		cssVO.clearErrorTip=function(line){
			if(typeof(line)==="string"){
				let pts;
				pts=line.split(".");
				if(pts.length>1){
					line=pptLines[pts[0]];
					if(line && line.clearErrorTip){
						pts.shift();
						return line.clearErrorTip(pts.join("."));
					}
					return;
				}else{
					line=pptLines[line];
				}
			}
			if(!line){
				return;
			}
			if(line.clearErrorTip){
				line.clearErrorTip();
			}
			line.showFace("!error");
			if(line.errorTip){
				line.errorTip.display=false;
			}
		};
	}
	/*}#1HQ1M47LD1PostCSSVO*/
	cssVO.constructor=DataView;
	return cssVO;
};
/*#{1HQ1M47LD1ExCodes*/
/*}#1HQ1M47LD1ExCodes*/

//----------------------------------------------------------------------------
DataView.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HQ1M47LD1PreAISpot*/
	/*}#1HQ1M47LD1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("数据视图"):("Data View"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HQ1M47LD1PostAISpot*/
	/*}#1HQ1M47LD1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
DataView.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("数据视图"):("Data View")),icon:"rename.svg",previewImg:false,
	fixPose:true,initW:300,initH:100,
	catalog:"Views",
	args: {
		"box": {
			"name": "box", "showName": "box", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"template": {
			"name": "template", "showName": "template", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"dataObj": {
			"name": "dataObj", "showName": "dataObj", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"property": {
			"name": "property", "showName": "property", "type": "string", "key": true, "fixed": true, "initVal": ""
		}, 
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"titleHeight": {
						"name": "titleHeight", "showName": "titleHeight", "type": "int", "key": true, "fixed": true, "initVal": 30
					}, 
					"titleSize": {
						"name": "titleSize", "showName": "titleSize", "type": "int", "key": true, "fixed": true, "initVal": 18
					}, 
					"titleColor": {
						"name": "titleColor", "showName": "titleColor", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"titleBold": {
						"name": "titleBold", "showName": "titleBold", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"lineHeight": {
						"name": "lineHeight", "showName": "lineHeight", "type": "int", "key": true, "fixed": true, "initVal": 30
					}, 
					"lineGap": {
						"name": "lineGap", "showName": "lineGap", "type": "int", "key": true, "fixed": true, "initVal": 5
					}, 
					"labelSize": {
						"name": "labelSize", "showName": "labelSize", "type": "int", "key": true, "fixed": true, "initVal": 12
					}, 
					"labelColor": {
						"name": "labelColor", "showName": "labelColor", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"labelBold": {
						"name": "labelBold", "showName": "labelBold", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"labelLine": {
						"name": "labelLine", "showName": "labelLine", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"valueSize": {
						"name": "valueSize", "showName": "valueSize", "type": "int", "key": true, "fixed": true, "initVal": 14
					}, 
					"valueColor": {
						"name": "valueColor", "showName": "valueColor", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"valueBold": {
						"name": "valueBold", "showName": "valueBold", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"segHeight": {
						"name": "segHeight", "showName": "segHeight", "type": "int", "key": true, "fixed": true, "initVal": 20
					}, 
					"segSize": {
						"name": "segSize", "showName": "segSize", "type": "int", "key": true, "fixed": true, "initVal": 14
					}, 
					"segBold": {
						"name": "segBold", "showName": "segBold", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"segColor": {
						"name": "segColor", "showName": "segColor", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
					}, 
					"trace": {
						"name": "trace", "showName": "trace", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"edit": {
						"name": "edit", "showName": "edit", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"noteSize": {
						"name": "noteSize", "showName": "noteSize", "type": "int", "key": true, "fixed": true, "initVal": 12
					}, 
					"autoCollapse": {
						"name": "autoCollapse", "showName": "autoCollapse", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"hideCollapse": {
						"name": "hideCollapse", "showName": "hideCollapse", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"valueRightAlign": {
						"name": "valueRightAlign", "showName": "valueRightAlign", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"gridLine": {
						"name": "gridLine", "showName": "gridLine", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"labelWidth": {
						"name": "labelWidth", "showName": "labelWidth", "type": "int", "key": true, "fixed": true, "initVal": 0
					}
				}
			}, 
			"key": true, "fixed": true
		}, 
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Object View", "localizable": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","padding","minW","minH","maxW","maxH"],
	faces:["open","close"],
	subContainers:{
	},
	/*#{1HQ1M47LD0ExGearInfo*/
	/*}#1HQ1M47LD0ExGearInfo*/
};
/*#{1HQ1M47LD0EndDoc*/
DataView.gearExport.args.box.edit=false;
DataView.gearExport.args.property.edit=false;
DataView.gearExport.args.template={
	"name": "template", "showName": "Template", "type": "choice", "key": true, "fixed": true,"initVal": null,
	"vals":[],rawEdit:false,
	val2ShowText(val){
		let tmp;
		if(val===null){
			return null;
		}
		tmp=VFACT.getEditUITemplate(val);
		if(tmp){
			return tmp.label||tmp.name;
		}
		return val;
	},
	getMenuItems(){
		let list,tmps,tmpName,tmp;
		list=[{text:"None",valText:`null`}];
		tmps=VFACT.getEditUITemplates();
		for(tmpName in tmps){
			tmp=tmps[tmpName];
			if(tmp instanceof Function){
				tmp=tmp();
			}
			if(tmp){
				list.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
			}
		}
		return list;
	}
};
DataView.gearExport.args.dataObj={
	"name": "dataObj", "showName": "DataObj", "type": "choice", "key": true, "fixed": true, "initVal": null,
	"vals":[],
	getMenuItems(){
		let template,classCode;
		let list,tmps,tmpName,tmp,mockObj;
		list=[{text:"None",valText:`null`}];
		template=this.owner.getAttrVal("template");
		if(template){
			let objClass,EditAttr,mockups,mockup;
			EditAttr=VFACT.classRegs.EditAttr;
			classCode="ObjClass"+template;
			objClass=EditAttr.getClass(classCode);
			if(objClass){
				mockups=objClass.mockupObjs.attrList;
				for(mockup of mockups){
					mockObj=mockup.getJSObj(0,5,false);
					list.push({text:mockup.name,valText:`#${JSON.stringify(mockObj)}`});
				}
			}
		}
		return list;
	}
};
DataView.gearExport.args.options.def.allowExtraAttr=true;
/*}#1HQ1M47LD0EndDoc*/

export default DataView;
export{DataView};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQ1M47LD0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1M47LD2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1M47LD3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1M47LD4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1M47LD5",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"property": {
//					"type": "string",
//					"valText": ""
//				},
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1HQ1MDMNA0",
//					"attrs": {
//						"titleHeight": {
//							"type": "int",
//							"valText": "30"
//						},
//						"titleSize": {
//							"type": "int",
//							"valText": "18"
//						},
//						"titleColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"titleBold": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"lineHeight": {
//							"type": "int",
//							"valText": "30"
//						},
//						"lineGap": {
//							"type": "int",
//							"valText": "5"
//						},
//						"labelSize": {
//							"type": "int",
//							"valText": "12"
//						},
//						"labelColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"labelBold": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"labelLine": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"valueSize": {
//							"type": "int",
//							"valText": "14"
//						},
//						"valueColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"valueBold": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"segHeight": {
//							"type": "int",
//							"valText": "20"
//						},
//						"segSize": {
//							"type": "int",
//							"valText": "14"
//						},
//						"segBold": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"segColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"trace": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"edit": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"noteSize": {
//							"type": "int",
//							"valText": "12"
//						},
//						"autoCollapse": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"hideCollapse": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"valueRightAlign": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"gridLine": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"labelWidth": {
//							"type": "int",
//							"valText": "0"
//						}
//					}
//				},
//				"title": {
//					"type": "string",
//					"valText": "Object View",
//					"localizable": true
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1M47LD6",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#null"
//				},
//				"label": {
//					"type": "string",
//					"valText": "#template?(template.label||template.name):\"Missing Object\"#>null"
//				},
//				"isArray": {
//					"type": "bool",
//					"valText": "#false"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"fixedOrder": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1M47LD7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8IVOP9I0",
//					"attrs": {
//						"id": "openOrCollapse",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "80",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8J01R800",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8J01R801",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8J01R802",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Data View",
//			"localize": {
//				"EN": "Data View",
//				"CN": "数据视图"
//			},
//			"localizable": true
//		},
//		"gearIcon": "rename.svg",
//		"gearW": "300",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1M47LD8",
//			"attrs": {
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8ITFQH20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8IU5TC30",
//							"attrs": {}
//						}
//					}
//				},
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8ITFUDA0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8IU5TC31",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1M47LD9",
//			"attrs": {
//				"dev": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HQ837KKL0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HQ1M47LD5",
//							"attrs": {
//								"box": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"template": {
//									"type": "auto",
//									"valText": "#{name:\"Data Object\",}"
//								},
//								"dataObj": {
//									"type": "auto",
//									"valText": "{}"
//								},
//								"property": {
//									"type": "string",
//									"valText": ""
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1HQ1MDMNA0",
//									"attrs": {
//										"lineHeight": {
//											"type": "int",
//											"valText": "30"
//										},
//										"labelSize": {
//											"type": "int",
//											"valText": "12"
//										},
//										"labelColor": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"valueSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"valueColor": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"labelLine": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"valueBold": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"edit": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"trace": {
//											"type": "bool",
//											"valText": "false"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HQ1M47LD7",
//							"attrs": {}
//						}
//					}
//				},
//				"null": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HQ839MSO0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HQ1M47LD5",
//							"attrs": {
//								"box": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"template": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"dataObj": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"property": {
//									"type": "string",
//									"valText": ""
//								},
//								"options": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1HQ1MDMNA0",
//									"attrs": {
//										"lineHeight": {
//											"type": "int",
//											"valText": "30"
//										},
//										"labelSize": {
//											"type": "int",
//											"valText": "12"
//										},
//										"labelColor": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"valueSize": {
//											"type": "int",
//											"valText": "14"
//										},
//										"valueColor": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"fontBody\"]"
//										},
//										"labelLine": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"valueBold": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"edit": {
//											"type": "bool",
//											"valText": "false"
//										},
//										"trace": {
//											"type": "bool",
//											"valText": "false"
//										}
//									}
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HQ1M47LD7",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1M47LD1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1M47LD10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#box?[0,0,10,0]:[0,0,options.lineGap||5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "16",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ25L9CK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ26A9DM0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxLabel",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "#box?(options.segHeight||30):(options.titleHeight||30)",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsWrap": "No Wrap",
//										"itemsAlign": "Center",
//										"attach": "#!!title"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1I8ITRQIO0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8IU5TC32",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "15",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/zhankai.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I8IU5TC33",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",15,0,appCfg.sharedAssets+\"/zhankai.svg\",null)",
//														"id": "BtnOpen",
//														"position": "relative",
//														"x": "7",
//														"y": "7",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"attach": "#(!!box)&&(!options.hideCollapse)"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8IU5TC34",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC35",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC36",
//																	"attrs": {
//																		"rotate": {
//																			"type": "number",
//																			"valText": "90"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														},
//														"1I8ITFUDA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC37",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC38",
//																	"attrs": {
//																		"rotate": {
//																			"type": "number",
//																			"valText": "0"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFUDA0",
//															"faceTagName": "close"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8IU5TC39",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8J041030",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8J041031",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I8IVOP9I0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8IU5TC310",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I8IU5TC311",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HQ25PQ6Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ25PQ6Q1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxIcon",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "#box?(options?(options.segHeight-3):22):(options?(options.titleHeight-3):22)",
//														"h": "#box?(options?(options.segHeight-3):22):(options?(options.titleHeight-3):22)",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#box?(options?(options.segColor||cfgColor[\"fontBody\"]):cfgColor[\"fontBody\"]):(options?(options.titleColor||cfgColor[\"fontBody\"]):cfgColor[\"fontBody\"])",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"attach": "#!!icon",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ25PQ6R0",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC312",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC313",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ25PQ6S2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ25PQ6S3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ25MEIR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ25MEIR1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#box?(options?(options.segColor||cfgColor[\"fontBody\"]):cfgColor[\"fontBody\"]):(options?(options.titleColor||cfgColor[\"fontBody\"]):cfgColor[\"fontBody\"])",
//														"text": "#title",
//														"font": "",
//														"fontSize": "#box?(options?(options.segSize||14):14):(options?(options.titleSize||14):14)",
//														"bold": "#box?(options?(!!options.segBold):true):(options?(!!options.titleBold):true)",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!title"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ25MEIS0",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC316",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC317",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ25MEIS1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ25MEIS2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ26A9DM1",
//									"attrs": {
//										"1I8ITFQH20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8IU5TC320",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8IU5TC321",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8ITFQH20",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ26A9DM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ26A9DM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I85M02450",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I85M3FQ50",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I85M382O0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I85M382O1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxBG",
//														"position": "Absolute",
//														"x": "10",
//														"y": "0",
//														"w": "100%-10",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[0,0,0,0]",
//														"border": "[0,0,0,1]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"attach": "#!!box"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I85M382P0",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC324",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC325",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I85M382P1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I85M382P2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I85M28760",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I85M28761",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "#(template && template.desc)",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,5,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#template?template.desc:\"\"",
//														"font": "",
//														"fontSize": "#options?(options.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I85M28762",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC328",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC329",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I85M28763",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I85M28764",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I85M2IB20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I85M2IB21",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxPpts",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "#box?[5,5,5,15]:[5,5,5,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I85M2IB30",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC332",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC333",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I85M2IB31",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I85M2IB32",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1I85M2MA00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I85M2MA01",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I85M2MA02",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//														"id": "BtnAddElement",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"attach": "#(!!isArray)&&(edit)&&(!fixedOrder)"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I85M2MA10",
//													"attrs": {
//														"1I8ITFQH20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8IU5TC336",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8IU5TC337",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8ITFQH20",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I85M2MA11",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I85M2MA12",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I85M2MA13",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I85M2MA14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I85M2MA15",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I85M3FQ51",
//									"attrs": {
//										"1I8ITFQH20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8IU5TC340",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8IU5TC341",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8ITFQH20",
//											"faceTagName": "open"
//										},
//										"1I8ITFUDA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8IU5TC342",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8IU5TC343",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8ITFUDA0",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I85M3FQ52",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I85M3FQ53",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1M47LD11",
//					"attrs": {
//						"1I8ITFQH20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8IU5TC344",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8IU5TC345",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8ITFQH20",
//							"faceTagName": "open"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1M47LD12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1M47LD13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1M47LD14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}