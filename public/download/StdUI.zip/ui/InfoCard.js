//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H54B0SFB0StartDoc*/
/*}#1H54B0SFB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let InfoCard=function(title,intro,pic,icon,picW,picH){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H54B0SFB1LocalVals*/
	let focused=false;
	/*}#1H54B0SFB1LocalVals*/
	
	/*#{1H54B0SFB1PreState*/
	/*}#1H54B0SFB1PreState*/
	state={
		"border":2,"corner":12,"sizeCap":txtSize.big,"sizeLabel":txtSize.smallPlus,"hideLabel":false,"capBold":false,
		/*#{1H54B0SFC3ExState*/
		/*}#1H54B0SFC3ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H54B0SFB1PostState*/
	/*}#1H54B0SFB1PostState*/
	cssVO={
		"hash":"1H54B0SFB1",nameHost:true,
		"type":"button","position":"relative","x":38,"y":26,"w":300,"h":"","cursor":"pointer","padding":[10,10,10,picW>0?(picW+15):10],"minW":"","minH":(pic&&picH>0)?picH+20:30,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","traceSize":true,"subAlign":1,
		children:[
			{
				"hash":"1H54B23MV0",
				"type":"box","id":"BG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],
				"border":$P(()=>(state.border),state),"borderColor":cfgColor.lineBodyLit,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H571UPP00",
				"type":"image","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":pic,
				"fitSize":"cover","alignX":1,"alignY":1,
			},
			{
				"hash":"1H8H7U93F0",
				"type":"box","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
				"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H5721BRE0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","autoLayout":true,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBody,"text":title,"fontSize":$P(()=>(state.sizeCap),state),"fontWeight":(state.capBold)?"bold":"normal","fontStyle":"normal",
				"textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1H572917N0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
				"text":intro,"fontSize":$P(()=>(state.sizeLabel),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"attached":!state.hideLabel,
			}
		],
		get $$border(){return state["border"]},
		set $$border(v){
			state["border"]=v;
			/*#{1H54B0SFB1Setborder*/
			/*}#1H54B0SFB1Setborder*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H54B0SFB1Setcorner*/
			/*}#1H54B0SFB1Setcorner*/
		},
		get $$sizeCap(){return state["sizeCap"]},
		set $$sizeCap(v){
			state["sizeCap"]=v;
			/*#{1H54B0SFB1SetsizeCap*/
			/*}#1H54B0SFB1SetsizeCap*/
		},
		get $$sizeLabel(){return state["sizeLabel"]},
		set $$sizeLabel(v){
			state["sizeLabel"]=v;
			/*#{1H54B0SFB1SetsizeLabel*/
			/*}#1H54B0SFB1SetsizeLabel*/
		},
		get $$hideLabel(){return state["hideLabel"]},
		set $$hideLabel(v){
			state["hideLabel"]=v;
			/*#{1H54B0SFB1SethideLabel*/
			/*}#1H54B0SFB1SethideLabel*/
		},
		get $$capBold(){return state["capBold"]},
		set $$capBold(v){
			state["capBold"]=v;
			/*#{1H54B0SFB1SetcapBold*/
			/*}#1H54B0SFB1SetcapBold*/
		},
		/*#{1H54B0SFB1ExtraCSS*/
		/*}#1H54B0SFB1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H599SSCN0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H599SSCN0PreCode*/
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":state.border,"borderColor":cfgColor.lineBodyLit
				}
			},"over":{
				/*#{1H59BOAKE1PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H59BOAKE1PreCode*/
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":state.border+1,"borderColor":cfgColor.lineBody
				}
			},"down":{
				/*#{1H59BOAKE3PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H59BOAKE3PreCode*/
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":state.border+1,"borderColor":cfgColor.lineBody
				}
			},"gray":{
				/*#{1H59CBSSK0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H59CBSSK0PreCode*/
				"#self":{
					"alpha":0.5
				},
				/*BG*/"#1H54B23MV0":{
					"border":state.border,"borderColor":cfgColor.lineBodyLit
				}
			},"focus":{
				/*BG*/"#1H54B23MV0":{
					"background":cfgColor["itemFocus"],"borderColor":cfgColor["fontBody"]
				},
				/*#{1IIQBVFKC0Code*/
				$(){
					focused=true;
				},
				/*}#1IIQBVFKC0Code*/
			},"blur":{
				/*BG*/"#1H54B23MV0":{
					"background":[255,255,255,0],"borderColor":cfgColor.lineBodyLit
				},
				/*#{1IIQBVLH70Code*/
				$(){
					focused=false;
				},
				/*}#1IIQBVLH70Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H54B0SFB1Create*/
			/*}#1H54B0SFB1Create*/
		},
		/*#{1H54B0SFB1EndCSS*/
		/*}#1H54B0SFB1EndCSS*/
	};
	/*#{1H54B0SFB1PostCSSVO*/
	/*}#1H54B0SFB1PostCSSVO*/
	cssVO.constructor=InfoCard;
	return cssVO;
};
/*#{1H54B0SFB1ExCodes*/
/*}#1H54B0SFB1ExCodes*/

//----------------------------------------------------------------------------
InfoCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H54B0SFB1PreAISpot*/
	/*}#1H54B0SFB1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("对象卡片"):("Obj-Card"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H54B0SFB1PostAISpot*/
	/*}#1H54B0SFB1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
InfoCard.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("对象卡片"):("Obj-Card")),icon:"idcard.svg",previewImg:"./PicCard.png",
	fixPose:false,initW:300,initH:80,
	"desc":(($ln==="CN")?("一个带有标题和简介的卡片。可能在左侧有一张图片或者图标。"):("A card with title and intro. Maybe has a picture image on left side.")),
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Title", "localizable": true
		}, 
		"intro": {
			"name": "intro", "showName": "intro", "type": "string", "key": true, "fixed": true, "initVal": "Card intro text", "localizable": true
		}, 
		"pic": {
			"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/prj.svg", "initValText": "#appCfg.sharedAssets+\"/prj.svg\""
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": ""
		}, 
		"picW": {
			"name": "picW", "showName": "picW", "type": "int", "key": true, "fixed": true, "initVal": 50
		}, 
		"picH": {
			"name": "picH", "showName": "picH", "type": "int", "key": true, "fixed": true, "initVal": 50
		}
	},
	state:{
		border:{name:"border",type:"int",initVal:2},
		corner:{name:"corner",type:"int",initVal:12},
		sizeCap:{name:"sizeCap",type:"int",initVal:20,editType:"fontSize"},
		sizeLabel:{name:"sizeLabel",type:"int",initVal:14,editType:"fontSize"},
		hideLabel:{name:"hideLabel",type:"bool",initVal:false},
		capBold:{name:"capBold",type:"bool",initVal:false}
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","filter","cursor","zIndex","flex","margin","minW","minH","maxW","maxH","enable","drag"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1H54B0SFB0ExGearInfo*/
	/*}#1H54B0SFB0ExGearInfo*/
};
/*#{1H54B0SFB0EndDoc*/
/*}#1H54B0SFB0EndDoc*/

export default InfoCard;
export{InfoCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H54B0SFB0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H54B0SFB2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H54B0SFC0",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5MLLAOG0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H54B0SFC1",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Title",
//					"localizable": true
//				},
//				"intro": {
//					"type": "string",
//					"valText": "Card intro text",
//					"localizable": true
//				},
//				"pic": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/prj.svg\""
//				},
//				"icon": {
//					"type": "url",
//					"valText": ""
//				},
//				"picW": {
//					"type": "int",
//					"valText": "50"
//				},
//				"picH": {
//					"type": "int",
//					"valText": "50"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H54B0SFC2",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H54B0SFC3",
//			"attrs": {
//				"border": {
//					"type": "int",
//					"valText": "2"
//				},
//				"corner": {
//					"type": "int",
//					"valText": "12"
//				},
//				"sizeCap": {
//					"type": "int",
//					"valText": "#txtSize.big",
//					"editType": "fontSize"
//				},
//				"sizeLabel": {
//					"type": "int",
//					"valText": "#txtSize.smallPlus",
//					"editType": "fontSize"
//				},
//				"hideLabel": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"capBold": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Obj-Card",
//			"localize": {
//				"EN": "Obj-Card",
//				"CN": "对象卡片"
//			},
//			"localizable": true
//		},
//		"gearIcon": "idcard.svg",
//		"gearW": "300",
//		"gearH": "80",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "A card with title and intro. Maybe has a picture image on left side.",
//			"localize": {
//				"EN": "A card with title and intro. Maybe has a picture image on left side.",
//				"CN": "一个带有标题和简介的卡片。可能在左侧有一张图片或者图标。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "./PicCard.png",
//		"faceTags": {
//			"jaxId": "1H54B0SFC4",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H599SSCN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE1",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE2",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE4",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59CBSSK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59CCI1N0",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIQBVFKC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIQC21RN0",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIQBVLH70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIQC21RN1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HRVQ02460",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H54B0SFB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H54B0SFC5",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "38",
//						"y": "26",
//						"w": "300",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "#[10,10,10,picW>0?(picW+15):10]",
//						"minW": "",
//						"minH": "#(pic&&picH>0)?picH+20:30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y",
//						"traceSize": "true",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H54B23MV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H572GMLL0",
//									"attrs": {
//										"type": "box",
//										"id": "BG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0]",
//										"border": "${state.border},state",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "${state.corner},state",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H572GMLL1",
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N2",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "#state.border",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N4",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "#state.border+1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N6",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "#state.border+1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CJKI01",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "#state.border",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										},
//										"1IIQBVLH70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[255,255,255,0]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVLH70",
//											"faceTagName": "blur"
//										},
//										"1IIQBVFKC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemFocus\"]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVFKC0",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H572GMLL2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H572GMLL3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1H571UPP00",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H572GMLL4",
//									"attrs": {
//										"type": "image",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "#pic",
//										"autoSize": "false",
//										"fitSize": "Cover",
//										"repeat": "true",
//										"alignX": "Center",
//										"alignY": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H572GMLL5",
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N10",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA31CPFK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA31CPFK1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										},
//										"1IIQBVFKC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVFKC0",
//											"faceTagName": "focus"
//										},
//										"1IIQBVLH70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T1ECE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T1ECE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVLH70",
//											"faceTagName": "blur"
//										},
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H572GMLL6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H572GMLL7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H8H7U93F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H8H7U93F1",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H8H7U93F2",
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H8H7U93F5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H8H7U93F6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA31CPFK2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA31CPFK3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										},
//										"1IIQBVFKC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVFKC0",
//											"faceTagName": "focus"
//										},
//										"1IIQBVLH70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T1ECE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T1ECE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVLH70",
//											"faceTagName": "blur"
//										},
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H8H7U93F9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H8H7U93F10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H5721BRE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H57290200",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBody",
//										"text": "#title",
//										"font": "",
//										"fontSize": "${state.sizeCap},state",
//										"bold": "#state.capBold",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H57290201",
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N14",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA31CPFK4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA31CPFK5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										},
//										"1IIQBVFKC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVFKC0",
//											"faceTagName": "focus"
//										},
//										"1IIQBVLH70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T1ECE4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T1ECE5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVLH70",
//											"faceTagName": "blur"
//										},
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D210",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D211",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H57290202",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H57290203",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H572917N0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H572917N1",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "#intro",
//										"font": "",
//										"fontSize": "${state.sizeLabel},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"attach": "#!state.hideLabel"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H572917O0",
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N17",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CCI1N18",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA31CPFK6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA31CPFK7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										},
//										"1IIQBVFKC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQC21RN20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQC21RN21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVFKC0",
//											"faceTagName": "focus"
//										},
//										"1IIQBVLH70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T1ECE6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T1ECE7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQBVLH70",
//											"faceTagName": "blur"
//										},
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D212",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D213",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J67T29D214",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J67T29D215",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H572917O1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H572917O2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H54B0SFC6",
//					"attrs": {
//						"1H59BOAKE1": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CCI1N21",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CCI1N22",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE1",
//							"faceTagName": "over"
//						},
//						"1H59CBSSK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CCI1N23",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CCI1N24",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59CBSSK0",
//							"faceTagName": "gray"
//						},
//						"1H599SSCN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CJKI020",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CJKI021",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H599SSCN0",
//							"faceTagName": "up"
//						},
//						"1H59BOAKE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CJKI022",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CJKI023",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE3",
//							"faceTagName": "down"
//						},
//						"1IIQBVFKC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIQC21RN24",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQC21RN25",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIQBVFKC0",
//							"faceTagName": "focus"
//						},
//						"1IIQBVLH70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J67T1ECE8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J67T1ECE9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIQBVLH70",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H54B0SFC7",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H54B0SFC8",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H54B0SFC9",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "border"
//				},
//				{
//					"type": "string",
//					"valText": "corner"
//				},
//				{
//					"type": "string",
//					"valText": "sizeCap"
//				},
//				{
//					"type": "string",
//					"valText": "sizeLabel"
//				},
//				{
//					"type": "string",
//					"valText": "hideLabel"
//				},
//				{
//					"type": "string",
//					"valText": "capBold"
//				}
//			]
//		}
//	}
//}