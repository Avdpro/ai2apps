//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H2OFG9J20StartDoc*/
/*}#1H2OFG9J20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TxtLink=function(href,color,colorOver,colorDown,newPage){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H2OFG9J21LocalVals*/
	let mouseDown=false;
	let colorUp;
	/*}#1H2OFG9J21LocalVals*/
	
	/*#{1H2OFG9J21PreState*/
	/*}#1H2OFG9J21PreState*/
	/*#{1H2OFG9J21PostState*/
	/*}#1H2OFG9J21PostState*/
	cssVO={
		"hash":"1H2OFG9J21",nameHost:true,
		"type":"text","x":0,"y":0,"w":"","h":"","cursor":"pointer","styleClass":"","color":color,"text":"Link Text","fontWeight":"normal","fontStyle":"normal",
		"textDecoration":"underline",
		/*#{1H2OFG9J21ExtraCSS*/
		/*}#1H2OFG9J21ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H2OFG9J21Create*/
			let webObj;
			colorUp=self.color;
			webObj=self.$_webObj;
			function OnMouseUpOut(evt){
				if(!mouseDown)
					return;
				mouseDown=false;
				VFACT.sysRemoveOnMouseUp(OnMouseUpOut);
			}
			webObj.addEventListener("mousedown",(evt)=>{
				if(mouseDown)
					return;
				mouseDown=true;
				self.color=colorDown;
				VFACT.sysAddOnMouseUp(OnMouseUpOut);
			},false);
			webObj.addEventListener("mouseup",(evt)=>{
				if(!mouseDown)
					return;
				VFACT.sysRemoveOnMouseUp(OnMouseUpOut);
				self.color=colorOver;
				mouseDown=false;
				if(href){
					if(newPage){
						window.open(href,null);
					}else{
						document.location.href=href;
					}
				}
			},true);
			/*}#1H2OFG9J21Create*/
		},
		/*#{1H2OFG9J21EndCSS*/
		/*}#1H2OFG9J21EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn,event){
		/*#{1H2OFQJ380FunctionBody*/
		if(isIn){
			if(mouseDown){
				self.color=colorDown;
			}else{
				self.color=colorOver;
			}
		}else{
			self.color=colorUp;
		}
		/*}#1H2OFQJ380FunctionBody*/
	};
	/*#{1H2OFG9J21PostCSSVO*/
	/*}#1H2OFG9J21PostCSSVO*/
	return cssVO;
};
/*#{1H2OFG9J21ExCodes*/
/*}#1H2OFG9J21ExCodes*/

TxtLink.gearExport={
	framework: "jax",
	hudType: "text",
	"showName":(($ln==="CN")?("链接"):("Link")),icon:"link.svg",previewImg:"./Link.png",
	fixPose:false,initW:100,initH:20,
	"desc":"Link text, click to open new page or change current page's location.",
	catalog:"Texts",
	args: {
		"href": {
			"name": "href", "showName": "href", "type": "string", "key": true, "fixed": true, "initVal": ""
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [13,110,253,1]
		}, 
		"colorOver": {
			"name": "colorOver", "showName": "colorOver", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [9.1,77,177.1,1]
		}, 
		"colorDown": {
			"name": "colorDown", "showName": "colorDown", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"newPage": {
			"name": "newPage", "showName": "newPage", "type": "bool", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","alpha","rotate","scale","filter","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH","color","text","font","fontSize","bold","italic","underline","alignH","alignV","wrap","ellipsis","select","shadow","shadowX","shadowY","shadowBlur","shadowColor","shadowEx"],
	faces:[],
	subContainers:{
	},
	/*#{1H2OFG9J20ExGearInfo*/
	/*}#1H2OFG9J20ExGearInfo*/
};
export default TxtLink;
export{TxtLink};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearText",
//	"jaxId": "1H2OFG9J20",
//	"editVersion": 122,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H2OFG9J30",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H2OFG9J31",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8GJ1LJK0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2OFG9J32",
//			"editVersion": 56,
//			"attrs": {
//				"href": {
//					"type": "string",
//					"valText": ""
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.primary"
//				},
//				"colorOver": {
//					"type": "colorRGBA",
//					"valText": "#[...cfgColor.primary,-30]"
//				},
//				"colorDown": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"newPage": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2OFG9J33",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H2OFG9J34",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Link",
//			"localize": {
//				"EN": "Link",
//				"CN": "链接"
//			},
//			"localizable": true
//		},
//		"gearIcon": "link.svg",
//		"gearW": "100",
//		"gearH": "20",
//		"gearCatalog": "Texts",
//		"description": "Link text, click to open new page or change current page's location.",
//		"fixPose": "false",
//		"previewImg": "./Link.png",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H2OFG9J35",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "text",
//			"jaxId": "1H2OFG9J21",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H2OFG9J36",
//					"editVersion": 146,
//					"attrs": {
//						"type": "text",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"\"",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"color": "#color",
//						"text": "Link Text",
//						"font": "",
//						"fontSize": "16",
//						"bold": "false",
//						"italic": "false",
//						"underline": "true",
//						"alignH": "Left",
//						"alignV": "Top",
//						"wrap": "false",
//						"ellipsis": "false",
//						"select": "false",
//						"shadow": "false",
//						"shadowX": "0",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowColor": "[0,0,0,1.00]",
//						"shadowEx": "",
//						"maxTextW": "0",
//						"autoSizeW": "false",
//						"autoSizeH": "false"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": []
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H2OFG9J37",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H2OFG9J38",
//					"editVersion": 2,
//					"attrs": {
//						"OnMouseInOut": {
//							"type": "fixedFunc",
//							"jaxId": "1H2OFQJ380",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1H2Q3F11I0",
//									"editVersion": 4,
//									"attrs": {
//										"isIn": "",
//										"event": ""
//									}
//								}
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H2OFG9J39",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "false",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H2OFG9J310",
//			"editVersion": 190,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"color": "true",
//				"text": "true",
//				"font": "true",
//				"fontSize": "true",
//				"bold": "true",
//				"italic": "true",
//				"underline": "true",
//				"alignH": "true",
//				"alignV": "true",
//				"autoSizeW": "false",
//				"autoSizeH": "false",
//				"wrap": "true",
//				"ellipsis": "true",
//				"select": "true",
//				"shadow": "true",
//				"shadowX": "true",
//				"shadowY": "true",
//				"shadowBlur": "true",
//				"shadowColor": "true",
//				"shadowEx": "true",
//				"maxTextW": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}