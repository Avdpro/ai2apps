//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IM04HNJU0StartDoc*/
/*}#1IM04HNJU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let PathCompareCenter=function(entryObj,node){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtState;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let focused=false;
	
	/*#{1IM04HNJU1LocalVals*/
	/*}#1IM04HNJU1LocalVals*/
	
	/*#{1IM04HNJU1PreState*/
	/*}#1IM04HNJU1PreState*/
	/*#{1IM04HNJU1PostState*/
	/*}#1IM04HNJU1PostState*/
	cssVO={
		"hash":"1IM04HNJU1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":32,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IM04J40K0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],"border":[0,1,0,1],
				"borderColor":cfgColor["fontBodyLit"],
				children:[
					{
						"hash":"1IM2RG5PH0",
						"type":"text","id":"TxtState","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","color":[0,0,0],"text":"-","fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignH":1,"alignV":1,
					}
				],
			}
		],
		/*#{1IM04HNJU1ExtraCSS*/
		/*}#1IM04HNJU1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1IM04J40K0":{
					"background":[255,255,255,0]
				}
			},"down":{
				/*BoxBG*/"#1IM04J40K0":{
					"background":cfgColor["itemDown"]
				}
			},"over":{
				/*BoxBG*/"#1IM04J40K0":{
					"background":cfgColor["itemOver"]
				}
			},"focus":{
				/*BoxBG*/"#1IM04J40K0":{
					"background":cfgColor["itemFocus"]
				}
			},"blur":{
				/*BoxBG*/"#1IM04J40K0":{
					"background":[255,255,255,0]
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtState=self.TxtState;
			/*#{1IM04HNJU1Create*/
			this.action="Open";
			/*}#1IM04HNJU1Create*/
		},
		/*#{1IM04HNJU1EndCSS*/
		/*}#1IM04HNJU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.updateState=async function(){
		/*#{1IM2RGS6P0Start*/
		let lState,rState;
		if(entryObj.dir){
			txtState.text="";
			txtState.alpha=1;
			return;
		}
		lState=entryObj.leftState;
		rState=entryObj.rightState;
		if(lState==="Same"){
			txtState.text="=";
			txtState.alpha=0.3;
			this.action="Open";
		}else if(lState==="New" || lState==="More"){
			txtState.text="➡️";
			txtState.alpha=1;
			this.action="CopyToRight";
		}else{
			txtState.text="⬅️";
			txtState.alpha=1;
			this.action="CopyToLeft";
		}
		/*}#1IM2RGS6P0Start*/
	};
	/*#{1IM04HNJU1PostCSSVO*/
	/*}#1IM04HNJU1PostCSSVO*/
	cssVO.constructor=PathCompareCenter;
	return cssVO;
};
/*#{1IM04HNJU1ExCodes*/
/*}#1IM04HNJU1ExCodes*/

//----------------------------------------------------------------------------
PathCompareCenter.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IM04HNJU1PreAISpot*/
	/*}#1IM04HNJU1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IM04HNJU1PostAISpot*/
	/*}#1IM04HNJU1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
PathCompareCenter.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"entryObj": {
			"name": "entryObj", "showName": "entryObj", "type": "auto", "key": true, "fixed": true, "initVal": undefined
		}, 
		"node": {"name":"node","showName":"node","type":"auto","key":true,"fixed":true}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","down","over","focus","blur"],
	subContainers:{
	},
	/*#{1IM04HNJU0ExGearInfo*/
	/*}#1IM04HNJU0ExGearInfo*/
};
/*#{1IM04HNJU0EndDoc*/
/*}#1IM04HNJU0EndDoc*/

export default PathCompareCenter;
export{PathCompareCenter};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1IM04HNJU0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IM04HNJU2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "30",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IM04HNJU3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IM04HNJU4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IM04HNJU5",
//			"attrs": {
//				"entryObj": {
//					"type": "auto",
//					"valText": ""
//				},
//				"node": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IM04HNJU6",
//			"attrs": {
//				"focused": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IM04HNJU7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM2RGS6P0",
//					"attrs": {
//						"id": "updateState",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM2RH5B20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM2RH5B21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM2RH5B22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IM04HNJU8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM04JDDC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM04LIK80",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM04JH270",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM04LIK81",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM04JQ3S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM04LIK82",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM04KTDE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM04LIK83",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM04L1JJ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM04LIK84",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IM04HNJU9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1IM04HNJU1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IM04HNJU10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "32",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IM04J40K0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM04LIK85",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0.00]",
//										"border": "[0,1,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IM2RG5PH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2RH5B30",
//													"attrs": {
//														"type": "text",
//														"id": "TxtState",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "-",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IM2RH5B31",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM2RH5B32",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM2RH5B33",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IM04LIK86",
//									"attrs": {
//										"1IM04JQ3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM04O0QI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM04O0QI1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM04JQ3S0",
//											"faceTagName": "over"
//										},
//										"1IM04JH270": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM04O0QI2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM04O0QI3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM04JH270",
//											"faceTagName": "down"
//										},
//										"1IM04KTDE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM04O0QI4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM04O0QI5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM04KTDE0",
//											"faceTagName": "focus"
//										},
//										"1IM04L1JJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM04O0QI6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM04O0QI7",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[255,255,255,0.00]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM04L1JJ0",
//											"faceTagName": "blur"
//										},
//										"1IM04JDDC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1JMKGG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1JMKGG1",
//													"attrs": {
//														"background": "[255,255,255,0.00]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM04JDDC0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IM04LIK87",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM04LIK88",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IM04HNJU11",
//					"attrs": {
//						"1IM04JQ3S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM04O0QI8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM04O0QI9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM04JQ3S0",
//							"faceTagName": "over"
//						},
//						"1IM04JH270": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM04O0QI10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM04O0QI11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM04JH270",
//							"faceTagName": "down"
//						},
//						"1IM04KTDE0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM04O0QI12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM04O0QI13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM04KTDE0",
//							"faceTagName": "focus"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IM04HNJU12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IM04HNJU13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IM04HNJU14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}