//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnSwitch} from "./BtnSwitch.js";
/*#{1HQL6A8E10StartDoc*/
/*}#1HQL6A8E10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLBool=function(box,template,dataObj,property,opts,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxIcon,txtLabel,txtValue,btnSwitch;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let value=(!!dataObj[property])?1:0;
	let pptTemplate=template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value));
	let edit=(!pptTemplate.readOnly) && opts.edit && (box && box.edit);
	let icon=pptTemplate.icon;
	let labelLine=!!opts.labelLine;
	let choices=pptTemplate.choices||["No","Yes"];
	let description=edit?pptTemplate.desc:null;
	let valueGap=choices?3:(opts.labelLine?10:3);
	let menuGap=opts.labelLine?6:3;
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":opts?(opts.lineHeight||25):25,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1F1DNF0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":opts?(opts.lineHeight-3):22,"h":opts?(opts.lineHeight-3):22,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-x",
				"itemsWrap":1,"itemsAlign":1,
				children:[
					{
						"hash":"1HQ1GMNN90",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":labelLine?"100%":"","h":"","minW":opts.labelWidth||0,"minH":"","maxW":"","maxH":"",
						"styleClass":"","color":opts.labelColor,"text":title||(pptTemplate.label?pptTemplate.label:(property+":")),"fontSize":opts?(opts.labelSize||12):14,
						"fontWeight":(opts?(opts.labelBold||false):false)?"bold":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HQ1GNGQ60",
						"type":"text","id":"TxtValue","position":"relative","x":0,"y":0,"w":"","h":"","margin":[opts.labelLine?2:0,0,0,opts.labelLine?6:3],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","color":opts.valueColor,"text":choices[value],"fontSize":opts?(opts.valueSize||16):16,"fontWeight":(opts?(!!opts.valueBold):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"","alignH":2,"flex":(!!opts.valueRightAlign)&&(!opts.edit),
					},
					{
						"hash":"1HQL6KJ2O0",
						"type":BtnSwitch(opts?(Math.max(opts.lineHeight-20,20)):20,!!value),"id":"BtnSwitch","position":"relative","x":0,"y":0,"margin":[0,0,0,valueGap],
						"attached":!!edit,
						/*#{1HQL6KJ2O0Codes*/
						OnCheck(check){
							self.commitEdit(this.checked);
							box._OnEdit && box._OnEdit();
						}
						/*}#1HQL6KJ2O0Codes*/
					},
					{
						"hash":"1HQ1JKTFQ0",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":description,"fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","wrap":true,"attached":!!description,
					}
				],
			},
			{
				"hash":"1I9ATMEK40",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["subFocus"],"attached":!!opts.gridLine,
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get $$property(){
			return property;
		},
		set $$property(p){
			return property=p;
		},
		template:pptTemplate,
		get $$value(){
			return value;
		},
		set $$value(val){
			return self.commitEdit(val);
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
			"error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":cfgColor["error"]
				}
			},"!error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":opts.labelColor
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtValue=self.TxtValue;btnSwitch=self.BtnSwitch;
			/*#{1HQ1EDCKJ1Create*/
			self.postCheck();
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		val=!!val;
		if(pptTemplate.checkValue){
			if(!pptTemplate.checkValue(val)){
				val=value;
			}
		}
		if(val!==value){
			value=val;
			self.updateValue();
		}
		return value;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		value=dataObj[property]?1:0;
		self.updateValue();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		if(txtValue){
			txtValue.text=choices[value?1:0];
		}
		if(btnSwitch){
			btnSwitch.checked=!!value;
		}
		self.postCheck();
	};
	
	//------------------------------------------------------------------------
	cssVO.postCheck=function(){
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	cssVO.constructor=DLBool;
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/

//----------------------------------------------------------------------------
DLBool.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HQ1EDCKJ1PreAISpot*/
	/*}#1HQ1EDCKJ1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HQ1EDCKJ1PostAISpot*/
	/*}#1HQ1EDCKJ1PostAISpot*/
	return exposeVO;
};

/*#{1HQL6A8E10EndDoc*/
/*}#1HQL6A8E10EndDoc*/

export default DLBool;
export{DLBool};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQL6A8E10",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "#{properties:{size:{type:\"int\",label:\"Size\",description:\"This is size\"}}}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "#{size:50}"
//				},
//				"property": {
//					"type": "string",
//					"valText": "size"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 1, edit:1, gridLine:true}"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"value": {
//					"type": "auto",
//					"valText": "#(!!dataObj[property])?1:0"
//				},
//				"pptTemplate": {
//					"type": "auto",
//					"valText": "#template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value))"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "#(!pptTemplate.readOnly) && opts.edit && (box && box.edit)"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#null//appCfg.sharedAssets+\"/inc.svg\"#>pptTemplate.icon"
//				},
//				"labelLine": {
//					"type": "bool",
//					"valText": "#!!opts.labelLine"
//				},
//				"choices": {
//					"type": "auto",
//					"valText": "#pptTemplate.choices||[\"No\",\"Yes\"]"
//				},
//				"description": {
//					"type": "string",
//					"valText": "#edit?pptTemplate.desc:null"
//				},
//				"valueGap": {
//					"type": "int",
//					"valText": "#choices?3:(opts.labelLine?10:3)"
//				},
//				"menuGap": {
//					"type": "int",
//					"valText": "#opts.labelLine?6:3"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VN1I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND0",
//							"attrs": {}
//						}
//					}
//				},
//				"!error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VNIQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "#opts?(opts.lineHeight||25):25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ1F1DNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1F383P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#opts?(opts.lineHeight-3):22",
//										"h": "#opts?(opts.lineHeight-3):22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1F383P1",
//									"attrs": {
//										"1HQ20VN1I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQ2126ND2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ2126ND3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VN1I0",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1F383P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1F383P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GMNN90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GMNN91",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "#labelLine?\"100%\":\"\"",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "#opts.labelWidth||0",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.labelColor",
//														"text": "#title||(pptTemplate.label?pptTemplate.label:(property+\":\"))",
//														"font": "",
//														"fontSize": "#opts?(opts.labelSize||12):14",
//														"bold": "#opts?(opts.labelBold||false):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GMNNA0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND5",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"error\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														},
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#opts.labelColor"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GMNNA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GMNNA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GNGQ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GNGQ61",
//													"attrs": {
//														"type": "text",
//														"id": "TxtValue",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "#[opts.labelLine?2:0,0,0,opts.labelLine?6:3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.valueColor",
//														"text": "#choices[value]",
//														"font": "",
//														"fontSize": "#opts?(opts.valueSize||16):16",
//														"bold": "#opts?(!!opts.valueBold):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true",
//														"flex": "#(!!opts.valueRightAlign)&&(!opts.edit)"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GNGQ62",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GNGQ63",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GNGQ64",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1LFSMBH0",
//											"jaxId": "1HQL6KJ2O0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HQL6KJ2O1",
//													"attrs": {
//														"size": "#opts?(Math.max(opts.lineHeight-20,20)):20",
//														"check": "#!!value"
//													}
//												},
//												"properties": {
//													"jaxId": "1HQL6KJ2O2",
//													"attrs": {
//														"type": "#null#>BtnSwitch(opts?(Math.max(opts.lineHeight-20,20)):20,!!value)",
//														"id": "BtnSwitch",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "#[0,0,0,valueGap]",
//														"attach": "#!!edit"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQL6KJ2P0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQL7II860",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQL7II861",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQL6KJ2P1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQL6KJ2P2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HQL6KJ2P3",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1JKTFQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1JO33U0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#description",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!description"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1JO33U1",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1JO33U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1JO33U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {
//										"1HQ20VN1I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQ2126ND16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ2126NE0",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VN1I0",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I9ATMEK40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9ATMEK41",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"subFocus\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!opts.gridLine"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I9ATMEK50",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I9ATMEK51",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9ATMEK52",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {
//						"1HQ20VN1I0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQ2126NE1",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ2126NE2",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQ20VN1I0",
//							"faceTagName": "error"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}