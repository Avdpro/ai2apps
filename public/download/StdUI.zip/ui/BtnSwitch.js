//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LFSMBH0StartDoc*/
/*}#1H1LFSMBH0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnSwitch=function(size,check){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LFSMBH1LocalVals*/
	/*}#1H1LFSMBH1LocalVals*/
	
	/*#{1H1LFSMBH1PreState*/
	/*}#1H1LFSMBH1PreState*/
	state={
		"checked":check,"color":cfgColor.primary,"lineColor":cfgColor["lineBody"],
		/*#{1H1LFSMBH6ExState*/
		/*}#1H1LFSMBH6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LFSMBH1PostState*/
	/*}#1H1LFSMBH1PostState*/
	cssVO={
		"hash":"1H1LFSMBH1",nameHost:true,
		"type":"button","x":117,"y":160,"w":size*1.7,"h":size,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H1LFTSJC0",
				"type":"box","id":"BoxBase","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.checked?state.color:[180,180,180,1]),state),
				"border":1,"borderColor":$P(()=>(state.lineColor),state),"corner":100,"contentLayout":"flex-x","subAlign":$P(()=>(state.checked?2:0),state),
				children:[
					{
						"hash":"1H1LFV0AV0",
						"type":"box","id":"BoxBtn","position":"relative","x":0,"y":"50%","w":size-2,"h":size-2,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor.body,"border":1,"borderColor":state.lineColor,"corner":100,
					}
				],
			}
		],
		get $$checked(){return state["checked"]},
		set $$checked(v){
			state["checked"]=v;
			/*#{1H1LFSMBH1Setchecked*/
			/*}#1H1LFSMBH1Setchecked*/
		},
		get $$color(){return state["color"]},
		set $$color(v){
			state["color"]=v;
			/*#{1H1LFSMBH1Setcolor*/
			/*}#1H1LFSMBH1Setcolor*/
		},
		get $$lineColor(){return state["lineColor"]},
		set $$lineColor(v){
			state["lineColor"]=v;
			/*#{1H1LFSMBH1SetlineColor*/
			/*}#1H1LFSMBH1SetlineColor*/
		},
		/*#{1H1LFSMBH1ExtraCSS*/
		/*}#1H1LFSMBH1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":cfgColor.body
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":[...cfgColor.primary,80]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":cfgColor.primary
				}
			},"gray":{
				"#self":{
					"alpha":0.6
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1LFSMBH1Create*/
			/*}#1H1LFSMBH1Create*/
		},
		/*#{1H1LFSMBH1EndCSS*/
		/*}#1H1LFSMBH1EndCSS*/
	};
	/*#{1H1LFSMBH1PostCSSVO*/
	cssVO.OnClick=function(){
		state.checked=!state.checked;
		if(this.OnCheck){
			this.OnCheck(state.checked);
		}
	};
	/*}#1H1LFSMBH1PostCSSVO*/
	return cssVO;
};
/*#{1H1LFSMBH1ExCodes*/
/*}#1H1LFSMBH1ExCodes*/

BtnSwitch.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("开关按钮"):("Switch")),icon:"btn_switch.svg",previewImg:false,
	fixPose:false,initW:20,initH:32,
	"desc":"Switch button",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20
		}, 
		"check": {
			"name": "check", "showName": "check", "type": "bool", "key": true, "fixed": true, "initVal": false
		}
	},
	state:{
		checked:{name:"checked",type:"bool",initVal:false},
		color:{name:"color",type:"colorRGBA",initVal:[13,110,253,1]},
		lineColor:{name:"lineColor",type:"colorRGBA",initVal:[0,0,0,1]}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1LFSMBH0ExGearInfo*/
	/*}#1H1LFSMBH0ExGearInfo*/
};
/*#{1H1LFSMBH0EndDoc*/
/*}#1H1LFSMBH0EndDoc*/

export default BtnSwitch;
export{BtnSwitch};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1LFSMBH0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1LFSMBH2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1LFSMBH3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8GLKMLR0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1LFSMBH4",
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "20"
//				},
//				"check": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1LFSMBH5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1LFSMBH6",
//			"attrs": {
//				"checked": {
//					"type": "bool",
//					"valText": "#check"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.primary"
//				},
//				"lineColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"lineBody\"]"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Switch",
//			"localize": {
//				"EN": "Switch",
//				"CN": "开关按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_switch.svg",
//		"gearW": "20",
//		"gearH": "32",
//		"gearCatalog": "Buttons",
//		"description": "Switch button",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1LFSMBH7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LGD5EN1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LGD5EN3",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LGD5EN5",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN6",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1LGD5EN7",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAQBNQ0E0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1LFSMBH1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1LFSMBH8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "117",
//						"y": "160",
//						"w": "#size*1.7",
//						"h": "#size",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1LFTSJC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LGD5EN8",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBase",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "${state.checked?state.color:[180,180,180,1]},state",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "${state.lineColor},state",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"subAlign": "${state.checked?2:0},state"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H1LFV0AV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LGD5EN9",
//													"attrs": {
//														"type": "box",
//														"id": "BoxBtn",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"w": "#size-2",
//														"h": "#size-2",
//														"anchorH": "Left",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.body",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#state.lineColor",
//														"corner": "100",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1LGD5EN10",
//													"attrs": {
//														"1H1LGD5EN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LGL3RB1",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor.body"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN0",
//															"faceTagName": "up"
//														},
//														"1H1LGD5EN2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LGL3RB3",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#[...cfgColor.primary,80]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN2",
//															"faceTagName": "over"
//														},
//														"1H1LGD5EN4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LGL3RB5",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor.primary"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN4",
//															"faceTagName": "down"
//														},
//														"1H1LGD5EN6": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H1LGL3RB7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN6",
//															"faceTagName": "gray"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1LGD5EN11",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H1LGD5EN12",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1LGD5EN13",
//									"attrs": {
//										"1H1LGD5EN2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LGL3RB9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN2",
//											"faceTagName": "over"
//										},
//										"1H1LGD5EN4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LGL3RB11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN4",
//											"faceTagName": "down"
//										},
//										"1H1LGD5EN6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1LGL3RB13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1LGD5EN14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1LGD5EN15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1LFSMBH9",
//					"attrs": {
//						"1H1LGD5EN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB14",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LGL3RB15",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN0",
//							"faceTagName": "up"
//						},
//						"1H1LGD5EN2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LGL3RB17",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN2",
//							"faceTagName": "over"
//						},
//						"1H1LGD5EN4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LGL3RB19",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN4",
//							"faceTagName": "down"
//						},
//						"1H1LGD5EN6": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1LGL3RB21",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.6",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN6",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1LFSMBH10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1LFSMBH11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LFSMBH12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "checked"
//				},
//				{
//					"type": "string",
//					"valText": "color"
//				},
//				{
//					"type": "string",
//					"valText": "lineColor"
//				}
//			]
//		}
//	}
//}