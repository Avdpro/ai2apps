//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LFSMBH0StartDoc*/
/*}#1H1LFSMBH0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnSwitch=function(size,check){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LFSMBH1LocalVals*/
	/*}#1H1LFSMBH1LocalVals*/
	
	/*#{1H1LFSMBH1PreState*/
	/*}#1H1LFSMBH1PreState*/
	state={
		"checked":check,"color":cfgColor.primary,"lineColor":cfgColor["lineBody"],
		/*#{1H1LFSMBH6ExState*/
		/*}#1H1LFSMBH6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LFSMBH1PostState*/
	/*}#1H1LFSMBH1PostState*/
	cssVO={
		"hash":"1H1LFSMBH1",nameHost:true,
		"type":"button","x":117,"y":160,"w":size*1.7,"h":size,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H1LFTSJC0",
				"type":"box","id":"BoxBase","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.checked?state.color:[0,0,0,0]),state),
				"border":1,"borderColor":$P(()=>(state.lineColor),state),"corner":100,"contentLayout":"flex-x","subAlign":$P(()=>(state.checked?2:0),state),
				children:[
					{
						"hash":"1H1LFV0AV0",
						"type":"box","id":"BoxBtn","position":"relative","x":0,"y":"50%","w":size-4,"h":size-4,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.fontBody,"corner":100,
					}
				],
			}
		],
		get $$checked(){return state["checked"]},
		set $$checked(v){
			state["checked"]=v;
			/*#{1H1LFSMBH1Setchecked*/
			/*}#1H1LFSMBH1Setchecked*/
		},
		get $$color(){return state["color"]},
		set $$color(v){
			state["color"]=v;
			/*#{1H1LFSMBH1Setcolor*/
			/*}#1H1LFSMBH1Setcolor*/
		},
		get $$lineColor(){return state["lineColor"]},
		set $$lineColor(v){
			state["lineColor"]=v;
			/*#{1H1LFSMBH1SetlineColor*/
			/*}#1H1LFSMBH1SetlineColor*/
		},
		/*#{1H1LFSMBH1ExtraCSS*/
		/*}#1H1LFSMBH1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":cfgColor.body
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":[...cfgColor.primary,80]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxBtn*/"#1H1LFV0AV0":{
					"background":cfgColor.primary
				}
			},"gray":{
				"#self":{
					"alpha":0.6
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1LFSMBH1Create*/
			/*}#1H1LFSMBH1Create*/
		},
		/*#{1H1LFSMBH1EndCSS*/
		/*}#1H1LFSMBH1EndCSS*/
	};
	/*#{1H1LFSMBH1PostCSSVO*/
	cssVO.OnClick=function(){
		state.checked=!state.checked;
		if(this.OnCheck){
			this.OnCheck(state.checked);
		}
	};
	/*}#1H1LFSMBH1PostCSSVO*/
	return cssVO;
};
/*#{1H1LFSMBH1ExCodes*/
/*}#1H1LFSMBH1ExCodes*/

BtnSwitch.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("开关按钮"):("Switch")),icon:"btn_switch.svg",previewImg:false,
	fixPose:false,initW:20,initH:32,
	"desc":"Switch button",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20
		}, 
		"check": {
			"name": "check", "showName": "check", "type": "bool", "key": true, "fixed": true, "initVal": false
		}
	},
	state:{
		checked:{name:"checked",type:"bool",initVal:false},
		color:{name:"color",type:"colorRGBA",initVal:[13,110,253,1]},
		lineColor:{name:"lineColor",type:"colorRGBA",initVal:[0,0,0,1]}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1LFSMBH0ExGearInfo*/
	/*}#1H1LFSMBH0ExGearInfo*/
};
export default BtnSwitch;
export{BtnSwitch};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1LFSMBH0",
//	"editVersion": 152,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1LFSMBH2",
//			"editVersion": 28,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1LFSMBH3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8GLKMLR0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LFSMBH4",
//			"editVersion": 60,
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "20"
//				},
//				"check": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LFSMBH5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1LFSMBH6",
//			"editVersion": 68,
//			"attrs": {
//				"checked": {
//					"type": "bool",
//					"valText": "#check"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.primary"
//				},
//				"lineColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"lineBody\"]"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Switch",
//			"localize": {
//				"EN": "Switch",
//				"CN": "开关按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_switch.svg",
//		"gearW": "20",
//		"gearH": "32",
//		"gearCatalog": "Buttons",
//		"description": "Switch button",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1LFSMBH7",
//			"editVersion": 8,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LGD5EN1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN2",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LGD5EN3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN4",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LGD5EN5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LGD5EN6",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LGD5EN7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAQBNQ0E0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1LFSMBH1",
//			"editVersion": 30,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1LFSMBH8",
//					"editVersion": 122,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "117",
//						"y": "160",
//						"w": "#size*1.7",
//						"h": "#size",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1LFTSJC0",
//							"editVersion": 24,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LGD5EN8",
//									"editVersion": 170,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBase",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "${state.checked?state.color:[0,0,0,0]},state",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "${state.lineColor},state",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"subAlign": "${state.checked?2:0},state"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H1LFV0AV0",
//											"editVersion": 35,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LGD5EN9",
//													"editVersion": 140,
//													"attrs": {
//														"type": "box",
//														"id": "BoxBtn",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"w": "#size-4",
//														"h": "#size-4",
//														"anchorH": "Left",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.body",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor.fontBody",
//														"corner": "100",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1LGD5EN10",
//													"editVersion": 8,
//													"attrs": {
//														"1H1LGD5EN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LGL3RB1",
//																	"editVersion": 8,
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor.body"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN0",
//															"faceTagName": "up"
//														},
//														"1H1LGD5EN2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LGL3RB3",
//																	"editVersion": 8,
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#[...cfgColor.primary,80]"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN2",
//															"faceTagName": "over"
//														},
//														"1H1LGD5EN4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LGL3RB5",
//																	"editVersion": 14,
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor.primary"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN4",
//															"faceTagName": "down"
//														},
//														"1H1LGD5EN6": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LGL3RB6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LGL3RB7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LGD5EN6",
//															"faceTagName": "gray"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1LGD5EN11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1LGD5EN12",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1LGD5EN13",
//									"editVersion": 10,
//									"attrs": {
//										"1H1LGD5EN2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LGL3RB9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN2",
//											"faceTagName": "over"
//										},
//										"1H1LGD5EN4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LGL3RB11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN4",
//											"faceTagName": "down"
//										},
//										"1H1LGD5EN6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LGL3RB12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LGL3RB13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LGD5EN6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1LGD5EN14",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1LGD5EN15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1LFSMBH9",
//					"editVersion": 8,
//					"attrs": {
//						"1H1LGD5EN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB14",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LGL3RB15",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN0",
//							"faceTagName": "up"
//						},
//						"1H1LGD5EN2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB16",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LGL3RB17",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN2",
//							"faceTagName": "over"
//						},
//						"1H1LGD5EN4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB18",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LGL3RB19",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN4",
//							"faceTagName": "down"
//						},
//						"1H1LGD5EN6": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LGL3RB20",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LGL3RB21",
//									"editVersion": 8,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.6",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LGD5EN6",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1LFSMBH10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1LFSMBH11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LFSMBH12",
//			"editVersion": 104,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "checked"
//				},
//				{
//					"type": "string",
//					"valText": "color"
//				},
//				{
//					"type": "string",
//					"valText": "lineColor"
//				}
//			]
//		}
//	}
//}