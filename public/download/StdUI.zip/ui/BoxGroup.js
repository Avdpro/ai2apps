//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnGroup} from "./BtnGroup.js";
/*#{1I9Q1LH0R0StartDoc*/
import {BtnObject} from "./BtnObject.js";
/*}#1I9Q1LH0R0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxGroup=function(text,icon,objects,options){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnGroup,boxItems;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I9Q1LH0S0LocalVals*/
	let hudsReady=false;
	/*}#1I9Q1LH0S0LocalVals*/
	
	/*#{1I9Q1LH0S0PreState*/
	objects=objects||[];
	/*}#1I9Q1LH0S0PreState*/
	state={
		"isExpand":false,"objects":objects,"huds":[],
		/*#{1I9Q1LH0S6ExState*/
		/*}#1I9Q1LH0S6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I9Q1LH0S0PostState*/
	/*}#1I9Q1LH0S0PostState*/
	cssVO={
		"hash":"1I9Q1LH0S0",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1I9Q1OJ710",
				"type":BtnGroup({text:text,icon:icon},{"fontSize":options.fontSize,"height":options.height,"iconSize":options.iconSize,"color":options.color,"checkBox":false,"indentSize":15,"btnBG":options.btnBG}),
				"id":"BtnGroup","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1I9Q1P47P0",
				"type":"hud","id":"BoxItems","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[0,0,0,options.indentSize],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
			}
		],
		get $$isExpand(){return state["isExpand"]},
		set $$isExpand(v){
			state["isExpand"]=v;
			/*#{1I9Q1LH0S0SetisExpand*/
			/*}#1I9Q1LH0S0SetisExpand*/
		},
		get $$objects(){return state["objects"]},
		set $$objects(v){
			state["objects"]=v;
			/*#{1I9Q1LH0S0Setobjects*/
			/*}#1I9Q1LH0S0Setobjects*/
		},
		get $$huds(){return state["huds"]},
		set $$huds(v){
			state["huds"]=v;
			/*#{1I9Q1LH0S0Sethuds*/
			/*}#1I9Q1LH0S0Sethuds*/
		},
		/*#{1I9Q1LH0S0ExtraCSS*/
		/*}#1I9Q1LH0S0ExtraCSS*/
		faces:{
			"expand":{
				/*BtnGroup*/"#1I9Q1OJ710":{
					"face":"expand"
				},
				/*BoxItems*/"#1I9Q1P47P0":{
					"display":1
				},
				/*#{1I9Q7BCS20Code*/
				$(){
					state.isExpand=true;
				}
				/*}#1I9Q7BCS20Code*/
			},"collapse":{
				/*BtnGroup*/"#1I9Q1OJ710":{
					"face":"collapse"
				},
				/*BoxItems*/"#1I9Q1P47P0":{
					"display":0
				},
				/*#{1I9Q7BIN70Code*/
				$(){
					state.isExpand=false;
				}
				/*}#1I9Q7BIN70Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnGroup=self.BtnGroup;boxItems=self.BoxItems;
			/*#{1I9Q1LH0S0Create*/
			if(options.autoExpand){
				self.expand();
			}
			/*}#1I9Q1LH0S0Create*/
		},
		/*#{1I9Q1LH0S0EndCSS*/
		/*}#1I9Q1LH0S0EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.genHuds=async function(){
		/*#{1I9Q47NKU0Start*/
		let defClass,list,obj;
		boxItems.clearChildren();
		state.huds.splice(0);
		if(options.getObjects){
			objects=(await options.getObjects())||[];
			state.objects=objects;
		}
		defClass=options.itemDef||BtnObject;
		list=state.objects;
		for(obj of list){
			state.huds.push(boxItems.appendNewChild({
				type:defClass(obj),x:0,y:0,position:"relative",object:obj
			}));
		}
		hudsReady=true;
		/*}#1I9Q47NKU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.expand=async function(){
		/*#{1I9Q46OD80Start*/
		if(options.dynamic|| !hudsReady){
			await self.genHuds();
		}
		btnGroup.showFace("expand");
		self.showFace("expand");
		/*}#1I9Q46OD80Start*/
	};
	//------------------------------------------------------------------------
	cssVO.collapse=function(){
		/*#{1I9Q46V640Start*/
		btnGroup.showFace("collapse");
		self.showFace("collapse");
		/*}#1I9Q46V640Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addObject=async function(object){
		/*#{1I9Q5G4950Start*/
		let defClass;
		state.objects.push(object);
		if(hudsReady){
			defClass=options.itemDef||BtnObject;
			state.huds.push(boxItems.appendNewChild({
				type:defClass(object),x:0,y:0,position:"relative",object:object
			}));
		}
		/*}#1I9Q5G4950Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setObjects=async function(objs){
		/*#{1I9Q5GCOP0Start*/
		objs=objs||[];
		state.objects.splice(0);
		state.objects.splice(0,0,...objs);
		hudsReady=false;
		if(btnGroup.isExpand||options.autoExpand){
			self.collapse();
			await self.expand();			
		}
		/*}#1I9Q5GCOP0Start*/
	};
	/*#{1I9Q1LH0S0PostCSSVO*/
	/*}#1I9Q1LH0S0PostCSSVO*/
	return cssVO;
};
/*#{1I9Q1LH0S0ExCodes*/
/*}#1I9Q1LH0S0ExCodes*/

BoxGroup.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"Group",icon:"folder.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Group", "localizable": true
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/folder.svg", "initValText": "#appCfg.sharedAssets+\"/folder.svg\""
		}, 
		"objects": {
			"name": "objects", "showName": "objects", "type": "auto", "key": true, "fixed": true, 
			"initVal": [], "initValText": "#[]"
		}, 
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 14, "initValText": "#txtSize.smallPlus"
					}, 
					"height": {
						"name": "height", "showName": "height", "type": "int", "key": true, "fixed": true, "initVal": 24
					}, 
					"iconSize": {
						"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 22
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1]
					}, 
					"autoExpand": {
						"name": "autoExpand", "showName": "autoExpand", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"dynamic": {
						"name": "dynamic", "showName": "dynamic", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"indentSize": {
						"name": "indentSize", "showName": "indentSize", "type": "int", "key": true, "fixed": true, "initVal": 15
					}, 
					"btnBG": {
						"name": "btnBG", "showName": "btnBG", "type": "colorRGBA", "key": true, "fixed": true, "initVal": "linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))", 
						"initValText": "#cfgColor[\"subFocus\"]"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		isExpand:{name:"isExpand",type:"bool",initVal:false},
		objects:{name:"objects",type:"auto",initVal:[]},
		huds:{name:"huds",type:"auto",initVal:[]}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","subAlign","itemsAlign","itemsWrap","clip","uiEvent","alpha","rotate","scale","filter","cursor","zIndex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:["expand","collapse"],
	subContainers:{
	},
	/*#{1I9Q1LH0R0ExGearInfo*/
	/*}#1I9Q1LH0R0ExGearInfo*/
};
/*#{1I9Q1LH0R0EndDoc*/
/*}#1I9Q1LH0R0EndDoc*/

export default BoxGroup;
export{BoxGroup};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I9Q1LH0R0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I9Q1LH0S1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I9Q1LH0S2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I9Q1LH0S3",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I9Q1LH0S4",
//			"attrs": {
//				"text": {
//					"type": "string",
//					"valText": "Group",
//					"localizable": true
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/folder.svg\""
//				},
//				"objects": {
//					"type": "auto",
//					"valText": "#[]"
//				},
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I9Q2ECII0",
//					"attrs": {
//						"fontSize": {
//							"type": "int",
//							"valText": "#txtSize.smallPlus"
//						},
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"iconSize": {
//							"type": "int",
//							"valText": "22"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "[0,0,0,1.00]"
//						},
//						"autoExpand": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"dynamic": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						},
//						"btnBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"subFocus\"]"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I9Q1LH0S5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I9Q1LH0S6",
//			"attrs": {
//				"isExpand": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"objects": {
//					"type": "auto",
//					"valText": "#objects"
//				},
//				"huds": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9Q47NKU0",
//					"attrs": {
//						"id": "genHuds",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "245",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9Q48FV60",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9Q48FV61",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9Q48FV62",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9Q46OD80",
//					"attrs": {
//						"id": "expand",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "80",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9Q47ALA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9Q47ALA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9Q47ALA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9Q46V640",
//					"attrs": {
//						"id": "collapse",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9Q47ALA3",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9Q47ALA4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9Q47ALA5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9Q5G4950",
//					"attrs": {
//						"id": "addObject",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "330",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9Q5H1LI0",
//							"attrs": {
//								"object": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9Q5H1LI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9Q5H1LI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I9Q5GCOP0",
//					"attrs": {
//						"id": "setObjects",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "415",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I9Q5H1LI3",
//							"attrs": {
//								"objs": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I9Q5H1LI4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I9Q5H1LI5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "Group",
//		"gearIcon": "folder.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I9Q1LH0S7",
//			"attrs": {
//				"expand": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I9Q7BCS20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I9Q7D3KB0",
//							"attrs": {}
//						}
//					}
//				},
//				"collapse": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I9Q7BIN70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I9Q7D3KB1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I9Q1LH0S8",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I9Q1LH0S0",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I9Q1LH0S9",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1I9Q06C5B0",
//							"jaxId": "1I9Q1OJ710",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I9Q1PKU10",
//									"attrs": {
//										"entryObj": "#{text:text,icon:icon}",
//										"options": {
//											"jaxId": "1I9Q1PKU11",
//											"attrs": {
//												"fontSize": "#options.fontSize",
//												"height": "#options.height",
//												"iconSize": "#options.iconSize",
//												"color": "#options.color",
//												"checkBox": "false",
//												"indentSize": "15",
//												"btnBG": "#options.btnBG"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1I9Q1PKU12",
//									"attrs": {
//										"type": "#null#>BtnGroup({text:text,icon:icon},{\"fontSize\":options.fontSize,\"height\":options.height,\"iconSize\":options.iconSize,\"color\":options.color,\"checkBox\":false,\"indentSize\":15,\"btnBG\":options.btnBG})",
//										"id": "BtnGroup",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I9Q1PKU13",
//									"attrs": {
//										"1I9Q7BCS20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q7D3KB2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q7D3KB3",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"expand\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9Q7BCS20",
//											"faceTagName": "expand"
//										},
//										"1I9Q7BIN70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q7D3KB4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q7D3KB5",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"collapse\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9Q7BIN70",
//											"faceTagName": "collapse"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I9Q1PKU14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9Q1PKU15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1I9Q1PKU16",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I9Q1P47P0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9Q1PKU17",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxItems",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#[0,0,0,options.indentSize]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I9Q1PKU18",
//									"attrs": {
//										"1I9Q7BCS20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q7D3KB6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q7D3KB7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9Q7BCS20",
//											"faceTagName": "expand"
//										},
//										"1I9Q7BIN70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9Q7D3KB8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9Q7D3KB9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I9Q7BIN70",
//											"faceTagName": "collapse"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I9Q1PKU19",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9Q1PKU110",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I9Q1LH0S10",
//					"attrs": {
//						"1I9Q7BCS20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9Q7D3KB10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9Q7D3KB11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I9Q7BCS20",
//							"faceTagName": "expand"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I9Q1LH0S11",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I9Q1LH0S12",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I9Q1LH0S13",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "true",
//				"itemsAlign": "true",
//				"itemsWrap": "true",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "isExpand"
//				},
//				{
//					"type": "string",
//					"valText": "objects"
//				},
//				{
//					"type": "string",
//					"valText": "huds"
//				}
//			]
//		}
//	}
//}