//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LSJKOO0StartDoc*/
/*}#1H1LSJKOO0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxRange=function(value,minVal,maxVal){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnDrag,boxBtn;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LSJKOO1LocalVals*/
	/*}#1H1LSJKOO1LocalVals*/
	
	/*#{1H1LSJKOO1PreState*/
	/*}#1H1LSJKOO1PreState*/
	state={
		"buttonSize":20,"barSize":8,"value":value,"min":minVal,"max":maxVal,"step":1,"valColor":cfgColor.primary,"enable":true,
		/*#{1H1LSJKOO6ExState*/
		/*}#1H1LSJKOO6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LSJKOO1PostState*/
	let dragOrgX,maxDragX;
	/*}#1H1LSJKOO1PostState*/
	cssVO={
		"hash":"1H1LSJKOO1",nameHost:true,
		"type":"hud","x":125,"y":182,"w":100,"h":20,"alpha":$P(()=>(state.enable?1:0.6),state),"styleClass":"",
		"trackSize":true,
		children:[
			{
				"hash":"1H1LSR12R0",
				"type":"box","id":"BoxTrack","x":5,"y":"50%","w":">calc(100% - 10px)","h":$P(()=>(state.barSize),state),"anchorY":1,"styleClass":"","background":[0,0,0,0],
				"border":1,"borderColor":cfgColor.fontBody,"corner":100,
				children:[
					{
						"hash":"1H1LTEIBS0",
						"type":"box","id":"BoxValue","x":0,"y":0,"w":$P(()=>(((state.value-state.min)/(state.max-state.min)*100)+"%"),state),"h":"100%","styleClass":"",
						"background":$P(()=>(state.valColor),state),"corner":[100,0,0,100],
						"OnClick":function(event){
							/*#{1H2E5TECE0FunctionBody*/
							self.stepValue(1);
							/*}#1H2E5TECE0FunctionBody*/
						},
					}
				],
				"OnClick":function(event){
					/*#{1H2E5T5950FunctionBody*/
					self.stepValue(-1);
					/*}#1H2E5T5950FunctionBody*/
				},
			},
			{
				"hash":"1H2E6IVF70",
				"type":"button","id":"BtnDrag","x":$P(()=>(`(FW-${state.buttonSize})*${(state.value-state.min)/(state.max-state.min)}`),state),"y":"50%","w":$P(()=>(state.buttonSize),state),
				"h":$P(()=>(state.buttonSize),state),"anchorY":1,"cursor":"pointer","styleClass":"","drag":2,
				children:[
					{
						"hash":"1H2E6L0B10",
						"type":"box","id":"BoxBtn","x":0,"y":0,"w":$P(()=>(state.buttonSize),state),"h":$P(()=>(state.buttonSize),state),"uiEvent":-1,"styleClass":"","background":cfgColor.body,
						"border":1,"borderColor":cfgColor.fontBody,"corner":100,
					}
				],
				/*#{1H2E6IVF70Codes*/
				OnDragStart(evt){
					dragOrgX=btnDrag.x;
					maxDragX=self.w-btnDrag.w-20;
				},
				OnDrag(evt,dx,dy){
					let x=dragOrgX+dx;
					let value,valText;
					x=x<0?0:x;
					x=x>maxDragX?maxDragX:x;
					//btnDrag.x=x;
					value=x/maxDragX*(state.max-state.min)+state.min;
					//filter value:
					state.value=value;
					if(state.digit>=0){
						valText=value.toFixed(state.digit);
						value=parseFloat(valText);
					}else{
						valText=""+value;
					}
					if(self.OnChange){
						self.OnChange(value,valText);
					}
				},
				OnDragEnd(evt,dx,dy){
					let x=dragOrgX+dx;
					let value,valText;
					x=x<0?0:x;
					x=x>maxDragX?maxDragX:x;
					value=x/maxDragX*(state.max-state.min)+state.min;
					//filter value:
					state.value=value;
					if(state.digit>=0){
						valText=value.toFixed(state.digit);
						value=parseFloat(valText);
					}else{
						valText=""+value;
					}
					if(self.OnChange){
						self.OnChange(value,valText);
					}
				}
				/*}#1H2E6IVF70Codes*/
			}
		],
		get $$value(){return state["value"]},
		set $$value(v){
			state["value"]=v;
			/*#{1H1LSJKOO1Setvalue*/
			/*}#1H1LSJKOO1Setvalue*/
		},
		get $$min(){return state["min"]},
		set $$min(v){
			state["min"]=v;
			/*#{1H1LSJKOO1Setmin*/
			/*}#1H1LSJKOO1Setmin*/
		},
		get $$max(){return state["max"]},
		set $$max(v){
			state["max"]=v;
			/*#{1H1LSJKOO1Setmax*/
			/*}#1H1LSJKOO1Setmax*/
		},
		get $$step(){return state["step"]},
		set $$step(v){
			state["step"]=v;
			/*#{1H1LSJKOO1Setstep*/
			/*}#1H1LSJKOO1Setstep*/
		},
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LSJKOO1Setenable*/
			/*}#1H1LSJKOO1Setenable*/
		},
		get $$barSize(){return state["barSize"]},
		set $$barSize(v){
			state["barSize"]=v;
			/*#{1H1LSJKOO1SetbarSize*/
			/*}#1H1LSJKOO1SetbarSize*/
		},
		get $$buttonSize(){return state["buttonSize"]},
		set $$buttonSize(v){
			state["buttonSize"]=v;
			/*#{1H1LSJKOO1SetbuttonSize*/
			/*}#1H1LSJKOO1SetbuttonSize*/
		},
		get $$valColor(){return state["valColor"]},
		set $$valColor(v){
			state["valColor"]=v;
			/*#{1H1LSJKOO1SetvalColor*/
			/*}#1H1LSJKOO1SetvalColor*/
		},
		/*#{1H1LSJKOO1ExtraCSS*/
		/*}#1H1LSJKOO1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnDrag=self.BtnDrag;boxBtn=self.BoxBtn;
			/*#{1H1LSJKOO1Create*/
			/*}#1H1LSJKOO1Create*/
		},
		/*#{1H1LSJKOO1EndCSS*/
		/*}#1H1LSJKOO1EndCSS*/
	};
	/*#{1H1LSJKOO1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.stepValue=function(dir){
		let value,valText;
		value=state.value;
		if(dir<0){
			value-=state.step;
		}else{
			value+=state.step;
		}
		value=value<state.min?state.min:value;
		value=value>state.max?state.max:value;
		state.value=value;
		if(state.digit>=0){
			valText=value.toFixed(state.digit);
			value=parseFloat(valText);
		}else{
			valText=""+value;
		}
		if(self.OnChange){
			self.OnChange(value,valText);
		}
		
	};
	
	//------------------------------------------------------------------------
	cssVO.getValText=function(){
		let value;
		value=state.value;
		if(state.digit>=0){
			return value.toFixed(state.digit);
		}
		return ""+value;
	};
	/*}#1H1LSJKOO1PostCSSVO*/
	return cssVO;
};
/*#{1H1LSJKOO1ExCodes*/
/*}#1H1LSJKOO1ExCodes*/

BoxRange.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("滑动值"):("Value Bar")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	"desc":"Draggable value bar",
	catalog:"Inputs",
	args: {
		"value": {
			"name": "value", "showName": "value", "type": "number", "key": true, "fixed": true, "initVal": 100
		}, 
		"minVal": {
			"name": "minVal", "showName": "minVal", "type": "number", "key": true, "fixed": true, "initVal": 0
		}, 
		"maxVal": {
			"name": "maxVal", "showName": "maxVal", "type": "number", "key": true, "fixed": true, "initVal": 100
		}
	},
	state:{
		value:{name:"value",type:"number",initVal:100},
		min:{name:"min",type:"number",initVal:0},
		max:{name:"max",type:"number",initVal:100},
		step:{name:"step",type:"number",initVal:1},
		enable:{name:"enable",type:"bool",initVal:true},
		barSize:{name:"barSize",type:"int",initVal:8},
		buttonSize:{name:"buttonSize",type:"int",initVal:20},
		valColor:{name:"valColor",type:"colorRGBA",initVal:[13,110,253,1]}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","attach"],
	faces:[],
	subContainers:{
	},
	/*#{1H1LSJKOO0ExGearInfo*/
	/*}#1H1LSJKOO0ExGearInfo*/
};
export default BoxRange;
export{BoxRange};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H1LSJKOO0",
//	"editVersion": 137,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1LSJKOO2",
//			"editVersion": 16,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1LSJKOO3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8GMK1QS0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LSJKOO4",
//			"editVersion": 50,
//			"attrs": {
//				"value": {
//					"type": "number",
//					"valText": "100"
//				},
//				"minVal": {
//					"type": "number",
//					"valText": "0"
//				},
//				"maxVal": {
//					"type": "number",
//					"valText": "100"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LSJKOO5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1LSJKOO6",
//			"editVersion": 80,
//			"attrs": {
//				"buttonSize": {
//					"type": "int",
//					"valText": "20"
//				},
//				"barSize": {
//					"type": "int",
//					"valText": "8"
//				},
//				"value": {
//					"type": "number",
//					"valText": "#value"
//				},
//				"min": {
//					"type": "number",
//					"valText": "#minVal"
//				},
//				"max": {
//					"type": "number",
//					"valText": "#maxVal"
//				},
//				"step": {
//					"type": "number",
//					"valText": "1"
//				},
//				"valColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.primary"
//				},
//				"enable": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Value Bar",
//			"localize": {
//				"EN": "Value Bar",
//				"CN": "滑动值"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Inputs",
//		"description": "Draggable value bar",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1LSJKOO7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1LSJKOO1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1LSJKOO8",
//					"editVersion": 136,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "125",
//						"y": "182",
//						"w": "100",
//						"h": "20",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "${state.enable?1:0.6},state",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1LSR12R0",
//							"editVersion": 23,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LU2FHR0",
//									"editVersion": 200,
//									"attrs": {
//										"type": "box",
//										"id": "BoxTrack",
//										"position": "Absolute",
//										"x": "5",
//										"y": "50%",
//										"w": "100%-10",
//										"h": "${state.barSize},state",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontBody",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H1LTEIBS0",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LU2FHR1",
//													"editVersion": 136,
//													"attrs": {
//														"type": "box",
//														"id": "BoxValue",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "${((state.value-state.min)/(state.max-state.min)*100)+\"%\"},state",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "${state.valColor},state",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "[100,0,0,100]",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1LU2FHR2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1LU2FHR3",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H2E5TECE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H2E5UPMI0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1LU2FHR4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1LU2FHR5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1LU2FHR6",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H2E5T5950",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H2E5UPMI1",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1LU2FHR7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "button",
//							"jaxId": "1H2E6IVF70",
//							"editVersion": 28,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2E6Q85N0",
//									"editVersion": 130,
//									"attrs": {
//										"type": "button",
//										"id": "BtnDrag",
//										"position": "Absolute",
//										"x": "${`(FW-${state.buttonSize})*${(state.value-state.min)/(state.max-state.min)}`},state",
//										"y": "50%",
//										"w": "${state.buttonSize},state",
//										"h": "${state.buttonSize},state",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "pointer",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"enable": "true",
//										"drag": "Pointer down"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H2E6L0B10",
//											"editVersion": 31,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2E6L0B11",
//													"editVersion": 216,
//													"attrs": {
//														"type": "box",
//														"id": "BoxBtn",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "${state.buttonSize},state",
//														"h": "${state.buttonSize},state",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.body",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor.fontBody",
//														"corner": "100",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2E6L0B12",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2E6L0B13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2E6L0B14",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2E6Q85N1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2E6Q85N2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2E6Q85N3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1LSJKOO9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1LSJKOO10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1LSJKOO11",
//					"editVersion": 6,
//					"attrs": {
//						"trackSize": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LSJKOO12",
//			"editVersion": 118,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "value"
//				},
//				{
//					"type": "string",
//					"valText": "min"
//				},
//				{
//					"type": "string",
//					"valText": "max"
//				},
//				{
//					"type": "string",
//					"valText": "step"
//				},
//				{
//					"type": "string",
//					"valText": "enable"
//				},
//				{
//					"type": "string",
//					"valText": "barSize"
//				},
//				{
//					"type": "string",
//					"valText": "buttonSize"
//				},
//				{
//					"type": "string",
//					"valText": "valColor"
//				}
//			]
//		}
//	}
//}