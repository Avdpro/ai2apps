//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NaviTop} from "./NaviTop.js";
import {BtnIcon} from "./BtnIcon.js";
import {DataView} from "./DataView.js";
/*#{1GGJKM84D0StartDoc*/
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let title="Hello Tab-OS!";
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H2CTK7KT0",
				"type":NaviTop("Cool Site Name",[108,117,125,1],[255,255,255,1],"/~/-tabos/shared/assets/cklogo.svg","/~/-tabos/shared/assets/menu.svg",[]),"position":"relative",
				"x":0,"y":0,"face":"desktop",
				subContainers:{
					"1H2CQTOQC0":[
						{
							"hash":"1H2CTOITA0",
							"type":BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,0,0,5],
						}
					]
				},
				/*#{1H2CTK7KT0Codes*/
				showMenu(){
					app.showDlg(menu,{hud:this});
				}
				/*}#1H2CTK7KT0Codes*/
			},
			{
				"hash":"1HQTTHM9N0",
				"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12},"Object View"),
				"position":"relative","x":0,"y":0,
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"init":{
				"#1H2CTK7KT0":{
					"display":1
				}
			},"mobile":{
				"#1H2CTK7KT0":{
					"face":"mobile"
				}
			},"desktop":{
				"#1H2CTK7KT0":{
					"face":"desktop"
				}
			},"showMenu":{
			},"showDlog":{
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GGJKM84D1Create*/
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/


/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5P3EKLL0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Hello Tab-OS!"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBPVTR0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "true",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H2OBUOH70",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OCKPNB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H2OCMPHB0",
//							"attrs": {}
//						}
//					}
//				},
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OCOSG70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H2OCPGU50",
//							"attrs": {}
//						}
//					}
//				},
//				"showMenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBPJL10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H2OBUOH71",
//							"attrs": {}
//						}
//					}
//				},
//				"showDlog": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBRQUC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H2OBUOH72",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQTTDPOI0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1H2CQBSVI0",
//							"jaxId": "1H2CTK7KT0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H2CTKJ800",
//									"attrs": {
//										"title": "Cool Site Name",
//										"bgColor": "[108,117,125,1.00]",
//										"color": "[255,255,255,1.00]",
//										"logoIcon": "/~/-tabos/shared/assets/cklogo.svg",
//										"menuIcon": "/~/-tabos/shared/assets/menu.svg",
//										"menuItems": "[]"
//									}
//								},
//								"properties": {
//									"jaxId": "1H2CTKJ801",
//									"attrs": {
//										"type": "#null#>NaviTop(\"Cool Site Name\",[108,117,125,1],[255,255,255,1],\"/~/-tabos/shared/assets/cklogo.svg\",\"/~/-tabos/shared/assets/menu.svg\",[])",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "\"desktop\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H2CTKJ802",
//									"attrs": {
//										"1H2OBPVTR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OBUOH73",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2OBUOH74",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBPVTR0",
//											"faceTagName": "init"
//										},
//										"1H2OBPJL10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OBUOH80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2OBUOH81",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBPJL10",
//											"faceTagName": "showMenu"
//										},
//										"1H2OCKPNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCMPHB1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2OCMPHB2",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"mobile\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OCKPNB0",
//											"faceTagName": "mobile"
//										},
//										"1H2OBRQUC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCPGU51",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2OCPGU52",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBRQUC0",
//											"faceTagName": "showDlog"
//										},
//										"1H2OCOSG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCPGU53",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2OCPGU54",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"desktop\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OCOSG70",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H2CTKJ803",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H2CTKJ804",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H2CTKJ805",
//									"attrs": {
//										"Slot1H2CQI73O0": {
//											"jaxId": "1H2CTLSKA0",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										},
//										"Slot1H2CQTOQC0": {
//											"jaxId": "1H2CTLT8S0",
//											"attrs": {
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1KJQ5RK0",
//															"jaxId": "1H2CTOITA0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1H2CTPCG412",
//																	"attrs": {
//																		"style": "#cfgColor.fontPrimary",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1H2CTPCG413",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+\"/find.svg\",null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "50%",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Center",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H2CTPCG414",
//																	"attrs": {
//																		"1H2OBPJL10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH820",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H2OBUOH821",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBPJL10",
//																			"faceTagName": "showMenu"
//																		},
//																		"1H2OBPVTR0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH822",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H2OBUOH823",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBPVTR0",
//																			"faceTagName": "init"
//																		},
//																		"1H2OBRQUC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH824",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H2OBUOH825",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBRQUC0",
//																			"faceTagName": "showDlog"
//																		},
//																		"1H2OCKPNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OCMPHB9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H2OCMPHB10",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OCKPNB0",
//																			"faceTagName": "mobile"
//																		},
//																		"1H2OCOSG70": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OCPGU62",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H2OCPGU63",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OCOSG70",
//																			"faceTagName": "desktop"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H2CTPCG415",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H2CTPCG416",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H2CTPCG417",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HQ1M47LD0",
//							"jaxId": "1HQTTHM9N0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HQTTK2BT0",
//									"attrs": {
//										"box": "null",
//										"template": "null",
//										"dataObj": "null",
//										"property": "",
//										"options": {
//											"jaxId": "1HQTTK2BT1",
//											"attrs": {
//												"titleHeight": "30",
//												"titleSize": "18",
//												"titleColor": "#cfgColor[\"fontBody\"]",
//												"titleBold": "true",
//												"lineHeight": "30",
//												"lineGap": "5",
//												"labelSize": "12",
//												"labelColor": "#cfgColor[\"fontBody\"]",
//												"labelLine": "false",
//												"valueSize": "14",
//												"valueColor": "#cfgColor[\"fontBody\"]",
//												"valueBold": "false",
//												"segHeight": "20",
//												"segSize": "14",
//												"segBold": "true",
//												"segColor": "#cfgColor[\"fontBody\"]",
//												"trace": "false",
//												"edit": "false",
//												"noteSize": "12"
//											}
//										},
//										"title": "Object View"
//									}
//								},
//								"properties": {
//									"jaxId": "1HQTTK2BT2",
//									"attrs": {
//										"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12},\"Object View\")",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQTTK2BT3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HQTTK2BT4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQTTK2BT5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HQTTK2BT6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {
//						"1H2OBPJL10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OBUOH882",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2OBUOH883",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OBPJL10",
//							"faceTagName": "showMenu"
//						},
//						"1H2OBRQUC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU662",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2OCPGU663",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OBRQUC0",
//							"faceTagName": "showDlog"
//						},
//						"1H2OCKPNB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU664",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2OCPGU665",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OCKPNB0",
//							"faceTagName": "mobile"
//						},
//						"1H2OCOSG70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU666",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2OCPGU667",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OCOSG70",
//							"faceTagName": "desktop"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "true",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}