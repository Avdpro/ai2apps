//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NaviTop} from "./NaviTop.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1GGJKM84D0StartDoc*/
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let title="Hello Tab-OS!";
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H2CTK7KT0",
				"type":NaviTop("Cool Site Name",[108,117,125,1],[255,255,255,1],"/~/-tabos/shared/assets/cklogo.svg","/~/-tabos/shared/assets/menu.svg",[]),"x":0,
				"y":0,"face":"desktop",
				subContainers:{
					"1H2CQTOQC0":[
						{
							"hash":"1H2CTOITA0",
							"type":BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,0,0,5],
						}
					]
				},
				/*#{1H2CTK7KT0Codes*/
				showMenu(){
					app.showDlg(menu,{hud:this});
				}
				/*}#1H2CTK7KT0Codes*/
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"init":{
				"#1H2CTK7KT0":{
					"display":1
				}
			},"mobile":{
				"#1H2CTK7KT0":{
					"face":"mobile"
				}
			},"desktop":{
				"#1H2CTK7KT0":{
					"face":"desktop"
				}
			},"showMenu":{
			},"showDlog":{
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GGJKM84D1Create*/
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/


export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"editVersion": 48,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1GGJKM84D2",
//			"editVersion": 26,
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GGJKM84D3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5P3EKLL0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D4",
//			"editVersion": 16,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D5",
//			"editVersion": 16,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Hello Tab-OS!"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1GGJKM84D6",
//			"editVersion": 4,
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1GGJKM84D7",
//			"editVersion": 18,
//			"attrs": {
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBPVTR0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "true",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H2OBUOH70",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OCKPNB0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H2OCMPHB0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OCOSG70",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H2OCPGU50",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"showMenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBPJL10",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H2OBUOH71",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"showDlog": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H2OBRQUC0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H2OBUOH72",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1GGJKM84D8",
//					"editVersion": 104,
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Block"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1H2CQBSVI0",
//							"jaxId": "1H2CTK7KT0",
//							"editVersion": 64,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1H2CTKJ800",
//									"editVersion": 20,
//									"attrs": {
//										"title": "Cool Site Name",
//										"bgColor": "[108,117,125,1.00]",
//										"color": "[255,255,255,1.00]",
//										"logoIcon": "/~/-tabos/shared/assets/cklogo.svg",
//										"menuIcon": "/~/-tabos/shared/assets/menu.svg",
//										"menuItems": "[]"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2CTKJ801",
//									"editVersion": 47,
//									"attrs": {
//										"type": "#null#>NaviTop(\"Cool Site Name\",[108,117,125,1],[255,255,255,1],\"/~/-tabos/shared/assets/cklogo.svg\",\"/~/-tabos/shared/assets/menu.svg\",[])",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "\"desktop\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2CTKJ802",
//									"editVersion": 18,
//									"attrs": {
//										"1H2OBPVTR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OBUOH73",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2OBUOH74",
//													"editVersion": 6,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBPVTR0",
//											"faceTagName": "init"
//										},
//										"1H2OBPJL10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OBUOH80",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2OBUOH81",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBPJL10",
//											"faceTagName": "showMenu"
//										},
//										"1H2OCKPNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCMPHB1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2OCMPHB2",
//													"editVersion": 6,
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"mobile\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OCKPNB0",
//											"faceTagName": "mobile"
//										},
//										"1H2OBRQUC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCPGU51",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2OCPGU52",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OBRQUC0",
//											"faceTagName": "showDlog"
//										},
//										"1H2OCOSG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2OCPGU53",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2OCPGU54",
//													"editVersion": 4,
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"desktop\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H2OCOSG70",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2CTKJ803",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2CTKJ804",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1H2CTKJ805",
//									"editVersion": 0,
//									"attrs": {
//										"Slot1H2CQI73O0": {
//											"type": "gearcontainer",
//											"jaxId": "1H2CTLSKA0",
//											"editVersion": 4,
//											"attrs": {
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"container": "true"
//											}
//										},
//										"Slot1H2CQTOQC0": {
//											"type": "gearcontainer",
//											"jaxId": "1H2CTLT8S0",
//											"editVersion": 4,
//											"attrs": {
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1KJQ5RK0",
//															"jaxId": "1H2CTOITA0",
//															"editVersion": 76,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H2CTPCG412",
//																	"editVersion": 50,
//																	"attrs": {
//																		"style": "#cfgColor.fontPrimary",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2CTPCG413",
//																	"editVersion": 77,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+\"/find.svg\",null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "50%",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Center",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2CTPCG414",
//																	"editVersion": 10,
//																	"attrs": {
//																		"1H2OBPJL10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH820",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2OBUOH821",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBPJL10",
//																			"faceTagName": "showMenu"
//																		},
//																		"1H2OBPVTR0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH822",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2OBUOH823",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBPVTR0",
//																			"faceTagName": "init"
//																		},
//																		"1H2OBRQUC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OBUOH824",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2OBUOH825",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OBRQUC0",
//																			"faceTagName": "showDlog"
//																		},
//																		"1H2OCKPNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OCMPHB9",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2OCMPHB10",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OCKPNB0",
//																			"faceTagName": "mobile"
//																		},
//																		"1H2OCOSG70": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H2OCPGU62",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2OCPGU63",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H2OCOSG70",
//																			"faceTagName": "desktop"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2CTPCG415",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2CTPCG416",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H2CTPCG417",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1GGJKM84D9",
//					"editVersion": 52,
//					"attrs": {
//						"1H2OBPJL10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OBUOH882",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2OBUOH883",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OBPJL10",
//							"faceTagName": "showMenu"
//						},
//						"1H2OBRQUC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU662",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2OCPGU663",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OBRQUC0",
//							"faceTagName": "showDlog"
//						},
//						"1H2OCKPNB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU664",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2OCPGU665",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OCKPNB0",
//							"faceTagName": "mobile"
//						},
//						"1H2OCOSG70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2OCPGU666",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2OCPGU667",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H2OCOSG70",
//							"faceTagName": "desktop"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1GGJKM84D10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJKM84D11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "true",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"editVersion": 70,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}