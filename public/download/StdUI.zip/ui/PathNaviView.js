//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I8JBEEAD0StartDoc*/
import pathLib from "/@path";
import {makeNotify,makeObjEventEmitter} from "/@events";
import {readPath,readPathInfo,applyFileDrop} from "../FileUtils.js";
import {PathEntryLine} from "./PathEntryLine.js";
/*}#1I8JBEEAD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let PathNaviView=function(options,lineOpts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let tbView;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I8JBEEAD1LocalVals*/
	let app=VFACT.app;
	let dropApplied=false;
	let filterRegexes=null;
	/*}#1I8JBEEAD1LocalVals*/
	
	/*#{1I8JBEEAD1PreState*/
	options=options||{};
	lineOpts=lineOpts||{};
	if(options.dirOnly ){
		lineOpts.dirOnly=true;
	}
	/*}#1I8JBEEAD1PreState*/
	state={
		"path":"/","pathEntry":null,"focusedNode":null,"selected":null,"hotEntry":null,
		/*#{1I8JBEEAD7ExState*/
		/*}#1I8JBEEAD7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I8JBEEAD1PostState*/
	//------------------------------------------------------------------------
	let funcNodeDef=function(obj,node){
		let lastClickTime=0;
		return {
			type:PathEntryLine(self,node,obj,node.indent,lineOpts),
			OnClick:function(evt){
				let button;
				button=evt.button;
				if(button===0){//Left button
					let time=Date.now();
					if(time-lastClickTime<500){
						lastClickTime=0;
						if(obj.dir){
							if(lineOpts.expandBtn){
								if(node.isOpen){
									self.collapseDirNode(node);
									//tbView.closeNode(node);
								}else{
									self.expandDirNode(node);
								}
							}else{
								self.emitNotify("OpenDir");
							}
						}else{
							self.emitNotify("OpenFile");
						}
					}else{
						if(options.multiSelect){
							if(evt.shiftKey){
								let hotNode,nodes,idx1,idx2,i;
								hotNode=tbView.hotNode;
								nodes=tbView.nodes;
								if(!hotNode){
									tbView.setHotNode(node);
									lastClickTime=0;
								}else{
									if(hotNode===node){
										return;//Do nothing.
									}
									idx1=tbView.indexOfNode(hotNode);
									idx2=tbView.indexOfNode(node);
									if(idx1>idx2){//Swap idx,idx2
										idx1=idx1+idx2;
										idx2=idx1-idx2;
										idx1=idx1-idx2;
									}
									if(evt.metaKey||evt.ctrlKey){
										let nd;
										tbView.pauseCallback++;
										//tbView.hotNode=null;
										for(i=idx1;i<=idx2;i++){
											nd=nodes[i];
											if(tbView.isNodeSelected(nd)){
												tbView.deselectNode(nd);
											}else{
												tbView.selectNode(nd);
											}
										}
										tbView.pauseCallback--;
										tbView.setHotNode(node,true);
									}else{
										tbView.pauseCallback++;
										tbView.clearSelects();
										tbView.hotNode=null;
										for(i=idx1;i<=idx2;i++){
											tbView.selectNode(nodes[i]);
										}
										tbView.pauseCallback--;
										tbView.setHotNode(node,true);
									}
								}
							}else if(evt.metaKey||evt.ctrlKey){
								if(tbView.isNodeSelected(node)){
									let idx,selList,nextNode,hotNode;
									hotNode=tbView.hotNode;
									selList=Array.from(tbView.selected);
									idx=selList.indexOf(node);
									tbView.deselectNode(node);
									if(hotNode===node){
										nextNode=selList[idx+1]||selList[idx-1];
										if(nextNode){
											tbView.setHotNode(nextNode,true);
										}
									}
								}else{
									if(tbView.hotNode!==node){
										tbView.setHotNode(node,true);
									}else{
										self.emitNotify("CaptureFocus");
									}
								}
								lastClickTime=0;
							}else{
								tbView.setHotNode(node);
								lastClickTime=time;
							}
						}else{
							if(tbView.hotNode!==node){
								tbView.setHotNode(node);
								lastClickTime=time;
							}else{
								self.emitNotify("CaptureFocus");
								lastClickTime=time;
							}
						}
					}
				}else if(button===2){//Right button
					if(tbView.selected.size>1){
						if(tbView.isNodeSelected(node)){
							if(tbView.hotNode!==node){
								tbView.setHotNode(node,true);
							}else{
								self.emitNotify("CaptureFocus");
							}
							tbView.setHotNode(node,true);
							lastClickTime=0;
							if(this.showFileMenu){
								this.showFileMenu();
							}
						}else{
							if(tbView.hotNode!==node){
								tbView.setHotNode(node,true);
							}else{
								self.emitNotify("CaptureFocus");
							}
							lastClickTime=0;
							if(this.showFileMenu){
								this.showFileMenu();
							}
						}
					}else{
						if(tbView.hotNode!==node){
							tbView.setHotNode(node);
						}else{
							self.emitNotify("CaptureFocus");
						}
						lastClickTime=0;
						if(this.showFileMenu){
							this.showFileMenu(evt);
						}
					}
				}
			}
		};
	};
	
	//------------------------------------------------------------------------
	let funcGetSubObjs=function(obj,node){
		return node.subItems;
	};
	/*}#1I8JBEEAD1PostState*/
	cssVO={
		"hash":"1I8JBEEAD1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"options":options,"lineOpts":lineOpts,
		children:[
			{
				"hash":"1I8JBKDOO0",
				"type":"tree","id":"TbView","position":"relative","x":0,"y":0,"w":"100%","h":"100%","contentLayout":"flex-y","overflow":"auto","padding":[0,0,50,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"OnClick":function(event){
					/*#{1I94ULFIO0FunctionBody*/
					self.emitNotify("CaptureFocus");
					/*}#1I94ULFIO0FunctionBody*/
				},
			}
		],
		get $$path(){return state["path"]},
		set $$path(v){
			state["path"]=v;
			/*#{1I8JBEEAD1Setpath*/
			/*}#1I8JBEEAD1Setpath*/
		},
		get $$pathEntry(){return state["pathEntry"]},
		set $$pathEntry(v){
			state["pathEntry"]=v;
			/*#{1I8JBEEAD1SetpathEntry*/
			/*}#1I8JBEEAD1SetpathEntry*/
		},
		get $$focusedNode(){return state["focusedNode"]},
		set $$focusedNode(v){
			state["focusedNode"]=v;
			/*#{1I8JBEEAD1SetfocusedNode*/
			/*}#1I8JBEEAD1SetfocusedNode*/
		},
		get $$selected(){return state["selected"]},
		set $$selected(v){
			state["selected"]=v;
			/*#{1I8JBEEAD1Setselected*/
			/*}#1I8JBEEAD1Setselected*/
		},
		get $$hotEntry(){return state["hotEntry"]},
		set $$hotEntry(v){
			state["hotEntry"]=v;
			/*#{1I8JBEEAD1SethotEntry*/
			/*}#1I8JBEEAD1SethotEntry*/
		},
		/*#{1I8JBEEAD1ExtraCSS*/
		/*}#1I8JBEEAD1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			tbView=self.TbView;
			/*#{1I8JBEEAD1Create*/
			tbView.nodeDef=funcNodeDef;
			tbView.getSubObjs=funcGetSubObjs;
			tbView.OnHotNodeChange=self.OnHotNodeChange;
			tbView.OnSelNodeChange=self.OnSelNodeChange;
			state.selected=tbView.selected;
			makeObjEventEmitter(this);
			makeNotify(this);
			if(options.path){
				if(Array.isArray(options.path)){
					state.path=null;
					for(let path of options.path){
						self.addRootPath(path,false);
					}
				}else{
					self.viewPath(options.path);
				}
			}
			/*}#1I8JBEEAD1Create*/
		},
		/*#{1I8JBEEAD1EndCSS*/
		/*}#1I8JBEEAD1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.buildFilter=async function(filter){
		/*#{1I8O8NQVM0Start*/
		let list,i,n;
		filter=filter||options.filter;
		if(!filter){
			filterRegexes=null;
			return;
		}
		if(Array.isArray(filter)){
			list=filter.slice(0);
			n=list.length;
			for(i=0;i<n;i++){
				filter=list[i];
				if(filter instanceof RegExp){
				}else if(typeof(filter)==="string"){
					if(filter.startsWith("*.")){
						list[i]=new RegExp(`\.${filter.substring(2)}$`,'i');
					}else if(filter[0]==="."){
						list[i]=new RegExp(`\.${filter.substring(1)}$`,'i');
					}else{
						list[i]=new RegExp(`\.${filter.substring(1)}$`,'i');
					}
				}
			}
			if(list.length>0){
				filterRegexes=list;
				return;
			}
		}
		if(typeof(filter)==="string"){
			let filters;
			filters=filter.split(";");
			list=[];
			for(filter of filters){
				if(filter){
					if(filter.startsWith("*.")){
						list.push(new RegExp(`\.${filter.substring(2)}$`,'i'));
					}else if(filter[0]==="."){
						list.push(new RegExp(`\.${filter.substring(1)}$`,'i'));
					}else{
						list.push(new RegExp(`\.${filter.substring(1)}$`,'i'));
					}
				}
			}
			if(list.length>0){
				filterRegexes=list;
				return;
			}
		}
		filterRegexes=null;
		/*}#1I8O8NQVM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.filterPath=function(path){
		/*#{1I8OC8MR40Start*/
		if(!filterRegexes){
			return true;
		}
		return filterRegexes.every((rgx)=>{
			return rgx.test(path)
		});
		/*}#1I8OC8MR40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.viewPath=async function(path,opts){
		/*#{1I8LN5T3L0Start*/
		let list,entry;
		tbView.clear();
		if(opts){
			Object.assign(options,opts);
		}
		if("multiSelect" in options){
			tbView.multiSelect=options.multiSelect;
		}else{
			tbView.multiSelect=false;
		}
		if("allowDrop" in options){
			self.allowDrop=!!options.allowDrop;
			if(options.allowDrop && !dropApplied){
				applyFileDrop(tbView,{
					OnDropFile:self.OnDropFile
				});
				dropApplied=true;
			}
		}
		self.buildFilter();
		state.path=path;
		tbView.path=path;
		list=await readPath(path,options.sort||"Name");
		if(!list){
			return;
		}
		for(entry of list){
			if(options.dirOnly && (!entry.dir)){
				continue;
			}
			if(entry.dir){
				tbView.addNode(entry,null);
			}else if(!filterRegexes || self.filterPath(entry.name)){
				tbView.addNode(entry,null);
			}
		}
		/*}#1I8LN5T3L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addRootPath=async function(paths,open){
		/*#{1I94I7NLO0Start*/
		let entry,node,path;
		if(!Array.isArray(paths)){
			paths=[paths];
		}
		for(path of paths){
			entry=await readPathInfo(path);
			if(!entry){
				return null;
			}
			node=tbView.addNode(entry,null);
			if(open && entry.dir){
				node.hud.expand();
			}
		}
		return node;
		/*}#1I94I7NLO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.initRootPath=async function(paths,open){
		/*#{1I8LP55LJ0Start*/
		let entry,node,path;
		if(!Array.isArray(paths)){
			paths=[paths];
		}
		state.path=null;
		state.pathEntry=null;
		
		for(path of paths){
			entry=await readPathInfo(path);
			if(!entry){
				return null;
			}
			node=tbView.addNode(entry,null);
			if(open){
				node.hud.expand();
			}
		}
		/*}#1I8LP55LJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnDropFile=async function(files){
		/*#{1I8LNLF8B0Start*/
		let path,node,entry;
		if(!files){
			return;
		}
		for(path of files){
			if(state.path===pathLib.dirname(path)){
				node=self.getPathNode(path);
				if(!node){
					entry=await readPathInfo(path);
					node=tbView.addNode(entry,null);
				}
			}
		}
		if(node){
			tbView.hotNode=node;
		}
		/*}#1I8LNLF8B0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnDropDel=async function(list){
		/*#{1I96M863T0Start*/
		let path,node;
		for(path of list){
			node=self.getPathNode(path);
			if(node){
				tbView.removeNode(node);
			}
		}
		/*}#1I96M863T0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.diffView=async function(){
		/*#{1I8LP6VB20Start*/
		//TODO: Code this:
		/*}#1I8LP6VB20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getPathNode=function(path){
		/*#{1I8LPOHDM0Start*/
		let node;
		node=tbView.findNode((node)=>{return node.nodeObj && node.nodeObj.path===path;});
		if(node){
			return node;
		}
		return null;
		/*}#1I8LPOHDM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showPathNode=async function(path,find,select){
		/*#{1I8NDFJV50Start*/
		let node,upperPath,upperNode;
		node=self.getPathNode(path);
		if(node){
			if(select){
				tbView.setHotNode(node);
			}
			tbView.scrollShowNode(node);
			return node;
		}
		if(!lineOpts.expandBtn || !find){
			return null;
		}
		upperPath=pathLib.dirname(path);
		upperNode=await self.showPathNode(upperPath,true,false);
		if(upperNode){
			await upperNode.hud.expand();
			node=self.getPathNode(path);
			if(node){
				if(select){
					tbView.setHotNode(node);
				}
				tbView.scrollShowNode(node);
			}
			return node;
		}
		return null;
		/*}#1I8NDFJV50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.expandDirNode=async function(node){
		/*#{1I8NN2NQI0Start*/
		let hud=node.hud;
		let path=hud.path;
		if(!options.cacheSub || !node.subItems){
			let list;
			list=await readPath(path,"Name");
			node.subItems=list.filter((entry)=>{
				if(options.dirOnly && (!entry.dir)){
					return false;
				}
				if(filterRegexes && (!self.filterPath(entry.name))){
					return false;
				}
				return true;
			});
		}
		tbView.openNode(node);
		if((!node.subItems) || (!node.subItems.length)){
			hud.showFace("empty");
		}else{
			hud.showFace("!empty");
		}
		hud.showFace("expand");
		/*}#1I8NN2NQI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.collapseDirNode=async function(node){
		/*#{1I8NN3E7C0Start*/
		let hotNode=tbView.hotNode;
		let hud=node.hud;
		tbView.closeNode(node);
		hud.showFace("collapse");
		if(hotNode && !tbView.hotNode){
			tbView.hotNode=node;
		}
		/*}#1I8NN3E7C0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.deleteDirNode=async function(node){
		/*#{1IAS9VLNI0Start*/
		tbView.removeNode(node);
		/*}#1IAS9VLNI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnHotNodeChange=async function(node){
		/*#{1I8Q2NH910Start*/
		let entry;
		entry=node?node.nodeObj:null;
		state.focusedNode=node;
		state.hotEntry=entry;
		if(node){
			self.emit("FocusPath",entry?entry.path:null,entry,node);
			self.emitNotify("FocusPath");
		}else{
			self.emit("FocusPath",null,null,null);
			self.emitNotify("FocusPath");
		}
		/*}#1I8Q2NH910Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSelNodeChange=async function(){
		/*#{1I8VDHGAP0Start*/
		if(!options.multiSelect){
			return;
		}
		self.emitNotify("FocusPath");
		/*}#1I8VDHGAP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getSelection=function(sort){
		/*#{1I8R3O9S00Start*/
		let list;
		list=Array.from(tbView.selected.values());
		if(sort){
			list=tbView.sortNodes(list);
		}
		return list;
		/*}#1I8R3O9S00Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnKeyDown=function(keyCode,evt){
		/*#{1I90G7QJD0Start*/
		let node,nodeIdx,nxtNode;
		switch(keyCode){
			case "ArrowRight":
				if(lineOpts.expandBtn){
					node=tbView.hotNode;
					if(node.nodeObj.dir){
						if(node.isOpen){
							nodeIdx=tbView.indexOfNode(node);
							nxtNode=tbView.nodes[nodeIdx+1];
							if(nxtNode){
								tbView.setHotNode(nxtNode);
								tbView.scrollShowNode(nxtNode);
							}
						}else{
							self.expandDirNode(node);
						}
					}
					return true;
				}
				return false;
			case "ArrowLeft":
				if(lineOpts.expandBtn){
					node=tbView.hotNode;
					if(node.nodeObj.dir){
						if(node.isOpen){
							self.collapseDirNode(node);
						}else{
							nodeIdx=tbView.indexOfNode(node);
							nxtNode=tbView.nodes[nodeIdx-1];
							nxtNode=node.ownerNode||nxtNode;
							if(nxtNode){
								tbView.setHotNode(nxtNode);
								tbView.scrollShowNode(nxtNode);
							}
						}
					}
					return true;
				}
				return false;
			case "ArrowUp":{
				node=tbView.hotNode;
				if(node){
					nodeIdx=tbView.indexOfNode(node);
					nxtNode=tbView.nodes[nodeIdx-1];
					if(nxtNode){
						if(evt.shiftKey){
							if(tbView.isNodeSelected(nxtNode)){
								tbView.deselectNode(node);
								tbView.setHotNode(nxtNode,true);
							}else{
								tbView.setHotNode(nxtNode,true);
							}
						}else{
							tbView.setHotNode(nxtNode);
						}
						tbView.scrollShowNode(nxtNode);
						return true;
					}
				}else{
					node=tbView.nodes[0];
					if(node){
						tbView.setHotNode(node);
						tbView.scrollShowNode(node);
						return true;
					}
				}
				return false;
			}
			case "ArrowDown":{
				node=tbView.hotNode;
				if(node){
					nodeIdx=tbView.indexOfNode(node);
					nxtNode=tbView.nodes[nodeIdx+1];
					if(nxtNode){
						if(evt.shiftKey){
							if(tbView.isNodeSelected(nxtNode)){
								tbView.deselectNode(node);
								tbView.setHotNode(nxtNode,true);
							}else{
								tbView.setHotNode(nxtNode,true);
							}
						}else{
							tbView.setHotNode(nxtNode);
						}
						tbView.scrollShowNode(nxtNode);
						return true;
					}
				}else{
					node=tbView.nodes[0];
					if(node){
						tbView.setHotNode(node);
						tbView.scrollShowNode(node);
						return true;
					}
				}
				return false;
			}
		}
		return false;
		/*}#1I90G7QJD0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnViewFocus=async function(){
		/*#{1I94OQGP40Start*/
		let hotNode;
		hotNode=tbView.hotNode;
		if(hotNode){
			hotNode.hud.showFace("focus");
		}
		/*}#1I94OQGP40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnViewBlur=async function(){
		/*#{1I94OQUFU0Start*/
		let hotNode;
		hotNode=tbView.hotNode;
		if(hotNode){
			hotNode.hud.showFace("subFocus");
		}
		/*}#1I94OQUFU0Start*/
	};
	/*#{1I8JBEEAD1PostCSSVO*/
	cssVO.showPath=cssVO.showPathNode;
	/*}#1I8JBEEAD1PostCSSVO*/
	cssVO.constructor=PathNaviView;
	return cssVO;
};
/*#{1I8JBEEAD1ExCodes*/
/*}#1I8JBEEAD1ExCodes*/

//----------------------------------------------------------------------------
PathNaviView.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I8JBEEAD1PreAISpot*/
	/*}#1I8JBEEAD1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I8JBEEAD1PostAISpot*/
	/*}#1I8JBEEAD1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
PathNaviView.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"options": {
			"type": "object", "name": "options", "showName": "options", "icon": undefined, 
			"def": {
				"attrs": {
					"path": {
						"name": "path", "showName": "path", "type": "string", "key": true, "fixed": true, "initVal": ""
					}, 
					"dirOnly": {
						"name": "dirOnly", "showName": "dirOnly", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"multiSelect": {
						"name": "multiSelect", "showName": "multiSelect", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"allowDrop": {
						"name": "allowDrop", "showName": "allowDrop", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"cacheSub": {
						"name": "cacheSub", "showName": "cacheSub", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"prescanSub": {
						"name": "prescanSub", "showName": "prescanSub", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"sort": {
						"name": "sort", "showName": "sort", "type": "string", "key": true, "fixed": true, "initVal": "Name"
					}, 
					"filter": {
						"name": "filter", "showName": "filter", "type": "auto", "key": true, "fixed": true, 
						"initVal": null
					}
				}
			}, 
			"key": true, "fixed": true
		}, 
		"lineOpts": {
			"type": "object", "name": "lineOpts", "showName": "lineOpts", "icon": undefined, 
			"def": {
				"attrs": {
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 14, "initValText": "#txtSize.smallPlus"
					}, 
					"allowDrop": {
						"name": "allowDrop", "showName": "allowDrop", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"allowDrag": {
						"name": "allowDrag", "showName": "allowDrag", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"height": {
						"name": "height", "showName": "height", "type": "int", "key": true, "fixed": true, "initVal": 24
					}, 
					"iconSize": {
						"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 20
					}, 
					"color": {
						"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
						"initVal": [0,0,0,1], "initValText": "#cfgColor.fontBody"
					}, 
					"checkBox": {
						"name": "checkBox", "showName": "checkBox", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"expandBtn": {
						"name": "expandBtn", "showName": "expandBtn", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"indentSize": {
						"name": "indentSize", "showName": "indentSize", "type": "int", "key": true, "fixed": true, "initVal": 15
					}, 
					"fileSize": {
						"name": "fileSize", "showName": "fileSize", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"fileMenu": {
						"name": "fileMenu", "showName": "fileMenu", "type": "bool", "key": true, "fixed": true, "initVal": true
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		path:{name:"path",type:"string",initVal:"/"},
		pathEntry:{name:"pathEntry",type:"auto",initVal:null},
		focusedNode:{name:"focusedNode",type:"auto",initVal:null},
		selected:{name:"selected",type:"auto",initVal:null},
		hotEntry:{name:"hotEntry",type:"auto",initVal:null}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","contentLayout","subAlign","itemsAlign","itemsWrap","clip","uiEvent","alpha","rotate","scale","filter","aspect","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:[],
	subContainers:{
	},
	/*#{1I8JBEEAD0ExGearInfo*/
	/*}#1I8JBEEAD0ExGearInfo*/
};
/*#{1I8JBEEAD0EndDoc*/
/*}#1I8JBEEAD0EndDoc*/

export default PathNaviView;
export{PathNaviView};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I8JBEEAD0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I8JBEEAD2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I8JBEEAD3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I8JBEEAD4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I8JBEEAD5",
//			"attrs": {
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I8LN4QIV0",
//					"attrs": {
//						"path": {
//							"type": "string",
//							"valText": ""
//						},
//						"dirOnly": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"multiSelect": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"allowDrop": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"cacheSub": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"prescanSub": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"sort": {
//							"type": "string",
//							"valText": "Name"
//						},
//						"filter": {
//							"type": "auto",
//							"valText": "null"
//						}
//					}
//				},
//				"lineOpts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1I8LO538R0",
//					"attrs": {
//						"fontSize": {
//							"type": "int",
//							"valText": "#txtSize.smallPlus"
//						},
//						"allowDrop": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"allowDrag": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"iconSize": {
//							"type": "int",
//							"valText": "20"
//						},
//						"color": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor.fontBody"
//						},
//						"checkBox": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"expandBtn": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						},
//						"fileSize": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"fileMenu": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I8JBEEAD6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I8JBEEAD7",
//			"attrs": {
//				"path": {
//					"type": "string",
//					"valText": "/"
//				},
//				"pathEntry": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"focusedNode": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"selected": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"hotEntry": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8O8NQVM0",
//					"attrs": {
//						"id": "buildFilter",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "790",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8O8U4330",
//							"attrs": {
//								"filter": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8O8U4331",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8O8U4332",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8OC8MR40",
//					"attrs": {
//						"id": "filterPath",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "795",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8OC96RE0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8OC96RE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8OC96RE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LN5T3L0",
//					"attrs": {
//						"id": "viewPath",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LN7EFK0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": "/"
//								},
//								"opts": {
//									"type": "object",
//									"def": "FlatObj",
//									"jaxId": "1I8MILSU00",
//									"attrs": {}
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LN7EFK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LN7EFK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I94I7NLO0",
//					"attrs": {
//						"id": "addRootPath",
//						"label": "New AI Seg",
//						"x": "330",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I94I944T0",
//							"attrs": {
//								"paths": {
//									"type": "auto",
//									"valText": ""
//								},
//								"open": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I94I944T1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I94I944T2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LP55LJ0",
//					"attrs": {
//						"id": "initRootPath",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LP89V90",
//							"attrs": {
//								"paths": {
//									"type": "string",
//									"valText": ""
//								},
//								"open": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LP89V91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LP89V92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LNLF8B0",
//					"attrs": {
//						"id": "OnDropFile",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "255",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LNME800",
//							"attrs": {
//								"files": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LNME801",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LNME802",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I96M863T0",
//					"attrs": {
//						"id": "OnDropDel",
//						"label": "New AI Seg",
//						"x": "330",
//						"y": "255",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I96M8FEU0",
//							"attrs": {
//								"list": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I96M8FEU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I96M8FEU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LP6VB20",
//					"attrs": {
//						"id": "diffView",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "340",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LP89V93",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LP89V94",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LP89V95",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8LPOHDM0",
//					"attrs": {
//						"id": "getPathNode",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "425",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8LPP29H0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8LPP29H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8LPP29H2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NDFJV50",
//					"attrs": {
//						"id": "showPathNode",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "425",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NDMVG20",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								},
//								"find": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"select": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NDMVG21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NDMVG22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NN2NQI0",
//					"attrs": {
//						"id": "expandDirNode",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "580",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NN41IB0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NN41IB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NN41IB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8NN3E7C0",
//					"attrs": {
//						"id": "collapseDirNode",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "580",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8NN41IB3",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8NN41IB4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8NN41IB5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IAS9VLNI0",
//					"attrs": {
//						"id": "deleteDirNode",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "580",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IASA0IHU0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IASA0IHU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IASA0IHU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8Q2NH910",
//					"attrs": {
//						"id": "OnHotNodeChange",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8Q2OLCU0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8Q2OLCU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8Q2OLCU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8VDHGAP0",
//					"attrs": {
//						"id": "OnSelNodeChange",
//						"label": "New AI Seg",
//						"x": "330",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8VDHMF00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8VDHMF01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8VDHMF02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8R3O9S00",
//					"attrs": {
//						"id": "getSelection",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "675",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8R3OUGT0",
//							"attrs": {
//								"sort": {
//									"type": "bool",
//									"valText": "#true"
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8R3OUGT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8R3OUGT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I90G7QJD0",
//					"attrs": {
//						"id": "OnKeyDown",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "885",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I90G8C5J0",
//							"attrs": {
//								"keyCode": {
//									"type": "string",
//									"valText": ""
//								},
//								"evt": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I90G8C5J1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I90G8C5J2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I94OQGP40",
//					"attrs": {
//						"id": "OnViewFocus",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "965",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I94OR6K20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I94OR6K21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I94OR6K22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I94OQUFU0",
//					"attrs": {
//						"id": "OnViewBlur",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "965",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I94OR6K23",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I94OR6K24",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I94OR6K25",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I8JBEEAD8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I8JBEEAD9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I8JBEEAD1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I8JBEEAD10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "TreeBox",
//							"jaxId": "1I8JBKDOO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8JBKO3I0",
//									"attrs": {
//										"type": "tree",
//										"id": "TbView",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"contentLayout": "flex-y",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,50,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8JBKO3I1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I8JBKO3I2",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I94ULFIO0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I94UM1MI0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I8JBKO3I3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I8JBEEAD11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I8JBEEAD12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I8JBEEAD13",
//					"attrs": {
//						"options": {
//							"type": "auto",
//							"valText": "#options"
//						},
//						"lineOpts": {
//							"type": "auto",
//							"valText": "#lineOpts"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I8JBEEAD14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "true",
//				"subAlign": "true",
//				"itemsAlign": "true",
//				"itemsWrap": "true",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "true",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "path"
//				},
//				{
//					"type": "string",
//					"valText": "pathEntry"
//				},
//				{
//					"type": "string",
//					"valText": "focusedNode"
//				},
//				{
//					"type": "string",
//					"valText": "selected"
//				},
//				{
//					"type": "string",
//					"valText": "hotEntry"
//				}
//			]
//		}
//	}
//}