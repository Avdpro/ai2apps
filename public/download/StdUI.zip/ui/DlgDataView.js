//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {DataView} from "./DataView.js";
import {BtnText} from "./BtnText.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HT9NO28U0StartDoc*/
import pathLib from "/@path";
/*
This is a template for standard dialog.
*/
/*}#1HT9NO28U0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgDataView=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,dvData,boxButtons,btnYes,btnNo,btn3rd;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let template={};
	let dataObj={};
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":"Edit Data","buttons":[],
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":"30%","w":360,"h":"","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HTBLR3GA0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[0,0,8,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["itemGray"],
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","minW":"","minH":50,"maxW":"","maxH":500,"styleClass":"",
				children:[
					{
						"hash":"1HT9O0AQM0",
						"type":DataView(null,null,{},"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":10,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12},"Object View"),
						"id":"DvData","position":"relative","x":0,"y":0,"h":"",
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,state.buttons[1]||"OK",false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"text":$P(()=>(state.buttons[1]||"OK"),state),
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							let vo;
							vo=dvData.getEditedVO();
							self.close(vo);
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,state.buttons[0]||"Cancel",false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"text":$P(()=>(state.buttons[0]||"Cancel"),state),
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(null);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":$P(()=>(!!(state.buttons[2])),state),
						"anchorY":1,
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HUSDA2A50",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","x":">calc(100% - 30px)","y":9,
				"tip":(($ln==="CN")?("保存数据"):("Save data")),
				"OnClick":function(event){
					self.saveData(this,event);
				},
			},
			{
				"hash":"1HUSDC31G0",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","x":">calc(100% - 57px)","y":9,
				"tip":(($ln==="CN")?("打开预先保存的数据"):("Open pre-saved data")),
				"OnClick":function(event){
					self.openData(this,event);
				},
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;dvData=self.DvData;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;btn3rd=self.Btn3rd;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.openData=async function(sender,event){
		/*#{1HUSE6R8R0Start*/
		let path,ext,tabFS;
		tabFS=(await import("/@tabos")).tabFS;
		if(!tabFS){
			return;
		}
		path="/doc";
		app.showDlg("/@homekit/ui/DlgFile.js",{
			mode:"open",
			path:path,
			buttonText:(($ln==="CN")?("读取"):/*EN*/("Open")),
			options:{
				multiSelect:false,
				preview:true,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				ext=pathLib.extname(filePath);
				try{
					let vo,code;
					if(ext===".js"){
						path="/~"+filePath;
						vo=(await import(path)).default;
					}else{
						code=await tabFS.readFile(filePath,"utf8");
						vo=JSON.parse(code);
					}
					dvData.setObject(null,vo,null);
				}catch(e){
				}
			}
		});
		/*}#1HUSE6R8R0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveData=async function(sender,event){
		/*#{1HUSE7R1J0Start*/
		let path,tabFS;
		tabFS=(await import("/@tabos")).tabFS;
		if(!tabFS){
			return;
		}
		path="/doc";
		app.showDlg("/@homekit/ui/DlgFile.js",{
			mode:"save",
			path:path,
			buttonText:(($ln==="CN")?("保存"):/*EN*/("Save")),
			options:{
				multiSelect:false,
				preview:true,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				try{
					let vo,code;
					vo=dvData.getEditedVO();
					await tabFS.writeFile(filePath,JSON.stringify(vo,null,"\t"),"utf8");
				}catch(e){
				}
			}
		});
		/*}#1HUSE7R1J0Start*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let w,h,x,y,mx,my,hud,ax,ay;
		dlgVO=vo;
		template=vo.template||{};
		dataObj=vo.object||null;
		dvData.setObject(template,dataObj,vo.options);
		state.title=vo.title||template.title||"Edit data:";
		hud=vo.hud;
		self.w=vo.width||vo.w||360;
		if(hud){
			let webObj,rect,asW,asH;
			webObj=hud.webObj;
			rect=webObj.getBoundingClientRect();
			asW=hud.w>=0?(rect.width/hud.w):1;
			asH=hud.h>=0?(rect.height/hud.h):1;
			x=rect.left+(vo.x*asW||0);
			y=rect.top+(vo.y*asH||hud.h*asH);
		}else{
			x=vo.x||0;
			y=vo.y||0;
		}
		w=self.w;
		//self.h=;//For ani
		ax=vo.alignX||vo.anchorH||vo.anchorX||0;
		switch(ax){
			case 0:
			default:
				break;
			case 1:
				x-=w*0.5;
				break;
			case 2:
				x-=w;
				break;
		}
		/*ay=vo.alignY||vo.anchorV||vo.anchorY||0;
		switch(ay){
			case 0:
			default:
				break;
			case 1:
				y-=h*0.5;
				break;
			case 2:
				y-=h;
				break;
		}*/
		mx=app.clientW-10;
		my=app.clientH-10;
		x=x<0?0:(x+w>mx?(mx-w):x);
		y=y<0?0:(y+h>my?(my-h):y);
		self.x=x;self.y=y-20;
		self.animate({type:"pose",y:y,time:80});
		callAfter(()=>{
			dvData.focus();
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DlgDataView.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("标准对话框"):("Standard Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent"}
	},
	/*#{1HT9NO28U0ExGearInfo*/
	/*}#1HT9NO28U0ExGearInfo*/
};
/*#{1HT9NO28U0EndDoc*/
/*}#1HT9NO28U0EndDoc*/

export default DlgDataView;
export{DlgDataView};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HT9NO28U0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {
//				"template": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Edit Data",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HUSE6R8R0",
//					"attrs": {
//						"id": "openData",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HUSE84AL0",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HUSE84AL1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HUSE84AL2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HUSE7R1J0",
//					"attrs": {
//						"id": "saveData",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HUSE84AL3",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HUSE84AL4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HUSE84AL5",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HT9NO29R0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "10",
//						"y": "30%",
//						"w": "360",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,3,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HTBLR3GA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HTBLTHHU0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,8,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"itemGray\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HTBLTHHU1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HTBLTHHU2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTBLTHHU3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "500",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1HQ1M47LD0",
//											"jaxId": "1HT9O0AQM0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HT9OOM8B1",
//													"attrs": {
//														"box": "null",
//														"template": "null",
//														"dataObj": "{}",
//														"property": "",
//														"options": {
//															"jaxId": "1HT9OOM8B2",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "true",
//																"lineHeight": "30",
//																"lineGap": "10",
//																"labelSize": "12",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "false",
//																"valueSize": "14",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "false",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "true",
//																"noteSize": "12"
//															}
//														},
//														"title": "Object View"
//													}
//												},
//												"properties": {
//													"jaxId": "1HT9OOM8B3",
//													"attrs": {
//														"type": "#null#>DataView(null,null,{},\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":10,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12},\"Object View\")",
//														"id": "DvData",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"h": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HT9OOM8B4",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HT9OOM8B5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HT9OOM8B6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HT9OOM8B7",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[1]||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,state.buttons[1]||\"OK\",false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "${state.buttons[1]||\"OK\"},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T820FU1",
//													"attrs": {
//														"style": "warning",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[0]||\"Cancel\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T820FU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",80,24,state.buttons[0]||\"Cancel\",false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "${state.buttons[0]||\"Cancel\"},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T820FU3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H1T820FU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JQQ40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T820FU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V2",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H25185U60",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H25185U61",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[2]",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H25185U62",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,state.buttons[2],false,\"\")",
//														"id": "Btn3rd",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "${!!(state.buttons[2])},state",
//														"face": "",
//														"anchorV": "Center",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H25185U70",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H25185U71",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H25185U72",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H25185U73",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H25185U74",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H25185U75",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1HUSDA2A50",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HUSDBUUC0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HUSDBUUC1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//										"id": "BtnSave",
//										"position": "Absolute",
//										"x": "100%-30",
//										"y": "9",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HUSDBUUC2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HUSDBUUC3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HUSE84AM0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HUSE84AM1",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1HUSE7R1J0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HUSDBUUC4",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Save data",
//											"localize": {
//												"EN": "Save data",
//												"CN": "保存数据"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HUSDBUUD0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1HUSDC31G0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HUSDC31G1",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HUSDC31G2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//										"id": "BtnOpen",
//										"position": "Absolute",
//										"x": "100%-57",
//										"y": "9",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HUSDC31G3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HUSDC31G4",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HUSE84AM2",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HUSE84AM3",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1HUSE6R8R0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HUSDC31G5",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Open pre-saved data",
//											"localize": {
//												"EN": "Open pre-saved data",
//												"CN": "打开预先保存的数据"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HUSDC31G6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}