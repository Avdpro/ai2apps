//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HQSTVR7J0StartDoc*/
/*}#1HQSTVR7J0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLEditElementjs=function(box,lineDef,opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxLine;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	let line=null;
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":25,"maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQSU12AU0",
				"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","id":"BoxLine","position":"relative","x":0,"y":0,"w":">calc(100% - 28px)","h":"","minW":"","minH":25,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,
				/*#{1HQ1GLVEK0Codes*/
				children:[lineDef]
				/*}#1HQ1GLVEK0Codes*/
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get property(){
			return line.property;
		},
		get template(){
			return line.template;
		},
		get value(){
			return line.value;
		},
		get line(){
			return line;
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxLine=self.BoxLine;
			/*#{1HQ1EDCKJ1Create*/
			line=boxLine.firstChild;
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		return line.commitEdit(val);
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(){
		//TODO: Code this:
	}
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		line.OnDataChange();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		line.updateValue();
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/


/*#{1HQSTVR7J0EndDoc*/
/*}#1HQSTVR7J0EndDoc*/

export default DLEditElementjs;
export{DLEditElementjs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQSTVR7J0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"lineDef": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1HQSU12AU0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HQSUULPC0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "25",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HQSUULPC1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//										"id": "BtnMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,3,0,0]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQSUULPC2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HQSUULPC3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQSUULPC4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HQSUULPC5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxLine",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%-28",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "25",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "false",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}