//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1H1LRUDP20StartDoc*/
/*}#1H1LRUDP20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxSteps=function(size){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnStepUp,btnStepDown;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LRUDP21LocalVals*/
	let stepTimer=null;
	let btnDown=false;
	/*}#1H1LRUDP21LocalVals*/
	
	/*#{1H1LRUDP21PreState*/
	/*}#1H1LRUDP21PreState*/
	state={
		"enable":true,"enableUp":true,"enableDown":true,
		/*#{1H1LRUDP26ExState*/
		/*}#1H1LRUDP26ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LRUDP21PostState*/
	function timerStep(dir){
		self.OnStep&&self.OnStep(dir);
		stepTimer=setTimeout(()=>{timerStep(dir)},200);
	}
	/*}#1H1LRUDP21PostState*/
	cssVO={
		"hash":"1H1LRUDP21",nameHost:true,
		"type":"hud","x":121,"y":141,"w":size,"h":size,"alpha":$P(()=>(state.enable?1:0.6),state),"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H1LRVCO90",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepup.svg",null),"id":"BtnStepUp","x":0,"y":0,"enable":$P(()=>(state.enableUp),state),
				"padding":1,
				"OnButtonDown":function(code,event){
					/*#{1H2E51V6T0FunctionBody*/
					if(stepTimer){
						clearTimeout(stepTimer);
					}
					if(btnDown){
						btnDown=0;
						return;
					}
					btnDown=1;
					self.OnStep&&self.OnStep(1);
					stepTimer=setTimeout(()=>{
						timerStep(1);
					},500);
					/*}#1H2E51V6T0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E520ES0FunctionBody*/
					btnDown=0;
					if(stepTimer){
						clearTimeout(stepTimer);
					}
					/*}#1H2E520ES0FunctionBody*/
				},
			},
			{
				"hash":"1H1LS2K200",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepdown.svg",null),"id":"BtnStepDown","x":0,"y":size*0.5,"enable":$P(()=>(state.enableDown),state),
				"padding":1,
				"OnButtonDown":function(code,event){
					/*#{1H2E52PJA0FunctionBody*/
					if(stepTimer){
						clearTimeout(stepTimer);
					}
					if(btnDown){
						btnDown=0;
						return;
					}
					btnDown=1;
					self.OnStep&&self.OnStep(-1);
					stepTimer=setTimeout(()=>{
						timerStep(-1);
					},500);
					/*}#1H2E52PJA0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E52QAT0FunctionBody*/
					btnDown=0;
					if(stepTimer){
						clearTimeout(stepTimer);
					}
					/*}#1H2E52QAT0FunctionBody*/
				},
			}
		],
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LRUDP21Setenable*/
			/*}#1H1LRUDP21Setenable*/
		},
		get $$enableUp(){return state["enableUp"]},
		set $$enableUp(v){
			state["enableUp"]=v;
			/*#{1H1LRUDP21SetenableUp*/
			/*}#1H1LRUDP21SetenableUp*/
		},
		get $$enableDown(){return state["enableDown"]},
		set $$enableDown(v){
			state["enableDown"]=v;
			/*#{1H1LRUDP21SetenableDown*/
			/*}#1H1LRUDP21SetenableDown*/
		},
		/*#{1H1LRUDP21ExtraCSS*/
		/*}#1H1LRUDP21ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnStepUp=self.BtnStepUp;btnStepDown=self.BtnStepDown;
			/*#{1H1LRUDP21Create*/
			/*}#1H1LRUDP21Create*/
		},
		/*#{1H1LRUDP21EndCSS*/
		/*}#1H1LRUDP21EndCSS*/
	};
	/*#{1H1LRUDP21PostCSSVO*/
	/*}#1H1LRUDP21PostCSSVO*/
	return cssVO;
};
/*#{1H1LRUDP21ExCodes*/
/*}#1H1LRUDP21ExCodes*/

BoxSteps.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("增减按钮"):("Step Button")),icon:"btn_step.svg",previewImg:false,
	fixPose:false,initW:20,initH:20,
	"desc":"2-buttons that increase or decrease value.",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20
		}
	},
	state:{
		enable:{name:"enable",type:"bool",initVal:true},
		enableUp:{name:"enableUp",type:"bool",initVal:true},
		enableDown:{name:"enableDown",type:"bool",initVal:true}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","attach"],
	faces:[],
	subContainers:{
	},
	/*#{1H1LRUDP20ExGearInfo*/
	/*}#1H1LRUDP20ExGearInfo*/
};
/*#{1H1LRUDP20EndDoc*/
/*}#1H1LRUDP20EndDoc*/

export default BoxSteps;
export{BoxSteps};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H1LRUDP20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1LRUDP22",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1LRUDP23",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8GMI9N00",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1LRUDP24",
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "20"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1LRUDP25",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1LRUDP26",
//			"attrs": {
//				"enable": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"enableUp": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"enableDown": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Step Button",
//			"localize": {
//				"EN": "Step Button",
//				"CN": "增减按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_step.svg",
//		"gearW": "20",
//		"gearH": "20",
//		"gearCatalog": "Buttons",
//		"description": "2-buttons that increase or decrease value.",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1LRUDP27",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I9VCNTQ90",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1LRUDP21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1LRUDP28",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "121",
//						"y": "141",
//						"w": "#size",
//						"h": "#size",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "${state.enable?1:0.6},state",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1LRVCO90",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H1LS2IUM0",
//									"attrs": {
//										"style": "front",
//										"w": "#size",
//										"h": "#size*0.5",
//										"icon": "#appCfg.sharedAssets+\"/stepup.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H1LS2IUM1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",size,size*0.5,appCfg.sharedAssets+\"/stepup.svg\",null)",
//										"id": "BtnStepUp",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"enable": "${state.enableUp},state",
//										"padding": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1LS2IUM2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1LS2IUM3",
//									"attrs": {
//										"OnButtonDown": {
//											"type": "fixedFunc",
//											"jaxId": "1H2E51V6T0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H2E52ABQ0",
//													"attrs": {
//														"code": "",
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnButtonUp": {
//											"type": "fixedFunc",
//											"jaxId": "1H2E520ES0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H2E52ABQ1",
//													"attrs": {
//														"code": "",
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H1LS2IUM4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1H2E4O2FS0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1LS2K200",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H1LS2K201",
//									"attrs": {
//										"style": "front",
//										"w": "#size",
//										"h": "#size*0.5",
//										"icon": "#appCfg.sharedAssets+\"/stepdown.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H1LS2K210",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",size,size*0.5,appCfg.sharedAssets+\"/stepdown.svg\",null)",
//										"id": "BtnStepDown",
//										"position": "Absolute",
//										"x": "0",
//										"y": "#size*0.5",
//										"display": "On",
//										"face": "",
//										"enable": "${state.enableDown},state",
//										"padding": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1LS2K211",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1LS2K212",
//									"attrs": {
//										"OnButtonDown": {
//											"type": "fixedFunc",
//											"jaxId": "1H2E52PJA0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H2E5383C0",
//													"attrs": {
//														"code": "",
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnButtonUp": {
//											"type": "fixedFunc",
//											"jaxId": "1H2E52QAT0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H2E5383C1",
//													"attrs": {
//														"code": "",
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H1LS2K213",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1H2E4O2FS1",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1LRUDP29",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1LRUDP210",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1LRUDP211",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LRUDP212",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "enable"
//				},
//				{
//					"type": "string",
//					"valText": "enableUp"
//				},
//				{
//					"type": "string",
//					"valText": "enableDown"
//				}
//			]
//		}
//	}
//}