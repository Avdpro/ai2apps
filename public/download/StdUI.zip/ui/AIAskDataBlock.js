//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "./BtnText.js";
/*#{1HR4IFBH60StartDoc*/
import {DataView} from "./DataView.js";
/*}#1HR4IFBH60StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let AIAskDataBlock=function(session,vo){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxData,boxButtons,btnNext;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HR4IFBH61LocalVals*/
	let dvData=null;
	let callback=null;
	let dvOptions={
		"titleHeight":30,
		"titleSize":18,
		"titleColor":cfgColor["fontBody"],
		"titleBold":true,
		"lineHeight":30,"lineGap":10,
		"labelSize":12,"labelColor":cfgColor["fontBodySub"],"labelLine":true,"labelBold":true,
		"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,
		"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],
		"trace":false,"edit":true,
		"noteSize":12
	};
	/*}#1HR4IFBH61LocalVals*/
	
	/*#{1HR4IFBH61PreState*/
	/*}#1HR4IFBH61PreState*/
	/*#{1HR4IFBH61PostState*/
	/*}#1HR4IFBH61PostState*/
	cssVO={
		"hash":"1HR4IFBH61",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,5,0,5],"minW":"","minH":30,"maxW":500,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HR4ITG6T0",
				"type":"hud","id":"BoxData","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
			},
			{
				"hash":"1HR4IU9MI0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"subAlign":1,"itemsAlign":1,
				children:[
					{
						"hash":"1HR4IVKPI0",
						"type":BtnText("primary",100,26,(($ln==="CN")?("下一步"):("Next")),false,""),"id":"BtnNext","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1HR4JQEVL0FunctionBody*/
							if(callback && dvData){
								let vo,json;
								vo=dvData.getEditedVO();
								json=JSON.stringify(vo);
								dvOptions.edit=false;
								dvData.setObject(null,vo);
								callback([json,vo]);
								btnNext.display=false;
								self.alpha=0.6;
							}
							/*}#1HR4JQEVL0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HR4IFBH61ExtraCSS*/
		/*}#1HR4IFBH61ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxData=self.BoxData;boxButtons=self.BoxButtons;btnNext=self.BtnNext;
			/*#{1HR4IFBH61Create*/
			/*}#1HR4IFBH61Create*/
		},
		/*#{1HR4IFBH61EndCSS*/
		/*}#1HR4IFBH61EndCSS*/
	};
	/*#{1HR4IFBH61PostCSSVO*/
	//------------------------------------------------------------------------
	let willCheck=false;
	cssVO.showBlock=function(input,_callback){
		callback=_callback;
		input.options=input.options||{};
		dvOptions={...dvOptions,...input.options};
		dvData=boxData.appendNewChild({
			"type":DataView(null,input.template,input.data,"",dvOptions,""),
			"id":"DvData","position":"relative","x":0,"y":0,
			OnEdit:function(){
				async function check(){
					let missing,vo,error,template;
					willCheck=false;
					error=false;
					this.clearErrorTips();
					missing=this.getMissing(false);
					if(missing){
						error=1;
					}
					vo=this.getEditedVO();
					if(input.OnEdit){
						error=(await input.OnEdit(session,this,vo))||error;
					}
					template=dvData.template;
					if(template.OnEdit){
						error=(await template.OnEdit(this,vo))||error;
					}
					btnNext.enable=!error;
				};
				if(!willCheck){
					btnNext.enable=false;
					willCheck=true;
					callAfter(()=>{
						check.call(this);
					},500,self);
				}
			}
		});
		boxButtons.display=!!dvOptions.edit;
		if(!dvOptions.edit){
			_callback(JSON.stringify(input.data),input.data);
		}
	};
	/*}#1HR4IFBH61PostCSSVO*/
	return cssVO;
};
/*#{1HR4IFBH61ExCodes*/
/*}#1HR4IFBH61ExCodes*/


/*#{1HR4IFBH60EndDoc*/
/*}#1HR4IFBH60EndDoc*/

export default AIAskDataBlock;
export{AIAskDataBlock};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HR4IFBH60",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HR4IFBH62",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HR4IFBH63",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HR4IFBH64",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HR4IFBH65",
//			"attrs": {
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"vo": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1HR4IOFQN0",
//					"attrs": {
//						"template": {
//							"type": "string",
//							"valText": ""
//						},
//						"dataObj": {
//							"type": "auto",
//							"valText": "null"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HR4IFBH66",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HR4IFBH67",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HR4IFBH68",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HR4IFBH69",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HR4IFBH61",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HR4IFBH610",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "500",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HR4ITG6T0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HR4IVIQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxData",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HR4IVIQ41",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HR4IVIQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HR4IVIQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HR4IU9MI0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HR4IVIQ44",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1HR4IVKPI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HR4J0TJ20",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "26",
//														"text": {
//															"type": "string",
//															"valText": "Next",
//															"localize": {
//																"EN": "Next",
//																"CN": "下一步"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HR4J0TJ21",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,26,(($ln===\"CN\")?(\"下一步\"):(\"Next\")),false,\"\")",
//														"id": "BtnNext",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HR4J0TJ22",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HR4J0TJ23",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HR4JQEVL0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HR4JQO5M0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HR4J0TJ24",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HR4J0TJ25",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1HR4J0TJ26",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HR4IVIQ45",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HR4IVIQ46",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HR4IVIQ47",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HR4IFBH611",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HR4IFBH612",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HR4IFBH613",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HR4IFBH614",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}