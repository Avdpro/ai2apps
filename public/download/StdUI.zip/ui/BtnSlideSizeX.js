//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G94H2G1P0StartDoc*/
/*}#1G94H2G1P0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnSlideSizeX=function(start,update,fin){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G94H2G1P7LocalVals*/
	let orgX;
	let dragging=0;
	/*}#1G94H2G1P7LocalVals*/
	
	/*#{1G94H2G1P7PreState*/
	/*}#1G94H2G1P7PreState*/
	/*#{1G94H2G1P7PostState*/
	/*}#1G94H2G1P7PostState*/
	cssVO={
		"hash":"1G94H2G1P7",nameHost:true,
		"type":"button","x":0,"y":0,"w":3,"h":"100%","cursor":"col-resize","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","drag":2,
		children:[
			{
				"hash":"1G94H64P10",
				"type":"box","x":0,"y":0,"w":"100%","h":"100%","display":0,"uiEvent":-1,"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.secondary,
			}
		],
		/*#{1G94H2G1P7ExtraCSS*/
		OnDragStart(evt){
			dragging=1;
			orgX=this.x;
			start && start(evt);
			self.showFace("drag");
		},
		OnDrag(e,dx,dy){
			let x;
			x=orgX+dx;
			if(update){
				x=update(e,x,dx);
			}
			this.x=x;	
		},
		OnDragEnd(e,dx,dy){
			let x;
			x=orgX+dx;
			if(update){
				x=update(e,x,dx);
			}
			if(fin){
				fin(e,x,dx);
			}
			self.showFace("up");
			dragging=0;
		},
		/*}#1G94H2G1P7ExtraCSS*/
		faces:{
			"up":{
				/*#{1G94HBPCR0PreCode*/
				$(){
					if(dragging)
						return false;
					return true;
				},
				/*}#1G94HBPCR0PreCode*/
				"#1G94H64P10":{
					"display":0
				}
			},"over":{
				/*#{1G94HBSRD0PreCode*/
				$(){
					if(dragging)
						return false;
					return true;
				},
				/*}#1G94HBSRD0PreCode*/
				"#1G94H64P10":{
					"display":1,"alpha":0.5
				}
			},"down":{
				/*#{1G94HC0S20PreCode*/
				$(){
					if(dragging)
						return false;
					return true;
				},
				/*}#1G94HC0S20PreCode*/
				"#1G94H64P10":{
					"display":1,"alpha":0.8
				}
			},"drag":{
				"#1G94H64P10":{
					"display":1,"alpha":0.8
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G94H2G1P7Create*/
			start=self.OnSlideStart||start;
			update=self.OnSlideUpdate||update;
			fin=self.OnSlideFin||fin;
			/*}#1G94H2G1P7Create*/
		},
		/*#{1G94H2G1P7EndCSS*/
		/*}#1G94H2G1P7EndCSS*/
	};
	/*#{1G94H2G1P7PostCSSVO*/
	/*}#1G94H2G1P7PostCSSVO*/
	return cssVO;
};
/*#{1G94H2G1P7ExCodes*/
/*}#1G94H2G1P7ExCodes*/

BtnSlideSizeX.gearExport={
	framework: "vfact",
	hudType: "button",
	"showName":"Slider X",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:3,initH:300,
	catalog:"Buttons",
	args: {
		"start": {
			"name": "start", "showName": "start", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"update": {
			"name": "update", "showName": "update", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"fin": {
			"name": "fin", "showName": "fin", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","cursor","zIndex"],
	faces:["up","over","down","drag"],
	subContainers:{
	},
	/*#{1G94H2G1P0ExGearInfo*/
	/*}#1G94H2G1P0ExGearInfo*/
};
/*#{1G94H2G1P0EndDoc*/
/*}#1G94H2G1P0EndDoc*/

export default BtnSlideSizeX;
export{BtnSlideSizeX};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G94H2G1P0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G94H2G1P1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G94H2G1P2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA2T4C9K0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G94H2G1P3",
//			"attrs": {
//				"start": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"update": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"fin": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G94H2G1P4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G94H2G1P5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "Slider X",
//		"gearIcon": "gears.svg",
//		"gearW": "3",
//		"gearH": "300",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G94H2G1P6",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G94HBPCR0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G94HGQQL0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G94HBSRD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G94HGQQL1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G94HC0S20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G94HGQQL2",
//							"attrs": {}
//						}
//					}
//				},
//				"drag": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G94HC5ST0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G94HGQQL3",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA2T4C9K1",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G94H2G1P7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G94H2G1P8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "3",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "col-resize",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "Pointer down"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G94H64P10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G94HGQQM0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.secondary",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G94HGQQM1",
//									"attrs": {
//										"1G94HBSRD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G94HGQQM2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G94HGQQM3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G94HBSRD0",
//											"faceTagName": "over"
//										},
//										"1G94HBPCR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G94HGQQM4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G94HGQQM5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G94HBPCR0",
//											"faceTagName": "up"
//										},
//										"1G94HC0S20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G94HGQQM6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G94HGQQM7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.8",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G94HC0S20",
//											"faceTagName": "down"
//										},
//										"1G94HC5ST0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G94HGQQM8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G94HGQQM9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.8",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G94HC5ST0",
//											"faceTagName": "drag"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G94HGQQM10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA2T4C9K2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G94H2G1P9",
//					"attrs": {
//						"1G94HBSRD0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G94HGQQM11",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G94HGQQM12",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G94HBSRD0",
//							"faceTagName": "over"
//						},
//						"1G94HBPCR0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G94HGQQM13",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G94HGQQM14",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G94HBPCR0",
//							"faceTagName": "up"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G94H2G1P10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IA2T4C9K3",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G94H2G1P11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}