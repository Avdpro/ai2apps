//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {PathCompareEntry} from "./PathCompareEntry.js";
import {PathCompareCenter} from "./PathCompareCenter.js";
/*#{1IM04Q3SR0StartDoc*/
import {readPath,readPathInfo} from "/@StdUI/FileUtils.js";
import {scanCompDir,quickCompDir} from "/@StdUI/CompareUtils.js";
/*}#1IM04Q3SR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let PathCompareLine=function(cmpView,entryObj,node,options){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let leftLine,btnCenter,rightLine;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let name=entryObj.name||"disk.json";
	let path=entryObj.path||"disk.json";
	let left=entryObj.left||{name:"disk.json",dir:false};
	let right=entryObj.right||{name:"disk.json",dir:false};
	let leftPath=entryObj.leftPath||"/AgentBuilder/agent.json";
	let rightPath=entryObj.rightPath||"/builder/disk.json";
	let indent=node.indent||0;
	
	/*#{1IM04Q3SR1LocalVals*/
	let dataDoc;
	let isDebug;
	dataDoc=options.dataDoc;
	left=entryObj.left;
	right=entryObj.right;
	/*}#1IM04Q3SR1LocalVals*/
	
	/*#{1IM04Q3SR1PreState*/
	/*}#1IM04Q3SR1PreState*/
	/*#{1IM04Q3SR1PostState*/
	/*}#1IM04Q3SR1PostState*/
	cssVO={
		"hash":"1IM04Q3SR1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1IM078OCR0",
				"type":PathCompareEntry(cmpView,node,left,node.indent||0,{"fontSize":options.fontSize,"allowDrop":true,"allowDrag":true,"height":options.height,"iconSize":options.iconSize,"color":cfgColor["fontBody"],"checkBox":false,"expandBtn":true,"indentSize":options.indentSize,"fileSize":true,"fileMenu":true}),
				"id":"LeftLine","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1IM079PVP0",
				"type":PathCompareCenter(entryObj,node),"id":"BtnCenter","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1IM07APSB0",
				"type":PathCompareEntry(cmpView,node,right,node.indent||0,{"fontSize":14,"allowDrop":true,"allowDrag":true,"height":24,"iconSize":20,"color":cfgColor["fontBody"],"checkBox":false,"expandBtn":true,"indentSize":15,"fileSize":true,"fileMenu":true}),
				"id":"RightLine","position":"relative","x":0,"y":0,
			}
		],
		/*#{1IM04Q3SR1ExtraCSS*/
		entry:entryObj,compEntry:entryObj,node:node,
		/*}#1IM04Q3SR1ExtraCSS*/
		faces:{
			"read":{
				"#self":{
					"uiEvent":-1
				},
				/*LeftLine*/"#1IM078OCR0":{
					"enable":false
				},
				/*RightLine*/"#1IM07APSB0":{
					"enable":false
				}
			},"ready":{
				"#self":{
					"uiEvent":1
				},
				/*LeftLine*/"#1IM078OCR0":{
					"enable":true
				},
				/*RightLine*/"#1IM07APSB0":{
					"enable":true
				}
			},"focus":{
				/*LeftLine*/"#1IM078OCR0":{
					"face":"focus"
				},
				/*RightLine*/"#1IM07APSB0":{
					"face":"focus"
				}
			},"blur":{
				/*LeftLine*/"#1IM078OCR0":{
					"face":"blur"
				},
				/*RightLine*/"#1IM07APSB0":{
					"face":"blur"
				}
			},"expand":{
				/*LeftLine*/"#1IM078OCR0":{
					"face":"expand"
				},
				/*RightLine*/"#1IM07APSB0":{
					"face":"expand"
				}
			},"collapse":{
				/*LeftLine*/"#1IM078OCR0":{
					"face":"collapse"
				},
				/*RightLine*/"#1IM07APSB0":{
					"face":"collapse"
				}
			},"select":{
				/*LeftLine*/"#1IM078OCR0":{
					"face":"select"
				},
				/*RightLine*/"#1IM07APSB0":{
					"face":"select"
				}
			}
		},
		OnCreate:function(){
			self=this;
			leftLine=self.LeftLine;btnCenter=self.BtnCenter;rightLine=self.RightLine;
			/*#{1IM04Q3SR1Create*/
			self.leftState="";
			self.rightState="";
			self.isNewState=false;
			self.update(false);
			leftLine.compEntry=entryObj;
			leftLine.side="Left";
			rightLine.compEntry=entryObj;
			rightLine.side="Right";
			leftLine.OnClick=function(event){
				self.OnLineClick(event,"Left");
			}
			rightLine.OnClick=function(event){
				self.OnLineClick(event,"Right");
			}
			btnCenter.OnClick=function(){
				switch(btnCenter.action){
					case "CopyToLeft":
						cmpView.copyToLeft(self);
						break;
					case "CopyToRight":
						cmpView.copyToRight(self);
						break;
				}
			}
			entryObj.hudLine=self;
			/*}#1IM04Q3SR1Create*/
		},
		/*#{1IM04Q3SR1EndCSS*/
		OnFree:function(){
			entryObj.hudLine=null;
		}
		/*}#1IM04Q3SR1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.update=async function(rescan){
		/*#{1IM1KC9FM0Start*/
		let leftInfo,rightInfo,pmLeft,pmRight;
		self.showFace("read");
		if(!left || !left.name){
			leftLine.showFace("hide");
			leftLine.display=true;
			//leftLine.display=false;
		}else{
			leftLine.showFace("show");
			leftLine.display=true;
			//leftLine.display=true;
		}
		if(!right || !right.name){
			rightLine.showFace("hide");
			rightLine.display=true;
			//rightLine.display=false;
		}else{
			rightLine.showFace("show");
			rightLine.display=true;
			//rightLine.display=true;
		}
		pmLeft=leftLine.update();
		pmRight=rightLine.update();
		[leftInfo,rightInfo]=await Promise.all([pmLeft,pmRight]);
		if(!leftInfo && !rightInfo){
			//Both side deleted:
			cmpView.removeEntryLine(self);
			return;
		}else if((leftInfo && leftInfo.dir) || (rightInfo && rightInfo.dir)){
			if(rescan || !entryObj.scaned){
				if(dataDoc){
					await scanCompDir(entryObj,dataDoc.excludePathSet,dataDoc.excludeTypeSet);
				}else{
					await scanCompDir(entryObj);
				}
			}else{
				await quickCompDir(entryObj);
			}
			self.setState(entryObj.leftState,entryObj.rightState);
		}else{
			//compare time:
			if(rescan || !entryObj.scaned){
				if(!leftInfo){
					self.setState("Old","More");
				}else if(!rightInfo){
					self.setState("More","Old");
				}else if(leftInfo.hash && leftInfo.hash===rightInfo.hash){
					self.setState("Same","Same");
				}else{
					if(leftInfo.modifyTime>0 && rightInfo.modifyTime>0){
						if(leftInfo.modifyTime>=rightInfo.modifyTime){
							self.setState("New","Old");
						}else{
							self.setState("Old","New");
						}
					}else{
						self.setState("New","New");
					}
				}
			}else{
				self.setState(entryObj.leftState,entryObj.rightState);
			}
		}
		btnCenter.updateState();
		self.showFace("ready");
		/*}#1IM1KC9FM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setState=async function(lState,rState){
		/*#{1IM1NUTCR0Start*/
		if(self.leftState===lState && self.rightState===rState){
			return;
		}
		entryObj.leftState=lState;
		entryObj.rightState=rState;
		entryObj.scaned=true;
		self.leftState=lState;
		self.rightState=rState;
		leftLine.setEntryState(lState);
		rightLine.setEntryState(rState);
		self.isNewState=true;
		/*}#1IM1NUTCR0Start*/
	};
	/*#{1IM04Q3SR1PostCSSVO*/
	/*}#1IM04Q3SR1PostCSSVO*/
	cssVO.constructor=PathCompareLine;
	return cssVO;
};
/*#{1IM04Q3SR1ExCodes*/
/*}#1IM04Q3SR1ExCodes*/

//----------------------------------------------------------------------------
PathCompareLine.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IM04Q3SR1PreAISpot*/
	/*}#1IM04Q3SR1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IM04Q3SR1PostAISpot*/
	/*}#1IM04Q3SR1PostAISpot*/
	return exposeVO;
};

/*#{1IM04Q3SR0EndDoc*/
/*}#1IM04Q3SR0EndDoc*/

export default PathCompareLine;
export{PathCompareLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IM04Q3SR0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IM04Q3SS0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IM04Q3SS1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IM04Q3SS2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IM04Q3SS3",
//			"attrs": {
//				"cmpView": {
//					"type": "auto",
//					"valText": ""
//				},
//				"entryObj": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"node": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"options": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1IM06HBLK2",
//					"attrs": {
//						"height": {
//							"type": "int",
//							"valText": "24"
//						},
//						"fontSize": {
//							"type": "int",
//							"valText": "14"
//						},
//						"iconSize": {
//							"type": "int",
//							"valText": "20"
//						},
//						"indentSize": {
//							"type": "int",
//							"valText": "15"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IM04Q3SS4",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "#entryObj.name||\"disk.json\""
//				},
//				"path": {
//					"type": "string",
//					"valText": "#entryObj.path||\"disk.json\""
//				},
//				"left": {
//					"type": "string",
//					"valText": "#entryObj.left||{name:\"disk.json\",dir:false}"
//				},
//				"right": {
//					"type": "string",
//					"valText": "#entryObj.right||{name:\"disk.json\",dir:false}"
//				},
//				"leftPath": {
//					"type": "string",
//					"valText": "#entryObj.leftPath||\"/AgentBuilder/agent.json\""
//				},
//				"rightPath": {
//					"type": "string",
//					"valText": "#entryObj.rightPath||\"/builder/disk.json\""
//				},
//				"indent": {
//					"type": "int",
//					"valText": "#node.indent||0"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IM04Q3SS5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM1KC9FM0",
//					"attrs": {
//						"id": "update",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM1KCGS00",
//							"attrs": {
//								"rescan": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM1KCGS01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM1KCGS02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM1NUTCR0",
//					"attrs": {
//						"id": "setState",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "155",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM1NVK030",
//							"attrs": {
//								"lState": {
//									"type": "string",
//									"valText": ""
//								},
//								"rState": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM1NVK031",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM1NVK032",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IM04Q3SS6",
//			"attrs": {
//				"read": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM1H96M10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM1HAMKU0",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM1H9BNS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM1HAMKU1",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM1HA9Q30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM1HAMKU2",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM1HAFK50",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM1HAMKU3",
//							"attrs": {}
//						}
//					}
//				},
//				"expand": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM2SF8530",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM2SGMLT0",
//							"attrs": {}
//						}
//					}
//				},
//				"collapse": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM2SFK4E0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM2SGMLT1",
//							"attrs": {}
//						}
//					}
//				},
//				"select": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM2TKP8N0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM2TMJ9P0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IM04Q3SS7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IM04Q3SR1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IM04Q3SS8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1IM06J4S40",
//							"jaxId": "1IM078OCR0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IM079GOJ0",
//									"attrs": {
//										"viewBox": "#cmpView",
//										"treeNode": "#node",
//										"entryObj": "#left",
//										"indent": "#node.indent||0",
//										"options": {
//											"jaxId": "1IM079GOJ1",
//											"attrs": {
//												"fontSize": "#options.fontSize",
//												"allowDrop": "true",
//												"allowDrag": "true",
//												"height": "#options.height",
//												"iconSize": "#options.iconSize",
//												"color": "#cfgColor[\"fontBody\"]",
//												"checkBox": "false",
//												"expandBtn": "true",
//												"indentSize": "#options.indentSize",
//												"fileSize": "true",
//												"fileMenu": "true"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1IM079GOJ2",
//									"attrs": {
//										"type": "#null#>PathCompareEntry(cmpView,node,left,node.indent||0,{\"fontSize\":options.fontSize,\"allowDrop\":true,\"allowDrag\":true,\"height\":options.height,\"iconSize\":options.iconSize,\"color\":cfgColor[\"fontBody\"],\"checkBox\":false,\"expandBtn\":true,\"indentSize\":options.indentSize,\"fileSize\":true,\"fileMenu\":true})",
//										"id": "LeftLine",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IM079GOJ3",
//									"attrs": {
//										"1IM1H96M10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1KGTUB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1KGTUB1",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1H96M10",
//											"faceTagName": "read"
//										},
//										"1IM1H9BNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1KHBRG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1KHBRG1",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1H9BNS0",
//											"faceTagName": "ready"
//										},
//										"1IM2SFK4E0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2SGMLT2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2SGMLT3",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"collapse\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2SFK4E0",
//											"faceTagName": "collapse"
//										},
//										"1IM2SF8530": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2SGMLT4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2SGMLT5",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"expand\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2SF8530",
//											"faceTagName": "expand"
//										},
//										"1IM2TKP8N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P2",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"select\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2TKP8N0",
//											"faceTagName": "select"
//										},
//										"1IM1HA9Q30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P4",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"focus\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1HA9Q30",
//											"faceTagName": "focus"
//										},
//										"1IM1HAFK50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P6",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"blur\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1HAFK50",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IM079GOJ4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM079GOJ5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IM079GOJ6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1IM04HNJU0",
//							"jaxId": "1IM079PVP0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IM07D4LR0",
//									"attrs": {
//										"entryObj": "#entryObj",
//										"node": "#node"
//									}
//								},
//								"properties": {
//									"jaxId": "1IM07D4LR1",
//									"attrs": {
//										"type": "#null#>PathCompareCenter(entryObj,node)",
//										"id": "BtnCenter",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IM07D4LR2",
//									"attrs": {
//										"1IM1H96M10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1KGTUB2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1KGTUB3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1H96M10",
//											"faceTagName": "read"
//										},
//										"1IM2SF8530": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2SGMLT8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2SGMLT9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2SF8530",
//											"faceTagName": "expand"
//										},
//										"1IM1HAFK50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P12",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1HAFK50",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IM07D4LR3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM07D4LR4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IM07D4LR5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1IM06J4S40",
//							"jaxId": "1IM07APSB0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IM07APSB1",
//									"attrs": {
//										"viewBox": "#cmpView",
//										"treeNode": "#node",
//										"entryObj": "#right",
//										"indent": "#node.indent||0",
//										"options": {
//											"jaxId": "1IM07APSC0",
//											"attrs": {
//												"fontSize": "14",
//												"allowDrop": "true",
//												"allowDrag": "true",
//												"height": "24",
//												"iconSize": "20",
//												"color": "#cfgColor[\"fontBody\"]",
//												"checkBox": "false",
//												"expandBtn": "true",
//												"indentSize": "15",
//												"fileSize": "true",
//												"fileMenu": "true"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1IM07APSC1",
//									"attrs": {
//										"type": "#null#>PathCompareEntry(cmpView,node,right,node.indent||0,{\"fontSize\":14,\"allowDrop\":true,\"allowDrag\":true,\"height\":24,\"iconSize\":20,\"color\":cfgColor[\"fontBody\"],\"checkBox\":false,\"expandBtn\":true,\"indentSize\":15,\"fileSize\":true,\"fileMenu\":true})",
//										"id": "RightLine",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IM07APSC2",
//									"attrs": {
//										"1IM1H96M10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1KGTUB4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1KGTUB5",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1H96M10",
//											"faceTagName": "read"
//										},
//										"1IM1H9BNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM1KHBRH2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM1KHBRH3",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1H9BNS0",
//											"faceTagName": "ready"
//										},
//										"1IM2SFK4E0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2SGMLT10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2SGMLT11",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"collapse\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2SFK4E0",
//											"faceTagName": "collapse"
//										},
//										"1IM2SF8530": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2SGMLT12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2SGMLT13",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"expand\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2SF8530",
//											"faceTagName": "expand"
//										},
//										"1IM2TKP8N0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P14",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"select\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM2TKP8N0",
//											"faceTagName": "select"
//										},
//										"1IM1HA9Q30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P15",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P16",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"focus\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1HA9Q30",
//											"faceTagName": "focus"
//										},
//										"1IM1HAFK50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM2TMJ9P17",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM2TMJ9P18",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"blur\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IM1HAFK50",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IM07APSC3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM07APSC4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IM07APSC5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IM04Q3SS9",
//					"attrs": {
//						"1IM1H96M10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM1KGTUB6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM1KGTUB7",
//									"attrs": {
//										"uiEvent": {
//											"type": "choice",
//											"valText": "Tree Off"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM1H96M10",
//							"faceTagName": "read"
//						},
//						"1IM1H9BNS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM1KHBRH4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM1KHBRH5",
//									"attrs": {
//										"uiEvent": {
//											"type": "choice",
//											"valText": "On"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM1H9BNS0",
//							"faceTagName": "ready"
//						},
//						"1IM2SF8530": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM2SGMLT16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM2SGMLT17",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM2SF8530",
//							"faceTagName": "expand"
//						},
//						"1IM1HAFK50": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM2TMJ9P23",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM2TMJ9P24",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IM1HAFK50",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IM04Q3SS10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IM04Q3SS11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IM04Q3SS12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}