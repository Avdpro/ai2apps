//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1KB50JO0StartDoc*/
/*}#1H1KB50JO0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnText=function(style,w,h,text,outlined,icon){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let colorFix=style?(style[0].toUpperCase()+style.substring(1)):"Primary";
	
	/*#{1H1KB50JO1LocalVals*/
	style=style||"primary";
	/*}#1H1KB50JO1LocalVals*/
	
	/*#{1H1KB50JO1PreState*/
	/*}#1H1KB50JO1PreState*/
	state={
		"corner":5,"text":text,"fontSize":h>0?(h>26?h-14:12):16,
		/*#{1H1KB50JP4ExState*/
		/*}#1H1KB50JP4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KB50JO1PostState*/
	/*}#1H1KB50JO1PostState*/
	cssVO={
		"hash":"1H1KB50JO1",nameHost:true,
		"type":"button","x":138,"y":84,"w":w,"h":h,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":1,
		children:[
			{
				"hash":"1H1KEE8D70",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":outlined?[0,0,0,0]:cfgColor[style],
				"border":outlined?1.5:0,"borderColor":cfgColor[style],"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KFRSGD0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":$P(()=>(state.fontSize+4),state),"h":$P(()=>(state.fontSize+4),state),"anchorY":1,
				"uiEvent":-1,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":outlined?cfgColor[style]:cfgColor["font"+colorFix],
				"attached":icon,"maskImage":icon,
			},
			{
				"hash":"1H1KEIIO50",
				"type":"text","id":"TxtText","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),
				"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
			},
			{
				"hash":"1H2F6U36O0",
				"type":"hud","id":"BoxRight","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1KB50JO1Settext*/
			/*}#1H1KB50JO1Settext*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KB50JO1Setcorner*/
			/*}#1H1KB50JO1Setcorner*/
		},
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1KB50JO1SetfontSize*/
			/*}#1H1KB50JO1SetfontSize*/
		},
		/*#{1H1KB50JO1ExtraCSS*/
		/*}#1H1KB50JO1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor[style],"y":0,"borderColor":cfgColor[style]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"over":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[cfgColor[style][0],cfgColor[style][1],cfgColor[style][2],0.25]:[...cfgColor[style],20],"y":0
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"down":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?cfgColor[style]:[...cfgColor[style],-20],"y":1
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":">calc(50% + 1px)"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":1
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":1
				}
			},"gray":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor["itemGray"],"borderColor":cfgColor["itemGray"]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1KB50JO1Create*/
			/*}#1H1KB50JO1Create*/
		},
		/*#{1H1KB50JO1EndCSS*/
		/*}#1H1KB50JO1EndCSS*/
	};
	/*#{1H1KB50JO1PostCSSVO*/
	/*}#1H1KB50JO1PostCSSVO*/
	return cssVO;
};
/*#{1H1KB50JO1ExCodes*/
/*}#1H1KB50JO1ExCodes*/

BtnText.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("文本按钮"):("Text Button")),icon:"btn_text.svg",previewImg:"./BtnText.png",
	fixPose:false,initW:100,initH:30,
	"desc":"Styled text button, can have an icon.",
	catalog:"Basic,Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "string", "key": true, "fixed": true, "initVal": "primary"
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 100
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 30
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Button", "localizable": true
		}, 
		"outlined": {
			"name": "outlined", "showName": "outlined", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": ""
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"Button",localizable:true},
		corner:{name:"corner",type:"int",initVal:5},
		fontSize:{name:"fontSize",type:"int",initVal:16}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","padding","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
		"1H2F6U36O0":{"showName":"BoxRight"}
	},
	/*#{1H1KB50JO0ExGearInfo*/
	/*}#1H1KB50JO0ExGearInfo*/
};
/*#{1H1KB50JO0EndDoc*/
/*}#1H1KB50JO0EndDoc*/

export default BtnText;
export{BtnText};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1KB50JO0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1KB50JP0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#appCfg.color.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1KB50JP1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H60R579L0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1KB50JP2",
//			"attrs": {
//				"style": {
//					"type": "string",
//					"valText": "primary"
//				},
//				"w": {
//					"type": "int",
//					"valText": "100"
//				},
//				"h": {
//					"type": "int",
//					"valText": "30"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Button",
//					"localizable": true
//				},
//				"outlined": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"icon": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1KB50JP3",
//			"attrs": {
//				"colorFix": {
//					"type": "string",
//					"valText": "#style?(style[0].toUpperCase()+style.substring(1)):\"Primary\""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1KB50JP4",
//			"attrs": {
//				"corner": {
//					"type": "int",
//					"valText": "5"
//				},
//				"text": {
//					"type": "string",
//					"valText": "#text",
//					"localizable": true
//				},
//				"fontSize": {
//					"type": "int",
//					"valText": "#h>0?(h>26?h-14:12):16"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Text Button",
//			"localize": {
//				"EN": "Text Button",
//				"CN": "文本按钮"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_text.svg",
//		"gearW": "100",
//		"gearH": "30",
//		"gearCatalog": "Basic,Buttons",
//		"description": "Styled text button, can have an icon.",
//		"fixPose": "false",
//		"previewImg": "./BtnText.png",
//		"faceTags": {
//			"jaxId": "1H1KB50JP5",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KBA35F0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "true",
//						"mockupNext": "over",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "1000",
//						"faceTimes": {
//							"jaxId": "1H1KBA35F1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KBA35F2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KBA35F3",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KBA35F4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KBA35F5",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1KBA35F6",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "true",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1KBA35F7",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA230KCK0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1KB50JO1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1KB50JP6",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "138",
//						"y": "84",
//						"w": "#w",
//						"h": "#h",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KEE8D70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KFF3U10",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#outlined?[0,0,0,0]:cfgColor[style]",
//										"border": "#outlined?1.5:0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[style]",
//										"corner": "${state.corner},state",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KFF3U11",
//									"attrs": {
//										"1H1KBA35F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?[0,0,0,0]:cfgColor[style]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[style]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F0",
//											"faceTagName": "up"
//										},
//										"1H1KBA35F2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?[cfgColor[style][0],cfgColor[style][1],cfgColor[style][2],0.25]:[...cfgColor[style],20]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F2",
//											"faceTagName": "over"
//										},
//										"1H1KBA35F4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?cfgColor[style]:[...cfgColor[style],-20]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F4",
//											"faceTagName": "down"
//										},
//										"1H1KBA35F6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KIK3A90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KIK3A91",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?[0,0,0,0]:cfgColor[\"itemGray\"]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemGray\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KFF3U12",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KFF3U13",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1KFRSGD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KG199J0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"w": "${state.fontSize+4},state",
//										"h": "${state.fontSize+4},state",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KG199J1",
//									"attrs": {
//										"1H1KBA35F2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q9",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F2",
//											"faceTagName": "over"
//										},
//										"1H1KBA35F4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q11",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?cfgColor[\"font\"+colorFix]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%+1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F4",
//											"faceTagName": "down"
//										},
//										"1H1KBA35F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q13",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "50%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F0",
//											"faceTagName": "up"
//										},
//										"1H1KBA35F6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KIS0C10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KIS0C11",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#outlined?cfgColor[\"itemGray\"]:cfgColor[\"font\"+colorFix]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KG199J2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KG199J3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1KEIIO50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KFF3U14",
//									"attrs": {
//										"type": "text",
//										"id": "TxtText",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,2,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1KFF3U15",
//									"attrs": {
//										"1H1KBA35F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q17",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F0",
//											"faceTagName": "up"
//										},
//										"1H1KBA35F2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q19",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#outlined?cfgColor[style]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F2",
//											"faceTagName": "over"
//										},
//										"1H1KBA35F4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KHVS3Q20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KHVS3Q21",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#outlined?cfgColor[\"font\"+colorFix]:cfgColor[\"font\"+colorFix]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F4",
//											"faceTagName": "down"
//										},
//										"1H1KBA35F6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1KIS0C20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1KIS0C21",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#outlined?cfgColor[\"itemGray\"]:cfgColor[\"font\"+colorFix]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1KFF3U16",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1KFF3U17",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2F6U36O0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2F70GVF0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxRight",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H2F70GVF1",
//									"attrs": {
//										"1H1KBA35F4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2HQON910",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2HQON911",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F4",
//											"faceTagName": "down"
//										},
//										"1H1KBA35F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2HQQUJC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2HQQUJC1",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F0",
//											"faceTagName": "up"
//										},
//										"1H1KBA35F2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2HQQUJC2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2HQQUJC3",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F2",
//											"faceTagName": "over"
//										},
//										"1H1KBA35F6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2HQQUJC4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H2HQQUJC5",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1KBA35F6",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H2F70GVF2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H2F70GVF3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1KB50JP7",
//					"attrs": {
//						"1H1KBA35F6": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1KIUEF70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1KIUEF71",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KBA35F6",
//							"faceTagName": "gray"
//						},
//						"1H1KBA35F4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HQQUJC6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2HQQUJC7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KBA35F4",
//							"faceTagName": "down"
//						},
//						"1H1KBA35F2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2HQQUJC8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H2HQQUJC9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KBA35F2",
//							"faceTagName": "over"
//						},
//						"1H1KBA35F0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3BIIRNO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H3BIIRNO1",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1KBA35F0",
//							"faceTagName": "up"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1KB50JP8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1KB50JP9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1KB50JP10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "text"
//				},
//				{
//					"type": "string",
//					"valText": "corner"
//				},
//				{
//					"type": "string",
//					"valText": "fontSize"
//				}
//			]
//		}
//	}
//}