//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {PathNaviView} from "./PathNaviView.js";
import {PathPreview} from "./PathPreview.js";
import {BtnText} from "./BtnText.js";
/*#{1I8OEKCIR0StartDoc*/
import {readPathInfo} from "../FileUtils.js";
import {tabFS} from "/@tabos";
import pathLib from "/@path";
/*}#1I8OEKCIR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgFile=function(title,closeIcon,buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,btnUpDir,edPath,pvFiles,boxPreview,edFileName,boxButtons,btnNewFolder,btnOpen,btnNo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO,preview,curPath,opts,mode,isEditing;
	app=window.tabOSApp;
	dlgVO=null;
	preview=true;
	curPath="/";
	isEditing=false;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,"btnText":"Open",
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":30,"w":640,"h":500,"anchorX":1,"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":12,"shadowBlur":10,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":25,"uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","alignV":1,
			},
			{
				"hash":"1I8OFKFAO0",
				"type":"hud","id":"BoxPath","position":"relative","x":0,"y":0,"w":"100%","h":24,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I8OFMCF20",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowupback.svg",null),"id":"BtnUpDir","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1I8Q1UMVF3FunctionBody*/
							self.gotoDir(pathLib.dirname(curPath));
							/*}#1I8Q1UMVF3FunctionBody*/
						},
					},
					{
						"hash":"1I8OFNOEQ0",
						"type":"edit","id":"EdPath","position":"relative","x":0,"y":0,"w":260,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("当前路径"):("Current path")),
						"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],
						"OnKeyDown":function(event){
							/*#{1I909RSAI0FunctionBody*/
							if(event.code==="Enter"){
								if((!event.isComposing) &&(!event.shiftKey)){
									let entry;
									event.stopPropagation();
									event.preventDefault();
									self.gotoDir(this.text);
								}
							}
							/*}#1I909RSAI0FunctionBody*/
						},
						"OnFocus":function(event){
							/*#{1I909S6JR0FunctionBody*/
							isEditing=true;
							/*}#1I909S6JR0FunctionBody*/
						},
						"OnBlur":function(event){
							/*#{1I909S8FE0FunctionBody*/
							isEditing=false;
							/*}#1I909S8FE0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1I8OFBRV30",
				"type":"hud","id":"BoxBody","position":"relative","x":0,"y":0,"w":"100%","h":100,"padding":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","flex":true,
				children:[
					{
						"hash":"1I8Q11N960",
						"type":"box","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":[1,0,1,0],"borderColor":cfgColor["fontBodyLit"],
					},
					{
						"hash":"1I8OFCCUA0",
						"type":PathNaviView({"path":"","dirOnly":false,"multiSelect":true,"allowDrop":true,"cacheSub":true,"prescanSub":false,"sort":"Name","filter":null},{"fontSize":txtSize.smallPlus,"allowDrop":true,"allowDrag":false,"height":24,"iconSize":20,"color":cfgColor.fontBody,"checkBox":false,"expandBtn":false,"indentSize":15,"fileSize":true,"fileMenu":true}),
						"id":"PvFiles","position":"relative","x":0,"y":0,"w":300,"h":"100%","minH":30,"flex":true,
					},
					{
						"hash":"1I8OH13GB0",
						"type":"box","position":"relative","x":0,"y":10,"w":1,"h":">calc(100% - 20px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
					},
					{
						"hash":"1I8OFG05S0",
						"type":"hud","id":"BoxPreview","position":"relative","x":0,"y":0,"w":250,"h":"100%","overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1I8T0QO6E0",
								"type":PathPreview({"readOnly":true,"showImage":true,"showContent":true,"showVersion":false,"showCloud":false,"showTool":false}),"id":"BoxPreview",
								"position":"relative","x":0,"y":0,
							}
						],
					}
				],
			},
			{
				"hash":"1I8OFQBIT0",
				"type":"edit","id":"EdFileName","position":"relative","x":0,"y":0,"w":320,"h":20,"margin":[10,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"placeHolder":(($ln==="CN")?("选中的内容"):("Selected")),"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.smallPlus,"outline":0,
				"border":[0,0,1,0],
				"OnFocus":function(event){
					/*#{1I90B4BOP0FunctionBody*/
					/*}#1I90B4BOP0FunctionBody*/
				},
				"OnBlur":function(event){
					/*#{1I90B4EBN0FunctionBody*/
					/*}#1I90B4EBN0FunctionBody*/
				},
				"OnKeyDown":function(event){
					/*#{1I90B4H7H0FunctionBody*/
					if(event.code==="Enter"){
						if((!event.isComposing) &&(!event.shiftKey)){
							let entry;
							event.stopPropagation();
							event.preventDefault();
							self.useSelected();
						}
					}
					/*}#1I90B4H7H0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1I8OHD4IU0",
						"type":BtnText("secondary",100,24,(($ln==="CN")?("新建文件夹"):("New folder")),false,""),"id":"BtnNewFolder","position":"relative","x":0,"y":"50%","anchorY":1,
						"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1I8OHD4IV0FunctionBody*/
							self.newFolder();
							/*}#1I8OHD4IV0FunctionBody*/
						},
					},
					{
						"hash":"1I8OHE6T10",
						"type":"hud","position":"relative","x":0,"y":0,"w":10,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
					},
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,(($ln==="CN")?("打开"):("Open")),false,""),"id":"BtnOpen","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"text":$P(()=>(state.btnText),state),
						"OnClick":function(event){
							self.useSelected(this,event);
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("secondary",80,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(false);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
			"preview":{
				"#self":{
					"w":640
				},
				"#1I8OH13GB0":{
					"display":1
				},
				/*BoxPreview*/"#1I8OFG05S0":{
					"display":1
				}
			},"!preview":{
				"#self":{
					"w":500
				},
				"#1I8OH13GB0":{
					"display":0
				},
				/*BoxPreview*/"#1I8OFG05S0":{
					"display":0
				}
			},"mobile":{
				"#self":{
					"w":360
				},
				"#1I8OH13GB0":{
					"display":0
				},
				/*BoxPreview*/"#1I8OFG05S0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;btnUpDir=self.BtnUpDir;edPath=self.EdPath;pvFiles=self.PvFiles;boxPreview=self.BoxPreview;edFileName=self.EdFileName;boxButtons=self.BoxButtons;btnNewFolder=self.BtnNewFolder;btnOpen=self.BtnOpen;btnNo=self.BtnNo;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			pvFiles.onNotify("FocusPath",()=>{
				let node,list;
				list=pvFiles.getSelection(false);
				if(list.length>1){
					let names;
					names=list.map((node)=>node.nodeObj.name);
					edFileName.text=JSON.stringify(names);
					list=list.map((node)=>node.nodeObj);
					self.showPreview(list);
				}else{
					node=pvFiles.focusedNode;
					if(node){
						edFileName.text=node.nodeObj.name;
						self.showPreview(node.nodeObj.path);
					}else{
						edFileName.text="";
						self.showPreview(curPath);
					}
				}
			});
			pvFiles.onNotify("OpenDir",()=>{
				let node;
				node=pvFiles.focusedNode;
				if(node){
					let entry=node.nodeObj;
					if(entry.dir){
						self.showPath(entry.path);
					}
				}
			});
			pvFiles.onNotify("OpenFile",self.useSelected);
			pvFiles.lineOpts.fileMenuOps=["Open","Copy","Rename","Delete"];
			pvFiles.lineOpts.handleFileMenu=async (action,hud,entry)=>{
				switch(action){
					case "Open":{
						if(entry.dir){
							self.showPath(entry.path);
						}else{
							let node;
							node=await pvFiles.showPathNode(entry.path,false,true);
							edFileName.text=entry.name;
							self.useSelected();
						}
						return;
					}
					case "Delete":{
						let nodes,i,n,node,treeBox,oldIdx;
						treeBox=pvFiles.TbView;
						nodes=pvFiles.getSelection().reverse();
						if(!nodes || !nodes.length){
							node=hud.treeNode;
							if(!node){
								return;
							}
							nodes=[node];
						}
						if(!window.confirm((($ln==="CN")?("您确定要删除选定的项目吗？"):/*EN*/("Are you sure to delete selected item(s)?")))){
							return;
						}
						oldIdx=treeBox.indexOfNode(hud.treeNode);
						app.showWait((($ln==="CN")?("正在删除项目..."):/*EN*/("Deleting items...")));
						treeBox.pauseCallback++;
						n=nodes.length;
						for(i=0;i<n;i++){
							node=nodes[i];
							await tabFS.del(node.nodeObj.path);
							treeBox.removeNode(node);
						}
						treeBox.pauseCallback--;
						if(oldIdx>=0){
							node=treeBox.nodes[oldIdx];
							if(node){
								treeBox.hotNode=node;
							}else{
								treeBox.hotNode=null;
							}
						}
						app.closeWait();
						return;
					}
					case "Rename":{
						let treeBox,node,newName,dir,path;
						treeBox=pvFiles.TbView;
						newName=window.prompt((($ln==="CN")?("请输入新名称:"):/*EN*/("Input new name:")),entry.name);
						if(!newName){
							return;
						}
						if(newName===entry.name){
							return;
						}
						dir=pathLib.dirname(entry.path);
						path=pathLib.join(dir,newName);
						if(await tabFS.isExist(path)){
							window.alert((($ln==="CN")?(`名称为${path}的项目已存在，不能使用这个名字。`):/*EN*/(`Item named ${path} already exists and cannot use this name.`)));
							return;
						}
						
						node=hud.treeNode;
						//Make sure no dirty-sub nodes:
						treeBox.closeNode(node);
						node.subItems=null;
						//Rename the file
						if(await tabFS.move(entry.path,path)){
							//Update entry and hud
							entry.name=newName;
							entry.path=path;
							hud.rename(newName);
						}
						return;
					}
					case "Copy":{
						let vo,treeBox,nodes;
						treeBox=pvFiles.TbView;
						nodes=pvFiles.getSelection();
						if(!nodes || !nodes.length){
							return;
						}
						vo={
							basePath:curPath,
							files:nodes.map((node)=>{return node.nodeObj?node.nodeObj.path:null;})
						};
						let theClipboard = navigator.clipboard;
						theClipboard.writeText(`{"$CokeFilesCopy":${JSON.stringify(vo)}}`);
						return;
					}
				}
			};
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showPath=async function(path){
		/*#{1I8OJNTML0Start*/
		edPath.text=path;
		curPath=path;
		await pvFiles.viewPath(path,opts);
		btnUpDir.enable=(curPath && curPath!=="/");
		self.showPreview(curPath);
		/*}#1I8OJNTML0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkFileName=async function(){
		/*#{1I8OJO3HH0Start*/
		/*}#1I8OJO3HH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showPreview=async function(path){
		/*#{1I8OKFVNO0Start*/
		let entry;
		if(Array.isArray(path)){//When pass-in array, must be array of entry
			boxPreview.setEntry(path);
			return;
		}
		entry=await readPathInfo(path);
		if(entry){
			boxPreview.setEntry(entry);
		}else{
			entry=await readPathInfo(curPath);
			boxPreview.setEntry(entry);
		}
		/*}#1I8OKFVNO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.newFolder=async function(){
		/*#{1I8OKGENL0Start*/
		let name,dirPath;
		if(curPath==="/"){
			return;
		}
		name=window.prompt("New folder name: ","New folder");
		if(!name){
			return;
		}
		//Check name 
		let checker=/^[ .A-Za-z0-9_-]{1,1024}$/;
		if(!checker.test(name)){
			window.alert("Wrong name: name should be 1~1024 chars, only allow 'A'~'Z', 'a'~'z', '0'~'9', '-', '_', '.', or space");
			return;
		}
		dirPath=pathLib.join(curPath,name);
		if(await tabFS.newDir(dirPath)){
			self.gotoPath(dirPath);
		}
		/*}#1I8OKGENL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.gotoDir=async function(path){
		/*#{1I8Q1T5610Start*/
		let entry=await readPathInfo(path);
		if(!entry || !entry.dir){
			window.alert((($ln==="CN")?(`${path} 不是一个文件夹！`):/*EN*/(`${path} is not a folder!`)));
			//edPath.text=curPath;
			return;
		}
		self.showPath(path);
		/*}#1I8Q1T5610Start*/
	};
	//------------------------------------------------------------------------
	cssVO.useSelected=async function(){
		/*#{1I8QAMTNO0Start*/
		let fileName,path,entry;
		fileName=edFileName.text;
		if(fileName){
			if(opts.multiSelect && fileName.startsWith("[" && fileName.endsWith("]"))){
				let list,fname,path,result;
				try{
					result=[];
					list=JSON.parse(fileName);
					for(fname of list){
						path=pathLib.join(curPath,fname);
						entry=await readPathInfo(path);
						if(entry){
							if(entry.dir){
								if(opts.dirOnly){
									result.push(path);
								}
							}else{
								if(!opts.dirOnly){
									result.push(path);
								}
							}
						}
					}
					if(result.length>0){
						if(opts.checkPath){
							let check=await opts.checkPath(result);
							if(check===false){
								return;
							}
						}
						self.close(result);
					}
				}catch(err){
					window.alert("Something wrong with your file selection.");
				}
			}else{
				path=pathLib.join(curPath,fileName);
				entry=await readPathInfo(path);
				if(!entry){
					if(mode==="save"){
						//Check path
						if(opts.checkPath){
							let check=await opts.checkPath(path,entry);
							if(check===false){
								return;
							}
						}
						self.close(path);
						return;
					}else{
						if(window.confirm((($ln==="CN")?(`${fileName} 不存在，是否仍然打开？`):/*EN*/(`${fileName} is not exist, open it anyway?`)))){
							if(opts.checkPath){
								let check=await opts.checkPath(path,entry);
								if(check===false){
									return;
								}
							}
							self.close(path);
							return;
						}else{
							edFileName.focus();
							edFileName.selectAll();
						}
						return;
					}
				}
				if(mode==="save"){
					if(!window.confirm(`File ${path} already exist, are you sure to overwrite it?`)){
						return;
					}
				}
				//Check path
				if(opts.checkPath){
					let check=await opts.checkPath(path,entry);
					if(check===false){
						return;
					}
				}
				if(entry.dir){
					if(opts.dirOnly){
						self.close(entry.path);
					}else{
						self.showPath(path);
					}
				}else{
					self.close(path);
				}
			}
		}
		/*}#1I8QAMTNO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		/*#{1I8R0058A0Start*/
		switch(cmd){
			case "Escape":
				self.close(null);
				break;
		}
		/*}#1I8R0058A0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnKeyDown=function(keyCode,evt){
		/*#{1I90G01ET0Start*/
		switch(keyCode){
			case "Escape":
				self.close(null);
				return true;
			case "ArrowUp":
			case "ArrowDown":
				if(isEditing){
					return false;
				}
				pvFiles.OnKeyDown(keyCode,evt);
				return true;
		}
		return false;
		/*}#1I90G01ET0Start*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		curPath=vo.path;
		opts=vo.options||{};
		//Mode:
		mode=(vo.mode||"open").toLowerCase();
		//Filter:
		opts.filter=opts.filter||vo.filter;
		//Multi-selection:
		opts.multiSelect=(!!vo.multiSelect)&&(mode==="open");
		opts.dirOnly=!!opts.dirOnly;
		
	
		//Set view-size:
		if(app.width<=400){
			preview=0;
			self.showFace("mobile");
		}else if(vo.preview||opts.preview){
			preview=1;
			self.showFace("preview");
		}else{
			preview=0;
			self.showFace("!preview");
		}
		
		//Title:
		if(vo.title){
			state.title=vo.title;
		}else{
			if(mode==="open"){
				if(opts.multiSelect){
					state.title=(($ln==="CN")?("选择文件"):/*EN*/("Select File(s)"));
				}else{
					state.title=(($ln==="CN")?("选择文件"):/*EN*/("Select File"));
				}
			}else{
				mode="save";
				state.title=(($ln==="CN")?("保存文件"):/*EN*/("Save File"));
			}
		}
		
		//Open button text:
		if(vo.buttonText){
			state.btnText=vo.buttonText;
		}else{
			if(mode==="open"){
				state.btnText=(($ln==="CN")?("打开"):/*EN*/("Open"));
			}else if(mode==="save"){
				state.btnText=(($ln==="CN")?("保存"):/*EN*/("Save"));
			}
		}
		//FileName:
		if(vo.fileName){
			let fpath;
			self.EdFileName.text=vo.fileName;
			fpath=pathLib.join(curPath,vo.fileName);
			self.checkFileName();
		}else{
			self.EdFileName.text="";
		}
		self.showPath(curPath);
		self.animate({
			type:"in",alpha:0,scale:0.95,time:80,
			OnFinish(){
				edFileName.focus();
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	cssVO.constructor=DlgFile;
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

//----------------------------------------------------------------------------
DlgFile.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1T7ISV51PreAISpot*/
	/*}#1H1T7ISV51PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("标准对话框"):("Standard Dialog"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1T7ISV51PostAISpot*/
	/*}#1H1T7ISV51PostAISpot*/
	return exposeVO;
};

/*#{1I8OEKCIR0EndDoc*/
/*}#1I8OEKCIR0EndDoc*/

export default DlgFile;
export{DlgFile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I8OEKCIR0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Open file",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#buttons"
//				},
//				"btnText": {
//					"type": "string",
//					"valText": "Open"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8OJNTML0",
//					"attrs": {
//						"id": "showPath",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8OJOD5P0",
//							"attrs": {
//								"path": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8OJOD5P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8OJOD5P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8OJO3HH0",
//					"attrs": {
//						"id": "checkFileName",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "140",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8OJOD5Q0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8OJOD5Q1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8OJOD5Q2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8OKFVNO0",
//					"attrs": {
//						"id": "showPreview",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "230",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8OKHVDC0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8OKHVDC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8OKHVDC2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8OKGENL0",
//					"attrs": {
//						"id": "newFolder",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "320",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8OKHVDC3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8OKHVDC4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8OKHVDC5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8Q1T5610",
//					"attrs": {
//						"id": "gotoDir",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "410",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8Q1UMVF0",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8Q1UMVF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8Q1UMVF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8QAMTNO0",
//					"attrs": {
//						"id": "useSelected",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "500",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8QANVGB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8QANVGB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8QANVGB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I8R0058A0",
//					"attrs": {
//						"id": "handleShortcut",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "590",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I8R00R4C0",
//							"attrs": {
//								"cmd": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I8R00R4C1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I8R00R4C2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I90G01ET0",
//					"attrs": {
//						"id": "OnKeyDown",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "675",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I90G0R3U0",
//							"attrs": {
//								"keyCode": {
//									"type": "string",
//									"valText": ""
//								},
//								"evt": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I90G0R3U1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I90G0R3U2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {
//				"preview": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8OF7FRV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8OFVVQS0",
//							"attrs": {}
//						}
//					}
//				},
//				"!preview": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8OF80E10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8OFVVQS1",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I8OILAQJ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I8OIMT7E0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I8OEIDG90",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "30",
//						"w": "640",
//						"h": "500",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "12",
//										"shadowBlur": "10",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7E2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7E3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "25",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.midPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7E4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7E5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I8OFKFAO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OFVVQS6",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxPath",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KJQ5RK0",
//											"jaxId": "1I8OFMCF20",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8OFVVQS7",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/arrowupback.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I8OFVVQS8",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowupback.svg\",null)",
//														"id": "BtnUpDir",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OFVVQS9",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OFVVQS10",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8Q1UMVF3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8Q1UMVF4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OFVVQS11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8OFVVQS12",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1I8OFNOEQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OFVVQS13",
//													"attrs": {
//														"type": "edit",
//														"id": "EdPath",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "260",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": {
//															"type": "string",
//															"valText": "Current path",
//															"localize": {
//																"EN": "Current path",
//																"CN": "当前路径"
//															},
//															"localizable": true
//														},
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "#cfgColor[\"body\"]",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OFVVQS14",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OFVVQS15",
//													"attrs": {
//														"OnKeyDown": {
//															"type": "fixedFunc",
//															"jaxId": "1I909RSAI0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I909THLL0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														},
//														"OnFocus": {
//															"type": "fixedFunc",
//															"jaxId": "1I909S6JR0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I909THLL1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														},
//														"OnBlur": {
//															"type": "fixedFunc",
//															"jaxId": "1I909S8FE0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I909THLL2",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OFVVQS16",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I8OFVVQS17",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7F4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7F5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8OFVVQS18",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8OFVVQS19",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I8OFBRV30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OFVVQS20",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBody",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I8Q11N960",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8Q13QT30",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[1,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8Q13QT31",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I8Q13QT32",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8Q13QT33",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I8JBEEAD0",
//											"jaxId": "1I8OFCCUA0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8OFCCUA1",
//													"attrs": {
//														"options": {
//															"jaxId": "1I8OFCCUA2",
//															"attrs": {
//																"path": "",
//																"dirOnly": "false",
//																"multiSelect": "true",
//																"allowDrop": "true",
//																"cacheSub": "true",
//																"prescanSub": "false",
//																"sort": "Name",
//																"filter": "null"
//															}
//														},
//														"lineOpts": {
//															"jaxId": "1I8OFCCUA3",
//															"attrs": {
//																"fontSize": "#txtSize.smallPlus",
//																"allowDrop": "true",
//																"allowDrag": "false",
//																"height": "24",
//																"iconSize": "20",
//																"color": "#cfgColor.fontBody",
//																"checkBox": "false",
//																"expandBtn": "false",
//																"indentSize": "15",
//																"fileSize": "true",
//																"fileMenu": "true"
//															}
//														}
//													}
//												},
//												"properties": {
//													"jaxId": "1I8OFCCUA4",
//													"attrs": {
//														"type": "#null#>PathNaviView({\"path\":\"\",\"dirOnly\":false,\"multiSelect\":true,\"allowDrop\":true,\"cacheSub\":true,\"prescanSub\":false,\"sort\":\"Name\",\"filter\":null},{\"fontSize\":txtSize.smallPlus,\"allowDrop\":true,\"allowDrag\":false,\"height\":24,\"iconSize\":20,\"color\":cfgColor.fontBody,\"checkBox\":false,\"expandBtn\":false,\"indentSize\":15,\"fileSize\":true,\"fileMenu\":true})",
//														"id": "PvFiles",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"w": "300",
//														"h": "100%",
//														"minH": "30",
//														"flex": "true",
//														"padding": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OFCCUA5",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OFCCUB2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OFCCUB3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8OFCCUB4",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I8OH13GB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OH4NQA12",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "10",
//														"w": "1",
//														"h": "100%-20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodyLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OH4NQA13",
//													"attrs": {
//														"1I8OF7FRV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OH4NQA14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OH4NQA15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF7FRV0",
//															"faceTagName": "preview"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OH4NQA16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OH4NQA17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														},
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OH4NQA18",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OH4NQA19",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I8OFG05S0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OFVVQS23",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxPreview",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "250",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "5",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1I8R9NI5A0",
//															"jaxId": "1I8T0QO6E0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I8T0R9U10",
//																	"attrs": {
//																		"options": {
//																			"jaxId": "1I8T0R9U11",
//																			"attrs": {
//																				"readOnly": "true",
//																				"showImage": "true",
//																				"showContent": "true",
//																				"showVersion": "false",
//																				"showCloud": "false",
//																				"showTool": "false"
//																			}
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I8T0R9U12",
//																	"attrs": {
//																		"type": "#null#>PathPreview({\"readOnly\":true,\"showImage\":true,\"showContent\":true,\"showVersion\":false,\"showCloud\":false,\"showTool\":false})",
//																		"id": "BoxPreview",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I8T0R9U13",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I8T0R9U14",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I8T0R9U15",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I8T0R9U16",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I8OFVVQS24",
//													"attrs": {
//														"1I8OF7FRV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OFVVQS25",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OFVVQS26",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF7FRV0",
//															"faceTagName": "preview"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OFVVQT0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OFVVQT1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														},
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OFVVQT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OFVVQT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I8OFVVQT4",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7F12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7F13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8OFVVQT7",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I8OFVVQT8",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1I8OFQBIT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OFVVQT9",
//									"attrs": {
//										"type": "edit",
//										"id": "EdFileName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "320",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "",
//										"placeHolder": {
//											"type": "string",
//											"valText": "Selected",
//											"localize": {
//												"EN": "Selected",
//												"CN": "选中的内容"
//											},
//											"localizable": true
//										},
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "#cfgColor[\"body\"]",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I8OFVVQT10",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7F14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7F15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I8OFVVQT11",
//									"attrs": {
//										"OnFocus": {
//											"type": "fixedFunc",
//											"jaxId": "1I90B4BOP0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I90B5J8J0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnBlur": {
//											"type": "fixedFunc",
//											"jaxId": "1I90B4EBN0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I90B5J8J1",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnKeyDown": {
//											"type": "fixedFunc",
//											"jaxId": "1I90B4H7H0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I90B5J8J2",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I8OFVVQT12",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false",
//										"itemsAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1I8OHD4IU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I8OHD4IU1",
//													"attrs": {
//														"style": "secondary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "New folder",
//															"localize": {
//																"EN": "New folder",
//																"CN": "新建文件夹"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I8OHD4IU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",100,24,(($ln===\"CN\")?(\"新建文件夹\"):(\"New folder\")),false,\"\")",
//														"id": "BtnNewFolder",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OHD4IU3",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OHD4IU6",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I8OHD4IV0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I8OHD4IV1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OHD4IV2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I8OHD4IV3",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I8OHD4IV4",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I8OHE6T10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OHGKVF0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "10",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I8OHGKVF1",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I8OHGKVF2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I8OHGKVF3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "#\"Open\"",
//															"localize": {
//																"EN": "#\"Open\"",
//																"CN": "#\"打开\""
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,(($ln===\"CN\")?(\"打开\"):(\"Open\")),false,\"\")",
//														"id": "BtnOpen",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "${state.btnText},state",
//															"localizable": true
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JCTG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I8QAMTNO0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T820FU1",
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "#\"Cancel\"",
//															"localize": {
//																"EN": "#\"Cancel\"",
//																"CN": "#\"取消\""
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T820FU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T820FU3",
//													"attrs": {
//														"1I8OILAQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIMT7F22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIMT7F23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OILAQJ0",
//															"faceTagName": "mobile"
//														},
//														"1I8OF80E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I8OIQ69H22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I8OIQ69H23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I8OF80E10",
//															"faceTagName": "!preview"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1T820FU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JQQ40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T820FU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V2",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {
//										"1I8OILAQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIMT7F24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIMT7F25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OILAQJ0",
//											"faceTagName": "mobile"
//										},
//										"1I8OF80E10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I8OIQ69H24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I8OIQ69H25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I8OF80E10",
//											"faceTagName": "!preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {
//						"1I8OF80E10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8OFVVQT19",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OFVVQT20",
//									"attrs": {
//										"w": {
//											"type": "length",
//											"valText": "500"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8OF80E10",
//							"faceTagName": "!preview"
//						},
//						"1I8OF7FRV0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8OFVVQT21",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OFVVQT22",
//									"attrs": {
//										"w": {
//											"type": "length",
//											"valText": "640"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8OF7FRV0",
//							"faceTagName": "preview"
//						},
//						"1I8OILAQJ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I8OIMT7F26",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I8OIMT7F27",
//									"attrs": {
//										"w": {
//											"type": "length",
//											"valText": "360"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I8OILAQJ0",
//							"faceTagName": "mobile"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}