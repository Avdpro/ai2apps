//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HJAR4GIA0StartDoc*/
/*}#1HJAR4GIA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxSyncSubDir=function(dirVO){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HJAR4GIA1LocalVals*/
	/*}#1HJAR4GIA1LocalVals*/
	
	/*#{1HJAR4GIA1PreState*/
	/*}#1HJAR4GIA1PreState*/
	state={
		"syncName":dirVO.target,"syncDir":dirVO.dir,
		/*#{1HJAR4GIA7ExState*/
		/*}#1HJAR4GIA7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HJAR4GIA1PostState*/
	/*}#1HJAR4GIA1PostState*/
	cssVO={
		"hash":"1HJAR4GIA1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HJAR64P80",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"Sync target:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HJAR7K7H0",
				"type":"edit","id":"EdTarget","position":"relative","x":15,"y":0,"w":">calc(100% - 60px)","h":20,"margin":[3,0,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","text":dirVO.target||"","color":cfgColor["fontBody"],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
			},
			{
				"hash":"1HJAR8P4R0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"Sub dir:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HJAR9C040",
				"type":"edit","id":"EdDir","position":"relative","x":15,"y":0,"w":">calc(100% - 30px)","h":20,"margin":[3,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","text":dirVO.dir,"color":cfgColor["fontBody"],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
			},
			{
				"hash":"1HJARB25A0",
				"type":BtnIcon("front",30,30,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","x":">calc(100% - 40px)","y":10,"padding":2,
				"OnClick":function(event){
					/*#{1HJARQA1N0FunctionBody*/
					if(self.OnSubDirRemove){
						self.OnSubDirRemove(self);
					}
					/*}#1HJARQA1N0FunctionBody*/
				},
			},
			{
				"hash":"1I6414JC60",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"Filter:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1I6415LV80",
				"type":"edit","id":"EdFilter","position":"relative","x":15,"y":0,"w":">calc(100% - 30px)","h":20,"margin":[3,0,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","text":dirVO.filter||"","placeHolder":"filter-js-file url, like: /@myagent/myfilter.js","color":cfgColor["fontBody"],"fontSize":txtSize.smallPlus,
				"outline":0,"border":[0,0,1,0],"autoSelect":false,"spellCheck":false,
			},
			{
				"hash":"1IEJKHC540",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"Ignores:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1IEJKHUJH0",
				"type":"edit","id":"EdIgnore","position":"relative","x":15,"y":0,"w":">calc(100% - 30px)","h":20,"margin":[3,0,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","text":dirVO.ignore?""+dirVO.ignore.join(";"):"","placeHolder":"item path, sperate with \";\"","color":cfgColor["fontBody"],
				"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],"autoSelect":false,"spellCheck":false,
			}
		],
		/*#{1HJAR4GIA1ExtraCSS*/
		/*}#1HJAR4GIA1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HJAR4GIA1Create*/
			/*}#1HJAR4GIA1Create*/
		},
		/*#{1HJAR4GIA1EndCSS*/
		/*}#1HJAR4GIA1EndCSS*/
	};
	/*#{1HJAR4GIA1PostCSSVO*/
	/*}#1HJAR4GIA1PostCSSVO*/
	cssVO.constructor=BoxSyncSubDir;
	return cssVO;
};
/*#{1HJAR4GIA1ExCodes*/
/*}#1HJAR4GIA1ExCodes*/

//----------------------------------------------------------------------------
BoxSyncSubDir.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HJAR4GIA1PreAISpot*/
	/*}#1HJAR4GIA1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="SyncSubDir";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HJAR4GIA1PostAISpot*/
	/*}#1HJAR4GIA1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxSyncSubDir.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"SyncSubDir",icon:"folder.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"dirVO": {
			"name": "dirVO", "showName": "dirVO", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"target":"SYNC/handler","dir":"handler"}, "initValText": "#{target:\"SYNC/handler\",dir:\"handler\"}"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1HJAR4GIA0ExGearInfo*/
	/*}#1HJAR4GIA0ExGearInfo*/
};
/*#{1HJAR4GIA0EndDoc*/
/*}#1HJAR4GIA0EndDoc*/

export default BoxSyncSubDir;
export{BoxSyncSubDir};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HJAR4GIA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HJAR4GIA2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HJAR4GIA3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HJAR4GIA4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HJAR4GIA5",
//			"attrs": {
//				"dirVO": {
//					"type": "auto",
//					"valText": "#{target:\"SYNC/handler\",dir:\"handler\"}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HJAR4GIA6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HJAR4GIA7",
//			"attrs": {
//				"syncName": {
//					"type": "string",
//					"valText": "#dirVO.target"
//				},
//				"syncDir": {
//					"type": "string",
//					"valText": "#dirVO.dir"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "SyncSubDir",
//		"gearIcon": "folder.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HJAR4GIA8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HJAR4GIA9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HJAR4GIA1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HJAR4GIA10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "5",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HJAR64P80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJAR8O970",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Sync target:",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJAR8O971",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HJAR8O972",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJAR8O973",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1HJAR7K7H0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJAR9A510",
//									"attrs": {
//										"type": "edit",
//										"id": "EdTarget",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"w": "100%-60",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[3,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "#dirVO.target||\"\"",
//										"placeHolder": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJAR9A511",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HJAR9A512",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJAR9A513",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HJAR8P4R0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJAR8P4R1",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Sub dir:",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJAR8P4S0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HJAR8P4S1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJAR8P4S2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1HJAR9C040",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJAR9C041",
//									"attrs": {
//										"type": "edit",
//										"id": "EdDir",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"w": "100%-30",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[3,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "#dirVO.dir",
//										"placeHolder": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJAR9C042",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HJAR9C043",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HJAR9C044",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1HJARB25A0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HJARCQBN0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "30",
//										"h": "30",
//										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HJARCQBN1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",30,30,appCfg.sharedAssets+\"/trash.svg\",null)",
//										"id": "BtnRemove",
//										"position": "Absolute",
//										"x": "100%-40",
//										"y": "10",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HJARCQBO0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HJARCQBO1",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HJARQA1N0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HJARR61Q0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HJARCQBO2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HJARCQBO3",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I6414JC60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I6414JC61",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Filter:",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I6414JC70",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I6414JC71",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I6414JC72",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1I6415LV80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I6415LV81",
//									"attrs": {
//										"type": "edit",
//										"id": "EdFilter",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"w": "100%-30",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[3,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "#dirVO.filter||\"\"",
//										"placeHolder": "filter-js-file url, like: /@myagent/myfilter.js",
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "false",
//										"spellCheck": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I6415LV90",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I6415LV91",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I6415LV92",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1IEJKHC540",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IEJKHC541",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Ignores:",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IEJKHC550",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IEJKHC551",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IEJKHC552",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1IEJKHUJH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IEJKHUJH1",
//									"attrs": {
//										"type": "edit",
//										"id": "EdIgnore",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"w": "100%-30",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[3,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "#dirVO.ignore?\"\"+dirVO.ignore.join(\";\"):\"\"",
//										"placeHolder": "item path, sperate with \";\"",
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "false",
//										"spellCheck": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IEJKHUJI0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IEJKHUJI1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IEJKHUJI2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HJAR4GIA11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HJAR4GIA12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HJAR4GIA13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HJAR4GIA14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}