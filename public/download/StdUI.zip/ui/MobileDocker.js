//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H6627I8R0StartDoc*/
/*}#1H6627I8R0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MobileDocker=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let baseUI,boxSlide,dkUIs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H6627I8R1LocalVals*/
	let app=VFACT.app;
	let dragMeta=null;
	let uiStack=null;
	/*}#1H6627I8R1LocalVals*/
	
	/*#{1H6627I8R1PreState*/
	/*}#1H6627I8R1PreState*/
	/*#{1H6627I8R1PostState*/
	/*}#1H6627I8R1PostState*/
	cssVO={
		"hash":"1H6627I8R1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H662C7E00",
				"type":"hud","id":"BaseUI","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
			},
			{
				"hash":"1H662E85T0",
				"type":"hud","id":"BoxSlide","x":0,"y":0,"w":20,"h":"100%","styleClass":"",
			},
			{
				"hash":"1H662AB0R0",
				"type":"dock","id":"DkUIs","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","coverAction":0,"ui":0,
			}
		],
		/*#{1H6627I8R1ExtraCSS*/
		/*}#1H6627I8R1ExtraCSS*/
		faces:{
			"Base":{
			},"Dialog":{
			}
		},
		OnCreate:function(){
			self=this;
			baseUI=self.BaseUI;boxSlide=self.BoxSlide;dkUIs=self.DkUIs;
			/*#{1H6627I8R1Create*/
			if(app && app.uiForge){
				//Don't be active in edit mode.
				return;
			}
			uiStack=dkUIs.uiStack;
			boxSlide.display=false;
			dkUIs.display=false;
			dragMeta=VFACT.applyMoveDrag(dkUIs,null,true,1,0);
			dragMeta.setCallbacks(self.OnDragStart,self.OnDragMove,self.OnDragEnd);
			dragMeta.setGap(10);
			/*}#1H6627I8R1Create*/
		},
		/*#{1H6627I8R1EndCSS*/
		/*}#1H6627I8R1EndCSS*/
	};
	/*#{1H6627I8R1PostCSSVO*/
	//************************************************************************
	//UI:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.openUI=function(ui,vo){
			if(ui.$_webObj){
				ui.hold();
			}else{
				let def=ui;
				if(def instanceof Function){
					def=def();
				}
				if(!def.type){
					throw Error("Argument ui should be a VFACT live-obj or ui-def.");
				}
				ui=self.appendNewChild(def);
				ui.hold();
				self.removeChild(ui);
			}
			let ui0=uiStack[0];
			if(!ui0){
				boxSlide.display=true;
				dkUIs.display=true;
			}
			dkUIs.showUI(ui,vo);
			ui.x=self.w;
			ui.animate({
				type:"pose",x:0,time:100,
				OnFinish(){
					if(!ui0){
						baseUI.display=false;
					}
				}
			});
			dragMeta.setTarget(ui);
			ui.release();
			return ui;
		};
		
		//--------------------------------------------------------------------
		cssVO.closeUI=function(ui){
			let topUI=dkUIs.curUI;
			let ui0=uiStack[0];
			let preUI=uiStack[uiStack.length-2];
			if(ui){
				if(ui!==topUI){
					dkUIs.dismissUI(ui);
					return;
				}
			}else{
				ui=dkUIs.curUI;
			}
			if(ui===ui0){
				baseUI.display=true;
			}else if(preUI){
				preUI.display=true;
			}
			ui.animate({
				type:"pose",x:self.w,time:100,
				OnFinish(){
					dkUIs.dismissUI(ui,true);
					if(ui0===ui){
						boxSlide.display=false;
						dkUIs.display=false;
					}else{
						dragMeta.setTarget(preUI);
					}
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.restoreUI=function(){
			let ui=dkUIs.curUI;
			let ui0=uiStack[0];
			ui.animate({
				type:"pose",x:0,time:100,
				OnFinish(){
					if(ui0===ui){
						baseUI.display=false;
					}
				}
			});
		};
	}
	//************************************************************************
	//Drags:
	//************************************************************************
	{
		let orgX,selfW,dragging=false;
		//--------------------------------------------------------------------
		cssVO.OnDragStart=function(evt,tgt){
			let preUI=uiStack[uiStack.length-2]||baseUI;
			if(tgt){
				dragging=true;
				preUI.display=true;
				selfW=self.w;
				orgX=tgt.x;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDragMove=function(evt,tgt,dx,dy){
			if(dragging){
				dx=dx<0?0:dx;
				tgt.x=orgX+dx;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDragEnd=function(evt,tgt){
			if(!dragging)
				return;
			if(tgt.x>=selfW*0.5){
				self.closeUI();
			}else{
				//Restore top dlgUI pos:
				self.restoreUI();
			}
		};
	}
	/*}#1H6627I8R1PostCSSVO*/
	return cssVO;
};
/*#{1H6627I8R1ExCodes*/
/*}#1H6627I8R1ExCodes*/

MobileDocker.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("手机App框架"):("Mobile Docker")),icon:"huddock.svg",previewImg:false,
	fixPose:true,initW:100,initH:300,
	"desc":"Mobile application docker. With a dialog stack that can swap to close.",
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","contentLayout","subAlign","itemsAlign","itemsWrap","clip","uiEvent","alpha","rotate","scale","aspect","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:["Base","Dialog"],
	subContainers:{
		"1H662C7E00":{"showName":"BaseUI"}
	},
	/*#{1H6627I8R0ExGearInfo*/
	/*}#1H6627I8R0ExGearInfo*/
};
export default MobileDocker;
export{MobileDocker};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H6627I8R0",
//	"editVersion": 88,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H6627I8R2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H6627I8R3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H6627I8R4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H6627I8R5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H6627I8R6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H6627I8R7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Mobile Docker",
//			"localize": {
//				"EN": "Mobile Docker",
//				"CN": "手机App框架"
//			},
//			"localizable": true
//		},
//		"gearIcon": "huddock.svg",
//		"gearW": "100",
//		"gearH": "300",
//		"gearCatalog": "Views",
//		"description": "Mobile application docker. With a dialog stack that can swap to close.",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H6627I8R8",
//			"editVersion": 4,
//			"attrs": {
//				"Base": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H662PL9L0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H662PL9L1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"Dialog": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H662PL9L2",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H662PL9L3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H6627I8R1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H6627I8R9",
//					"editVersion": 66,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H662C7E00",
//							"editVersion": 34,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H662D2HV0",
//									"editVersion": 72,
//									"attrs": {
//										"type": "hud",
//										"id": "BaseUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H662D2HV1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H662D2HV2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H662D2HV3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H662E85T0",
//							"editVersion": 32,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H662PL9M0",
//									"editVersion": 92,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxSlide",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "20",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H662PL9M1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H662PL9M2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H662PL9M3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "dock",
//							"jaxId": "1H662AB0R0",
//							"editVersion": 33,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H662AJHS0",
//									"editVersion": 84,
//									"attrs": {
//										"type": "dock",
//										"id": "DkUIs",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"coverAction": "Hide",
//										"ui": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H662AJHS1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H662AJHS2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H662AJHS3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H6627I8R10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H6627I8R11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H6627I8R12",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H6627I8R13",
//			"editVersion": 122,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "true",
//				"subAlign": "true",
//				"itemsAlign": "true",
//				"itemsWrap": "true",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "true",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}