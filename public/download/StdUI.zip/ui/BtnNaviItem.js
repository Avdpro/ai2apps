//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1H1TCNO8A0StartDoc*/
import DlgMenu from "./DlgMenu.js";
/*}#1H1TCNO8A0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnNaviItem=function(code,text,color,icon,items,fontSize,hasClose,iconSize,mark){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxNewMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let markColor=mark===true?cfgColor.error:mark;
	
	/*#{1H1TCNO8A1LocalVals*/
	let app=window.tabOSApp;
	let focused=false;
	/*}#1H1TCNO8A1LocalVals*/
	
	/*#{1H1TCNO8A1PreState*/
	/*}#1H1TCNO8A1PreState*/
	state={
		"markNum":0,
		/*#{1H1TCNO8A6ExState*/
		/*}#1H1TCNO8A6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1TCNO8A1PostState*/
	/*}#1H1TCNO8A1PostState*/
	cssVO={
		"hash":"1H1TCNO8A1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"","h":"100%","cursor":"pointer","padding":[5,5,5,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"code":code,
		children:[
			{
				"hash":"1H1TCV3O50",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":iconSize||(fontSize+6),"h":iconSize||(fontSize+6),"autoLayout":true,"uiEvent":-1,
				"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":color,"aspect":"1","attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H1TCQ3130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"alpha":0.5,"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":color,"text":text,"fontSize":fontSize||txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TIOQU40",
				"type":"box","id":"MenuMark","position":"relative","x":0,"y":"50%","w":"","h":">calc(100% - 10px)","anchorY":1,"uiEvent":-1,"alpha":0.5,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","background":color,"aspect":"1","maskImage":appCfg.sharedAssets+"/down.svg","attached":!!items,
			},
			{
				"hash":"1I54TJEKG0",
				"type":BtnIcon(color,fontSize+4,0,appCfg.sharedAssets+"/close.svg",undefined),"id":"BtnClose","position":"relative","x":0,"y":0,"attached":hasClose===true,
				"margin":[0,0,0,3],"alpha":0.5,
			},
			{
				"hash":"1I7PO2OSM0",
				"type":"box","id":"BoxNewMark","x":">calc(100% - 10px)","y":">calc(50% - 3px)","w":"","h":12,"anchorX":1,"anchorY":1,"display":$P(()=>(state.markNum>0),state),
				"uiEvent":-1,"padding":2,"minW":12,"minH":"","maxW":"","maxH":"","styleClass":"","background":markColor,"corner":100,"attached":!!mark,
				children:[
					{
						"hash":"1I7PO8SHK0",
						"type":"text","id":"TxtMarkNum","position":"relative","x":"50%","y":0,"w":"","h":"100%","anchorX":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontError"],"text":$P(()=>(state.markNum>1?state.markNum:""),state),"fontSize":12,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
						"alignH":1,"alignV":1,
					}
				],
			}
		],
		get $$markNum(){return state["markNum"]},
		set $$markNum(v){
			state["markNum"]=v;
			/*#{1H1TCNO8A1SetmarkNum*/
			/*}#1H1TCNO8A1SetmarkNum*/
		},
		/*#{1H1TCNO8A1ExtraCSS*/
		/*}#1H1TCNO8A1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1TD2J6S0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2J6S0PreCode*/
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.5
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.5
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.5
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"uiEvent":1,"alpha":0.5
				}
			},"over":{
				/*#{1H1TD45OB0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD45OB0PreCode*/
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.7
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.7
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.7
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"alpha":0.7
				}
			},"down":{
				/*#{1H1TD2VV70PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2VV70PreCode*/
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":1
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":1
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":1
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"alpha":1
				}
			},"gray":{
				/*#{1H1TLQVNS0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TLQVNS0PreCode*/
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.2
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.2
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.2
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"uiEvent":-1,"alpha":0.2
				}
			},"focus":{
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":1
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":1
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":1
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"alpha":1
				},
				/*#{1H1TD5GM90Code*/
				$(){
					focused=true;
					this.uiEvent=-1;
				},
				/*}#1H1TD5GM90Code*/
			},"blur":{
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.5
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.5
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.5
				},
				/*BtnClose*/"#1I54TJEKG0":{
					"alpha":0.5
				},
				/*#{1H1TD5O2O0Code*/
				$(){
					focused=false;
					this.uiEvent=1;
				},
				/*}#1H1TD5O2O0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxNewMark=self.BoxNewMark;
			/*#{1H1TCNO8A1Create*/
			/*}#1H1TCNO8A1Create*/
		},
		/*#{1H1TCNO8A1EndCSS*/
		/*}#1H1TCNO8A1EndCSS*/
	};
	/*#{1H1TCNO8A1PostCSSVO*/
	cssVO.incMark=function(){
		let num;
		num=state.markNum;
		if(!num){
			num=1;
			state.markNum=num;
		}else if(num<99){
			num+=1;
			state.markNum=num;
		}
		boxNewMark.scale=0.6;
		boxNewMark.animate({type:"pose",scale:1,time:30});
	};
	/*}#1H1TCNO8A1PostCSSVO*/
	cssVO.constructor=BtnNaviItem;
	return cssVO;
};
/*#{1H1TCNO8A1ExCodes*/
/*}#1H1TCNO8A1ExCodes*/

//----------------------------------------------------------------------------
BtnNaviItem.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1TCNO8A1PreAISpot*/
	/*}#1H1TCNO8A1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("导航入口"):("Navi Entry"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1TCNO8A1PostAISpot*/
	/*}#1H1TCNO8A1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnNaviItem.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("导航入口"):("Navi Entry")),icon:"gears.svg",previewImg:false,
	fixPose:true,initW:100,initH:40,
	"desc":"Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
	catalog:"Buttons",
	args: {
		"code": {
			"name": "code", "showName": "code", "type": "string", "key": true, "fixed": true, "initVal": "Home"
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": true
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/home.svg", "initValText": "#appCfg.sharedAssets+\"/home.svg\""
		}, 
		"items": {"name":"items","showName":"items","type":"auto","key":true,"fixed":true}, 
		"fontSize": {
			"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 16, "initValText": "#txtSize.mid"
		}, 
		"hasClose": {
			"name": "hasClose", "showName": "hasClose", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"iconSize": {
			"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 0
		}, 
		"mark": {
			"name": "mark", "showName": "mark", "type": "auto", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
		markNum:{name:"markNum",type:"int",initVal:0}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","cursor","margin","enable","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1H1TCNO8A0ExGearInfo*/
	/*}#1H1TCNO8A0ExGearInfo*/
};
/*#{1H1TCNO8A0EndDoc*/
/*}#1H1TCNO8A0EndDoc*/

export default BtnNaviItem;
export{BtnNaviItem};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1TCNO8A0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1TCNO8A2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "40",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1TCNO8A3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5RF70O00",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1TCNO8A4",
//			"attrs": {
//				"code": {
//					"type": "string",
//					"valText": "Home"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Home",
//					"localizable": true
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/home.svg\""
//				},
//				"items": {
//					"type": "auto",
//					"valText": ""
//				},
//				"fontSize": {
//					"type": "int",
//					"valText": "#txtSize.mid"
//				},
//				"hasClose": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"iconSize": {
//					"type": "int",
//					"valText": "0"
//				},
//				"mark": {
//					"type": "auto",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1TCNO8A5",
//			"attrs": {
//				"markColor": {
//					"type": "auto",
//					"valText": "#mark===true?cfgColor.error:mark"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1TCNO8A6",
//			"attrs": {
//				"markNum": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Navi Entry",
//			"localize": {
//				"EN": "Navi Entry",
//				"CN": "导航入口"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "40",
//		"gearCatalog": "Buttons",
//		"description": "Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1TCNO8A7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2J6S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T390",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD45OB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T391",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2VV70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T392",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TLQVNS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TLR73E0",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5GM90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T393",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5O2O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T394",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HU3VJD1P0",
//			"attrs": {
//				"iconed": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I4OP806T0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"iconSize": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"icon_only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54T5QH10",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.small"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"text_only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54T5QH11",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": ""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.small"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"has_close": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54TV0KV0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "true"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"big_icon": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I7JC858V0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"iconSize": {
//									"type": "int",
//									"valText": "30"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1TCNO8A1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1TCNO8A8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "\"\"",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,5,5,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"attach": "true",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TCV3O50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T395",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#iconSize||(fontSize+6)",
//										"h": "#iconSize||(fontSize+6)",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TD5T396",
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T399",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3910",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3911",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3912",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V21",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10LV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10LV1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TD5T3917",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TD5T3918",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1TCQ3130",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3919",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#color",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#fontSize||txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TD5T3920",
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3923",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3924",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3925",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3926",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V25",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF7",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10LV2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10LV3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TD5T3931",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TD5T3932",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TIOQU40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TIT6SM0",
//									"attrs": {
//										"type": "box",
//										"id": "MenuMark",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"w": "\"\"",
//										"h": "100%-10",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"maskImage": "#appCfg.sharedAssets+\"/down.svg\"",
//										"attach": "#!!items"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TIT6SM1",
//									"attrs": {
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TIUJ9A13",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TIUJ9A15",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V29",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF11",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10M00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10M01",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TIT6SM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TIT6SM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1I54TJEKG0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I54TNAR10",
//									"attrs": {
//										"style": "#color",
//										"w": "#fontSize+4",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1I54TNAR11",
//									"attrs": {
//										"type": "#null#>BtnIcon(color,fontSize+4,0,appCfg.sharedAssets+\"/close.svg\",undefined)",
//										"id": "BtnClose",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"attach": "#hasClose===true",
//										"margin": "[0,0,0,3]",
//										"alpha": "0.5"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I54TNAR12",
//									"attrs": {
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54TSA0L0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54TSA0L1",
//													"attrs": {
//														"uiEvent": {
//															"type": "choice",
//															"valText": "Tree Off"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54TSA0L2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54TSA0L3",
//													"attrs": {
//														"uiEvent": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF13",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF15",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF17",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10M02",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10M03",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I54TNAR13",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I54TNAR14",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I54TNAR15",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I7PO2OSM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7PP3SMJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNewMark",
//										"position": "Absolute",
//										"x": "100%-10",
//										"y": "50%-3",
//										"w": "",
//										"h": "12",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "${state.markNum>0},state",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "12",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#markColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!mark"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I7PO8SHK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PP3SMJ1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtMarkNum",
//														"position": "Relative",
//														"x": "50%",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontError\"]",
//														"text": "${state.markNum>1?state.markNum:\"\"},state",
//														"font": "",
//														"fontSize": "12",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7PP3SMJ2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I7PP3SMJ3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7PP3SMJ4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I7PP3SMJ5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I7PP3SMJ6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7PP3SMJ7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1TCNO8A9",
//					"attrs": {
//						"1H1TD45OB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3937",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3938",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD45OB0",
//							"faceTagName": "over"
//						},
//						"1H1TD5GM90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3939",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3940",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD5GM90",
//							"faceTagName": "focus"
//						},
//						"1H1TD5O2O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3941",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3942",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD5O2O0",
//							"faceTagName": "blur"
//						},
//						"1H1TD2VV70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I54V583S2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I54V583S3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD2VV70",
//							"faceTagName": "down"
//						},
//						"1H1TLQVNS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I54V764A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I54V764A1",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TLQVNS0",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1TCNO8A10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1TCNO8A11",
//					"attrs": {
//						"code": {
//							"type": "string",
//							"valText": "#code"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1TCNO8A12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "markNum"
//				}
//			]
//		}
//	}
//}