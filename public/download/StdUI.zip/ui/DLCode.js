//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HRMFE0V90StartDoc*/
/*}#1HRMFE0V90StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLCode=function(box,template,dataObj,property,opts,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxIcon,txtLabel,txtMode,boxCode;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let value=dataObj[property];
	let pptTemplate=template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value));
	let edit=(!pptTemplate.readOnly) && opts.edit && (box && box.edit);
	let icon=pptTemplate.icon;
	let labelLine=!!opts.labelLine;
	let choices=pptTemplate.choices||["No","Yes"];
	let description=edit?pptTemplate.desc:null;
	let valueGap=choices?3:(opts.labelLine?6:3);
	let menuGap=opts.labelLine?6:3;
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	let mode="Text";
	let cm=null;
	if(value===undefined){
		value="";
	}
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":opts?(opts.lineHeight||25):25,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1F1DNF0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":opts?(opts.lineHeight-3):22,"h":opts?(opts.lineHeight-3):22,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-y",
				"itemsWrap":1,"itemsAlign":1,
				children:[
					{
						"hash":"1HQ1GMNN90",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":opts.labelColor,"text":title||(pptTemplate.label?pptTemplate.label:(property+":")),"fontSize":opts?(opts.labelSize||12):14,"fontWeight":(opts?(opts.labelBold||false):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HRMG54D20",
						"type":"box","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":25,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["fontSecondarySub"],"border":[1,1,0,1],"borderColor":cfgColor["fontBody"],"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1HRMGBL6H0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
								"OnClick":function(event){
									self.showMenu(this,event);
								},
							},
							{
								"hash":"1HRMGD6JL0",
								"type":"text","id":"TxtMode","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Plain text","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							}
						],
					},
					{
						"hash":"1HRMFNHVB0",
						"type":"box","id":"BoxFrame","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":200,"padding":5,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor["body"],"border":[0,1,1,1],"borderColor":cfgColor["fontBody"],
						children:[
							{
								"hash":"1HRMFOS370",
								"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							}
						],
					},
					{
						"hash":"1HQ1JKTFQ0",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":description,"fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","wrap":true,"attached":!!description,
					}
				],
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get $$property(){
			return property;
		},
		set $$property(p){
			return property=p;
		},
		template:pptTemplate,
		get $$value(){
			if(cm){
				value=cm.doc.getValue();
			}else{
				value="";
			}
			return value;
		},
		set $$value(val){
			return self.commitEdit(val);
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
			"error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":cfgColor["error"]
				}
			},"!error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":opts.labelColor
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtMode=self.TxtMode;boxCode=self.BoxCode;
			/*#{1HQ1EDCKJ1Create*/
			self.setText(value);
			self.postCheck();
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(sender,event){
		/*#{1HRMGQNAR0Start*/
		let newMode;
		/*}#1HRMGQNAR0Start*/
		{
			let $items,$item;
			$items=[
				{id:"text",text:(($ln==="CN")?("纯文本"):("Plain text"))},
				{id:"javascript",text:"Javascript"},
				{id:"html",text:"HTML"}
			];
			/*#{1HRMGS8SE2Items*/
			/*}#1HRMGS8SE2Items*/
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="text"){
					/*#{1HRMGR5Q70*/
					newMode="text";
					txtMode.text=$item.text;
					/*}#1HRMGR5Q70*/
				}else if($item.id==="javascript"){
					/*#{1HRMGR5Q71*/
					newMode="javascript";
					txtMode.text=$item.text;
					/*}#1HRMGR5Q71*/
				}else if($item.id==="html"){
					/*#{1HRMGR5Q72*/
					newMode="html";
					txtMode.text=$item.text;
					/*}#1HRMGR5Q72*/
				}
			}
			/*#{1HRMGS8SE2Post*/
			if(newMode===mode){
				return;
			}
			self.setText(value,newMode);
			self.focus();
			/*}#1HRMGS8SE2Post*/
		}
		
		//SetMode
		/*#{1HRMH2OT30*/
		/*}#1HRMH2OT30*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.setText=async function(text,newMode){
		let wrap=false;
		if(cm){
			if(mode===newMode){
				cm.doc.setValue(text);
				return;
			}
			boxCode.webObj.innerHTML="";
			cm=null;
		}
		mode=newMode||"text";
		switch(mode){
			case "javascript":
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				break;
			case "html":
				mode="text/html";
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
	
				await VFACT.appendScript("/@codemirror/mode/css.js");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/htmlmixed.js");
				break;
			case "markdown":
				wrap=true;
				mode="text/x-markdown";
				await VFACT.appendScript("/@codemirror/mode/markdown.js");
				break;
			case "json":
				mode={name: "javascript", json: true};
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				break;
			case "css":
			case ".css":
				mode={name: "css"};
				await VFACT.appendScript("/@codemirror/mode/css.js");
				break;
			case "jsx":
			case ".jsx":
				mode="text/jsx";
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/jsx.js");
				break;
			case ".cpp":
				mode="text/x-c++src";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			case ".java":
				mode="text/x-java";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			case "text":
			case ".txt":
				mode="text/plain";
				break;
		}
		//cmDoc=this.cmDoc=CodeMirror.Doc(value,mode);
		cm=CodeMirror(boxCode.webObj, {
			value:text,
			mode:mode,
			lineNumbers:true,
			undoDepth:20
		});
		cm.setSize("100%","100%");
		cm.on("changes", this.OnCMChanges.bind(self));
	};
	
	//------------------------------------------------------------------------
	cssVO.getText=function(){
		if(cm){
			return cm.doc.getValue();
		}
		return "";
	};
	
	//------------------------------------------------------------------------
	cssVO.OnCMChanges=function(){
		value=cm.doc.getValue();
		box._OnEdit && box._OnEdit();
	};
	
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		if(pptTemplate.checkValue){
			if(!pptTemplate.checkValue(val)){
				val=value;
			}
		}
		if(val!==value){
			value=val;
			self.updateValue();
		}
		return value;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		value=dataObj[property];
		self.updateValue();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		self.setText(value);
		self.postCheck();
	};
	
	//------------------------------------------------------------------------
	cssVO.postCheck=function(){
	};
	
	//------------------------------------------------------------------------
	cssVO.focus=function(){
		if(cm){
			cm.focus();
		}
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/


/*#{1HRMFE0V90EndDoc*/
/*}#1HRMFE0V90EndDoc*/

export default DLCode;
export{DLCode};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HRMFE0V90",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "#{properties:{size:{type:\"int\",label:\"Size\",description:\"This is size\"}}}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "#{size:50}"
//				},
//				"property": {
//					"type": "string",
//					"valText": "size"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 1, edit:0}"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"value": {
//					"type": "auto",
//					"valText": "#dataObj[property]"
//				},
//				"pptTemplate": {
//					"type": "auto",
//					"valText": "#template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value))"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "#(!pptTemplate.readOnly) && opts.edit && (box && box.edit)"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#null//appCfg.sharedAssets+\"/inc.svg\"#>pptTemplate.icon"
//				},
//				"labelLine": {
//					"type": "bool",
//					"valText": "#!!opts.labelLine"
//				},
//				"choices": {
//					"type": "auto",
//					"valText": "#pptTemplate.choices||[\"No\",\"Yes\"]"
//				},
//				"description": {
//					"type": "string",
//					"valText": "#edit?pptTemplate.desc:null"
//				},
//				"valueGap": {
//					"type": "int",
//					"valText": "#choices?3:(opts.labelLine?6:3)"
//				},
//				"menuGap": {
//					"type": "int",
//					"valText": "#opts.labelLine?6:3"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HRMGQNAR0",
//					"attrs": {
//						"id": "showMenu",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HRMGS8SE0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HRMGS8SE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HRMGS8SE2",
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "300",
//										"y": "120",
//										"desc": "",
//										"codes": "true",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HRMGR5Q70",
//													"attrs": {
//														"id": "text",
//														"text": {
//															"type": "string",
//															"valText": "Plain text",
//															"localize": {
//																"EN": "Plain text",
//																"CN": "纯文本"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HRMGR5Q71",
//													"attrs": {
//														"id": "javascript",
//														"text": "Javascript",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HRMGR5Q72",
//													"attrs": {
//														"id": "html",
//														"text": "HTML",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HRMGS8SE3",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HRMH2OT30"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HRMH2OT30",
//									"attrs": {
//										"id": "SetMode",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "120",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HRMH2OT40",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HRMGS8SE4",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HRMGS8SE2"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VN1I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND0",
//							"attrs": {}
//						}
//					}
//				},
//				"!error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VNIQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "#opts?(opts.lineHeight||25):25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ1F1DNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1F383P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#opts?(opts.lineHeight-3):22",
//										"h": "#opts?(opts.lineHeight-3):22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1F383P1",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HJ1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1F383P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1F383P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GMNN90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GMNN91",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,3,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.labelColor",
//														"text": "#title||(pptTemplate.label?pptTemplate.label:(property+\":\"))",
//														"font": "",
//														"fontSize": "#opts?(opts.labelSize||12):14",
//														"bold": "#opts?(opts.labelBold||false):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GMNNA0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND5",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"error\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														},
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#opts.labelColor"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GMNNA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GMNNA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HRMG54D20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HRMG9DER0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-10",
//														"h": "25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,3]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontSecondarySub\"]",
//														"border": "[1,1,0,1]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1KJQ5RK0",
//															"jaxId": "1HRMGBL6H0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HRMGCN7E0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HRMGCN7E1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnMenu",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,3,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HRMGCN7E2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HRMGCN7E3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HRMGS8SF0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HRMGS8SF1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HRMGQNAR0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HRMGCN7E4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HRMGCN7E5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HRMGD6JL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRMGEVRK0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtMode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Plain text",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HRMGEVRK1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HRMGEVRK2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HRMGEVRK3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HRMG9DER1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HRMG9DER2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HRMG9DER3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HRMFNHVB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HRMFPLF90",
//													"attrs": {
//														"type": "box",
//														"id": "BoxFrame",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-10",
//														"h": "200",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "5",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[0,1,1,1]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HRMFOS370",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRMFPLF91",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCode",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HRMFPLF92",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HRMFPLF93",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HRMFPLF94",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HRMFPLF95",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HRMFPLF96",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HRMFPLF97",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1JKTFQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1JO33U0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#description",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!description"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1JO33U1",
//													"attrs": {
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQMCM8HK2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQMCM8HK3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1JO33U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1JO33U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HK4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HK5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {
//						"1HQ20VNIQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQMCM8HK6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQMCM8HK7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQ20VNIQ0",
//							"faceTagName": "!error"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}