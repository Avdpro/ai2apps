//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G700UK7O0StartDoc*/
import {BtnTabLabel} from "./BtnTabLabel.js";
import {makeNotify,makeObjEventEmitter} from "/@events";
/*}#1G700UK7O0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxTabLine=function(trkH,tabSize,tabs){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let colors=appCfg.darkMode?appCfg.colorDK:appCfg.color ;
	
	/*#{1G700UK7O7LocalVals*/
	let btns=[];
	let btnHash={};
	let hotBtn=null;
	/*}#1G700UK7O7LocalVals*/
	
	/*#{1G700UK7O7PreState*/
	/*}#1G700UK7O7PreState*/
	/*#{1G700UK7O7PostState*/
	/*}#1G700UK7O7PostState*/
	cssVO={
		"hash":"1G700UK7O7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":200,"h":trkH,"autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1G7018R9A0",
				"type":"box","x":0,"y":"FH-1","w":"FW","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodySub,
			}
		],
		/*#{1G700UK7O7ExtraCSS*/
		/*}#1G700UK7O7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G700UK7O7Create*/
			let def;
			for(def of tabs){
				self.addTab(def);
			}
			makeNotify(self);
			makeObjEventEmitter(self);
			/*}#1G700UK7O7Create*/
		},
		/*#{1G700UK7O7EndCSS*/
		get $$hotTab(){
			return hotBtn?hotBtn.def.msg:"";
		},
		set $$hotTab(msg){
			let btn;
			btn=btnHash[msg];
			if(btn){
				if(hotBtn){
					if(hotBtn===btn){
						return;
					}
					hotBtn.showFace("blur");
				}
				btn.showFace("focus");
				hotBtn=btn;
			}
		}
		/*}#1G700UK7O7EndCSS*/
	};
	/*#{1G700UK7O7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.addTab=function(def){
		let css,btn;
		css={
			type:BtnTabLabel(def.text,tabSize,trkH),def:def,
			OnClick:function(){
				let msg;
				if(hotBtn){
					if(hotBtn===btn){
						return;
					}
					hotBtn.showFace("blur");
				}
				this.showFace("focus");
				hotBtn=btn;
				msg=btn.def.msg||btn.def.text;
				//emitNotify:
				self.emitNotify("TabChanged");
				self.emit("TabChanged",msg);
				if(self.OnTabChange){
					self.OnTabChange();
				}
			}
		};
		if(!btns.length){
			css.marginL=10;
		}
		btn=self.appendNewChild(css);
		btn.tabIndex=btns.length;
		btns.push(btn);
		if(def.hot){
			btn.showFace("focus");
			hotBtn=btn;
		}
		btnHash[def.msg]=btn;
		return btn;
	};
	/*}#1G700UK7O7PostCSSVO*/
	return cssVO;
};
/*#{1G700UK7O7ExCodes*/
/*}#1G700UK7O7ExCodes*/

BoxTabLine.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"BoxTabLine",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:200,initH:24,
	catalog:"Views",
	args: {
		"trkH": {
			"name": "trkH", "showName": "trkH", "type": "int", "key": true, "fixed": true, "initVal": 24
		}, 
		"tabSize": {
			"name": "tabSize", "showName": "tabSize", "type": "int", "key": true, "fixed": true, "initVal": 120
		}, 
		"tabs": {
			"name": "tabs", "showName": "tabs", "type": "auto", "key": true, "fixed": true, 
			"initVal": [{"text":"Tab1","msg":"Tab1","hot":1},{"text":"Tab2","msg":"Tab2"}]
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","margin","padding","attach"],
	faces:[],
	subContainers:{
	},
	/*#{1G700UK7O0ExGearInfo*/
	/*}#1G700UK7O0ExGearInfo*/
};
/*#{1G700UK7O0EndDoc*/
/*}#1G700UK7O0EndDoc*/

export default BoxTabLine;
export{BoxTabLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G700UK7O0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G700UK7O1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G700UK7O2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA30GJ500",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G700UK7O3",
//			"attrs": {
//				"trkH": {
//					"type": "int",
//					"valText": "24"
//				},
//				"tabSize": {
//					"type": "int",
//					"valText": "120"
//				},
//				"tabs": {
//					"type": "auto",
//					"valText": "[{\"text\":\"Tab1\",\"msg\":\"Tab1\",\"hot\":1},{\"text\":\"Tab2\",\"msg\":\"Tab2\"}]"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G700UK7O4",
//			"attrs": {
//				"colors": {
//					"type": "auto",
//					"valText": "#appCfg.darkMode?appCfg.colorDK:appCfg.color "
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G700UK7O5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "BoxTabLine",
//		"gearIcon": "gears.svg",
//		"gearW": "200",
//		"gearH": "24",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G700UK7O6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA30GJ501",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G700UK7O7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G700UK7O8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "200",
//						"h": "#trkH",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G7018R9A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G701D2110",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "\"FH-1\"",
//										"w": "\"FW\"",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.lineBodySub",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G701D2111",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G701D2112",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GEOKAK6R0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G700UK7O9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G700UK7O10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GEOKAK6R1",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G700UK7O11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}