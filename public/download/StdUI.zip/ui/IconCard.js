//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H59BTKMB0StartDoc*/
/*}#1H59BTKMB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let IconCard=function(title,intro,pic,picW,picH){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H54B0SFB1LocalVals*/
	/*}#1H54B0SFB1LocalVals*/
	
	/*#{1H54B0SFB1PreState*/
	/*}#1H54B0SFB1PreState*/
	/*#{1H54B0SFB1PostState*/
	/*}#1H54B0SFB1PostState*/
	cssVO={
		"hash":"1H54B0SFB1",nameHost:true,
		"type":"button","x":38,"y":26,"w":300,"h":"","padding":10,"minW":"","minH":(pic&&picH>0)?picH+20:30,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"traceSize":true,"subAlign":1,
		children:[
			{
				"hash":"1H54B23MV0",
				"type":"box","id":"BG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],
				"border":1,"borderColor":cfgColor.lineBodyLit,"corner":6,
			},
			{
				"hash":"1H59BTTB30",
				"type":"box","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
				"attached":!!pic,"maskImage":pic,
			},
			{
				"hash":"1H5721BRE0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW","h":"","autoLayout":true,"margin":[0,0,5,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":title,"fontSize":txtSize.big,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1H572917N0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW-20","h":"","autoLayout":true,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":intro,"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","wrap":true,
			}
		],
		/*#{1H54B0SFB1ExtraCSS*/
		/*}#1H54B0SFB1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"gray":{
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H54B0SFB1Create*/
			/*}#1H54B0SFB1Create*/
		},
		/*#{1H54B0SFB1EndCSS*/
		/*}#1H54B0SFB1EndCSS*/
	};
	/*#{1H54B0SFB1PostCSSVO*/
	/*}#1H54B0SFB1PostCSSVO*/
	cssVO.constructor=IconCard;
	return cssVO;
};
/*#{1H54B0SFB1ExCodes*/
/*}#1H54B0SFB1ExCodes*/

//----------------------------------------------------------------------------
IconCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H54B0SFB1PreAISpot*/
	/*}#1H54B0SFB1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("图标卡片"):("Icon-Card"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H54B0SFB1PostAISpot*/
	/*}#1H54B0SFB1PostAISpot*/
	return exposeVO;
};

/*#{1H59BTKMB0EndDoc*/
/*}#1H59BTKMB0EndDoc*/

export default IconCard;
export{IconCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H59BTKMB0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H54B0SFB2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H54B0SFC0",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5NQV6BP0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H54B0SFC1",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Title",
//					"localizable": true
//				},
//				"intro": {
//					"type": "string",
//					"valText": "Card intro text",
//					"localizable": true
//				},
//				"pic": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/prj.svg\""
//				},
//				"picW": {
//					"type": "int",
//					"valText": "50"
//				},
//				"picH": {
//					"type": "int",
//					"valText": "50"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H54B0SFC2",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H54B0SFC3",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Icon-Card",
//			"localize": {
//				"EN": "Icon-Card",
//				"CN": "图标卡片"
//			},
//			"localizable": true
//		},
//		"gearIcon": "idcard.svg",
//		"gearW": "300",
//		"gearH": "80",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "A card with title and intro. Maybe has an mono-color-icon on left side.",
//			"localize": {
//				"EN": "A card with title and intro. Maybe has an mono-color-icon on left side.",
//				"CN": "一个带有标题和简介的卡片。可能左侧有一个单色图标。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "./PicCard.png",
//		"faceTags": {
//			"jaxId": "1H54B0SFC4",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H599SSCN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE1",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE2",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59BOAKE4",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59CICIB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H59CISV50",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HRVPOB300",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H54B0SFB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H54B0SFC5",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "38",
//						"y": "26",
//						"w": "300",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "#(pic&&picH>0)?picH+20:30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y",
//						"traceSize": "true",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H54B23MV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H572GMLL0",
//									"attrs": {
//										"type": "box",
//										"id": "BG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H572GMLL1",
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV51",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV52",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV53",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV54",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV55",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV56",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CICIB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV57",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV58",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CICIB0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H572GMLL2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H572GMLL3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H59BTTB30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59C42NS0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!pic",
//										"maskImage": "#pic"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H59C42NS1",
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV59",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV510",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV511",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV512",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV513",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV514",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H59C42NS2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H59C42NS3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H5721BRE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H57290200",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBody",
//										"text": "#title",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H57290201",
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV517",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV518",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV519",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV520",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV521",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV522",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H57290202",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H57290203",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H572917N0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H572917N1",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW-20\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "#intro",
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H572917O0",
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV525",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV526",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV527",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV528",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV529",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H59CISV530",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H572917O1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H572917O2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H54B0SFC6",
//					"attrs": {
//						"1H599SSCN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV533",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CISV534",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H599SSCN0",
//							"faceTagName": "up"
//						},
//						"1H59BOAKE1": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV535",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CISV536",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE1",
//							"faceTagName": "over"
//						},
//						"1H59BOAKE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV537",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H59CISV538",
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE3",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H54B0SFC7",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H54B0SFC8",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H54B0SFC9",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}