//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H4NCJO0E0StartDoc*/
/*}#1H4NCJO0E0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let SlideShow=function(frontColor,showTime){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let slides,footer;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H4NCJO0E1LocalVals*/
	let app=VFACT.app;
	let dotCSS={
		type:"box",position:"relative",background:frontColor,x:0,y:0,w:20,h:3,cursor:"pointer",alpha:0.25,
		margin:[0,5,0,5],
		focus(){
			this.animate({type:"pose",alpha:1,time:100});
		},
		blur(){
			this.animate({type:"pose",alpha:0.25,time:100});
		},
		OnClick(){
			self.OnDotClick(this);
		}
	};
	/*}#1H4NCJO0E1LocalVals*/
	
	/*#{1H4NCJO0E1PreState*/
	let slideW=0;
	let moving=false;
	let slideHuds=[];
	let dots=[];
	let slideIdx=0;
	let timer=null;
	showTime=showTime*1000;
	/*}#1H4NCJO0E1PreState*/
	/*#{1H4NCJO0E1PostState*/
	/*}#1H4NCJO0E1PostState*/
	cssVO={
		"hash":"1H4NCJO0E1",nameHost:true,
		"type":"hud","x":38,"y":8,"w":300,"h":200,"overflow":1,"styleClass":"",
		children:[
			{
				"hash":"1H4NCVJH60",
				"type":"hud","id":"Slides","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","contentLayout":"flex-x",
				children:[
				],
			},
			{
				"hash":"1H4ND24M40",
				"type":"hud","id":"BoxLeft","x":0,"y":0,"w":80,"h":"100%","alpha":0.5,"cursor":"pointer","styleClass":"",
				children:[
					{
						"hash":"1H4ND66740",
						"type":"box","x":">calc(50% - 10px)","y":"50%","w":20,"h":20,"anchorX":1,"anchorY":1,"uiEvent":-1,"rotate":45,"styleClass":"","background":[255,255,255,0],
						"border":[0,0,2,2],"borderColor":frontColor,
					}
				],
				"OnMouseInOut":function(isIn,event){
					/*#{1H4NFEFOR0FunctionBody*/
					if(isIn){
						self.showFace("leftOver");
					}else{
						self.showFace("leftOut");
					}
					/*}#1H4NFEFOR0FunctionBody*/
				},
				"OnClick":function(event){
					/*#{1H4NFI77R0FunctionBody*/
					if(moving)
						return;
					self.slideMove(-1);
					self.resetTimer();
					/*}#1H4NFI77R0FunctionBody*/
				},
			},
			{
				"hash":"1H4ND27NL0",
				"type":"hud","id":"BoxRight","x":">calc(100% - 80px)","y":0,"w":80,"h":"100%","alpha":0.5,"cursor":"pointer","styleClass":"",
				children:[
					{
						"hash":"1H4ND3OHO0",
						"type":"box","x":">calc(50% + 10px)","y":"50%","w":20,"h":20,"anchorX":1,"anchorY":1,"uiEvent":-1,"rotate":45,"styleClass":"","background":[255,255,255,0],
						"border":[2,2,0,0],"borderColor":frontColor,
					}
				],
				"OnMouseInOut":function(isIn,event){
					/*#{1H4NFGTIJ0FunctionBody*/
					if(isIn){
						self.showFace("rightOver");
					}else{
						self.showFace("rightOut");
					}
					/*}#1H4NFGTIJ0FunctionBody*/
				},
				"OnClick":function(event){
					/*#{1H4NFHGNA0FunctionBody*/
					if(moving)
						return;
					self.slideMove(1);
					self.resetTimer();
					/*}#1H4NFHGNA0FunctionBody*/
				},
			},
			{
				"hash":"1H4NDCMJM0",
				"type":"hud","id":"Footer","x":0,"y":">calc(100% - 20px)","w":"100%","h":20,"styleClass":"","contentLayout":"flex-x","subAlign":1,"itemsAlign":1,
			}
		],
		/*#{1H4NCJO0E1ExtraCSS*/
		/*}#1H4NCJO0E1ExtraCSS*/
		faces:{
			"leftOver":{
				/*BoxLeft*/"#1H4ND24M40":{
					"alpha":1
				}
			},"leftOut":{
				/*BoxLeft*/"#1H4ND24M40":{
					"alpha":0.5
				}
			},"rightOver":{
				/*BoxRight*/"#1H4ND27NL0":{
					"alpha":1
				}
			},"rightOut":{
				/*BoxRight*/"#1H4ND27NL0":{
					"alpha":0.5
				}
			}
		},
		OnCreate:function(){
			self=this;
			slides=self.Slides;footer=self.Footer;
			/*#{1H4NCJO0E1Create*/
			if(app && app.uiForge){
				//Don't be active in edit mode.
				return;
			}
			self.buildSlides();
			/*}#1H4NCJO0E1Create*/
		},
		/*#{1H4NCJO0E1EndCSS*/
		OnFree(){
			if(timer){
				clearInterval(timer);
			}
		}
		/*}#1H4NCJO0E1EndCSS*/
	};
	/*#{1H4NCJO0E1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.buildSlides=function(){
		let list,i,n,hud;
		slideW=self.w;
		slideHuds.splice(0);
		dots.splice(0);
		slideIdx=0;
		list=slides.children;
		n=list.length;
		for(i=0;i<n;i++){
			hud=list[i];
			hud.x=hud.slideX=i*slideW;
			hud.display=0;
			hud.y=0;
			hud.position="absolute";
			slideHuds.push(hud);
			dots.push(footer.appendNewChild({type:dotCSS,slideIdx:i}));
		}
		slides.x=0;
		self.resetTimer();
		hud=slideHuds[0];
		if(hud){
			hud.display=1;
		}
		hud=dots[0];
		if(hud){
			hud.focus();
		}
	};
	//------------------------------------------------------------------------
	cssVO.resetTimer=function(){
		if(timer){
			clearInterval(timer);
		}
		if(showTime>0){
			timer=setInterval(()=>{
				self.slideMove(1);
			},showTime);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showSlide=function(idx,byDir){
		let slide,dot,oldSlide;
		
		function aniFin(){
			slide.x=slide.slideX;
			slides.x=-slide.slideX;
			oldSlide.display=false;
			moving=false;
		}
		if(moving)
			return;
		slideW=self.w;
		slide=slideHuds[idx];
		if(!slide)
			return;
		if(idx===slideIdx)
			return;
		oldSlide=slideHuds[slideIdx];
		slide.display=true;
		if(!byDir){
			byDir=idx>slideIdx?1:-1;
		}
		if(slideW>10){
			moving=true;
			slide.x=oldSlide.x+slideW*byDir;
			slides.animate({
				type:"pose",x:-slide.x,time:200,
				OnFinish:aniFin
			});
		}else{
			aniFin();
		}
	
		dot=dots[slideIdx];
		dot.blur();
		dot=dots[idx];
		dot.focus();
		slideIdx=idx;
	};
	
	//------------------------------------------------------------------------
	cssVO.slideMove=function(dir){
		let idx;
		idx=slideIdx+dir;
		if(idx>=slideHuds.length){
			idx=0;
		}
		if(idx<0){
			idx=slideHuds.length-1;
		}
		self.showSlide(idx,dir);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDotClick=function(dot){
		let idx=dot.slideIdx;
		if(moving)
			return;
		self.showSlide(idx);
		self.resetTimer();
	};
	/*}#1H4NCJO0E1PostCSSVO*/
	return cssVO;
};
/*#{1H4NCJO0E1ExCodes*/
/*}#1H4NCJO0E1ExCodes*/

SlideShow.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("轮播框"):("SlideShow")),icon:"ani.svg",previewImg:"./SlideShow.png",
	fixPose:false,initW:300,initH:200,
	"desc":(($ln==="CN")?("一个用于循环浏览元素的幻灯片。"):("A slideshow for cycling through elements.")),
	catalog:"Views",
	args: {
		"frontColor": {
			"name": "frontColor", "showName": "frontColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1]
		}, 
		"showTime": {
			"name": "showTime", "showName": "showTime", "type": "int", "key": true, "fixed": true, "initVal": 5
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","aspect","cursor","zIndex","margin","minW","minH","maxW","maxH"],
	faces:["leftOver","leftOut","rightOver","rightOut"],
	subContainers:{
		"1H4NCVJH60":{"showName":"Slides","contentLayout":"flex-x"}
	},
	/*#{1H4NCJO0E0ExGearInfo*/
	/*}#1H4NCJO0E0ExGearInfo*/
};
export default SlideShow;
export{SlideShow};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H4NCJO0E0",
//	"editVersion": 131,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H4NCJO0F0",
//			"editVersion": 468,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[30,30,30]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H4NCJO0F1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5JT5I770",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H4NCJO0F2",
//			"editVersion": 18,
//			"attrs": {
//				"frontColor": {
//					"type": "colorRGBA",
//					"valText": "[255,255,255,1.00]"
//				},
//				"showTime": {
//					"type": "int",
//					"valText": "5"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H4NCJO0F3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H4NCJO0F4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "SlideShow",
//			"localize": {
//				"EN": "SlideShow",
//				"CN": "轮播框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "ani.svg",
//		"gearW": "300",
//		"gearH": "200",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "A slideshow for cycling through elements.",
//			"localize": {
//				"EN": "A slideshow for cycling through elements.",
//				"CN": "一个用于循环浏览元素的幻灯片。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "./SlideShow.png",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H4NCJO0F5",
//			"editVersion": 8,
//			"attrs": {
//				"leftOver": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H4NEJK5S0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H4NEJK5S1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"leftOut": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H4NEJK5S2",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H4NEJK5S3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"rightOver": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H4NEJK5S4",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H4NEJK5S5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"rightOut": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H4NEJK5S6",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H4NEJK5S7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H4NCJO0E1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H4NCJO0F6",
//					"editVersion": 74,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "38",
//						"y": "8",
//						"w": "300",
//						"h": "200",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H4NCVJH60",
//							"editVersion": 46,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4ND05NR0",
//									"editVersion": 112,
//									"attrs": {
//										"type": "hud",
//										"id": "Slides",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H4NEH7760",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEJK5S8",
//													"editVersion": 94,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"success\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H4NEJK5S9",
//													"editVersion": 10,
//													"attrs": {
//														"1H4NEJK5S4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S4",
//															"faceTagName": "rightOver"
//														},
//														"1H4NEJK5S6": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S6",
//															"faceTagName": "rightOut"
//														},
//														"1H4NEJK5S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S0",
//															"faceTagName": "leftOver"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H4NEJK5S10",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H4NEJK5S11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H4ND05NR1",
//									"editVersion": 10,
//									"attrs": {
//										"1H4NEJK5S4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S4",
//											"faceTagName": "rightOver"
//										},
//										"1H4NEJK5S6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S6",
//											"faceTagName": "rightOut"
//										},
//										"1H4NEJK5S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S0",
//											"faceTagName": "leftOver"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H4ND05NR2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H4ND05NR3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H4ND24M40",
//							"editVersion": 37,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4ND24M41",
//									"editVersion": 98,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxLeft",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "80",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "pointer",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H4ND66740",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4ND66741",
//													"editVersion": 182,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%-10",
//														"y": "50%",
//														"w": "20",
//														"h": "20",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "45",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,0.00]",
//														"border": "[0,0,2,2]",
//														"borderStyle": "Solid",
//														"borderColor": "#frontColor",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H4ND66742",
//													"editVersion": 10,
//													"attrs": {
//														"1H4NEJK5S4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S4",
//															"faceTagName": "rightOver"
//														},
//														"1H4NEJK5S6": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S6",
//															"faceTagName": "rightOut"
//														},
//														"1H4NEJK5S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S0",
//															"faceTagName": "leftOver"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H4ND66743",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H4ND66744",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H4ND24M42",
//									"editVersion": 8,
//									"attrs": {
//										"1H4NEJK5S4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH18",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S4",
//											"faceTagName": "rightOver"
//										},
//										"1H4NEJK5S6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH20",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH21",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S6",
//											"faceTagName": "rightOut"
//										},
//										"1H4NEJK5S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH22",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH23",
//													"editVersion": 8,
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S0",
//											"faceTagName": "leftOver"
//										},
//										"1H4NEJK5S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NF6H0O0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NF6H0O1",
//													"editVersion": 4,
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S2",
//											"faceTagName": "leftOut"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H4ND24M43",
//									"editVersion": 4,
//									"attrs": {
//										"OnMouseInOut": {
//											"type": "fixedFunc",
//											"jaxId": "1H4NFEFOR0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H4NFF4T10",
//													"editVersion": 4,
//													"attrs": {
//														"isIn": "",
//														"event": ""
//													}
//												}
//											}
//										},
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H4NFI77R0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H4NFIA8D0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H4ND24M44",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H4ND27NL0",
//							"editVersion": 39,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4ND27NL1",
//									"editVersion": 116,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxRight",
//										"position": "Absolute",
//										"x": "100%-80",
//										"y": "0",
//										"w": "80",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "pointer",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H4ND3OHO0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4ND64N00",
//													"editVersion": 154,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%+10",
//														"y": "50%",
//														"w": "20",
//														"h": "20",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "45",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,0.00]",
//														"border": "[2,2,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#frontColor",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H4ND64N01",
//													"editVersion": 10,
//													"attrs": {
//														"1H4NEJK5S4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH24",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH25",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S4",
//															"faceTagName": "rightOver"
//														},
//														"1H4NEJK5S6": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S6",
//															"faceTagName": "rightOut"
//														},
//														"1H4NEJK5S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H4NEPQPH28",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H4NEPQPH29",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H4NEJK5S0",
//															"faceTagName": "leftOver"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H4ND64N02",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H4ND64N03",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H4ND27NL2",
//									"editVersion": 10,
//									"attrs": {
//										"1H4NEJK5S4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH30",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH31",
//													"editVersion": 8,
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S4",
//											"faceTagName": "rightOver"
//										},
//										"1H4NEJK5S6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH32",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH33",
//													"editVersion": 4,
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S6",
//											"faceTagName": "rightOut"
//										},
//										"1H4NEJK5S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH34",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH35",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S0",
//											"faceTagName": "leftOver"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H4ND27NL3",
//									"editVersion": 4,
//									"attrs": {
//										"OnMouseInOut": {
//											"type": "fixedFunc",
//											"jaxId": "1H4NFGTIJ0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H4NFH2NU0",
//													"editVersion": 4,
//													"attrs": {
//														"isIn": "",
//														"event": ""
//													}
//												}
//											}
//										},
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H4NFHGNA0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H4NFIA8D1",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H4ND27NL4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H4NDCMJM0",
//							"editVersion": 44,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4NEF31G0",
//									"editVersion": 94,
//									"attrs": {
//										"type": "hud",
//										"id": "Footer",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-20",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H4NEF31G1",
//									"editVersion": 10,
//									"attrs": {
//										"1H4NEJK5S4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH36",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH37",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S4",
//											"faceTagName": "rightOver"
//										},
//										"1H4NEJK5S6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH38",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH39",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S6",
//											"faceTagName": "rightOut"
//										},
//										"1H4NEJK5S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H4NEPQPH40",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H4NEPQPH41",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H4NEJK5S0",
//											"faceTagName": "leftOver"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H4NEF31G2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H4NEF31G3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H4NCJO0F7",
//					"editVersion": 10,
//					"attrs": {
//						"1H4NEJK5S4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H4NEPQPH42",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4NEPQPH43",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H4NEJK5S4",
//							"faceTagName": "rightOver"
//						},
//						"1H4NEJK5S6": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H4NEPQPH44",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4NEPQPH45",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H4NEJK5S6",
//							"faceTagName": "rightOut"
//						},
//						"1H4NEJK5S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H4NEPQPH46",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H4NEPQPH47",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H4NEJK5S0",
//							"faceTagName": "leftOver"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H4NCJO0F8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H4NCJO0F9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H4NCJO0F10",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "true",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}