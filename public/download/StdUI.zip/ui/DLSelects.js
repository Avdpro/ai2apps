//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "./BtnCheck.js";
/*#{1HQV9FE9T0StartDoc*/
/*}#1HQV9FE9T0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLSelects=function(box,template,dataObj,property,opts,title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxIcon,txtLabel,txtValue,boxSelects;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let value=dataObj[property];
	let pptTemplate=template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value));
	let edit=(!pptTemplate.readOnly) && opts.edit && (!box || box.edit);
	let icon=pptTemplate.icon;
	let labelLine=!!opts.labelLine;
	let choices=pptTemplate.choices||["No","Yes"];
	let description=edit?pptTemplate.desc:null;
	let valueGap=choices?3:(opts.labelLine?6:3);
	let menuGap=opts.labelLine?6:3;
	let radio=false;
	
	/*#{1HQ1EDCKJ1LocalVals*/
	const app=VFACT.app;
	let traced=null;
	let lines=[];
	let valueSet=null;
	let value2Text=null;
	radio=pptTemplate.type!=="array";
	if(!radio){
		choices=pptTemplate.element.choices;
	}
	choices=choices||[{text:"Select 1",value:"1"},{text:"Select 2",value:"2"}];
	/*}#1HQ1EDCKJ1LocalVals*/
	
	/*#{1HQ1EDCKJ1PreState*/
	/*}#1HQ1EDCKJ1PreState*/
	/*#{1HQ1EDCKJ1PostState*/
	/*}#1HQ1EDCKJ1PostState*/
	cssVO={
		"hash":"1HQ1EDCKJ1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,opts.lineGap?opts.lineGap:5,0],"padding":[0,0,0,0],"minW":"","minH":opts?(opts.lineHeight||25):25,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HQ1F1DNF0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":opts?(opts.lineHeight-3):22,"h":opts?(opts.lineHeight-3):22,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1HQ1GLVEK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-y",
				"itemsWrap":1,"itemsAlign":1,
				children:[
					{
						"hash":"1HQ1GMNN90",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":opts.labelColor,
						"text":title||(pptTemplate.label?pptTemplate.label:(property+":")),"fontSize":opts?(opts.labelSize||12):14,"fontWeight":(opts?(opts.labelBold||false):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HQ1GNGQ60",
						"type":"text","id":"TxtValue","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":"","margin":[2,0,5,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":opts.valueColor,"text":value,"fontSize":opts?(opts.noteSize||opts.valueSize||16):16,"fontWeight":(opts?(!!opts.valueBold):false)?"bold":"normal",
						"fontStyle":"normal","textDecoration":"","wrap":true,
					},
					{
						"hash":"1HQV9H1I40",
						"type":"hud","id":"BoxSelects","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,20],"minW":"","minH":20,"maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-y","attached":!!edit,
						children:[
						],
					},
					{
						"hash":"1HQ1JKTFQ0",
						"type":"text","id":"TxtDesc","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":description,"fontSize":opts?(opts.descSize||12):12,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","wrap":true,"attached":!!description,
					}
				],
			}
		],
		/*#{1HQ1EDCKJ1ExtraCSS*/
		get $$property(){
			return property;
		},
		set $$property(p){
			return property=p;
		},
		template:pptTemplate,
		get $$value(){
			return value;
		},
		set $$value(val){
			return self.commitEdit(val);
		},
		/*}#1HQ1EDCKJ1ExtraCSS*/
		faces:{
			"error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":cfgColor["error"]
				}
			},"!error":{
				/*TxtLabel*/"#1HQ1GMNN90":{
					"color":opts.labelColor
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxIcon=self.BoxIcon;txtLabel=self.TxtLabel;txtValue=self.TxtValue;boxSelects=self.BoxSelects;
			/*#{1HQ1EDCKJ1Create*/
			if(edit){
				self.initSelects();
			}
			self.postCheck();
			/*}#1HQ1EDCKJ1Create*/
		},
		/*#{1HQ1EDCKJ1EndCSS*/
		/*}#1HQ1EDCKJ1EndCSS*/
	};
	/*#{1HQ1EDCKJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initSelects=function(){
		let lineCSS,line,stub;
		boxSelects.clearChildren();
		valueSet=new Set(value);
		value2Text={};
		lines.splice(0);
		if(radio){
			for(stub of choices){
				if(typeof(stub)==="string"){
					stub={text:stub,value:stub};
				}
				lineCSS={
					"type":BtnCheck(opts?(Math.max(opts.lineHeight-20,16)):20,stub.text,value===stub.value,true),"position":"relative","x":0,"y":0,"fontSize":opts?(opts.valueSize||14):14,
					"margin":[0,0,5,0],stub:stub,value:stub.value,
					OnCheck(checked){
						self.commitEdit(this.value);
						box._OnEdit && box._OnEdit();
					}
				};
				lines.push(boxSelects.appendNewChild(lineCSS));
				value2Text[stub.value]=stub.text;
			}
		}else{
			for(stub of choices){
				if(stub===undefined){
					continue;
				}
				if(typeof(stub)==="string"){
					stub={text:stub,value:stub};
				}
				lineCSS={
					"type":BtnCheck(opts?(Math.max(opts.lineHeight-20,16)):20,stub.text,valueSet.has(stub.value),false),"position":"relative","x":0,"y":0,"fontSize":opts?(opts.valueSize||14):14,
					"margin":[0,0,5,0],stub:stub,value:stub.value,
					OnCheck(checked){
						self.readSelects();
						self.commitEdit(value);
						box._OnEdit && box._OnEdit();
					}
				};
				lines.push(boxSelects.appendNewChild(lineCSS));
				value2Text[stub.value]=stub.text;
			}
		}
		if(radio){
			self.updateRadios();
		}else{
			self.updateSelects();
		}
	};
	//------------------------------------------------------------------------
	cssVO.commitEdit=function(val){
		if(pptTemplate.checkValue){
			if(!pptTemplate.checkValue(val)){
				val=value;
			}
		}
		if(val!==value){
			value=val;
			self.updateValue();
		}
		return value;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDataChange=function(){
		value=dataObj[property];
		self.updateValue();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateLabel=function(label){
		txtLabel.text=label||(property+":");
	};
	
	//------------------------------------------------------------------------
	cssVO.makeShowText=function(){
		let text,val,i,n;
		if(radio){
			text=value2Text[value]||value;
		}else{
			text="";
			n=value.length;
			for(i=0;i<n;i++){
				val=value[i];
				if(i>0){
					text+=", "
				}
				text+=value2Text[val];
			}
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	cssVO.updateValue=function(){
		if(txtValue){
			txtValue.text=self.makeShowText();
		}
		if(radio){
			self.updateRadios();
		}else{
			self.updateSelects();
		}
		self.postCheck();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateRadios=function(){
		let line;
		for(line of lines){
			if(line.value===value){
				line.checked=true;
				line.uiEvent=-1;
			}else{
				line.checked=false;
				line.uiEvent=1;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.readSelects=function(){
		let line;
		value=[];
		for(line of lines){
			if(line.checked){
				value.push(line.value);
			}
		}
		valueSet=new Set(value);
	};

	//------------------------------------------------------------------------
	cssVO.updateSelects=function(){
		let line;
		value=[];
		for(line of lines){
			if(valueSet.has(line.value)){
				line.checked=true;
			}else{
				line.checked=false;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.postCheck=function(){
		if(edit){
			if(pptTemplate.required){
				if(!value){
					self.showFace("error");
				}else{
					self.showFace("!error");
				}
			}
		}
	};
	/*}#1HQ1EDCKJ1PostCSSVO*/
	return cssVO;
};
/*#{1HQ1EDCKJ1ExCodes*/
/*}#1HQ1EDCKJ1ExCodes*/


/*#{1HQV9FE9T0EndDoc*/
/*}#1HQV9FE9T0EndDoc*/

export default DLSelects;
export{DLSelects};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HQV9FE9T0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HQ1EDCKK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HQ1EDCKK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HQ1EDCKK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HQ1EDCKK3",
//			"attrs": {
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"template": {
//					"type": "auto",
//					"valText": "#{properties:{mode:{type:\"string\",label:\"Mode\",description:\"This is mode\",choices:[\"a\",\"b\",\"c\"]}}}"
//				},
//				"dataObj": {
//					"type": "auto",
//					"valText": "#{mode:\"a\"}"
//				},
//				"property": {
//					"type": "string",
//					"valText": "mode"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "#{lineHeight: 40, labelSize: 12, labelColor:[0,0,200,1], valueSize: 18, valueColor:[0,0,0,1], labelLine: 1, edit:1}"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HQ1EDCKK4",
//			"attrs": {
//				"value": {
//					"type": "auto",
//					"valText": "#dataObj[property]"
//				},
//				"pptTemplate": {
//					"type": "auto",
//					"valText": "#template.element||(template.properties?template.properties[property]:VFACT.genTemplateByVal(value))"
//				},
//				"edit": {
//					"type": "bool",
//					"valText": "#(!pptTemplate.readOnly) && opts.edit && (!box || box.edit)"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#null//appCfg.sharedAssets+\"/inc.svg\"#>pptTemplate.icon"
//				},
//				"labelLine": {
//					"type": "bool",
//					"valText": "#!!opts.labelLine"
//				},
//				"choices": {
//					"type": "auto",
//					"valText": "#pptTemplate.choices||[\"No\",\"Yes\"]"
//				},
//				"description": {
//					"type": "string",
//					"valText": "#edit?pptTemplate.desc:null"
//				},
//				"valueGap": {
//					"type": "int",
//					"valText": "#choices?3:(opts.labelLine?6:3)"
//				},
//				"menuGap": {
//					"type": "int",
//					"valText": "#opts.labelLine?6:3"
//				},
//				"radio": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HQ1EDCKK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HQ1EDCKK6",
//			"attrs": {
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VN1I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND0",
//							"attrs": {}
//						}
//					}
//				},
//				"!error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HQ20VNIQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HQ2126ND1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HQ1EDCKK7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HQ1EDCKJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HQ1EDCKK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "#[0,0,opts.lineGap?opts.lineGap:5,0]",
//						"padding": "[0,0,0,0]",
//						"minW": "",
//						"minH": "#opts?(opts.lineHeight||25):25",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HQ1F1DNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1F383P0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#opts?(opts.lineHeight-3):22",
//										"h": "#opts?(opts.lineHeight-3):22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HQ1F383P1",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HJ1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1F383P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1F383P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HQ1GLVEK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQ1H5UQ40",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GMNN90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GMNN91",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.labelColor",
//														"text": "#title||(pptTemplate.label?pptTemplate.label:(property+\":\"))",
//														"font": "",
//														"fontSize": "#opts?(opts.labelSize||12):14",
//														"bold": "#opts?(opts.labelBold||false):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GMNNA0",
//													"attrs": {
//														"1HQ20VN1I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND5",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"error\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VN1I0",
//															"faceTagName": "error"
//														},
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQ2126ND6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQ2126ND7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#opts.labelColor"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GMNNA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GMNNA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1GNGQ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1GNGQ61",
//													"attrs": {
//														"type": "text",
//														"id": "TxtValue",
//														"position": "relative",
//														"x": "5",
//														"y": "0",
//														"w": "100%-10",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[2,0,5,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#opts.valueColor",
//														"text": "#value",
//														"font": "",
//														"fontSize": "#opts?(opts.noteSize||opts.valueSize||16):16",
//														"bold": "#opts?(!!opts.valueBold):false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1GNGQ62",
//													"attrs": {
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQMCM8HJ2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQMCM8HJ3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1GNGQ63",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1GNGQ64",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HQV9H1I40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQV9HL490",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxSelects",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,20]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"attach": "#!!edit"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1LD0QTJ0",
//															"jaxId": "1HQV9OOM60",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HQV9QU210",
//																	"attrs": {
//																		"size": "#opts?(Math.max(opts.lineHeight-20,16)):20",
//																		"text": "Select 1",
//																		"checked": "true",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HQV9QU211",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(opts?(Math.max(opts.lineHeight-20,16)):20,\"Select 1\",true,false)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"fontSize": {
//																			"type": "int",
//																			"valText": "#opts?(opts.valueSize||14):14"
//																		},
//																		"margin": "[0,0,5,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HQV9QU212",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HQV9QU213",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HQV9QU214",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HQV9QU215",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1H1LD0QTJ0",
//															"jaxId": "1HQV9V0NI0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HQV9V0NI1",
//																	"attrs": {
//																		"size": "#opts?(Math.max(opts.lineHeight-20,16):20",
//																		"text": "Select 2",
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HQV9V0NI2",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(opts?(Math.max(opts.lineHeight-20,16):20,\"Select 2\",false,false)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"fontSize": {
//																			"type": "int",
//																			"valText": "#opts?(opts.valueSize||14):14"
//																		}
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HQV9V0NI3",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HQV9V0NI4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HQV9V0NI5",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HQV9V0NI6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HQV9HL491",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HQV9HL492",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQV9HL493",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HQ1JKTFQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQ1JO33U0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDesc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,0,0]",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#description",
//														"font": "",
//														"fontSize": "#opts?(opts.descSize||12):12",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!description"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HQ1JO33U1",
//													"attrs": {
//														"1HQ20VNIQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HQMCM8HK2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HQMCM8HK3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HQ20VNIQ0",
//															"faceTagName": "!error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HQ1JO33U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HQ1JO33U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HQ1H5UQ41",
//									"attrs": {
//										"1HQ20VNIQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HQMCM8HK4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HQMCM8HK5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HQ20VNIQ0",
//											"faceTagName": "!error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HQ1H5UQ42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HQ1H5UQ43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HQ1EDCKK9",
//					"attrs": {
//						"1HQ20VNIQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HQMCM8HK6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HQMCM8HK7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HQ20VNIQ0",
//							"faceTagName": "!error"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HQ1EDCKK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HQ1EDCKK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HQ1EDCKK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}