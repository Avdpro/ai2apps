//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxSyncSubDir} from "./BoxSyncSubDir.js";
import {BtnText} from "./BtnText.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1HIOTKLE50StartDoc*/
import {tabFS} from "/@tabos";
import {syncDisk} from "/@disk/sync.js";
/*}#1HIOTKLE50StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgSyncDir=function(buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,edSyncPath,boxDirs,btnMenu,txtError,boxButtons,btnYes,btnNo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let localPath="";
	let syncPath="";
	let dlgVO=null;
	let diskJSON=null;
	let syncSubDirs=null;
	
	/*#{1H1T7ISV51LocalVals*/
	let app;
	app=VFACT.app;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":(($ln==="CN")?("与服务器目录同步"):("Sync folder with server")),"msAction":"delete",
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":"40%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":10,"minW":360,"minH":"","maxW":500,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":8,"shadowY":16,"shadowBlur":10,"shadowColor":[0,0,0,0.2],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":30,"maxW":"","maxH":500,"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HIOTP98I0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Server folder path:",
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HIOTQ7BB0",
						"type":"edit","id":"EdSyncPath","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":20,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","placeHolder":"Input server folder path","color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.smallPlus,
						"outline":0,"border":[0,0,1,0],
					},
					{
						"hash":"1HJAQNDJ60",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HJAR0SSO0",
								"type":"hud","id":"BoxDirs","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HJAS8FO30",
										"type":BoxSyncSubDir({name:"SYNC/handler",dir:"handler"}),"position":"relative","x":0,"y":0,
									}
								],
							},
							{
								"hash":"1HJAQPC680",
								"type":"hud","id":"BoxAddDir","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HJAQR2AM0",
										"type":BtnText("primary",120,22,(($ln==="CN")?("添加子目录"):("Add Sub Dir")),false,""),"id":"BtnAddDir","x":">calc(100% - 130px)","y":"50%","anchorY":1,
										"OnClick":function(event){
											self.OnAddSubDir(this,event);
										},
									}
								],
							}
						],
					},
					{
						"hash":"1HIOTUHQL0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1HIOTVP850",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.btnMenuOnClick(this,event);
								},
							},
							{
								"hash":"1HIOU13TR0",
								"type":"text","id":"TxtMSAction","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBody"],"text":(($ln==="CN")?($P(()=>(`本地缺失项目：${state.msAction==="delete"?"删除服务器项目":"下载"}`),state)):($P(()=>(`Local missing items: ${state.msAction==="delete"?"Delete on server":"Download"}`),state))),
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HIOUONAP0",
						"type":"text","id":"TxtError","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":[0,0,0],"text":"Error message","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,"attached":!!buttons,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",100,24,(($ln==="CN")?("同步"):("Sync")),false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1HIP0O3T90FunctionBody*/
							self.doSync();
							/*}#1HIP0O3T90FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",100,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(false);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
			"init":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("服务器目录路径:"):("Server folder path:")),"alignH":0
				},
				/*EdSyncPath*/"#1HIOTQ7BB0":{
					"display":1
				},
				"#1HJAQNDJ60":{
					"display":1
				},
				"#1HIOTUHQL0":{
					"display":1
				},
				/*BtnMenu*/"#1HIOTVP850":{
					"display":1
				},
				/*TxtMSAction*/"#1HIOU13TR0":{
					"display":1
				},
				/*TxtError*/"#1HIOUONAP0":{
					"display":0
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":1
				},
				/*BtnYes*/"#1H1T802O00":{
					"display":1
				},
				/*BtnNo*/"#1H1T820FU0":{
					"display":1,"text":(($ln==="CN")?("取消"):("Cancel"))
				}
			},"work":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("正在同步目录……"):("Syncing dir...")),"alignH":1
				},
				/*EdSyncPath*/"#1HIOTQ7BB0":{
					"display":0
				},
				"#1HJAQNDJ60":{
					"display":0
				},
				"#1HIOTUHQL0":{
					"display":0
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":0
				}
			},"error":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("同步目录失败:"):("Sync dir failed:")),"alignH":0
				},
				"#1HJAQNDJ60":{
					"display":0
				},
				/*TxtError*/"#1HIOUONAP0":{
					"display":1,"margin":[5,0,0,0]
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":1
				},
				/*BtnYes*/"#1H1T802O00":{
					"display":0
				},
				/*BtnNo*/"#1H1T820FU0":{
					"display":1,"text":(($ln==="CN")?("关闭"):("Close"))
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;edSyncPath=self.EdSyncPath;boxDirs=self.BoxDirs;btnMenu=self.BtnMenu;txtError=self.TxtError;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.initDlg=async function(){
		/*#{1HIOVDCKV0Start*/
		let json;
		/*}#1HIOVDCKV0Start*/
		self.showFace("init");
		try{
			/*#{1HIP05LDL1*/
			json=await tabFS.readFile(localPath+"/disk.json","utf8");
			json=JSON.parse(json);
			/*}#1HIP05LDL1*/
		}catch(error){
			/*#{1HIP05LDL3*/
			json={};
			/*}#1HIP05LDL3*/
		}
		/*#{1HIP0EPP40*/
		boxDirs.clearChildren();
		syncSubDirs=null;
		if(json.syncDir){
			syncPath=json.syncDir.name;
			{
				let subDirs,dirVO,css;
				subDirs=json.syncDir.dirs;
				if(subDirs){
					for(dirVO of subDirs){
						css={
							type:BoxSyncSubDir(dirVO),position:"relative",
							OnSubDirRemove:self.OnSubDirRemove
						}
						boxDirs.appendNewChild(css);
					}
				}
				if(subDirs && subDirs.length>0){
					syncSubDirs=subDirs;
				}
				state.msAction=json.syncDir.missing||"delete";
			}
		}else{
			syncPath="";
		}
		diskJSON=json;
		edSyncPath.text=syncPath;
		/*}#1HIP0EPP40*/
	};
	//------------------------------------------------------------------------
	cssVO.btnMenuOnClick=async function(sender,event){
		/*#{1HIOVG2600Start*/
		/*}#1HIOVG2600Start*/
		{
			let $items,$item;
			$items=[
				{id:"Delete",text:(($ln==="CN")?("删除"):("Delete"))},
				{id:"Download",text:(($ln==="CN")?("下载"):("Download"))}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btnMenu,items:$items});
			if($item){
				if($item.id==="Delete"){
					/*#{1HIOVJ1B80*/
					state.msAction="delete";
					/*}#1HIOVJ1B80*/
				}else if($item.id==="Download"){
					/*#{1HIOVJ1B81*/
					state.msAction="download";
					/*}#1HIOVJ1B81*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.doSync=async function(){
		/*#{1HIP0OSCG0Start*/
		let diskName,subDirs,dirBoxes;
		syncPath=edSyncPath.text;
		dirBoxes=boxDirs.children;
		if(dirBoxes && dirBoxes.length>0){
			let i,n,dirBox,dirVO,filter,ignores;
			subDirs=[];
			n=dirBoxes.length;
			for(i=0;i<n;i++){
				dirBox=dirBoxes[i];
				dirVO={
					target:dirBox.EdTarget.text,
					dir:dirBox.EdDir.text,
				};
				filter=dirBox.EdFilter.text;
				if(filter){
					dirVO.filter=filter
				}
				ignores=dirBox.EdIgnore.text;
				if(ignores){
					ignores=ignores.split(";");
					dirVO.ignore=ignores;
				}else{
					dirVO.ignore=null;
				}
				subDirs.push(dirVO);
			}
		}
		/*}#1HIP0OSCG0Start*/
		if(!syncPath && !subDirs){
			return;
		}
		self.showFace("work");
		try{
			//DoSync
			/*#{1HIP10KDJ0*/
			diskName=localPath.substring(1);
			if(!diskJSON.syncDir){
				diskJSON.syncDir={};
			}
			diskJSON.syncDir.name=syncPath;
			if(subDirs){
				diskJSON.syncDir.dirs=subDirs;
			}
			diskJSON.syncDir.missing=state.msAction;
			await tabFS.writeFile(localPath+"/disk.json",JSON.stringify(diskJSON,null,"\t"));
			await syncDisk(null,diskName,{missing:state.msAction});
			self.close(true);
			/*}#1HIP10KDJ0*/
		}catch(error){
			//LogError
			/*#{1HIP10KDJ1*/
			console.log(error);
			txtError.text=""+error;
			/*}#1HIP10KDJ1*/
			self.showFace("error");
		}
	};
	//------------------------------------------------------------------------
	cssVO.OnSubDirRemove=async function(sender){
		/*#{1HJASSDKR0Start*/
		boxDirs.removeChild(sender);
		/*}#1HJASSDKR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnAddSubDir=async function(sender,event){
		/*#{1HJATHBK30Start*/
		let css;
		let dirVO={
			target:edSyncPath.text,
			dir:""
		};
		css={
			type:BoxSyncSubDir(dirVO),position:"relative",
			OnSubDirRemove:self.OnSubDirRemove
		}
		boxDirs.appendNewChild(css);
		
		/*}#1HJATHBK30Start*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		localPath=vo.path;
		self.initDlg();
		self.animate({type:"in",alpha:0,scale:0.9,time:100,OnFinish(){
			if(dlgVO.run && (syncPath || syncSubDirs)){
				self.doSync();
			}
		}});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	cssVO.constructor=DlgSyncDir;
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

//----------------------------------------------------------------------------
DlgSyncDir.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1T7ISV51PreAISpot*/
	/*}#1H1T7ISV51PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("标准对话框"):("Standard Dialog"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1T7ISV51PostAISpot*/
	/*}#1H1T7ISV51PostAISpot*/
	return exposeVO;
};

/*#{1HIOTKLE50EndDoc*/
/*}#1HIOTKLE50EndDoc*/

export default DlgSyncDir;
export{DlgSyncDir};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HIOTKLE50",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "iPad 768x1024",
//				"screenW": "768",
//				"screenH": "1024",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {
//				"localPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"syncPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"dlgVO": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"diskJSON": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"syncSubDirs": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Sync folder with server",
//					"localize": {
//						"EN": "Sync folder with server",
//						"CN": "与服务器目录同步"
//					},
//					"localizable": true
//				},
//				"msAction": {
//					"type": "string",
//					"valText": "delete"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIOVDCKV0",
//					"attrs": {
//						"id": "initDlg",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HIOVDCL00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HIOVDCL01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HIOVDCL02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIOVQ75V0"
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIOVG2600",
//					"attrs": {
//						"id": "btnMenuOnClick",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "270",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HIOVJ1BB0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HIOVJ1BB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HIOVJ1BB2",
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btnMenu",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HIOVG7CM0",
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "Delete",
//															"localize": {
//																"EN": "Delete",
//																"CN": "删除"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1HIOVJ1B80"
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HIOVG7CM1",
//													"attrs": {
//														"id": "Download",
//														"text": {
//															"type": "string",
//															"valText": "Download",
//															"localize": {
//																"EN": "Download",
//																"CN": "下载"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1HIOVJ1B81"
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HIOVJ1BB3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIOVJ1B81",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "550",
//										"y": "300",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HIOVJ1BB4",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HIOVJ1BB5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIOVJ1BB2"
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIOVJ1B80",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "550",
//						"y": "200",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"jaxId": "1HIOVJ1BB6",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "SetFace",
//					"jaxId": "1HIOVQ75V0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"component": "self",
//						"face": "init",
//						"outlet": {
//							"jaxId": "1HIOVQ75V1",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP061310"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "TryCatch",
//					"jaxId": "1HIP061310",
//					"attrs": {
//						"id": "ReadJSON",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"outlets": {
//							"jaxId": "1HIP061311",
//							"attrs": {
//								"try": {
//									"jaxId": "1HIP05LDL0",
//									"attrs": {
//										"id": "Try",
//										"desc": "输出节点。",
//										"codes": "false"
//									},
//									"linkedSeg": "1HIP05LDL1"
//								},
//								"catch": {
//									"jaxId": "1HIP05LDL2",
//									"attrs": {
//										"id": "Catch",
//										"desc": "输出节点。",
//										"codes": "false"
//									},
//									"linkedSeg": "1HIP05LDL3"
//								}
//							}
//						},
//						"outlet": {
//							"jaxId": "1HIP061312",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP0EPP40"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP05LDL1",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "20",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"jaxId": "1HIP061313",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP05LDL3",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"jaxId": "1HIP061314",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP0EPP40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "130",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"jaxId": "1HIP0F3VI0",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIP0OSCG0",
//					"attrs": {
//						"id": "doSync",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "420",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HIP0OSCL0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HIP0OSCL1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Condition",
//									"jaxId": "1HIP0QLGU0",
//									"attrs": {
//										"id": "CheckPath",
//										"label": "New AI Seg",
//										"x": "300",
//										"y": "420",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "ConditionOutlet",
//													"jaxId": "1HIP0PKJ00",
//													"attrs": {
//														"id": "NoPath",
//														"condition": "!syncPath && !subDirs",
//														"codes": "false",
//														"desc": "条件输出节点。"
//													},
//													"linkedSeg": "1HIP10U090"
//												}
//											]
//										},
//										"catchlet": {
//											"jaxId": "1HIP0QLGM0",
//											"attrs": {
//												"id": "else",
//												"desc": "输出节点。",
//												"codes": "false"
//											}
//										},
//										"outlet": {
//											"jaxId": "1HIP0QLGU1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U091"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HIP10U090",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "390",
//										"desc": "",
//										"codes": "false",
//										"result": ""
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "TryCatch",
//									"jaxId": "1HIP10U092",
//									"attrs": {
//										"id": "TrySync",
//										"label": "New AI Seg",
//										"x": "740",
//										"y": "490",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"jaxId": "1HIP10U093",
//											"attrs": {
//												"try": {
//													"jaxId": "1HIP10U094",
//													"attrs": {
//														"id": "Try",
//														"desc": "输出节点。",
//														"codes": "false"
//													},
//													"linkedSeg": "1HIP10KDJ0"
//												},
//												"catch": {
//													"jaxId": "1HIP10U095",
//													"attrs": {
//														"id": "Catch",
//														"desc": "输出节点。",
//														"codes": "false"
//													},
//													"linkedSeg": "1HIP10KDJ1"
//												}
//											}
//										},
//										"outlet": {
//											"jaxId": "1HIP10U096",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HIP10U091",
//									"attrs": {
//										"id": "ShowWor",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "490",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "work",
//										"outlet": {
//											"jaxId": "1HIP10U097",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U092"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIP10KDJ0",
//									"attrs": {
//										"id": "DoSync",
//										"label": "New AI Seg",
//										"x": "950",
//										"y": "410",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HIP10U098",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIP10KDJ1",
//									"attrs": {
//										"id": "LogError",
//										"label": "New AI Seg",
//										"x": "950",
//										"y": "540",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HIP10U099",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U0910"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HIP10U0910",
//									"attrs": {
//										"id": "ShowError",
//										"label": "New AI Seg",
//										"x": "1140",
//										"y": "540",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "error",
//										"outlet": {
//											"jaxId": "1HIP10U0911",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HIP0OSCL2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP0QLGU0"
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJASSDKR0",
//					"attrs": {
//						"id": "OnSubDirRemove",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "570",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJASSDL30",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HJASSDL31",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HJASSDL32",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HJATHBK30",
//					"attrs": {
//						"id": "OnAddSubDir",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "670",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HJATHPMK0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HJATHPMK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HJATHPMK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HIOUEJ7T1",
//							"attrs": {}
//						}
//					}
//				},
//				"work": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HIOUEJ7T3",
//							"attrs": {}
//						}
//					}
//				},
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HIOUEJ7T5",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HIOTKLGD0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "40%",
//						"w": "90%",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "360",
//						"minH": "",
//						"maxW": "500",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "8",
//										"shadowY": "16",
//										"shadowBlur": "10",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.20]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOVDCL11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										},
//										"1HIOUEJ7T2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJASAACJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJASAACJ1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T2",
//											"faceTagName": "work"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOVDCL15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										},
//										"1HIOUEJ7T2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJASAACJ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJASAACJ3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T2",
//											"faceTagName": "work"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "500",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HIOTP98I0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOU98SJ0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Server folder path:",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HIOU98SJ1",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUIQOQ7",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Server folder path:",
//																			"localize": {
//																				"EN": "Server folder path:",
//																				"CN": "服务器目录路径:"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": {
//																			"type": "choice",
//																			"valText": "Left"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHP6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUNCHP7",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Syncing dir...",
//																			"localize": {
//																				"EN": "Syncing dir...",
//																				"CN": "正在同步目录……"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": {
//																			"type": "choice",
//																			"valText": "Center"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL012",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL013",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Sync dir failed:",
//																			"localize": {
//																				"EN": "Sync dir failed:",
//																				"CN": "同步目录失败:"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": {
//																			"type": "choice",
//																			"valText": "Left"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HIOU98SJ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HIOU98SJ3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HIOTQ7BB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOU98SJ4",
//													"attrs": {
//														"type": "edit",
//														"id": "EdSyncPath",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "Input server folder path",
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "#cfgColor[\"body\"]",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HIOU98SJ5",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUIQOQ9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHP8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUNCHP9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HIOU98SJ6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HIOU98SJ7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HJAQNDJ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJAQVEG30",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HJAR0SSO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJAR22500",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxDirs",
//																		"position": "relative",
//																		"x": "10",
//																		"y": "0",
//																		"w": "100%-20",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1HJAR4GIA0",
//																			"jaxId": "1HJAS6BNF0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HJAS70UT0",
//																					"attrs": {
//																						"dirVO": "#{name:\"SYNC/handler\",dir:\"handler\"}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HJAS70UT1",
//																					"attrs": {
//																						"type": "#null#>BoxSyncSubDir({name:\"SYNC/handler\",dir:\"handler\"})",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HJAS70UT2",
//																					"attrs": {
//																						"1HIOUEJ7T0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T0",
//																							"faceTagName": "init"
//																						},
//																						"1HIOUEJ7T2": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T2",
//																							"faceTagName": "work"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HJAS70UT3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HJAS70UT4",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HJAS70UT5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1HJAR4GIA0",
//																			"jaxId": "1HJAS8FO30",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HJASAACJ10",
//																					"attrs": {
//																						"dirVO": "#{name:\"SYNC/handler\",dir:\"handler\"}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HJASAACJ11",
//																					"attrs": {
//																						"type": "#null#>BoxSyncSubDir({name:\"SYNC/handler\",dir:\"handler\"})",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HJASAACJ12",
//																					"attrs": {
//																						"1HIOUEJ7T0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ13",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ14",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T0",
//																							"faceTagName": "init"
//																						},
//																						"1HIOUEJ7T2": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ15",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ16",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T2",
//																							"faceTagName": "work"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HJASAACJ19",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HJASAACJ20",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HJASAACJ21",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HJAR22501",
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T2",
//																			"faceTagName": "work"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HJAR22502",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HJAR22503",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HJAQPC680",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJAQVEG31",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxAddDir",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1H1KB50JO0",
//																			"jaxId": "1HJAQR2AM0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HJAQVEG32",
//																					"attrs": {
//																						"style": "primary",
//																						"w": "120",
//																						"h": "22",
//																						"text": {
//																							"type": "string",
//																							"valText": "Add Sub Dir",
//																							"localize": {
//																								"EN": "Add Sub Dir",
//																								"CN": "添加子目录"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HJAQVEG33",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"primary\",120,22,(($ln===\"CN\")?(\"添加子目录\"):(\"Add Sub Dir\")),false,\"\")",
//																						"id": "BtnAddDir",
//																						"position": "Absolute",
//																						"x": "100%-130",
//																						"y": "50%",
//																						"display": "On",
//																						"face": "",
//																						"anchorV": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HJAQVEG34",
//																					"attrs": {
//																						"1HIOUEJ7T0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T0",
//																							"faceTagName": "init"
//																						},
//																						"1HIOUEJ7T2": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJASAACJ30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJASAACJ31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HIOUEJ7T2",
//																							"faceTagName": "work"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HJAQVEG35",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HJATHPMK3",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HJATHPMK4",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HJATHBK30"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HJAQVEG36",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HJAQVEG37",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HJAQVEG38",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HJAQVEG39",
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T2",
//																			"faceTagName": "work"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HJAQVEG310",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HJAQVEG311",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HJAQVEG312",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ41",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ43",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ45",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HJAQVEG313",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HJAQVEG314",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HIOTUHQL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOU98SJ8",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1KJQ5RK0",
//															"jaxId": "1HIOTVP850",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HIOU98SJ9",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HIOU98SJ10",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnMenu",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HIOU98SJ11",
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOUIQOQ10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HIOUIQOQ11",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T2",
//																			"faceTagName": "work"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HIOU98SJ12",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HIOVJ1BC0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HIOVJ1BC1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HIOVG2600"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HIOU98SJ13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HIOU98SK0",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HIOU13TR0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOU98SK1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtMSAction",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "${`Local missing items: ${state.msAction===\"delete\"?\"Delete on server\":\"Download\"}`},state",
//																			"localize": {
//																				"EN": "${`Local missing items: ${state.msAction===\"delete\"?\"Delete on server\":\"Download\"}`},state",
//																				"CN": "${`本地缺失项目：${state.msAction===\"delete\"?\"删除服务器项目\":\"下载\"}`},state"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HIOU98SK2",
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOUIQOQ12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HIOUIQOQ13",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJASAACJ48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJASAACJ49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T2",
//																			"faceTagName": "work"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HIOU98SK3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HIOU98SK4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HIOU98SK5",
//													"attrs": {
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHQ4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUNCHQ5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL020",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL021",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HIOU98SK6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HIOU98SK7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HIOUONAP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOV1JL024",
//													"attrs": {
//														"type": "text",
//														"id": "TxtError",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Error message",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HIOV1JL025",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL026",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL027",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL030",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL031",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"margin": {
//																			"type": "auto",
//																			"valText": "[5,0,0,0]",
//																			"editMode": "edges"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HIOV1JL032",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HIOV1JL033",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOVDCL17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										},
//										"1HIOUEJ7T2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJASAACJ52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJASAACJ53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T2",
//											"faceTagName": "work"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "#!!buttons",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T81V2B0",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Sync",
//															"localize": {
//																"EN": "Sync",
//																"CN": "同步"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T81V2B1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"同步\"):(\"Sync\")),false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T81V2B2",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUIQOQ19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL038",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL039",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1T81V2B3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HIP0O3T90",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HIP0OSCM0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T81V2B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V1",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AD1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H1T820FU1",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Cancel",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1H1T820FU2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H1T820FU3",
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOUIQOQ21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"text": {
//																			"type": "string",
//																			"valText": "Cancel",
//																			"localize": {
//																				"EN": "Cancel",
//																				"CN": "取消"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL040",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HIOV1JL041",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"text": {
//																			"type": "string",
//																			"valText": "Close",
//																			"localize": {
//																				"EN": "Close",
//																				"CN": "关闭"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJASAACJ56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJASAACJ57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H1T820FU4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H1T8JQQ40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H1T820FU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1H211US3V2",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1H8H690AE0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOUIQOQ22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOUIQOQ23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										},
//										"1HIOUEJ7T2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOUNCHQ12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOUNCHQ13",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T2",
//											"faceTagName": "work"
//										},
//										"1HIOUEJ7T4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOV1JL042",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HIOV1JL043",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T4",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {
//						"1HIOUEJ7T0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HIOVDCL18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HIOVDCL19",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HIOUEJ7T0",
//							"faceTagName": "init"
//						},
//						"1HIOUEJ7T2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HJASAACJ58",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJASAACJ59",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HIOUEJ7T2",
//							"faceTagName": "work"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}