//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnText} from "./BtnText.js";
/*#{1HIOTKLE50StartDoc*/
import {tabFS} from "/@tabos";
import {syncDisk} from "/@disk/sync.js";
/*}#1HIOTKLE50StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgSyncDir=function(buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,edSyncPath,btnMenu,txtError,boxButtons,btnYes,btnNo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let localPath="";
	let syncPath="";
	let dlgVO=null;
	let diskJSON=null;
	
	/*#{1H1T7ISV51LocalVals*/
	let app;
	app=VFACT.app;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":(($ln==="CN")?("与服务器目录同步"):("Sync folder with server")),"msAction":"delete",
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":"40%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":10,"minW":360,"minH":"","maxW":500,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HIOTP98I0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","styleClass":"","color":[0,0,0],"text":"Server folder path:","fontWeight":"normal",
						"fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HIOTQ7BB0",
						"type":"edit","id":"EdSyncPath","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":20,"margin":[5,0,0,0],"styleClass":"","placeHolder":"Input server folder path",
						"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
					},
					{
						"hash":"1HIOTUHQL0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":[0,10,0,10],"styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1HIOTVP850",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.btnMenuOnClick(this,event);
								},
							},
							{
								"hash":"1HIOU13TR0",
								"type":"text","id":"TxtMSAction","position":"relative","x":0,"y":0,"w":100,"h":"100%","styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?($P(()=>(`本地缺失项目：${state.msAction==="delete"?"删除服务器项目":"下载"}`),state)):($P(()=>(`Local missing items: ${state.msAction==="delete"?"Delete on server":"Download"}`),state))),
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HIOUONAP0",
						"type":"text","id":"TxtError","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","styleClass":"","color":[0,0,0],"text":"Error message",
						"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,"attached":!!buttons,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",100,24,(($ln==="CN")?("同步"):("Sync")),false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1HIP0O3T90FunctionBody*/
							self.doSync();
							/*}#1HIP0O3T90FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",100,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(false);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
			"init":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("服务器目录路径:"):("Server folder path:")),"alignH":0
				},
				/*EdSyncPath*/"#1HIOTQ7BB0":{
					"display":1
				},
				"#1HIOTUHQL0":{
					"display":1
				},
				/*BtnMenu*/"#1HIOTVP850":{
					"display":1
				},
				/*TxtMSAction*/"#1HIOU13TR0":{
					"display":1
				},
				/*TxtError*/"#1HIOUONAP0":{
					"display":0
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":1
				},
				/*BtnYes*/"#1H1T802O00":{
					"display":1
				},
				/*BtnNo*/"#1H1T820FU0":{
					"display":1,"text":(($ln==="CN")?("取消"):("Cancel"))
				}
			},"work":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("正在同步目录……"):("Syncing dir...")),"alignH":1
				},
				/*EdSyncPath*/"#1HIOTQ7BB0":{
					"display":0
				},
				"#1HIOTUHQL0":{
					"display":0
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":0
				}
			},"error":{
				"#1HIOTP98I0":{
					"text":(($ln==="CN")?("同步目录失败:"):("Sync dir failed:")),"alignH":0
				},
				/*TxtError*/"#1HIOUONAP0":{
					"display":1,"margin":[5,0,0,0]
				},
				/*BoxButtons*/"#1H1T7UCES0":{
					"display":1
				},
				/*BtnYes*/"#1H1T802O00":{
					"display":0
				},
				/*BtnNo*/"#1H1T820FU0":{
					"display":1,"text":(($ln==="CN")?("关闭"):("Close"))
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;edSyncPath=self.EdSyncPath;btnMenu=self.BtnMenu;txtError=self.TxtError;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.initDlg=async function(){
		/*#{1HIOVDCKV0Start*/
		let json;
		/*}#1HIOVDCKV0Start*/
		self.showFace("init");
		try{
			/*#{1HIP05LDL1*/
			json=await tabFS.readFile(localPath+"/disk.json","utf8");
			json=JSON.parse(json);
			/*}#1HIP05LDL1*/
		}catch(error){
			/*#{1HIP05LDL3*/
			json={};
			/*}#1HIP05LDL3*/
		}
		/*#{1HIP0EPP40*/
		if(json.syncDir){
			syncPath=json.syncDir.name;
		}else{
			syncPath="";
		}
		diskJSON=json;
		edSyncPath.text=syncPath;
		/*}#1HIP0EPP40*/
	};
	//------------------------------------------------------------------------
	cssVO.btnMenuOnClick=async function(sender,event){
		/*#{1HIOVG2600Start*/
		/*}#1HIOVG2600Start*/
		{
			let $items,$item;
			$items=[
				{id:"Delete",text:(($ln==="CN")?("删除"):("Delete"))},
				{id:"Download",text:(($ln==="CN")?("下载"):("Download"))}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btnMenu,items:$items});
			if($item){
				if($item.id==="Delete"){
					/*#{1HIOVJ1B80*/
					state.msAction="delete";
					/*}#1HIOVJ1B80*/
				}else if($item.id==="Download"){
					/*#{1HIOVJ1B81*/
					state.msAction="download";
					/*}#1HIOVJ1B81*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.doSync=async function(){
		/*#{1HIP0OSCG0Start*/
		let diskName;
		syncPath=edSyncPath.text;
		/*}#1HIP0OSCG0Start*/
		if(!syncPath){
			return;
		}
		self.showFace("work");
		try{
			/*#{1HIP10KDJ0*/
			diskName=localPath.substring(1);
			if(!diskJSON.syncDir){
				diskJSON.syncDir={};
			}
			diskJSON.syncDir.name=syncPath;
			await tabFS.writeFile(localPath+"/disk.json",JSON.stringify(diskJSON,null,"\t"));
			await syncDisk(null,diskName,null);
			self.close(true);
			/*}#1HIP10KDJ0*/
		}catch(error){
			/*#{1HIP10KDJ1*/
			console.log(error);
			txtError.text=""+error;
			/*}#1HIP10KDJ1*/
			self.showFace("error");
		}
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		localPath=vo.path;
		self.initDlg();
		self.animate({type:"in",alpha:0,scale:0.9,time:100,OnFinish(){
			if(dlgVO.run && syncPath){
				self.doSync();
			}
		}});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/


export default DlgSyncDir;
export{DlgSyncDir};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HIOTKLE50",
//	"editVersion": 162,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1T7ISV52",
//			"editVersion": 12,
//			"attrs": {
//				"device": "iPad 768x1024",
//				"screenW": "768",
//				"screenH": "1024",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1T7ISV53",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8H690AD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV54",
//			"editVersion": 112,
//			"attrs": {
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV55",
//			"editVersion": 34,
//			"attrs": {
//				"localPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"syncPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"dlgVO": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"diskJSON": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1T7ISV56",
//			"editVersion": 38,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "与服务器目录同步",
//					"localize": {
//						"EN": "Sync folder with server",
//						"CN": "与服务器目录同步"
//					},
//					"localizable": true
//				},
//				"msAction": {
//					"type": "string",
//					"valText": "delete"
//				}
//			}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIOVDCKV0",
//					"editVersion": 36,
//					"attrs": {
//						"id": "initDlg",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIOVDCL00",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIOVDCL01",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"segs": {
//							"type": "array",
//							"attrs": []
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIOVDCL02",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIOVQ75V0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIOVG2600",
//					"editVersion": 34,
//					"attrs": {
//						"id": "btnMenuOnClick",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "270",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIOVJ1BB0",
//							"editVersion": 4,
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIOVJ1BB1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"segs": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HIOVJ1BB2",
//									"editVersion": 42,
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "270",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btnMenu",
//										"outlets": {
//											"type": "array",
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HIOVG7CM0",
//													"editVersion": 14,
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "删除",
//															"localize": {
//																"EN": "Delete",
//																"CN": "删除"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1HIOVJ1B80"
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HIOVG7CM1",
//													"editVersion": 14,
//													"attrs": {
//														"id": "Download",
//														"text": {
//															"type": "string",
//															"valText": "下载",
//															"localize": {
//																"EN": "Download",
//																"CN": "下载"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1HIOVJ1B81"
//												}
//											]
//										},
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIOVJ1BB3",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIOVJ1B81",
//									"editVersion": 26,
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "550",
//										"y": "300",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIOVJ1BB4",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIOVJ1BB5",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIOVJ1BB2"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIOVJ1B80",
//					"editVersion": 26,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "550",
//						"y": "200",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIOVJ1BB6",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "SetFace",
//					"jaxId": "1HIOVQ75V0",
//					"editVersion": 32,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"component": "self",
//						"face": "init",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIOVQ75V1",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP061310"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "TryCatch",
//					"jaxId": "1HIP061310",
//					"editVersion": 34,
//					"attrs": {
//						"id": "ReadJSON",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"outlets": {
//							"type": "object",
//							"jaxId": "1HIP061311",
//							"editVersion": 4,
//							"attrs": {
//								"try": {
//									"type": "aioutlet",
//									"def": "AISegOutlet",
//									"jaxId": "1HIP05LDL0",
//									"editVersion": 8,
//									"attrs": {
//										"id": "Try",
//										"desc": "输出节点。",
//										"codes": "false"
//									},
//									"linkedSeg": "1HIP05LDL1"
//								},
//								"catch": {
//									"type": "aioutlet",
//									"def": "AISegOutlet",
//									"jaxId": "1HIP05LDL2",
//									"editVersion": 8,
//									"attrs": {
//										"id": "Catch",
//										"desc": "输出节点。",
//										"codes": "false"
//									},
//									"linkedSeg": "1HIP05LDL3"
//								}
//							}
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIP061312",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP0EPP40"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP05LDL1",
//					"editVersion": 26,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "20",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIP061313",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP05LDL3",
//					"editVersion": 26,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIP061314",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HIP0EPP40",
//					"editVersion": 30,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "130",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIP0F3VI0",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HIP0OSCG0",
//					"editVersion": 36,
//					"attrs": {
//						"id": "doSync",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "420",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIP0OSCL0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HIP0OSCL1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"segs": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Condition",
//									"jaxId": "1HIP0QLGU0",
//									"editVersion": 32,
//									"attrs": {
//										"id": "CheckPath",
//										"label": "New AI Seg",
//										"x": "300",
//										"y": "420",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"type": "array",
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "ConditionOutlet",
//													"jaxId": "1HIP0PKJ00",
//													"editVersion": 14,
//													"attrs": {
//														"id": "NoPath",
//														"condition": "!syncPath",
//														"codes": "false",
//														"desc": "条件输出节点。"
//													},
//													"linkedSeg": "1HIP10U090"
//												}
//											]
//										},
//										"catchlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP0QLGM0",
//											"editVersion": 8,
//											"attrs": {
//												"id": "else",
//												"desc": "输出节点。",
//												"codes": "false"
//											}
//										},
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP0QLGU1",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U091"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Return",
//									"jaxId": "1HIP10U090",
//									"editVersion": 26,
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "390",
//										"desc": "",
//										"codes": "false",
//										"result": ""
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "TryCatch",
//									"jaxId": "1HIP10U092",
//									"editVersion": 52,
//									"attrs": {
//										"id": "TrySync",
//										"label": "New AI Seg",
//										"x": "740",
//										"y": "490",
//										"desc": "",
//										"codes": "false",
//										"outlets": {
//											"type": "object",
//											"jaxId": "1HIP10U093",
//											"editVersion": 4,
//											"attrs": {
//												"try": {
//													"type": "aioutlet",
//													"def": "AISegOutlet",
//													"jaxId": "1HIP10U094",
//													"editVersion": 8,
//													"attrs": {
//														"id": "Try",
//														"desc": "输出节点。",
//														"codes": "false"
//													},
//													"linkedSeg": "1HIP10KDJ0"
//												},
//												"catch": {
//													"type": "aioutlet",
//													"def": "AISegOutlet",
//													"jaxId": "1HIP10U095",
//													"editVersion": 8,
//													"attrs": {
//														"id": "Catch",
//														"desc": "输出节点。",
//														"codes": "false"
//													},
//													"linkedSeg": "1HIP10KDJ1"
//												}
//											}
//										},
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP10U096",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HIP10U091",
//									"editVersion": 38,
//									"attrs": {
//										"id": "ShowWor",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "490",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "work",
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP10U097",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U092"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIP10KDJ0",
//									"editVersion": 36,
//									"attrs": {
//										"id": "DoSync",
//										"label": "New AI Seg",
//										"x": "950",
//										"y": "410",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP10U098",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HIP10KDJ1",
//									"editVersion": 54,
//									"attrs": {
//										"id": "LogError",
//										"label": "New AI Seg",
//										"x": "950",
//										"y": "540",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP10U099",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HIP10U0910"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HIP10U0910",
//									"editVersion": 58,
//									"attrs": {
//										"id": "ShowError",
//										"label": "New AI Seg",
//										"x": "1140",
//										"y": "540",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "error",
//										"outlet": {
//											"type": "aioutlet",
//											"def": "AISegOutlet",
//											"jaxId": "1HIP10U0911",
//											"editVersion": 4,
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HIP0OSCL2",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HIP0QLGU0"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "标准对话框",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1T7ISV57",
//			"editVersion": 6,
//			"attrs": {
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HIOUEJ7T1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"work": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T2",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HIOUEJ7T3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HIOUEJ7T4",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HIOUEJ7T5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HIOTKLGD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1T7ISV58",
//					"editVersion": 198,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "40%",
//						"w": "90%",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "360",
//						"minH": "",
//						"maxW": "500",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"editVersion": 35,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O0",
//									"editVersion": 152,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O1",
//									"editVersion": 16,
//									"attrs": {
//										"1HIOUEJ7T4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOV1JL02",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOV1JL03",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T4",
//											"faceTagName": "error"
//										},
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOVDCL11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"editVersion": 48,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O4",
//									"editVersion": 176,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O5",
//									"editVersion": 16,
//									"attrs": {
//										"1HIOUEJ7T4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOV1JL010",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOV1JL011",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T4",
//											"faceTagName": "error"
//										},
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOVDCL15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"editVersion": 50,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O8",
//									"editVersion": 98,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HIOTP98I0",
//											"editVersion": 33,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ0",
//													"editVersion": 108,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Server folder path:",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ1",
//													"editVersion": 6,
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUIQOQ7",
//																	"editVersion": 10,
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "服务器目录路径:",
//																			"localize": {
//																				"EN": "Server folder path:",
//																				"CN": "服务器目录路径:"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": "Left"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHP6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUNCHP7",
//																	"editVersion": 14,
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "正在同步目录……",
//																			"localize": {
//																				"EN": "Syncing dir...",
//																				"CN": "正在同步目录……"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": "Center"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL012",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL013",
//																	"editVersion": 14,
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "同步目录失败:",
//																			"localize": {
//																				"EN": "Sync dir failed:",
//																				"CN": "同步目录失败:"
//																			},
//																			"localizable": true
//																		},
//																		"alignH": "Left"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HIOU98SJ3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HIOTQ7BB0",
//											"editVersion": 26,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ4",
//													"editVersion": 168,
//													"attrs": {
//														"type": "edit",
//														"id": "EdSyncPath",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "Input server folder path",
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "#cfgColor[\"body\"]",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ5",
//													"editVersion": 6,
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUIQOQ9",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHP8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUNCHP9",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL014",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL015",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HIOU98SJ7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HIOTUHQL0",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOU98SJ8",
//													"editVersion": 160,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1H1KJQ5RK0",
//															"jaxId": "1HIOTVP850",
//															"editVersion": 43,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HIOU98SJ9",
//																	"editVersion": 22,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SJ10",
//																	"editVersion": 29,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnMenu",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SJ11",
//																	"editVersion": 8,
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOUIQOQ10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HIOUIQOQ11",
//																					"editVersion": 4,
//																					"attrs": {
//																						"display": "On"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T4": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOV1JL016",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HIOV1JL017",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T4",
//																			"faceTagName": "error"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SJ12",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HIOVJ1BC0",
//																			"editVersion": 6,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HIOVJ1BC1",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1HIOVG2600"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HIOU98SJ13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SK0",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HIOU13TR0",
//															"editVersion": 22,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SK1",
//																	"editVersion": 142,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtMSAction",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "${`本地缺失项目：${state.msAction===\"delete\"?\"删除服务器项目\":\"下载\"}`},state",
//																			"localize": {
//																				"EN": "${`Local missing items: ${state.msAction===\"delete\"?\"Delete on server\":\"Download\"}`},state",
//																				"CN": "${`本地缺失项目：${state.msAction===\"delete\"?\"删除服务器项目\":\"下载\"}`},state"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SK2",
//																	"editVersion": 8,
//																	"attrs": {
//																		"1HIOUEJ7T0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOUIQOQ12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HIOUIQOQ13",
//																					"editVersion": 4,
//																					"attrs": {
//																						"display": "On"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T0",
//																			"faceTagName": "init"
//																		},
//																		"1HIOUEJ7T4": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HIOV1JL018",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HIOV1JL019",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HIOUEJ7T4",
//																			"faceTagName": "error"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HIOU98SK3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HIOU98SK4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HIOU98SK5",
//													"editVersion": 10,
//													"attrs": {
//														"1HIOUEJ7T2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUNCHQ4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUNCHQ5",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T2",
//															"faceTagName": "work"
//														},
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL020",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL021",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL022",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL023",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HIOU98SK6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HIOU98SK7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HIOUONAP0",
//											"editVersion": 34,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOV1JL024",
//													"editVersion": 132,
//													"attrs": {
//														"type": "text",
//														"id": "TxtError",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Error message",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HIOV1JL025",
//													"editVersion": 8,
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL026",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL027",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL030",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL031",
//																	"editVersion": 22,
//																	"attrs": {
//																		"display": "On",
//																		"margin": "[5,0,0,0]"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HIOV1JL032",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HIOV1JL033",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O9",
//									"editVersion": 16,
//									"attrs": {
//										"1HIOUEJ7T4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOV1JL036",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOV1JL037",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T4",
//											"faceTagName": "error"
//										},
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOVDCL16",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOVDCL17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"editVersion": 42,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O12",
//									"editVersion": 140,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "#!!buttons",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"editVersion": 93,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H1T81V2B0",
//													"editVersion": 54,
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "同步",
//															"localize": {
//																"EN": "Sync",
//																"CN": "同步"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1T81V2B1",
//													"editVersion": 104,
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"同步\"):(\"Sync\")),false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1T81V2B2",
//													"editVersion": 8,
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUIQOQ19",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL038",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL039",
//																	"editVersion": 6,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1T81V2B3",
//													"editVersion": 6,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HIP0O3T90",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HIP0OSCM0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1T81V2B4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H211US3V1",
//													"editVersion": 0,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1H8H690AD1",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"editVersion": 111,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H1T820FU1",
//													"editVersion": 70,
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "取消",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1T820FU2",
//													"editVersion": 101,
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1T820FU3",
//													"editVersion": 8,
//													"attrs": {
//														"1HIOUEJ7T0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOUIQOQ20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOUIQOQ21",
//																	"editVersion": 14,
//																	"attrs": {
//																		"display": "On",
//																		"text": {
//																			"type": "string",
//																			"valText": "取消",
//																			"localize": {
//																				"EN": "Cancel",
//																				"CN": "取消"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T0",
//															"faceTagName": "init"
//														},
//														"1HIOUEJ7T4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HIOV1JL040",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HIOV1JL041",
//																	"editVersion": 14,
//																	"attrs": {
//																		"display": "On",
//																		"text": {
//																			"type": "string",
//																			"valText": "关闭",
//																			"localize": {
//																				"EN": "Close",
//																				"CN": "关闭"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HIOUEJ7T4",
//															"faceTagName": "error"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1T820FU4",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H1T8JQQ40",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1T820FU5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H211US3V2",
//													"editVersion": 0,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1H8H690AE0",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O13",
//									"editVersion": 6,
//									"attrs": {
//										"1HIOUEJ7T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOUIQOQ22",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOUIQOQ23",
//													"editVersion": 4,
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T0",
//											"faceTagName": "init"
//										},
//										"1HIOUEJ7T2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOUNCHQ12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOUNCHQ13",
//													"editVersion": 4,
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T2",
//											"faceTagName": "work"
//										},
//										"1HIOUEJ7T4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HIOV1JL042",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HIOV1JL043",
//													"editVersion": 4,
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HIOUEJ7T4",
//											"faceTagName": "error"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O14",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1T7ISV59",
//					"editVersion": 16,
//					"attrs": {
//						"1HIOUEJ7T4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HIOV1JL046",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HIOV1JL047",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HIOUEJ7T4",
//							"faceTagName": "error"
//						},
//						"1HIOUEJ7T0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HIOVDCL18",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HIOVDCL19",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HIOUEJ7T0",
//							"faceTagName": "init"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1T7ISV510",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1T7ISV511",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"editVersion": 84,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}