//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H05H4GKA0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1H05H4GKA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnAIChatMsg=function(app,msg,ui){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edMessage;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let roleText=$ln!=="CN"?{"raw":"Raw User","user":"User","assistant":"Assistant"}:{"raw":"用户无加工","user":"用户","assistant":"AI助理"};
	
	/*#{1H05H4GKA1LocalVals*/
	let editing, tracing, tokenTimer;
	editing=false;
	tracing=false;
	tokenTimer=null;
	/*}#1H05H4GKA1LocalVals*/
	
	/*#{1H05H4GKA1PreState*/
	/*}#1H05H4GKA1PreState*/
	state={
		"tip":"Input a message here",
		/*#{1H05H4GKA6ExState*/
		/*}#1H05H4GKA6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H05H4GKA1PostState*/
	/*}#1H05H4GKA1PostState*/
	cssVO={
		"hash":"1H05H4GKA1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","padding":[10,5,10,5],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		"msg":msg,
		children:[
			{
				"hash":"1H05H63NR0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"borderColor":cfgColor["lineBodyLit"],
			},
			{
				"hash":"1H0MDDB0B0",
				"type":"text","id":"TxtTip","x":95,"y":10,"w":100,"h":20,"display":$P(()=>(msg.content?false:true),msg),"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodyLit,"text":$P(()=>(state.tip),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H05HEO5U0",
				"type":"memo","id":"EdMessage","position":"relative","x":90,"y":0,"w":">calc(100% - 125px)","h":"","padding":0,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","text":msg.content,"color":cfgColor.fontBody,"background":[255,255,255,0],"font":"helvetica, sans-serif","fontSize":txtSize.smallMid,
				"outline":0,"borderColor":cfgColor.lineBodyLit,"corner":6,
				"OnBlur":function(event){
					/*#{1H0MD1E020FunctionBody*/
					self.endEdit();
					/*}#1H0MD1E020FunctionBody*/
				},
				"OnInput":function(){
					/*#{1H0MDSIEC0FunctionBody*/
					self.syncMsg();
					/*}#1H0MDSIEC0FunctionBody*/
				},
			},
			{
				"hash":"1H0NT2NF60",
				"type":"text","id":"TxtTokens","position":"relative","x":90,"y":5,"w":">calc(100% - 125px)","h":15,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodyLit,"text":$P(()=>(msg.tokens>=0?`Tokens: ${msg.tokens}`:"- - -"),msg),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,
			}
		],
		/*#{1H05H4GKA1ExtraCSS*/
		/*}#1H05H4GKA1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H05HAQES0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HAQES0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["body"]
				},
				/*TxtTip*/"#1H0MDDB0B0":{
					"x":95,"y":10
				},
				/*EdMessage*/"#1H05HEO5U0":{
					"border":0,"padding":[0,0,0,0],"color":cfgColor.fontBody
				}
			},"over":{
				/*#{1H05HB7BH0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HB7BH0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["tool"]
				}
			},"down":{
				/*#{1H05HBU9A0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HBU9A0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["footer"]
				}
			},"edit":{
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["body"]
				},
				/*TxtTip*/"#1H0MDDB0B0":{
					"x":100,"y":15
				},
				/*EdMessage*/"#1H05HEO5U0":{
					"padding":5,"border":1
				}
			},"trace":{
				/*EdMessage*/"#1H05HEO5U0":{
					"color":cfgColor.fontBodyLit
				}
			}
		},
		OnCreate:function(){
			self=this;
			edMessage=self.EdMessage;
			/*#{1H05H4GKA1Create*/
			msg.block=self;
			/*}#1H05H4GKA1Create*/
		},
		/*#{1H05H4GKA1EndCSS*/
		/*}#1H05H4GKA1EndCSS*/
	};
	/*#{1H05H4GKA1PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(editing || tracing)
			return;
		editing=true;
		self.showFace("edit");
		edMessage.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.endEdit=function(){
		editing=false;
		self.showFace("up");
	};
	
	//------------------------------------------------------------------------
	cssVO.doChangeRole=function(btn){
		if(tracing){
			return;
		}
		app.showDlg(DlgMenu,{
			hud:btnRole,
			items:[
				{text:(($ln==="CN")?("用户"):/*EN*/("User")),code:"user"},
				{text:(($ln==="CN")?("AI助理"):/*EN*/("Assistant")),code:"assistant"},
				{text:(($ln==="CN")?("用户无加工"):/*EN*/("User Raw")),code:"raw"},
			],
			callback(item){
				if(!item){
					return;
				}
				ui.aboutChangeDoc(self);
				btnRole.text=item.text;
				msg.role=item.code;
				ui.msgChanged(msg,self);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.syncMsg=function(){
		let text;
		if(tracing)
			return;
		text=edMessage.text;
		if(text!==msg.content){
			ui.aboutChangeDoc(self);
			msg.content=text;
			ui.msgChanged(msg,self);
			msg.tokens=-1;
			self.askToken();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.askToken=function(){
		if(tokenTimer){
			clearTimeout(tokenTimer);
			tokenTimer=null;
		}
		tokenTimer=setTimeout(()=>{
			tokenTimer=null;
			if(msg.tokens>=0)
				return;
			ui.askToken(self);
		},3000);
	};
	
	//------------------------------------------------------------------------
	let traceObj,tracePrefix,tracePostfix;
	let OnUpdate=function (){
		if(traceObj){
			self.EdMessage.text=msg.content=tracePrefix+traceObj.content+tracePostfix;
		}
	};
	let OnClose=function(){
		if(traceObj){
			traceObj.off("content",OnUpdate);
			traceObj.off("close",OnClose);
			traceObj=null;
		}
		tracing=false;
		self.showFace("up");
	};
	cssVO.traceObj=function(obj,prefix="",postfix=""){
		tracing=true;
		traceObj=obj;
		tracePrefix=prefix;
		tracePostfix=postfix;
		self.showFace("trace");
		obj.on("content",OnUpdate);
		obj.on("close",OnClose);
	};
	
	//------------------------------------------------------------------------
	cssVO.stopTrace=OnClose;
	
	/*}#1H05H4GKA1PostCSSVO*/
	cssVO.constructor=BtnAIChatMsg;
	return cssVO;
};
/*#{1H05H4GKA1ExCodes*/
/*}#1H05H4GKA1ExCodes*/

//----------------------------------------------------------------------------
BtnAIChatMsg.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H05H4GKA1PreAISpot*/
	/*}#1H05H4GKA1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H05H4GKA1PostAISpot*/
	/*}#1H05H4GKA1PostAISpot*/
	return exposeVO;
};

/*#{1H05H4GKA0EndDoc*/
/*}#1H05H4GKA0EndDoc*/

export default BtnAIChatMsg;
export{BtnAIChatMsg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H05H4GKA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H05H4GKA2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H05H4GKA3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H9FDVE4O0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H05H4GKA4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"msg": {
//					"type": "auto",
//					"valText": "{\"role\":\"assistant\",\"content\":\"Hello!\"}"
//				},
//				"ui": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H05H4GKA5",
//			"attrs": {
//				"roleText": {
//					"type": "auto",
//					"valText": "#$ln!==\"CN\"?{\"raw\":\"Raw User\",\"user\":\"User\",\"assistant\":\"Assistant\"}:{\"raw\":\"用户无加工\",\"user\":\"用户\",\"assistant\":\"AI助理\"}"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H05H4GKA6",
//			"attrs": {
//				"tip": {
//					"type": "string",
//					"valText": "Input a message here",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H05H4GKA7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HAQES0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HB7BH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HBU9A0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO2",
//							"attrs": {}
//						}
//					}
//				},
//				"edit": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HL0CO3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO4",
//							"attrs": {}
//						}
//					}
//				},
//				"trace": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0MRO7CB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0MRSS550",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA2KENQK0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H05H4GKA1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H05H4GKA8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%-10",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,5,10,5]",
//						"minW": "",
//						"minH": "20",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H05H63NR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO5",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HL0CO6",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO8",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO10",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"tool\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO12",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"footer\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HL0CO13",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HL0CO14",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H0MDDB0B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MDI9MS0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTip",
//										"position": "Absolute",
//										"x": "95",
//										"y": "10",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "${msg.content?false:true},msg",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodyLit",
//										"text": "${state.tip},state",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0MDI9MS1",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0ME7TE52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0ME7TE53",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "95"
//														},
//														"y": {
//															"type": "length",
//															"valText": "10"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0ME7TE54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0ME7TE55",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "100"
//														},
//														"y": {
//															"type": "length",
//															"valText": "15"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MFFSGE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MFFSGE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS557",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS558",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0MDI9MS2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MDI9MS3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "memo",
//							"jaxId": "1H05HEO5U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO24",
//									"attrs": {
//										"type": "memo",
//										"id": "EdMessage",
//										"position": "relative",
//										"x": "90",
//										"y": "0",
//										"w": "100%-125",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"text": "#msg.content",
//										"color": "#cfgColor.fontBody",
//										"bgColor": "[255,255,255,0.00]",
//										"font": "helvetica, sans-serif",
//										"fontSize": "#txtSize.smallMid",
//										"outline": "0",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "6",
//										"readOnly": "false",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HL0CO25",
//									"attrs": {
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MCV82A4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MCV82A5",
//													"attrs": {
//														"padding": {
//															"type": "auto",
//															"valText": "5",
//															"editMode": "edges"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MCV82A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MCV82A7",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "0",
//															"editMode": "edges"
//														},
//														"padding": {
//															"type": "auto",
//															"valText": "[0,0,0,0]",
//															"editMode": "edges"
//														},
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor.fontBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H0MRO7CB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS559",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS5510",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor.fontBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MRO7CB0",
//											"faceTagName": "trace"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS5511",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS5512",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HL0CO26",
//									"attrs": {
//										"OnBlur": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MD1E020",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MD2PIG0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnInput": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MDSIEC0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MDSU300",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HL0CO27",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H0NT2NF60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0NT7G0J0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTokens",
//										"position": "relative",
//										"x": "90",
//										"y": "5",
//										"w": "100%-125",
//										"h": "15",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodyLit",
//										"text": "${msg.tokens>=0?`Tokens: ${msg.tokens}`:\"- - -\"},msg",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0NT7G0J1",
//									"attrs": {
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NT7G0J2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NT7G0J3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0NT7G0J4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0NT7G0J5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H05H4GKA9",
//					"attrs": {
//						"1H05HB7BH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H05HL0CO30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HB7BH0",
//							"faceTagName": "over"
//						},
//						"1H05HBU9A0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H0MRSS5610",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MRSS5611",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HBU9A0",
//							"faceTagName": "down"
//						},
//						"1H05HL0CO3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H0MRSS5612",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MRSS5613",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HL0CO3",
//							"faceTagName": "edit"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H05H4GKA10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H05H4GKA11",
//					"attrs": {
//						"msg": {
//							"type": "auto",
//							"valText": "#msg"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H05H4GKA12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}