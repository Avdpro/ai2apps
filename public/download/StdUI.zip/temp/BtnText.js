//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1KB50JO0StartDoc*/
/*}#1H1KB50JO0StartDoc*/
//----------------------------------------------------------------------------
let BtnText=function(style,w,h,text,outlined,icon){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let colorFix=style[0].toUpperCase()+style.substring(1);
	
	/*#{1H1KB50JO1LocalVals*/
	/*}#1H1KB50JO1LocalVals*/
	
	/*#{1H1KB50JO1PreState*/
	/*}#1H1KB50JO1PreState*/
	state={
		"corner":5,"text":text,"fontSize":h>0?(h>26?h-14:12):16,
		/*#{1H1KB50JP4ExState*/
		/*}#1H1KB50JP4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KB50JO1PostState*/
	/*}#1H1KB50JO1PostState*/
	cssVO={
		"hash":"1H1KB50JO1",nameHost:true,
		"type":"button","x":138,"y":84,"w":w,"h":h,"cursor":"pointer","styleClass":"","contentLayout":"flex-x","subAlign":1,
		children:[
			{
				"hash":"1H1KEE8D70",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":outlined?[0,0,0,0]:cfgColor[style],"border":outlined?1.5:0,
				"borderColor":cfgColor[style],"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KFRSGD0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":$P(()=>(state.fontSize+4),state),"h":$P(()=>(state.fontSize+4),state),"anchorY":1,
				"uiEvent":-1,"margin":[0,3,0,0],"styleClass":"","background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"attached":icon,"maskImage":icon,
			},
			{
				"hash":"1H1KEIIO50",
				"type":"text","id":"TxtText","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,2,0,0],"styleClass":"","color":outlined?cfgColor[style]:cfgColor["font"+colorFix],
				"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
				"alignV":1,
			},
			{
				"hash":"1H2F6U36O0",
				"type":"hud","id":"BoxRight","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"",
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1KB50JO1Settext*/
			/*}#1H1KB50JO1Settext*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KB50JO1Setcorner*/
			/*}#1H1KB50JO1Setcorner*/
		},
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1KB50JO1SetfontSize*/
			/*}#1H1KB50JO1SetfontSize*/
		},
		/*#{1H1KB50JO1ExtraCSS*/
		/*}#1H1KB50JO1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor[style],"y":0,"borderColor":cfgColor[style]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"over":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[cfgColor[style][0],cfgColor[style][1],cfgColor[style][2],0.25]:[...cfgColor[style],20],"y":0
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"down":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?cfgColor[style]:[...cfgColor[style],-20],"y":1
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":">calc(50% + 1px)"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":1
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":1
				}
			},"gray":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor["itemGray"],"borderColor":cfgColor["itemGray"]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1KB50JO1Create*/
			/*}#1H1KB50JO1Create*/
		},
		/*#{1H1KB50JO1EndCSS*/
		/*}#1H1KB50JO1EndCSS*/
	};
	/*#{1H1KB50JO1PostCSSVO*/
	/*}#1H1KB50JO1PostCSSVO*/
	return cssVO;
};
/*#{1H1KB50JO1ExCodes*/
/*}#1H1KB50JO1ExCodes*/

BtnText.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Text Button",icon:"btn_text.svg",previewImg:"./BtnText.png",
	fixPose:false,initW:100,initH:30,
	desc:"Styled text button, can have an icon.",
	catalog:"Basic,Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "string", "key": true, "fixed": true, "initVal": "primary", "localizable": undefined
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 30, "localizable": undefined
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Button", "localizable": true
		}, 
		"outlined": {
			"name": "outlined", "showName": "outlined", "type": "bool", "key": true, "fixed": true, "initVal": false, "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "", "localizable": undefined
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"Button"},
		corner:{name:"corner",type:"int",initVal:5},
		fontSize:{name:"fontSize",type:"int",initVal:16}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","padding","enable","attach"],
	faces:[
		{name:"up",entry:true,next:"over",desc:"",time:1000},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:true,next:"",desc:"",time:0}
	],
	subContainers:{
		"1H2F6U36O0":{"showName":"BoxRight"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1KB50JO0ExGearInfo*/
	/*}#1H1KB50JO0ExGearInfo*/
};
export default BtnText;
export{BtnText};