//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1O8E46I0StartDoc*/
/*}#1H1O8E46I0StartDoc*/
//----------------------------------------------------------------------------
let DlgMenu=function(){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let contents;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O8E46I1LocalVals*/
	/*}#1H1O8E46I1LocalVals*/
	
	/*#{1H1O8E46I1PreState*/
	/*}#1H1O8E46I1PreState*/
	/*#{1H1O8E46I1PostState*/
	/*}#1H1O8E46I1PostState*/
	cssVO={
		"hash":"1H1O8E46I1",nameHost:true,
		"type":"box","x":42,"y":38,"w":100,"h":"","overflow":1,"padding":5,"minH":30,"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBody,
		"shadow":true,"shadowX":3,"shadowY":5,"shadowBlur":6,"shadowSpread":2,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H2CN3UCE0",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":20,"styleClass":"","contentLayout":"flex-y",
			}
		],
		/*#{1H1O8E46I1ExtraCSS*/
		/*}#1H1O8E46I1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			contents=self.Contents;
			/*#{1H1O8E46I1Create*/
			/*}#1H1O8E46I1Create*/
		},
		/*#{1H1O8E46I1EndCSS*/
		/*}#1H1O8E46I1EndCSS*/
	};
	/*#{1H1O8E46I1PostCSSVO*/
	/*}#1H1O8E46I1PostCSSVO*/
	return cssVO;
};
/*#{1H1O8E46I1ExCodes*/
/*}#1H1O8E46I1ExCodes*/

DlgMenu.gearExport={
	framework: "jax",
	hudType: "box",
	showName:"Menu",icon:"menu.svg",previewImg:false,
	fixPose:false,initW:100,initH:30,
	desc:"Menu frame",
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","padding","minW","minH","maxW","maxH","styleClass","background","border","borderStyle","borderColor","corner","attach"],
	faces:[
	],
	subContainers:{
		"1H2CN3UCE0":{"showName":"Contents","contentLayout":"flex-y"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1O8E46I0ExGearInfo*/
	/*}#1H1O8E46I0ExGearInfo*/
};
export default DlgMenu;
export{DlgMenu};