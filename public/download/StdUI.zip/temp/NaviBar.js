//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1TJQ6AL0StartDoc*/
/*}#1H1TJQ6AL0StartDoc*/
//----------------------------------------------------------------------------
let NaviBar=function(items,color,initFocused){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let contents,boxFocus,focusBar;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1TJQ6AL1LocalVals*/
	/*}#1H1TJQ6AL1LocalVals*/
	
	/*#{1H1TJQ6AL1PreState*/
	/*}#1H1TJQ6AL1PreState*/
	/*#{1H1TJQ6AL1PostState*/
	/*}#1H1TJQ6AL1PostState*/
	cssVO={
		"hash":"1H1TJQ6AL1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"","h":"100%","minW":20,"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1H2ISHP700",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"100%","overflow":undefined,"minW":20,"styleClass":"","flex":true,"contentLayout":"flex-x",
				"itemsAlign":1,
			},
			{
				"hash":"1H2IT5UTD0",
				"type":"hud","id":"BoxFocus","x":0,"y":0,"w":10,"h":"100%","display":0,"overflow":undefined,"styleClass":"",
				children:[
					{
						"hash":"1H2IT77820",
						"type":"box","id":"FocusBar","x":0,"y":">calc(100% - 3px)","w":"100%","h":3,"overflow":undefined,"styleClass":"","background":color,"corner":100,
					}
				],
			}
		],
		/*#{1H1TJQ6AL1ExtraCSS*/
		/*}#1H1TJQ6AL1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			contents=self.Contents;boxFocus=self.BoxFocus;focusBar=self.FocusBar;
			/*#{1H1TJQ6AL1Create*/
			/*}#1H1TJQ6AL1Create*/
		},
		/*#{1H1TJQ6AL1EndCSS*/
		/*}#1H1TJQ6AL1EndCSS*/
	};
	/*#{1H1TJQ6AL1PostCSSVO*/
	/*}#1H1TJQ6AL1PostCSSVO*/
	return cssVO;
};
/*#{1H1TJQ6AL1ExCodes*/
/*}#1H1TJQ6AL1ExCodes*/

NaviBar.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Navi Bar",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:360,initH:40,
	desc:"Navi buttons bar",
	catalog:"Views",
	args: {
		"items": {
			"name": "items", "showName": "items", "type": "auto", "key": true, "fixed": true, 
			"initVal": [], "localizable": undefined
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"initFocused": {
			"name": "initFocused", "showName": "initFocused", "type": "string", "key": true, "fixed": true, "initVal": "", "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","subAlign","uiEvent","scale","cursor","zIndex","flex","margin","traceSize","minW","minH","maxW","maxH"],
	faces:[
	],
	subContainers:{
		"1H2ISHP700":{"showName":"Contents","contentLayout":"flex-x"},
		"1H2IT5UTD0":{"showName":"BoxFocus"}
	},
	deviceW:375,
	deviceH:40,
	/*#{1H1TJQ6AL0ExGearInfo*/
	/*}#1H1TJQ6AL0ExGearInfo*/
};
export default NaviBar;
export{NaviBar};