//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1TCNO8A0StartDoc*/
/*}#1H1TCNO8A0StartDoc*/
//----------------------------------------------------------------------------
let BtnNaviItem=function(code,text,color,icon,items){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1TCNO8A1LocalVals*/
	/*}#1H1TCNO8A1LocalVals*/
	
	/*#{1H1TCNO8A1PreState*/
	/*}#1H1TCNO8A1PreState*/
	/*#{1H1TCNO8A1PostState*/
	/*}#1H1TCNO8A1PostState*/
	cssVO={
		"hash":"1H1TCNO8A1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"","h":"100%","alpha":0.5,"cursor":"pointer","padding":[5,5,5,5],"styleClass":"","contentLayout":"flex-x",
		"code":code,
		children:[
			{
				"hash":"1H1TCV3O50",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":"","h":"100%","anchorY":1,"uiEvent":-1,"styleClass":"","background":color,"aspect":"1",
				"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H1TCQ3130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"padding":0,"styleClass":"","color":color,"text":text,
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TIOQU40",
				"type":"box","id":"MenuMark","position":"relative","x":0,"y":"50%","w":"","h":">calc(100% - 10px)","anchorY":1,"uiEvent":-1,"styleClass":"","background":color,
				"aspect":"1","maskImage":appCfg.sharedAssets+"/down.svg","attached":!!items,
			}
		],
		/*#{1H1TCNO8A1ExtraCSS*/
		/*}#1H1TCNO8A1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1TD2J6S0PreCode*/
				/*}#1H1TD2J6S0PreCode*/
				"#self":{
					"alpha":0.5
				}
			},"over":{
				/*#{1H1TD45OB0PreCode*/
				/*}#1H1TD45OB0PreCode*/
				"#self":{
					"alpha":0.7
				}
			},"down":{
				/*#{1H1TD2VV70PreCode*/
				/*}#1H1TD2VV70PreCode*/
				"#self":{
					"alpha":1
				}
			},"gray":{
				/*#{1H1TLQVNS0PreCode*/
				/*}#1H1TLQVNS0PreCode*/
				"#self":{
					"alpha":0.2
				}
			},"focus":{
				"#self":{
					"alpha":1
				},
				/*#{1H1TD5GM90Code*/
				/*}#1H1TD5GM90Code*/
			},"blur":{
				"#self":{
					"alpha":0.5
				},
				/*#{1H1TD5O2O0Code*/
				/*}#1H1TD5O2O0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1TCNO8A1Create*/
			/*}#1H1TCNO8A1Create*/
		},
		/*#{1H1TCNO8A1EndCSS*/
		/*}#1H1TCNO8A1EndCSS*/
	};
	/*#{1H1TCNO8A1PostCSSVO*/
	/*}#1H1TCNO8A1PostCSSVO*/
	return cssVO;
};
/*#{1H1TCNO8A1ExCodes*/
/*}#1H1TCNO8A1ExCodes*/

BtnNaviItem.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"BtnNaviItem",icon:"gears.svg",previewImg:"false",
	fixPose:true,initW:100,initH:40,
	desc:"Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
	catalog:"Buttons",
	args: {
		"code": {
			"name": "code", "showName": "code", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": undefined
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": true
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/home.svg", "localizable": undefined
		}, 
		"items": {"name":"items","showName":"items","type":"auto","key":true,"fixed":true}
	},
	state:{
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","cursor","margin","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0},
		{name:"focus",entry:false,next:"",desc:"",time:0},
		{name:"blur",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:40,
	/*#{1H1TCNO8A0ExGearInfo*/
	/*}#1H1TCNO8A0ExGearInfo*/
};
export default BtnNaviItem;
export{BtnNaviItem};