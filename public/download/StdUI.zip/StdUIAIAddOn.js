import {VFACT} from "/@vfact";

const $ln=VFACT.lanCode;

const EditAISeg=VFACT.classRegs.EditAISeg;
const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
const SegObjShellAttr=EditAISeg.SegObjShellAttr;
const SegOutletDef=EditAISegOutlet.SegOutletDef;

const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
const docAIAgentExporter=DocAIAgentExporter.prototype;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;

const packExtraCodes=docAIAgentExporter.packExtraCodes;
const packResult=docAIAgentExporter.packResult;

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//:AISeg that init and start AAE:
EditAISeg.regDef({
	name:"askDataView",showName:(($ln==="CN")?("数据视图"):/*EN*/("DataView")),icon:"rename.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("提示文本"):("Tip text")),type:"string",initVal:"Please input:",hideVal:1,key:1,fixed:1,localizable:true
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["event","Event","Event"],
			],valueType:"string"
		},
		"data":{
			name:"data",showName:(($ln==="CN")?("数据"):("Data")),type:"auto",initVal:"$$input$$",initValText:"#input",key:1,fixed:1
		},
		"template":{
			name:"template",showName:(($ln==="CN")?("模版"):("Template")),type:"choice",key:1,fixed:1,edit:false,navi:"doc",
			"vals":[],rawEdit:false,valueType:"string",
			val2ShowText(val){
				let tmp;
				if(val===null){
					return null;
				}
				tmp=VFACT.getEditUITemplate(val);
				if(tmp){
					return tmp.label||tmp.name;
				}
				return val;
			},
			getMenuItems(){
				let list,tmps,tmpName,tmp;
				list=[{text:"None",valText:`null`}];
				tmps=VFACT.getEditUITemplates();
				for(tmpName in tmps){
					tmp=tmps[tmpName];
					if(tmp instanceof Function){
						tmp=tmp();
					}
					if(tmp){
						list.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
					}
				}
				return list;
			}
		},
		"editData":{
			name:"editData",showName:(($ln==="CN")?("编辑数据"):("Edit Data")),type:"bool",initVal:false,key:1,fixed:1
		},
	},
	listHint:[
		"id","mkpInput","text","template","data","editData","role","codes","context","global","desc",
	]
});

DocAIAgentExporter.segTypeExporters["askDataView"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.packText(`let result,resultText;`);
		coder.maybeNewLine();
		coder.packText(`let role=`);this.genAttrStatement(seg.getAttr("role"));coder.packText(`;`);coder.newLine();
		coder.packText(`let md=await import("/@StdUI/ui/AIAskDataBlock.js");`);coder.newLine();
		coder.packText(`let func=md.default;`);coder.newLine();
		coder.packText(`let text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
		coder.packText(`let template=`);this.genAttrStatement(seg.getAttr("template"));coder.packText(`;`);coder.newLine();
		coder.packText(`let data=`);this.genAttrStatement(seg.getAttr("data"));coder.packText(`;`);coder.newLine();
		coder.packText(`let edit=`);this.genAttrStatement(seg.getAttr("editData"));coder.packText(`;`);coder.newLine();
		coder.packText(`let inputVO={template:template,data:data,options:{edit:edit}};`);coder.newLine();
		packExtraCodes(coder,seg,"Pre");
		coder.packText(`[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(session,{}),input:inputVO,role:role});`);coder.newLine();
		this.packUpdateContext(coder,seg);
		this.packUpdateGlobal(coder,seg);
		packExtraCodes(coder,seg);
		//Result:
		packResult(coder,seg,seg.outlet);
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

