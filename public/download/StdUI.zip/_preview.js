const pptProxyIdx=0;
const pptWebObjIdx=1;
const pptStyleObjIdx=2;
const pptInitedIdx=3;
const pptPVTMapIdx=4;
const pptRefCountIdx=5;
const pptViewScopeIdx=6;
const pptChildrenIdx=7;
const pptDisplayIdx=8;
const pptDisplayCodeIdx=9;


let VFACT,VFACTObj;
VFACT={
	get version(){
		return "0.0.1";
	}
};
//****************************************************************************
//shared util functions:
//****************************************************************************
let callAfter$1;
{
	//------------------------------------------------------------------------
	callAfter$1=async function(func,timeout,valMap){
		let pms;
		if(!timeout){
			pms=new Promise((resolve,reject)=>{
				resolve();
			});
			await pms;
			if(valMap){
				if(valMap[pptRefCountIdx]>0){
					func();
				}
			}else {
				func();
			}
			return;
		}
		if(valMap){
			window.setTimeout(()=>{
				if(valMap[pptRefCountIdx]>0){
					func();
				}
			},timeout);
		}else {
			window.setTimeout(func,timeout);
		}
	};
}


//****************************************************************************
//nameHost feature:
//****************************************************************************
let nameHostList=[];
let curNameHost=null;
let pushNameHost,popNameHost,checkInNameObj;
{
	pushNameHost=VFACT.pushNameHost=function(obj) {
		nameHostList.push(obj);
		curNameHost = obj;
	};
	popNameHost=VFACT.popNameHost=function(obj) {
		if (obj && curNameHost !== obj) {
			console.error("nameHostList error!");
			return;
		}
		nameHostList.pop();
		curNameHost = nameHostList[nameHostList.length - 1];
	};
	checkInNameObj=VFACT.checkInNameObj=function (obj, actId, id) {
		let idx, hostObj;
		idx = nameHostList.length - 1;
		hostObj = nameHostList[idx];
		while (hostObj) {
			if (actId) {
				hostObj["#" + actId] = obj;
			}
			if (id) {
				hostObj[id] = obj;
			}
			if (hostObj.nameHostStop !== false) {
				return;
			}
			idx--;
			hostObj = nameHostList[idx];
		}
	};
}

//****************************************************************************
//Gear container feature:
//****************************************************************************
let containerHashes=[];
let gearSlotsList=[];
let curContainerHash=null;
let curGearSlots=null;
let pushContainerHash,popContainerHash;
{
	pushContainerHash=VFACT.pushContainerHash=function(obj,slots) {
		containerHashes.push(obj);
		gearSlotsList.push(slots);
		curContainerHash = obj;
		curGearSlots=slots;
	};
	popContainerHash=VFACT.popContainerHash=function(obj) {
		if (obj && curContainerHash !== obj) {
			console.error("containerHashes error!");
			return;
		}
		containerHashes.pop();
		gearSlotsList.pop();
		curContainerHash = containerHashes[containerHashes.length - 1];
		curGearSlots = gearSlotsList[containerHashes.length - 1];
	};
}

//****************************************************************************
//define PVT:
//****************************************************************************
let $P,$PVT;
{
	$P=function(funcGet,traceObj){
		return new $PVT(funcGet,traceObj);
	};
	$PVT=function(funcGet,traceObj){
		let val,funcSet,traced,traceView,traceFunc;
		traced=0;
		traceView=null;
		if(traceObj) {
			val = funcGet();
		}
		Object.defineProperty(this,"val",{
			get:function(){
				return traced?val:funcGet();
			}
		});
		this.traceObj=traceObj;
		
		traceFunc=function(){
			funcSet(funcGet());
		};
		
		//-------------------------------------------------------------------
		//apply trace:
		this.trace=function(func,viewScope,msg){
			traceView=viewScope;
			funcSet=func;
			val = funcGet();
			if(traceObj){
				if(traceObj.onChange) {
					traceObj.onChange(traceFunc);
					traced = 1;
				}else if(traceObj.onNotify){
					traceObj.onNotify(msg||"*",traceFunc,traceView);
					traced = 2;
				}
			}
		};
		
		//-------------------------------------------------------------------
		//stop trace
		this.untrace=function(){
			if(!traced || !funcSet){
				return;
			}
			if(traced===1){
				traceObj.offChange(traceFunc);
			}else if(traced===2){
				traceObj.offNotify("*",traceFunc,traceView);
			}
			traced=0;
		};
	};
}

let TypeDef;
let typeDefs = {};
//****************************************************************************
//TypeDef:
//****************************************************************************
{
	TypeDef = function (name, initStyle, initClass) {
		let defPpts, pptHash;
		this.name = name;
		pptHash = this.pptHash = {
			"proxy": 0,
			"webObj": 1,
			"styleObj": 2,
			"inited": 3,
			"pvtMap": 4,
			"refCount": 5,
			"viewScope": 6,
			"children": 7,
			"display": 8,
			"displayCode": 9,
		};
		let nextPptIdx = 10;
		defPpts = this.defaultPpts = [null, null, null, false, null, 1, null, null, true, ""];//null for pvt-map, view-scope and children; 1 for refCount
		this.allocPptIdx = function (pptName, defaultPpt) {
			let idx = nextPptIdx++;
			defPpts[idx] = defaultPpt;
			if (pptName) {
				pptHash[pptName] = idx;
			}
			return idx;
		};
		this.getPptIdx = function (pptName) {
			let idx;
			idx = pptHash[pptName];
			return idx === undefined ? -1 : idx;
		};
		this.setMap = new Map();
		this.getMap = new Map();
		this.initStyle = {
			boxSizing: "border-box",
			flex: "0 0 auto"
		};
		if (initStyle) {
			this.initStyle = { ...this.initStyle, ...initStyle };
		}
		this.initClass = initClass || null;
		typeDefs[name] = this;
		this.preCreateCodes = [];
		this.postCreateCodes = [];
	};
	let _typeDef = TypeDef.prototype = {};
	TypeDef.aliasType = function (orgName, newName) {
		typeDefs[newName] = typeDefs[orgName];
	};
	_typeDef.defineIdxOnlyPpt = function (name, initVal, hasPVT = false) {
		let idx = this.allocPptIdx(name, initVal);
		if (hasPVT) {
			this.definePpt(name,
				(valMap) => {return valMap[idx];},
				(valMap, val) => {valMap[idx] = val;},
				hasPVT);
		} else {
			this.getMap.set(name, idx);
			this.setMap.set(name, idx);
		}
		return idx;
	};
	_typeDef.defineIdxOnlyPptCall = function (name, initVal, hasPVT = false) {
		let idx = this.allocPptIdx(name, initVal);
		this.definePpt(name,
			(valMap) => {return valMap[idx];},
			(valMap, val) => {
				let pxy = valMap[pptProxyIdx];
				if (val instanceof Function) {
					val = val.bind(pxy);
				}
				valMap[idx] = val;
			},
			hasPVT);
		return idx;
	};
	_typeDef.defineFunction = function (name, func) {
		let funcIdx;
		funcIdx = this.getPptIdx(name + "()");
		if (funcIdx<0) {
			funcIdx = this.allocPptIdx(name + "()", null);
		}
		this.getMap.set(name, (valMap) => {
			let call_;
			if(!valMap){
				return func;
			}
			call_ = valMap[funcIdx];
			if (!call_) {
				call_ = valMap[funcIdx] = func.bind(valMap);
			}
			return call_;
		});
	};

	//--------------------------------------------------------------------------
	//Reg a prpoerty
	_typeDef.definePpt=function(name,getPpt,setPpt,hasPVT){
		let def,getMap,setMap;
		def=this;
		getMap=def.getMap;
		setMap=def.setMap;
		//Get:
		if(getPpt){
			getMap.set(name,getPpt);
		}
		//Set:
		if(!(setPpt instanceof Function)){
			return;
		}
		if(hasPVT){
			let pvtSlot;
			pvtSlot=def.allocPptIdx(null,null);
			setMap.set(name, (valMap,val) => {
				let oldPVT = valMap[pvtSlot];
				let pvtMap=valMap[pptPVTMapIdx];
				if (oldPVT) {
					oldPVT.untrace();
					valMap[pvtSlot] = null;
					pvtMap.delete(name);
				}
				if (val && val.trace) {
					if (val.traceObj) {
						val.trace((v)=>{setPpt(valMap,v);}, name, valMap[pptViewScopeIdx]);
						valMap[pvtSlot] = val;
						pvtMap.set(name,val);
					}
					val = val.val;
				}
				return setPpt(valMap,val);
			});
		}else {
			setMap.set(name,setPpt);
		}
	};
	_typeDef.aliasPpt=function(orgName,newName){
		let def,getMap,setMap;
		def=this;
		getMap=def.getMap;
		setMap=def.setMap;
		getMap.set(newName,getMap.get(orgName));
		setMap.set(newName,setMap.get(orgName));
	};
	_typeDef.hasPpt=function(name){
		let def,getMap,setMap;
		def=this;
		getMap=def.getMap;
		setMap=def.setMap;
		return !!(getMap.get(name)||setMap.get(name));
	};
}

//****************************************************************************
//VFACTObj
//****************************************************************************
{
	VFACTObj=function(type,webObj,styleObj,pptMap){
		this.$_type=type;
		this.$_webObj=webObj;
		this.$_styleObj=styleObj;
		this.$_pptMap=pptMap;
	};
	
	VFACT.createObj=function(def,owner=null,before=null){
		let type,typeDef,self,webObj,styleObj,pxy;
		let defChian=[];
		let defDisplay;//display property in def
		let isNameHost,slotDefs,gearSlots;
		if(!def){
			return null;
		}
		//Flatten def:
		if(typeof(def)==="string"){
			type=def;
			def={};
		}else {
			defChian.push(def);
			type=def.type||"div";
			while(typeof(type)==="object"){
				defChian.push(type);
				def={...type,...def,type:type.type};
				type=def.type||"div";
			}
		}

		//Check if we really create this element?
		if(("attached" in def)&&(!def.attached)){
			return null;
		}
		
		typeDef=typeDefs[type];
		if(!typeDef){
			console.log(`Can't find component type: ${type}`);
			return null;
		}
		type=typeDef;
		let hookMap,oldSetMap;
		let funcSetMap=type.setMap;
		let funcGetMap=type.getMap;
		let pptList=[...type.defaultPpts];
		pptList[pptPVTMapIdx]=new Map();//the PVT map
		//TODO: Support HTML-element direct creates:
		if(type.createElement){
			webObj=type.createElement(def,pptList);
		}else {
			webObj=document.createElement("div");
		}
		styleObj=webObj.style;
		pptList[pptWebObjIdx]=webObj;
		pptList[pptStyleObjIdx]=styleObj;
		if(type.initClass){
			webObj.className=type.initClass;
		}
		if(type.initStyle){
			Object.assign(styleObj,type.initStyle);
		}
		self=new VFACTObj(type,webObj,styleObj,pptList);
		self.$_hookSetAttr=function(attrName,func){
			let oldFunc;
			if(!hookMap){
				hookMap={};
				oldSetMap=funcSetMap;
				funcSetMap={
					get:function(name){
						let func;
						func=hookMap[name];
						if(func){
							return func;
						}
						return oldSetMap.get(name);
					}
				};
			}
			oldFunc=oldSetMap.get(attrName);
			if(oldFunc){
				hookMap[attrName]=function(...args){
					if(func.call(self,...args)===false){
						return;
					}
					oldFunc.call(self,...args);
				};
			}
		};
		
		pxy= new Proxy(self,{
			get(obj,pName){
				let func=funcGetMap.get(pName);
				if(func) {
					if(func>=0){
						return pptList[func];
					}
					return func(pptList);
				}
				return self[pName];
			},
			set(obj,pName,val){
				let func=funcSetMap.get(pName);
				if(func){
					if(func>=0) {
						pptList[func]=val;
						return true;
					}
					func(pptList,val);
					return true;
				}
				if(pName[0]!=="$" || pName[1]!=="_"){
					self[pName]=val;
				}
				return true;
			}
		});
		pptList[pptProxyIdx]=pxy;
		self.self=self;
		self.proxy=pxy;
		webObj.$_pxy=pxy;
		webObj.$_vfact=self;

		if("display" in def) {
			defDisplay = def.display || "";
		}else {
			defDisplay = 1;
		}
		def.display=0;
		styleObj.display="none";
		
		if(owner){
			if(owner instanceof VFACTObj){
				if(before){
					owner.insertBefore(pxy,before);
				}else {
					owner.appendChild(pxy);
				}
				pxy.release();
			}else {
				//should be HTML element:
				owner.appendChild(webObj);
			}
		}

		if(type.prefix){
			def=type.prefix(pxy,def,webObj,styleObj,pptList);
		}
		
		//apply def's properties:
		let defPpts,pptName;
		defPpts=Object.getOwnPropertyNames(def);
		for(pptName of defPpts){
			if(pptName.startsWith("$$")){
				let preDef,desc;
				for(preDef of defChian){
					desc = Object.getOwnPropertyDescriptor(preDef, pptName);
					if(desc && (!("value" in desc))){
						let hasKey,val;
						pptName = pptName.substring(2);
						hasKey = pptName in def;
						if(hasKey){
							val = def[pptName];
						}else {
							hasKey = pptName in self;
							val = self[pptName];
						}
						Object.defineProperty(self, pptName, desc);
						if (hasKey) {
							self[pptName] = val;
						}
						break;
					}
				}
			}else {
				//Assign the ppt:
				pxy[pptName]=def[pptName];
			}
		}

		slotDefs=def.subContainers;
		if(slotDefs){
			gearSlots=pxy.subContainers={};
			slotDefs.nameProxy=curNameHost;
			pushContainerHash(slotDefs,gearSlots);
		}
		if(def.hash || def.id){
			checkInNameObj(pxy,def.hash,def.id);
		}
		isNameHost=def.faces||def.nameHost;
		if(isNameHost){
			pushNameHost(pxy);
			checkInNameObj(pxy,null,"#self");//confirm this:
		}
		let chdList=def.children;
		let gearNamePxy=null;
		if(curContainerHash){
			let gearChds;
			gearChds=curContainerHash[def.hash];
			if(gearChds && gearChds.length){
				curGearSlots[def.hash]=pxy;
				chdList=gearChds;
				gearNamePxy=curContainerHash.nameProxy;
				if(gearNamePxy){
					pushNameHost(gearNamePxy);
				}
			}
		}
		if(chdList && pxy.appendChild){
			let chdDef;
			for(chdDef of chdList){
				VFACT.createObj(chdDef,pxy);
			}
		}
		if(gearNamePxy){
			popNameHost(gearNamePxy);
		}
		if(defDisplay) {
			pxy.display=defDisplay;
		}
		pxy.doLayout && pxy.doLayout();
		if(type.postCreate){
			type.postCreate(pxy,def,webObj,styleObj,pptList);
		}
		if(isNameHost){
			popNameHost(pxy);
		}
		if(slotDefs){
			popContainerHash(slotDefs);
			slotDefs.nameProxy=null;
		}
		pptList[pptInitedIdx]=true;
		//all set, call OnCreate function:
		if(def.face){
			pxy.showFace(def.face);
		}
		if(pxy.OnCreate){
			pxy.OnCreate();
		}
		return pxy;
	};
	VFACT.pushNameHost=pushNameHost;
	VFACT.popNameHost=popNameHost;
	VFACT.checkInNameObj=checkInNameObj;
	
	VFACT.createFragDummy=function(owner){
		let frg=new DocumentFragment();
		frg.$_pxy=owner;
		return frg;
	};
	VFACT.appendFragDummy=function(frg,webObj,before){
		let pxy;
		if(!webObj){
			pxy=frg.$_pxy;
			webObj=pxy.webObj;
		}
		if(before){
			webObj.insertBefore(frg,before);
		}else {
			webObj.appendChild(frg);
		}
	};
}
{
	VFACTObj.vmcAddRefcount=function(){
		let valMap=this;
		valMap[pptRefCountIdx]+=1;
	};
	
	VFACTObj.vmcRelease=function(){
		let valMap=this;
		valMap[pptRefCountIdx]-=1;
		if(valMap[pptRefCountIdx]<=0){
			let pvtMap,pvt,self;
			let pxy=valMap[pptProxyIdx];
			let onFree,typeOnFree,pvts;
			self=pxy.self;
			onFree=pxy.OnFree;
			if(onFree){
				onFree.call(pxy);
			}
			typeOnFree=self.$_type.OnFree;
			if(typeOnFree){
				typeOnFree(valMap);
			}
			pxy.clearChildren();
			pvtMap=valMap[pptPVTMapIdx];
			if(pvtMap){
				pvts=pvtMap.values();
				for(pvt of pvts){
					pvt.untrace();
				}
				pvtMap.clear();
			}
			self.$_webObj=null;
			self.$_styleObj=null;
			valMap.splice(0);
		}
	};
	
	VFACTObj.objHas=function(objPxy,valName){
		
	};
}

let makeNotify$1;
{
	makeNotify$1=function(self){
		var m_NotifyPaused;
		var m_viewHubIn = {};
		var m_viewHubOn = {};
		var m_isInEnvList = 0;
		var m_NotifyOnMsgHash = {};
		var m_PendingNofifyOn=[];
		var m_msgValHash={};
		var removeValBindOfView;
		var notifyToMap,notifyHubOn,notifyOnAll;
		var muteNotify=false;
		if(self.emitNotify){
			return;
		}
		//---------------------------------------------------------------
		//make changing [name] attrib notify [msg] message, if [msg] is uset, null or "", msg will be "*":
		self.upgradeVal = function (name, msg) {
			var oldMsg, curVal, desc, oldGet, oldSet,msgList;
			if (!(name in self)) {
				return;
			}
			if (!msg) {
				msg = "*";//Default message:
			}
			if(Array.isArray(msg)){
				msgList=msg;
			}
			oldMsg = m_msgValHash[name];
			if (oldMsg) {
				if (msg !== oldMsg) {
					throw "Notify upgradVal error: val " + name + " is already been upgraded with diffrent msg " + oldMsg + ", new msg: " + msg;
				}
				return;
			}
			desc = Object.getOwnPropertyDescriptor(self, name);
			oldGet = desc.get;
			oldSet = desc.set;
			curVal = self[name];
			m_msgValHash[name] = msg;
			if(msgList){
				Object.defineProperty(self, name,
					{
						enumerable: desc.enumerable,
						configurable: true,
						set: function (newVal) {
							let msg;
							curVal = newVal;
							if (oldSet) {
								oldSet.call(self, newVal);
							}
							for(msg of msgList) {
								notifyHubOn(msg);
							}
							return newVal;
						},
						get: function () {
							return oldGet ? oldGet.call(self) : curVal;
						}
					}
				);
			}else {
				Object.defineProperty(self, name,
					{
						enumerable: desc.enumerable,
						configurable: true,
						set: function (newVal) {
							curVal = newVal;
							if (oldSet) {
								oldSet.call(self, newVal);
							}
							notifyHubOn(msg);
							return newVal;
						},
						get: function () {
							return oldGet ? oldGet.call(self) : curVal;
						}
					}
				);
			}
		};
		
		//---------------------------------------------------------------
		self.getValMsg = function (name) {
			return m_msgValHash[name];
		};
		
		//---------------------------------------------------------------
		self.onNotify=self.bindValNotify = function (msgName,func,view,once=0) {
			var map, set, msg;
			if (!func) {
				console.error("hub notify function!!");
				return;
			}
			if (!(msgName in self)) {
				msg=msgName;
			}else {
				msg = m_msgValHash[msgName];
			}
			if(!msg){
				throw ""+msgName+" is not upgraded!";
			}
			map = m_viewHubOn[msg];
			if (!map) {
				map = m_viewHubOn[msg] = new Map();
				map.mute=0;
			}
			set = map.get(view);
			if (!set) {
				set = new Set();
				map.set(view, set);
			}
			if(!once) {
				set.add(func);
			}else {
				let onceFunc;
				onceFunc=function(...args){
					func(...args);
					self.off(msg,onceFunc,view);
				};
				set.add(onceFunc);
			}
			return msg;
		};
		
		//---------------------------------------------------------------
		self.onceNotify=function(msgName,func,view){
			self.onNotify(msgName,func,view,1);
		};
		
		//---------------------------------------------------------------
		self.removeValBindOfView = removeValBindOfView = function (msgName, view) {
			var list, i;
			if (!msgName) {
				list = m_viewHubIn;
				for (i in list) {
					removeValBindOfView(i, view);
				}
				list = m_viewHubOn;
				for (i in list) {
					removeValBindOfView(i, view);
				}
				return;
			}
			list = m_viewHubIn[msgName];
			if (list) {
				list.delete(view);
			}
			list = m_viewHubOn[msgName];
			if (list) {
				list.delete(view);
			}
		};
		
		//---------------------------------------------------------------
		self.offNotify=self.removeValNotify = function (msgName, func, view) {
			var list, map, set, i, msg;
			if (!msgName) {
				list = m_viewHubIn;
				for (i in list) {
					msg=i;
					self.removeValNotify(msg, view, func);
				}
				list = m_viewHubOn;
				for (i in list) {
					msg=i;
					self.removeValNotify(i, view, func);
				}
				return;
			}
			map = m_viewHubIn[msgName];
			if (map) {
				set = map.get(view);
				if (set) {
					set.delete(func);
				}
			}
			map = m_viewHubOn[msgName];
			if (map) {
				set = map.get(view);
				if (set) {
					set.delete(func);
				}
			}
		};
		
		//---------------------------------------------------------------
		notifyToMap = function (map) {
			var views, view, set, func;
			views = map.keys();
			for (view of views) {
				if (!view || view.allowValNotify!==false) {
					set = map.get(view);
					for (func of set) {
						func();
					}
				}
			}
		};
		
		//---------------------------------------------------------------
		//Fire a notify message
		self.emitNotify=self.notifyValMsgOn = notifyHubOn = function (msg) {
			if(!m_NotifyOnMsgHash[msg] && !muteNotify) {
				let map = m_viewHubOn[msg];
				if(map && map.mute){
					return;
				}
				
				m_NotifyOnMsgHash[msg] = 1;
				m_PendingNofifyOn.push(msg);
				if (m_isInEnvList)
					return;
				m_isInEnvList = 1;
				callAfter$1(notifyOnAll);
			}
		};
		
		//---------------------------------------------------------------
		notifyOnAll = function () {
			var map, msg, list, loop;
			m_isInEnvList = 0;
			if (m_NotifyPaused) {
				return;
			}
			loop = 0;
			do {
				list = m_PendingNofifyOn.splice(0);
				for (msg of list) {
					m_NotifyOnMsgHash[msg] = 0;
					map = m_viewHubOn[msg];
					if (map) {
						notifyToMap(map);
					}
				}
				loop++;
				if (loop > 3) {
					console.warn(`Notify too many times.`);
					break;
				}
			} while (m_PendingNofifyOn.length);
		};
		
		//---------------------------------------------------------------
		Object.defineProperty(self,"pauseValNotify",{
			get:function(){
				return m_NotifyPaused;
			},
			set:function(v){
				v=v?1:0;
				m_NotifyPaused=v;
				return v;
			}
		});
		
		//-------------------------------------------------------------------
		self.muteNotify=function(msg){
			if(msg){
				let map;
				map = m_viewHubOn[msg];
				if (!map) {
					map = m_viewHubOn[msg] = new Map();
					map.mute=1;
				}
			}else {
				muteNotify++;
			}
		};
		
		//-------------------------------------------------------------------
		self.unmuteNotify=function(msg){
			if(msg){
				let map;
				map = m_viewHubOn[msg];
				if (map) {
					map.mute-=1;
				}
			}else {
				muteNotify--;
			}
		};
	};
	VFACT.makeNotify=makeNotify$1;
}

let VFACTState=function(orgObj){
	this.orgObj=orgObj;
};

//with strictState object, you can't set state's variable, you must call setState method to update state contents and trigger updates
let strictState=function(orgObj,viewScope,...subs){
	let curObj,proxy;
	let onChangeSet;//setState,,onChange,offChange,refresh;
	let willRefresh=0;
	function refresh(sub){
		let func;
		willRefresh=0;
		for(func of onChangeSet){
			func();
		}
		if(sub && subs){
			for(sub of subs){
				sub.refresh();
			}
		}
	}
	function setState(newObj){
		if(newObj instanceof Function){
			newObj=newObj(curObj);
		}
		curObj={
			...newObj,setState,onChange,offChange,refresh
		};
		if(!willRefresh){
			willRefresh=1;
			callAfter$1(refresh);
		}
	}
	function onChange(callback){
		onChangeSet.add(callback);
	}
	function offChange(callback){
		onChangeSet.delete(callback);
	}
	onChangeSet=new Set();
	curObj={
		...orgObj,
		setState,onChange,offChange,refresh
	};
	proxy=new Proxy(new VFACTState(orgObj),{
		get:function(obj,pName){
			return curObj[pName];
		},
		set:function(obj,pName,val){
			switch(pName){
				case "$owner":
					return true;
			}
			return false;
		}
	});
	return proxy;
};
VFACT.strictState=strictState;

//with flexState object, you can set state's variable and it will trigger updates
let flexState=function(orgObj,viewScope,...subs){
	let curObj,proxy;
	let onChangeSet;//setState,,onChange,offChange,refresh;
	let willRefresh=0;
	function refresh(sub){
		let func;
		willRefresh=0;
		for(func of onChangeSet){
			func();
		}
		if(sub && subs){
			for(sub of subs){
				sub.refresh();
			}
		}
	}
	function setState(newObj){
		if(newObj instanceof Function){
			newObj=newObj(curObj);
		}
		curObj={
			...newObj,setState,onChange,offChange,refresh
		};
		if(!willRefresh){
			willRefresh=1;
			callAfter$1(refresh);
		}
	}
	function onChange(callback){
		onChangeSet.add(callback);
	}
	function offChange(callback){
		onChangeSet.delete(callback);
	}
	onChangeSet=new Set();
	curObj={
		...orgObj,
		setState,onChange,offChange,refresh
	};
	proxy=new Proxy(new VFACTState(orgObj),{
		get:function(obj,pName){
			return curObj[pName];
		},
		set:function(obj,pName,val){
			switch(pName){
				case "$owner":
					return true;
			}
			curObj[pName]=val;
			if(!willRefresh){
				willRefresh=1;
				callAfter$1(refresh);
			}
			return true;
		}
	});
	return proxy;
};
VFACT.flexState=flexState;

let VFACTAni,vfactAni;
const STATE_NONE=0;
const STATE_READY=1;
const STATE_ANI=2;
const STATE_PAUSED=3;
const STATE_END=4;
const STATE_CANCELED=5;

//---------------------------------------------------------------------------
//Animate base class, all animate is contorled with time:
VFACTAni=function(def=null,obj=null)
{
	if(!def){
		return;
	}
	this.startTime=0;
	this.endTime=0;
	this.state=0;
	this.uiObj=null;
	this.state=STATE_NONE;
	this.OnFinish=null;
	this.OnCanel=null;
	this.initByDef(def);
	//Play:
	this.webAniObj=null;
	this.keyFrames=null;
	this.duration=200;
	this.webAniOpts=null;
	//Callback:
	this.OnFinish=null;
	this.OnCancel=null;
	if(obj){
		this.bind2Obj(obj);
	}
};
vfactAni=VFACTAni.prototype={};

//***************************************************************************
//Register ani type and create ani:
//***************************************************************************
{
	var aniTypeHash = {};

	//---------------------------------------------------------------------------
	//Register an animate type:
	VFACTAni.regAni = function (typeName, func) {
		aniTypeHash[typeName] = func;
	};

	//---------------------------------------------------------------------------
	//Create animate by type:
	VFACTAni.createAniByType = function (typeName, def, obj) {
		let typeType,func,ani;
		typeType=typeof(typeName);
		if(typeType==="string") {
			func = aniTypeHash[typeName];
		}
		ani=new func(def,obj);
		return ani;
	};
	
	VFACTAni.regAni("ani",VFACTAni);
	
	VFACTAni.animate=function(pxy,def,startPlay=true){
		let type,ani;
		type=def.type;
		ani=VFACTAni.createAniByType(type,def,pxy);
		if(def.pause||(!startPlay)){
			return ani;
		}
		ani.start();
		return ani;
	};
}

//***************************************************************************
//API:
//***************************************************************************
{
	//-----------------------------------------------------------------------
	//Init with def:
	vfactAni.initByDef = function (def) {
		if (this.def) {
			console.error("Ani already inited.");
			return;
		}
		this.def = def;
		if (this.uiObj) {
			this.state = STATE_READY;
		}
	};

	//-----------------------------------------------------------------------
	//bind animate with UI-Obj:
	vfactAni.bind2Obj = function (obj) {
		this.uiObj = obj;
		if (obj && this.def) {
			this.styleObj=obj.$_styleObj;
			this.state = STATE_READY;
		}
	};

	//-----------------------------------------------------------------------
	//start animate:
	vfactAni.start = function () {
		let div,def,easing,loop,delay,endDelay;
		let self=this;
		if (this.state !== STATE_READY) {
			console.error("Ani not ready!");
			return;
		}
		def=this.def;
		if(this.setupKeyFrames){
			this.setupKeyFrames();
		}else {
			this.keyFrames=def.keyFrames;
			this.duration=def.duration||def.time||200;
			this.webAniOpts=def.options||null;
			this.OnFinish=def.OnFinish;
			this.OnCancel=def.OnCancel;
		}
		this.startTime = Date.now();
		if(!this.keyFrames){
			this.state=STATE_END;
			this.endTime = this.startTime;
			return;
		}
		this.state = STATE_ANI;
		div=this.uiObj.webObj;
		easing=def.easing;
		let opts=this.webAniOpts||{duration:this.duration};
		if(easing){
			opts.easing=easing;
		}
		loop=def.loop;
		if(loop){
			opts.iterations=loop>0?loop:Infinity;
		}
		delay=def.delay;
		if(delay>0){
			opts.delay=delay;
		}
		endDelay=def.endDelay;
		if(endDelay>0){
			opts.endDelay=endDelay;
		}
		this.webAniObj=div.animate(this.keyFrames,opts);
		//Callback:
		this.webAniObj.onfinish=function(){
			self.OnFinish&&self.OnFinish();
		};
		this.webAniObj.oncancel=function(){
			self.OnCancel&&self.OnCancel();
		};
	};

	//-----------------------------------------------------------------------
	//pause animate:
	vfactAni.pause = function () {
		if(this.state!==STATE_ANI){
			console.error("Ani not playing!");
			return;
		}
		this.webAniObj.pause();
		this.state=STATE_PAUSED;
	};
	//-----------------------------------------------------------------------
	//resume animate:
	vfactAni.resume = function () {
		if(this.state!==STATE_PAUSED){
			console.error("Ani not paused!");
			return;
		}
		this.webAniObj.play();
		this.state=STATE_ANI;
	};
	//-----------------------------------------------------------------------
	//finish animate:
	vfactAni.stop =
	vfactAni.finish = function () {
		if(this.state!==STATE_PAUSED && this.state!==STATE_ANI){
			console.error("Can't stop ani!");
			return;
		}
		this.webAniObj.finish();
		this.webAniObj=null;
		this.state=STATE_END;
	};
	//-----------------------------------------------------------------------
	//cancel animate:
	vfactAni.cancel = function () {
		if(this.state!==STATE_PAUSED && this.state!==STATE_ANI){
			console.error("Can't stop ani!");
			return;
		}
		this.webAniObj.cancel();
		this.webAniObj=null;
		this.state=STATE_CANCELED;
	};
}

//****************************************************************************
//Pose animate:
//****************************************************************************
{
	//------------------------------------------------------------------------
	let AniPose=function(def,obj){
		if(!def)
			return;
		VFACTAni.call(this,def,obj);
	};
	let aniPose=AniPose.prototype=new VFACTAni();
	VFACTAni.regAni("pose",AniPose);
	//------------------------------------------------------------------------
	aniPose.setupKeyFrames=function(){
		let vo1,vo2,x,y,w,h,frames,frame,finFrame;
		let self=this;
		let def=this.def;
		let obj=this.uiObj;
		let webObj=obj.webObj;
		let styleObj=webObj.style;
		let tsfmLineOrg="";
		let tsfmLineTgt="";
		frames=def.frames;
		frame=frames?frames[0]:def;
		finFrame=frames?frames[frames.length-1]:def;
		vo1={};vo2={};
		this.duration=def.duration||def.time||200;
		function def2VO(){
			let vo2={};
			if("x" in def) {
				x = def.x;
				if(x instanceof Function){
					x=x.call(obj);
				}
				vo2.left=(x>=0||x<0)?x+"px":x;
			}
			if("y" in def) {
				y = def.y;
				if(y instanceof Function){
					y=y.call(obj);
				}
				vo1.top=styleObj.top;
				vo2.top=(y>=0||y<0)?y+"px":y;
			}
			if("w" in def) {
				w = def.w;
				if(w instanceof Function){
					w=w.call(obj);
				}
				vo1.width=styleObj.width;
				vo2.width=(w>=0||w<0)?w+"px":w;
			}
			if("h" in def) {
				h = def.h;
				if(h instanceof Function){
					h=h.call(obj);
				}
				vo1.height=styleObj.height;
				vo2.height=(h>=0||h<0)?h+"px":h;
			}
			if("alpha" in def) {
				vo2.opacity = def.alpha;
			}
			if("scale" in def){
				tsfmLineTgt+='scale('+def.scale+') ';
			}else {
				tsfmLineTgt+='scale('+obj.scale+') ';
			}

			if("rotate" in def){
				tsfmLineTgt+='rotate('+def.rotate+'deg)';
			}else {
				tsfmLineTgt+='rotate('+obj.rotate+'deg)';
			}
			vo2.transform = tsfmLineTgt;
			if("offset" in def){
				vo2.offset=def.offet;
			}
			return vo2;
		}
		if("x" in frame) {
			x = frame.x;
			if(x instanceof Function){
				x=x.call(obj);
			}
			vo1.left=styleObj.left;
			vo2.left=(x>=0||x<0)?x+"px":x;
		}
		if("y" in frame) {
			y = frame.y;
			if(y instanceof Function){
				y=y.call(obj);
			}
			vo1.top=styleObj.top;
			vo2.top=(y>=0||y<0)?y+"px":y;
		}
		if("w" in frame) {
			w = frame.w;
			if(w instanceof Function){
				w=w.call(obj);
			}
			vo1.width=styleObj.width;
			vo2.width=(w>=0||w<0)?w+"px":w;
		}
		if("h" in frame) {
			h = frame.h;
			if(h instanceof Function){
				h=h.call(obj);
			}
			vo1.height=styleObj.height;
			vo2.height=(h>=0||h<0)?h+"px":h;
		}
		if("alpha" in frame) {
			vo1.opacity = styleObj.opacity;
			vo2.opacity = frame.alpha;
		}
		//Anchor:
		{
			let ax,ay;
			ax=obj.anchorX;
			ay=obj.anchorY;
			switch(ax){
				case 0:
				default:
					ax="0px";
					break;
				case 1:
					ax="-50%";
					break;
				case 2:
					ax="-100%";
					break;
			}
			switch(ay){
				case 0:
				default:
					ay="0px";
					break;
				case 1:
					ay="-50%";
					break;
				case 2:
					ay="-100%";
					break;
			}
			tsfmLineOrg+=`translate(${ax},${ay}) `;
			tsfmLineTgt+=`translate(${ax},${ay}) `;
		}
		if("scale" in frame){
			tsfmLineOrg+='scale('+obj.scale+') ';
			tsfmLineTgt+='scale('+frame.scale+') ';
		}else {
			tsfmLineOrg+='scale('+obj.scale+') ';
			tsfmLineTgt+='scale('+obj.scale+') ';
		}
		
		if("rotate" in frame){
			tsfmLineOrg+='rotate('+obj.rotate+'deg)';
			tsfmLineTgt+='rotate('+frame.rotate+'deg)';
		}else {
			tsfmLineOrg+='rotate('+obj.rotate+'deg)';
			tsfmLineTgt+='rotate('+obj.rotate+'deg)';
		}
		vo1.transform = tsfmLineOrg;
		vo2.transform = tsfmLineTgt;
		
		this.webAniOpts={
			composite:"replace",duration:this.duration,easing:def.easing
		};
		this.keyFrames=[vo1,vo2];
		if(frames){
			let i,n;
			this.keyFrames=[vo1];
			n=frames.length;
			for(i=1;i<n;i++){
				this.keyFrames.push(def2VO(frames[i]));
			}
			this.keyFrames.push(vo2);
		}else {
			this.keyFrames=[vo1,vo2];
		}
		//Setup OnFinish:
		this.OnFinish=function(){
			if("x" in finFrame){
				obj.x = finFrame.x;
			}
			if("y" in finFrame){
				obj.y = frame.y;
			}
			if("w" in finFrame){
				obj.w = finFrame.w;
			}
			if("h" in finFrame){
				obj.h = finFrame.h;
			}
			if("alpha" in finFrame){
				obj.alpha = finFrame.alpha;
			}
			if("scale" in finFrame){
				obj.scale = finFrame.scale;
			}
			if("rotate" in finFrame){
				obj.rotate = finFrame.rotate;
			}
			if(def.OnFinish){
				def.OnFinish.call(self);
			}
		};
		this.OnCancel=function(){
			if(def.OnCancel){
				def.OnCancel.call(self);
			}
		};
	};
}

//****************************************************************************
//Fade animate:
//****************************************************************************
{
	//------------------------------------------------------------------------
	let AniFade=function(def,obj){
		if(!def)
			return;
		this.actionDir=1;//0:hide,1:show
		VFACTAni.call(this,def,obj);
	};
	let aniFade=AniFade.prototype=new VFACTAni();
	VFACTAni.regAni("fade",AniFade);
	VFACTAni.regAni("show",AniFade);
	VFACTAni.regAni("hide",AniFade);
	VFACTAni.regAni("in",AniFade);
	VFACTAni.regAni("out",AniFade);
	
	//------------------------------------------------------------------------
	aniFade.start=function(){
		this.uiObj.display=true;
		vfactAni.start.call(this);
	};

	//------------------------------------------------------------------------
	aniFade.setupKeyFrames=function(){
		let self=this;
		let def=this.def;
		let obj=this.uiObj;

		switch(def.type){
			case "show":
			case "in":
				obj.display=1;
				this.actionDir=1;
				this.setupAniFrames();
				this.keyFrames=[this.hideKeyFrame,this.showKeyFrame];
				break;
			case "hide":
			case "out":
				if(!obj.display){
					this.keyFrames=null;
					return;
				}
				this.actionDir=0;
				this.setupAniFrames();
				this.keyFrames=[this.showKeyFrame,this.hideKeyFrame];
				break;
			default:
				if(obj.display){
					this.actionDir=0;
					this.setupAniFrames();
					this.keyFrames=[this.showKeyFrame,this.hideKeyFrame];
				}else {
					this.actionDir=1;
					this.setupAniFrames();
					this.keyFrames=[this.hideKeyFrame,this.showKeyFrame];
				}
		}
		this.OnFinish=function(){
			if(self.actionDir===0){
				obj.display=0;
				Object.assign(self.styleObj,self.showKeyFrame);
			}
			if(def.OnFinish){
				def.OnFinish.call(self);
			}
		};
		this.OnCancel=function(){
			if(self.actionDir===0){
				obj.display=1;
				Object.assign(self.styleObj,self.showKeyFrame);
			}else {
				obj.display=0;
				Object.assign(self.styleObj,self.showKeyFrame);
			}
			if(def.OnCancel){
				def.OnCancel.call(self);
			}
		};
	};
	
	//------------------------------------------------------------------------
	aniFade.setupAniFrames=function(){
		let voShow,voHide,x,y,w,h;
		let def=this.def;
		let obj=this.uiObj;
		let webObj=obj.webObj;
		let styleObj=webObj.style;
		let tsfmLineShow="";
		let tsfmLineHide="";
		voShow={};voHide={};
		this.showKeyFrame=voShow;
		this.hideKeyFrame=voHide;
		this.duration=def.duration||def.time||200;
		if("dx" in def){
			x = def.dx;
			if(x instanceof Function){
				x=x.call(obj);
			}
			voShow.left=styleObj.left;
			voHide.left=(obj.x+x)+"px";
		}else {
			if("showX" in def) {
				x = def.showX;
				if(x instanceof Function){
					x=x.call(obj);
				}
				voShow.left=(x>=0||x<0)?x+"px":x;
			}else {
				voShow.left=styleObj.left;
			}
			if("hideX" in def) {
				x = def.hideX;
				if(x instanceof Function){
					x=x.call(obj);
				}
				voHide.left=(x>=0||x<0)?x+"px":x;
			}else {
				voHide.left=styleObj.left;
			}
		}
		
		if("dy" in def){
			y = def.dy;
			if(y instanceof Function){
				y=y.call(obj);
			}
			voShow.top=styleObj.top;
			voHide.top=(obj.y+y)+"px";
		}else {
			if("showY" in def) {
				y = def.showY;
				if(y instanceof Function){
					y=y.call(obj);
				}
				voShow.top=(y>=0||y<0)?y+"px":y;
			}else {
				voShow.top=styleObj.top;
			}
			if("hideY" in def) {
				y = def.hideY;
				if(y instanceof Function){
					y=y.call(obj);
				}
				voHide.top=(y>=0||y<0)?y+"px":y;
			}else {
				voHide.top=styleObj.top;
			}
		}
		
		if("dw" in def){
			w = def.dw;
			if(w instanceof Function){
				w=w.call(obj);
			}
			voShow.width=styleObj.width;
			voHide.width=(obj.w+w)+"px";
		}else {
			if("showW" in def) {
				w = def.showW;
				if(w instanceof Function){
					w=w.call(obj);
				}
				voShow.width=(w>=0||w<0)?w+"px":w;
			}else {
				voShow.width=styleObj.width;
			}
			if("hideW" in def) {
				w = def.hideW;
				if(w instanceof Function){
					w=w.call(obj);
				}
				voHide.width=(w>=0||w<0)?w+"px":w;
			}else {
				voHide.width=styleObj.width;
			}
		}

		if("dh" in def){
			h = def.dh;
			if(h instanceof Function){
				h=h.call(obj);
			}
			voShow.height=styleObj.height;
			voHide.height=(obj.h+h)+"px";
		}else {
			if("showH" in def) {
				h = def.showH;
				if(h instanceof Function){
					h=h.call(obj);
				}
				voShow.height=(h>=0||h<0)?h+"px":h;
			}else {
				voShow.height=styleObj.height;
			}
			if("hideH" in def) {
				h = def.hideH;
				if(h instanceof Function){
					h=h.call(obj);
				}
				voHide.height=(h>=0||h<0)?h+"px":h;
			}else {
				voHide.height=styleObj.height;
			}
		}

		if("alpha" in def) {
			voShow.opacity = styleObj.opacity;
			voHide.opacity = def.alpha;
		}
		
		//Anchor:
		{
			let ax,ay,hCode,vCode;
			ax=obj.anchorX;
			ay=obj.anchorY;
			switch(ax){
				case 0:
				default:
					ax="0px";
					hCode="left";
					break;
				case 1:
					ax="-50%";
					hCode="center";
					break;
				case 2:
					ax="-100%";
					hCode="right";
					break;
			}
			switch(ay){
				case 0:
				default:
					ay="0px";
					vCode="top";
					break;
				case 1:
					ay="-50%";
					vCode="center";
					break;
				case 2:
					ay="-100%";
					vCode="bottom";
					break;
			}
			tsfmLineShow+=`translate(${ax},${ay}) `;
			tsfmLineHide+=`translate(${ax},${ay}) `;
			voShow.transformOrigin=vCode+" "+hCode;
			voHide.transformOrigin=vCode+" "+hCode;
		}
		
		if("scale" in def){
			tsfmLineShow+='scale('+obj.scale+') ';
			tsfmLineHide+='scale('+(def.scale)+') ';
		}else {
			tsfmLineShow+='scale('+obj.scale+') ';
			tsfmLineHide+='scale('+obj.scale+') ';
		}
		
		if("rotate" in def){
			tsfmLineShow+='rotate('+obj.rotate+'deg)';
			tsfmLineHide+='rotate('+def.rotate+'deg)';
		}else {
			tsfmLineShow+='rotate('+obj.rotate+'deg)';
			tsfmLineHide+='rotate('+obj.rotate+'deg)';
		}
		voShow.transform = tsfmLineShow;
		voHide.transform = tsfmLineHide;

		this.webAniOpts={
			composite:"replace",duration:this.duration,easing:def.easing
		};
	};
}

//****************************************************************************
//Auto animate:
//****************************************************************************
{
	//------------------------------------------------------------------------
	let AniAuto=function(def,obj){
		if(!def)
			return;
		this.orgStyle=null;
		this.tgtStyle=null;
		this.orgDisplay=0;
		this.tgtDisplay=0;
		VFACTAni.call(this,def,obj);
	};
	let aniAuto=AniAuto.prototype=new VFACTAni();
	VFACTAni.regAni("auto",AniAuto);

	//------------------------------------------------------------------------
	//-----------------------------------------------------------------------
	//bind animate with UI-Obj:
	aniAuto.bind2Obj = function (obj) {
		let styleObj;
		this.uiObj = obj;
		styleObj=obj.webObj.style;
		this.orgDisplay=obj.display;
		this.orgStyle={
			left:styleObj.left,
			top:styleObj.top,
			width:styleObj.width,
			height:styleObj.height,
			opacity:styleObj.opacity,
			transfrom:styleObj.transform,
		};
		if (this.def) {
			this.state = STATE_READY;
		}
	};
	
	//------------------------------------------------------------------------
	aniAuto.setupKeyFrames=function(){
		let self,obj,styleObj,def,finStyle;
		self=this;
		def=this.def;
		obj=this.uiObj;
		styleObj=obj.webObj.style;
		this.tgtDisplay=obj.display;
		this.tgtStyle={
			left:styleObj.left,
			top:styleObj.top,
			width:styleObj.width,
			height:styleObj.height,
			opacity:styleObj.opacity,
			transfrom:styleObj.transform,
		};
		finStyle={...this.tgtStyle};
		this.duration=def.duration||def.time||200;
		if(this.tgtDisplay===this.orgDisplay && !this.orgDisplay){
			this.keyFrames=null;
			return;
		}
		if(!this.orgDisplay && this.tgtDisplay){
			if(def.fade){
				this.orgStyle.opacity=0;
			}
		}else if(this.orgDisplay  && !this.tgtDisplay){
			if(def.fade){
				this.tgtStyle.opacity=0;
			}
		}
		this.keyFrames=[this.orgStyle,this.tgtStyle];
		//Setup OnFinish:
		this.OnFinish=function(){
			Object.assign(styleObj,finStyle);
			if(def.OnFinish){
				def.OnFinish.call(self);
			}
		};
		this.OnCancel=function(){
			if(def.OnCancel){
				def.OnCancel.call(self);
			}
		};
	};
}

//****************************************************************************
//:shared util functions:
//****************************************************************************
let escapeHTML,unescapeHTML,getTextSize,fixColor;
{
	escapeHTML=function (htmlStr) {
		let pts,n;
		htmlStr=htmlStr.replaceAll("&", "&amp;")
			.replaceAll("<", "&lt;")
			.replaceAll(">", "&gt;")
			.replaceAll('"', "&quot;")
			.replaceAll("'", "&#39;")
			.replaceAll("\r", "");
		pts=htmlStr.split("\n");
		n=pts.length;
		if(n>0){
			/*for(i=0;i<n;i++){
				pts[i]='"'+pts[i]+'"';
			}*/
			htmlStr=pts.join("\n<br>\n");
		}
		return htmlStr;
	};
	unescapeHTML=function(htmlStr) {
		return htmlStr.replaceAll("&#39;","'")
			.replaceAll("&quot;",'"')
			.replaceAll("&gt;",">")
			.replaceAll("&lt;","<")
			.replaceAll("&amp;","&");
	};
	
	getTextSize=function(text, webObj) {
		// re-use canvas object for better performance
		let font,styleObj;
		const canvas = getTextSize.canvas || (getTextSize.canvas = document.createElement("canvas"));
		const context = canvas.getContext("2d");
		styleObj=window.getComputedStyle(webObj,null);
		font=`${styleObj.fontWeight} ${styleObj.fontSize} ${styleObj.fontFamily}`;
		context.font = font;
		const metrics = context.measureText(text);
		return [Math.trunc(metrics.width),Math.trunc(metrics.height)];
	};
	fixColor=function(v){
		let l;
		v=[...v];
		l=v[4];
		if(l>=0){
			l=l>100?100:l;
			v[0]=(255-v[0])*l/100+v[0];
			v[1]=(255-v[1])*l/100+v[1];
			v[2]=(255-v[2])*l/100+v[2];
		}else if(l<0){
			l=l<-100?-100:l;
			v[0]=v[0]*(100+l)/100;
			v[1]=v[1]*(100+l)/100;
			v[2]=v[2]*(100+l)/100;
		}
		return v;
	};
}
//****************************************************************************
//:System event handlers: mouse up, drag component
//****************************************************************************
let sysAddOnMouseUp,sysRemoveOnMouseUp;
let sysStartDrag;
{
	let sysDragVO=null;
	let sysDragOrgX=0;
	let sysDragOrgY=0;
	let sysOnMouseUpReg=new Set();
	VFACT.sysAddOnMouseUp=sysAddOnMouseUp=function(callback){
		sysOnMouseUpReg.add(callback);
	};
	VFACT.sysRemoveOnMouseUp=sysRemoveOnMouseUp=function(callback){
		sysOnMouseUpReg.delete(callback);
	};
	
	
	//Drag compoent moving:
	VFACT.startDrag=sysStartDrag=function(evt,vo){
		if(sysDragVO){
			let dx,dy;
			dx=evt.x-sysDragOrgX;
			dy=evt.y-sysDragOrgY;
			sysDragVO.OnDone && sysDragVO.OnDone(evt,dx,dy);
		}
		sysDragOrgX=evt.x;
		sysDragOrgY=evt.y;
		sysDragVO=vo;
	};
	VFACT.stopDrag=function(vo){
		if(vo && vo!==sysDragVO){
			return;
		}
		if(sysDragVO){
			sysDragVO.OnDone && sysDragVO.OnDone(null,0,0);
			sysDragVO=null;
		}
	};
	document.body.addEventListener("mouseup",(evt)=>{
		let callback;
		for(callback of sysOnMouseUpReg){
			callback(evt);
		}
	});
	document.body.addEventListener("mousemove",(evt)=>{
		if(sysDragVO){
			let dx,dy;
			dx=evt.x-sysDragOrgX;
			dy=evt.y-sysDragOrgY;
			sysDragVO.OnDrag && sysDragVO.OnDrag(evt,dx,dy);
			evt.stopPropagation();
		}
	},true);
	document.body.addEventListener("mouseup",(evt)=>{
		if(sysDragVO){
			let dx,dy;
			dx=evt.x-sysDragOrgX;
			dy=evt.y-sysDragOrgY;
			sysDragVO.OnDone && sysDragVO.OnDone(evt,dx,dy);
			evt.stopPropagation();
			sysDragVO=null;
		}
	},true);
}

let vmcAddRefcount=VFACTObj.vmcAddRefcount;
let vmcRelease=VFACTObj.vmcRelease;

//****************************************************************************
//:Common properties all types shared:
//****************************************************************************
function setupBasic(typeDef){
	//Fast propertie index:
	let pptXIdx=typeDef.allocPptIdx("x",0);
	let pptYIdx=typeDef.allocPptIdx("y",0);
	let pptZIdx=typeDef.allocPptIdx("z");
	let pptWIdx=typeDef.allocPptIdx("w",100);
	let pptHIdx=typeDef.allocPptIdx("h",100);
	let pptMinWIdx=typeDef.allocPptIdx("minW","");
	let pptMinHIdx=typeDef.allocPptIdx("minH","");
	let pptMaxWIdx=typeDef.allocPptIdx("maxW","");
	let pptMaxHIdx=typeDef.allocPptIdx("maxH","");
	let pptLayoutXFuncIdx=typeDef.allocPptIdx("layoutXFunc");
	let pptLayoutYFuncIdx=typeDef.allocPptIdx("layoutYFunc");
	let pptLayoutWFuncIdx=typeDef.allocPptIdx("layoutWFunc");
	let pptLayoutHFuncIdx=typeDef.allocPptIdx("layoutHFunc");
	let pptLayoutMinWFuncIdx=typeDef.allocPptIdx("layoutMinWFunc");
	let pptLayoutMinHFuncIdx=typeDef.allocPptIdx("layoutMinHFunc");
	let pptLayoutMaxWFuncIdx=typeDef.allocPptIdx("layoutMaxWFunc");
	let pptLayoutMaxHFuncIdx=typeDef.allocPptIdx("layoutMaxHFunc");
	let pptAutoLayoutIdx=typeDef.allocPptIdx("autoLayout");
	let pptAXIdx=typeDef.allocPptIdx("anchorX",0);
	let pptAYIdx=typeDef.allocPptIdx("anchorY",0);
	let pptAlphaIdx=typeDef.allocPptIdx("alpha",0);
	let pptRotateIdx=typeDef.allocPptIdx("rotate",0);
	let pptScaleIdx=typeDef.allocPptIdx("scale",1);
	let pptTransformOriginIdx=typeDef.allocPptIdx("transformOrigin","center center");
	let pptMarginIdx=typeDef.allocPptIdx("margin");
	let pptPaddingIdx=typeDef.allocPptIdx("padding");
	let pptTraceSizeIdx=typeDef.allocPptIdx("traceSize",false);
	let pptAspectIdx=typeDef.allocPptIdx("aspect","");
	let pptOnSizeIdx=typeDef.defineIdxOnlyPpt("OnSize",null);
	let pptSizeTracerIdx=typeDef.allocPptIdx("sizeTracer",null);
	let pptOverflowIdx=typeDef.allocPptIdx("overflow",1);
	
	let funcGetMap=typeDef.getMap;
	let funcSetMap=typeDef.setMap;
	
	//Val functions:
	let getParent;
	let _layoutChildren;
	let _maybeLayoutChildren;
	let setPosition,getPosition;
	let setX,getX,setY,getY,setZ,getZ;
	let setW,getW,setH,getH;
	let setAX,getAX,setAY,getAY;
	let setTrsmOrg,getTrsmOrg;
	let setAlpha,getAlpha;
	let setScale,getScale;
	let setRotate,getRotate;
	let setMargin,getMargin;
	let setPadding,getPadding;
	let setOverflow,getOverflow;
	let setStyleClass,getStyleClass,getClassList;
	
	let applyTrsm,applyAnchor;
	let parseLength;
	{
		//------------------------------------------------------------------------
		applyAnchor=applyTrsm=function(valMap){
			let sVal,rVal,line,vCode,hCode,styleObj;
			line="";
			let ax,ay;
			ax=valMap[pptAXIdx];
			ay=valMap[pptAYIdx];
			switch(ax){
				case 0:
				default:
					ax="0px";
					hCode="left";
					break;
				case 1:
					ax="-50%";
					hCode="center";
					break;
				case 2:
					ax="-100%";
					hCode="right";
					break;
			}
			switch(ay){
				case 0:
				default:
					ay="0px";
					vCode="top";
					break;
				case 1:
					ay="-50%";
					vCode="center";
					break;
				case 2:
					ay="-100%";
					vCode="bottom";
					break;
			}
			line+=`translate(${ax},${ay}) `;
			sVal=valMap[pptScaleIdx];
			rVal=valMap[pptRotateIdx];
			if(rVal>0 || rVal<0){
				line+=`rotate(${rVal}deg) `;
			}else if(rVal!==undefined){
				line+=`rotate(${rVal}) `;
			}
			if(sVal>=0||sVal<0){
				line+=`scale(${sVal}) `;
			}else if(Array.isArray(sVal)){
				line+=`scale(${sVal[0]},${sVal[1]}) `;
			}else if(sVal){
				line+=`scale(${sVal}) `;
			}
			
			styleObj=valMap[pptStyleObjIdx];
			styleObj.transform=line;
			styleObj.transformOrigin=vCode+" "+hCode;
		};
	}
	
	//set readOnly but can call set functions:
	funcSetMap.set("children",()=>{});
	funcSetMap.set("attached",()=>{});
	
	//--------------------------------------------------------------------------
	//id, parent, previousSibling, nextSibling, querySelector :
	{
		funcGetMap.set("webObj",function(valMap){
			return valMap[pptWebObjIdx];
		});

		funcGetMap.set("style",function(valMap){
			return valMap[pptStyleObjIdx];
		});

		let setId=function(valMap,val){
			valMap[pptWebObjIdx].id=val;
		};
		let getId=function(valMap){
			return valMap[pptWebObjIdx].id;
		};
		typeDef.definePpt("id",getId,setId,false);
		
		getParent=function(valMap){
			let p;
			let webObj=valMap[pptWebObjIdx];
			p=webObj.parentNode;
			if(p){
				return p.$_pxy;
			}
			return null;
		};
		funcGetMap.set("parent",getParent);
		funcGetMap.set("father",getParent);
		
		let getPre=function(valMap){
			let webObj=valMap[pptWebObjIdx];
			if(webObj) {
				let obj = webObj.previousSibling;
				return obj?obj.$_pxy:null;
			}
			return null;
		};
		funcGetMap.set("previousSibling",getPre);
		
		let getNext=function(valMap){
			let webObj=valMap[pptWebObjIdx];
			if(webObj) {
				let obj = webObj.nextSibling;
				return obj?obj.$_pxy:null;
			}
			return null;
		};
		funcGetMap.set("nextSibling",getNext);
		
		{
			let funcIdx=typeDef.allocPptIdx("querySelector",null);
			let querySelector=function(valMap){
				let func;
				func=valMap[funcIdx];
				if(!func){
					let webObj=valMap[pptWebObjIdx];
					func=valMap[funcIdx]=(selectors,domElement=false)=>{
						let element;
						element=webObj.querySelector(selectors);
						if(domElement){
							return element;
						}
						return element?element.$_pxy:null;
					};
				}
				return func;
			};
			funcGetMap.set("querySelector",querySelector);
		}
		
		//This should goto JAX patch?
		{
			let funcIdx=typeDef.allocPptIdx("getElementById",null);
			let getElementById=function(valMap){
				let func;
				func=valMap[funcIdx];
				if(!func){
					let webObj=valMap[pptWebObjIdx];
					func=valMap[funcIdx]=(searchId)=>{
						let element;
						element=webObj.querySelector("#"+searchId);
						return element?element.$_pxy:null;
					};
				}
				return func;
			};
			funcGetMap.set("getElementById",getElementById);
		}
		
		{
			let funcIdx=typeDef.allocPptIdx("querySelectorAll",null);
			let querySelectorAll=function(valMap){
				let func;
				func=valMap[funcIdx];
				if(!func){
					let webObj=valMap[pptWebObjIdx];
					func=valMap[funcIdx]=(selectors,domElement=false)=>{
						let list;
						list=webObj.querySelector(selectors);
						if(domElement){
							return list;
						}
						let alist=[],item,i,n;
						n=list.length;
						for(i=0;i<n;i++){
							item=list[i].$_pxy;
							if(item){
								alist.push(item);
							}
						}
						return alist;
					};
				}
			};
			funcGetMap.set("querySelectorAll",querySelectorAll);
		}
	}
	
	//addRefCount
	{
		let getRefCount=function(valMap){
			return valMap[pptRefCountIdx];
		};
		funcGetMap.set("refCount",getRefCount);
		
		typeDef.defineFunction("addRefCount",vmcAddRefcount);
		funcGetMap.set("hold",funcGetMap.get("addRefCount"));
	}
	//release
	{
		typeDef.defineFunction("release",vmcRelease);
	}
	
	//--------------------------------------------------------------------------
	//doLayout, autoLayout, layoutChildren, traceSize:
	{
		//-------------------------------------------------------------------
		//ppt autoLayout:
		funcGetMap.set("autoLayout",(valMap)=>{
			return valMap[pptAutoLayoutIdx];
		});
		funcSetMap.set("autoLayout",(valMap,val)=>{
			val=!!val;
			valMap[pptAutoLayoutIdx]=val;
			return val;
		});
		
		//--------------------------------------------------------------------
		//ppt traceSize:
		funcGetMap.set("traceSize",(valMap)=>{
			return valMap[pptTraceSizeIdx];
		});
		funcSetMap.set("traceSize",(valMap,val)=>{
			let tracer,onSize,webObj;
			webObj=valMap[pptWebObjIdx];
			val=!!val;
			if(valMap[pptTraceSizeIdx]===val){
				return;
			}
			valMap[pptTraceSizeIdx]=val;
			if(val){
				tracer=valMap[pptSizeTracerIdx];
				if(!tracer){
					tracer=valMap[pptSizeTracerIdx]=new ResizeObserver(entries=>{
						if(webObj.offsetParent){
							onSize=valMap[pptOnSizeIdx];
							if(onSize){
								onSize.call(valMap[pptProxyIdx]);
							}
							_maybeLayoutChildren.call(valMap);
						}
					});
				}
				tracer.observe(valMap[pptWebObjIdx]);
			}else {
				tracer=valMap[pptSizeTracerIdx];
				if(tracer){
					tracer.unobserve(valMap[pptWebObjIdx]);
				}
			}
		});
		
		//-------------------------------------------------------------------
		//function doLayout():
		typeDef.defineFunction("doLayout",function(){
			let valMap=this;
			let lotFunc,parent,fw,fh,val;
			let oldW,oldH,sizeChanged=0;
			let pxy=valMap[pptProxyIdx];
			let styleObj=valMap[pptStyleObjIdx];
			oldW=valMap[pptWIdx];
			oldH=valMap[pptHIdx];
			parent=getParent(valMap);
			if(!parent){
				return;
			}
			fw=parent.clientW;
			fh=parent.clientH;
			
			lotFunc=valMap[pptLayoutXFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptXIdx]=val;
				if(val>=0||val<0){
					styleObj.left=val+"px";
				}else {
					styleObj.left=val;
				}
			}
			lotFunc=valMap[pptLayoutYFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptYIdx]=val;
				if(val>=0||val<0){
					styleObj.top=val+"px";
				}else {
					styleObj.top=val;
				}
			}
			lotFunc=valMap[pptLayoutMinWFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptMinWIdx]=val;
				if(val>=0||val<0){
					styleObj.minWidth=val+"px";
				}else {
					styleObj.minWidth=val;
				}
			}
			lotFunc=valMap[pptLayoutMaxWFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptMaxWIdx]=val;
				if(val>=0||val<0){
					styleObj.maxWidth=val+"px";
				}else {
					styleObj.maxWidth=val;
				}
			}
			lotFunc=valMap[pptLayoutMinHFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptMinHIdx]=val;
				if(val>=0||val<0){
					styleObj.minHeight=val+"px";
				}else {
					styleObj.minHeight=val;
				}
			}
			lotFunc=valMap[pptLayoutMaxHFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptMaxHIdx]=val;
				if(val>=0||val<0){
					styleObj.maxHeight=val+"px";
				}else {
					styleObj.maxHeight=val;
				}
			}
			lotFunc=valMap[pptLayoutWFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptWIdx]=val;
				if(val>=0||val<0){
					styleObj.width=val+"px";
				}else {
					styleObj.width=val;
				}
				if(val!==oldW){
					sizeChanged=1;
				}
			}
			lotFunc=valMap[pptLayoutHFuncIdx];
			if(lotFunc){
				val=lotFunc.call(pxy,fw,fh);
				valMap[pptHIdx]=val;
				if(val>=0||val<0){
					styleObj.height=val+"px";
				}else {
					styleObj.height=val;
				}
				if(val!==oldH){
					sizeChanged=1;
				}
			}
			//Callafter: layoutChildren
			if(sizeChanged){
				_maybeLayoutChildren.call(valMap);
			}
		});
		
		//-------------------------------------------------------------------
		//function maybeLayoutChildren():
		{
			let pptMaybeLayoutChildren=typeDef.allocPptIdx(null,0);
			_maybeLayoutChildren=function(){
				let valMap=this;
				if(valMap[pptMaybeLayoutChildren]){
					return;
				}
				valMap[pptMaybeLayoutChildren]=1;
				callAfter$1(()=>{
					valMap[pptMaybeLayoutChildren]=0;
					_layoutChildren.call(valMap);
				},0,valMap);
			};
			typeDef.defineFunction("maybeLayoutChildren",_maybeLayoutChildren);
		}
		
		//-------------------------------------------------------------------
		//layoutChildren():
		{
			_layoutChildren=function(){
				let valMap=this;
				let chds,chd,i,n;
				let pxy=valMap[pptProxyIdx];
				if(!pxy)
					return;
				chds=pxy.children;
				if(!chds)
					return;
				n=chds.length;
				for(i=0;i<n;i++){
					chd=chds[i];
					if(chd && chd.autoLayout){
						chd.doLayout();
					}
				}
			};
			typeDef.defineFunction("layoutChildren",_layoutChildren);
		}
	}
	
	//-------------------------------------------------------------------
	//clearChildren()
	{
		typeDef.defineFunction("clearChildren",function(){
			//No child in basic.
		});
	}
	
	//--------------------------------------------------------------------------
	//ppt position:
	{
		setPosition=function(valMap,val){
			valMap[pptStyleObjIdx].position=val;
		};
		getPosition=function(valMap){
			return valMap[pptStyleObjIdx].position;
		};
		typeDef.definePpt("position",getPosition,setPosition,false);
	}
	
	//------------------------------------------------------------------------
	//ppt uiEvent:
	{
	
		let pptUIEventIdx=typeDef.allocPptIdx("uiEvent",1);
		let setUIEvent=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptUIEventIdx]=val;
			switch(val){
				case -1:
				case 0://same with 1?
					styleObj.pointerEvents="none";
					break;
				case 1:
					styleObj.pointerEvents="auto";
					break;
			}
		};
		let getUIEvent=function(valMap,val){
			return valMap[pptUIEventIdx];
		};
		typeDef.definePpt("uiEvent",getUIEvent,setUIEvent,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt flex:
	{
		let _set=function(valMap,val){
			if(val===true){
				val="1 0 auto";
			}else if(val>0){
				val=val+" 0 auto";
			}
			valMap[pptStyleObjIdx].flex=val;
		};
		let _get=function(valMap){
			return valMap[pptStyleObjIdx].flex;
		};
		typeDef.definePpt("flex",_get,_set,false);
	}

	parseLength=function(valMap,val,funcPptIdx){
		let valType=typeof(val);
		let pxy=valMap[pptProxyIdx];
		if(valType==="function"){
			let pObj,fw,fh;
			pObj=getParent(valMap);
			if(pObj){
				fw=pObj.clientW;
				fh=pObj.clientH;
			}else {
				fw=0;
				fh=0;
			}
			valMap[funcPptIdx]=val;
			val=val.call(pxy,fw,fh);
		}else if(valType==="string"){
			if(val[val.length-1]==="%"){
				valMap[funcPptIdx]=null;
			}else if(val[0]===">"){//Raw HTML length:
				valMap[funcPptIdx]=null;
				val=val.substring(1);
			}else if(val){
				let pObj,fw,fh;
				pObj=getParent(valMap);
				if(pObj){
					fw=pObj.clientW;
					fh=pObj.clientH;
				}else {
					fw=0;
					fh=0;
				}
				try{
					val = new Function("FW", "FH", "return (" + val + ")");
					valMap[funcPptIdx]=val;
					val=val.call(pxy,fw,fh);
				}catch(err){
					val=0;
				}
			}else {
				valMap[funcPptIdx]=null;
				valMap[pptXIdx]=val;
				return "";
			}
		}else {
			valMap[funcPptIdx]=null;
		}
		return val;
	};
	//--------------------------------------------------------------------------
	//x,y,z,w,h
	{
		//------------------------------------------------------------------------
		//ppt x:
		{
			setX=function(valMap,val){
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutXFuncIdx);
				valMap[pptXIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.left=val+"px";
				}else {
					styleObj.left=val;
				}
			};
			getX=function(valMap){
				let webObj;
				webObj=valMap[pptWebObjIdx];
				if(webObj.offsetParent){
					return webObj.offsetLeft;
				}
				return valMap[pptXIdx];
			};
			typeDef.definePpt("x",getX,setX,true);
		}
		
		//------------------------------------------------------------------------
		//ppt y:
		{
			setY=function(valMap,val){
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutYFuncIdx);
				valMap[pptYIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.top=val+"px";
				}else {
					styleObj.top=val;
				}
			};
			getY=function(valMap){
				let webObj;
				webObj=valMap[pptWebObjIdx];
				if(webObj.offsetParent){
					return webObj.offsetTop;
				}
				return valMap[pptYIdx];
			};
			typeDef.definePpt("y",getY,setY,true);
		}
		
		//------------------------------------------------------------------------
		//z/zIndex
		{
			let parseInt=window.parseInt;//Faster?
			setZ=function(valMap,val){
				val=parseInt(val);
				if(val>=0 || val<0){
					valMap[pptZIdx]=val;
					valMap[pptStyleObjIdx].zIndex=val;
				}else {
					val="";
					valMap[pptZIdx]=undefined;
					valMap[pptStyleObjIdx].zIndex=val;
				}
			};
			getZ=function(valMap){
				return valMap[pptZIdx];
			};
			typeDef.definePpt("z",getZ,setZ,true);
			typeDef.definePpt("zIndex",getZ,setZ,true);
		}
		
		//------------------------------------------------------------------------
		//ppt w:
		{
			setW=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutWFuncIdx);
				oldVal=valMap[pptWIdx];
				valMap[pptWIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.width=val+"px";
				}else {
					styleObj.width=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			getW=function(valMap){
				let webObj;
				webObj=valMap[pptWebObjIdx];
				if(webObj.offsetParent){
					return webObj.offsetWidth;
				}
				return valMap[pptWIdx];
			};
			typeDef.definePpt("w",getW,setW,true);
			typeDef.definePpt("width",getW,setW,true);
		}
		
		//------------------------------------------------------------------------
		//ppt h:
		{
			setH=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutHFuncIdx);
				oldVal=valMap[pptHIdx];
				valMap[pptHIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.height=val+"px";
				}else {
					styleObj.height=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			getH=function(valMap){
				let webObj;
				webObj=valMap[pptWebObjIdx];
				if(webObj.offsetParent){
					return webObj.offsetHeight;
				}
				return valMap[pptHIdx];
			};
			typeDef.definePpt("h",getH,setH,true);
			typeDef.definePpt("height",getH,setH,true);
		}
		
		//------------------------------------------------------------------------
		//ppt minWidth:
		{
			let setVal=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutMinWFuncIdx);
				oldVal=valMap[pptMinWIdx];
				valMap[pptMinWIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.minWidth=val+"px";
				}else {
					styleObj.minWidth=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			let getVal=function(valMap){
				return valMap[pptMinWIdx];
			};
			typeDef.definePpt("minW",getVal,setVal,true);
			funcGetMap.set("minWidth",funcGetMap.get("minW"));
			funcSetMap.set("minWidth",funcSetMap.get("minW"));
		}

		//------------------------------------------------------------------------
		//ppt maxWidth:
		{
			let setVal=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutMaxWFuncIdx);
				oldVal=valMap[pptMaxWIdx];
				valMap[pptMaxWIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.maxWidth=val+"px";
				}else {
					styleObj.maxWidth=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			let getVal=function(valMap){
				return valMap[pptMaxWIdx];
			};
			typeDef.definePpt("maxW",getVal,setVal,true);
			funcGetMap.set("maxWidth",funcGetMap.get("maxW"));
			funcSetMap.set("maxWidth",funcSetMap.get("maxW"));
		}
		
		//------------------------------------------------------------------------
		//ppt minHeight:
		{
			let setVal=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutMinHFuncIdx);
				oldVal=valMap[pptMinHIdx];
				valMap[pptMinHIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.minHeight=val+"px";
				}else {
					styleObj.minHeight=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			let getVal=function(valMap){
				return valMap[pptMaxHIdx];
			};
			typeDef.definePpt("minH",getVal,setVal,true);
			funcGetMap.set("minHeight",funcGetMap.get("minH"));
			funcSetMap.set("minHeight",funcSetMap.get("minH"));
		}

		//------------------------------------------------------------------------
		//ppt maxHeight:
		{
			let setVal=function(valMap,val){
				let oldVal;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				val=parseLength(valMap,val,pptLayoutMaxHFuncIdx);
				oldVal=valMap[pptMaxHIdx];
				valMap[pptMaxHIdx]=val;
				if(val>0||val<0||val===0){
					styleObj.maxHeight=val+"px";
				}else {
					styleObj.maxHeight=val;
				}
				if(oldVal!==val){
					_maybeLayoutChildren.call(valMap);
				}
			};
			let getVal=function(valMap){
				return valMap[pptMaxHIdx];
			};
			typeDef.definePpt("maxH",getVal,setVal,true);
			funcGetMap.set("maxHeight",funcGetMap.get("maxH"));
			funcSetMap.set("maxHeight",funcSetMap.get("maxH"));
		}
	}
	
	//--------------------------------------------------------------------------
	//ppt clientWidth, clientHeight:
	{
		//------------------------------------------------------------------------
		let getClientW=function(valMap){
			let w;
			let webObj;
			webObj=valMap[pptWebObjIdx];
			if(webObj.offsetParent){
				return webObj.clientWidth;
			}
			w=valMap[pptWIdx];
			//TODO: apply border and padding:
			return w>=0?w:0;
		};
		funcGetMap.set("clientW",getClientW);
		funcGetMap.set("clientWidth",getClientW);
		
		//------------------------------------------------------------------------
		let getClientH=function(valMap){
			let h;
			let webObj;
			webObj=valMap[pptWebObjIdx];
			if(webObj.offsetParent){
				return webObj.clientHeight;
			}
			h=valMap[pptHIdx];
			//TODO: apply border and padding:
			return h>=0?h:0;
		};
		funcGetMap.set("clientH",getClientH);
		funcGetMap.set("clientHeight",getClientH);
		
		typeDef.defineFunction("getBoundingClientRect",function(){
			let valMap=this;
			let webObj=valMap[pptWebObjIdx];
			return webObj.getBoundingClientRect();
		});
	}
	
	//--------------------------------------------------------------------------
	//ppt anchorX:
	{
		setAX=function(valMap,val){
			switch(val){
				case 0:
				case 1:
				case 2:
					break;
				case "l":
				case "left":{
					val=0;
					break;
				}
				case "c":
				case "center":{
					val=1;
					break;
				}
				case "r":
				case "right":{
					val=2;
					break;
				}
				default:
					val=0;
					break;
				
			}
			valMap[pptAXIdx]=val;
			applyAnchor(valMap);
		};
		getAX=function(valMap){
			return valMap[pptAXIdx];
		};
		typeDef.definePpt("anchorX",getAX,setAX,true);
		funcGetMap.set("anchorH",funcGetMap.get("anchorX"));
		funcSetMap.set("anchorH",funcSetMap.get("anchorX"));
	}
	
	//--------------------------------------------------------------------------
	//ppt anchorY:
	{
		setAY=function(valMap,val){
			switch(val){
				case 0:
				case 1:
				case 2:
					break;
				case "t":
				case "top":{
					val=0;
					break;
				}
				case "c":
				case "center":{
					val=1;
					break;
				}
				case "b":
				case "bottom":{
					val=2;
					break;
				}
				default:
					val=0;
					break;
				
			}
			valMap[pptAYIdx]=val;
			applyAnchor(valMap);
		};
		getAY=function(valMap){
			return valMap[pptAYIdx];
		};
		typeDef.definePpt("anchorY",getAY,setAY,true);
		funcGetMap.set("anchorV",funcGetMap.get("anchorY"));
		funcSetMap.set("anchorV",funcSetMap.get("anchorY"));
	}
	
	//--------------------------------------------------------------------------
	//ppt transform-origin
	{
		setTrsmOrg=function(valMap,val){
			valMap[pptTransformOriginIdx]=val;
			valMap[pptStyleObjIdx].transformOrigin=val;
		};
		getTrsmOrg=function(valMap){
			return valMap[pptTransformOriginIdx];
		};
		typeDef.definePpt("transformOrigin",getTrsmOrg,setTrsmOrg,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt display
	{
		let _set=function(valMap,val){
			val=!!val;
			valMap[pptDisplayIdx]=val;
			valMap[pptStyleObjIdx].display=val?valMap[pptDisplayCodeIdx]:"none";
		};
		let _get=function(valMap){
			return valMap[pptDisplayIdx];
		};
		typeDef.definePpt("display",_get,_set,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt alpha:
	{
		setAlpha=function(valMap,val){
			valMap[pptAlphaIdx]=val;
			valMap[pptStyleObjIdx].opacity=val;
		};
		getAlpha=function(valMap){
			return valMap[pptAlphaIdx];
		};
		typeDef.definePpt("alpha",getAlpha,setAlpha,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt scale:
	{
		setScale=function(valMap,val){
			valMap[pptScaleIdx]=val;
			applyTrsm(valMap);
		};
		getScale=function(valMap){
			return valMap[pptScaleIdx];
		};
		typeDef.definePpt("scale",getScale,setScale,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt rotate:
	{
		setRotate=function(valMap,val){
			valMap[pptRotateIdx]=val;
			applyTrsm(valMap);
		};
		getRotate=function(valMap){
			return valMap[pptRotateIdx];
		};
		typeDef.definePpt("rotate",getRotate,setRotate,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt cursor, aspect, filter:
	{
		let setCursor=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			styleObj.cursor=val;
			return styleObj.cursor;
		};
		let getCursor=function(valMap){
			return valMap[pptStyleObjIdx].cursor;
		};
		typeDef.definePpt("cursor",getCursor,setCursor,true);
		
		let setAspect=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptAspectIdx]=val;
			styleObj.aspectRatio=val;
			return styleObj.val;
		};
		let getAspect=function(valMap,val){
			return valMap[pptAspectIdx];
		};
		typeDef.definePpt("aspect",getAspect,setAspect,true);
		
		let setFilter=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			styleObj.filter=val;
			return styleObj.filter;
		};
		let getFilter=function(valMap){
			return valMap[pptStyleObjIdx].filter;
		};
		typeDef.definePpt("filter",getFilter,setFilter,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt margin:
	{
		setMargin=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptMarginIdx]=val;
			if(Array.isArray(val)){
				styleObj.margin=`${val[0]}px ${val[1]}px ${val[2]}px ${val[3]}px`;
			}else if(val>=0 || val<0){
				styleObj.margin=val+"px";
			}else {
				styleObj.margin=val||"";
			}
		};
		getMargin=function(valMap){
			return valMap[pptMarginIdx];
		};
		typeDef.definePpt("margin",getMargin,setMargin,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt padding:
	{
		setPadding=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptPaddingIdx]=val;
			if(Array.isArray(val)){
				styleObj.padding=`${val[0]}px ${val[1]}px ${val[2]}px ${val[3]}px`;
			}else if(val>=0 || val<0){
				styleObj.padding=val+"px";
			}else {
				styleObj.padding=val||"";
			}
		};
		getPadding=function(valMap){
			return valMap[pptPaddingIdx];
		};
		typeDef.definePpt("padding",getPadding,setPadding,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt overflow:
	{
		setOverflow=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptOverflowIdx]=val;
			if(Array.isArray(val)){
				let code;
				switch(val[0]){
					case 1:
					case "hidden":
					case "clip":
						code="hidden ";
						break;
					case 0:
					case "visible":
					case "show":
						code="visible ";
						break;
					case "scroll":
					case 2:
						code="scroll ";
						break;
					case "auto":
					case 3:
						code="auto ";
						break;
				}
				switch(val[1]){
					case 1:
					case "hidden":
					case "clip":
						code+="hidden";
						break;
					case 0:
					case "visible":
					case "show":
						code+="visible";
						break;
					case "scroll":
					case 2:
						code+="scroll";
						break;
					case "auto":
					case 3:
						code+="auto";
						break;
				}
				styleObj.overflow=code;
			}else {
				switch(val){
					case 1:
					case "hidden":
					case "clip":
						styleObj.overflow="hidden";
						break;
					case 0:
					case "visible":
					case "show":
						styleObj.overflow="visible";
						break;
					case "scroll":
						styleObj.overflow="scroll";
						break;
					case "auto":
						styleObj.overflow="auto";
						break;
					case "scroll-x":
						styleObj.overflow="scroll hidden";
						break;
					case "scroll-y":
						styleObj.overflow="hidden scroll";
						break;
					default:
						styleObj.overflow=val;
						break;
				}
			}
		};
		getOverflow=function(valMap){
			return valMap[pptOverflowIdx];
		};
		typeDef.definePpt("overflow",getOverflow,setOverflow,true);
	}
	
	//------------------------------------------------------------------------
	//style class list
	{
		setStyleClass=function(valMap,val){
			let classList,items;
			let webObj=valMap[pptWebObjIdx];
			classList=webObj.classList;
			//Clear old list:
			items=Array.from(classList.values());
			classList.remove.apply(classList,items);
			if(!val){
				return;
			}
			if(typeof(val)==="string"){
				val=val.split(" ");
			}else if(!Array.isArray(val)){
				val=[val];
			}
			if(val && val.length){
				classList.add.apply(classList,val);
			}
		};
		getStyleClass=function(valMap){
			let webObj=valMap[pptWebObjIdx];
			return webObj.classList.value;
		};
		getClassList=function(valMap){
			let webObj=valMap[pptWebObjIdx];
			return webObj.classList;
		};
		typeDef.definePpt("styleClass",getStyleClass,setStyleClass,false);
		typeDef.definePpt("classList",getClassList,setStyleClass,false);
	}
	
	//------------------------------------------------------------------------
	//animate(def)
	if(VFACT.animate){
		let animate=VFACT.animate;
		typeDef.defineFunction("animate",function(def,startPlay=true){
			let valMap=this;
			let pxy=valMap[pptProxyIdx];
			return animate(pxy,def,startPlay);
		});
	}
	
	//------------------------------------------------------------------------
	//getBoundingClientRect()
	typeDef.defineFunction("getBoundingClientRect",function(){
		let valMap=this;
		let webObj=valMap[pptWebObjIdx];
		return webObj.getBoundingClientRect();
	});
}
VFACTObj.setupBasic=setupBasic;

//****************************************************************************
//:Init basic mouse click:
//****************************************************************************
function setupClick(typeDef){
	let getMap=typeDef.getMap;
	let setMap=typeDef.setMap;

	let pptOnClickIdx=typeDef.allocPptIdx("OnClick",null);
	let pptOnTreeClickIdx=typeDef.allocPptIdx("OnTreeClick",null);
	let _OnClick=function(valMap,evt){
		let webObj,pxy,callback;
		webObj=valMap[pptWebObjIdx];
		pxy=valMap[pptProxyIdx];
		if(evt.target===webObj){
			evt.stopPropagation();
			callback=valMap[pptOnClickIdx];
			if(callback){
				callback.call(pxy,evt);
			}
		}else {
			evt.stopPropagation();
			callback=valMap[pptOnTreeClickIdx];
			if(callback){
				callback.call(pxy,evt);
			}
		}
	};
	//-----------------------------------------------------------------------
	//ppt OnClick:
	{
		let _set=function(valMap,val){
			let callback;
			let webObj=valMap[pptWebObjIdx];
			valMap[pptOnClickIdx]=val;
			callback=valMap[pptOnTreeClickIdx];
			if(!val && !callback){
				webObj.onclick=null;
			}else {
				webObj.onclick=(evt)=>{
					_OnClick(valMap,evt);
				};
			}
		};
		let _get=function(valMap){
			return valMap[pptOnClickIdx];
		};
		getMap.set("OnClick",_get);
		setMap.set("OnClick",_set);
		
	}
	
	//-----------------------------------------------------------------------
	//ppt OnTreeClick:
	{
		let _set=function(valMap,val){
			let callback;
			let webObj=valMap[pptWebObjIdx];
			valMap[pptOnTreeClickIdx]=val;
			callback=valMap[pptOnClickIdx];
			if(!val && !callback){
				webObj.onclick=null;
			}else {
				webObj.onclick=(evt)=>{
					_OnClick(valMap,evt);
				};
			}
		};
		let _get=function(valMap){
			return valMap[pptOnTreeClickIdx];
		};
		getMap.set("OnTreeClick",_get);
		setMap.set("OnTreeClick",_set);
	}

	//-----------------------------------------------------------------------
	//ppt OnMouseInOut:
	{
		let pptOnMouseInOutIdx=typeDef.allocPptIdx("OnMouseInOut",null);
		let _MouseInOut=function(valMap,inout,evt){
			let callback=valMap[pptOnMouseInOutIdx];
			if(callback){
				callback.call(valMap[pptProxyIdx],inout,evt);
			}
		};
		let _set=function(valMap,val){
			let webObj=valMap[pptWebObjIdx];
			valMap[pptOnMouseInOutIdx]=val;
			if(!val){
				webObj.onmouseenter=null;
				webObj.onmouseleave=null;
			}else {
				webObj.onmouseenter=(evt)=>{
					_MouseInOut(valMap,1,evt);
				};
				webObj.onmouseleave=(evt)=>{
					_MouseInOut(valMap,0,evt);
				};
			}
		};
		let _get=function(valMap){
			return valMap[pptOnMouseInOutIdx];
		};
		getMap.set("OnMouseInOut",_get);
		setMap.set("OnMouseInOut",_set);
	}
}
VFACTObj.setupClick=setupClick;

//****************************************************************************
//:Init hierarchy features:
//****************************************************************************
function setupHierarchy(typeDef){
	let funcGetMap=typeDef.getMap;
	let funcSetMap=typeDef.setMap;
	
	let pptContentLayoutIdx=typeDef.allocPptIdx("contentLayout","");
	let pptGridConfigIdx=typeDef.allocPptIdx("gridConfig","");
	let pptSubAlignIdx=typeDef.allocPptIdx("subAlign",0);
	let pptItemsAlignIdx=typeDef.allocPptIdx("itemsAlign",0);
	let applyLayout;

	//-----------------------------------------------------------------------
	applyLayout=function(valMap){
		let layout,styleObj,display,code;
		styleObj=valMap[pptStyleObjIdx];
		layout=valMap[pptContentLayoutIdx];
		switch(layout){
			case "flex":
			case "flex-x":
			case "flexX":
				code=valMap[pptDisplayCodeIdx]="flex";
				styleObj.flexDirection="row";
				break;
			case "flexXr":
			case "flex-xr":
				code=valMap[pptDisplayCodeIdx]="flex";
				styleObj.flexDirection="row-reverse";
				break;
			case "flex-y":
			case "flexY":
				code=valMap[pptDisplayCodeIdx]="flex";
				styleObj.flexDirection="column";
				break;
			case "flexYr":
			case "flex-yr":
				code=valMap[pptDisplayCodeIdx]="flex";
				styleObj.flexDirection="column-reverse";
				break;
			case "grid":
				code=valMap[pptDisplayCodeIdx]="grid";
				break;
		}
		display=valMap[pptDisplayIdx];
		if(display){
			styleObj.display=code;
		}
	};
	
	//-----------------------------------------------------------------------
	//runtime properties:
	{
		//-------------------------------------------------------------------
		//ppt contentLayout:
		{
			let _set=function(valMap,val){
				valMap[pptContentLayoutIdx]=val;
				applyLayout(valMap);
			};
			let _get=function(valMap) {
				return valMap[pptContentLayoutIdx];
			};
			typeDef.definePpt("contentLayout",_get,_set,true);
		}

		//-------------------------------------------------------------------
		//ppt subAlign:
		{
			let _set=function(valMap,val){
				let styleObj;
				valMap[pptSubAlignIdx]=val;
				styleObj=valMap[pptStyleObjIdx];
				switch(val){
					case 0:
						styleObj.justifyContent="flex-start";
						break;
					case 1:
						styleObj.justifyContent="center";
						break;
					case 2:
						styleObj.justifyContent="flex-end";
						break;
					case 3:
						styleObj.justifyContent="space-around";
						break;
					case 4:
						styleObj.justifyContent="space-evenly";
						break;
					case 4:
						styleObj.justifyContent="space-between";
						break;
					default:
						styleObj.justifyContent=val;
						break;
				}
			};
			let _get=function(valMap) {
				return valMap[pptSubAlignIdx];
			};
			typeDef.definePpt("subAlign",_get,_set,true);
		}

		//-------------------------------------------------------------------
		//ppt itemsAlign:
		{
			let _set=function(valMap,val){
				let styleObj;
				valMap[pptItemsAlignIdx]=val;
				styleObj=valMap[pptStyleObjIdx];
				switch(val){
					case 0:
						styleObj.alignItems="start";
						break;
					case 1:
						styleObj.alignItems="center";
						break;
					case 2:
						styleObj.alignItems="flex-end";
						break;
					default:
						styleObj.alignItems=val;
						break;
				}
			};
			let _get=function(valMap) {
				return valMap[pptItemsAlignIdx];
			};
			typeDef.definePpt("itemsAlign",_get,_set,true);
		}

		//-------------------------------------------------------------------
		//ppt gridConfig:
		{
			let _set=function(valMap,val){
				let styleObj;
				valMap[pptGridConfigIdx]=val;
				styleObj=valMap[pptStyleObjIdx];
				if(Array.isArray((val))){
					if(val.length===2){
						styleObj.gridTemplateColumns=val[0]||"";
						styleObj.gridTemplateRows=val[1]||"";
					}else {
						styleObj.gridTemplateAreas=val[0]||"";
						styleObj.gridTemplateColumns=val[1]||"";
						styleObj.gridTemplateRows=val[2]||"";
					}
				}else {
					styleObj.gridTemplateColumns=val;
				}
			};
			let _get=function(valMap) {
				return valMap[pptGridConfigIdx];
			};
			typeDef.definePpt("gridConfig",_get,_set,true);
		}

		//-------------------------------------------------------------------
		let getFirstChild=function(valMap){
			let obj;
			obj=valMap[pptWebObjIdx].firstChild;
			return obj?obj.$_pxy:null;
		};
		funcGetMap.set("firstChild",getFirstChild);
		
		//------------------------------------------------------------------------
		let getLastChild=function(valMap){
			let element;
			element=valMap[pptWebObjIdx].lastChild;
			return element?element.$_pxy:null;
		};
		funcGetMap.set("lastChild",getLastChild);
		
		//------------------------------------------------------------------------
		let getChildList=function(valMap){
			let childPxy,chNdList;
			childPxy=valMap[pptChildrenIdx];
			if(childPxy){
				return childPxy;
			}
			chNdList=valMap[pptWebObjIdx].childNodes;
			childPxy=new Proxy(chNdList,{
				get:function(obj,pname){
					if(pname>=0){
						let node;
						node=obj[pname];
						if(!node){
							return null;
						}else {
							return node.$_pxy;
						}
					}
					return obj[pname];
				}
			});
			valMap[pptChildrenIdx]=childPxy;
			return childPxy;
		};
		funcGetMap.set("children",getChildList);
		funcSetMap.set("children",()=>{});
	}
	
	//--------------------------------------------------------------------------
	//runtime function
	{
		//-------------------------------------------------------------------
		//appendChild
		{
			typeDef.defineFunction("appendChild",function(obj){
				let valMap=this;
				let subWebObj,prePrt;
				subWebObj=obj.$_webObj;
				prePrt=subWebObj.parentNode;
				if(prePrt){
					prePrt=prePrt.$_pxy;
				}
				valMap[pptWebObjIdx].appendChild(subWebObj);
				obj.doLayout();
				if(!prePrt){
					obj.addRefCount();
				}
				return obj;
			});
		}
		
		//-------------------------------------------------------------------
		//appendNewChild
		{
			typeDef.defineFunction("appendNewChild",function(def){
				let valMap=this;
				if(Array.isArray(def)){
					let item;
					for(item of def){
						VFACT.createObj(item, valMap[pptProxyIdx]);
					}
					return;
				}
				return VFACT.createObj(def, valMap[pptProxyIdx]);
			});
		}
		
		//-------------------------------------------------------------------
		//insertBefore
		{
			typeDef.defineFunction("insertBefore",function(obj1,obj2){
				let valMap=this;
				let webObj1,prePrt;
				webObj1=obj1.$_webObj;
				prePrt=webObj1.parentNode;
				if(prePrt){
					prePrt=prePrt.$_pxy;
				}
				valMap[pptWebObjIdx].insertBefore(webObj1,obj2.$_webObj);
				obj1.doLayout();
				if(!prePrt){
					obj1.addRefCount();
				}
				return obj1;
			});
		}
		
		//-------------------------------------------------------------------
		//insertNewBefore
		{
			typeDef.defineFunction("insertNewBefore",function(def,obj){
				let valMap=this;
				return VFACT.createObj(def, valMap[pptProxyIdx],obj);
			});
		}

		//-------------------------------------------------------------------
		//removeChild
		{
			typeDef.defineFunction("removeChild",function(obj){
				let valMap=this;
				valMap[pptWebObjIdx].removeChild(obj.$_webObj);
				//dec-refcount:
				obj.release();
			});
		}
		
		//-------------------------------------------------------------------
		//replaceChild
		{
			typeDef.defineFunction("replaceChild",function(obj1,obj2){
				let valMap=this;
				let webObj1,prePrt;
				if(obj1===obj2){
					return;
				}
				webObj1=obj1.$_webObj;
				prePrt=webObj1.parentNode;
				if(prePrt){
					prePrt=prePrt.$_pxy;
				}
				obj1=valMap[pptWebObjIdx].replaceChild(webObj1,obj2.$_webObj);
				obj1.doLayout();
				//inc/dec-refcount:
				if(!prePrt){
					obj1.addRefCount();
				}
				obj2.release();
				return obj1;
			});
		}
		
		//-------------------------------------------------------------------
		//clearChildren
		{
			typeDef.defineFunction("clearChildren",function(){
				let valMap=this;
				let obj,pxy;
				let webObj=valMap[pptWebObjIdx];
				while(obj=webObj.firstChild){
					webObj.removeChild(obj);
					pxy=obj.$_pxy;
					if(pxy){
						pxy.release();
					}
				}
			});
		}
		
		//-------------------------------------------------------------------
		//execInTree
		{
			typeDef.defineFunction("execInTree",function(func){
				let valMap=this;
				let list,i,n,subObj,subExec;
				func(valMap[pptProxyIdx]);
				list=valMap[pptWebObjIdx].childNodes;
				n=list.length;
				for(i=0;i<n;i++){
					subObj=list[i].$_pxy;
					if(subObj){
						subExec=subObj.execInTree;
						if(subExec){
							subExec.call(subObj,func);
						}else {
							func(subObj);
						}
					}
				}
			});
		}
	}
}
VFACTObj.setupHierarchy=setupHierarchy;

const emptyList=[];
function setupNoneHierarchy(typeDef){
	let funcGetMap=typeDef.getMap;
	let funcSetMap=typeDef.setMap;

	//-----------------------------------------------------------------------
	//runtime properties:
	{
		//-------------------------------------------------------------------
		let getFirstChild=function(valMap){
			return null;
		};
		funcGetMap.set("firstChild",getFirstChild);
		
		//------------------------------------------------------------------------
		let getLastChild=function(valMap){
			let element;
			element=valMap[pptWebObjIdx].lastChild;
			return element?element.$_pxy:null;
		};
		funcGetMap.set("lastChild",getLastChild);
		
		//------------------------------------------------------------------------
		let getChildList=function(valMap){
			return emptyList;
		};
		funcGetMap.set("children",getChildList);
		funcSetMap.set("children",()=>{});
	}
	
	//--------------------------------------------------------------------------
	//runtime function
	{
		//-------------------------------------------------------------------
		//execInTree
		{
			typeDef.defineFunction("execInTree",function(func){
				let valMap=this;
				func(valMap[pptProxyIdx]);
			});
		}
	}
}
VFACTObj.setupNoneHierarchy=setupNoneHierarchy;

//****************************************************************************
//:Init faces features:
//****************************************************************************
function setupFaces(typeDef){
	let funcGetMap=typeDef.getMap;
	let funcSetMap=typeDef.setMap;
	
	let pptCurFaceIdx=typeDef.allocPptIdx("curFace","");
	let _setFace=function(faceName,vo){
		let valMap=this;
		let faces,faceVO,nameType;
		let pxy=valMap[pptProxyIdx];
		
		function applyFace(fvo){
			let name,obj,ppts;
			for(name in fvo){
				ppts=fvo[name];
				if(typeof(ppts)==="function"){
					if(ppts.call(pxy,vo)===false){
						return;
					}
				}else if(name[0]==="@"){
					let vo=ppts;
					window.setTimeout(()=>{
						applyFace(vo);
					},parseInt(name.substring(1)));
				}else {
					obj=pxy[name];
					if(obj){
						let def,orgAnis,curAnis,i,n,ani;
						orgAnis=ppts.ani;
						if(orgAnis){
							curAnis=[];
							n=orgAnis.length;
							for(i=0;i<n;i++){
								def=orgAnis[i];
								if(def.type==="auto"){
									curAnis[i]=obj.animate(def,false);
								}
							}
						}
						for(let ppt in ppts){
							if(ppt==="ani");else {
								obj[ppt]=ppts[ppt];
							}
						}
						if(orgAnis){
							for(i=0;i<n;i++){
								ani=curAnis[i];
								if(ani){
									ani.start();
								}else {
									obj.animate(orgAnis[i]);
								}
							}
						}
					}/*else{
						console.warn("Missing face target: "+name);
					}*/
				}
			}
		}
		if(!pxy){
			return;
		}
		faces=pxy.faces;
		if(!faces){
			return;
		}
		nameType=typeof(faceName);
		if(Array.isArray(faceName)){
			for(let face of faceName){
				_setFace.call(valMap,face);
			}
			return;
		}else if(nameType==="object"){
			faceVO=faceName;
		}else if(nameType==="string"){
			valMap[pptCurFaceIdx]=faceName;
			faceVO=faces[faceName];
		}
		if(faceVO){
			applyFace(faceVO);
		}
	};
	typeDef.defineFunction("setFace",_setFace);
	funcGetMap.set("showFace",funcGetMap.get("setFace"));
	funcSetMap.set("face",function(valMap,faceName){
		_setFace.call(valMap,faceName);
	});
	funcGetMap.set("face",function(valMap){
		return valMap[pptCurFaceIdx];
	});
}
VFACTObj.setupFaces=setupFaces;

//****************************************************************************
//:Init box properties:
//****************************************************************************
function setupBox(typeDef,bgColor){
	let funcGetMap=typeDef.getMap;
	typeDef.setMap;
	
	//background, border, box-Shadow, mask, etc...
	let pptBackgroundIdx=typeDef.allocPptIdx("background",bgColor);
	let pptCornerIdx=typeDef.allocPptIdx("corner",0);
	let pptBorderIdx=typeDef.allocPptIdx("border",0);
	let pptBorderColorIdx=typeDef.allocPptIdx("borderColor","#000000");
	let pptBorderStyleIdx=typeDef.allocPptIdx("borderStyle","none");
	let pptShadowIdx=typeDef.allocPptIdx("shadow",false);
	let pptShadowXIdx=typeDef.allocPptIdx("shadowX",1);
	let pptShadowYIdx=typeDef.allocPptIdx("shadowY",1);
	let pptShadowBlurIdx=typeDef.allocPptIdx("shadowBlur",2);
	let pptShadowSpreadIdx=typeDef.allocPptIdx("shadowSpread",0);
	let pptShadowColorIdx=typeDef.allocPptIdx("shadowColor",[0,0,0,0.5]);
	let pptShadowInsetIdx=typeDef.allocPptIdx("shadowInset",0);
	let pptMaskImageIdx=typeDef.allocPptIdx("maskImage",undefined);
	
	let setBackground,getBackground;
	let setCorner,getCorner;
	let setBorder,getBorder;
	let setBorderStyle,getBorderStyle;
	let applyShadow;
	let setShadow,getShadow;
	let setShadowX,getShadowX;
	let setShadowY,getShadowY;
	let setShadowBlur,getShadowBlur;
	let setShadowSpread,getShadowSpread;
	let setShadowInset,getShadowInset;
	let setShadowColor,getShadowColor;
	let setMaskImage,getMaskImage;
	
	Object.assign(typeDef.initStyle,{
		background:bgColor,
		borderStyle:"solid",
		borderWidth:"0px",
	});
	
	//--------------------------------------------------------------------------
	//ppt background:
	{
		setBackground=function(valMap,val){
			if(Array.isArray(val)){
				if(val.length>4){
					val=fixColor(val);
				}else {
					val=[...val];
				}
				valMap[pptBackgroundIdx]=val;
				val=`rgba(${val[0]||0},${val[1]||0},${val[2]||0},${val[3]>=0?val[3]:1})`;
			}else {
				valMap[pptBackgroundIdx]=val;
			}
			valMap[pptStyleObjIdx].background=val;
		};
		getBackground=function(valMap){
			return valMap[pptBackgroundIdx];
		};
		typeDef.definePpt("background",getBackground,setBackground,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt corner:
	{
		setCorner=function(valMap,val){
			valMap[pptCornerIdx]=val;
			if(val>=0||val<0){
				val=val+"px";
			}else if(Array.isArray(val)){
				val=`${val[0]||0}px ${val[1]||0}px ${val[2]||0}px ${val[3]||0}px`;
			}
			valMap[pptStyleObjIdx].borderRadius=val;
		};
		getCorner=function(valMap){
			return valMap[pptCornerIdx];
		};
		typeDef.definePpt("corner",getCorner,setCorner,true);
	}
	
	//------------------------------------------------------------------------
	//ppt outline:
	{
		let setOutline=function(valMap,val){
			valMap[pptStyleObjIdx].outlineStyle = val?"auto":"none";
		};
		let getOutline=function(valMap){
			return valMap[pptStyleObjIdx].outlineStyle==="none"?0:1;
		};
		typeDef.definePpt("outline",getOutline,setOutline,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt border:
	{
		setBorder=function(valMap,val){
			valMap[pptBorderIdx]=val;
			if(val>=0||val<0){
				val=val+"px";
			}else if(Array.isArray(val)){
				val=`${val[0]||0}px ${val[1]||0}px ${val[2]||0}px ${val[3]||0}px`;
			}
			valMap[pptStyleObjIdx].borderWidth=val;
		};
		getBorder=function(valMap){
			return valMap[pptBorderIdx];
		};
		typeDef.definePpt("border",getBorder,setBorder,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt borderColor:
	{
		//----------------------------------------------------------------------
		let set_=function(valMap,val){
			if(Array.isArray(val)){
				let r;
				val=[...val];
				r=val[0];
				if(r>=0){
					if(val.length>4){
						val=fixColor(val);
					}
					valMap[pptBorderColorIdx]=val;
					val=`rgba(${val[0]},${val[1]},${val[2]}, ${val[3]>=0?val[3]:1})`;
				}else if(Array.isArray(r)){
					if(val[0].length>4){
						val[0]=fixColor(val[0]);
					}else {
						val[0]=[...val[0]];
					}
					if(val[1].length>4){
						val[1]=fixColor(val[1]);
					}else {
						val[1]=[...val[1]];
					}
					if(val[2].length>4){
						val[2]=fixColor(val[2]);
					}else {
						val[2]=[...val[2]];
					}
					if(val[3].length>4){
						val[3]=fixColor(val[3]);
					}else {
						val[3]=[...val[3]];
					}
					valMap[pptBorderColorIdx]=val;
					val=`rgba(${val[0][0]},${val[0][1]},${val[0][2]}, ${val[0][3]>=0?val[0][3]:1}) rgba(${val[1][0]},${val[1][1]},${val[1][2]}, ${val[1][3]>=0?val[1][3]:1}) rgba(${val[2][0]},${val[2][1]},${val[2][2]}, ${val[2][3]>=0?val[2][3]:1}) rgba(${val[3][0]},${val[3][1]},${val[3][2]}, ${val[3][3]>=0?val[3][3]:1})`;
				}
			}else {
				valMap[pptBorderColorIdx]=val;
			}
			valMap[pptStyleObjIdx].borderColor=val;
		};
		let get_=function(valMap){
			return valMap[pptBorderColorIdx];
		};
		typeDef.definePpt("borderColor",get_,set_,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt borderStyle:
	{
		setBorderStyle=function(valMap,val){
			valMap[pptBorderStyleIdx]=val;
			function v2s(v){
				switch(v){
					case 0:
					case false:
						return "none";
					case 1:
					case undefined:
						return "solid";
					case 2:
						return "dashed";
					case 3:
						return "dotted";
				}
				return v;
			}
			if(Array.isArray(val)){
				val=`${v2s(val[0])} ${v2s(val[1])} ${v2s(val[2])} ${v2s(val[3])}`;
			}else {
				val=v2s(val);
			}
			valMap[pptStyleObjIdx].borderStyle=val;
		};
		getBorderStyle=function(valMap){
			return valMap[pptBorderStyleIdx];
		};
		typeDef.definePpt("borderStyle",getBorderStyle,setBorderStyle,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt shadow-related:
	{
		let pptWillApplyIdx=typeDef.allocPptIdx("willApplyShadow",0);
		applyShadow=function(valMap){
			function _apply(){
				let onOff,inset,x,y,blur,spread,color,code;
				let styleObj;
				styleObj=valMap[pptStyleObjIdx];
				valMap[pptWillApplyIdx]=0;
				onOff=valMap[pptShadowIdx];
				if(!onOff){
					styleObj.boxShadow="none";
					return;
				}
				inset=valMap[pptShadowInsetIdx];
				x=valMap[pptShadowXIdx];
				y=valMap[pptShadowYIdx];
				blur=valMap[pptShadowBlurIdx];
				spread=valMap[pptShadowSpreadIdx];
				color=valMap[pptShadowColorIdx];
				if(Array.isArray(color)){
					color=`rgba(${color[0]||0},${color[1]||0},${color[2]||0},${color[3]>=0?color[3]:1})`;
				}
				code=`${x}px ${y}px ${blur}px ${spread}px ${color}`;
				if(inset){
					code="inset "+code;
				}
				styleObj.boxShadow=code;
			}
			if(valMap[pptWillApplyIdx]){
				return;
			}
			valMap[pptWillApplyIdx]=1;
			callAfter$1(_apply,0,valMap);
		};
		
		//ppt shadow:
		setShadow=function(valMap,val){
			val=!!val;
			valMap[pptShadowIdx]=val;
			applyShadow(valMap);
		};
		getShadow=function(valMap){
			return valMap[pptShadowIdx];
		};
		typeDef.definePpt("shadow",getShadow,setShadow,true);
		
		//ppt shadowX:
		setShadowX=function(valMap,val){
			valMap[pptShadowXIdx]=val;
			applyShadow(valMap);
		};
		getShadowX=function(valMap){
			return valMap[pptShadowXIdx];
		};
		typeDef.definePpt("shadowX",getShadowX,setShadowX,true);
		
		//ppt shadowY:
		setShadowY=function(valMap,val){
			valMap[pptShadowYIdx]=val;
			applyShadow(valMap);
		};
		getShadowY=function(valMap){
			return valMap[pptShadowYIdx];
		};
		typeDef.definePpt("shadowY",getShadowY,setShadowY,true);
		
		//ppt shadowBlur:
		setShadowBlur=function(valMap,val){
			valMap[pptShadowBlurIdx]=val;
			applyShadow(valMap);
		};
		getShadowBlur=function(valMap){
			return valMap[pptShadowBlurIdx];
		};
		typeDef.definePpt("shadowBlur",getShadowBlur,setShadowBlur,true);
		
		//ppt shadowSpread:
		setShadowSpread=function(valMap,val){
			valMap[pptShadowSpreadIdx]=val;
			applyShadow(valMap);
		};
		getShadowSpread=function(valMap){
			return valMap[pptShadowSpreadIdx];
		};
		typeDef.definePpt("shadowSpread",getShadowSpread,setShadowSpread,true);
		
		//ppt shadowColor:
		setShadowColor=function(valMap,val){
			valMap[pptShadowColorIdx]=val;
			applyShadow(valMap);
		};
		getShadowColor=function(valMap){
			return valMap[pptShadowColorIdx];
		};
		typeDef.definePpt("shadowColor",getShadowColor,setShadowColor,true);
		
		//ppt shadowSpread:
		setShadowInset=function(valMap,val){
			valMap[pptShadowInsetIdx]=val;
			applyShadow(valMap);
		};
		getShadowInset=function(valMap){
			return valMap[pptShadowInsetIdx];
		};
		typeDef.definePpt("shadowInset",getShadowInset,setShadowInset,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt maskImage
	{
		setMaskImage=function(valMap,val){
			let styleObj;
			styleObj=valMap[pptStyleObjIdx];
			valMap[pptMaskImageIdx]=val;
			if(val){
				styleObj.maskImage=`url(${val})`;
				styleObj.webkitMaskImage=`url(${val})`;
				styleObj.webkitMaskSize = "100% 100%";
			}else {
				styleObj.maskImage="";
				styleObj.webkitMaskImage="";
			}
		};
		getMaskImage=function(valMap){
			return valMap[pptMaskImageIdx];
		};
		typeDef.definePpt("maskImage",getMaskImage,setMaskImage,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt clientWidth, clientHeight:
	{
		let pptWIdx=typeDef.getPptIdx("w");
		let pptHIdx=typeDef.getPptIdx("h");
		//------------------------------------------------------------------------
		let getClientW=function(valMap){
			let w;
			let webObj,borderSize;
			webObj=valMap[pptWebObjIdx];
			if(webObj.offsetParent){
				return webObj.clientWidth;
			}
			w=valMap[pptWIdx];
			borderSize=valMap[pptBorderIdx];
			if(borderSize>=0 || borderSize<0){
				w-=borderSize*2;
			}else if(Array.isArray(borderSize)){
				w-=(borderSize[3]||0)+(borderSize[1]||0);
			}
			return w>=0?w:0;
		};
		funcGetMap.set("clientW",getClientW);
		funcGetMap.set("clientWidth",getClientW);
		
		//------------------------------------------------------------------------
		let getClientH=function(valMap){
			let h;
			let webObj,borderSize;
			webObj=valMap[pptWebObjIdx];
			if(webObj.offsetParent){
				return webObj.clientHeight;
			}
			h=valMap[pptHIdx];
			borderSize=valMap[pptBorderIdx];
			if(borderSize>=0 || borderSize<0){
				h-=borderSize*2;
			}else if(Array.isArray(borderSize)){
				h-=(borderSize[0]||0)+(borderSize[2]||0);
			}
			return h>=0?h:0;
		};
		funcGetMap.set("clientH",getClientH);
		funcGetMap.set("clientHeight",getClientH);
	}
	
}
VFACTObj.setupBox=setupBox;

//****************************************************************************
//:Text properties:
//****************************************************************************
function setupText(typeDef){
	//text, color, align, wrap, text-shadow, etc...
	let funcGetMap=typeDef.getMap;
	let funcSetMap=typeDef.setMap;
	
	let pptTextDivIdx=typeDef.allocPptIdx("textDiv",null);
	
	let pptTextIdx=typeDef.allocPptIdx("text","");
	let pptColorIdx=typeDef.allocPptIdx("color",[0,0,0,1]);
	let pptAlignXIdx=typeDef.allocPptIdx("alignX");
	let pptAlignYIdx=typeDef.allocPptIdx("alignY");
	let pptWrapIdx=typeDef.allocPptIdx("wrap",false);
	let pptEllipsisIdx=typeDef.allocPptIdx("ellipsis",false);
	let pptFontIdx=typeDef.allocPptIdx("font");
	let pptFontSizeIdx=typeDef.allocPptIdx("fontSize");
	let pptWeightIdx=typeDef.allocPptIdx("weight");
	let pptSelectIdx=typeDef.allocPptIdx("selectable",false);
	let pptShadowIdx=typeDef.allocPptIdx("textShadow",false);
	let pptShadowXIdx=typeDef.allocPptIdx("textShadowX",1);
	let pptShadowYIdx=typeDef.allocPptIdx("textShadowY",1);
	let pptShadowBlurIdx=typeDef.allocPptIdx("textShadowBlur",2);
	let pptShadowColorIdx=typeDef.allocPptIdx("textShadowColor",[0,0,0,0.5]);
	let pptSizeCacheIdx=typeDef.allocPptIdx("sizeCache",null);
	
	let applyShadow;
	let setShadow,getShadow;
	let setShadowX,getShadowX;
	let setShadowY,getShadowY;
	let setShadowColor,getShadowColor;
	let setShadowBlur,getShadowBlur;
	
	Object.assign(typeDef.initStyle,{
		wordBreak:"keep-all",
		whiteSpace:"nowrap",
		userSelect:"none",
		webkitUserSelect:"none",
		webkitTouchCallout:"none",
	});
	
	typeDef.defaultPpts[pptDisplayCodeIdx]="flex";
	typeDef.createElement=function(def,pptList){
		let box,txtDiv;
		box=document.createElement("div");
		txtDiv=document.createElement("div");
		txtDiv.style.pointerEvents="none";
		box.appendChild(txtDiv);
		pptList[pptTextDivIdx]=txtDiv;
		return box;
	};
	
	//--------------------------------------------------------------------------
	//ppt text:
	{
		let _set=function(valMap,val){
			let txtDiv=valMap[pptTextDivIdx];
			valMap[pptTextIdx]=""+val;
			txtDiv.innerHTML=escapeHTML(""+val);
			valMap[pptSizeCacheIdx]=null;
		};
		let _get=function(valMap){
			return unescapeHTML(valMap[pptTextIdx]);
		};
		typeDef.definePpt("text",_get,_set,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt color:
	{
		let setColor=function(valMap,val){
			if(Array.isArray(val)){
				if(val.length>4){
					val=fixColor(val);
				}else {
					val=[...val];
				}
				valMap[pptColorIdx]=val;
				val=`rgba(${val[0]||0},${val[1]||0},${val[2]||0})`;
			}else {
				valMap[pptColorIdx]=val;
			}
			valMap[pptStyleObjIdx].color=val;
		};
		let getColor=function(valMap){
			return valMap[pptColorIdx];
		};
		typeDef.definePpt("color",getColor,setColor,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt font:
	{
		let setFont=function(valMap,val){
			valMap[pptFontIdx]=val;
			valMap[pptStyleObjIdx].fontFamily=val;
			valMap[pptSizeCacheIdx]=null;
		};
		let getFont=function(valMap){
			return valMap[pptFontIdx];
		};
		typeDef.definePpt("font",getFont,setFont,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt fontSize:
	{
		let setFontSize=function(valMap,val){
			valMap[pptFontSizeIdx]=val;
			if(val>0){
				val=val+"px";
			}
			valMap[pptStyleObjIdx].fontSize=val;
			valMap[pptSizeCacheIdx]=null;
		};
		let getFontSize=function(valMap){
			return valMap[pptFontSizeIdx];
		};
		typeDef.definePpt("fontSize",getFontSize,setFontSize,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt alignX:
	{
		let setVal=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptAlignXIdx]=val;
			switch(val){
				case 0:
				case "left":
				default:
					styleObj.textAlign="start";
					styleObj.justifyContent="flex-start";
					break;
				case 1:
				case "center":
					styleObj.textAlign="center";
					styleObj.justifyContent="center";
					break;
				case 2:
				case "right":
					styleObj.textAlign="end";
					styleObj.justifyContent="flex-end";
					break;
			}
		};
		let getVal=function(valMap){
			return valMap[pptAlignXIdx];
		};
		typeDef.definePpt("alignX",getVal,setVal,true);
		funcGetMap.set("alignH",funcGetMap.get("alignX"));
		funcSetMap.set("alignH",funcSetMap.get("alignX"));
	}
	
	//--------------------------------------------------------------------------
	//ppt alignY:
	{
		let setVal=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptAlignYIdx]=val;
			switch(val){
				case 0:
				case "top":
				default:
					styleObj.alignItems="start";
					break;
				case 1:
				case "center":
					styleObj.alignItems="center";
					break;
				case 2:
				case "bottom":
					styleObj.alignItems="end";
					break;
			}
		};
		let getVal=function(valMap){
			return valMap[pptAlignYIdx];
		};
		typeDef.definePpt("alignY",getVal,setVal,true);
		funcGetMap.set("alignV",funcGetMap.get("alignY"));
		funcSetMap.set("alignV",funcSetMap.get("alignY"));
	}
	
	//--------------------------------------------------------------------------
	//ppt autoW
	{
		let pptWIdx=typeDef.getPptIdx("w");
		let funcSetW=funcSetMap.get("w");
		let setVal=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			val=!!val;
			if(val){
				styleObj.width="";
			}else {
				funcSetW(valMap,valMap[pptWIdx]);
			}
		};
		let getVal=function(valMap){
			let styleObj=valMap[pptStyleObjIdx];
			let w=styleObj.width;
			return w==="" || w===undefined || w==="auto";
		};
		typeDef.definePpt("autoWidth",getVal,setVal,true);
		funcGetMap.set("autoW",funcGetMap.get("autoWidth"));
		funcSetMap.set("autoW",funcSetMap.get("autoWidth"));
	}
	
	//--------------------------------------------------------------------------
	//ppt autoH
	{
		let pptHIdx=typeDef.getPptIdx("h");
		let funcSetH=funcSetMap.get("h");
		let setVal=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			val=!!val;
			if(val){
				styleObj.height="";
			}else {
				funcSetH(valMap,valMap[pptHIdx]);
			}
		};
		let getVal=function(valMap){
			let styleObj=valMap[pptStyleObjIdx];
			let h=styleObj.height;
			return h==="" || h===undefined;
		};
		typeDef.definePpt("autoHeight",getVal,setVal,true);
		funcGetMap.set("autoH",funcGetMap.get("autoHeight"));
		funcSetMap.set("autoH",funcSetMap.get("autoHeight"));
	}

	//--------------------------------------------------------------------------
	//ppt fontWeight:
	{
		let setVal=function(valMap,val){
			valMap[pptWeightIdx]=val;
			valMap[pptStyleObjIdx].fontWeight=val;
			valMap[pptSizeCacheIdx]=null;
		};
		let getVal=function(valMap){
			return valMap[pptWeightIdx];
		};
		typeDef.definePpt("fontWeight",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt fontStyle:
	{
		let setVal=function(valMap,val){
			valMap[pptStyleObjIdx].fontStyle=val;
		};
		let getVal=function(valMap){
			return valMap[pptStyleObjIdx].fontStyle;
		};
		typeDef.definePpt("fontStyle",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt textDecoration:
	{
		let setVal=function(valMap,val){
			valMap[pptStyleObjIdx].textDecoration=val;
		};
		let getVal=function(valMap){
			return valMap[pptStyleObjIdx].textDecoration;
		};
		typeDef.definePpt("textDecoration",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt selectable:
	{
		let setVal=function(valMap,val){
			let styleObj=valMap[pptStyleObjIdx];
			valMap[pptSelectIdx]=val;
			styleObj.userSelect=val?"text":"none";
			styleObj.webkitUserSelect=val?"text":"none";
			styleObj.webkitTouchCallout=val?"text":"none";
		};
		let getVal=function(valMap){
			return valMap[pptSelectIdx];
		};
		typeDef.definePpt("selectable",getVal,setVal,true);
		typeDef.definePpt("select",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt wrap:
	{
		let setVal=function(valMap,val){
			let txtStyle;
			let styleObj=valMap[pptStyleObjIdx];
			txtStyle=valMap[pptTextDivIdx].style;
			valMap[pptWrapIdx]=!!val;
			if(val){
				valMap[pptEllipsisIdx]=false;
				styleObj.whiteSpace="";
				styleObj.wordBreak="break-word";
				txtStyle.textOverflow= "";
			}else {
				styleObj.whiteSpace="nowrap";
				styleObj.wordBreak="keep-all";
			}
			valMap[pptSizeCacheIdx]=null;
		};
		let getVal=function(valMap){
			return valMap[pptWrapIdx];
		};
		typeDef.definePpt("wrap",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt ellipsis:
	{
		let setVal=function(valMap,val){
			let txtStyle;
			let styleObj=valMap[pptStyleObjIdx];
			txtStyle=valMap[pptTextDivIdx].style;
			valMap[pptEllipsisIdx]=!!val;
			if(val){
				valMap[pptWrapIdx]=false;
				styleObj.whiteSpace="nowrap";
				styleObj.wordBreak="keep-all";
				txtStyle.minWidth="0px";
				txtStyle.overflow="hidden";
				txtStyle.textOverflow="ellipsis";
			}else {
				txtStyle.textOverflow= "";
				txtStyle.minWidth="";
				txtStyle.overflow="";
			}
			valMap[pptSizeCacheIdx]=null;
		};
		let getVal=function(valMap){
			return valMap[pptEllipsisIdx];
		};
		typeDef.definePpt("ellipsis",getVal,setVal,true);
	}
	
	//--------------------------------------------------------------------------
	//ppt shadow-related:
	{
		let willApply=0;
		applyShadow=function(valMap){
			let styleObj=valMap[pptStyleObjIdx];
			function _apply(){
				let onOff,x,y,blur,color,code;
				willApply=0;
				onOff=valMap[pptShadowIdx];
				if(!onOff){
					styleObj.textShadow="none";
					return;
				}
				x=valMap[pptShadowXIdx];
				y=valMap[pptShadowYIdx];
				blur=valMap[pptShadowBlurIdx];
				color=valMap[pptShadowColorIdx];
				if(Array.isArray(color)){
					color=`rgba(${color[0]||0},${color[1]||0},${color[2]||0},${color[3]>=0?color[3]:1})`;
				}
				code=`${color} ${x}px ${y}px ${blur}px`;
				styleObj.textShadow=code;
			}
			if(willApply){
				return;
			}
			willApply=1;
			callAfter$1(_apply,0,valMap);
		};
		
		//ppt shadow:
		setShadow=function(valMap,val){
			val=!!val;
			valMap[pptShadowIdx]=val;
			applyShadow(valMap);
		};
		getShadow=function(valMap){
			return valMap[pptShadowIdx];
		};
		typeDef.definePpt("textShadow",getShadow,setShadow,true);
		if(!typeDef.hasPpt("shadow")){
			typeDef.aliasPpt("textShadow","shadow");
		}
		
		//ppt shadowX:
		setShadowX=function(valMap,val){
			valMap[pptShadowXIdx]=val;
			applyShadow(valMap);
		};
		getShadowX=function(valMap){
			return valMap[pptShadowXIdx];
		};
		typeDef.definePpt("textShadowX",getShadowX,setShadowX,true);
		if(!typeDef.hasPpt("shadowX")){
			typeDef.aliasPpt("textShadowX","shadowX");
		}
		
		//ppt shadowY:
		setShadowY=function(valMap,val){
			valMap[pptShadowYIdx]=val;
			applyShadow(valMap);
		};
		getShadowY=function(valMap){
			return valMap[pptShadowYIdx];
		};
		typeDef.definePpt("textShadowY",getShadowY,setShadowY,true);
		if(!typeDef.hasPpt("shadowY")){
			typeDef.aliasPpt("textShadowY","shadowY");
		}
		
		//ppt shadowBlur:
		setShadowBlur=function(valMap,val){
			valMap[pptShadowBlurIdx]=val;
			applyShadow(valMap);
		};
		getShadowBlur=function(valMap){
			return valMap[pptShadowBlurIdx];
		};
		typeDef.definePpt("textShadowBlur",getShadowBlur,setShadowBlur,true);
		if(!typeDef.hasPpt("shadowBlur")){
			typeDef.aliasPpt("textShadowBlur","shadowBlur");
		}
		
		//ppt shadowColor:
		setShadowColor=function(valMap,val){
			valMap[pptShadowColorIdx]=val;
			applyShadow(valMap);
		};
		getShadowColor=function(valMap){
			return valMap[pptShadowColorIdx];
		};
		typeDef.definePpt("textShadowColor",getShadowColor,setShadowColor,true);
		if(!typeDef.hasPpt("shadowColor")){
			typeDef.aliasPpt("textShadowColor","shadowColor");
		}
	}
	
	//--------------------------------------------------------------------------
	//ppt textW,textH
	{
		let getTextW=function(valMap){
			let webObj,w,h;
			let txtDiv;
			let cachedSize;
			cachedSize=valMap[pptSizeCacheIdx];
			if(cachedSize){
				return cachedSize[0];
			}
			webObj=valMap[pptWebObjIdx];
			txtDiv = valMap[pptTextDivIdx];
			if(webObj.offsetParent) {
				w = txtDiv.scrollWidth;
				h = txtDiv.scrollHeight;
				valMap[pptSizeCacheIdx]=[w,h];
				return w>=0?w:0;
			}
			cachedSize=valMap[pptSizeCacheIdx]=getTextSize(valMap[pptTextIdx],txtDiv);
			return cachedSize[0];
		};
		funcGetMap.set("textW",getTextW);
		funcGetMap.set("textWidth",getTextW);
		
		let getTextH=function(valMap){
			let webObj,w,h;
			let txtDiv;
			let cachedSize;
			cachedSize=valMap[pptSizeCacheIdx];
			if(cachedSize){
				return cachedSize[0];
			}
			webObj=valMap[pptWebObjIdx];
			txtDiv = valMap[pptTextDivIdx];
			if(webObj.offsetParent) {
				w = txtDiv.scrollWidth;
				h = txtDiv.scrollHeight;
				valMap[pptSizeCacheIdx]=[w,h];
				return h>=0?h:0;
			}
			cachedSize=valMap[pptSizeCacheIdx]=getTextSize(valMap[pptTextIdx],txtDiv);
			return cachedSize[1];
		};
		funcGetMap.set("textH",getTextH);
		funcGetMap.set("textHeight",getTextH);
	}
	
	//--------------------------------------------------------------------------
	//isEllipsised()
	typeDef.defineFunction("isEllipsised",function(){
		let valMap=this;
		let txtDiv;
		if(valMap[pptEllipsisIdx]) {
			txtDiv = valMap[pptTextDivIdx];
			return txtDiv.scrollWidth>txtDiv.offsetWidth;
		}
		return false;
	});
}
VFACTObj.setupText=setupText;

//****************************************************************************
//:Image properties:
//****************************************************************************
function setupImage(typeDef,pathFix){
	let getMap,setMap;
	getMap=typeDef.getMap;
	setMap=typeDef.setMap;
	
	let pptImageIdx=typeDef.allocPptIdx("imageReady",false);
	let pptImageObjIdx=typeDef.allocPptIdx("imageObj",false);
	let pptImageReadyIdx=typeDef.allocPptIdx("image","");
	let pptImageWIdx=typeDef.defineIdxOnlyPpt("imageW",false);
	let pptImageHIdx=typeDef.defineIdxOnlyPpt("imageH",false);
	let pptAutoSizeIdx=typeDef.allocPptIdx("autoSize",false);
	let pptFitSizeIdx=typeDef.allocPptIdx("fitSize",false);
	let pptAlignXIdx=typeDef.allocPptIdx("alignX",1);
	let pptAlignYIdx=typeDef.allocPptIdx("alignY",1);
	let pptRepeatIdx=typeDef.allocPptIdx("repeat",0);
	let pptImageOffsetIdx=typeDef.allocPptIdx("imageOffset",0);
	let pptImageScaleXIdx=typeDef.allocPptIdx("imageScaleX",1);
	let pptImageScaleYIdx=typeDef.allocPptIdx("imageScaleY",1);
	//ppt for 3x3
	let pptImage3x3Idx=typeDef.allocPptIdx("image3x3",null);
	let pptImage3x3WidthIdx=typeDef.allocPptIdx("image3x3Width",null);
	
	let _setW=setMap.get("w");
	let _setH=setMap.get("h");
	
	let applyImagePos;
	let applyImageSize;
	let applyBorderImage;
	
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(pxy,def,webObj,styleObj,valMap){
		let imageObj;
		if(oldPrefix){
			def=oldPrefix.call(typeDef,pxy,def,webObj,styleObj,valMap);
		}
		imageObj=valMap[pptImageObjIdx]=new Image();
		imageObj.crossOrigin="anonymous";
		imageObj.onload=function(){
			let img3x3,img3x3Width;
			styleObj=valMap[pptStyleObjIdx];
			if(!styleObj){
				return;
			}
			valMap[pptImageReadyIdx]=1;
			valMap[pptImageWIdx]=imageObj.width;
			valMap[pptImageHIdx]=imageObj.height;
			img3x3=valMap[pptImage3x3Idx];
			img3x3Width=valMap[pptImage3x3WidthIdx]||img3x3;
			if(img3x3){
				styleObj.backgroundImage="";
				styleObj.borderImageSource="url(" + imageObj.src + ")";
				styleObj.borderImageSlice=img3x3[0]+" "+img3x3[1]+" "+img3x3[2]+" "+img3x3[3]+" fill";
				styleObj.borderImageWidth=img3x3Width[0]+"px "+img3x3Width[1]+"px "+img3x3Width[2]+"px "+img3x3Width[3]+"px";
				styleObj.borderImageRepeat="stretch";
			}else {
				styleObj.borderImageSource="";
				styleObj.backgroundImage = "url(" + imageObj.src + ")";
				applyImageSize(valMap);
			}
			if(pxy.OnLoad){
				pxy.OnLoad();
			}
		};
		imageObj.onerror=function(){
			valMap[pptImageReadyIdx]=0;
			valMap[pptImageWIdx]=0;
			valMap[pptImageHIdx]=0;
			styleObj.borderImageSource="";
			styleObj.backgroundImage="";
			if(pxy.OnError){
				pxy.OnError();
			}
		};
		return def;
	};
	
	//------------------------------------------------------------------------
	applyImageSize=function(valMap){
		let imgScaleX,imgScaleY,fitSize;
		let styleObj=valMap[pptStyleObjIdx];
		imgScaleX=valMap[pptImageScaleXIdx];
		imgScaleY=valMap[pptImageScaleYIdx];
		fitSize=valMap[pptFitSizeIdx];
		if(fitSize){
			valMap[pptAutoSizeIdx]=false;
			styleObj.backgroundSize=`${100*imgScaleX}% ${100*imgScaleY}%`;
		}else {
			if(valMap[pptImageReadyIdx]){
				styleObj.backgroundSize=`${valMap[pptImageWIdx]*imgScaleX}px ${valMap[pptImageWIdx]*imgScaleY}px`;
			}
		}
	};

	//------------------------------------------------------------------------
	applyBorderImage=function(valMap){
		let styleObj=valMap[pptStyleObjIdx];
		if(!styleObj){
			return;
		}
		let imageObj=valMap[pptImageObjIdx];
		if(imageObj && imageObj.width>0){
			let img3x3=valMap[pptImage3x3Idx];
			if(img3x3){
				let img3x3Width=valMap[pptImage3x3WidthIdx]||img3x3;
				styleObj.backgroundImage="";
				styleObj.borderImageSource="url(" + imageObj.src + ")";
				styleObj.borderImageSlice=img3x3[0]+" "+img3x3[1]+" "+img3x3[2]+" "+img3x3[3]+" fill";
				styleObj.borderImageWidth=img3x3Width[0]+"px "+img3x3Width[1]+"px "+img3x3Width[2]+"px "+img3x3Width[3]+"px";
			}else {
				styleObj.borderImageSource="";
				styleObj.backgroundImage = "url(" + imageObj.src + ")";
				applyImageSize(valMap);
			}
		}
	};
	
	applyImagePos=function(valMap){
		let posText,alignX,alignY,pos,posX,posY;
		let styleObj=valMap[pptStyleObjIdx];
		alignX=valMap[pptAlignXIdx];
		alignY=valMap[pptAlignYIdx];
		pos=valMap[pptImageOffsetIdx];
		switch(alignX){
			case 0:case 1:case 2:
				break;
			default:
				alignX=1;
				break;
			case "left":
				alignX=0;
				break;
			case "center":
				alignX=1;
				break;
			case "right":
				alignX=2;
				break;
		}
		switch(alignY){
			case 0:case 1:case 2:
				break;
			default:
				alignY=1;
				break;
			case "top":
				alignY=0;
				break;
			case "center":
				alignY=1;
				break;
			case "bottom":
				alignY=2;
				break;
		}
		if(pos>=0||pos<0){
			posX=posY=pos;
		}else if(Array.isArray(pos)){
			posX=pos[0];
			posY=pos[1];
		}else {
			posX=0;posY=0;
		}
		posText=(alignX===0?"left ":(alignX===2?"right ":"center "));
		if(alignX!==1) {
			posText += "" + posX + "px ";
		}
		posText+=(alignY===0?"top ":(alignY===2?"bottom ":"center "));
		if(alignY!==1) {
			posText += "" + posY + "px ";
		}
		styleObj.backgroundPosition=posText;
	};
	
	//************************************************************************
	//define ppts
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//ppt autoSize
		{
			let _set=function(valMap,val){
				val=!!val;
				valMap[pptAutoSizeIdx]=val;
				if(val){
					valMap[pptFitSizeIdx]=false;
					if(valMap[pptImageReadyIdx]){
						_setW(valMap[pptImageWIdx]);
						_setH(valMap[pptImageHIdx]);
					}
				}
			};
			let _get=function(valMap){
				return valMap[pptAutoSizeIdx];
			};
			typeDef.definePpt("autoSize",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt fitSize
		{
			let _set=function(valMap,val){
				val=!!val;
				valMap[pptFitSizeIdx]=val;
				applyImageSize(valMap);
			};
			let _get=function(valMap){
				return valMap[pptFitSizeIdx];
			};
			typeDef.definePpt("fitSize",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt alignX
		{
			let _set=function(valMap,val){
				valMap[pptAlignXIdx]=val;
				applyImagePos(valMap);
			};
			let _get=function(valMap){
				return valMap[pptAlignXIdx];
			};
			typeDef.definePpt("alignX",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt alignY
		{
			let _set=function(valMap,val){
				valMap[pptAlignYIdx]=val;
				applyImagePos(valMap);
			};
			let _get=function(valMap){
				return valMap[pptAlignYIdx];
			};
			typeDef.definePpt("alignY",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt repeat
		{
			let _set=function(valMap,val){
				let repeatX,repeatY;
				let styleObj=valMap[pptStyleObjIdx];
				valMap[pptRepeatIdx]=val;
				if(typeof(val)==="string"){
					styleObj.backgroundRepeat=val;
					return;
				}else if(Array.isArray(val)){
					repeatX=!!val[0];
					repeatY=!!val[1];
				}else {
					val=!!val;
					repeatX=repeatY=val;
				}
				styleObj.backgroundRepeat=(repeatX?"repeat ":"no-repeat ")+(repeatY?"repeat":"no-repeat");
			};
			let _get=function(valMap){
				return valMap[pptRepeatIdx];
			};
			typeDef.definePpt("repeat",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt imageOffset
		{
			let _set=function(valMap,val){
				valMap[pptImageOffsetIdx]=val;
				applyImagePos(valMap);
			};
			let _get=function(valMap){
				return valMap[pptImageOffsetIdx];
			};
			typeDef.definePpt("imageOffset",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt imageScale
		{
			let _set=function(valMap,val){
				let scaleX,scaleY;
				if(Array.isArray(val)){
					scaleX=val[0];
					scaleY=val[1];
				}else {
					scaleX=scaleY=val;
				}
				valMap[pptImageScaleXIdx]=scaleX;
				valMap[pptImageScaleYIdx]=scaleY;
				applyImageSize(valMap);
			};
			let _get=function(valMap){
				return valMap[pptRepeatIdx];
			};
			typeDef.definePpt("imageScale",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt image
		{
			let _set=function(valMap,val){
				let imgObj,curURL;
				imgObj=valMap[pptImageObjIdx];
				if(pathFix){
					val=pathFix(val);
				}
				curURL=valMap[pptImageIdx];
				if(curURL!==val){
					valMap[pptImageIdx]=val;
					valMap[pptImageReadyIdx]=0;
					imgObj.src=val;
				}
			};
			let _get=function(valMap){
				return valMap[pptImageIdx];
			};
			typeDef.definePpt("image",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt imageW,imageH
		{
			let getImageW=function(valMap){
				return valMap[pptImageWIdx];
			};
			getMap.set("imgW",getImageW);
			getMap.set("imageW",getImageW);
			getMap.set("imageWidth",getImageW);

			let getImageH=function(valMap){
				return valMap[pptImageHIdx];
			};
			getMap.set("imgH",getImageH);
			getMap.set("imageH",getImageH);
			getMap.set("imageHeight",getImageH);
		}

		//--------------------------------------------------------------------
		//ppt image3x3
		{
			let _set=function(valMap,val){
				if(Array.isArray(val)){
					valMap[pptImage3x3Idx]=val;
				}else {
					valMap[pptImage3x3Idx]=null;
				}
				applyBorderImage(valMap);
			};
			let _get=function(valMap){
				return valMap[pptImage3x3Idx];
			};
			typeDef.definePpt("image3x3",_get,_set,true);
		}
		
		//--------------------------------------------------------------------
		//ppt image3x3Width
		{
			let _set=function(valMap,val){
				if(Array.isArray(val)){
					valMap[pptImage3x3WidthIdx]=val;
				}else {
					valMap[pptImage3x3WidthIdx]=null;
				}
				applyBorderImage(valMap);
			};
			let _get=function(valMap){
				return valMap[pptImage3x3WidthIdx];
			};
			typeDef.definePpt("image3x3Width",_get,_set,true);
		}
	}
}
VFACTObj.setupImage=setupImage;

//****************************************************************************
//:Button:
//****************************************************************************
function setupButton(typeDef){
	
	const STATE_UP=0;
	const STATE_DOWN=1;
	const STATE_OVER=2;
	const STATE_GRAY=3;
	
	let pptIsLabelIdx=typeDef.allocPptIdx("isLabel",false);
	let pptLabelTgtIdx=typeDef.allocPptIdx("labelTgt",false);
	typeDef.allocPptIdx("labelDiv",null);
	let pptStateIdx=typeDef.allocPptIdx("state",STATE_UP);
	let pptEnableIdx=typeDef.allocPptIdx("enable",true);
	let pptIsPenDownIdx=typeDef.defineIdxOnlyPpt("isPenDown",false,false);
	let pptIsPenInIdx=typeDef.defineIdxOnlyPpt("isPenIn",0,false);
	let pptDragIdx=typeDef.defineIdxOnlyPpt("drag",0,false);
	let pptInDragIdx=typeDef.defineIdxOnlyPpt("inDrag",0,false);
	let pptOnDragStartIdx=typeDef.defineIdxOnlyPptCall("OnDragStart",null,false);
	let pptOnDragIdx=typeDef.defineIdxOnlyPptCall("OnDrag",null,false);
	let pptOnDragEndIdx=typeDef.defineIdxOnlyPptCall("OnDragEnd",null,false);
	let pptOnButtonDownIdx=typeDef.defineIdxOnlyPptCall("OnButtonDown",null,false);
	let pptOnButtonUpIdx=typeDef.defineIdxOnlyPptCall("OnButtonUp",null,false);
	let pptOnMouseUpOutIdx=typeDef.defineIdxOnlyPptCall("OnMouseUpOut",null,false);
	
	let pptOnClickIdx=typeDef.defineIdxOnlyPptCall("OnClick",null,false);
	
	let setState;
	
	let _OnMouseDown,_OnMouseEnter,_OnMouseLeave,_OnMouseUp,_OnMouseUpOut;
	typeDef.allocPptIdx("OnMouseDown");
	
	_OnMouseDown=function(valMap,evt){
		if(!valMap[pptEnableIdx]){
			return;
		}
		if(valMap[pptDragIdx]===2){
			valMap[pptIsPenDownIdx]=0;
			valMap[pptInDragIdx]=1;
			valMap[pptOnDragStartIdx] && valMap[pptOnDragStartIdx](evt);
			sysStartDrag(evt,{
				OnDrag:valMap[pptOnDragIdx],
				OnDone:(evt,dx,dy)=>{
					valMap[pptInDragIdx]=0;
					valMap[pptOnDragEndIdx] && valMap[pptOnDragEndIdx](evt,dx,dy);
				}
			});
			evt.stopPropagation();
		}else {
			let overcall;
			overcall=valMap[pptOnButtonDownIdx];
			if(overcall && overcall(1,evt)){
				return;
			}
			valMap[pptIsPenDownIdx]=1;
			setState(valMap,STATE_DOWN);
			sysAddOnMouseUp(valMap[pptOnMouseUpOutIdx]);
			evt.stopPropagation();
		}
	};
	
	_OnMouseEnter=function(valMap,evt){
		if(!valMap[pptEnableIdx]){
			return;
		}
		if(valMap[pptIsPenInIdx]){
			return;
		}
		valMap[pptIsPenInIdx]=1;
		if(valMap[pptIsPenDownIdx]){
			let overcall;
			overcall=valMap[pptOnButtonDownIdx];
			if(overcall){
				overcall(0,evt);
			}
			setState(valMap,STATE_DOWN);
			return;
		}
		setState(valMap,STATE_OVER);
	};
	
	_OnMouseLeave=function(valMap,evt){
		if(!valMap[pptEnableIdx]){
			return;
		}
		if(!valMap[pptIsPenInIdx]){
			return;
		}
		valMap[pptIsPenInIdx]=0;
		if(valMap[pptIsPenDownIdx]){
			//check if start drag:
			if(valMap[pptDragIdx]===1){
				valMap[pptIsPenDownIdx]=0;
				valMap[pptInDragIdx]=1;
				valMap[pptOnDragStartIdx] && valMap[pptOnDragStartIdx](evt);
				sysStartDrag(evt,{
					OnDrag:valMap[pptOnDragIdx],
					OnDone:(evt,dx,dy)=>{
						valMap[pptInDragIdx]=0;
						valMap[pptOnDragEndIdx] && valMap[pptOnDragEndIdx](evt);
					}
				});
				evt.stopPropagation();
				return;
			}
			let overcall;
			overcall=valMap[pptOnButtonUpIdx];
			if(overcall){
				overcall(0,evt);
			}
		}
		setState(valMap,STATE_UP);
	};
	
	_OnMouseUp=function(valMap,evt){
		if(!valMap[pptEnableIdx]){
			return;
		}
		if(!valMap[pptIsPenDownIdx]){
			return;
		}
		/*if(evt.target!==valMap[pptWebObjIdx]){
			return;
		}*/
		evt.stopPropagation();
		sysRemoveOnMouseUp(valMap[pptOnMouseUpOutIdx]);
		valMap[pptIsPenDownIdx]=0;
		let call,labelTgt;
		labelTgt=valMap[pptLabelTgtIdx];
		if(labelTgt){
			var newEvt;
			newEvt=new MouseEvent("click", {
				bubbles: true,cancelable: true,view: window
			});
			labelTgt.dispatchEvent(newEvt);
			return;
		}
		call=valMap[pptOnButtonUpIdx];
		if(call){
			if(call(1,evt)){
				setState(valMap,STATE_UP);
				return;
			}
		}
		call=valMap[pptOnClickIdx];
		if(call){
			let rst;
			vmcAddRefcount.call(valMap);
			rst=call(evt);
			if(valMap[pptEnableIdx]){
				if(rst===false){
					setState(valMap,STATE_OVER);
				}else {
					setState(valMap,STATE_UP);
					valMap[pptIsPenInIdx]=0;
				}
			}
			vmcRelease.call(valMap);
		}else {
			setState(valMap,STATE_UP);
			valMap[pptIsPenInIdx]=0;
		}
	};
	
	_OnMouseUpOut=function(valMap,evt){
		if(!valMap[pptEnableIdx]){
			return;
		}
		if(!valMap[pptIsPenDownIdx]){
			return;
		}
		valMap[pptIsPenDownIdx]=0;
		sysRemoveOnMouseUp(valMap[pptOnMouseUpOutIdx]);
		let call;
		call=valMap[pptOnButtonUpIdx];
		if(call){
			call(0,evt);
		}
		setState(valMap,STATE_UP);
	};
	
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(pxy,def,webObj,styleObj,valMap){
		if(oldPrefix){
			def=oldPrefix.call(typeDef,pxy,def,webObj,styleObj,valMap);
		}
		if(def.labelHtml){
			let div,labelTgt;
			//setup label-target:
			valMap[pptIsLabelIdx]=1;
			div=document.createElement('div');
			div.style.position="absolute";
			div.style.height="0px";
			div.style.opacity="0";
			div.style.overflow="hidden";
			div.innerHTML=def.labelHtml;
			labelTgt=div.firstChild;
			if(labelTgt){
				labelTgt.onchange=def.OnLabelAction||def.OnLableAction;
				valMap[pptLabelTgtIdx]=labelTgt;
			}
			webObj.appendChild(div);
			delete def.labelHtml;
		}
		//Install event handlers:
		webObj.addEventListener("mousedown",(evt)=>{
			_OnMouseDown(valMap,evt);
		},false);
		webObj.addEventListener("mouseenter",(evt)=>{
			_OnMouseEnter(valMap,evt);
		},false);
		webObj.addEventListener("mouseleave",(evt)=>{
			_OnMouseLeave(valMap,evt);
		},false);
		webObj.addEventListener("mouseup",(evt)=>{
			_OnMouseUp(valMap,evt);
		},true);
		valMap[pptOnMouseUpOutIdx]=(evt)=>{
			_OnMouseUpOut(valMap,evt);
		};
		return def;
	};
	let oldPost=typeDef.postCreate;
	typeDef.postCreate=function(pxy,def,webObj,styleObj,pptList){
		let state;
		if(oldPost){
			oldPost.call(typeDef,pxy,def,webObj,styleObj,pptList);
		}
		state=pptList[pptStateIdx];
		pptList[pptStateIdx]=null;
		setState(pptList,state);
	};
	
	//------------------------------------------------------------------------
	//ppt state:
	{
		let _set;
		_set=setState=function(valMap,val){
			let oldVal,faceCode;
			oldVal=valMap[pptStateIdx];
			if(oldVal===val){
				return;
			}
			switch(val){
				default:
				case STATE_UP:
					faceCode="up";
					break;
				case STATE_OVER:
					faceCode="over";
					break;
				case STATE_DOWN:
					faceCode="down";
					break;
				case STATE_GRAY:
					faceCode="gray";
					break;
			}
			valMap[pptStateIdx]=val;
			valMap[pptProxyIdx].showFace(faceCode);
		};
		let _get=function(valMap){
			return valMap[pptStateIdx];
		};
		typeDef.definePpt("state",_get,_set,false);
	}
	
	//------------------------------------------------------------------------
	//ppt enable:
	{
		let _set=function(valMap,val){
			let oldVal;
			oldVal=valMap[pptEnableIdx];
			val=!!val;
			valMap[pptEnableIdx]=val;
			if(val && !oldVal){
				setState(valMap,STATE_UP);
			}else if(!val && oldVal){
				setState(valMap,STATE_GRAY);
			}
		};
		let _get=function(valMap){
			return valMap[pptEnableIdx];
		};
		typeDef.definePpt("enable",_get,_set,true);
	}
}
VFACTObj.setupButton=setupButton;

//****************************************************************************
//:Edit:
//****************************************************************************
function setupEditCore(typeDef,isMemo){
	let getMap;
	
	getMap=typeDef.getMap;

	let pptColorIdx=typeDef.allocPptIdx("color",[0,0,0,1]);
	let pptFontIdx=typeDef.allocPptIdx("font","");
	let pptFontSizeIdx=typeDef.allocPptIdx("fontSize",16);
	let pptWeightIdx=typeDef.allocPptIdx("weight","");

	let pptAutoSelectIdx=typeDef.defineIdxOnlyPpt("autoSelect",true);
	
	let pptOnInputIdx=typeDef.defineIdxOnlyPptCall("OnInput",null,false);
	let pptOnChangeIdx=typeDef.defineIdxOnlyPptCall("OnChange",null,false);
	let pptOnUpdateIdx=typeDef.defineIdxOnlyPptCall("OnUpdate",null,false);
	let pptOnFocusIdx=typeDef.defineIdxOnlyPptCall("OnFocus",null,false);
	let pptOnBlurIdx=typeDef.defineIdxOnlyPptCall("OnBlur",null,false);
	let pptOnCancelIdx=typeDef.defineIdxOnlyPptCall("OnCancel",null,false);
	let pptOnKeyDownIdx=typeDef.defineIdxOnlyPptCall("OnKeyDown",null,false);
	let pptOnKeyUpIdx=typeDef.defineIdxOnlyPptCall("OnKeyUp",null,false);
	let pptOnPressKeyUpIdx=typeDef.defineIdxOnlyPptCall("OnPressKeyUp",null,false);
	let pptOnPressKeyDownIdx=typeDef.defineIdxOnlyPptCall("OnPressKeyDown",null,false);
	let pptOnNxtEditIdx=typeDef.defineIdxOnlyPptCall("OnNextEdit",null,false);
	let pptOnPreEditIdx=typeDef.defineIdxOnlyPptCall("OnPreviousEdit",null,false);

	let selectAll;
	
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(pxy,def,webObj,styleObj,valMap){
		let enterKeyTime=0;
		if(oldPrefix){
			def=oldPrefix.call(typeDef,pxy,def,webObj,styleObj,valMap);
		}
		//init event handlers:
		webObj.onfocus=function(evt){
			let call,autoSelect;
			autoSelect=valMap[pptAutoSelectIdx];
			if(autoSelect){
				selectAll.call(valMap);
			}
			call=valMap[pptOnFocusIdx];
			call && call(evt);
		};
		webObj.onblur=function(evt){
			let call;
			call=valMap[pptOnBlurIdx];
			call && call(evt);
		};
		webObj.oninput=function(evt){
			let call;
			call=valMap[pptOnInputIdx];
			call && call(evt);
		};
		webObj.onchange=function(e){
			let time;
			let call;
			call=valMap[pptOnChangeIdx];
			if(call){
				time=Date.now()-enterKeyTime;
				if(time<30) {
					call.OnChange(e);
				}
			}
		};
		if(isMemo){
			webObj.onkeydown=function(evt){
				let call;
				call=valMap[pptOnKeyDownIdx];
				if(call && call(evt)){
					evt.stopPropagation();
					evt.preventDefault();
					return;
				}
				if(evt.code==="Enter"){
					enterKeyTime=Date.now();
					call=valMap[pptOnUpdateIdx];
					call && call(evt);
				}else if(evt.code==="Escape"){
					call=valMap[pptOnCancelIdx];
					call && call(evt);
				}
			};
		}else {
			webObj.onkeydown=function(evt){
				let call;
				call=valMap[pptOnKeyDownIdx];
				if(call && call(evt)){
					evt.stopPropagation();
					evt.preventDefault();
					return;
				}
				if(evt.code==="Enter"){
					enterKeyTime=Date.now();
					call=valMap[pptOnUpdateIdx];
					call && call(evt);
				}else if(evt.code==="Escape"){
					call=valMap[pptOnCancelIdx];
					call && call(evt);
				}else if(evt.code==="ArrowUp"){
					call=valMap[pptOnPressKeyUpIdx];
					if(call && call(evt)){
						evt.stopPropagation();
						evt.preventDefault();
					}
				}else if(evt.code==="ArrowDown"){
					call=valMap[pptOnPressKeyDownIdx];
					if(call && call(evt)){
						evt.stopPropagation();
						evt.preventDefault();
					}
				}else if(evt.code==="Tab"){
					if(evt.shiftKey){
						call=valMap[pptOnPreEditIdx];
						if(call && call(evt)){
							evt.stopPropagation();
							evt.preventDefault();
						}
					}else {
						call=valMap[pptOnNxtEditIdx];
						if(call && call(evt)){
							evt.stopPropagation();
							evt.preventDefault();
						}
					}
				}
			};
		}
		webObj.onkeyup=function(evt){
			let call;
			call=valMap[pptOnKeyUpIdx];
			if(call && call(evt)){
				evt.stopPropagation();
				evt.preventDefault();
			}
		};
		return def;
	};
	
	//------------------------------------------------------------------------
	//ppt color:
	{
		let setColor=function(valMap,val){
			if(Array.isArray(val)){
				if(val.length>4){
					val=fixColor(val);
				}else {
					val=[...val];
				}
				valMap[pptColorIdx]=val;
				val=`rgba(${val[0]||0},${val[1]||0},${val[2]||0})`;
			}else {
				valMap[pptColorIdx]=val;
			}
			valMap[pptStyleObjIdx].color=val;
		};
		let getColor=function(valMap){
			return valMap[pptColorIdx];
		};
		typeDef.definePpt("color",getColor,setColor,true);
	}
	
	//------------------------------------------------------------------------
	//ppt font:
	{
		let setFont=function(valMap,val){
			valMap[pptFontIdx]=val;
			valMap[pptStyleObjIdx].fontFamily=val;
		};
		let getFont=function(valMap){
			return valMap[pptFontIdx];
		};
		typeDef.definePpt("font",getFont,setFont,true);
	}
	
	//------------------------------------------------------------------------
	//ppt fontSize:
	{
		let setFontSize=function(valMap,val){
			valMap[pptFontIdx]=val;
			if(val>0){
				val=val+"px";
			}
			valMap[pptStyleObjIdx].fontSize=val;
		};
		let getFontSize=function(valMap){
			return valMap[pptFontSizeIdx];
		};
		typeDef.definePpt("fontSize",getFontSize,setFontSize,true);
	}
	
	//------------------------------------------------------------------------
	//ppt fontWeight:
	{
		let setVal=function(valMap,val){
			valMap[pptWeightIdx]=val;
			valMap[pptStyleObjIdx].fontWeight=val;
		};
		let getVal=function(valMap){
			return valMap[pptWeightIdx];
		};
		typeDef.definePpt("fontWeight",getVal,setVal,true);
	}
	
	//------------------------------------------------------------------------
	//ppt fontStyle:
	{
		let setVal=function(valMap,val){
			valMap[pptStyleObjIdx].fontStyle=val;
		};
		let getVal=function(valMap){
			return valMap[pptStyleObjIdx].fontStyle;
		};
		typeDef.definePpt("fontStyle",getVal,setVal,true);
	}
	
	//------------------------------------------------------------------------
	//ppt textDecoration:
	{
		let setVal=function(valMap,val){
			valMap[pptStyleObjIdx].textDecoration=val;
		};
		let getVal=function(valMap){
			return valMap[pptStyleObjIdx].textDecoration;
		};
		typeDef.definePpt("textDecoration",getVal,setVal,true);
	}
	
	//------------------------------------------------------------------------
	//focus
	{
		let callIdx=typeDef.allocPptIdx("focus()",null);
		let _focus=function(valMap){
			let call=valMap[callIdx];
			if(!call){
				call=valMap[callIdx]=()=>{
					let autoSelect;
					valMap[pptWebObjIdx].focus();
					autoSelect=valMap[pptAutoSelectIdx];
					if(autoSelect){
						selectAll.call(valMap);
					}
				};
			}
			return call;
		};
		getMap.set("focus",_focus);
		getMap.set("startEdit",_focus);
	}
	
	//------------------------------------------------------------------------
	//blur
	{
		let callIdx=typeDef.allocPptIdx("blur()",null);
		let _call=function(valMap){
			let call=valMap[callIdx];
			if(!call){
				call=valMap[callIdx]=()=>{
					valMap[pptWebObjIdx].blur();
				};
			}
			return call;
		};
		getMap.set("blur",_call);
		getMap.set("endEdit",_call);
	}
	
	//------------------------------------------------------------------------
	//selectAll
	{
		selectAll=function(){
			let valMap=this;
			let webObj=valMap[pptWebObjIdx];
			if(isMemo){
				let myDiv = webObj;
				let range = document.createRange();
				range.selectNodeContents(myDiv);
				if(webObj.innerText){
					let selection = window.getSelection();
					selection.removeAllRanges();
					selection.addRange(range);			
				}
			}else {
				if(webObj.setSelectionRange){
					webObj.setSelectionRange(0,webObj.value.length);
				}else {
					let myDiv = webObj;
					let range = document.createRange();
					range.selectNodeContents(myDiv);
					let selection = window.getSelection();
					selection.removeAllRanges();
					selection.addRange(range);			
				}
			}
		};
		typeDef.defineFunction("selectAll",selectAll);
	}
}

function setupEdit(typeDef){
	
	typeDef.allocPptIdx("align",0);
	
	typeDef.createElement=function(def,pptMap){
		let obj;
		obj=document.createElement("input");
		obj.type=def.inputType||"text";
		return obj;
	};
	
	setupEditCore(typeDef,false);
	
	//------------------------------------------------------------------------
	//ppt inputType:
	{
		let setInputType=function(valMap,val){
			valMap[pptWebObjIdx].type = val;
		};
		let getInputType=function(valMap){
			return valMap[pptWebObjIdx].type;
		};
		typeDef.definePpt("inputType",getInputType,setInputType,true);
	}
	
	//------------------------------------------------------------------------
	//ppt pattern:
	{
		let setPattern=function(valMap,val){
			valMap[pptWebObjIdx].pattern = val;
		};
		let getPattern=function(valMap){
			return valMap[pptWebObjIdx].pattern;
		};
		typeDef.definePpt("pattern",getPattern,setPattern,true);
	}
	
	//------------------------------------------------------------------------
	//ppt text:
	{
		let setText=function(valMap,val){
			valMap[pptWebObjIdx].value = val;
		};
		let getText=function(valMap){
			return valMap[pptWebObjIdx].value;
		};
		typeDef.definePpt("text",getText,setText,true);
	}
	
	//------------------------------------------------------------------------
	//ppt placeholder:
	{
		let setPlaceHolder=function(valMap,val){
			valMap[pptWebObjIdx].placeholder = val;
		};
		let getPlaceHolder=function(valMap){
			return valMap[pptWebObjIdx].placeholder;
		};
		typeDef.definePpt("placeHolder",getPlaceHolder,setPlaceHolder,true);
	}

	//------------------------------------------------------------------------
	//ppt readOnly:
	{
		let setReadOnly=function(valMap,val){
			val=!!val;
			valMap[pptWebObjIdx].readOnly=val;
		};
		let getReadOnly=function(valMap){
			return !!(valMap[pptWebObjIdx].readOnly);
		};
		typeDef.definePpt("readOnly",getReadOnly,setReadOnly,true);
	}
	
	//------------------------------------------------------------------------
	//selectionStart
	{
		let getSelectionStart=function(valMap){
			return valMap[pptWebObjIdx].selectionStart;
		};
		let setSelectionStart=function(valMap,val){
			valMap[pptWebObjIdx].selectionStart=val;
		};
		typeDef.definePpt("selectionStart",getSelectionStart,setSelectionStart,true);
	}
	
	//------------------------------------------------------------------------
	//selectionEnd
	{
		let getSelectionEnd=function(valMap){
			return valMap[pptWebObjIdx].selectionEnd;
		};
		let setSelectionEnd=function(valMap,val){
			valMap[pptWebObjIdx].selectionEnd=val;
		};
		typeDef.definePpt("selectionEnd",getSelectionEnd,setSelectionEnd,true);
	}
	
	//------------------------------------------------------------------------
	//setSelectionRange
	{
		typeDef.defineFunction("setSelectionRange",function(p1,p2){
			let valMap=this;
			p1=p1||0;
			if(p2===undefined){
				p2=p1;
			}
			valMap[pptWebObjIdx].setSelectionRange(p1,p2);
		});
	}
}
VFACTObj.setupEdit=setupEdit;

function setupEditMemo(typeDef){

	
	typeDef.createElement=function(def,pptMap){
		let obj;
		obj=document.createElement("div");
		obj.contentEditable="true";
		obj.style.padding="5px";
		obj.style.overflow="auto";
		obj.style.cursor="text";
		return obj;
	};

	setupEditCore(typeDef,true);

	//------------------------------------------------------------------------
	//ppt text:
	{
		let setText=function(valMap,val){
			if(val){
				valMap[pptWebObjIdx].innerText = val;
			}else {
				valMap[pptWebObjIdx].innerHTML="";
			}
		};
		let getText=function(valMap){
			return valMap[pptWebObjIdx].innerText;
		};
		typeDef.definePpt("text",getText,setText,true);
	}

	//------------------------------------------------------------------------
	//ppt readOnly:
	let pptReadOnlyIdx=typeDef.allocPptIdx("readOnly",false);
	{
		let setReadOnly=function(valMap,val){
			valMap[pptReadOnlyIdx]=val;
			val=!!val;
			valMap[pptWebObjIdx].contentEditable=val?"false":"true";
		};
		let getReadOnly=function(valMap){
			return valMap[pptReadOnlyIdx];
		};
		typeDef.definePpt("readOnly",getReadOnly,setReadOnly,true);
	}
}VFACTObj.setupEditMemo=setupEditMemo;

//****************************************************************************
//:Docker:
//****************************************************************************
function setupDocker(typeDef){
	let getMap;
	getMap=typeDef.getMap;
	
	let pptUIListIdx=typeDef.allocPptIdx("uiList",null,false);
	let pptUIStackIdx=typeDef.allocPptIdx("uiStack",null,false);
	let pptCurUIIdx=typeDef.allocPptIdx("curUI",null,false);
	let pptCoverActionIdx=typeDef.defineIdxOnlyPpt("coverAction",1,false);
	
	let showUI;
	
	//--------------------------------------------------------------------
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(pxy,def,weObj,styleObj,valMap){
		if(oldPrefix){
			def=oldPrefix(pxy,def,weObj,styleObj,valMap);
		}
		valMap[pptUIStackIdx]=[];
		valMap[pptUIListIdx]=[];
		if(typeof(def.ui)==="object"){
			if(def.children){
				def.children.push(def.ui);
				def.ui=def.children.length-1;
			}else {
				def.children=[def.ui];
				def.ui=0;
			}
		}
		return def;
	};
	
	//--------------------------------------------------------------------
	let oldPostCreate=typeDef.postCreate;
	typeDef.postCreate=function(pxy,def,webObj,styleObj,valMap){
		let subUIs,list,i,n,node,subUI,uiIdx,ui;
		if(oldPostCreate){
			oldPostCreate.call(typeDef,pxy,def,webObj,styleObj,valMap);
		}
		//covert all children to subUI:
		subUIs=valMap[pptUIListIdx]=[];
		list=webObj.childNodes;
		n=list.length;
		for(i=0;i<n;i++){
			node=list[i];
			subUI=node.$_pxy;
			if(subUI){
				subUI.display=0;//Hide theUI
				subUIs.push(subUI);
			}
		}
		uiIdx=def.ui;
		if(uiIdx>=0){
			ui=subUIs[uiIdx];
			if(ui){
				showUI.call(valMap,ui,{});
			}
		}else if(typeof(uiIdx)==="string"){
			for(ui of subUIs){
				if(ui.id===uiIdx){
					showUI.call(valMap,ui,{});
					break;
				}
			}
		}
	};
	
	//--------------------------------------------------------------------
	//docker.showUI(ui,vo)
	{
		//----------------------------------------------------------------
		showUI=function(ui,vo){
			let valMap=this;
			let preUI,uiStack,idx,result,coverAction;
			let pxy=valMap[pptProxyIdx];
			if(ui>=0){
				let subUIs=valMap[pptUIListIdx];
				ui=subUIs[ui];
			}
			if(!ui){
				return null;
			}
			uiStack=valMap[pptUIStackIdx];
			preUI=valMap[pptCurUIIdx];
			coverAction=valMap[pptCoverActionIdx];
			if(preUI===ui){
				//same UI:
				let showUIFunc;
				showUIFunc=ui.showUI;
				if(showUIFunc){
					result=showUIFunc.call(ui,vo);
					if(result instanceof Promise){
						result.then(()=>{
							let callback;
							callback=pxy.OnUIShowed;
							callback&&callback(ui);
						});
					}else {
						let callback;
						callback=pxy.OnUIShowed;
						callback&&callback(ui);
					}
				}else {
					let callback;
					callback=pxy.OnUIShowed;
					callback&&callback(ui);
				}
				return ui;
			}
			valMap[pptCurUIIdx]=ui;
			idx=uiStack.indexOf(ui);
			if(idx>=0){
				uiStack.splice(idx,1);
			}
			uiStack.push(ui);
			ui.display=1;
			if(preUI){
				preUI.uiEvent=0;
				pxy.OnCoverUI&&pxy.OnCoverUI(preUI,ui);
				if(preUI.coverUI) {
					preUI.coverUI();
				}
			}
			ui.uiEvent=0;
			result =ui.showUI?ui.showUI(vo,preUI):null;
			pxy.OnShowUI&&pxy.OnShowUI(ui,preUI);
			if(result instanceof Promise){
				result.then(()=>{
					ui.uiEvent=1;
					if(preUI) {
						preUI.OnUICovered&&preUI.OnUICovered();
						pxy.OnUICovered&&pxy.OnUICovered(preUI);
						if(coverAction===0) {
							preUI.display=0;
						}else if(coverAction===1) {
							idx=uiStack.indexOf(preUI);
							if(idx>=0){
								uiStack.splice(idx,1);
							}
							pxy.removeChild(preUI);
						}else if(coverAction===2){
							preUI.display=0;
						}
					}
					pxy.OnUIShowed&&pxy.OnUIShowed(ui);
				});
			}else {
				ui.uiEvent=1;
				if(preUI) {
					preUI.OnUICovered&&preUI.OnUICovered();
					pxy.OnUICovered&&pxy.OnUICovered(preUI);
					if(coverAction===0) {
						preUI.display=0;
					}else if(coverAction===1) {
						idx=uiStack.indexOf(preUI);
						if(idx>=0){
							uiStack.splice(idx,1);
						}
						pxy.removeChild(preUI);
					}else if(coverAction===2){
						preUI.display=0;
					}
				}
				pxy.OnUIShowed&&pxy.OnUIShowed(ui);
			}
			return ui;
		};
		typeDef.defineFunction("showUI",showUI);
	}
	
	//--------------------------------------------------------------------
	//docker.showNewUI(uiDef,vo)
	{
		typeDef.defineFunction("showNewUI",function(uiDef,vo){
			let valMap=this;
			let ui;
			let pxy=valMap[pptProxyIdx];
			ui=pxy.appendNewChild(uiDef);
			if(!ui){
				return null;
			}
			let subUIs=valMap[pptUIListIdx];
			subUIs.push(ui);
			return showUI.call(valMap,ui,vo);
		});
	}
	
	//--------------------------------------------------------------------
	//docker.dismissUI(ui)
	{
		typeDef.defineFunction("dismissUI",async function(ui,remove){
			let valMap=this;
			let uiStack,idx,topUI,uncover;
			let pxy=valMap[pptProxyIdx];
			uncover=false;
			uiStack=valMap[pptUIStackIdx];
			topUI=uiStack[uiStack.length-1];
			if(!ui){
				ui=topUI;
				if(!ui){
					return;
				}
			}
			idx=uiStack.indexOf(ui);
			if(idx>=0){
				uiStack.splice(idx,1);
			}
			if(ui===topUI){
				topUI=uiStack[uiStack.length-1];
				if(topUI){
					topUI.display=1;
					topUI.uiEvent=1;
					uncover=true;
				}
				valMap[pptCurUIIdx]=topUI;
			}
			//call ui's dissmis or animate a bit?
			if(uncover && topUI){
				topUI.OnUncover&&topUI.OnUncover();
			}
			if(ui.OnDismiss){
				await ui.OnDismiss();
			}
			if(uncover && topUI){
				topUI.OnUncovered&&topUI.OnUncovered();
			}
			
			if(remove){
				pxy.removeChild(ui);
			}else {
				ui.uiEvent=0;
				ui.display=0;
			}
		});
	}
	
	//--------------------------------------------------------------------
	//ppt curUI:
	{
		let _get=function(valMap){
			return valMap[pptCurUIIdx];
		};
		getMap.set("curUI",_get);
	}
}
VFACTObj.setupDocker=setupDocker;

//****************************************************************************
//Drag and drop:
//****************************************************************************
{
	//------------------------------------------------------------------------
	VFACT.applyDrag=function(pxy,vo){
		let valMap;
		let webObj;
		valMap=pxy.$_pptMap;
		webObj=valMap[pptWebObjIdx];
		if(!vo){
			vo=webObj.$_dragVO;
			if(!vo){
				return;
			}
			if(vo.OnDragStart) {
				webObj.removeEventListener(vo.OnDragStart);
			}
			if(vo.OnDrag) {
				webObj.removeEventListener(vo.OnDrag);
			}
			if(vo.OnDragEnd) {
				webObj.removeEventListener(vo.OnDrag);
			}
			webObj.draggable="false";
			return;
		}
		vo={...vo};
		webObj.draggable="true";
		webObj.$_dragVO=vo;
		if(vo.OnDragStart){
			vo.OnDragStart=vo.OnDragStart.bind(pxy);
			webObj.addEventListener("dragstart",vo.OnDragStart);
		}
		if(vo.OnDrag){
			vo.OnDrag=vo.OnDrag.bind(pxy);
			webObj.addEventListener("drag",vo.OnDrag);
		}
		if(vo.OnDragEnd){
			vo.OnDragEnd=vo.OnDragEnd.bind(pxy);
			webObj.addEventListener("dragend",vo.OnDragEnd);
		}
	};
	
	//------------------------------------------------------------------------
	VFACT.applyDrop=function(pxy,vo){
		let valMap;
		let webObj;
		valMap=pxy.$_pptMap;
		webObj=valMap[pptWebObjIdx];
		if(!vo){
			vo=webObj.$_dropVO;
			if(!vo){
				return;
			}
			if(vo.OnDragEnter){
				webObj.removeEventListener("dragenter",vo.OnDragEnter);
			}
			if(vo.OnDragOver){
				webObj.removeEventListener("dragover",vo.OnDragOver);
			}
			if(vo.OnDragLeave){
				webObj.removeEventListener("dragleave",vo.OnDragLeave);
			}
			if(vo.OnDrop){
				webObj.removeEventListener("drop",vo.OnDrop);
			}
		}
		vo={...vo};
		if(vo.OnDragEnter){
			vo.OnDragEnter=vo.OnDragEnter.bind(pxy);
			webObj.addEventListener("dragenter",vo.OnDragEnter);
		}
		if(vo.OnDragOver){
			vo.OnDragOver=vo.OnDragOver.bind(pxy);
			webObj.addEventListener("dragover",vo.OnDragOver);
		}
		if(vo.OnDragLeave){
			vo.OnDragLeave=vo.OnDragLeave.bind(pxy);
			webObj.addEventListener("dragleave",vo.OnDragLeave);
		}
		if(vo.OnDrop){
			vo.OnDrop=vo.OnDrop.bind(pxy);
			webObj.addEventListener("drop",vo.OnDrop);
		}
	};
	
	//------------------------------------------------------------------------
	VFACT.applyMoveDrag=function(pxy,tgtPxy){
		let valMap;
		let webObj,startX,startY,orgX,orgY;

		function move(evt){
			let dx,dy;
			dx=evt.x-startX;
			dy=evt.y-startY;
			tgtPxy.x=orgX+dx;
			tgtPxy.y=orgY+dy;
			evt.preventDefault();
			evt.stopPropagation();
		}

		valMap=pxy.$_pptMap;
		webObj=valMap[pptWebObjIdx];
		//webObj.draggable="true";
		webObj.addEventListener("mousedown",(evt)=>{
			startX=evt.x;
			startY=evt.y;
			orgX=tgtPxy.x;
			orgY=tgtPxy.y;
			evt.preventDefault();
			evt.stopPropagation();

			document.body.addEventListener("mousemove",move,true);
			
			document.body.addEventListener("mouseup",(evt)=>{
				evt.preventDefault();
				evt.stopPropagation();
				document.body.removeEventListener("mousemove",move,true);
			},{once:true,capture:true});
		});
	};
}

//****************************************************************************
//Scroll to show item:
//****************************************************************************
{
	//------------------------------------------------------------------------
	VFACT.scrollToShow=function(item,scrollBox=null,opts=null){
		let rectItem,rectBox,d,gap,ani,dx=0,dy=0;
		opts=opts||{x:1,y:1};
		ani=!!opts.smooth;
		gap=opts.gap||0;
		scrollBox=scrollBox||item.parent;
		rectItem=item.getBoundingClientRect();
		rectBox=scrollBox.getBoundingClientRect();
		if(opts.x){
			if(rectItem.x<rectBox.x+gap){
				d=(rectItem.x-gap-rectBox.x);
			}
			if(rectItem.x+rectItem.width+gap>rectBox.x+rectBox.width){
				d=(rectItem.x+rectItem.width+gap-rectBox.x-rectBox.width);
			}
			dx=d||0;
			//scrollBox.webObj.scrollLeft+=d||0;
		}
		if(opts.y){
			if(rectItem.y<rectBox.y+gap){
				d=(rectItem.y-gap-rectBox.y);
			}
			if(rectItem.y+rectItem.height+gap>rectBox.y+rectBox.height){
				d=(rectItem.y+rectItem.height+gap-rectBox.y-rectBox.height);
			}
			dy=d||0;
			//scrollBox.webObj.scrollTop+=d||0;
		}
		if(dx||dy){
			scrollBox.webObj.scrollBy({top:dy,left:dx,behavior:ani?"smooth":"instant"});
		}
	};
}

//****************************************************************************
//Fonts
//****************************************************************************
{
	//------------------------------------------------------------------------
	VFACT.loadFont=async function(name,url,options){
		let fontFace,loadedFace;
		try{
			fontFace=new FontFace(name,url,options);
			loadedFace=await fontFace.load();
			document.fonts.add(loadedFace);
		}catch(err){
			console.error("Load font error:");
			console.error(err);
		}
	};
}

//****************************************************************************
//ShowList
//****************************************************************************
{
	//------------------------------------------------------------------------
	VFACT.dataList2View=function(view,list,defFunc,clear=true,watchFunc=null){
		let items,obj,css,i,n,item;
		items=[];
		if(clear){
			view.clearChildren();
		}
		n=list.length;
		for(i=0;i<n;i++){
			obj=list[i];
			css=defFunc(obj,i,view);
			if(css){
				css.position="relative";
				item=view.appendNewChild(css);
				if(watchFunc && watchFunc(item)===false){
					view.removeChild(item);
				}else {
					items.push(item);
				}
			}
		}
		return items;
	};
}

//----------------------------------------------------------------------------
//Tree-Node
let setupTreeNode=function(typeDef){
	let getMap;
	getMap=typeDef.getMap;
	
	typeDef.defineIdxOnlyPpt("ownerNode",null,false);
	let pptHudIdx=typeDef.allocPptIdx("hud",null);
	typeDef.defineIdxOnlyPpt("nodeObj",null,false);
	typeDef.defineIdxOnlyPpt("isOpen",false,false);
	typeDef.defineIdxOnlyPpt("indentW",0,false);
	typeDef.defineIdxOnlyPpt("indent",0,false);
	
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(obj,def,webObj,styleObj,valMap){
		if(oldPrefix){
			oldPrefix.call(typeDef,obj,def,webObj,styleObj,valMap);
		}
		obj.autoLayout=true;
		return def;
	};
	//************************************************************************
	//define ppts:
	//************************************************************************
	let _setHud;
	{
		//ppt hud:
		{
			let _set;
			_set=_setHud=function(valMap,val){
				let curHud=valMap[pptHudIdx];
				let webObj=valMap[pptWebObjIdx];
				if(curHud===val){
					return;
				}
				if(curHud){
					webObj.removeChild(curHud.$_webObj);
					curHud.release();
				}
				curHud=valMap[pptHudIdx]=val;
				if(curHud){
					webObj.appendChild(curHud.$_webObj);
					curHud.hold();
				}
			};
			let _get=function(valMap){
				return valMap[pptHudIdx];
			};
			typeDef.definePpt("hud",_get,_set,false);
		}
	}
	//************************************************************************
	//overload functions:
	//************************************************************************
	{
		let appendChild=function(valMap){
			return (hud)=>{
				return _setHud(valMap,hud);
			};
		};
		typeDef.definePpt("appendChild",appendChild,null,false);
		
		typeDef.defineFunction("clearChildren",function(){
			let valMap=this;
			let curHud=valMap[pptHudIdx];
			let webObj=valMap[pptWebObjIdx];
			if(curHud){
				webObj.removeChild(curHud.$_webObj);
				curHud.release();
			}
			valMap[pptHudIdx]=null;
		});
		
		typeDef.defineFunction("doLayout",function(){
			let valMap=this;
			let curHud=valMap[pptHudIdx];
			if(curHud){
				curHud.doLayout();
			}
		});
			
		//------------------------------------------------------------------------
		let getClientW=function(valMap){
			let webObj,prtNode;
			webObj=valMap[pptWebObjIdx];
			prtNode=webObj.parentNode;
			if(!prtNode){
				return 0;
			}
			if(prtNode.offsetParent){
				return prtNode.clientWidth;
			}
			return 0;
		};
		getMap.set("clientW",getClientW);
		getMap.set("clientWidth",getClientW);
		
		//------------------------------------------------------------------------
		let getClientH=function(valMap){
			let webObj,prtNode;
			webObj=valMap[pptWebObjIdx];
			prtNode=webObj.parentNode;
			if(!prtNode){
				return 0;
			}
			if(prtNode.offsetParent){
				return prtNode.clientHeight;
			}
			return 0;
		};
		getMap.set("clientH",getClientH);
		getMap.set("clientHeight",getClientH);
		
		typeDef.defineFunction("showFace",function(...args){
			let valMap=this;
			let curHud=valMap[pptHudIdx];
			if(curHud){
				curHud.showFace(...args);
			}
		});
	}
};
let typeTreeNode=new TypeDef("treeNode",{"position":"relative","box-sizing":"border-box"});
VFACTObj.setupBasic(typeTreeNode);
setupTreeNode(typeTreeNode);

//----------------------------------------------------------------------------
//Tree:
let setupTree=function(typeDef,isJAX=false){
	let getMap;
	
	let codeFocus=isJAX?"hot":"focus";
	let codeBlur=isJAX?"normal":"blur";
	let codeSelect=isJAX?"selected":"select";
	
	getMap=typeDef.getMap;
	
	typeDef.defineIdxOnlyPpt("indent",20,false);
	let pptNodeGapIdx=typeDef.defineIdxOnlyPpt("nodeGap",0,false);
	let pptNodeDefIdx=typeDef.defineIdxOnlyPpt("nodeDef",null,false);
	let pptGetSubObjsIdx=typeDef.defineIdxOnlyPpt("getSubObjs",null,false);
	let pptHotNodeIdx=typeDef.allocPptIdx("hotNode",null);
	let pptSelectedIdx=typeDef.allocPptIdx("selected",null);
	let pptMultiSelectIdx=typeDef.defineIdxOnlyPpt("multiSelect",false,false);
	let pptPauseCallbackIdx=typeDef.defineIdxOnlyPpt("pauseCallback",0,false);
	let setHotNode,_clearSelects;
	
	let removeChild=getMap.get("removeChild")(null);
	
	let oldPrefix=typeDef.prefix;
	typeDef.prefix=function(obj,def,webObj,styleObj,valMap){
		if(oldPrefix){
			oldPrefix.call(typeDef,obj,def,webObj,styleObj,valMap);
		}
		valMap[pptSelectedIdx]=new Set();
		return def;
	};
	
	//************************************************************************
	//define ppts:
	//************************************************************************
	{
		//ppt headSpace
		{
			let pptIdx=typeDef.getPptIdx("padding",0);
			let _set=function(valMap,val){
				let padding=valMap[pptIdx];
				let styleObj=valMap[pptStyleObjIdx];
				if(padding>=0){
					padding=[val,padding,padding,padding];
				}else if(Array.isArray(padding)){
					padding[0]=val;
				}else {
					padding=[val,0,0,0];
				}
				styleObj.padding=`${padding[0]}px ${padding[1]}px ${padding[2]}px ${padding[3]}px`;
			};
			let _get=function(valMap){
				let padding=valMap[pptIdx];
				if(padding>=0){
					return padding;
				}else if(Array.isArray(padding)){
					return padding[0];
				}
				return 0;
			};
			typeDef.definePpt("headSpace",_get,_set,true);
		}
		
		//ppt endSpace
		{
			let pptIdx=typeDef.getPptIdx("padding");
			let _set=function(valMap,val){
				let padding=valMap[pptIdx];
				let styleObj=valMap[pptStyleObjIdx];
				if(padding>=0){
					padding=[padding,padding,val,padding];
				}else if(Array.isArray(padding)){
					padding[3]=val;
				}else {
					padding=[0,0,val,0];
				}
				styleObj.padding=`${padding[0]}px ${padding[1]}px ${padding[2]}px ${padding[3]}px`;
			};
			let _get=function(valMap){
				let padding=valMap[pptIdx];
				if(padding>=0){
					return padding;
				}else if(Array.isArray(padding)){
					return padding[3];
				}
				return 0;
			};
			typeDef.definePpt("endSpace",_get,_set,true);
		}
		
		//ppt nodes: proxy for nodes
		{
			let pptNodesIdx=typeDef.allocPptIdx("nodes",null);
			let getNodes=function(valMap,val){
				let nodes,webNodes;
				nodes=valMap[pptNodesIdx];
				if(nodes){
					return nodes;
				}
				webNodes=valMap[pptWebObjIdx].childNodes;
				nodes=new Proxy(webNodes,{
					get:function(obj,pName){
						if(pName>=0){
							return webNodes[pName].$_pxy;
						}
						if(pName==="length"){
							return webNodes.length;
						}
					}
				});
				valMap[pptNodesIdx]=nodes;
				return nodes;
			};
			getMap.set("nodes",getNodes);
		}
		
		//ppt hotNode
		{
			//will be replaced for JAXPatch
			setHotNode=function(valMap,val,addSel=0){
				let curHot=valMap[pptHotNodeIdx];
				let multi=valMap[pptMultiSelectIdx];
				let selSet=valMap[pptSelectedIdx];
				let pxy=valMap[pptProxyIdx];
				if(val===curHot){
					return;
				}
				if(curHot){
					if(selSet.has(curHot)){
						curHot.hud && curHot.hud.showFace(codeSelect);//will be replaced for JAXPatch
					}else {
						curHot.hud && curHot.hud.showFace(codeBlur);//will be replaced for JAXPatch
					}
				}
				valMap[pptHotNodeIdx]=curHot=val;
				if(curHot){
					if(multi && addSel){
						selSet.add(curHot);
						curHot.hud && curHot.hud.showFace(codeFocus);
						if(!valMap[pptPauseCallbackIdx]){
							pxy.OnSelNodeChange && pxy.OnSelNodeChange();
						}
					}else {
						valMap[pptPauseCallbackIdx]++;
						_clearSelects(valMap);
						valMap[pptPauseCallbackIdx]--;
						selSet.add(curHot);
						if(!valMap[pptPauseCallbackIdx]){
							pxy.OnSelNodeChange && pxy.OnSelNodeChange();
						}
						curHot.hud && curHot.hud.showFace(codeFocus);
					}
				}else {
					if(!multi){
						_clearSelects(valMap);
					}
				}
				pxy.OnHotNodeChange && pxy.OnHotNodeChange(curHot);
			};
			let _get=function(valMap){
				return valMap[pptHotNodeIdx];
			};
			typeDef.definePpt("hotNode",_get,setHotNode,false);
			typeDef.defineFunction("setHotNode",function(node,addSel){
				setHotNode(this,node,addSel);
			});
		}
		
		//ppt selected
		{
			let _get=function(valMap){
				return valMap[pptSelectedIdx];
			};
			typeDef.definePpt("selected",_get,null,false);
		}
	}
	
	//************************************************************************
	//define functions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//tree.clear():
		{
			typeDef.defineFunction("clear",function(){
				let valMap=this;
				let obj,subpxy,pxy;
				valMap[pptWebObjIdx];
				pxy=valMap[pptProxyIdx];
				setHotNode(valMap,null);
				_clearSelects(valMap);
				while(obj=pxy.firstChild){
					removeChild.call(valMap,obj);
					subpxy=obj.$_pxy;
					if(subpxy){
						subpxy.release();
					}
				}
			});
		}
		
		//--------------------------------------------------------------------
		//tree.addNode(newNodeObj,ownerNode,hud=null):
		let _addNode=function(valMap,obj,upNode,hudDef){
			let node,checkDiv,checkPxy,upIndent;
			let nodeDefFunc=valMap[pptNodeDefIdx];
			let pxy=valMap[pptProxyIdx];
			if(!upNode){
				node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},pxy);
				node.margin=[0,0,valMap[pptNodeGapIdx],0];
				node.nodeObj=obj;
				node.indent=0;
				if(!hudDef){
					hudDef=nodeDefFunc(obj,node,pxy);
				}
				hudDef.position="relative";
				VFACT.createObj(hudDef,node);
				return node;
			}
			upIndent=upNode.indent;
			checkDiv=upNode.$_webObj.nextSibling;
			while(checkDiv){
				checkPxy=checkDiv.$_pxy;
				if(checkPxy && checkPxy.indent<=upIndent){
					node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},pxy,checkPxy);
					node.margin=[0,0,valMap[pptNodeGapIdx],0];
					node.nodeObj=obj;
					node.indent=upIndent+1;
					if(!hudDef){
						hudDef=nodeDefFunc(obj,node,pxy);
					}
					hudDef.position="relative";
					VFACT.createObj(hudDef,node);
					return node;
				}
				checkDiv=checkDiv.nextSibling;
			}
			//Add to end:
			node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},pxy);
			node.margin=[0,0,valMap[pptNodeGapIdx],0];
			node.nodeObj=obj;
			node.indent=upIndent+1;
			if(!hudDef){
				hudDef=nodeDefFunc(obj,node,pxy);
			}
			hudDef.position="relative";
			VFACT.createObj(hudDef,node);
			return node;
		};
		
		{
			typeDef.defineFunction("addNode",function(obj,upNode,hudDef){
				return _addNode(this,obj,upNode,hudDef);
			});
		}
	}
	
	//------------------------------------------------------------------------
	//tree.addNodes(list,upNode)
	let _addNodes;
	{
		_addNodes=function(valMap,list,upNode){
			let node,hudDef,obj,upIndent,checkDiv,checkPxy;
			let nodeDefFunc=valMap[pptNodeDefIdx];
			let gap=valMap[pptNodeGapIdx];
			let pxy=valMap[pptProxyIdx];
			let webObj=valMap[pptWebObjIdx];
			let frg=new DocumentFragment();
			frg.$_pxy=pxy;
			frg.offsetParent=webObj.offsetParent;
			frg.clientWidth=webObj.clientWidth;
			frg.clientHeight=webObj.clientHeight;
			/*frg.clientW=pxy.clientW;
			frg.clientH=pxy.clientH;*/
			if(!upNode){
				for(obj of list){
					node=VFACT.createObj({type:"treeNode",w:"100%",h:"",ownerNode:upNode,autoLayout:1},frg);
					node.margin=[0,0,gap,0];
					node.nodeObj=obj;
					node.indent=0;
					hudDef=nodeDefFunc(obj,node,pxy);
					hudDef.position="relative";
					VFACT.createObj(hudDef,node);
				}
				webObj.appendChild(frg);
				return;
			}
			upIndent=upNode.indent;
			checkDiv=upNode.$_webObj.nextSibling;
			while(checkDiv){
				checkPxy=checkDiv.$_pxy;
				if(checkPxy && checkPxy.indent<=upIndent){
					for(obj of list){
						//node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode},pxy,checkPxy);
						node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},frg);
						node.margin=[0,0,gap,0];
						node.nodeObj=obj;
						node.indent=upIndent+1;
						hudDef=nodeDefFunc(obj,node,pxy);
						hudDef.position="relative";
						VFACT.createObj(hudDef,node);
					}
					webObj.insertBefore(frg,checkPxy.$_webObj);
					return;
				}
				checkDiv=checkDiv.nextSibling;
			}
			//Add to end:
			for(obj of list){
				node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},frg);
				//node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode},pxy);
				node.margin=[0,0,gap,0];
				node.nodeObj=obj;
				node.indent=upIndent+1;
				hudDef=nodeDefFunc(obj,node,pxy);
				hudDef.position="relative";
				VFACT.createObj(hudDef,node);
			}
			webObj.appendChild(frg);
		};
		{
			typeDef.defineFunction("addNodes",function(list,upNode){
				let valMap=this;
				_addNodes(valMap,list,upNode);
			});
		}
	}
	
	//------------------------------------------------------------------------
	//tree.insertNode(idx,obj,upNode,hud)
	{
		let _insertNode=function(valMap,idx,obj,upNode,hud){
			let checkNode,upIndent,checkIndent;
			let node,hudDef;
			let nodeDefFunc=valMap[pptNodeDefIdx];
			let pxy=valMap[pptProxyIdx];
			upIndent=upNode.indent;
			checkIndent=upIndent+1;
			checkNode=upNode.nextSibling;
			while(checkNode){
				if(idx===0){
					break;
				}
				if(checkNode.indent<=upIndent){
					break;
				}
				if(checkNode.indent===checkIndent){
					idx--;
				}
				checkNode=checkNode.nextSibling;
			}
			//appendNode before checkNode:
			node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},pxy,checkNode||null);
			node.margin=[0,0,valMap[pptNodeGapIdx],0];
			node.nodeObj=obj;
			node.indent=upIndent+1;
			if(hud){
				node.hud=hud;
			}else {
				hudDef=nodeDefFunc(obj,node,pxy);
				hudDef.position="relative";
				VFACT.createObj(hudDef,node);
			}
			return node;
		};
		{
			typeDef.defineFunction("insertNode",function(idx,obj,upNode,hud){
				return _insertNode(this,idx,obj,upNode,hud);
			});
		}
	}
	
	//------------------------------------------------------------------------
	//tree.insertNodeBefore(obj,beforeNode,hud)
	{
		let _insertNodeBefore=function(valMap,obj,beforeNode,hud){
			let upNode,node,hudDef;
			let nodeDefFunc=valMap[pptNodeDefIdx];
			let pxy=valMap[pptProxyIdx];
			upNode=beforeNode.ownerNode;
			node=VFACT.createObj({type:"treeNode",position:"relative",x:0,y:0,w:"100%",h:"",ownerNode:upNode,autoLayout:1},pxy,beforeNode);
			node.margin=[0,0,valMap[pptNodeGapIdx],0];
			node.nodeObj=obj;
			node.indent=beforeNode.indent;
			if(hud){
				node.hud=hud;
			}else {
				hudDef=nodeDefFunc(obj,node,pxy);
				hudDef.position="relative";
				hud=VFACT.createObj(hudDef,node);
			}
			return node;
		};
		{
			typeDef.defineFunction("insertNodeBefore",function (obj,beforeNode,hud){
				return _insertNodeBefore(this,obj,beforeNode,hud);
			});
		}
	}
	
	//------------------------------------------------------------------------
	//tree.replaceNode(newObj,oldNode,hud)
	{
		let _replaceNode=function(valMap,newObj,node,hud){
			let hudDef,hotNode,selSet;
			let pxy=valMap[pptProxyIdx];
			node.nodeObj=newObj;
			if(hud){
				node.hud=hud;
			}else {
				let nodeDefFunc=valMap[pptNodeDefIdx];
				hudDef=nodeDefFunc(newObj,node,pxy);
				hudDef.position="relative";
				hud=VFACT.createObj(hudDef,node);
			}
			hotNode=valMap[pptHotNodeIdx];
			selSet=valMap[pptSelectedIdx];
			if(hotNode===node){
				hud.showFace(codeFocus);
			}else if(selSet.has(node)){
				hud.showFace(codeSelect);
			}
			return node;
		};
		
		typeDef.defineFunction("replaceNode",function(newObj,node,hud){
			return _replaceNode(this,newObj,node,hud);
		});
	}
	
	//------------------------------------------------------------------------
	//tree.removeNode(node)
	{
		let _removeNode=function(valMap,node){
			let hotNode,selSet;
			hotNode=valMap[pptHotNodeIdx];
			selSet=valMap[pptSelectedIdx];
			if(hotNode===node){
				setHotNode(valMap,null,1);
			}
			selSet.delete(node);
			node.hud=null;
			removeChild.call(valMap,node);
		};
		typeDef.defineFunction("removeNode",function(node){
			_removeNode(this,node);
		});
	}
	
	//------------------------------------------------------------------------
	//tree.getNodeHud(node)
	{
		typeDef.defineFunction("getNodeHud",function(node){
			return node.hud;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.getNodeOfObj(obj)
	{
		let _getNodeOfObj=function(valMap,obj){
			let checkNode;
			let pxy=valMap[pptProxyIdx];
			checkNode=pxy.firstChild;
			while(checkNode){
				if(checkNode.nodeObj===obj){
					return checkNode;
				}
				checkNode=checkNode.nextSibling;
			}
			return null;
		};
		typeDef.defineFunction("getNodeOfObj",function(obj){
			return _getNodeOfObj(this,obj);
			
		});
	}
	
	//------------------------------------------------------------------------
	//tree.getNodeIdxOfObj(obj)
	{
		typeDef.defineFunction("getNodeIdxOfObj",function(obj){
			let valMap=this;
			let checkNode,idx=0;
			let pxy=valMap[pptProxyIdx];
			checkNode=pxy.firstChild;
			while(checkNode){
				if(checkNode.nodeObj===obj){
					return idx;
				}
				idx++;
				checkNode=checkNode.nextSibling;
			}
			return -1;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.indexOfNode(node)
	{
		typeDef.defineFunction("indexOfNode",function(node){
			let valMap=this;
			let list,nodeWebObj,idx,n;
			let webObj=valMap[pptWebObjIdx];
			nodeWebObj=node.$_webObj;
			list=webObj.childNodes;
			n=list.length;
			for(idx=0;idx<n;idx++){
				if(list[idx]===nodeWebObj){
					return idx;
				}
			}
			return -1;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.openNode(node)
	let _openNode;
	{
		_openNode=function(node){
			let valMap=this;
			let getSubsFunc,subs;
			if(node.isOpen){
				return;
			}
			getSubsFunc=valMap[pptGetSubObjsIdx];
			if(!getSubsFunc){
				return;
			}
			subs=getSubsFunc(node.nodeObj,node);
			if(Array.isArray(subs) && subs.length>0){
				_addNodes(valMap,subs,node);
			}
			node.isOpen=true;
			node.hud && node.hud.showFace("open");
		};
		typeDef.defineFunction("openNode",_openNode);
	}
	
	//------------------------------------------------------------------------
	//tree.closeNode(node)
	let _closeNode;
	{
		_closeNode=function(node){
			let valMap=this;
			let checkNode,indent,hotNode,selSet,pauseCallback,selChanged;
			if(!node.isOpen){
				return;
			}
			let pxy=valMap[pptProxyIdx];
			node.isOpen=false;
			node.hud && node.hud.showFace("close");
			checkNode=node.nextSibling;
			indent=node.indent;
			hotNode=valMap[pptHotNodeIdx];
			selSet=valMap[pptSelectedIdx];
			pauseCallback=valMap[pptPauseCallbackIdx];
			selChanged=0;
			while(checkNode){
				if(checkNode.indent<=indent){
					break;
				}
				if(checkNode===hotNode){
					hotNode=null;
					setHotNode(valMap,null,1);
				}
				if(selSet.has(checkNode)){
					selSet.delete(checkNode);
					selChanged=1;
				}
				node=checkNode;
				checkNode=node.nextSibling;
				removeChild.call(valMap,node);
			}
			if(selChanged && !pauseCallback){
				pxy.OnSelNodeChange && pxy.OnSelNodeChange();
			}
		};
		typeDef.defineFunction("closeNode",_closeNode);
	}
	
	//------------------------------------------------------------------------
	//tree.clearSelects()
	{
		_clearSelects=function(valMap){
			let selSet,node,selChanged,pauseCallback;
			let hotNode;
			let pxy=valMap[pptProxyIdx];
			selSet=valMap[pptSelectedIdx];
			pauseCallback=valMap[pptPauseCallbackIdx];
			selChanged=0;
			for(node of selSet){
				selChanged=1;
				node.hud && node.hud.showFace(codeBlur);
			}
			selSet.clear();
			if(selChanged && !pauseCallback){
				pxy.OnSelNodeChange && pxy.OnSelNodeChange();
			}
			hotNode=valMap[pptHotNodeIdx];
			if(hotNode){
				hotNode.showFace(codeFocus);
			}
		};
		let funcIdx=typeDef.allocPptIdx("clearSelects()",null);
		let clearSelects=function(valMap){
			let func;
			func=valMap[funcIdx];
			if(!func){
				func=valMap[funcIdx]=()=>{
					_clearSelects(valMap);
				};
			}
			return func;
		};
		getMap.set("clearSelects",clearSelects);
	}
	
	//------------------------------------------------------------------------
	//tree.selectNode(node)
	{
		typeDef.defineFunction("selectNode",function (node) {
			let valMap=this;
			let selSet,hotNode,pauseCallback;
			let pxy=valMap[pptProxyIdx];
			pauseCallback=valMap[pptPauseCallbackIdx];
			selSet=valMap[pptSelectedIdx];
			hotNode=valMap[pptHotNodeIdx];
			if(selSet.has(node)){
				return;
			}
			selSet.add(node);
			if(node!==hotNode){
				node.hud && node.hud.showFace(codeSelect);
			}
			if(!pauseCallback){
				pxy.OnSelNodeChange && pxy.OnSelNodeChange();
			}
		});
	}
	
	//------------------------------------------------------------------------
	//tree.selectAll()
	{
		typeDef.defineFunction("selectAll",function () {
			let valMap=this;
			let selSet,hotNode,pauseCallback;
			let pxy=valMap[pptProxyIdx];
			let list,node,n,idx,webObj;
			webObj=valMap[pptWebObjIdx];
			pauseCallback=valMap[pptPauseCallbackIdx];
			selSet=valMap[pptSelectedIdx];
			hotNode=valMap[pptHotNodeIdx];
			list=webObj.childNodes;
			n=list.length;
			for(idx=0;idx<n;idx++){
				node=list[idx];
				selSet.add(node);
				if(node!==hotNode){
					node.hud && node.hud.showFace(codeSelect);
				}
			}
			if(!pauseCallback){
				pxy.OnSelNodeChange && pxy.OnSelNodeChange();
			}
		});
	}

	//------------------------------------------------------------------------
	//tree.deselectNode(node)
	{
		typeDef.defineFunction("deselectNode",function (node) {
			let valMap=this;
			let selSet,hotNode,pauseCallback;
			let pxy=valMap[pptProxyIdx];
			pauseCallback=valMap[pptPauseCallbackIdx];
			selSet=valMap[pptSelectedIdx];
			hotNode=valMap[pptHotNodeIdx];
			if(!selSet.has(node)){
				return;
			}
			selSet.delete(node);
			if(node===hotNode){
				valMap[pptHotNodeIdx]=null;
				node.hud && node.hud.showFace(codeBlur);
				pxy.OnHotNodeChange && pxy.OnHotNodeChange(null);
			}else {
				node.hud && node.hud.showFace(codeBlur);
			}
			if(!pauseCallback){
				pxy.OnSelNodeChange && pxy.OnSelNodeChange();
			}
		});
	}
	
	//------------------------------------------------------------------------
	//tree.isNodeSelected(node)
	{
		typeDef.defineFunction("isNodeSelected",function (node) {
			let valMap=this;
			let selSet;
			selSet=valMap[pptSelectedIdx];
			return selSet.has(node);
		});
	}
	
	//------------------------------------------------------------------------
	//tree.findNode(func)
	{
		typeDef.defineFunction("findNode",function (func) {
			let valMap=this;
			let checkNode;
			let pxy=valMap[pptProxyIdx];
			checkNode=pxy.firstChild;
			while(checkNode){
				if(func(checkNode)){
					return checkNode;
				}
				checkNode=checkNode.nextSibling;
			}
			return null;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.getNodeNum()
	{
		typeDef.defineFunction("getNodeNum",function () {
			return this[pptWebObjIdx].childNodes.length;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.sortNodes(nodeList)
	{
		typeDef.defineFunction("sortNodes",function (list) {
			let valMap=this;
			let nodeWebObjs,i,n,tgtList;
			nodeWebObjs=valMap[pptWebObjIdx].childNodes;
			n=nodeWebObjs.length;
			for(i=0;i<n;i++){
				nodeWebObjs[i].nodeIdx=i;
			}
			tgtList=list.map(item=>item.$_webObj);
			tgtList.sort((a,b)=>{
				return a.nodeIdx-b.nodeIdx;
			});
			return tgtList.map(item=>item.$_pxy);
		});
	}
	
	let _insertBefore=getMap.get("insertBefore")(null);
	//------------------------------------------------------------------------
	//tree.moveNodeUp(node)
	{
		typeDef.defineFunction("moveNodeUp",function(node){
			let valMap=this;
			let preNode,curOpen;
			preNode=node.previousSibling;
			if(!preNode || preNode.indent<node.indent){
				return false;
			}
			while(preNode && preNode.indent>node.indent){
				preNode=preNode.ownerNode;
			}
			if(!preNode||preNode.indent!==node.indent){
				return false;//impossible...
			}
			curOpen=node.isOpen;
			if(curOpen){
				_closeNode.call(valMap,node);
			}
			_insertBefore.call(valMap,node,preNode);
			if(curOpen){
				_openNode.call(valMap,node);
			}
			return true;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.moveNodeDown(node)
	{
		typeDef.defineFunction("moveNodeDown",function(node){
			let valMap=this;
			let nextNode,nextOpen,curOpen;
			curOpen=node.isOpen;
			if(curOpen){
				_closeNode.call(valMap,node);
			}
			nextNode=node.nextSibling;
			if(!nextNode){// || nextNode.indent!==node.indent){
				return false;
			}
			if(nextNode.indent<node.indent){
				return false;//This is the last node:
			}
			nextOpen=nextNode.isOpen;
			if(nextOpen){
				_closeNode.call(valMap,nextNode);
			}
			_insertBefore.call(valMap,nextNode,node);
			if(nextOpen){
				_openNode.call(valMap,nextNode);
			}
			if(curOpen){
				_openNode.call(valMap,node);
			}
			return true;
		});
	}
	
	//------------------------------------------------------------------------
	//tree.isNodeInView(node)
	{
		typeDef.defineFunction("isNodeInView",function (node) {
			let valMap=this;
			let div,overTop,overBtm;
			let webObj=valMap[pptWebObjIdx];
			div=node.$_webObj;
			overTop = div.offsetTop - webObj.offsetTop < webObj.scrollTop;
			overBtm =  (div.offsetTop - webObj.offsetTop + div.clientHeight) > (webObj.scrollTop + webObj.clientHeight);
			return !(overTop||overBtm);
		});
	}
	
	//------------------------------------------------------------------------
	//tree.scrollShowNode(node)
	{
		typeDef.defineFunction("scrollShowNode",function(node){
			let valMap=this;
			let div;
			let overTop,overBtm;
			div=node.$_webObj;
			let webObj=valMap[pptWebObjIdx];
			overTop = div.offsetTop - webObj.offsetTop < webObj.scrollTop;
			overBtm =  (div.offsetTop - webObj.offsetTop + div.clientHeight) > (webObj.scrollTop + webObj.clientHeight);
			
			if(overTop){
				div.scrollIntoView(true);
			}else if(overBtm){
				div.scrollIntoView(false);
			}
		});
	}
	
	//------------------------------------------------------------------------
	//overload: hudObj.appendChild
	{
		typeDef.defineFunction("appendChild",function(obj){
			let valMap=this;
			let subWebObj,prePrt;
			if(obj.$_type!==typeTreeNode){
				return null;
			}
			subWebObj=obj.$_webObj;
			prePrt=subWebObj.parentNode;
			if(prePrt){
				prePrt=prePrt.$_pxy;
			}
			valMap[pptWebObjIdx].appendChild(subWebObj);
			obj.doLayout();
			if(!prePrt){
				obj.addRefCount();
			}
			return obj;
		});
	}
	
	//------------------------------------------------------------------------
	//overload: hudObj.appendNewChild
	{
		getMap.delete("appendNewChild");
	}
	
	//------------------------------------------------------------------------
	//overload: hudObj.insertBefore
	{
		typeDef.defineFunction("insertBefore",function(obj1,obj2){
			let valMap=this;
			let webObj1,prePrt;
			if(obj1.$_type!==typeTreeNode){
				return null;
			}
			webObj1=obj1.$_webObj;
			prePrt=webObj1.parentNode;
			if(prePrt){
				prePrt=prePrt.$_pxy;
			}
			obj1=valMap[pptWebObjIdx].insertBefore(webObj1,obj2.$_webObj).$_pxy;
			obj1.doLayout();
			if(!prePrt){
				obj1.addRefCount();
			}
			return obj1;
		});
	}
	
	//------------------------------------------------------------------------
	//overload: hudObj.removeChild
	getMap.delete("removeChild");
	
	//------------------------------------------------------------------------
	//overload: hudObj.replaceChild
	getMap.delete("replaceChild");
	
	//------------------------------------------------------------------------
	//overload: hudObj.clearChildren
	//getMap.delete("clearChildren");
	getMap.set("clearChildren",getMap.get("clear"));
	
	//------------------------------------------------------------------------
	//hudObj.execInTree(func)
	{
		typeDef.defineFunction("execInTree",function(func){
			let valMap=this;
			let list,i,n,subObj,subExec;
			let pxy=valMap[pptProxyIdx];
			let webObj=valMap[pptWebObjIdx];
			func(pxy);
			list=webObj.childNodes;
			n=list.length;
			for(i=0;i<n;i++){
				subObj=list[i].$_pxy;
				if(subObj){
					subObj=subObj.hud;
					if(subObj){
						subExec=subObj.execInTree;
						if(subExec){
							subExec.call(subObj,func);
						}else {
							func(subObj);
						}
					}
				}
			}
		});
	}
};
VFACTObj.setupTree=setupTree;

//animate function:
VFACT.animate=VFACTAni.animate;

//Define basic VFACT components:
let typeObj$1=new TypeDef("obj",{position:"absolute"});
VFACTObj.setupBasic(typeObj$1);
VFACTObj.setupHierarchy(typeObj$1);
VFACTObj.setupFaces(typeObj$1);
VFACTObj.setupClick(typeObj$1);
TypeDef.aliasType("obj","view");
TypeDef.aliasType("obj","hud");

let typeBox$1=new TypeDef("box",{position:"absolute"});
VFACTObj.setupBasic(typeBox$1);
VFACTObj.setupBox(typeBox$1,"rgba[255,255,255,1]");
VFACTObj.setupHierarchy(typeBox$1);
VFACTObj.setupFaces(typeBox$1);
VFACTObj.setupClick(typeBox$1);

let typeJAXImage$1=new TypeDef("image",{position:"absolute"});
VFACTObj.setupBasic(typeJAXImage$1);
VFACTObj.setupImage(typeJAXImage$1);
VFACTObj.setupHierarchy(typeJAXImage$1);
VFACTObj.setupFaces(typeJAXImage$1);
VFACTObj.setupClick(typeJAXImage$1);

let typeJAXText$1=new TypeDef("text",{position:"absolute"});
VFACTObj.setupBasic(typeJAXText$1);
VFACTObj.setupText(typeJAXText$1);
//VFACTObj.setupHierarchy(typeJAXText);
VFACTObj.setupFaces(typeJAXText$1);
VFACTObj.setupClick(typeJAXText$1);

let typeJAXButton$1=new TypeDef("button",{position:"absolute"});
VFACTObj.setupBasic(typeJAXButton$1);
VFACTObj.setupHierarchy(typeJAXButton$1);
VFACTObj.setupFaces(typeJAXButton$1);
VFACTObj.setupClick(typeJAXButton$1);
VFACTObj.setupButton(typeJAXButton$1);
TypeDef.aliasType("button","btn");

let typeJAXEdit$1=new TypeDef("edit",{position:"absolute"});
VFACTObj.setupBasic(typeJAXEdit$1);
VFACTObj.setupNoneHierarchy(typeJAXEdit$1);
VFACTObj.setupFaces(typeJAXEdit$1);
VFACTObj.setupBox(typeJAXEdit$1);
VFACTObj.setupEdit(typeJAXEdit$1);

let typeJAXEditMemo$1=new TypeDef("memo",{position:"absolute"});
VFACTObj.setupBasic(typeJAXEditMemo$1);
VFACTObj.setupNoneHierarchy(typeJAXEditMemo$1);
VFACTObj.setupFaces(typeJAXEditMemo$1);
VFACTObj.setupBox(typeJAXEditMemo$1);
VFACTObj.setupEditMemo(typeJAXEditMemo$1);

let typeJAXDocker$1=new TypeDef("dock",{position:"absolute"});
VFACTObj.setupBasic(typeJAXDocker$1);
VFACTObj.setupHierarchy(typeJAXDocker$1);
VFACTObj.setupFaces(typeJAXDocker$1);
VFACTObj.setupDocker(typeJAXDocker$1);

let typeJAXTree$1=new TypeDef("tree",{position:"absolute",overFlow:"auto"});
VFACTObj.setupBasic(typeJAXTree$1);
VFACTObj.setupHierarchy(typeJAXTree$1);
VFACTObj.setupFaces(typeJAXTree$1);
VFACTObj.setupTree(typeJAXTree$1);

//animate function:
VFACT.animate=VFACTAni.animate;

//Define basic VFACT components:
let typeObj=new TypeDef("obj",{position:"absolute"});
VFACTObj.setupBasic(typeObj);
VFACTObj.setupHierarchy(typeObj);
VFACTObj.setupFaces(typeObj);
VFACTObj.setupClick(typeObj);
TypeDef.aliasType("obj","view");
TypeDef.aliasType("obj","hud");

let typeBox=new TypeDef("box",{position:"absolute"});
VFACTObj.setupBasic(typeBox);
VFACTObj.setupBox(typeBox,"rgba[255,255,255,1]");
VFACTObj.setupHierarchy(typeBox);
VFACTObj.setupFaces(typeBox);
VFACTObj.setupClick(typeBox);

let typeJAXImage=new TypeDef("image",{position:"absolute"});
VFACTObj.setupBasic(typeJAXImage);
VFACTObj.setupImage(typeJAXImage);
VFACTObj.setupHierarchy(typeJAXImage);
VFACTObj.setupFaces(typeJAXImage);
VFACTObj.setupClick(typeJAXImage);

let typeJAXText=new TypeDef("text",{position:"absolute"});
VFACTObj.setupBasic(typeJAXText);
VFACTObj.setupText(typeJAXText);
//VFACTObj.setupHierarchy(typeJAXText);
VFACTObj.setupFaces(typeJAXText);
VFACTObj.setupClick(typeJAXText);

let typeJAXButton=new TypeDef("button",{position:"absolute"});
VFACTObj.setupBasic(typeJAXButton);
VFACTObj.setupHierarchy(typeJAXButton);
VFACTObj.setupFaces(typeJAXButton);
VFACTObj.setupClick(typeJAXButton);
VFACTObj.setupButton(typeJAXButton);
TypeDef.aliasType("button","btn");

let typeJAXEdit=new TypeDef("edit",{position:"absolute"});
VFACTObj.setupBasic(typeJAXEdit);
VFACTObj.setupNoneHierarchy(typeJAXEdit);
VFACTObj.setupFaces(typeJAXEdit);
VFACTObj.setupBox(typeJAXEdit);
VFACTObj.setupEdit(typeJAXEdit);

let typeJAXEditMemo=new TypeDef("memo",{position:"absolute"});
VFACTObj.setupBasic(typeJAXEditMemo);
VFACTObj.setupNoneHierarchy(typeJAXEditMemo);
VFACTObj.setupFaces(typeJAXEditMemo);
VFACTObj.setupBox(typeJAXEditMemo);
VFACTObj.setupEditMemo(typeJAXEditMemo);

let typeJAXDocker=new TypeDef("dock",{position:"absolute"});
VFACTObj.setupBasic(typeJAXDocker);
VFACTObj.setupHierarchy(typeJAXDocker);
VFACTObj.setupFaces(typeJAXDocker);
VFACTObj.setupDocker(typeJAXDocker);

let typeJAXTree=new TypeDef("tree",{position:"absolute",overFlow:"auto"});
VFACTObj.setupBasic(typeJAXTree);
VFACTObj.setupHierarchy(typeJAXTree);
VFACTObj.setupFaces(typeJAXTree);
VFACTObj.setupTree(typeJAXTree);

//>>>>>>Node2Coke>>>>>>
var module$1$1={exports:{}};
var module$2=module$1$1;

function assertPath(path) {
	if (typeof path !== 'string') {
		throw new TypeError('Path must be a string. Received ' + JSON.stringify(path));
	}
}

// Resolves . and .. elements in a path with directory names
function normalizeStringPosix(path, allowAboveRoot) {
	var res = '';
	var lastSegmentLength = 0;
	var lastSlash = -1;
	var dots = 0;
	var code;
	for (var i = 0; i <= path.length; ++i) {
		if (i < path.length)
			code = path.charCodeAt(i);
		else if (code === 47 /*/*/)
			break;
		else
			code = 47 /*/*/;
		if (code === 47 /*/*/) {
			if (lastSlash === i - 1 || dots === 1) ; else if (lastSlash !== i - 1 && dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 /*.*/ || res.charCodeAt(res.length - 2) !== 46 /*.*/) {
					if (res.length > 2) {
						var lastSlashIndex = res.lastIndexOf('/');
						if (lastSlashIndex !== res.length - 1) {
							if (lastSlashIndex === -1) {
								res = '';
								lastSegmentLength = 0;
							} else {
								res = res.slice(0, lastSlashIndex);
								lastSegmentLength = res.length - 1 - res.lastIndexOf('/');
							}
							lastSlash = i;
							dots = 0;
							continue;
						}
					} else if (res.length === 2 || res.length === 1) {
						res = '';
						lastSegmentLength = 0;
						lastSlash = i;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					if (res.length > 0)
						res += '/..';
					else
						res = '..';
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0)
					res += '/' + path.slice(lastSlash + 1, i);
				else
					res = path.slice(lastSlash + 1, i);
				lastSegmentLength = i - lastSlash - 1;
			}
			lastSlash = i;
			dots = 0;
		} else if (code === 46 /*.*/ && dots !== -1) {
			++dots;
		} else {
			dots = -1;
		}
	}
	return res;
}

function _format(sep, pathObject) {
	var dir = pathObject.dir || pathObject.root;
	var base = pathObject.base || (pathObject.name || '') + (pathObject.ext || '');
	if (!dir) {
		return base;
	}
	if (dir === pathObject.root) {
		return dir + base;
	}
	return dir + sep + base;
}

var posix = {
	// path.resolve([from ...], to)
	resolve: function resolve() {
		var resolvedPath = '';
		var resolvedAbsolute = false;
		var cwd;
		
		for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
			var path;
			if (i >= 0)
				path = arguments[i];
			else {
				if (cwd === undefined)
					cwd = process.cwd();
				path = cwd;
			}
			
			assertPath(path);
			
			// Skip empty entries
			if (path.length === 0) {
				continue;
			}
			
			resolvedPath = path + '/' + resolvedPath;
			resolvedAbsolute = path.charCodeAt(0) === 47 /*/*/;
		}
		
		// At this point the path should be resolved to a full absolute path, but
		// handle relative paths to be safe (might happen when process.cwd() fails)
		
		// Normalize the path
		resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);
		
		if (resolvedAbsolute) {
			if (resolvedPath.length > 0)
				return '/' + resolvedPath;
			else
				return '/';
		} else if (resolvedPath.length > 0) {
			return resolvedPath;
		} else {
			return '.';
		}
	},
	
	normalize: function normalize(path) {
		assertPath(path);
		
		if (path.length === 0) return '.';
		
		var isAbsolute = path.charCodeAt(0) === 47 /*/*/;
		var trailingSeparator = path.charCodeAt(path.length - 1) === 47 /*/*/;
		
		// Normalize the path
		path = normalizeStringPosix(path, !isAbsolute);
		
		if (path.length === 0 && !isAbsolute) path = '.';
		if (path.length > 0 && trailingSeparator) path += '/';
		
		if (isAbsolute) return '/' + path;
		return path;
	},
	
	isAbsolute: function isAbsolute(path) {
		assertPath(path);
		return path.length > 0 && path.charCodeAt(0) === 47 /*/*/;
	},
	
	join: function join() {
		if (arguments.length === 0)
			return '.';
		var joined;
		for (var i = 0; i < arguments.length; ++i) {
			var arg = arguments[i];
			assertPath(arg);
			if (arg.length > 0) {
				if (joined === undefined)
					joined = arg;
				else
					joined += '/' + arg;
			}
		}
		if (joined === undefined)
			return '.';
		return posix.normalize(joined);
	},
	
	relative: function relative(from, to) {
		assertPath(from);
		assertPath(to);
		
		if (from === to) return '';
		
		from = posix.resolve(from);
		to = posix.resolve(to);
		
		if (from === to) return '';
		
		// Trim any leading backslashes
		var fromStart = 1;
		for (; fromStart < from.length; ++fromStart) {
			if (from.charCodeAt(fromStart) !== 47 /*/*/)
				break;
		}
		var fromEnd = from.length;
		var fromLen = fromEnd - fromStart;
		
		// Trim any leading backslashes
		var toStart = 1;
		for (; toStart < to.length; ++toStart) {
			if (to.charCodeAt(toStart) !== 47 /*/*/)
				break;
		}
		var toEnd = to.length;
		var toLen = toEnd - toStart;
		
		// Compare paths to find the longest common path from root
		var length = fromLen < toLen ? fromLen : toLen;
		var lastCommonSep = -1;
		var i = 0;
		for (; i <= length; ++i) {
			if (i === length) {
				if (toLen > length) {
					if (to.charCodeAt(toStart + i) === 47 /*/*/) {
						// We get here if `from` is the exact base path for `to`.
						// For example: from='/foo/bar'; to='/foo/bar/baz'
						return to.slice(toStart + i + 1);
					} else if (i === 0) {
						// We get here if `from` is the root
						// For example: from='/'; to='/foo'
						return to.slice(toStart + i);
					}
				} else if (fromLen > length) {
					if (from.charCodeAt(fromStart + i) === 47 /*/*/) {
						// We get here if `to` is the exact base path for `from`.
						// For example: from='/foo/bar/baz'; to='/foo/bar'
						lastCommonSep = i;
					} else if (i === 0) {
						// We get here if `to` is the root.
						// For example: from='/foo'; to='/'
						lastCommonSep = 0;
					}
				}
				break;
			}
			var fromCode = from.charCodeAt(fromStart + i);
			var toCode = to.charCodeAt(toStart + i);
			if (fromCode !== toCode)
				break;
			else if (fromCode === 47 /*/*/)
				lastCommonSep = i;
		}
		
		var out = '';
		// Generate the relative path based on the path difference between `to`
		// and `from`
		for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
			if (i === fromEnd || from.charCodeAt(i) === 47 /*/*/) {
				if (out.length === 0)
					out += '..';
				else
					out += '/..';
			}
		}
		
		// Lastly, append the rest of the destination (`to`) path that comes after
		// the common path parts
		if (out.length > 0)
			return out + to.slice(toStart + lastCommonSep);
		else {
			toStart += lastCommonSep;
			if (to.charCodeAt(toStart) === 47 /*/*/)
				++toStart;
			return to.slice(toStart);
		}
	},
	
	_makeLong: function _makeLong(path) {
		return path;
	},
	
	dirname: function dirname(path) {
		assertPath(path);
		if (path.length === 0) return '.';
		var code = path.charCodeAt(0);
		var hasRoot = code === 47 /*/*/;
		var end = -1;
		var matchedSlash = true;
		for (var i = path.length - 1; i >= 1; --i) {
			code = path.charCodeAt(i);
			if (code === 47 /*/*/) {
				if (!matchedSlash) {
					end = i;
					break;
				}
			} else {
				// We saw the first non-path separator
				matchedSlash = false;
			}
		}
		
		if (end === -1) return hasRoot ? '/' : '.';
		if (hasRoot && end === 1) return '//';
		return path.slice(0, end);
	},
	
	basename: function basename(path, ext) {
		if (ext !== undefined && typeof ext !== 'string') throw new TypeError('"ext" argument must be a string');
		assertPath(path);
		
		var start = 0;
		var end = -1;
		var matchedSlash = true;
		var i;
		
		if (ext !== undefined && ext.length > 0 && ext.length <= path.length) {
			if (ext.length === path.length && ext === path) return '';
			var extIdx = ext.length - 1;
			var firstNonSlashEnd = -1;
			for (i = path.length - 1; i >= 0; --i) {
				var code = path.charCodeAt(i);
				if (code === 47 /*/*/) {
					// If we reached a path separator that was not part of a set of path
					// separators at the end of the string, stop now
					if (!matchedSlash) {
						start = i + 1;
						break;
					}
				} else {
					if (firstNonSlashEnd === -1) {
						// We saw the first non-path separator, remember this index in case
						// we need it if the extension ends up not matching
						matchedSlash = false;
						firstNonSlashEnd = i + 1;
					}
					if (extIdx >= 0) {
						// Try to match the explicit extension
						if (code === ext.charCodeAt(extIdx)) {
							if (--extIdx === -1) {
								// We matched the extension, so mark this as the end of our path
								// component
								end = i;
							}
						} else {
							// Extension does not match, so our result is the entire path
							// component
							extIdx = -1;
							end = firstNonSlashEnd;
						}
					}
				}
			}
			
			if (start === end) end = firstNonSlashEnd;else if (end === -1) end = path.length;
			return path.slice(start, end);
		} else {
			for (i = path.length - 1; i >= 0; --i) {
				if (path.charCodeAt(i) === 47 /*/*/) {
					// If we reached a path separator that was not part of a set of path
					// separators at the end of the string, stop now
					if (!matchedSlash) {
						start = i + 1;
						break;
					}
				} else if (end === -1) {
					// We saw the first non-path separator, mark this as the end of our
					// path component
					matchedSlash = false;
					end = i + 1;
				}
			}
			
			if (end === -1) return '';
			return path.slice(start, end);
		}
	},
	
	extname: function extname(path) {
		assertPath(path);
		var startDot = -1;
		var startPart = 0;
		var end = -1;
		var matchedSlash = true;
		// Track the state of characters (if any) we see before our first dot and
		// after any path separator we find
		var preDotState = 0;
		for (var i = path.length - 1; i >= 0; --i) {
			var code = path.charCodeAt(i);
			if (code === 47 /*/*/) {
				// If we reached a path separator that was not part of a set of path
				// separators at the end of the string, stop now
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				// We saw the first non-path separator, mark this as the end of our
				// extension
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46 /*.*/) {
				// If this is our first dot, mark it as the start of our extension
				if (startDot === -1)
					startDot = i;
				else if (preDotState !== 1)
					preDotState = 1;
			} else if (startDot !== -1) {
				// We saw a non-dot and non-path separator before our dot, so we should
				// have a good chance at having a non-empty extension
				preDotState = -1;
			}
		}
		
		if (startDot === -1 || end === -1 ||
			// We saw a non-dot character immediately before the dot
			preDotState === 0 ||
			// The (right-most) trimmed path component is exactly '..'
			preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
			return '';
		}
		return path.slice(startDot, end);
	},

	ext2name: function ext2name(path) {
		assertPath(path);
		let pos;
		pos=path.lastIndexOf("/");
		if(pos>=0){
			path=path.substring(pos+1);
		}
		pos=path.lastIndexOf(".");
		if(pos<=0){
			return "";
		}
		pos=path.lastIndexOf(".",pos-1);
		if(pos<0){
			return "";
		}
		return path.substring(pos);
	},

	format: function format(pathObject) {
		if (pathObject === null || typeof pathObject !== 'object') {
			throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof pathObject);
		}
		return _format('/', pathObject);
	},
	
	parse: function parse(path) {
		assertPath(path);
		
		var ret = { root: '', dir: '', base: '', ext: '', name: '' };
		if (path.length === 0) return ret;
		var code = path.charCodeAt(0);
		var isAbsolute = code === 47 /*/*/;
		var start;
		if (isAbsolute) {
			ret.root = '/';
			start = 1;
		} else {
			start = 0;
		}
		var startDot = -1;
		var startPart = 0;
		var end = -1;
		var matchedSlash = true;
		var i = path.length - 1;
		
		// Track the state of characters (if any) we see before our first dot and
		// after any path separator we find
		var preDotState = 0;
		
		// Get non-dir info
		for (; i >= start; --i) {
			code = path.charCodeAt(i);
			if (code === 47 /*/*/) {
				// If we reached a path separator that was not part of a set of path
				// separators at the end of the string, stop now
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				// We saw the first non-path separator, mark this as the end of our
				// extension
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46 /*.*/) {
				// If this is our first dot, mark it as the start of our extension
				if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
			} else if (startDot !== -1) {
				// We saw a non-dot and non-path separator before our dot, so we should
				// have a good chance at having a non-empty extension
				preDotState = -1;
			}
		}
		
		if (startDot === -1 || end === -1 ||
			// We saw a non-dot character immediately before the dot
			preDotState === 0 ||
			// The (right-most) trimmed path component is exactly '..'
			preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
			if (end !== -1) {
				if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);else ret.base = ret.name = path.slice(startPart, end);
			}
		} else {
			if (startPart === 0 && isAbsolute) {
				ret.name = path.slice(1, startDot);
				ret.base = path.slice(1, end);
			} else {
				ret.name = path.slice(startPart, startDot);
				ret.base = path.slice(startPart, end);
			}
			ret.ext = path.slice(startDot, end);
		}
		
		if (startPart > 0) ret.dir = path.slice(0, startPart - 1);else if (isAbsolute) ret.dir = '/';
		
		return ret;
	},
	
	sep: '/',
	delimiter: ':',
	win32: null,
	posix: null
};

posix.posix = posix;

module$2.exports = posix;

//>>>>>>Node2Coke>>>>>>
var pathLib = module$1$1.exports;
//<<<<<<Node2Coke<<<<<<

//>>>>>>Node2Coke>>>>>>
var module$1={exports:{}};
var module=module$1;

var R = typeof Reflect === 'object' ? Reflect : null;
var ReflectApply = R && typeof R.apply === 'function'
	? R.apply
	: function ReflectApply(target, receiver, args) {
		return Function.prototype.apply.call(target, receiver, args);
	};

var ReflectOwnKeys;
if (R && typeof R.ownKeys === 'function') {
	ReflectOwnKeys = R.ownKeys;
} else if (Object.getOwnPropertySymbols) {
	ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target)
			.concat(Object.getOwnPropertySymbols(target));
	};
} else {
	ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target);
	};
}

function ProcessEmitWarning(warning) {
	if (console && console.warn) console.warn(warning);
}

var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
	return value !== value;
};

function EventEmitter() {
	EventEmitter.init.call(this);
}
module.exports = EventEmitter;
module.exports.once = once;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;

function checkListener(listener) {
	if (typeof listener !== 'function') {
		throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
	}
}

Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
	enumerable: true,
	get: function() {
		return defaultMaxListeners;
	},
	set: function(arg) {
		if (typeof arg !== 'number' || arg < 0 || NumberIsNaN(arg)) {
			throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + '.');
		}
		defaultMaxListeners = arg;
	}
});

EventEmitter.init = function() {
	
	if (this._events === undefined ||
		this._events === Object.getPrototypeOf(this)._events) {
		this._events = Object.create(null);
		this._eventsCount = 0;
	}
	
	this._maxListeners = this._maxListeners || undefined;
};

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
	if (typeof n !== 'number' || n < 0 || NumberIsNaN(n)) {
		throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + '.');
	}
	this._maxListeners = n;
	return this;
};

function _getMaxListeners(that) {
	if (that._maxListeners === undefined)
		return EventEmitter.defaultMaxListeners;
	return that._maxListeners;
}

EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
	return _getMaxListeners(this);
};

EventEmitter.prototype.emit = function emit(type) {
	var args = [];
	for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
	var doError = (type === 'error');
	
	var events = this._events;
	if (events !== undefined)
		doError = (doError && events.error === undefined);
	else if (!doError)
		return false;
	
	// If there is no 'error' event listener then throw.
	if (doError) {
		var er;
		if (args.length > 0)
			er = args[0];
		if (er instanceof Error) {
			// Note: The comments on the `throw` lines are intentional, they show
			// up in Node's output if this results in an unhandled exception.
			throw er; // Unhandled 'error' event
		}
		// At least give some kind of context to the user
		var err = new Error('Unhandled error.' + (er ? ' (' + er.message + ')' : ''));
		err.context = er;
		throw err; // Unhandled 'error' event
	}
	
	var handler = events[type];
	
	if (handler === undefined)
		return false;
	
	if (typeof handler === 'function') {
		ReflectApply(handler, this, args);
	} else {
		var len = handler.length;
		var listeners = arrayClone(handler, len);
		for (var i = 0; i < len; ++i)
			ReflectApply(listeners[i], this, args);
	}
	
	return true;
};

function _addListener(target, type, listener, prepend) {
	var m;
	var events;
	var existing;
	
	checkListener(listener);
	
	events = target._events;
	if (events === undefined) {
		events = target._events = Object.create(null);
		target._eventsCount = 0;
	} else {
		// To avoid recursion in the case that type === "newListener"! Before
		// adding it to the listeners, first emit "newListener".
		if (events.newListener !== undefined) {
			target.emit('newListener', type,
				listener.listener ? listener.listener : listener);
			
			// Re-assign `events` because a newListener handler could have caused the
			// this._events to be assigned to a new object
			events = target._events;
		}
		existing = events[type];
	}
	
	if (existing === undefined) {
		// Optimize the case of one listener. Don't need the extra array object.
		existing = events[type] = listener;
		++target._eventsCount;
	} else {
		if (typeof existing === 'function') {
			// Adding the second element, need to change to array.
			existing = events[type] =
				prepend ? [listener, existing] : [existing, listener];
			// If we've already got an array, just append.
		} else if (prepend) {
			existing.unshift(listener);
		} else {
			existing.push(listener);
		}
		
		// Check for listener leak
		m = _getMaxListeners(target);
		if (m > 0 && existing.length > m && !existing.warned) {
			existing.warned = true;
			// No error code for this since it is a Warning
			// eslint-disable-next-line no-restricted-syntax
			var w = new Error('Possible EventEmitter memory leak detected. ' +
				existing.length + ' ' + String(type) + ' listeners ' +
				'added. Use emitter.setMaxListeners() to ' +
				'increase limit');
			w.name = 'MaxListenersExceededWarning';
			w.emitter = target;
			w.type = type;
			w.count = existing.length;
			ProcessEmitWarning(w);
		}
	}
	
	return target;
}

EventEmitter.prototype.addListener = function addListener(type, listener) {
	return _addListener(this, type, listener, false);
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.prependListener =
	function prependListener(type, listener) {
		return _addListener(this, type, listener, true);
	};

function onceWrapper() {
	if (!this.fired) {
		this.target.removeListener(this.type, this.wrapFn);
		this.fired = true;
		if (arguments.length === 0)
			return this.listener.call(this.target);
		return this.listener.apply(this.target, arguments);
	}
}

function _onceWrap(target, type, listener) {
	var state = { fired: false, wrapFn: undefined, target: target, type: type, listener: listener };
	var wrapped = onceWrapper.bind(state);
	wrapped.listener = listener;
	state.wrapFn = wrapped;
	return wrapped;
}

EventEmitter.prototype.once = function once(type, listener) {
	checkListener(listener);
	this.on(type, _onceWrap(this, type, listener));
	return this;
};

EventEmitter.prototype.prependOnceListener =
	function prependOnceListener(type, listener) {
		checkListener(listener);
		this.prependListener(type, _onceWrap(this, type, listener));
		return this;
	};

// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener =
	function removeListener(type, listener) {
		var list, events, position, i, originalListener;
		
		checkListener(listener);
		
		events = this._events;
		if (events === undefined)
			return this;
		
		list = events[type];
		if (list === undefined)
			return this;
		
		if (list === listener || list.listener === listener) {
			if (--this._eventsCount === 0)
				this._events = Object.create(null);
			else {
				delete events[type];
				if (events.removeListener)
					this.emit('removeListener', type, list.listener || listener);
			}
		} else if (typeof list !== 'function') {
			position = -1;
			
			for (i = list.length - 1; i >= 0; i--) {
				if (list[i] === listener || list[i].listener === listener) {
					originalListener = list[i].listener;
					position = i;
					break;
				}
			}
			
			if (position < 0)
				return this;
			
			if (position === 0)
				list.shift();
			else {
				spliceOne(list, position);
			}
			
			if (list.length === 1)
				events[type] = list[0];
			
			if (events.removeListener !== undefined)
				this.emit('removeListener', type, originalListener || listener);
		}
		
		return this;
	};

EventEmitter.prototype.off = EventEmitter.prototype.removeListener;

EventEmitter.prototype.removeAllListeners =
	function removeAllListeners(type) {
		var listeners, events, i;
		
		events = this._events;
		if (events === undefined)
			return this;
		
		// not listening for removeListener, no need to emit
		if (events.removeListener === undefined) {
			if (arguments.length === 0) {
				this._events = Object.create(null);
				this._eventsCount = 0;
			} else if (events[type] !== undefined) {
				if (--this._eventsCount === 0)
					this._events = Object.create(null);
				else
					delete events[type];
			}
			return this;
		}
		
		// emit removeListener for all listeners on all events
		if (arguments.length === 0) {
			var keys = Object.keys(events);
			var key;
			for (i = 0; i < keys.length; ++i) {
				key = keys[i];
				if (key === 'removeListener') continue;
				this.removeAllListeners(key);
			}
			this.removeAllListeners('removeListener');
			this._events = Object.create(null);
			this._eventsCount = 0;
			return this;
		}
		
		listeners = events[type];
		
		if (typeof listeners === 'function') {
			this.removeListener(type, listeners);
		} else if (listeners !== undefined) {
			// LIFO order
			for (i = listeners.length - 1; i >= 0; i--) {
				this.removeListener(type, listeners[i]);
			}
		}
		
		return this;
	};

function _listeners(target, type, unwrap) {
	var events = target._events;
	
	if (events === undefined)
		return [];
	
	var evlistener = events[type];
	if (evlistener === undefined)
		return [];
	
	if (typeof evlistener === 'function')
		return unwrap ? [evlistener.listener || evlistener] : [evlistener];
	
	return unwrap ?
		unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}

EventEmitter.prototype.listeners = function listeners(type) {
	return _listeners(this, type, true);
};

EventEmitter.prototype.rawListeners = function rawListeners(type) {
	return _listeners(this, type, false);
};

EventEmitter.listenerCount = function(emitter, type) {
	if (typeof emitter.listenerCount === 'function') {
		return emitter.listenerCount(type);
	} else {
		return listenerCount.call(emitter, type);
	}
};

EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
	var events = this._events;
	
	if (events !== undefined) {
		var evlistener = events[type];
		
		if (typeof evlistener === 'function') {
			return 1;
		} else if (evlistener !== undefined) {
			return evlistener.length;
		}
	}
	
	return 0;
}

EventEmitter.prototype.eventNames = function eventNames() {
	return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};

function arrayClone(arr, n) {
	var copy = new Array(n);
	for (var i = 0; i < n; ++i)
		copy[i] = arr[i];
	return copy;
}

function spliceOne(list, index) {
	for (; index + 1 < list.length; index++)
		list[index] = list[index + 1];
	list.pop();
}

function unwrapListeners(arr) {
	var ret = new Array(arr.length);
	for (var i = 0; i < ret.length; ++i) {
		ret[i] = arr[i].listener || arr[i];
	}
	return ret;
}

function once(emitter, name) {
	return new Promise(function (resolve, reject) {
		function errorListener(err) {
			emitter.removeListener(name, resolver);
			reject(err);
		}
		
		function resolver() {
			if (typeof emitter.removeListener === 'function') {
				emitter.removeListener('error', errorListener);
			}
			resolve([].slice.call(arguments));
		}		
		eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
		if (name !== 'error') {
			addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
		}
	});
}

function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
	if (typeof emitter.on === 'function') {
		eventTargetAgnosticAddListener(emitter, 'error', handler, flags);
	}
}

function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
	if (typeof emitter.on === 'function') {
		if (flags.once) {
			emitter.once(name, listener);
		} else {
			emitter.on(name, listener);
		}
	} else if (typeof emitter.addEventListener === 'function') {
		// EventTarget does not have `error` event semantics like Node
		// EventEmitters, we do not listen for `error` events here.
		emitter.addEventListener(name, function wrapListener(arg) {
			// IE does not have builtin `{ once: true }` support so we
			// have to do it manually.
			if (flags.once) {
				emitter.removeEventListener(name, wrapListener);
			}
			listener(arg);
		});
	} else {
		throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
	}
}

//**********************************************************************************************************************
//Make a object emitter
//**********************************************************************************************************************
var makeObjEventEmitter;
{
	let emitDeep=0;
	makeObjEventEmitter=function(obj){
		let events={};
		let mute=0;
		if(obj.emit){
			return;
		}
		obj.on=function(msg,callback){
			let cbkSet;
			cbkSet=events[msg];
			callback._call_once=false;
			if(!cbkSet){
				events[msg]=cbkSet=new Set();
				cbkSet.mute=0;
			}
			cbkSet.add(callback);
		};
		obj.once=function(msg,callback){
			let cbkSet;
			cbkSet=events[msg];
			callback._call_once=true;
			if(!cbkSet){
				events[msg]=cbkSet=new Set();
				cbkSet.mute=0;
			}
			cbkSet.add(callback);
		};
		obj.off=function(msg,callback){
			let cbkSet;
			cbkSet=events[msg];
			if(cbkSet){
				cbkSet.delete(callback);
			}
		};
		obj.muteEmit=function(msg){
			if(!msg) {
				mute += 1;
			}else {
				let cbkSet;
				cbkSet=events[msg];
				if(!cbkSet){
					events[msg]=cbkSet=new Set();
					cbkSet.mute=0;
				}
				cbkSet.mute+=1;
			}
		};
		obj.unmuteEmit=function(msg){
			if(!msg) {
				mute -= 1;
			}else {
				let cbkSet;
				cbkSet=events[msg];
				if(cbkSet){
					cbkSet.mute+=1;
				}
			}
		};
		obj.emit=function(msg,...args){
			let cbkSet,cbks,cbk;
			if(mute)
				return;
			cbkSet=events[msg];
			emitDeep++;
			if(emitDeep>20){
				console.warn("Emit too deep, no more emits");
				emitDeep--;
				return;
			}
			if(cbkSet){
				if(!cbkSet.mute) {
					cbks = Array.from(cbkSet.keys());
					for (cbk of cbks) {
						cbk(...args);
						if (cbk._call_once) {
							cbkSet.delete(cbk);
						}
					}
				}
			}
			emitDeep--;
		};
		obj.eventNames=function(){
			return Object.keys(events);
		};
		obj.removeAllListeners=function(eventName){
			if(eventName){
				let cbkSet;
				cbkSet=events[eventName];
				if(cbkSet){
					cbkSet.clear();
				}
			}else {
				events={};
			}
		};
	};
}

//***************************************************************************
//callAtfer function:
//***************************************************************************
let callAfter;
{
	let aboutCall=0;
	let callList=[];
	let makeCall=function(){
		let list,i,n;
		list=callList;
		aboutCall=0;
		callList=[];
		n=list.length;
		for(i=0;i<n;i++){
			list[i]();
		}
	};
	callAfter=async function(func,timeout){
		let pms;
		if(!timeout){
			callList.push(func);
			if(aboutCall){
				return;
			}
			aboutCall=1;
			pms=new Promise((resolve,reject)=>{
				resolve();
			});
			await pms;
			makeCall();
			return;
		}
		window.setTimeout(func,timeout);
	};
}

//***************************************************************************
//Notify-Object
//***************************************************************************
let makeNotify;
{
	makeNotify=function(self){
		let m_NotifyPaused;
		let m_viewHubIn = {};
		let m_viewHubOn = {};
		let m_isInEnvList = 0;
		let m_NotifyOnMsgHash = {};
		let m_PendingNofifyOn=[];
		let m_msgValHash={};
		let removeValBindOfView;
		let notifyToMap,notifyHubOn,notifyOnAll;
		let muteNotify=false;
		if(self.emitNotify){
			return;
		}
		//---------------------------------------------------------------
		//make a property val notify-able, fires notify when this property changes:
		self.upgradeVal = function (name, msg) {
			var oldMsg, curVal, desc, oldGet, oldSet,msgList;
			if (!(name in self)) {
				return;
			}
			if (!msg) {
				msg = "*";//default notify message is "*"
			}
			if(Array.isArray(msg)){
				msgList=msg;
			}
			oldMsg = m_msgValHash[name];
			if (oldMsg) {
				if (msg !== oldMsg) {
					throw "JAXDataObj upgradVal error: val " + name + " is already been upgraded with diffrent msg " + oldMsg + ", new msg: " + msg;
				}
				return;
			}
			desc = Object.getOwnPropertyDescriptor(self, name);
			oldGet = desc.get;
			oldSet = desc.set;
			curVal = self[name];
			m_msgValHash[name] = msg;
			if(msgList){
				//Mapping:
				Object.defineProperty(self, name,
					{
						enumerable: desc.enumerable,
						configurable: true,
						set: function (newVal) {
							let msg;
							curVal = newVal;
							if (oldSet) {
								oldSet.call(self, newVal);
							}
							for(msg of msgList) {
								//notifyHubIn(msg);//这个要去掉
								notifyHubOn(msg);
							}
							return newVal;
						},
						get: function () {
							return oldGet ? oldGet.call(self) : curVal;
						}
					}
				);
			}else {
				//Mapping:
				Object.defineProperty(self, name,
					{
						enumerable: desc.enumerable,
						configurable: true,
						set: function (newVal) {
							curVal = newVal;
							if (oldSet) {
								oldSet.call(self, newVal);
							}
							notifyHubOn(msg);
							return newVal;
						},
						get: function () {
							return oldGet ? oldGet.call(self) : curVal;
						}
					}
				);
			}
		};
		
		//---------------------------------------------------------------
		//Get a "upgraded" property val's notify message string:
		self.getValMsg = function (name) {
			return m_msgValHash[name];
		};
		
		//---------------------------------------------------------------
		//Install a message tracer:
		self.onNotify=self.bindValNotify = function (msgName,func,view,once=0) {
			var map, set, msg;
			if (!func) {
				console.error("hub notify function!!");
				return;
			}
			if (!(msgName in self)) {
				msg=msgName;
			}else {
				msg = m_msgValHash[msgName];
			}
			if(!msg){
				throw ""+msgName+" is not upgraded!";
			}
			map = m_viewHubOn[msg];
			if (!map) {
				map = m_viewHubOn[msg] = new Map();
				map.mute=0;
			}
			set = map.get(view);
			if (!set) {
				set = new Set();
				map.set(view, set);
			}
			if(!once) {
				set.add(func);
			}else {
				let onceFunc;
				onceFunc=function(...args){
					func(...args);
					self.off(msg,onceFunc,view);
				};
				set.add(onceFunc);
			}
			return msg;
		};
		
		//---------------------------------------------------------------
		//Install an one-time message tracer
		self.onceNotify=function(msgName,func,view){
			self.onNotify(msgName,func,view,1);
		};
		
		//---------------------------------------------------------------
		//Uninstall all message tracers of a view
		self.removeValBindOfView = removeValBindOfView = function (msgName, view) {
			var list, i;
			if (!msgName) {
				list = m_viewHubIn;
				for (i in list) {
					removeValBindOfView(i, view);
				}
				list = m_viewHubOn;
				for (i in list) {
					removeValBindOfView(i, view);
				}
				return;
			}
			list = m_viewHubIn[msgName];
			if (list) {
				list.delete(view);
			}
			list = m_viewHubOn[msgName];
			if (list) {
				list.delete(view);
			}
		};
		
		//---------------------------------------------------------------
		//Uninstall a message tracer:
		self.offNotify=self.removeValNotify = function (msgName, func, view) {
			var list, map, set, i, msg;
			if (!msgName) {
				list = m_viewHubIn;
				for (i in list) {
					msg=i;
					self.removeValNotify(msg, view, func);
				}
				list = m_viewHubOn;
				for (i in list) {
					msg=i;
					self.removeValNotify(i, view, func);
				}
				return;
			}
			map = m_viewHubIn[msgName];
			if (map) {
				set = map.get(view);
				if (set) {
					set.delete(func);
				}
			}
			map = m_viewHubOn[msgName];
			if (map) {
				set = map.get(view);
				if (set) {
					set.delete(func);
				}
			}
		};
		
		//---------------------------------------------------------------
		notifyToMap = function (map) {
			var views, view, set, func;
			views = map.keys();
			for (view of views) {
				if (!view || view.allowValNotify!==false) {
					set = map.get(view);
					for (func of set) {
						func();
					}
				}
			}
		};
		
		//---------------------------------------------------------------
		//Set to fire a message notify, 
		self.emitNotify=self.notifyValMsgOn = notifyHubOn = function (msg) {
			if(!m_NotifyOnMsgHash[msg] && !muteNotify) {
				let map = m_viewHubOn[msg];
				if(map && map.mute){
					return;
				}
				
				m_NotifyOnMsgHash[msg] = 1;
				m_PendingNofifyOn.push(msg);
				if (m_isInEnvList)
					return;
				m_isInEnvList = 1;
				callAfter(notifyOnAll);
			}
		};
		
		//---------------------------------------------------------------
		//Fire all panding messages:
		notifyOnAll = function () {
			var map, msg, list, loop;
			m_isInEnvList = 0;
			if (m_NotifyPaused) {
				return;
			}
			loop = 0;
			do {
				list = m_PendingNofifyOn.splice(0);
				for (msg of list) {
					m_NotifyOnMsgHash[msg] = 0;
					map = m_viewHubOn[msg];
					if (map) {
						notifyToMap(map);
					}
				}
				loop++;
				if (loop > 3) {
					console.warn(`JAXDataObj notify too many times.`);
					break;
				}
			} while (m_PendingNofifyOn.length);
		};
		
		//---------------------------------------------------------------
		Object.defineProperty(self,"pauseValNotify",{
			get:function(){
				return m_NotifyPaused;
			},
			set:function(v){
				v=v?1:0;
				m_NotifyPaused=v;
				return v;
			}
		});
		
		//-------------------------------------------------------------------
		self.muteNotify=function(msg){
			if(msg){
				let map;
				map = m_viewHubOn[msg];
				if (!map) {
					map = m_viewHubOn[msg] = new Map();
					map.mute=1;
				}
			}else {
				muteNotify++;
			}
		};
		
		//-------------------------------------------------------------------
		self.unmuteNotify=function(msg){
			if(msg){
				let map;
				map = m_viewHubOn[msg];
				if (map) {
					map.mute-=1;
				}
			}else {
				muteNotify--;
			}
		};
	};
}
module$1.exports['once'];
//<<<<<<Node2Coke<<<<<<

//****************************************************************************
//:Parse URL params:
//****************************************************************************
{
	let pos;
	let appURL=document.location.href;
	let appParams={};
	VFACT.appParams=appParams;
	VFACT.appURL=document.location.href;
	VFACT.appPath=pathLib.dirname(document.location.pathname);
	VFACT.appOrigin=pathLib.dirname(document.location.origin);
	pos=appURL.indexOf("?");
	if(pos<0){
		pos=appURL.indexOf("#");
	}
	if(pos>0){
		let ptext,list;
		ptext=appURL.substring(pos+1);
		list=ptext.split("&");
		list.forEach(item=>{
			let subs,key,val;
			subs=item.split("=");
			if(subs.length===2){
				key=decodeURIComponent(subs[0]);
				val=decodeURIComponent(subs[1]);
				appParams[key]=val;
			}
		});
	}
	if(VFACT.appPath.startsWith("//")){
		VFACT.appFilePath=VFACT.appPath.substring(1);
	}else if(VFACT.appPath.startsWith("/~/")){
		VFACT.appFilePath=VFACT.appPath.substring(2);
	}
}

//****************************************************************************
//:Load CSS/Scripts:
//****************************************************************************
{
	let dynaScripts={};
	//--------------------------------------------------------------------
	VFACT.appendCSS=function(path){
		let pms=dynaScripts[path];
		if(pms){
			return pms;
		}
		pms=new Promise((resolve,reject)=>{
			let tag;
			tag=document.createElement('link');
			tag.rel="stylesheet";
			tag.href = document.location.origin+path;
			tag.type="text/css";
			document.getElementsByTagName('head')[0].appendChild(tag);
			//document.body.appendChild(tag);
			resolve();
		});
		dynaScripts[path]=pms;
		return pms;
	};

	//--------------------------------------------------------------------
	VFACT.appendScript=function(path){
		let pms=dynaScripts[path];
		if(pms){
			return pms;
		}
		pms=new Promise((resolve,reject)=>{
			let tag;
			tag=document.createElement('script');
			tag.onload = function () {
				resolve();
			};
			tag.onerror = function () {
				reject();
			};
			tag.src = document.location.origin+path;
			document.body.appendChild(tag);
		});
		dynaScripts[path]=pms;
		return pms;
	};
}

//****************************************************************************
//:Download dummy obj:
//****************************************************************************
{
	let webFileDownload;
	webFileDownload=document.createElement("a");
	webFileDownload.style.position="absolute";
	webFileDownload.style.top="-300px";
	webFileDownload.style.opacity="0";
	document.body.appendChild(webFileDownload);
	VFACT.webFileDownload=webFileDownload;
}

//****************************************************************************
//:CreateApp UI by uiDef and opts:
//****************************************************************************
let createApp=async function(){
	let appObj,appDef,path,pos;
	appDef={
		type:"obj",id:"FACTAppFrame",x:0,y:0,w:"100%",h:"100%",nameHost:1,traceSize:1,
	};
	appObj=VFACT.createObj(appDef,document.body);
	VFACT.makeNotify(appObj);
	//app basic info:
	appObj.appParams=VFACT.appParams;
	path=document.location.pathname;
	appObj.appPath=path;
	pos=path.lastIndexOf("/");
	appObj.appDir=path.substring(0,pos);
	makeObjEventEmitter(appObj);
	makeNotify(appObj);
	return appObj;
};

//----------------------------------------------------------------------------
//Init the app by major-UIDef and options, based on options setup Dialog, tip, 
//shortcuts and other basic features of App:
let initApp=async function(appObj,uiDef,opts={}){
	let uiDefs,appFrame;
	let dlgLayer;

	//setup default options:
	if(!("dialog" in opts)){
		opts.dialog=1;
	}

	if(!("tip" in opts)){
		opts.tip=1;
	}
	appFrame=appObj.appFrame=opts.appFrame||null;

	if(Array.isArray(uiDef)){
		uiDefs=uiDef;
	}else {
		uiDefs=[uiDef||{
			type:"obj",id:"MainUILayer",x:0,y:0,w:"100%",h:"100%",
		}];
	}

	appObj.OnAppCreate=function(){
		this.children[0];
		dlgLayer=this.DlgLayer;
	};

	//************************************************************************
	//Enable dialog feature?
	//************************************************************************
	let isShowDlg=0;
	let dlgList=[];
	if(opts.dialog){
		uiDefs.push({
			type:"box",id:"DlgLayer",x:0,y:0,w:"100%",h:"100%",zIndex:200,display:0,
			OnClick:function(evt){
				appObj.OnDlgBGClick(evt);
			}
		});
		//--------------------------------------------------------------------
		appObj.getDlg=function(){
			let idx=dlgList.length-1;
			return dlgList[idx];
		};
		
		//--------------------------------------------------------------------
		let dlgHash={};
		async function loadDlg(url){
			if(dlgHash[url]){
				return dlgHash[url];
			}
			try{
				dlgHash[url]=(await import(url)).default;
			}catch(err){
				return null;
			}
			return dlgHash[url];
		}
		
		//--------------------------------------------------------------------
		//Show dialog:
		appObj.showDlg=function(dlgFunc,vo,shared=1,callback=null){
			var dlgHud,dlgCSS,curDlg,checkBG;
			
			if(typeof(dlgFunc)==="string"){
				loadDlg(dlgFunc).then((func)=>{
					appObj.showDlg(func,vo,shared);
				});
				return;
			}
	
			//Show dialog BG:
			if(!isShowDlg) {
				dlgLayer.display=1;
				isShowDlg = 1;
				checkBG=1;
			}
			//If there is a dialog, make it mute to user input. New dialog will be on top of it:
			curDlg=dlgList.length>0?dlgList[dlgList.length-1]:null;
			if(curDlg){
				curDlg.uiEvent=-1;
			}
	
			if(dlgFunc.$_pptMap){//If dialog is already a vfact-ui-obj, make sure it can append to dlg-layer:
				dlgHud=dlgFunc;
				if(dlgHud.parent){
					dlgHud.hold();
					dlgHud.parent.removeChild(dlgHud);
				}
				dlgHud.display=true;
				dlgLayer.appendChild(dlgHud);
			}else if(shared){//If dialog is sharing instance, try use shared instance:
				dlgHud=dlgFunc.sharedDlg;
				if(!dlgHud) {
					dlgCSS = dlgFunc(appObj);
					dlgHud = dlgLayer.appendNewChild(dlgCSS);
					if (shared) {
						dlgFunc.sharedDlg = dlgHud;
						dlgHud.hold();
					}
				}else {
					dlgLayer.appendChild(dlgHud);
				}
			}else {
				dlgCSS = dlgFunc(appObj);
				dlgHud = dlgLayer.appendNewChild(dlgCSS);
				if (shared) {
					dlgFunc.sharedDlg = dlgHud;
				}
			}
			if(checkBG) {
				if (dlgHud.showDlgBGMask) {
					dlgLayer.color = [0, 0, 0, 0.5];
				} else {
					dlgLayer.color = [0, 0, 0, 0];
				}
			}
			dlgHud.uiEvent=1;
			dlgHud.showDlg && dlgHud.showDlg(vo);
			dlgList.push(dlgHud);
			dlgHud._dlgCallback=callback;
			return dlgHud;
		};
		
		//--------------------------------------------------------------------
		appObj.modalDlg=function(dlgFunc,vo,shared){
			return new Promise((resolve)=>{
				this.showDlg(dlgFunc,vo,shared,resolve);
			});
		};
	
		//--------------------------------------------------------------------
		//Close dialog:
		appObj.closeDlg=function(dlg,result){
			var idx,preDlg;
			if(!dlg){
				idx=dlgList.length-1;
				dlg=dlgList[idx];
			}else {
				idx=dlgList.indexOf(dlg);
			}
			if(idx<0){
				//The dialog is hiding
				return;
			}
			dlg.closeDlg && dlg.closeDlg(result);
			dlgLayer.removeChild(dlg);
			if(idx===dlgList.length-1){
				//This is the last one:
				preDlg=dlgList[idx-1];
				if(preDlg){
					preDlg.uiEvent=1;
				}
			}
			dlgList.splice(idx,1);
			//If no more dialog is showing, close dialog BG and layer:
			if(dlgList.length===0){
				dlgLayer.display=0;
				isShowDlg=0;
			}
			if(dlg._dlgCallback){
				dlg._dlgCallback(result);
				dlg._dlgCallback=null;
			}
		};
	
		//--------------------------------------------------------------------
		//Dialog BG been clicked:
		appObj.OnDlgBGClick=function(){
			let idx,dlg;
			idx=dlgList.length-1;
			dlg=dlgList[idx];
			if(dlg && dlg.OnBGClick){
				dlg.OnBGClick();
			}
		};
		
		//--------------------------------------------------------------------
		//Make an existing hud-item as an dialog:
		appObj.showFloatDlg=function(hud,bgColor){
			let curDlg;
			//Show dialog BG:
			if(!isShowDlg) {
				dlgLayer.display=1;
				isShowDlg = 1;
				dlgLayer.color = bgColor||[0, 0, 0, 0];
			}else {
				curDlg=dlgList.length>0?dlgList[dlgList.length-1]:null;
				if(curDlg){
					curDlg.uiEvent=-1;
				}
			}
			hud._orgZIndex=hud.zIndex;
			hud.zIndex=dlgLayer.zIndex+10;
			dlgList.push(hud);
		};
		
		//--------------------------------------------------------------------
		//Close a float-dialog:
		appObj.closeFloatDlg=function(dlg){
			var idx,preDlg;
			if(!dlg){
				idx=dlgList.length-1;
				dlg=dlgList[idx];
			}else {
				idx=dlgList.indexOf(dlg);
			}
			if(idx<0){
				//The dialog is hiding?
				if(dlgList.length===0){
					dlgLayer.display=0;
					isShowDlg=0;
				}
				return;
			}
			dlg.zIndex=dlg._orgZIndex;
			if(idx===dlgList.length-1){
				//This is the last one:
				preDlg=dlgList[idx-1];
				if(preDlg){
					preDlg.uiEvent=1;
				}
			}
			dlgList.splice(idx,1);
			//If no more dialog is showing, close dialog BG and layer:
			if(dlgList.length===0){
				dlgLayer.display=0;
				isShowDlg=0;
			}
		};
	}else {
		appObj.showDlg=function(){
			return null;
		};
	}
	
	//************************************************************************
	//Enable wait dialog featre
	//************************************************************************
	if(opts.dialog && opts.wait){
		let waitDlgDef,waitDlg,isShowWait;
		waitDlgDef=function(app){
			return {
				type:"box",id:"WaitDlg",x:0,y:0,w:"FW",h:"FH",background:[0,0,0,0.3],autoLayout:1,nameHost:1,
				children:[
					{
						type:"box",id:"BoxInfo",x:"FW/2",y:"FH/2",w:"FW>600?FW/2:300",h:80,anchorX:1,background:"#FFFFFF",shadow:1,shadowX:3,shadowY:8,shadowBlur:5,shadowColor:[0,0,0,0.3],
						children:[
							{
								type:"text",id:"TxtInfo",x:0,y:0,w:"FW",h:"FH",color:[0,0,0,1],fontSize:15,alignX:1,alignY:1,wrap:1,
								text:"Pleas wait..."
							}
						]
					}
				],
				OnCreate(){
					waitDlg=this;
				},
				showDlg(vo){
					let time=vo.time>=0?vo.time:500;
					waitDlg.BoxInfo.display=0;
					waitDlg.TxtInfo.text=vo.info||"Please wait";
					waitDlg.background=[0,0,0,0];
					setTimeout(()=>{
						waitDlg.background=[0,0,0,0.3];
						waitDlg.BoxInfo.display=1;
					},time);
				},
			};
		};
		
		//--------------------------------------------------------------------
		appObj.showWait=function(info,time=500){
			if(isShowWait){
				waitDlg.TxtInfo=info;
				return;//
			}
			isShowWait=1;
			appObj.showDlg(waitDlgDef,{info:info,time:time});
		};
		
		//--------------------------------------------------------------------
		appObj.closeWait=function(){
			if(!isShowWait){
				return;//
			}
			isShowWait=0;
			appObj.closeDlg(waitDlg);
		};
		
		//--------------------------------------------------------------------
		appObj.isWaiting=function(){
			return isShowWait;
		};
	}
	if(opts.mask);

	//************************************************************************
	//Enable tip feature?
	//************************************************************************
	if(opts.tip){
		let cssTipBox;
		const TIP_TIME=200;
		const TIP_LIFETIME=3000;
		let isTipShowing,tgtTipHud,tipTimer;
		let tipHud=null;
		let tipBox=null;
		opts.tip=1;
		cssTipBox=function()
		{
			var txtName,text="tip";
			var tipAlignH=1,tipAlignV=0;
			return {
				nameHost:1,
				type:"box",id:"TipBox",x:0,y:0,w:200,h:20,display:0,anchorX:0,anchorY:0,
				background:[50,50,50,1],corner:3,shadow:1,shadowX:1,shadowY:3,shadowBlur:5,shadowColor:[0,0,0,0.5],
				children:[{
					type:"text",id:"TxtName",x:0,y:0,w:"FW",h:"FH",autoLayout:1,
					text:text,fontSize:12,color:[255,255,255],bold:0,
					alignH:1,alignV:1
				}],
				faces:{},
				OnCreate:function(){
					tipBox=this;
					txtName=this.TxtName;
				},
				show:function(x,y,text,alignH=1,alignV=0,time=80){
					tipAlignH=alignH;
					tipAlignV=alignV;
					tipHud.x=x;
					tipHud.y=y;
					tipHud.text=text;
					tipHud.display=1;
					//y=tipHud.y;
					//tipHud.y=y-15;
					//TODO: Support ani:
					/*tipHud.animate({
						type:"in",
						dy:-15,alpha:0,
						time:time,
					});*/
					tipHud.animate({
						type:"ani",
						keyFrames:[
							{opacity:0},
							{opacity:1},
						],
						duration:time,
					});
				},
				hide:function(){
					this.display=0;
				},
				get $$text(){return text;},
				set $$text(newText){
					var x,y,w,h;
					text=newText;
					if(txtName) {
						txtName.text = text;
						w=txtName.textW;
						txtName.w=w+12;
						w=tipBox.w=w+12;
						h=tipBox.h;
						switch(tipAlignH){
							case 0:
								break;
							case 1:
								tipHud.x-=w/2;
								break;
							case 2:
								tipHud.x-=w;
								break;
						}
						switch(tipAlignV){
							case 0:
								break;
							case 1:
								tipHud.y-=h/2;
								break;
							case 2:
								tipHud.y-=h;
								break;
						}
						x=tipHud.x;y=tipHud.y;
						if(x<10){
							x=tipHud.x=10;
						}
						if(x+w+10>=appObj.clientWidth){
							x=tipHud.x=appObj.clientWidth-10-w;
						}
						/*if(x+w*0.5+10>=appObj.clientWidth){
							x=tipHud.x=appObj.clientWidth-10-w*0.5;
						}*/
						if(y<10){
							y=tipHud.y=10;
						}
						if(y+h+10>=appObj.clientHeight){
							y=tipHud.y=appObj.clientHeight-10-h;
						}
					}
				}
			};
		};
		//--------------------------------------------------------------------
		//About to show tip
		appObj.showTip=function(hud,tip,x,y,ah,av,time=TIP_TIME,life=TIP_LIFETIME){
			let rect;
			let w,h,asw,ash;
			if(hud===tgtTipHud){
				return;
			}
			if(isTipShowing){
				tipHud.hide();
			}
			if(tipTimer){
				window.clearTimeout(tipTimer);
			}
			tgtTipHud=hud;
			if(!hud)
				return;
			w=hud.w;h=hud.h;
			tipTimer=window.setTimeout(()=>{
				//Show tip:
				tipTimer=null;
				if(x===undefined){
					w=hud.w;h=hud.h;
					x=w/2;y=h+5;
				}
	
				rect=hud.getBoundingClientRect();
				if(w>0){
					asw=rect.width/w;
					x*=asw;
				}
				if(h>0){
					ash=rect.height/h;
					y*=ash;
				}
				x=rect.left+x;
				y=rect.top+y;
	
				if(!tipHud){
					tipHud=tipBox;
				}
				tipHud.show(x,y,tip,ah,av);
				isTipShowing=1;
				tipTimer=window.setTimeout(()=>{
					appObj.abortTip(hud);
				},life);
			},time);
		};
	
		//--------------------------------------------------------------------
		//Cancel about-showing tip:
		appObj.abortTip=function(hud){
			if(hud && hud!==tgtTipHud){
				return;
			}
			if(tipTimer){
				window.clearTimeout(tipTimer);
				tipTimer=null;
			}
			tgtTipHud=null;
			if(isTipShowing){
				this.hideTip();
			}
		};
	
		//--------------------------------------------------------------------
		//Hide current showing tip
		appObj.hideTip=function(){
			if(isTipShowing){
				tipHud.display=0;
				isTipShowing=0;
			}
		};

		uiDefs.push({
			type:"box",id:"TipLayer",x:0,y:0,w:"100%",h:"100%",zIndex:300,uiEvent:-1,
			children:[
				cssTipBox()
			]
		});
	}
	
	//************************************************************************
	//Enable hud layer? By default it's on:
	//************************************************************************
	if(opts.hud!==false){
		uiDefs.push({
			type:"box",id:"HudLayer",x:0,y:0,w:"100%",h:"100%",zIndex:500,uiEvent:-1,
			OnCreate(){
				appObj.hudLayer=this;
			}
		});
	}
	
	//************************************************************************
	//Enable shortcuts feature?
	//************************************************************************
	if(opts.shortcuts){
		let switchApping=0;
		let switchDocing=0;
		let switchDlg=null;
		let hotBox=null;
		let DlgTask=null;

		//Check if handle task shortcut:
		if(!appFrame){
			if(opts.DlgTask){
				DlgTask=opts.DlgTask;
			}
		}
		//--------------------------------------------------------------------
		//Set focus box
		appObj.setFocusBox=function(box){
			if(box===hotBox){
				return;
			}
			if(hotBox && hotBox.OnAppBlur){
				hotBox.OnAppBlur();
			}
			hotBox=box;
			if(hotBox && hotBox.OnAppFocus){
				hotBox.OnAppFocus();
			}
			appObj.emitNotify("FocusBox");
		};
	
		//--------------------------------------------------------------------
		//Get focus box:
		appObj.getFocusBox=function(){
			return hotBox;
		};
	
		//-------------------------------------------------------------------*
		//Handle key down events:
		appObj.OnKeyDown=function(e){
			var key,list,item,i,n,hotView;
	
			if(isShowDlg){
				hotView=dlgList.length>0?dlgList[dlgList.length-1]:null;
			}else {
				hotView=hotBox;
			}
			
			function checkShortcut(item){
				if(item.altKey!==e.altKey){
					return 0;
				}
				if(item.ctrlKey!==e.ctrlKey){
					return 0;
				}
				if(item.metaKey!==e.metaKey){
					return 0;
				}
				if(item.shiftKey!==e.shiftKey){
					return 0;
				}
				return 1;
			}
			key=e.code;
			list=opts.shortcuts[key];
			if(!list){
				key=""+e.keyCode;
				list=opts.shortcuts[key];
			}
			if(hotView && hotView.OnKeyDown){
				if(hotView.OnKeyDown(e.code,e)){
					return 1;
				}
			}
			if(list) {
				if (Array.isArray(list)) {
					n = list.length;
					for (i = 0; i < n; i++) {
						item = list[i];
						if (checkShortcut(item)) {
							//Handle shortcut:
							if(hotView && hotView.handleShortcut){
								if(hotView.handleShortcut(item.action,e)){
									return 1;
								}
							}
							//Handle app shortcut here:
							if(opts.handleShortcut){
								opts.handleShortcut(item.action,e);
							}
							return 0;
						}
					}
				} else {
					item = list;
					if (checkShortcut(item)) {
						if(hotView && hotView.handleShortcut){
							if(hotView.handleShortcut(item.action,e)){
								return 1;
							}
						}
						//Handle app shortcut here:
						if(opts.handleShortcut){
							if(opts.handleShortcut(item.action,e)){
								return 1;
							}
						}
						return 0;
					}
				}
			}
	
			//Handle alt-tab switch doc:
			if(e.key==="Tab" || e.code==="Escape"){
				if(e.altKey && !e.metaKey){
					//See if we can switch doc:
					if(appFrame){
						switchDlg=appFrame.app.showTaskDlg(e);
						if(switchDlg){
							switchApping=1;
							return 1;
						}
					}else if(DlgTask){
						appObj.showTaskDlg(e);
						return 1;
					}
				}
			}
			//Check internal doc switing:
			if(opts.switchDoc && e.code==="Escape"){
				if(e.ctrlKey && !e.metaKey){
					//See if we can switch doc:
					if(switchDocing){
						if(e.shiftKey){
							opts.switchDoc.pre();
						}else {
							opts.switchDoc.next();
						}
						return 1;
					}else {
						switchDocing=1;
						opts.switchDoc.start();
						return 1;
					}
				}
			}
			return 0;
		};
	
		//-------------------------------------------------------------------
		//Handle key-up events:
		appObj.OnKeyUp=function(e){
			let hotView=null;
			if(isShowDlg){
				hotView=dlgList.length>0?dlgList[dlgList.length-1]:null;
			}else {
				hotView=hotBox;
			}
			if(hotView && hotView.OnKeyUp){
				if(hotView.OnKeyUp(e.code,e)){
					return 1;
				}
			}
			if(switchApping && e.key==="Alt"){
				if(DlgTask){
					switchDlg.gotoTask();
				}else {
					switchDlg.gotoTask();
				}
				switchApping=0;
				switchDlg=null;
				return 1;
			}
			if(switchDocing && e.key==="ctrlKey"){
				opts.switchDoc.end();
				return 1;
			}
		};
		
		//--------------------------------------------------------------------
		appObj.showTaskDlg=function(evt){
			if(switchApping){
				if(evt.shiftKey){
					switchDlg.preTask();
				}else {
					switchDlg.nextTask();
				}
				return switchDlg;
			}
			if(!isShowDlg){
				switchApping=1;
				//Show the switch doc dialog:
				switchDlg=appObj.showDlg(DlgTask,{
					byShortCut:1,
					OnClosed(){
						switchApping=0;
						switchDlg=null;
					}
				});
				return switchDlg;
			}
			return null;
		};
		document.addEventListener("keydown",(evt)=>{
			if(appObj.OnKeyDown(evt)){
				evt.stopPropagation();
				evt.preventDefault();
			}
		});
		document.addEventListener("keyup",(evt)=>{
			if(appObj.OnKeyUp(evt)){
				evt.stopPropagation();
				evt.preventDefault();
			}
		});
	}
	
	if(opts.polishUIDefs){
		await opts.polishUIDefs(appObj,uiDefs);
	}

	//************************************************************************
	//Create AppUI:
	//************************************************************************
	{
		let uiDef;
		let frg=new DocumentFragment();
		frg.$_pxy=appObj;
		VFACT.pushNameHost(appObj);
		for(uiDef of uiDefs){
			VFACT.createObj(uiDef,frg);
		}		
		VFACT.popNameHost(appObj);
		appObj.webObj.appendChild(frg);
		appObj.OnAppCreate();
	}
	return appObj;
};

VFACT.createApp=createApp;
VFACT.initApp=initApp;

//Auto genterated by Cody
/*#{Imports*/
/*}#Imports*/
var cfgURL$2=import.meta.url;
/*#{StartDoc*/
/*}#StartDoc*/
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
//----------------------------------------------------------------------------
let appCfg$2=window.codyAppCfgs[cfgURL$2]||{//"jaxId":"1G9QH48EU2"
	"version":"0.0.1",
	"txtSize":{
		"small":12,"smallMid":14,"mid":16,"smallBig":18,"big":20,"smallLarge":24,"large":28,"smallLarger":32,"larger":36,"smallHuge":42,"huge":48,"bigHuge":56,
		"smallHuger":64,"huger":72,"bigHuger":80
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20,"naviLineH":28,"attrLineH":28,"cardLineH":48,"headerH":30
	},
	"color":{
		"primary":[13,110,253,1],"fontPrimary":[255,255,255,1],"fontPrimarySub":[13,110,253,1,80],"fontPrimaryLit":[13,110,253,1,50],"secondary":[108,117,125,1],
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[108,117,125,1,80],"fontSecondaryLit":[108,117,125,1,50],"body":[255,255,255,1],"fontBody":[0,0,0,1],
		"fontBodySub":[80,80,80,1],"fontBodyLit":[180,180,180,1],"lineBody":[0,0,0,1],"lineBodySub":[80,80,80,1],"lineBodyLit":[180,180,180,1],"lineBodyThin":[220,220,220,1],
		"success":[0,128,0,1],"fontSuccess":[255,255,255,1],"fontSuccessSub":[0,128,0,1,80],"fontSuccessLit":[0,128,0,1,50],"warning":[255,128,12,1],"fontWarning":[255,255,255,1],
		"fontWarningSub":[255,128,12,1,80],"fontWarningLit":[255,128,12,1,50],"fontDisable":[255,255,255,1],"fontDisableSub":[200,200,200,1,80],"disable":[200,200,200,1],
		"fontDisableLit":[200,200,200,1,50],"error":[240,0,0,1],"fontError":[255,255,255,1],"fontErrorSub":[240,0,0,1,80],"fontErrorLit":[240,0,0,1,50],"iconBtnOver":[13,110,253,1,80],
		"iconBtnDown":[13,110,253,1,60],"iconBtnUp":[255,255,255,0],"hot":[220,240,255,1],"iconFace":[50,50,50,1],"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))",
		"gntSelected":"linear-gradient(to right, rgba(180,180,180,1), 50%, rgba(180,180,180,0.1))","gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(180,180,180,0.1))",
		"gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))","gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))",
		"tool":[240,240,240,1],"fontTool":[0,0,0,1,-100],"fontToolSub":[240,240,240,1,-60],"fontToolLit":[82.32,82.32,82.32,1,-30],"gntLine":"linear-gradient(to right, rgba(80,80,80,1), 50%, rgba(80,80,80,0.1))",
		"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))","gntTarget":"linear-gradient(to right, rgba(255,100,255,1), 50%, rgba(255,0,255,0.5))"
	},
	"sharedAssets":"/~/-tabos/shared/assets","assetsDir":"/@editkit/assets",
	"desktopColors":{
		"0":[220,220,220,1],"1":[50,100,160,1],"2":[220,150,80,1],"3":[50,110,55,1],"4":[255,255,255,1]
	},
	"desktopColorIdx":0,
	"dockerColors":{
		"0":[82,94,107,1],"1":[198,77,13,1],"2":[15,107,34,11]
	},
	"dockerColor":{
		"0":82,"1":94,"2":107,"3":1
	},
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL$2]=appCfg$2;
appCfg$2.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg$2){
		for(attrName in appCfg$2){
			if(attrName in majorCfg){
				cAttr=appCfg$2[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else {
					appCfg$2[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg$2.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL$2]===appCfg$2){
		window.codyAppCfgs[cfgURL$2]=proxy;
	}
	appCfg$2=proxy;
};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "appCfg",
//	"jaxId": "1G9QH48EU0",
//	"editVersion": 4,
//	"attrs": {
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1G9QH48EU6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G9QH48EU1",
//			"editVersion": 1,
//			"attrs": {
//				"appCfg": {
//					"type": "object",
//					"jaxId": "1G9QH48EU2",
//					"editVersion": 18,
//					"attrs": {
//						"version": "0.0.1",
//						"txtSize": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU3",
//							"editVersion": 15,
//							"attrs": {
//								"small": {
//									"type": "auto",
//									"valText": "12"
//								},
//								"smallMid": {
//									"type": "auto",
//									"valText": "14"
//								},
//								"mid": {
//									"type": "auto",
//									"valText": "16"
//								},
//								"smallBig": {
//									"type": "auto",
//									"valText": "18"
//								},
//								"big": {
//									"type": "auto",
//									"valText": "20"
//								},
//								"smallLarge": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"large": {
//									"type": "auto",
//									"valText": "28"
//								},
//								"smallLarger": {
//									"type": "auto",
//									"valText": "32"
//								},
//								"larger": {
//									"type": "auto",
//									"valText": "36"
//								},
//								"smallHuge": {
//									"type": "auto",
//									"valText": "42"
//								},
//								"huge": {
//									"type": "auto",
//									"valText": "48"
//								},
//								"bigHuge": {
//									"type": "auto",
//									"valText": "56"
//								},
//								"smallHuger": {
//									"type": "auto",
//									"valText": "64"
//								},
//								"huger": {
//									"type": "auto",
//									"valText": "72"
//								},
//								"bigHuger": {
//									"type": "auto",
//									"valText": "80"
//								}
//							}
//						},
//						"size": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU4",
//							"editVersion": 16,
//							"attrs": {
//								"menuLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"pathLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"dockerW": {
//									"type": "auto",
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"type": "auto",
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"type": "auto",
//									"valText": "20"
//								},
//								"naviLineH": {
//									"type": "int",
//									"valText": "28"
//								},
//								"attrLineH": {
//									"type": "int",
//									"valText": "28"
//								},
//								"cardLineH": {
//									"type": "int",
//									"valText": "48"
//								},
//								"headerH": {
//									"type": "int",
//									"valText": "30"
//								}
//							}
//						},
//						"color": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU5",
//							"editVersion": 141,
//							"attrs": {
//								"primary": {
//									"type": "auto",
//									"valText": "[13,110,253,1]"
//								},
//								"fontPrimary": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"type": "auto",
//									"valText": "[13,110,253,1,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "auto",
//									"valText": "[13,110,253,1,50]"
//								},
//								"secondary": {
//									"type": "auto",
//									"valText": "[108,117,125,1]"
//								},
//								"fontSecondary": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"type": "auto",
//									"valText": "[108,117,125,1,80]"
//								},
//								"fontSecondaryLit": {
//									"type": "auto",
//									"valText": "[108,117,125,1,50]"
//								},
//								"body": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontBody": {
//									"type": "auto",
//									"valText": "[0,0,0,1]"
//								},
//								"fontBodySub": {
//									"type": "auto",
//									"valText": "[80,80,80,1]"
//								},
//								"fontBodyLit": {
//									"type": "auto",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBody": {
//									"type": "auto",
//									"valText": "[0,0,0,1]"
//								},
//								"lineBodySub": {
//									"type": "auto",
//									"valText": "[80,80,80,1]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBodyThin": {
//									"type": "colorRGBA",
//									"valText": "[220,220,220,1]"
//								},
//								"success": {
//									"type": "auto",
//									"valText": "[0,128,0,1]"
//								},
//								"fontSuccess": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"type": "auto",
//									"valText": "[0,128,0,1,80]"
//								},
//								"fontSuccessLit": {
//									"type": "auto",
//									"valText": "[0,128,0,1,50]"
//								},
//								"warning": {
//									"type": "auto",
//									"valText": "[255,128,12,1]"
//								},
//								"fontWarning": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"type": "auto",
//									"valText": "[255,128,12,1,80]"
//								},
//								"fontWarningLit": {
//									"type": "auto",
//									"valText": "[255,128,12,1,50]"
//								},
//								"fontDisable": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontDisableSub": {
//									"type": "auto",
//									"valText": "[200,200,200,1,80]"
//								},
//								"disable": {
//									"type": "auto",
//									"valText": "[200,200,200,1]"
//								},
//								"fontDisableLit": {
//									"type": "auto",
//									"valText": "[200,200,200,1,50]"
//								},
//								"error": {
//									"type": "auto",
//									"valText": "[240,0,0,1]"
//								},
//								"fontError": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontErrorSub": {
//									"type": "auto",
//									"valText": "[240,0,0,1,80]"
//								},
//								"fontErrorLit": {
//									"type": "auto",
//									"valText": "[240,0,0,1,50]"
//								},
//								"iconBtnOver": {
//									"type": "auto",
//									"valText": "[13,110,253,1,80]"
//								},
//								"iconBtnDown": {
//									"type": "auto",
//									"valText": "[13,110,253,1,60]"
//								},
//								"iconBtnUp": {
//									"type": "auto",
//									"valText": "[255,255,255,0]"
//								},
//								"hot": {
//									"type": "auto",
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"type": "auto",
//									"valText": "[50,50,50,1]"
//								},
//								"gntFocus": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))\""
//								},
//								"gntSelected": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(180,180,180,1), 50%, rgba(180,180,180,0.1))\""
//								},
//								"gntSelect": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(180,180,180,0.1))\""
//								},
//								"gntDlgHeader": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))\""
//								},
//								"gntHotText": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))\""
//								},
//								"tool": {
//									"type": "auto",
//									"valText": "[240,240,240,1]"
//								},
//								"fontTool": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-100]"
//								},
//								"fontToolSub": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-60]"
//								},
//								"fontToolLit": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-30]"
//								},
//								"gntLine": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(80,80,80,1), 50%, rgba(80,80,80,0.1))"
//								},
//								"gntLineBreak": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))\""
//								},
//								"gntTarget": {
//									"type": "colorRGBA",
//									"valText": "#\"linear-gradient(to right, rgba(255,100,255,1), 50%, rgba(255,0,255,0.5))\""
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "auto",
//							"valText": "\"/~/-tabos/shared/assets\""
//						},
//						"assetsDir": {
//							"type": "auto",
//							"valText": "\"/@editkit/assets\""
//						},
//						"desktopColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH52120",
//							"editVersion": 5,
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[220,220,220,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[50,100,160,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[220,150,80,1]"
//								},
//								"3": {
//									"type": "auto",
//									"valText": "[50,110,55,1]"
//								},
//								"4": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								}
//							}
//						},
//						"desktopColorIdx": {
//							"type": "auto",
//							"valText": "0"
//						},
//						"dockerColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH52121",
//							"editVersion": 3,
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[82,94,107,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[198,77,13,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[15,107,34,11]"
//								}
//							}
//						},
//						"dockerColor": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GMFI9OUF0",
//							"editVersion": 8,
//							"attrs": {
//								"0": {
//									"valText": "82"
//								},
//								"1": {
//									"valText": "94"
//								},
//								"2": {
//									"valText": "107"
//								},
//								"3": {
//									"valText": "1"
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//}

//Auto genterated by Cody
/*#{Imports*/
/*}#Imports*/
var cfgURL$1=import.meta.url;
/*#{StartDoc*/
/*}#StartDoc*/
let colors$1={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1],"disable":[200,200,200,1],"tool":[240,240,240,1]
};
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
//----------------------------------------------------------------------------
let appCfg$1=window.codyAppCfgs[cfgURL$1]||{//"jaxId":"1G8FNJVFK2"
	"version":"0.0.1",
	"txtSize":{
		"small":12,"smallMid":14,"mid":16,"smallBig":18,"big":20,"smallLarge":24,"large":28,"smallLarger":32,"larger":36,"smallHuge":42,"huge":48,"bigHuge":56,
		"smallHuger":64,"huger":72,"bigHuger":80
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20
	},
	"color":{
		"primary":colors$1.primary,"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors$1.primary,80],"fontPrimaryLit":[...colors$1.primary,50],"secondary":colors$1.secondary,
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors$1.secondary,80],"fontSecondaryLit":[...colors$1.secondary,50],"body":[255,255,255,1],"fontBody":[0,0,0,1],
		"fontBodySub":[80,80,80,1],"fontBodyLit":[180,180,180,1],"lineBody":[0,0,0,1],"lineBodySub":[80,80,80,1],"lineBodyLit":[180,180,180,1],"success":colors$1.success,
		"fontSuccess":[255,255,255,1],"fontSuccessSub":[...colors$1.success,80],"fontSuccessLit":[...colors$1.success,50],"warning":colors$1.warning,"fontWarning":[255,255,255,1],
		"fontWarningSub":[...colors$1.warning,80],"fontWarningLit":[...colors$1.warning,50],"disable":colors$1.disable,"fontDisable":[255,255,255,1],"fontDisableSub":[...colors$1.disable,80],
		"fontDisableLit":[...colors$1.disable,50],"error":colors$1.error,"fontError":[255,255,255,1],"fontErrorSub":[...colors$1.error,80],"fontErrorLit":[...colors$1.error,50],
		"iconBtnOver":[...colors$1.primary,80],"iconBtnDown":[...colors$1.primary,60],"iconBtnUp":[255,255,255,0],"hot":[220,240,255,1],"iconFace":[50,50,50,1],
		"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))","gntSelected":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))",
		"gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))","gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))",
		"gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))","tool":colors$1.tool,"fontTool":[...colors$1.tool,-100],
		"fontToolSub":[...colors$1.tool,-60],"fontToolLit":[...colors$1.tool,-30],"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
	},
	"sharedAssets":"/~/-tabos/shared/assets","assetsDir":"/@homekit/assets",
	"desktopColors":[
		[220,220,220,1],[50,100,160,1],[220,150,80,1],[50,110,55,1],[255,255,255,1]
	],
	"desktopColorIdx":0,
	"dockerColors":[
		[82,94,107,1],[147,52,77,1],[15,107,34,11]
	],
	"dockerColor":[82,94,107,1],
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL$1]=appCfg$1;
appCfg$1.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg$1){
		for(attrName in appCfg$1){
			if(attrName in majorCfg){
				cAttr=appCfg$1[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else {
					appCfg$1[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg$1.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL$1]===appCfg$1){
		window.codyAppCfgs[cfgURL$1]=proxy;
	}
	appCfg$1=proxy;
};

/*#{EndDoc*/
appCfg$1.getFileIcon=function(extName){
	return "/~/-tabos/shared/assets/filetype/file.svg";
};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "appCfg",
//	"jaxId": "1G8FNJVFK0",
//	"editVersion": 3,
//	"attrs": {
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1G8H0GUB50",
//			"editVersion": 1,
//			"attrs": {
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1G8H0GUB51",
//					"editVersion": 18,
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						},
//						"disable": {
//							"type": "colorRGBA",
//							"valText": "[200,200,200,1.00]"
//						},
//						"tool": {
//							"type": "colorRGBA",
//							"valText": "[240,240,240,1.00]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G8FNJVFK1",
//			"editVersion": 1,
//			"attrs": {
//				"appCfg": {
//					"type": "object",
//					"jaxId": "1G8FNJVFK2",
//					"editVersion": 65,
//					"attrs": {
//						"version": "0.0.1",
//						"txtSize": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK3",
//							"editVersion": 30,
//							"attrs": {
//								"small": {
//									"type": "int",
//									"valText": "12"
//								},
//								"smallMid": {
//									"type": "int",
//									"valText": "14"
//								},
//								"mid": {
//									"type": "int",
//									"valText": "16"
//								},
//								"smallBig": {
//									"type": "int",
//									"valText": "18"
//								},
//								"big": {
//									"type": "int",
//									"valText": "20"
//								},
//								"smallLarge": {
//									"type": "int",
//									"valText": "24"
//								},
//								"large": {
//									"type": "int",
//									"valText": "28"
//								},
//								"smallLarger": {
//									"type": "int",
//									"valText": "32"
//								},
//								"larger": {
//									"type": "int",
//									"valText": "36"
//								},
//								"smallHuge": {
//									"type": "int",
//									"valText": "42"
//								},
//								"huge": {
//									"type": "int",
//									"valText": "48"
//								},
//								"bigHuge": {
//									"type": "int",
//									"valText": "56"
//								},
//								"smallHuger": {
//									"type": "int",
//									"valText": "64"
//								},
//								"huger": {
//									"type": "int",
//									"valText": "72"
//								},
//								"bigHuger": {
//									"type": "int",
//									"valText": "80"
//								}
//							}
//						},
//						"size": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK4",
//							"editVersion": 12,
//							"attrs": {
//								"menuLineH": {
//									"type": "int",
//									"valText": "24"
//								},
//								"pathLineH": {
//									"type": "int",
//									"valText": "24"
//								},
//								"dockerW": {
//									"type": "int",
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"type": "int",
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"type": "int",
//									"valText": "20"
//								}
//							}
//						},
//						"color": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK5",
//							"editVersion": 467,
//							"attrs": {
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,50]"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,50]"
//								},
//								"body": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "[80,80,80,1]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "[80,80,80,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1.00]"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,50]"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,50]"
//								},
//								"disable": {
//									"type": "colorRGBA",
//									"valText": "#colors.disable"
//								},
//								"fontDisable": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontDisableSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.disable,80]"
//								},
//								"fontDisableLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.disable,50]"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,50]"
//								},
//								"iconBtnOver": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"iconBtnDown": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,60]"
//								},
//								"iconBtnUp": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,0.0]"
//								},
//								"hot": {
//									"type": "colorRGBA",
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"type": "colorRGBA",
//									"valText": "[50,50,50,1.00]"
//								},
//								"gntFocus": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))"
//								},
//								"gntSelected": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntSelect": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntDlgHeader": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))"
//								},
//								"gntHotText": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))"
//								},
//								"tool": {
//									"type": "colorRGBA",
//									"valText": "#colors.tool"
//								},
//								"fontTool": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-100]"
//								},
//								"fontToolSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-60]"
//								},
//								"fontToolLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-30]"
//								},
//								"gntLineBreak": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "string",
//							"valText": "/~/-tabos/shared/assets"
//						},
//						"assetsDir": {
//							"type": "string",
//							"valText": "/@homekit/assets"
//						},
//						"desktopColors": {
//							"type": "array",
//							"def": "RGBAArray",
//							"attrs": [
//								{
//									"type": "colorRGBA",
//									"valText": "[220,220,220,1.00]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(50,100,160,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(220,150,80,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(50,110,55,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								}
//							]
//						},
//						"desktopColorIdx": {
//							"type": "int",
//							"valText": "0"
//						},
//						"dockerColors": {
//							"type": "array",
//							"def": "RGBAArray",
//							"attrs": [
//								{
//									"type": "colorRGBA",
//									"valText": "[82, 94, 107,1]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[147,52,77,1]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[15,107,34,11]"
//								}
//							]
//						},
//						"dockerColor": {
//							"type": "colorRGBA",
//							"valText": "[82, 94, 107,1]"
//						}
//					}
//				}
//			}
//		}
//	}
//}

let BtnIcon$1=function(app,w,h,image,pad){let $ln,cfgColor,cfgSize,txtSize,state,cssVO,self;return $ln=appCfg$1.lanCode||"EN",cfgColor=appCfg$1.color,cfgSize=appCfg$1.size,txtSize=appCfg$1.txtSize,state={image:image},state=VFACT.flexState(state),cssVO={hash:"1G1KK6QLK7",nameHost:!0,type:"button",x:137,y:71,w:w,h:h||w,styleClass:"",children:[{hash:"1G8JQOV7P0",type:"box",id:"BoxBG",x:0,y:0,w:"FW",h:"FH",uiEvent:-1,styleClass:"",background:cfgColor.iconBtnUp,borderColor:cfgColor.primary,corner:w>20?5:3},{hash:"1G8JQRPD60",type:"box",id:"BoxIcon",x:pad,y:pad,w:w-2*pad,h:(h||w)-2*pad,uiEvent:-1,styleClass:"",background:cfgColor.fontBody,maskImage:$P((()=>state.image),state)}],get $$image(){return state.image},set $$image(v){state.image=v;},faces:{up:{"#1G8JQOV7P0":{background:cfgColor.iconBtnUp},"#1G8JQRPD60":{w:w-2*pad,h:(h||w)-2*pad,x:pad,y:pad,background:cfgColor.fontBody}},over:{"#1G8JQOV7P0":{background:cfgColor.iconBtnOver},"#1G8JQRPD60":{w:w-2*pad,h:(h||w)-2*pad,x:pad,y:pad}},down:{"#1G8JQOV7P0":{background:cfgColor.iconBtnDown},"#1G8JQRPD60":{x:pad+1,y:pad+1,w:w-2*pad-2,h:(h||w)-2*pad-2}},gray:{"#1G8JQOV7P0":{background:cfgColor.iconBtnUp},"#1G8JQRPD60":{x:pad,y:pad,w:w-2*pad,h:(h||w)-2*pad,background:cfgColor.fontBodyLit}},focus:{"#1G8JQOV7P0":{border:2}},blur:{"#1G8JQOV7P0":{border:0}}},OnCreate:function(){self=this;}},cssVO.OnButtonDown=function(){self.tip&&app.showTip&&app.abortTip(self);},cssVO.OnMouseInOut=function(isIn){self.tip&&app.showTip&&(isIn?app.showTip(self,self.tip,self.w/2,self.h+5,1,0):app.abortTip(self));},cssVO};BtnIcon$1.gearExport={framework:"vfact",hudType:"button",showName:"Mono Icon Button ",icon:"gears.svg",initW:32,initH:32,catalog:"Buttons",args:{app:{name:"app",showName:"app",type:"auto",key:!0,fixed:!0,initVal:null,localizable:void 0},w:{name:"w",showName:"w",type:"int",key:!0,fixed:!0,initVal:32,localizable:void 0},h:{name:"h",showName:"h",type:"int",key:!0,fixed:!0,initVal:32,localizable:void 0},image:{name:"image",showName:"image",type:"string",key:!0,fixed:!0,initVal:"/~/-tabos/shared/assets/folder.svg",localizable:void 0},pad:{name:"pad",showName:"pad",type:"int",key:!0,fixed:!0,initVal:1,localizable:void 0}},state:{image:{name:"image",type:"string",initVal:"/~/-tabos/shared/assets/folder.svg"}},properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","margin","attach","enable","drag"],faces:["up","over","down","gray","focus","blur"]};

let MenuLine=function(item){let cfgColor,cfgSize,txtSize,cssVO,self;appCfg$1.lanCode||"EN",cfgColor=appCfg$1.color,cfgSize=appCfg$1.size,txtSize=appCfg$1.txtSize;let colors=appCfg$1.darkMode?appCfg$1.colorDK:appCfg$1.color;return cssVO={hash:"1G3UMIA9M6",nameHost:!0,type:"button",x:0,y:0,w:"FW",h:cfgSize.menuLineH,autoLayout:!0,padding:[0,5,0,5],styleClass:"",enable:"enable"in item?item.enable:1,contentLayout:"flex-x",children:[{hash:"1G3UMN4AU0",type:"box",x:0,y:0,w:"FW",h:"FH",autoLayout:!0,display:0,styleClass:"",background:colors.hot},{hash:"1G3VB8GI90",type:"box",id:"BoxIcon",position:"relative",x:0,y:1,w:"FH-2",h:"FH-2",styleClass:"",background:colors.iconFace,shadowColor:[0,0,0,1],maskImage:item.icon?item.icon.indexOf("/")>=0?item.icon:appCfg$1.assetsDir+"/"+item.icon:"",attached:!!item.icon},{hash:"1GCMNLHLO0",type:"hud",id:"BoxColor",position:"relative",x:0,y:1,w:"FH-2",h:"FH-2",margin:[0,0,0,5],styleClass:"",attached:item.color,children:[{hash:"1GCMNMI320",type:"image",x:0,y:0,w:"FW",h:"FH",styleClass:"",image:appCfg$1.sharedAssets+"/checker.svg",fitSize:!0},{hash:"1GCMNNMDQ0",type:"box",x:0,y:0,w:"FW",h:"FH",styleClass:"",background:item.color||[255,255,255,1],border:1,borderColor:cfgColor.lineBody}]},{hash:"1G3UND5OR0",type:"text",id:"TxtText",position:"relative",x:0,y:0,w:"",h:"100%",styleClass:"",color:colors.textDlg,text:item.text,fontSize:txtSize.smallMid,fontWeight:"normal",fontStyle:"normal",textDecoration:"",alignV:1,contentLayout:"flex-x"},{hash:"1G3VBJ04B0",type:"box",id:"BoxCheck",x:"FW-10",y:3,w:"FH-6",h:"FH-6",anchorX:2,styleClass:"",background:colors.iconFace,maskImage:appCfg$1.assetsDir+"/check.svg",attached:!!item.checked}],faces:{up:{"#self":{alpha:1},"#1G3UMN4AU0":{display:0}},down:{"#1G3UMN4AU0":{display:1}},over:{"#1G3UMN4AU0":{display:1}},gray:{"#self":{alpha:.5},"#1G3UMN4AU0":{display:0}}},OnCreate:function(){self=this,this.preferW=self.TxtText.textW+50;}},cssVO};

let DlgMenu$1=function(app){let cssVO,self;appCfg$1.lanCode||"EN";let lineH,dlgVO=null;return cssVO={hash:"1G3VJR35A7",nameHost:!0,type:"box",x:60,y:77,w:100,h:100,overflow:1,styleClass:"",background:[255,255,255,1],border:1,shadow:!0,shadowX:3,shadowY:5,shadowBlur:6,shadowSpread:2,shadowColor:[0,0,0,.3],faces:{},OnCreate:function(){self=this,self.h="",lineH=appCfg$1.size.menuLineH;}},cssVO.showDlg=function(vo){let x,y,w,h,list,i,n,item,mx,my,maxW,orgHud=vo.hud;if(dlgVO=vo,orgHud){let webObj,rect,asW,asH;webObj=orgHud.webObj,rect=webObj.getBoundingClientRect(),asW=orgHud.w>=0?rect.width/orgHud.w:1,asH=orgHud.h>=0?rect.height/orgHud.h:1,x=rect.left+(vo.x*asW||0),y=rect.top+(vo.y*asH||orgHud.h*asH),self.w=vo.w||(orgHud.w>120?orgHud.w:120);}else x=vo.x||0,y=vo.y||0,self.w=vo.w||120;for(self.clearChildren(),list=vo.items,n=list.length,vo.maxLines?n>vo.maxLines?(h=vo.maxLines*lineH+6,self.overflow=[0,2]):(h=n*lineH+6,self.overflow=[0,0]):(h=n*lineH+6,self.h=h-15,self.overflow=[0,0]),maxW=0,i=0;i<n;i++)item=list[i],item=this.appendNewChild({type:MenuLine(item),x:0,y:2+i*lineH,item:item,OnClick:function(e){return self.OnClick(this.item,e),1}}),item.preferW>maxW&&(maxW=item.preferW);switch(self.w<maxW&&(self.w=maxW),w=self.w,vo.anchorH){case 0:default:break;case 1:x-=.5*w;break;case 2:x-=w;}switch(vo.anchorV){case 0:default:break;case 1:y-=.5*h;break;case 2:y-=h;}mx=app.clientW-10,my=app.clientH-10,x=x<0?0:x+w>mx?mx-w:x,y=y<0?0:y+h>my?my-h:y,self.x=x,self.y=y,self.animate({type:"pose",h:h,time:80});},cssVO.OnClick=function(item,evt){app.closeDlg(self,item),window.setTimeout((()=>{dlgVO.callback&&dlgVO.callback(item,evt);}),0);},cssVO.OnBGClick=function(){app.closeDlg(self),dlgVO.callback&&dlgVO.callback(null);},cssVO.handleShortcut=function(cmd){if("Escape"===cmd)return app.closeDlg(self),dlgVO.callback&&dlgVO.callback(null),!0},cssVO};

function packPreview(){}

//Auto genterated by Cody
/*}#1H2VOVHFO0StartDoc*/
//----------------------------------------------------------------------------
let UIView=function(uiDef){
	let cfgColor,txtSize,state;
	let cssVO,self;
	let boxUI,boxDevice,boxHud,boxTouch,faceList,btnFace,btnDevice,edW,edH,txtZoom;
	
	appCfg$2.lanCode||'EN';
	cfgColor=appCfg$2.color;
	txtSize=appCfg$2.txtSize;
	
	let app=window.tabOSApp;
	let mobile=app.width<500;
	let isNaked=false;
	let assets="pvassets";
	
	/*#{1H2VOVHFO1LocalVals*/
	let pvUIObj=null;
	let faces=[];
	let createArgs;
	let rootFace=null;
	let curFace=null;	
	let designW,designH;
	let clean=true;
	VFACT.appFilePath;
	isNaked=packPreview.length<2;
	/*}#1H2VOVHFO1LocalVals*/
	
	/*#{1H2VOVHFO1PreState*/
	/*}#1H2VOVHFO1PreState*/
	state={
		"faceLog":"",
		/*#{1H2VOVHFP3ExState*/
		/*}#1H2VOVHFP3ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H2VOVHFO1PostState*/
	/*}#1H2VOVHFO1PostState*/
	cssVO={
		"hash":"1H2VOVHFO1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H2VP0R4V0",
				"type":"hud","id":"BoxUI","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":1,"styleClass":"",
				children:[
					{
						"hash":"1H390GGLS0",
						"type":"text","x":5,"y":5,"w":100,"h":20,"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>("Face: "+state.faceLog),state),"fontSize":txtSize.mid,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1H2VR7I5R0",
						"type":"box","id":"BoxDevice","x":200,"y":100,"w":375,"h":750,"scale":0.5,"styleClass":"","background":[255,255,255,1],"shadow":true,"shadowY":3,
						"shadowBlur":6,
						children:[
							{
								"hash":"1H2VRDAEI0",
								"type":"hud","id":"BoxHud","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
							}
						],
					},
					{
						"hash":"1H34AHRPL0",
						"type":"hud","id":"BoxTouch","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
					},
					{
						"hash":"1H39266GK0",
						"type":"box","id":"BoxPlay","x":"50%","y":">calc(100% - 45px)","w":120,"h":40,"anchorX":1,"styleClass":"","background":[255,255,255,1],"border":1,
						"borderColor":cfgColor.fontBodyLit,"corner":20,"shadow":true,"shadowX":0,"shadowY":3,"shadowBlur":6,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-x",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1H392B3KM0",
								"type":BtnIcon$1(app,32,32,assets+"/undo.svg",1),"id":"BtnNaviReset","position":"relative","x":0,"y":0,
								"tip":"Reset UI",
								"OnClick":function(event){
									/*#{1H3971K360FunctionBody*/
									self.resetUI();
									/*}#1H3971K360FunctionBody*/
								},
							},
							{
								"hash":"1H392EVVR0",
								"type":BtnIcon$1(app,32,32,assets+"/arrowleft.svg",1),"id":"BtnNaviBack","position":"relative","x":0,"y":0,
								"tip":"Back",
								"OnClick":function(event){
									/*#{1H39842S50FunctionBody*/
									self.naviBack();
									/*}#1H39842S50FunctionBody*/
								},
							},
							{
								"hash":"1H392H3330",
								"type":BtnIcon$1(app,32,32,assets+"/arrowright.svg",1),"id":"BtnNaviNext","position":"relative","x":0,"y":0,
								"tip":"Next",
								"OnClick":function(event){
									/*#{1H398508O0FunctionBody*/
									self.naviNext();
									/*}#1H398508O0FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1H2VP2LRF0",
				"type":"hud","id":"BoxSide","x":0,"y":30,"w":280,"h":">calc(100% - 30px)","display":0,"styleClass":"",
				children:[
					{
						"hash":"1H2VP420F0",
						"type":"hud","id":"BoxFaces","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
						children:[
							{
								"hash":"1H2VP9GIU0",
								"type":"box","id":"Top","x":0,"y":0,"w":"100%","h":30,"padding":5,"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],"contentLayout":"flex-x",
								children:[
									{
										"hash":"1H2VPC2IR0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,10,0,0],"styleClass":"","color":[0,0,0],"text":"Faces:","fontSize":txtSize.smallMid,
										"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H2VRLUBO0",
										"type":BtnIcon$1(null,28,28,assets+"/close.svg",3),"id":"BtnCloseFace","x":">calc(100% - 5px)","y":"50%","anchorY":1,"anchorX":2,
										"OnClick":function(event){
											/*#{1H34ADPD40FunctionBody*/
											self.hideFaceList();
											/*}#1H34ADPD40FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H2VPLCK70",
								"type":"hud","id":"FaceList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"hidden scroll","styleClass":"","contentLayout":"flex-y",
							}
						],
					},
					{
						"hash":"1H349Q9B00",
						"type":"box","id":"Line","x":"100%","y":0,"w":1,"h":"100%","styleClass":"","background":cfgColor.fontBodySub,
					}
				],
			},
			{
				"hash":"1H2VS1PMT0",
				"type":"box","id":"Header","x":0,"y":0,"w":"100%","h":30,"padding":5,"styleClass":"","background":cfgColor.tool,"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],
				"contentLayout":"flex-x",
				children:[
					{
						"hash":"1H349TUC20",
						"type":BtnIcon$1(app,28,28,assets+"/menu.svg",0),"id":"BtnFace","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,20,0,0],
						"tip":"Show faces",
						"OnClick":function(event){
							/*#{1H34A8N2R0FunctionBody*/
							self.showFaceList();
							/*}#1H34A8N2R0FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMU4",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":cfgColor.fontBodySub,"text":"Device:","fontSize":txtSize.smallMid,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1H2VS1PMT2",
						"type":BtnIcon$1(app,26,26,assets+"/btncombo.svg",1),"id":"BtnDevice","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":"Choose Device",
						"OnClick":function(event){
							/*#{1H358IN630FunctionBody*/
							self.chooseSize();
							/*}#1H358IN630FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMU9",
						"type":"edit","id":"EdW","position":"relative","x":0,"y":0,"w":40,"h":"100%","styleClass":"","text":"375","color":[0,0,0],"outline":0,"border":[0,0,1,0],
						"OnUpdate":function(){
							/*#{1H357M5CO0FunctionBody*/
							self.applySize();
							/*}#1H357M5CO0FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMV0",
						"type":"text","position":"relative","x":2,"y":0,"w":"","h":"100%","margin":[0,5,0,3],"styleClass":"","color":[0,0,0],"text":"x","fontWeight":"normal",
						"fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					},
					{
						"hash":"1H2VS1PMV5",
						"type":"edit","id":"EdH","position":"relative","x":0,"y":0,"w":40,"h":"100%","margin":[0,20,0,0],"styleClass":"","text":"750","color":[0,0,0],"outline":0,
						"border":[0,0,1,0],
						"OnUpdate":function(){
							/*#{1H357MCAE0FunctionBody*/
							self.applySize();
							/*}#1H357MCAE0FunctionBody*/
						},
					},
					{
						"hash":"1H35A7MM30",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":cfgColor.fontBodySub,"text":"Zoom:","fontSize":txtSize.smallMid,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1H35A826R0",
						"type":BtnIcon$1(app,26,26,assets+"/dec.svg",1),"id":"BtnZoomOut","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":"Zoom out",
						"OnClick":function(event){
							/*#{1H35A826R7FunctionBody*/
							self.stepZoom(-1);
							/*}#1H35A826R7FunctionBody*/
						},
					},
					{
						"hash":"1H35A87850",
						"type":"text","id":"TxtZoom","position":"relative","x":0,"y":0,"w":50,"h":"100%","cursor":"pointer","styleClass":"","color":[0,0,0],"text":"100%",
						"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"underline","alignH":1,"alignV":1,
						"OnClick":function(event){
							/*#{1H35ASSRE0FunctionBody*/
							self.chooseZoom();
							/*}#1H35ASSRE0FunctionBody*/
						},
					},
					{
						"hash":"1H35A9QIV0",
						"type":BtnIcon$1(app,26,26,assets+"/inc.svg",1),"id":"BtnZoomIn","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":"Zoom in",
						"OnClick":function(event){
							/*#{1H35A9QIV7FunctionBody*/
							self.stepZoom(1);
							/*}#1H35A9QIV7FunctionBody*/
						},
					},
					{
						"hash":"1H34AB4KC0",
						"type":BtnIcon$1(app,28,28,assets+"/send.svg",3),"id":"BtnShare","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,20],"attached":isNaked?false:true,
						"tip":"Share preview...",
						"OnClick":function(event){
							/*#{1H3KT44I10FunctionBody*/
							self.sharePreview();
							/*}#1H3KT44I10FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H2VOVHFO1ExtraCSS*/
		/*}#1H2VOVHFO1ExtraCSS*/
		faces:{
			"hideSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"x":0,"w":"100%"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":0
				},
				/*#{1H33URP2G0Code*/
				/*}#1H33URP2G0Code*/
			},"showSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"x":280,"w":">calc(100% - 280px)"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":1
				},
				/*#{1H33USAD90Code*/
				/*}#1H33USAD90Code*/
			},"pause":{
				/*BtnNaviReset*/"#1H392B3KM0":{
					"enable":false
				},
				/*BtnNaviBack*/"#1H392EVVR0":{
					"enable":false
				},
				/*BtnNaviNext*/"#1H392H3330":{
					"enable":false
				}
			},"resume":{
				/*BtnNaviReset*/"#1H392B3KM0":{
					"enable":true
				},
				/*BtnNaviBack*/"#1H392EVVR0":{
					"enable":true
				},
				/*BtnNaviNext*/"#1H392H3330":{
					"enable":true
				}
			},"mobile":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"display":1,"x":0,"w":"100%"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":0,"w":"100%"
				},
				/*BtnFace*/"#1H349TUC20":{
					"enable":true
				},
				"#1H2VS1PMU4":{
					"display":0
				},
				"#1H35A7MM30":{
					"display":0
				},
				/*TxtZoom*/"#1H35A87850":{
					"w":""
				},
				/*BtnShare*/"#1H34AB4KC0":{
					"display":0
				}
			},"mobileSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"display":0
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":1
				},
				/*BtnFace*/"#1H349TUC20":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxUI=self.BoxUI;boxDevice=self.BoxDevice;boxHud=self.BoxHud;boxTouch=self.BoxTouch;faceList=self.FaceList;btnFace=self.BtnFace;btnDevice=self.BtnDevice;edW=self.EdW;edH=self.EdH;txtZoom=self.TxtZoom;			/*#{1H2VOVHFO1Create*/
			let gearExport=uiDef.gearExport;
			let defArgs=gearExport.args;
			let args,name,arg;
			let iconURL=assets+"/faces.svg";
			
			faces=gearExport.faces||[];
			faces=faces.map((item)=>{return {
				...item,text:item.name,icon:iconURL,
			}});
			if(mobile){
				self.showFace("mobile");
			}
			{
				let frameW,frameH,deviceW,deviceH;
				frameW=app.width;
				frameH=app.height-30;
				designW=deviceW=gearExport.deviceW;
				designH=deviceH=gearExport.deviceH;
				boxDevice.w=deviceW;
				boxDevice.h=deviceH;
				edW.text=""+deviceW;
				edH.text=""+deviceH;
				self.fitDevice(frameW,frameH,true,false);
			}			
			VFACT.applyMoveDrag(boxTouch,boxDevice);
			
			args=[];
			for(name in defArgs){
				arg=defArgs[name];
				args.push(arg.initVal);
			}
			createArgs=args;
			self.resetUI();
			//Find preview-entry:
			{
				let face;
				for(face of faces){
					if(face.entry===true){
						self.showPVFace(face);
						break;
					}
				}
			}
			/*}#1H2VOVHFO1Create*/
		},
		/*#{1H2VOVHFO1EndCSS*/
		/*}#1H2VOVHFO1EndCSS*/
	};
	/*#{1H2VOVHFO1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showPVFace=function(faceObj,justShow=false){
		if(typeof(faceObj)==="string"){
			faceObj=faces.find((face)=>{return face.name===faceObj});
			if(!faceObj){
				return;
			}
		}
		if(justShow){
			pvUIObj.showFace(faceObj.name);
			return;
		}
		if(!clean){
			if(faceObj.entry){
				self.resetUI();
			}else {
				state.faceLog+=">>";
			}
		}
		pvUIObj.showFace(faceObj.name);
		if(faceObj.entry){
			rootFace=faceObj;
		}
		clean=false;
		state.faceLog+=faceObj.name;
		curFace=faceObj;
		if(faceObj.time>0){
			self.showFace("pause");
			setTimeout(()=>{
				self.showFace("resume");
			},faceObj.time+200);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.resetUI=function(){
		let uiDefVO=uiDef.apply(null,createArgs);
		boxHud.clearChildren();
		pvUIObj=boxHud.appendNewChild(uiDefVO);
		clean=true;
		rootFace=null;
		state.faceLog="";
	};
	
	//------------------------------------------------------------------------
	cssVO.naviBack=function(){
		if(rootFace){
			self.showPVFace(rootFace);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.naviNext=function(){
		let face;
		if(curFace && curFace.next){
			self.showPVFace(curFace.next);
			return;
		}else if(rootFace){
			let i,n;
			n=faces.length;
			i=faces.indexOf(rootFace);
			for(i=i+1;i<n;i++){
				face=faces[i];
				if(face.entry===true){
					self.showPVFace(face);
					return;
				}
			}
		}
		for(face of faces){
			if(face.entry===true){
				self.showPVFace(face);
				break;
			}
		}
		
	};
	
	//------------------------------------------------------------------------
	cssVO.showFaceList=function(){
		let i,n,stub,def;
		if(mobile){
			self.showFace("mobileSide");
		}else {
			self.showFace("showSide");
			self.fitDevice(0,0,true,false);
		}
		faceList.clearChildren();
		def={
			type:MenuLine({text:"Reset",icon:assets+"/undo.svg"}),faceStub:stub,position:"relative",margin:[3,0,3,0],
			OnClick(){
				self.resetUI();
				if(mobile){
					self.hideFaceList();
				}
			}
		};
		faceList.appendNewChild(def);
		n=faces.length;
		for(i=0;i<n;i++){
			stub=faces[i];
			def={
				type:MenuLine(stub),faceStub:stub,position:"relative",margin:[3,0,3,0],
				OnClick(){
					self.showPVFace(this.faceStub);
					if(mobile){
						self.hideFaceList();
					}
				}
			};
			faceList.appendNewChild(def);
		}
		btnFace.enable=false;
	};
	
	//------------------------------------------------------------------------
	cssVO.hideFaceList=function(){
		if(mobile){
			self.showFace("mobile");
		}else {
			self.showFace("hideSide");
			self.fitDevice(0,0,true,false);
		}
		btnFace.enable=true;
	};
	
	//------------------------------------------------------------------------
	cssVO.applySize=function(){
		let w,h;
		w=parseInt(edW.text);
		h=parseInt(edH.text);
		if(w>0){
			boxDevice.w=w;
		}
		if(h>0){
			boxDevice.h=h;
		}
		self.resetUI();
		self.fitDevice(0,0,true,false);
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseSize=function(){
		app.showDlg(DlgMenu$1,{
			hud:btnDevice,
			items:[
				{text:`Deisgn: ${designW}x${designH}`,w:designW,h:designH},
				{text:"iPhone 320x480",w:320,h:480},
				{text:"iPhone 375x500",w:375,h:500},
				{text:"iPhone 375x750",w:375,h:750},
				{text:"iPad 768x1024",w:768,h:1024},
				{text:"iPad 1024x768",w:1024,h:768},
				{text:"Desktop 800x600",w:800,h:600},
				{text:"Desktop 1200x900",w:1200,h:900},
			],
			callback(item){
				if(!item)
					return;
				boxDevice.w=item.w;
				boxDevice.h=item.h;
				edW.text=""+item.w;
				edH.text=""+item.h;
				self.resetUI();
				self.fitDevice(0,0,true,false);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseZoom=function(){
		app.showDlg(DlgMenu$1,{
			hud:txtZoom,
			items:[
				{text:"Fit Device",scale:-1},
				{text:"10%",scale:10},
				{text:"30%",scale:30},
				{text:"50%",scale:50},
				{text:"75%",scale:75},
				{text:"100%",scale:100},
				{text:"150%",scale:150},
				{text:"200%",scale:200},
				{text:"300%",scale:300},
			],
			callback(item){
				let scale;
				if(!item)
					return;
				scale=item.scale;
				if(scale<0){
					self.fitDevice(0,0,false,true);
				}else {
					txtZoom.text=scale+"%";
					scale/=100;
					boxDevice.animate({type:"pose",scale:scale,time:50});
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.stepZoom=function(dir){
		let scale=boxDevice.scale;
		scale=Math.floor(scale*100);
		scale+=dir*5;
		scale=scale<5?5:scale;
		scale=scale>500?500:scale;
		txtZoom.text=scale+"%";
		scale/=100;
		boxDevice.animate({type:"pose",scale:scale,time:50});
	};
	
	//------------------------------------------------------------------------
	cssVO.fitDevice=function(frameW,frameH,move,ani){
		let deviceW,deviceH,dw,dh;
		let x,y,scale;
		frameW=frameW||boxUI.clientW;
		frameH=(frameH||boxUI.clientH)-20;
	
		deviceW=boxDevice.w;
		deviceH=boxDevice.h;
		dw=frameW-deviceW;
		dh=frameH-deviceH;
		if(dw>20 && dh>20){
			x=dw*0.5;
			y=dh*0.5;
			scale=1;
		}else {
			let sw,sh;
			sw=(frameW-20)/(deviceW);
			sh=(frameH-20)/(deviceH);
			scale=sw<sh?sw:sh;
			scale=Math.floor(scale*100)/100;
			x=(frameW-(deviceW*scale))*0.5;
			y=(frameH-(deviceH*scale))*0.5+20;
		}
		if(ani){
			let def;
			def={type:"pose",scale:scale,time:50};
			if(move){
				def.x=x;def.y=y;
			}
			boxDevice.animate(def);
		}else {
			if(move){
				boxDevice.x=x;
				boxDevice.y=y;
			}
			boxDevice.scale=scale;
		}
		txtZoom.text=scale*100+"%";
	};
	
	//------------------------------------------------------------------------
	cssVO.sharePreview=async function(){
		//let packPreview;
		//packPreview=(await import("../exporters/PackPreview.js")).default;
		await packPreview();
	};
	/*}#1H2VOVHFO1PostCSSVO*/
	return cssVO;
};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H2VOVHFO0",
//	"editVersion": 73,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H2VOVHFO2",
//			"editVersion": 30,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H2VOVHFP0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2VOVHFP1",
//			"editVersion": 12,
//			"attrs": {
//				"uiDef": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2VOVHFP2",
//			"editVersion": 28,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "#null#>window.tabOSApp"
//				},
//				"mobile": {
//					"type": "bool",
//					"valText": "#false#>app.width<500"
//				},
//				"isNaked": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"assets": {
//					"type": "string",
//					"valText": "/@editkit/assets/preview"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H2VOVHFP3",
//			"editVersion": 14,
//			"attrs": {
//				"faceLog": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H2VOVHFP4",
//			"editVersion": 12,
//			"attrs": {
//				"hideSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H33URP2G0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H33UU7880",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"showSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H33USAD90",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H33UU7881",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"pause": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BJR33C0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BJRLOL0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"resume": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BJRLOL1",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BJRLOL2",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BV4FMP0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BV9ARD0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobileSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3CKGDSL0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3CLKM9C0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H2VOVHFO1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP5",
//					"editVersion": 66,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2VP0R4V0",
//							"editVersion": 40,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ0",
//									"editVersion": 112,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H390GGLS0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H391HRNA0",
//													"editVersion": 158,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "5",
//														"y": "5",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": "${\"Face: \"+state.faceLog},state",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"autoSizeW": "false",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H391HRNA1",
//													"editVersion": 54,
//													"attrs": {
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H391HRNA2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H391HRNA3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H2VR7I5R0",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R1",
//													"editVersion": 164,
//													"attrs": {
//														"type": "box",
//														"id": "BoxDevice",
//														"position": "Absolute",
//														"x": "200",
//														"y": "100",
//														"w": "375",
//														"h": "750",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.5",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "true",
//														"shadowX": "2",
//														"shadowY": "3",
//														"shadowBlur": "6",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H2VRDAEI0",
//															"editVersion": 26,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA0",
//																	"editVersion": 72,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxHud",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA1",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU7882",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU7883",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C7",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C8",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VRKAIA3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU7884",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU7885",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL7",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C9",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C11",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VR7I5R4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H34AHRPL0",
//											"editVersion": 30,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H34AHRPL1",
//													"editVersion": 72,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTouch",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H34AHRPL2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H34AHRPL3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H34AHRPL4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL9",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C13",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C15",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H34AHRPL5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H34AHRPL6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H39266GK0",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H394HA3U0",
//													"editVersion": 194,
//													"attrs": {
//														"type": "box",
//														"id": "BoxPlay",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "100%-45",
//														"w": "120",
//														"h": "40",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor.fontBodyLit",
//														"corner": "20",
//														"shadow": "true",
//														"shadowX": "0",
//														"shadowY": "3",
//														"shadowBlur": "6",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.30]",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392B3KM0",
//															"editVersion": 34,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392EUF50",
//																	"editVersion": 40,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/undo.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392EUF51",
//																	"editVersion": 58,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/undo.svg\",1)",
//																		"id": "BtnNaviReset",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392EUF52",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL11",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL12",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": "false"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR30",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR31",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": "true"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C17",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C18",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C19",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C20",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392EUF53",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H3971K360",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H3972BEC0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392EUF54",
//																	"editVersion": 8,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Reset UI",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392EUF55",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392EVVR0",
//															"editVersion": 36,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392EVVR1",
//																	"editVersion": 46,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/arrowleft.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392EVVR2",
//																	"editVersion": 60,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/arrowleft.svg\",1)",
//																		"id": "BtnNaviBack",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS0",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL13",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL14",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": "false"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR32",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR33",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": "true"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C21",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C22",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C23",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C24",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS1",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H39842S50",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H39857DA0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392EVVS2",
//																	"editVersion": 8,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Back",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS3",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392H3330",
//															"editVersion": 36,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392H3331",
//																	"editVersion": 40,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/arrowright.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392H3332",
//																	"editVersion": 60,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/arrowright.svg\",1)",
//																		"id": "BtnNaviNext",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392H3333",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL15",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL16",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": "false"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR34",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR35",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": "true"
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C25",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C26",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C27",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C28",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392H3334",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H398508O0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H39857DA1",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392H3335",
//																	"editVersion": 8,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Next",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392H3336",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H394HA3U1",
//													"editVersion": 54,
//													"attrs": {
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL17",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL18",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C29",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C30",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C31",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C32",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H394HA3U2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H394HA3U3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ1",
//									"editVersion": 42,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU7886",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU7887",
//													"editVersion": 8,
//													"attrs": {
//														"x": "0",
//														"w": "100%"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H340BHMQ4",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H340BHMQ5",
//													"editVersion": 16,
//													"attrs": {
//														"x": "280",
//														"w": "100%-280"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOL19",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOL20",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H3BV4FMP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9C33",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9C34",
//													"editVersion": 12,
//													"attrs": {
//														"display": "On",
//														"x": "0",
//														"w": "100%"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BV4FMP0",
//											"faceTagName": "mobile"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9C35",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9C36",
//													"editVersion": 4,
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VPIJLJ3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2VP2LRF0",
//							"editVersion": 32,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ4",
//									"editVersion": 108,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxSide",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "280",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H2VP420F0",
//											"editVersion": 23,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ5",
//													"editVersion": 114,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxFaces",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H2VP9GIU0",
//															"editVersion": 23,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ10",
//																	"editVersion": 124,
//																	"attrs": {
//																		"type": "box",
//																		"id": "Top",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H2VPC2IR0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ11",
//																					"editVersion": 154,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "\"\"",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,10,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Faces:",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ12",
//																					"editVersion": 64,
//																					"attrs": {
//																						"1H33URP2G0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H33UU78810",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H33UU78811",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33URP2G0",
//																							"faceTagName": "hideSide"
//																						},
//																						"1H3BJR33C0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3BJRLOL21",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3BJRLOL22",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3BJR33C0",
//																							"faceTagName": "pause"
//																						},
//																						"1H33USAD90": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E0",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E1",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33USAD90",
//																							"faceTagName": "showSide"
//																						},
//																						"1H3CKGDSL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E2",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3CKGDSL0",
//																							"faceTagName": "mobileSide"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1H2VPIJLJ14",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@homekit/ui/BtnIcon.js",
//																			"jaxId": "1H2VRLUBO0",
//																			"editVersion": 35,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1H2VRLUBO1",
//																					"editVersion": 58,
//																					"attrs": {
//																						"app": "null",
//																						"w": "28",
//																						"h": "28",
//																						"image": "#assets+\"/close.svg\"",
//																						"pad": "3"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO2",
//																					"editVersion": 78,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(null,28,28,assets+\"/close.svg\",3)",
//																						"id": "BtnCloseFace",
//																						"position": "Absolute",
//																						"x": "100%-5",
//																						"y": "50%",
//																						"display": "On",
//																						"face": "",
//																						"anchorV": "Center",
//																						"margin": "",
//																						"anchorH": "Right"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO3",
//																					"editVersion": 64,
//																					"attrs": {
//																						"1H33URP2G0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H33UU78816",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H33UU78817",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33URP2G0",
//																							"faceTagName": "hideSide"
//																						},
//																						"1H3BJR33C0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3BJRLOL23",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3BJRLOL24",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3BJR33C0",
//																							"faceTagName": "pause"
//																						},
//																						"1H33USAD90": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E4",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E5",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33USAD90",
//																							"faceTagName": "showSide"
//																						},
//																						"1H3CKGDSL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E6",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E7",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3CKGDSL0",
//																							"faceTagName": "mobileSide"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H34ADPD40",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1H34AE42M0",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1H2VRLUBO5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ15",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU78818",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU78819",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL25",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL26",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E8",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VPIJLJ17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "true",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H2VPLCK70",
//															"editVersion": 27,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K0",
//																	"editVersion": 118,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "FaceList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K1",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU78820",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU78821",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL27",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL28",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VR570K3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ18",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78822",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78823",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL29",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL30",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VPIJLJ20",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H349Q9B00",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H349Q9B01",
//													"editVersion": 122,
//													"attrs": {
//														"type": "box",
//														"id": "Line",
//														"position": "Absolute",
//														"x": "100%",
//														"y": "0",
//														"w": "1",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.fontBodySub",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H349Q9B02",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H349Q9B03",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H349Q9B04",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL31",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL32",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H349Q9B10",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H349Q9B11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ21",
//									"editVersion": 26,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78824",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78825",
//													"editVersion": 4,
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78826",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78827",
//													"editVersion": 4,
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOL33",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOL34",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H3BV4FMP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CJUFCH0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CJUFCH1",
//													"editVersion": 12,
//													"attrs": {
//														"display": "Off",
//														"w": "100%"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BV4FMP0",
//											"faceTagName": "mobile"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9E24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9E25",
//													"editVersion": 4,
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ22",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VPIJLJ23",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H2VS1PMT0",
//							"editVersion": 23,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VS1PMT1",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "Header",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H349TUC20",
//											"editVersion": 55,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H349TUC21",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "28",
//														"h": "28",
//														"image": "#assets+\"/menu.svg\"",
//														"pad": "0"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H349TUC22",
//													"editVersion": 83,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,28,28,assets+\"/menu.svg\",0)",
//														"id": "BtnFace",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,20,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H349TUC23",
//													"editVersion": 54,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H349TUC30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H349TUC31",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E28",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E29",
//																	"editVersion": 6,
//																	"attrs": {
//																		"enable": "false"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E31",
//																	"editVersion": 4,
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H349TUC32",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H34A8N2R0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H34A8UKU0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H349TUC33",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Show faces",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H349TUC34",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H2VS1PMU4",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU5",
//													"editVersion": 164,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": "Device:",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"autoSizeW": "false",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU6",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78830",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78831",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARE34",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARE35",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E36",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E37",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E38",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E39",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU8",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H2VS1PMT2",
//											"editVersion": 47,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H2VS1PMT3",
//													"editVersion": 100,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/btncombo.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMT4",
//													"editVersion": 68,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/btncombo.svg\",1)",
//														"id": "BtnDevice",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,0,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU0",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78838",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78839",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU1",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H358IN630",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H358J0000",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU2",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Choose Device",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU3",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1H2VS1PMU9",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU10",
//													"editVersion": 138,
//													"attrs": {
//														"type": "edit",
//														"id": "EdW",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "375",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU11",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78832",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78833",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU12",
//													"editVersion": 2,
//													"attrs": {
//														"OnUpdate": {
//															"type": "fixedFunc",
//															"jaxId": "1H357M5CO0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H357MO4Q0",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H2VS1PMV0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV1",
//													"editVersion": 196,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "2",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "x",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"autoSizeW": "false",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78834",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78835",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMV4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1H2VS1PMV5",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV6",
//													"editVersion": 142,
//													"attrs": {
//														"type": "edit",
//														"id": "EdH",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,20,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "750",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV7",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78836",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78837",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV8",
//													"editVersion": 2,
//													"attrs": {
//														"OnUpdate": {
//															"type": "fixedFunc",
//															"jaxId": "1H357MCAE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H357MO4Q1",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMV9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H35A7MM30",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A7MM31",
//													"editVersion": 182,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": "Zoom:",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"autoSizeW": "false",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A7MM40",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A7MM41",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A7MM42",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARF0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARF1",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A7MM43",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A7MM44",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H35A826R0",
//											"editVersion": 53,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H35A826R1",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/dec.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A826R2",
//													"editVersion": 77,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/dec.svg\",1)",
//														"id": "BtnZoomOut",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A826R3",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A826R4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A826R5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A826R6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35A826R7",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35A826R8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A826R9",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Zoom out",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H35A826R10",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H35A87850",
//											"editVersion": 30,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A87851",
//													"editVersion": 186,
//													"attrs": {
//														"type": "text",
//														"id": "TxtZoom",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "100%",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "Center",
//														"alignV": "Center",
//														"autoSizeW": "false",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A87860",
//													"editVersion": 46,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A87861",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A87862",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CJUFCH2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CJUFCH3",
//																	"editVersion": 14,
//																	"attrs": {
//																		"w": "\"\""
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F24",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F25",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A87863",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35ASSRE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35ATVIT0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A87864",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H35A9QIV0",
//											"editVersion": 56,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H35A9QIV1",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/inc.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A9QIV2",
//													"editVersion": 78,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/inc.svg\",1)",
//														"id": "BtnZoomIn",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A9QIV3",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A9QIV4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A9QIV5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F28",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F29",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F31",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A9QIV6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35A9QIV7",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35A9QIV8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A9QIV9",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Zoom in",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H35A9QIV10",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H34AB4KC0",
//											"editVersion": 40,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H34AB4KC1",
//													"editVersion": 58,
//													"attrs": {
//														"app": "#app",
//														"w": "28",
//														"h": "28",
//														"image": "#assets+\"/send.svg\"",
//														"pad": "3"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H34AB4KC2",
//													"editVersion": 81,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,28,28,assets+\"/send.svg\",3)",
//														"id": "BtnShare",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,20]",
//														"attach": "#isNaked?false:true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H34AB4KC3",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H34AB4KC4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H34AB4KC5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARE32",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARE33",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E32",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E33",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E34",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E35",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H34AB4KC6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H3KT44I10",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H3KT4A850",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H34AB4KC7",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Share preview...",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H34AB4KC8",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VS1PMV10",
//									"editVersion": 64,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78840",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78841",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOM24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOM25",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9F32",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9F33",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9F34",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9F35",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VS1PMV11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VS1PMV12",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP6",
//					"editVersion": 64,
//					"attrs": {
//						"1H33URP2G0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H33UU78842",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H33UU78843",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H33URP2G0",
//							"faceTagName": "hideSide"
//						},
//						"1H3BJR33C0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3BJRLON0",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3BJRLON1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H3BJR33C0",
//							"faceTagName": "pause"
//						},
//						"1H33USAD90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3CLKM9F36",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3CLKM9F37",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H33USAD90",
//							"faceTagName": "showSide"
//						},
//						"1H3CKGDSL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3CLKM9F38",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3CLKM9F39",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H3CKGDSL0",
//							"faceTagName": "mobileSide"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP7",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H2VOVHFP8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H2VOVHFP9",
//			"editVersion": 62,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}

//Auto genterated by Cody
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1";
/*#{StartDoc*/
/*}#StartDoc*/
let darkMode=false;
let colors={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1]
};
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1GGJKJ2SQ0"
	"version":"0.0.1",
	"txtSize":{
		"small":12,"smallPlus":14,"mid":16,"midPlus":18,"big":20,"bigPlus":25,"large":30,"largePlus":35,"huge":40,"hugePlus":50
	},
	"size":{
		"menuLineH":24
	},
	"color":{
		"body":[255,255,255,1.00],"primary":colors.primary,"secondary":colors.secondary,"success":colors.success,"warning":colors.warning,
		"front":[0,0,0,1.00],"error":colors.error,"fontBody":[0,0,0,1.00],"fontBodySub":[80,80,80,1.00],
		"fontBodyLit":[180,180,180,1.00],"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors.primary,80],"fontPrimaryLit":[...colors.primary,40],
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors.secondary,80.00],"fontSecondaryLit":[...colors.secondary,40.00],"fontSuccess":[255,255,255,1],
		"fontSuccessSub":[...colors.success,80.00],"fontSuccessLit":[...colors.success,40.00],"fontWarning":[255,255,255,1],"fontWarningSub":[...colors.warning,80],
		"fontWarningLit":[...colors.warning,40],"fontError":[255,255,255,1],"fontErrorSub":[...colors.error,80],"fontErrorLit":[...colors.error,40],"fontFront":[255,255,255,1.00],
		"fontFrontSub":[240,240,240,1.00],"fontFrontLit":[80,80,80,1.00],"lineBody":[0,0,0,1.00],
		"lineBodySub":[80,80,80,1.00],"lineBodyLit":[180,180,180,1.00],"itemOver":[240,240,240,1.00],
		"itemDown":[200,200,200,1.00],"itemFocus":[...colors.primary,80],"itemGray":[200,200,200,1.00]
	},
	"darkMode":darkMode,"sharedAssets":"/~/-tabos/shared/assets",
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else {
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "appCfg",
//	"jaxId": "1GGJKJ2SR0",
//	"editVersion": 8,
//	"attrs": {
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKJ2SR1",
//			"editVersion": 48,
//			"attrs": {
//				"darkMode": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJM2JI80",
//					"editVersion": 40,
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GGJKJ2SR2",
//			"editVersion": 2,
//			"attrs": {
//				"appCfg": {
//					"type": "object",
//					"jaxId": "1GGJKJ2SQ0",
//					"editVersion": 38,
//					"attrs": {
//						"version": "0.0.1",
//						"txtSize": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GGJKJ2SR3",
//							"editVersion": 94,
//							"attrs": {
//								"small": {
//									"type": "int",
//									"valText": "12"
//								},
//								"smallPlus": {
//									"type": "int",
//									"valText": "14"
//								},
//								"mid": {
//									"type": "int",
//									"valText": "16"
//								},
//								"midPlus": {
//									"type": "int",
//									"valText": "18"
//								},
//								"big": {
//									"type": "int",
//									"valText": "20"
//								},
//								"bigPlus": {
//									"type": "int",
//									"valText": "25"
//								},
//								"large": {
//									"type": "int",
//									"valText": "30"
//								},
//								"largePlus": {
//									"type": "int",
//									"valText": "35"
//								},
//								"huge": {
//									"type": "int",
//									"valText": "40"
//								},
//								"hugePlus": {
//									"type": "int",
//									"valText": "50"
//								}
//							}
//						},
//						"size": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GGJKJ2SR4",
//							"editVersion": 8,
//							"attrs": {
//								"menuLineH": {
//									"type": "int",
//									"valText": "24"
//								}
//							}
//						},
//						"color": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GGJKJ2SR5",
//							"editVersion": 580,
//							"attrs": {
//								"body": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[50,50,53,1]:[255,255,255,1.00]"
//								},
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"front": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,40]"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80.00]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,40.00]"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80.00]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,40.00]"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,40]"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,40]"
//								},
//								"fontFront": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[0,0,0,1]:[255,255,255,1.00]"
//								},
//								"fontFrontSub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[240,240,240,1.00]"
//								},
//								"fontFrontLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1]:[80,80,80,1.00]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"itemOver": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[100,100,100,1]:[240,240,240,1.00]"
//								},
//								"itemDown": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[200,200,200,1.00]"
//								},
//								"itemFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[...colors.primary,-20]:[...colors.primary,80]"
//								},
//								"itemGray": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[200,200,200,1.00]"
//								}
//							}
//						},
//						"darkMode": {
//							"type": "bool",
//							"valText": "#darkMode"
//						},
//						"sharedAssets": {
//							"type": "string",
//							"valText": "/~/-tabos/shared/assets"
//						}
//					}
//				}
//			}
//		}
//	}
//}

//Auto genterated by Cody
/*#{1H1KJQ5RK0StartDoc*/
/*}#1H1KJQ5RK0StartDoc*/
//----------------------------------------------------------------------------
let BtnIcon=function(style,w,h,icon,colorBG){
	let cfgColor,state;
	let cssVO;
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	
	let color=Array.isArray(style)?(style):(cfgColor[style]);
	
	/*#{1H1KJQ5RK1LocalVals*/
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":0,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":w,"h":h||w,"cursor":"pointer","styleClass":"",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":colorBG||[0,0,0,0],"border":$P(()=>(state.border||0),state),
				"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KKD55C0",
				"type":"box","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"uiEvent":-1,"margin":[0,3,0,0],"styleClass":"",
				"background":color,"attached":icon,"maskImage":icon,
			}
		],
		get $$border(){return state["border"]},
		set $$border(v){
			state["border"]=v;
			/*#{1H1KJQ5RK1Setborder*/
			/*}#1H1KJQ5RK1Setborder*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KJQ5RK1Setcorner*/
			/*}#1H1KJQ5RK1Setcorner*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG||[0,0,0,0],"y":0,"borderColor":cfgColor[style]
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"over":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"down":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"w":">calc(100% - 2px)","h":">calc(100% - 2px)"
				}
			},"gray":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H1KKD55C0":{
					"background":[color[0],color[1],color[2],color[3]*0.25],"w":"100%","h":"100%"
				}
			}
		},
		OnCreate:function(){
			
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnIcon.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Icon Button",icon:"btn_icon.svg",previewImg:"false",
	fixPose:false,initW:30,initH:30,
	desc:"Icon button",
	catalog:"Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "auto", "key": true, "fixed": true, "initVal": "front", "localizable": undefined
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 30, "localizable": undefined
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 0, "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg", "localizable": undefined
		}, 
		"colorBG": {
			"name": "colorBG", "showName": "colorBG", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}
	},
	state:{
		border:{name:"border",type:"int",initVal:0},
		corner:{name:"corner",type:"int",initVal:3}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","padding","enable","drag","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1KJQ5RK0ExGearInfo*/
	/*}#1H1KJQ5RK0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H2CQBSVI0StartDoc*/
/*}#1H2CQBSVI0StartDoc*/
//----------------------------------------------------------------------------
let NaviTop=function(title,bgColor,logoIcon,color,items,menuItems){
	let cfgColor,txtSize;
	let cssVO;
	
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7DITA1LocalVals*/
	/*}#1H1T7DITA1LocalVals*/
	
	/*#{1H1T7DITA1PreState*/
	/*}#1H1T7DITA1PreState*/
	/*#{1H1T7DITA1PostState*/
	/*}#1H1T7DITA1PostState*/
	cssVO={
		"hash":"1H1T7DITA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":40,"padding":[5,35,5,5],"styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1H1TB73370",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","padding":5,"styleClass":"","background":bgColor,"contentLayout":"flex-x",
			},
			{
				"hash":"1H1TBM5HJ0",
				"type":BtnIcon(cfgColor.fontSecondary,30,0,logoIcon,null),"id":"BtnHome","position":"relative","x":0,"y":0,"border":0,
				"OnClick":function(event){
					/*#{1H1TNA1270FunctionBody*/
					/*}#1H1TNA1270FunctionBody*/
				},
			},
			{
				"hash":"1H1TBHQJ30",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":color,"text":title,"fontSize":txtSize.big,
				"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TBOLJK0",
				"type":BtnIcon(cfgColor.fontSecondary,30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","x":">calc(100% - 5px)","y":"50%","anchorX":2,"anchorY":1,
				"OnClick":function(event){
					/*#{1H1TM72AV0FunctionBody*/
					/*}#1H1TM72AV0FunctionBody*/
				},
			},
			{
				"hash":"1H2CQI73O0",
				"type":"hud","id":"NaviItems","position":"relative","x":0,"y":0,"w":20,"h":"100%","margin":[0,0,0,20],"styleClass":"","flex":true,"contentLayout":"flex-x",
				"subAlign":4,
			},
			{
				"hash":"1H2CQTOQC0",
				"type":"hud","id":"ItemsRight","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":10,"styleClass":"","contentLayout":"flex-x",
			}
		],
		/*#{1H1T7DITA1ExtraCSS*/
		/*}#1H1T7DITA1ExtraCSS*/
		faces:{
			"desktop":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":1
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":1
				}
			},"mobile":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":0
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			/*#{1H1T7DITA1Create*/
			/*}#1H1T7DITA1Create*/
		},
		/*#{1H1T7DITA1EndCSS*/
		/*}#1H1T7DITA1EndCSS*/
	};
	/*#{1H1T7DITA1PostCSSVO*/
	/*}#1H1T7DITA1PostCSSVO*/
	return cssVO;
};
/*#{1H1T7DITA1ExCodes*/
/*}#1H1T7DITA1ExCodes*/

NaviTop.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Top Navi Bar",icon:"gears.svg",previewImg:"false",
	fixPose:true,initW:500,initH:60,
	desc:"Simple web site header, support both motile and desktop mode.",
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Cool Site Name", "localizable": true
		}, 
		"bgColor": {
			"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [108,117,125,1], "localizable": undefined
		}, 
		"logoIcon": {
			"name": "logoIcon", "showName": "logoIcon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/cklogo.svg", "localizable": undefined
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1], "localizable": undefined
		}, 
		"items": {
			"name": "items", "showName": "items", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}, 
		"menuItems": {
			"name": "menuItems", "showName": "menuItems", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[
		{name:"desktop",entry:false,next:"",desc:"",time:0},
		{name:"mobile",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
		"1H2CQI73O0":{"showName":"NaviItems","contentLayout":"flex-x"},
		"1H2CQTOQC0":{"showName":"ItemsRight","contentLayout":"flex-x"}
	},
	deviceW:800,
	deviceH:750,
	/*#{1H2CQBSVI0ExGearInfo*/
	/*}#1H2CQBSVI0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1TJQ6AL0StartDoc*/
/*}#1H1TJQ6AL0StartDoc*/
//----------------------------------------------------------------------------
let NaviBar=function(items,color,initFocused){
	let cssVO;
	
	appCfg.lanCode||'EN';
	
	
	/*#{1H1TJQ6AL1LocalVals*/
	/*}#1H1TJQ6AL1LocalVals*/
	
	/*#{1H1TJQ6AL1PreState*/
	/*}#1H1TJQ6AL1PreState*/
	/*#{1H1TJQ6AL1PostState*/
	/*}#1H1TJQ6AL1PostState*/
	cssVO={
		"hash":"1H1TJQ6AL1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"","h":"100%","minW":20,"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1H2ISHP700",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"100%","overflow":undefined,"minW":20,"styleClass":"","flex":true,"contentLayout":"flex-x",
				"itemsAlign":1,
			},
			{
				"hash":"1H2IT5UTD0",
				"type":"hud","id":"BoxFocus","x":0,"y":0,"w":10,"h":"100%","display":0,"overflow":undefined,"styleClass":"",
				children:[
					{
						"hash":"1H2IT77820",
						"type":"box","id":"FocusBar","x":0,"y":">calc(100% - 3px)","w":"100%","h":3,"overflow":undefined,"styleClass":"","background":color,"corner":100,
					}
				],
			}
		],
		/*#{1H1TJQ6AL1ExtraCSS*/
		/*}#1H1TJQ6AL1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			/*#{1H1TJQ6AL1Create*/
			/*}#1H1TJQ6AL1Create*/
		},
		/*#{1H1TJQ6AL1EndCSS*/
		/*}#1H1TJQ6AL1EndCSS*/
	};
	/*#{1H1TJQ6AL1PostCSSVO*/
	/*}#1H1TJQ6AL1PostCSSVO*/
	return cssVO;
};
/*#{1H1TJQ6AL1ExCodes*/
/*}#1H1TJQ6AL1ExCodes*/

NaviBar.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Navi Bar",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:360,initH:40,
	desc:"Navi buttons bar",
	catalog:"Views",
	args: {
		"items": {
			"name": "items", "showName": "items", "type": "auto", "key": true, "fixed": true, 
			"initVal": [], "localizable": undefined
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"initFocused": {
			"name": "initFocused", "showName": "initFocused", "type": "string", "key": true, "fixed": true, "initVal": "", "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","subAlign","uiEvent","scale","cursor","zIndex","flex","margin","traceSize","minW","minH","maxW","maxH"],
	faces:[
	],
	subContainers:{
		"1H2ISHP700":{"showName":"Contents","contentLayout":"flex-x"},
		"1H2IT5UTD0":{"showName":"BoxFocus"}
	},
	deviceW:375,
	deviceH:40,
	/*#{1H1TJQ6AL0ExGearInfo*/
	/*}#1H1TJQ6AL0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1TCNO8A0StartDoc*/
/*}#1H1TCNO8A0StartDoc*/
//----------------------------------------------------------------------------
let BtnNaviItem=function(code,text,color,icon,items){
	let txtSize;
	let cssVO;
	appCfg.lanCode||'EN';
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1TCNO8A1LocalVals*/
	/*}#1H1TCNO8A1LocalVals*/
	
	/*#{1H1TCNO8A1PreState*/
	/*}#1H1TCNO8A1PreState*/
	/*#{1H1TCNO8A1PostState*/
	/*}#1H1TCNO8A1PostState*/
	cssVO={
		"hash":"1H1TCNO8A1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"","h":"100%","alpha":0.5,"cursor":"pointer","padding":[5,5,5,5],"styleClass":"","contentLayout":"flex-x",
		"code":code,
		children:[
			{
				"hash":"1H1TCV3O50",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":"","h":"100%","anchorY":1,"uiEvent":-1,"styleClass":"","background":color,"aspect":"1",
				"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H1TCQ3130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"padding":0,"styleClass":"","color":color,"text":text,
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TIOQU40",
				"type":"box","id":"MenuMark","position":"relative","x":0,"y":"50%","w":"","h":">calc(100% - 10px)","anchorY":1,"uiEvent":-1,"styleClass":"","background":color,
				"aspect":"1","maskImage":appCfg.sharedAssets+"/down.svg","attached":!!items,
			}
		],
		/*#{1H1TCNO8A1ExtraCSS*/
		/*}#1H1TCNO8A1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1TD2J6S0PreCode*/
				/*}#1H1TD2J6S0PreCode*/
				"#self":{
					"alpha":0.5
				}
			},"over":{
				/*#{1H1TD45OB0PreCode*/
				/*}#1H1TD45OB0PreCode*/
				"#self":{
					"alpha":0.7
				}
			},"down":{
				/*#{1H1TD2VV70PreCode*/
				/*}#1H1TD2VV70PreCode*/
				"#self":{
					"alpha":1
				}
			},"gray":{
				/*#{1H1TLQVNS0PreCode*/
				/*}#1H1TLQVNS0PreCode*/
				"#self":{
					"alpha":0.2
				}
			},"focus":{
				"#self":{
					"alpha":1
				},
				/*#{1H1TD5GM90Code*/
				/*}#1H1TD5GM90Code*/
			},"blur":{
				"#self":{
					"alpha":0.5
				},
				/*#{1H1TD5O2O0Code*/
				/*}#1H1TD5O2O0Code*/
			}
		},
		OnCreate:function(){
			
			/*#{1H1TCNO8A1Create*/
			/*}#1H1TCNO8A1Create*/
		},
		/*#{1H1TCNO8A1EndCSS*/
		/*}#1H1TCNO8A1EndCSS*/
	};
	/*#{1H1TCNO8A1PostCSSVO*/
	/*}#1H1TCNO8A1PostCSSVO*/
	return cssVO;
};
/*#{1H1TCNO8A1ExCodes*/
/*}#1H1TCNO8A1ExCodes*/

BtnNaviItem.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"BtnNaviItem",icon:"gears.svg",previewImg:"false",
	fixPose:true,initW:100,initH:40,
	desc:"Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
	catalog:"Buttons",
	args: {
		"code": {
			"name": "code", "showName": "code", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": undefined
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": true
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/home.svg", "localizable": undefined
		}, 
		"items": {"name":"items","showName":"items","type":"auto","key":true,"fixed":true}
	},
	state:{
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","cursor","margin","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0},
		{name:"focus",entry:false,next:"",desc:"",time:0},
		{name:"blur",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:40,
	/*#{1H1TCNO8A0ExGearInfo*/
	/*}#1H1TCNO8A0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1KB50JO0StartDoc*/
/*}#1H1KB50JO0StartDoc*/
//----------------------------------------------------------------------------
let BtnText=function(style,w,h,text,outlined,icon){
	let cfgColor,state;
	let cssVO;
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	
	let colorFix=style[0].toUpperCase()+style.substring(1);
	
	/*#{1H1KB50JO1LocalVals*/
	/*}#1H1KB50JO1LocalVals*/
	
	/*#{1H1KB50JO1PreState*/
	/*}#1H1KB50JO1PreState*/
	state={
		"corner":5,"text":text,"fontSize":h>0?(h>26?h-14:12):16,
		/*#{1H1KB50JP4ExState*/
		/*}#1H1KB50JP4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KB50JO1PostState*/
	/*}#1H1KB50JO1PostState*/
	cssVO={
		"hash":"1H1KB50JO1",nameHost:true,
		"type":"button","x":138,"y":84,"w":w,"h":h,"cursor":"pointer","styleClass":"","contentLayout":"flex-x","subAlign":1,
		children:[
			{
				"hash":"1H1KEE8D70",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":outlined?[0,0,0,0]:cfgColor[style],"border":outlined?1.5:0,
				"borderColor":cfgColor[style],"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KFRSGD0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":$P(()=>(state.fontSize+4),state),"h":$P(()=>(state.fontSize+4),state),"anchorY":1,
				"uiEvent":-1,"margin":[0,3,0,0],"styleClass":"","background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"attached":icon,"maskImage":icon,
			},
			{
				"hash":"1H1KEIIO50",
				"type":"text","id":"TxtText","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,2,0,0],"styleClass":"","color":outlined?cfgColor[style]:cfgColor["font"+colorFix],
				"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
				"alignV":1,
			},
			{
				"hash":"1H2F6U36O0",
				"type":"hud","id":"BoxRight","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"",
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1KB50JO1Settext*/
			/*}#1H1KB50JO1Settext*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KB50JO1Setcorner*/
			/*}#1H1KB50JO1Setcorner*/
		},
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1KB50JO1SetfontSize*/
			/*}#1H1KB50JO1SetfontSize*/
		},
		/*#{1H1KB50JO1ExtraCSS*/
		/*}#1H1KB50JO1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor[style],"y":0,"borderColor":cfgColor[style]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"over":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[cfgColor[style][0],cfgColor[style][1],cfgColor[style][2],0.25]:[...cfgColor[style],20],"y":0
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":"50%"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor[style]:cfgColor["font"+colorFix],"y":0
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			},"down":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?cfgColor[style]:[...cfgColor[style],-20],"y":1
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":">calc(50% + 1px)"
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["font"+colorFix]:cfgColor["font"+colorFix],"y":1
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":1
				}
			},"gray":{
				/*BoxBG*/"#1H1KEE8D70":{
					"background":outlined?[0,0,0,0]:cfgColor["itemGray"],"borderColor":cfgColor["itemGray"]
				},
				/*BoxIcon*/"#1H1KFRSGD0":{
					"background":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*TxtText*/"#1H1KEIIO50":{
					"color":outlined?cfgColor["itemGray"]:cfgColor["font"+colorFix]
				},
				/*BoxRight*/"#1H2F6U36O0":{
					"y":0
				}
			}
		},
		OnCreate:function(){
			
			/*#{1H1KB50JO1Create*/
			/*}#1H1KB50JO1Create*/
		},
		/*#{1H1KB50JO1EndCSS*/
		/*}#1H1KB50JO1EndCSS*/
	};
	/*#{1H1KB50JO1PostCSSVO*/
	/*}#1H1KB50JO1PostCSSVO*/
	return cssVO;
};
/*#{1H1KB50JO1ExCodes*/
/*}#1H1KB50JO1ExCodes*/

BtnText.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Text Button",icon:"btn_text.svg",previewImg:"./BtnText.png",
	fixPose:false,initW:100,initH:30,
	desc:"Styled text button, can have an icon.",
	catalog:"Basic,Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "string", "key": true, "fixed": true, "initVal": "primary", "localizable": undefined
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 30, "localizable": undefined
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Button", "localizable": true
		}, 
		"outlined": {
			"name": "outlined", "showName": "outlined", "type": "bool", "key": true, "fixed": true, "initVal": false, "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "", "localizable": undefined
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"Button"},
		corner:{name:"corner",type:"int",initVal:5},
		fontSize:{name:"fontSize",type:"int",initVal:16}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","padding","enable","attach"],
	faces:[
		{name:"up",entry:true,next:"over",desc:"",time:1000},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:true,next:"",desc:"",time:0}
	],
	subContainers:{
		"1H2F6U36O0":{"showName":"BoxRight"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1KB50JO0ExGearInfo*/
	/*}#1H1KB50JO0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1T7ISV50StartDoc*/
/*}#1H1T7ISV50StartDoc*/
//----------------------------------------------------------------------------
let DialogTemplate=function(title,closeIcon,buttons){
	let cfgColor,txtSize,state;
	let cssVO;
	
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":"30%","w":360,"h":"","padding":10,"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":cfgColor.body,"border":2,"borderColor":cfgColor["fontBodySub"],
				"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"display":!!closeIcon,"padding":3,
				"attached":!!closeIcon,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"styleClass":"","color":cfgColor.fontBodySub,
				"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":30,"styleClass":"",
				children:[
					{
						"hash":"1H1T8B4370",
						"type":"text","id":"TxtMockup","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","color":cfgColor.fontBodyLit,"text":"Add your components here.",
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"styleClass":"","contentLayout":"flex-x",
				"subAlign":2,"attached":!!buttons,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,state.buttons[1]||"OK",false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,state.buttons[0]||"Cancel",false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":!!(buttons&&buttons[2]),
						"anchorY":1,"attached":!!(buttons&&buttons[2]),
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			/*#{1H1T7ISV51Create*/
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DialogTemplate.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Standard Dialog",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false, "localizable": undefined
		}, 
		"buttons": {
			"name": "buttons", "showName": "buttons", "type": "auto", "key": true, "fixed": true, 
			"initVal": [], "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[
	],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1T7ISV50ExGearInfo*/
	/*}#1H1T7ISV50ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1O8E46I0StartDoc*/
/*}#1H1O8E46I0StartDoc*/
//----------------------------------------------------------------------------
let DlgMenu=function(){
	let cssVO;
	
	appCfg.lanCode||'EN';
	
	
	/*#{1H1O8E46I1LocalVals*/
	/*}#1H1O8E46I1LocalVals*/
	
	/*#{1H1O8E46I1PreState*/
	/*}#1H1O8E46I1PreState*/
	/*#{1H1O8E46I1PostState*/
	/*}#1H1O8E46I1PostState*/
	cssVO={
		"hash":"1H1O8E46I1",nameHost:true,
		"type":"box","x":42,"y":38,"w":100,"h":"","overflow":1,"padding":5,"minH":30,"styleClass":"","background":[255,255,255,1],"border":1,"shadow":true,"shadowX":3,
		"shadowY":5,"shadowBlur":6,"shadowSpread":2,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H2CN3UCE0",
				"type":"hud","id":"Contents","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":20,"styleClass":"","contentLayout":"flex-y",
			}
		],
		/*#{1H1O8E46I1ExtraCSS*/
		/*}#1H1O8E46I1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			/*#{1H1O8E46I1Create*/
			/*}#1H1O8E46I1Create*/
		},
		/*#{1H1O8E46I1EndCSS*/
		/*}#1H1O8E46I1EndCSS*/
	};
	/*#{1H1O8E46I1PostCSSVO*/
	/*}#1H1O8E46I1PostCSSVO*/
	return cssVO;
};
/*#{1H1O8E46I1ExCodes*/
/*}#1H1O8E46I1ExCodes*/

DlgMenu.gearExport={
	framework: "jax",
	hudType: "box",
	showName:"Menu",icon:"menu.svg",previewImg:"false",
	fixPose:false,initW:100,initH:30,
	desc:"Menu frame",
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","padding","minW","minH","maxW","maxH","styleClass","background","border","borderStyle","borderColor","corner","attach"],
	faces:[
	],
	subContainers:{
		"1H2CN3UCE0":{"showName":"Contents","contentLayout":"flex-y"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1O8E46I0ExGearInfo*/
	/*}#1H1O8E46I0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1O4B7OK0StartDoc*/
/*}#1H1O4B7OK0StartDoc*/
//----------------------------------------------------------------------------
let BtnObject=function(obj,converter){
	let cfgColor,txtSize,state;
	let cssVO;
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O4B7OK1LocalVals*/
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":txtSize.smallPlus,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":24,"padding":[0,5,0,5],"styleClass":"","enable":obj.enable===false?false:true,"contentLayout":"flex-x","traceSize":true,
		"obj":obj,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":[0,0,0,0],
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":"FH-4","h":"FH-4","anchorY":1,"autoLayout":true,"margin":[0,3,0,0],"styleClass":"",
				"background":obj.iconColor||obj.color||cfgColor.fontBody,"attached":(!!obj.icon)||(obj.icon===""),"maskImage":obj.icon,
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":obj.color||cfgColor.fontBody,"text":obj.text,
				"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1O640F30",
				"type":"box","id":"BoxCheck","x":">calc(100% - 5px)","y":"50%","w":"FH-6","h":"FH-6","anchorX":2,"anchorY":1,"display":!!obj.check,"styleClass":"",
				"background":obj.color||cfgColor.fontBody,"border":1,"maskImage":appCfg.sharedAssets+"/check_fat.svg","attached":("check" in obj),
			}
		],
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1O4B7OK1SetfontSize*/
			/*}#1H1O4B7OK1SetfontSize*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			}
		},
		OnCreate:function(){
			
			/*#{1H1O4B7OK1Create*/
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

BtnObject.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Object Line",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:100,initH:24,
	catalog:"",
	args: {
		"obj": {
			"name": "obj", "showName": "obj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"text": "Object", "icon": "", "iconColor": [255,0,0,1], "check": true, "enable": false
			}, 
			"localizable": undefined
		}, 
		"converter": {
			"name": "converter", "showName": "converter", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}
	},
	state:{
		fontSize:{name:"fontSize",type:"int",initVal:14}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1O4B7OK0ExGearInfo*/
	/*}#1H1O4B7OK0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1LSJKOO0StartDoc*/
/*}#1H1LSJKOO0StartDoc*/
//----------------------------------------------------------------------------
let BoxRange=function(value,minVal,maxVal){
	let cfgColor,state;
	let cssVO;
	
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	
	
	/*#{1H1LSJKOO1LocalVals*/
	/*}#1H1LSJKOO1LocalVals*/
	
	/*#{1H1LSJKOO1PreState*/
	/*}#1H1LSJKOO1PreState*/
	state={
		"buttonSize":20,"barSize":8,"value":value,"min":minVal,"max":maxVal,"step":1,"valColor":cfgColor.primary,"enable":true,
		/*#{1H1LSJKOO6ExState*/
		/*}#1H1LSJKOO6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LSJKOO1PostState*/
	/*}#1H1LSJKOO1PostState*/
	cssVO={
		"hash":"1H1LSJKOO1",nameHost:true,
		"type":"hud","x":125,"y":182,"w":100,"h":20,"alpha":$P(()=>(state.enable?1:0.6),state),"styleClass":"",
		"trackSize":true,
		children:[
			{
				"hash":"1H1LSR12R0",
				"type":"box","id":"BoxTrack","x":5,"y":"50%","w":">calc(100% - 10px)","h":$P(()=>(state.barSize),state),"anchorY":1,"styleClass":"","background":[0,0,0,0],
				"border":1,"borderColor":cfgColor.fontBody,"corner":100,
				children:[
					{
						"hash":"1H1LTEIBS0",
						"type":"box","id":"BoxValue","x":0,"y":0,"w":$P(()=>(((state.value-state.min)/(state.max-state.min)*100)+"%"),state),"h":"100%","styleClass":"",
						"background":$P(()=>(state.valColor),state),"corner":[100,0,0,100],
						"OnClick":function(event){
							/*#{1H2E5TECE0FunctionBody*/
							/*}#1H2E5TECE0FunctionBody*/
						},
					}
				],
				"OnClick":function(event){
					/*#{1H2E5T5950FunctionBody*/
					/*}#1H2E5T5950FunctionBody*/
				},
			},
			{
				"hash":"1H2E6IVF70",
				"type":"button","id":"BtnDrag","x":$P(()=>(`(FW-${state.buttonSize})*${(state.value-state.min)/(state.max-state.min)}`),state),"y":"50%","w":$P(()=>(state.buttonSize),state),
				"h":$P(()=>(state.buttonSize),state),"anchorY":1,"cursor":"pointer","styleClass":"","drag":2,
				children:[
					{
						"hash":"1H2E6L0B10",
						"type":"box","id":"BoxBtn","x":0,"y":0,"w":$P(()=>(state.buttonSize),state),"h":$P(()=>(state.buttonSize),state),"uiEvent":-1,"styleClass":"","background":cfgColor.body,
						"border":1,"borderColor":cfgColor.fontBody,"corner":100,
					}
				],
				/*#{1H2E6IVF70Codes*/
				/*}#1H2E6IVF70Codes*/
			}
		],
		get $$value(){return state["value"]},
		set $$value(v){
			state["value"]=v;
			/*#{1H1LSJKOO1Setvalue*/
			/*}#1H1LSJKOO1Setvalue*/
		},
		get $$min(){return state["min"]},
		set $$min(v){
			state["min"]=v;
			/*#{1H1LSJKOO1Setmin*/
			/*}#1H1LSJKOO1Setmin*/
		},
		get $$max(){return state["max"]},
		set $$max(v){
			state["max"]=v;
			/*#{1H1LSJKOO1Setmax*/
			/*}#1H1LSJKOO1Setmax*/
		},
		get $$step(){return state["step"]},
		set $$step(v){
			state["step"]=v;
			/*#{1H1LSJKOO1Setstep*/
			/*}#1H1LSJKOO1Setstep*/
		},
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LSJKOO1Setenable*/
			/*}#1H1LSJKOO1Setenable*/
		},
		get $$barSize(){return state["barSize"]},
		set $$barSize(v){
			state["barSize"]=v;
			/*#{1H1LSJKOO1SetbarSize*/
			/*}#1H1LSJKOO1SetbarSize*/
		},
		get $$buttonSize(){return state["buttonSize"]},
		set $$buttonSize(v){
			state["buttonSize"]=v;
			/*#{1H1LSJKOO1SetbuttonSize*/
			/*}#1H1LSJKOO1SetbuttonSize*/
		},
		get $$valColor(){return state["valColor"]},
		set $$valColor(v){
			state["valColor"]=v;
			/*#{1H1LSJKOO1SetvalColor*/
			/*}#1H1LSJKOO1SetvalColor*/
		},
		/*#{1H1LSJKOO1ExtraCSS*/
		/*}#1H1LSJKOO1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			/*#{1H1LSJKOO1Create*/
			/*}#1H1LSJKOO1Create*/
		},
		/*#{1H1LSJKOO1EndCSS*/
		/*}#1H1LSJKOO1EndCSS*/
	};
	/*#{1H1LSJKOO1PostCSSVO*/
	/*}#1H1LSJKOO1PostCSSVO*/
	return cssVO;
};
/*#{1H1LSJKOO1ExCodes*/
/*}#1H1LSJKOO1ExCodes*/

BoxRange.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Value Bar",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:100,initH:100,
	desc:"Draggable value bar",
	catalog:"Inputs",
	args: {
		"value": {
			"name": "value", "showName": "value", "type": "number", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}, 
		"minVal": {
			"name": "minVal", "showName": "minVal", "type": "number", "key": true, "fixed": true, "initVal": 0, "localizable": undefined
		}, 
		"maxVal": {
			"name": "maxVal", "showName": "maxVal", "type": "number", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}
	},
	state:{
		value:{name:"value",type:"number",initVal:100},
		min:{name:"min",type:"number",initVal:0},
		max:{name:"max",type:"number",initVal:100},
		step:{name:"step",type:"number",initVal:1},
		enable:{name:"enable",type:"bool",initVal:true},
		barSize:{name:"barSize",type:"int",initVal:8},
		buttonSize:{name:"buttonSize",type:"int",initVal:20},
		valColor:{name:"valColor",type:"colorRGBA",initVal:[13,110,253,1]}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","attach"],
	faces:[
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1LSJKOO0ExGearInfo*/
	/*}#1H1LSJKOO0ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1LRUDP20StartDoc*/
/*}#1H1LRUDP20StartDoc*/
//----------------------------------------------------------------------------
let BoxSteps=function(size){
	let state;
	let cssVO;
	
	appCfg.lanCode||'EN';
	
	
	/*#{1H1LRUDP21LocalVals*/
	/*}#1H1LRUDP21LocalVals*/
	
	/*#{1H1LRUDP21PreState*/
	/*}#1H1LRUDP21PreState*/
	state={
		"enable":true,"enableUp":true,"enableDown":true,
		/*#{1H1LRUDP26ExState*/
		/*}#1H1LRUDP26ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LRUDP21PostState*/
	/*}#1H1LRUDP21PostState*/
	cssVO={
		"hash":"1H1LRUDP21",nameHost:true,
		"type":"hud","x":121,"y":141,"w":size,"h":size,"alpha":$P(()=>(state.enable?1:0.6),state),"styleClass":"",
		children:[
			{
				"hash":"1H1LRVCO90",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepup.svg",null),"id":"BtnStepUp","x":0,"y":0,"enable":$P(()=>(state.enableUp),state),
				"OnButtonDown":function(code,event){
					/*#{1H2E51V6T0FunctionBody*/
					/*}#1H2E51V6T0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E520ES0FunctionBody*/
					/*}#1H2E520ES0FunctionBody*/
				},
			},
			{
				"hash":"1H1LS2K200",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepdown.svg",null),"id":"BtnStepDown","x":0,"y":size*0.5,"enable":$P(()=>(state.enableDown),state),
				"OnButtonDown":function(code,event){
					/*#{1H2E52PJA0FunctionBody*/
					/*}#1H2E52PJA0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E52QAT0FunctionBody*/
					/*}#1H2E52QAT0FunctionBody*/
				},
			}
		],
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LRUDP21Setenable*/
			/*}#1H1LRUDP21Setenable*/
		},
		get $$enableUp(){return state["enableUp"]},
		set $$enableUp(v){
			state["enableUp"]=v;
			/*#{1H1LRUDP21SetenableUp*/
			/*}#1H1LRUDP21SetenableUp*/
		},
		get $$enableDown(){return state["enableDown"]},
		set $$enableDown(v){
			state["enableDown"]=v;
			/*#{1H1LRUDP21SetenableDown*/
			/*}#1H1LRUDP21SetenableDown*/
		},
		/*#{1H1LRUDP21ExtraCSS*/
		/*}#1H1LRUDP21ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			/*#{1H1LRUDP21Create*/
			/*}#1H1LRUDP21Create*/
		},
		/*#{1H1LRUDP21EndCSS*/
		/*}#1H1LRUDP21EndCSS*/
	};
	/*#{1H1LRUDP21PostCSSVO*/
	/*}#1H1LRUDP21PostCSSVO*/
	return cssVO;
};
/*#{1H1LRUDP21ExCodes*/
/*}#1H1LRUDP21ExCodes*/

BoxSteps.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Step Buttons",icon:"btn_step.svg",previewImg:"false",
	fixPose:false,initW:20,initH:20,
	desc:"2-buttons that increase or decrease value.",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20, "localizable": undefined
		}
	},
	state:{
		enable:{name:"enable",type:"bool",initVal:true},
		enableUp:{name:"enableUp",type:"bool",initVal:true},
		enableDown:{name:"enableDown",type:"bool",initVal:true}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","attach"],
	faces:[
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1LRUDP20ExGearInfo*/
	/*}#1H1LRUDP20ExGearInfo*/
};

//Auto genterated by Cody
/*#{1H1RPOAH90StartDoc*/
/*}#1H1RPOAH90StartDoc*/
//----------------------------------------------------------------------------
let BtnTextIcon=function(w,h,icon,color,hasMark,hasCheck,text){
	let cfgColor,txtSize,state;
	let cssVO;
	
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1KJQ5RK1LocalVals*/
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":false,"text":text,"fontSize":txtSize.small,"markNum":0,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":26,"y":15,"w":"","h":h||w,"cursor":"pointer","padding":[0,3,0,3],"minW":w,"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":[0,0,0,0],"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KKD55C0",
				"type":"box","position":"relative","x":"50%","y":0,"w":undefined,"h":">calc(100% - 15px)","anchorX":1,"uiEvent":-1,"alpha":hasCheck?0.5:1,"margin":[0,3,0,0],
				"styleClass":"","background":color,"attached":icon,"maskImage":icon,"aspect":"1",
			},
			{
				"hash":"1H1RPTGKE0",
				"type":"text","position":"relative","x":"50%","y":0,"w":"","h":"","anchorX":1,"alpha":hasCheck?0.5:1,"styleClass":"","color":color,"text":$P(()=>(state.text),state),
				"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
			},
			{
				"hash":"1H1UIGQ8B0",
				"type":"box","id":"BoxMark","x":"100%","y":0,"w":"","h":"","anchorX":2,"display":$P(()=>(!!state.markNum),state),"padding":[2,5,2,5],"minW":15,"styleClass":"",
				"background":cfgColor.error,"corner":100,"contentLayout":"flex-x","subAlign":1,"attached":!!hasMark,
				children:[
					{
						"hash":"1H1UILHLR0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","styleClass":"","color":cfgColor.fontError,"text":$P(()=>(state.markNum),state),"fontSize":txtSize.small,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			}
		],
		get $$markNum(){return state["markNum"]},
		set $$markNum(v){
			state["markNum"]=v;
			/*#{1H1KJQ5RK1SetmarkNum*/
			/*}#1H1KJQ5RK1SetmarkNum*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1KK1Q1R0PreCode*/
				/*}#1H1KK1Q1R0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"y":0,"borderColor":color
				},
				"#1H1KKD55C0":{
					"background":color,"y":0,"alpha":hasCheck?0.5:1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":hasCheck?0.5:1
				}
			},"over":{
				/*#{1H1KK1SU60PreCode*/
				/*}#1H1KK1SU60PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemOver,"y":0,"alpha":1
				},
				"#1H1KKD55C0":{
					"background":color,"y":0,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"down":{
				/*#{1H1KK1M7O0PreCode*/
				/*}#1H1KK1M7O0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemDown,"y":1
				},
				"#1H1KKD55C0":{
					"background":color,"y":1,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"gray":{
				/*#{1H1KK26UE3PreCode*/
				/*}#1H1KK26UE3PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H1KKD55C0":{
					"background":color,"alpha":0.3
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":0.3
				}
			},"focus":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0]
				},
				"#1H1KKD55C0":{
					"alpha":1
				},
				"#1H1RPTGKE0":{
					"alpha":1
				},
				/*#{1H1UIV5040Code*/
				/*}#1H1UIV5040Code*/
			},"blur":{
				"#1H1KKD55C0":{
					"alpha":0.5
				},
				"#1H1RPTGKE0":{
					"alpha":0.5
				},
				/*#{1H1UIVME70Code*/
				/*}#1H1UIVME70Code*/
			}
		},
		OnCreate:function(){
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnTextIcon.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Icon Text Button",icon:"btn_icon.svg",previewImg:"false",
	fixPose:false,initW:40,initH:40,
	desc:"Icon button with a text footer.",
	catalog:"Buttons",
	args: {
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 48, "localizable": undefined
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 48, "localizable": undefined
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg", "localizable": undefined
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"hasMark": {
			"name": "hasMark", "showName": "hasMark", "type": "bool", "key": true, "fixed": true, "initVal": true, "localizable": undefined
		}, 
		"hasCheck": {
			"name": "hasCheck", "showName": "hasCheck", "type": "bool", "key": true, "fixed": true, "initVal": false, "localizable": undefined
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Icon button", "localizable": undefined
		}
	},
	state:{
		markNum:{name:"markNum",type:"int",initVal:0}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0},
		{name:"focus",entry:false,next:"",desc:"",time:0},
		{name:"blur",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1RPOAH90ExGearInfo*/
	/*}#1H1RPOAH90ExGearInfo*/
};

//Auto genterated by Cody
/*#{1GGJKM84D0StartDoc*/
/*}#1GGJKM84D0StartDoc*/
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,state;
	let cssVO;
	
	appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H2CTK7KT0",
				"type":NaviTop("Cool Site Name",[108,117,125,1],"/~/-tabos/shared/assets/cklogo.svg",[255,255,255,1]),"x":0,"y":0,"face":"desktop",
				subContainers:{
					"1H2CQI73O0":[
						{
							"hash":"1H2CVL7LO0",
							"type":NaviBar([],cfgColor.fontSecondary),"position":"relative","x":0,"y":0,"w":"100%","subAlign":4,
							subContainers:{
								"1H2ISHP700":[
									{
										"hash":"1H2JAML0E0",
										"type":BtnNaviItem("Home","Home",cfgColor.fontSecondary,"/~/-tabos/shared/assets/home.svg",undefined),"position":"relative","x":0,"y":0,
									},
									{
										"hash":"1H2JAMRQF0",
										"type":BtnNaviItem("Doc","Documents",cfgColor.fontSecondary,"/~/-tabos/shared/assets/home.svg",undefined),"position":"relative","x":0,"y":0,
									}
								]
							},
						}
					],"1H2CQTOQC0":[
						{
							"hash":"1H2CTOITA0",
							"type":BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,0,0,5],
						}
					]
				},
				/*#{1H2CTK7KT0Codes*/
				/*}#1H2CTK7KT0Codes*/
			},
			{
				"hash":"1H22KV7950",
				"type":DialogTemplate("Dialog title",false,[]),"id":"DlgAlert","x":">calc(50% - 160px)","y":">calc(30%  -  81px)","display":0,"w":320,
				subContainers:{
					"1H1T7S0BE0":[
						{
							"hash":"1H22TNAVQ0",
							"type":"text","x":29,"y":5,"w":100,"h":20,"styleClass":"","color":[0,0,0],"text":"text","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						}
					]
				},
			},
			{
				"hash":"1H2CN7FUO0",
				"type":DlgMenu(),"id":"menu","x":">calc(100% - 15px)","y":30,"w":120,"anchorX":2,"corner":3,
				subContainers:{
					"1H2CN3UCE0":[
						{
							"hash":"1H2CN9SSN0",
							"type":BtnObject({"text":"Login"}),"position":"relative","x":0,"y":0,
						},
						{
							"hash":"1H2CNTN7K0",
							"type":BtnObject({"text":"Settings","enable":false}),"position":"relative","x":0,"y":0,
						}
					]
				},
			},
			{
				"hash":"1H2F72TEU0",
				"type":BtnText("primary",100,30,"Button",true,""),"x":115,"y":247,
				"OnClick":function(event){
					/*#{1H2MUD93F0FunctionBody*/
					/*}#1H2MUD93F0FunctionBody*/
				},
			},
			{
				"hash":"1H2HU0KNL0",
				"type":BoxRange(50,0,100),"x":353,"y":447,
			},
			{
				"hash":"1H2IBMFJR0",
				"type":BtnText("primary",100,30,"Button",false,""),"x":104,"y":533,"face":"",
			},
			{
				"hash":"1H2OCB3850",
				"type":BoxSteps(20),"x":145,"y":164,
			},
			{
				"hash":"1H2SEA0TE0",
				"type":BtnTextIcon(48,48,"/~/-tabos/shared/assets/lab.svg",[0,0,0,1],true,false,"Icon button"),"x":104,"y":342,
			},
			{
				"hash":"1H2V0VCVR0",
				"type":"image","x":37,"y":60,"w":178,"h":100,"styleClass":"","image":"assets/BtnText.png","fitSize":true,
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"init":{
				"#1H2CTK7KT0":{
					"display":1
				},
				/*DlgAlert*/"#1H22KV7950":{
					"display":0
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":0
				}
			},"mobile":{
				"#1H2CTK7KT0":{
					"face":"mobile"
				}
			},"desktop":{
				"#1H2CTK7KT0":{
					"face":"desktop"
				}
			},"showMenu":{
				/*DlgAlert*/"#1H22KV7950":{
					"display":0
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":1
				}
			},"showDlog":{
				/*DlgAlert*/"#1H22KV7950":{
					"display":1
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			/*#{1GGJKM84D1Create*/
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

MainUI.gearExport={
	framework: "vfact",
	hudType: "view",
	showName:"",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}, 
		"appFrame": {
			"name": "appFrame", "showName": "appFrame", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[
		{name:"init",entry:false,next:"",desc:"",time:0},
		{name:"mobile",entry:false,next:"",desc:"",time:0},
		{name:"desktop",entry:false,next:"",desc:"",time:0},
		{name:"showMenu",entry:false,next:"",desc:"",time:0},
		{name:"showDlog",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:1024,
	deviceH:768,
	/*#{1GGJKM84D0ExGearInfo*/
	/*}#1GGJKM84D0ExGearInfo*/
};

async function startApp() {
	let app,uiDef;
	window.tabOSApp=app=await VFACT.createApp();
	uiDef=UIView(MainUI);
	await VFACT.initApp(app,uiDef,{});
}
startApp();
