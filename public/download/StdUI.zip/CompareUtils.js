import pathLib from "/@path";
import {readPath,readPathInfo,applyFileMenu,applyFileDrag,applyFileDrop} from "./FileUtils.js";

//----------------------------------------------------------------------------
async function readCompDir(leftPath,rightPath,path,exFiles,exTypes){
	let uPath,lPath,rPath,leftList,rightList,list;
	let i,n,entryMap,item,name,entry,ext;
	entryMap=new Map();
	lPath=pathLib.join(leftPath,path);
	rPath=pathLib.join(rightPath,path);
	leftList=await readPath(lPath);
	rightList=await readPath(rPath);
	if(leftList){
		n=leftList.length;
		for(i=0;i<n;i++){
			item=leftList[i];
			name=item.name;
			uPath=pathLib.join(path,name);
			if(exFiles && exFiles.has(uPath)){
				continue;
			}
			if(exTypes && !item.dir){
				ext=pathLib.extname(name);
				if(exTypes.has(ext)){
					continue;
				}
			}
			entry={name:name,nameNoCase:item.nameNoCase,path:uPath,left:item,right:{path:pathLib.join(rPath,name)},dir:item.dir,leftPath:pathLib.join(lPath,name),rightPath:pathLib.join(rPath,name)};
			entryMap.set(name,entry);
		}
	}
	if(rightList){
		n=rightList.length;
		for(i=0;i<n;i++){
			item=rightList[i];
			name=item.name;
			uPath=pathLib.join(path,name);
			if(exFiles && exFiles.has(uPath)){
				continue;
			}
			if(exTypes && !item.dir){
				ext=pathLib.extname(name);
				if(exTypes.has(ext)){
					continue;
				}
			}
			entry=entryMap.get(name);
			if(entry){
				if((!!entry.dir)===(!!item.dir)){
					entry.right=item;
				}else{
					entryMap.delete(name);//Remove type-conflict items
				}
			}else{
				entry={name:name,nameNoCase:item.nameNoCase,path:uPath,left:{path:pathLib.join(lPath,name)},right:item,dir:item.dir,leftPath:pathLib.join(lPath,name),rightPath:pathLib.join(rPath,name)};
				entryMap.set(name,entry);
			}
			entryMap.set(name,entry);
		}
	}
	list=Array.from(entryMap.values());
	//Sort:
	list.sort((a,b)=>{
		let name1,name2;
		if(a.dir && !b.dir){
			return -1;
		}
		if(b.dir && !a.dir){
			return 1;
		}
		name1=a.nameNoCase;
		name2=b.nameNoCase;
		if(a.disk && b.disk){
			if(name1[0]==="-" && name2[0]!=="-"){
				return 1;
			}else if(name2[0]==="-" && name1[0]!=="-"){
				return -1;
			}
		}
		return name1<name2?-1:(name1>name2?1:0);
	});
	return list;		
}

//----------------------------------------------------------------------------
async function scanCompDir(entryObj,exFiles,exTypes){
	let lPath,rPath,lInfo,rInfo;
	let list,i,n,entry;
	let lNew,lMore,rNew,rMore;
	lPath=entryObj.leftPath;
	rPath=entryObj.rightPath;
	lNew=lMore=rNew=rMore=0;
	list=await readCompDir(lPath,rPath,"",exFiles,exTypes);
	n=list.length;
	for(i=0;i<n;i++){
		entry=list[i];
		entry.upperEntry=entryObj;
		if(entry.dir){
			let lNew,lMore,rNew,rMore;
			let subItems,subEntry;
			subItems=entry.subItems=await scanCompDir(entry,exFiles,exTypes);
			lNew=lMore=rNew=rMore=0;
			for(subEntry of subItems){
				if(subEntry.leftState==="New"){
					lNew+=1;
				}else if(subEntry.leftState==="More"){
					lMore+=1;
				}else if(subEntry.leftState==="NewAndMore"){
					lNew+=1;
					lMore+=1;
				}
				if(subEntry.rightState==="New"){
					rNew+=1;
				}else if(subEntry.rightState==="More"){
					rMore+=1;
				}else if(subEntry.rightState==="NewAndMore"){
					rNew+=1;
					rMore+=1;
				}
			}
			if(lNew===0 && lMore===0 && rNew===0 && rMore===0){
				entry.leftState="Same";
				entry.rightState="Same";
			}else{
				if(lNew>0 && lMore>0){
					entry.leftState="NewAndMore";
				}else if(lNew>0){
					entry.leftState="New";
				}else if(lMore>0){
					entry.leftState="More";
				}else{
					entry.leftState="Old";
				}
				if(rNew>0 && rMore>0){
					entry.rightState="NewAndMore";
				}else if(rNew>0){
					entry.rightState="New";
				}else if(rMore>0){
					entry.rightState="More";
				}else{
					entry.rightState="Old";
				}
			}
		}else{
			let lInfo,rInfo;
			lInfo=await readPathInfo(entry.leftPath);
			rInfo=await readPathInfo(entry.rightPath);
			if(!lInfo){
				entry.leftState="Miss";
				entry.rightState="More";
			}else if(!rInfo){
				entry.leftState="More";
				entry.rightState="Miss";
			}else if(lInfo.hash && lInfo.hash==rInfo.hash){
				entry.leftState="Same";
				entry.rightState="Same";
			}else{
				if(rInfo.modifyTime>0 && rInfo.modifyTime>0){
					if(rInfo.modifyTime>=rInfo.modifyTime){
						entry.leftState="New";
						entry.rightState="Old";
					}else{
						entry.leftState="Old";
						entry.rightState="New";
					}
				}else{
					entry.leftState="New";
					entry.rightState="New";
				}
			}
		}
		entry.scaned=true;
		if(entry.leftState==="New"){
			lNew+=1;
		}else if(entry.leftState==="More"){
			lMore+=1;
		}else if(entry.leftState==="NewAndMore"){
			lNew+=1;
			lMore+=1;
		}
		if(entry.rightState==="New"){
			rNew+=1;
		}else if(entry.rightState==="More"){
			rMore+=1;
		}else if(entry.rightState==="NewAndMore"){
			rNew+=1;
			rMore+=1;
		}
	}
	if(lNew===0 && lMore===0 && rNew===0 && rMore===0){
		entryObj.leftState="Same";
		entryObj.rightState="Same";
	}else{
		if(lNew>0 && lMore>0){
			entryObj.leftState="NewAndMore";
		}else if(lNew>0){
			entryObj.leftState="New";
		}else if(lMore>0){
			entryObj.leftState="More";
		}else{
			entryObj.leftState="Old";
		}
		if(rNew>0 && rMore>0){
			entryObj.rightState="NewAndMore";
		}else if(rNew>0){
			entryObj.rightState="New";
		}else if(rMore>0){
			entryObj.rightState="More";
		}else{
			entryObj.rightState="Old";
		}
	}
	entryObj.subItems=list;
	entryObj.scaned=true;
	return list;
}

//----------------------------------------------------------------------------
async function quickCompDir(entryObj){
	let list,i,n,entry;
	let lNew,lMore,rNew,rMore;
	lNew=lMore=rNew=rMore=0;
	list=entryObj.subItems;
	n=list.length;
	for(i=0;i<n;i++){
		entry=list[i];
		if(entry.leftState==="New"){
			lNew+=1;
		}else if(entry.leftState==="More"){
			lMore+=1;
		}else if(entry.leftState==="NewAndMore"){
			lNew+=1;
			lMore+=1;
		}
		if(entry.rightState==="New"){
			rNew+=1;
		}else if(entry.rightState==="More"){
			rMore+=1;
		}else if(entry.rightState==="NewAndMore"){
			rNew+=1;
			rMore+=1;
		}
	}
	if(lNew===0 && lMore===0 && rNew===0 && rMore===0){
		entryObj.leftState="Same";
		entryObj.rightState="Same";
	}else{
		if(lNew>0 && lMore>0){
			entryObj.leftState="NewAndMore";
		}else if(lNew>0){
			entryObj.leftState="New";
		}else if(lMore>0){
			entryObj.leftState="More";
		}else{
			entryObj.leftState="Old";
		}
		if(rNew>0 && rMore>0){
			entryObj.rightState="NewAndMore";
		}else if(rNew>0){
			entryObj.rightState="New";
		}else if(rMore>0){
			entryObj.rightState="More";
		}else{
			entryObj.rightState="Old";
		}
	}
}
export {readCompDir,scanCompDir,quickCompDir};


