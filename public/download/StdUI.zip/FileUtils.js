import {VFACT,callAfter,sleep} from "/@vfact";
import {appCfg} from "./cfg/appCfg.js";
import {tabFS} from "/@tabos";
import pathLib from "/@path";
import {path2Zip,zip2Path} from "/@zippath";

const $ln=VFACT.lanCode;
let img,dragIcons={};
img=document.createElement("img");
img.src=document.location.origin+appCfg.sharedAssets+"/drag_file.svg";
dragIcons.file=img;

img=document.createElement("img");
img.src=document.location.origin+appCfg.sharedAssets+"/drag_folder.svg";
dragIcons.dir=img;

img=document.createElement("img");
img.src=document.location.origin+appCfg.sharedAssets+"/drag_multi.svg";
dragIcons.multi=img;

//------------------------------------------------------------------------
function getDiskName(path){
	let pos;
	pos=path.indexOf("/",1);
	if(pos>0){
		return path.substring(1,pos);
	}
	return path.substring(1);
};

//----------------------------------------------------------------------------
/**
 * This function reads the contents of a specified path and returns a list of entries, with optional sorting.
 *
 * @param {string} path - The path to read entries from.
 * @param {string} sort - The sorting order for the entries (e.g., 'Name', 'Size').
 */
async function readPath(path,sort){
	let list,entry,subs;
	list=await tabFS.getEntries(path);
	if(list){
		if(path==="/"){
			for(entry of list){
				entry.nameNoCase=entry.name.toLowerCase();
				entry.extName=pathLib.extname(entry.nameNoCase);
				entry.path=path+entry.name;
				/*if(entry.dir){
					subs=await tabFS.getEntries(entry.path);
					entry.itemCnt=subs?subs.length:0;
				}*/
			}
		}else{
			for(entry of list){
				entry.nameNoCase=entry.name.toLowerCase();
				entry.extName=pathLib.extname(entry.nameNoCase);
				entry.path=path+"/"+entry.name;
				/*if(entry.dir){
					subs=await tabFS.getEntries(entry.path);
					entry.itemCnt=subs?subs.length:0;
				}*/
			}
		}
		if(sort){
			switch(sort){
				default:
				case "Name":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						name1=a.nameNoCase;
						name2=b.nameNoCase;
						if(a.disk && b.disk){
							if(name1[0]==="-" && name2[0]!=="-"){
								return 1;
							}else if(name2[0]==="-" && name1[0]!=="-"){
								return -1;
							}
						}
						return name1<name2?-1:(name1>name2?1:0);
					});
					break;
				}
				case "NameR":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
						}
						name1=a.nameNoCase;
						name2=b.nameNoCase;
						return name1<name2?1:(name1>name2?-1:0);
					});
					break;
				}
				case "Size":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
							name1=a.nameNoCase;
							name2=b.nameNoCase;
							return name1<name2?-1:(name1>name2?1:0);
						}
						return a.size>b.size?1:(a.size<b.size?-1:0);
					});
					break;
				}
				case "SizeR":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
							name1=a.nameNoCase;
							name2=b.nameNoCase;
							return name1<name2?-1:(name1>name2?1:0);
						}
						return a.size>b.size?-1:(a.size<b.size?1:0);
					});
					break;
				}
				case "Type":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
						}
						name1=a.extName;
						name2=b.extName;
						if(name1===name2){
							name1=a.nameNoCase;
							name2=b.nameNoCase;
							return name1<name2?-1:(name1>name2?1:0);
						}
						return name1<name2?-1:(name1>name2?1:0);
					});
					break;
				}
				case "TypeR":{
					list.sort((a,b)=>{
						let name1,name2;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
						}
						name1=a.extName;
						name2=b.extName;
						if(name1===name2){
							name1=a.nameNoCase;
							name2=b.nameNoCase;
							return name1<name2?-1:(name1>name2?1:0);
						}
						return name1<name2?1:(name1>name2?-1:0);
					});
				}
				case "Time":{
					list.sort((a,b)=>{
						let d;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
						}
						d=a.modifyTime-b.modifyTime;
						return Number.isFinite(d)?d:-1;
					});
					break;
				}
				case "TimeR":{
					list.sort((a,b)=>{
						let d;
						if(a.dir && !b.dir){
							return -1;
						}
						if(b.dir && !a.dir){
							return 1;
						}
						if(a.dir && b.dir){
							if(a[0]==="-" && b[0]!=="-"){
								return 1;
							}else if(b[0]==="-" && a[0]!=="-"){
								return -1;
							}
						}
						d=b.modifyTime-a.modifyTime;
						return Number.isFinite(d)?d:-1;
					});
					break;
				}

			}
		}
	}
	return list;
};

//----------------------------------------------------------------------------
async function readPathInfo(path){
	let entry;
	entry=await tabFS.getEntry(path);
	if(entry){
		entry.path=path;
		entry.nameNoCase=entry.name.toLowerCase();
		entry.extName=pathLib.extname(entry.nameNoCase);
	}
	return entry;
};

//----------------------------------------------------------------------------
async function readDirInfo(path,vo){
	let list,i,n,entry;
	if(!vo){
		entry=await readPathInfo(path);
		if(!entry.dir){
			return null;
		}
		vo={
			...entry,
			entryNum:0,
			size:0,
			modifyTime:0
		};
	}
	list=(await tabFS.getEntries(path))||[];
	n=list.length;
	for(i=0;i<n;i++){
		entry=list[i];
		if(entry.size>0){
			vo.size+=entry.size;
		}
		vo.modifyTime=entry.modifyTime>vo.modifyTime?entry.modifyTime:vo.modifyTime
		if(entry.dir){
			await readDirInfo(pathLib.join(path,entry.name),vo);
		}
	}
	vo.entryNum+=n;
	return vo;
};

//----------------------------------------------------------------------------
async function checkFilesExist(files){
	let curFiles=[],path,entry;
	for(path of files){
		entry=await tabFS.getEntry(path);
		if(entry){
			curFiles.push(path);
		}
	}
	return curFiles.length>0?curFiles:null;
};

//----------------------------------------------------------------------------
async function copyMoveFile(app,srcPath,dstDirPath,isMove){
	let basePath,srcList,srcDirs,orgPath,tgtPath,tgtEntry;
	let replaceAll,skipAll,askAll,i,n;

	srcList=[];
	srcDirs=[];
	async function checkInPath(path){
		let entry;
		entry=await tabFS.getEntry(basePath+"/"+path);
		if(entry.dir){
			let list,sub;
			if(dstDirPath.startsWith(basePath+"/"+path)){
				window.alert(`Can't copy move ${path} to ${dstDirPath}!`);
				throw "Error";
			}
			list=await tabFS.getEntries(basePath+"/"+path);
			for(sub of list){
				checkInPath(path+"/"+sub.name);
			}
			srcDirs.push(path);
		}else{
			srcList.push(path);
		}
	};
	//Make copy list:
	try{
		if(Array.isArray(srcPath)){
			let bn;
			basePath=pathLib.dirname(srcPath[0]);
			if(basePath===dstDirPath){
				return;
			}
			bn=basePath.length+1;
			for(let apath of srcPath){
				if(!apath.startsWith(basePath)){
					throw new Error("Copy/ move items must have same dirname.");
				}
				await checkInPath(apath.substring(bn));
			}
		}else{
			basePath=pathLib.dirname(srcPath);
			if(basePath===dstDirPath){
				return;
			}
			await checkInPath(pathLib.basename(srcPath));
		}
	}catch(err){
		return;
	}

	//Check if all dir name is ok
	for(orgPath of srcDirs){
		tgtPath=dstDirPath+"/"+orgPath;
		tgtEntry=await tabFS.getEntry(tgtPath);
		if(tgtEntry && !tgtEntry.dir){
			window.alert(`Can't overwrite file ${tgtPath} with dir ${basePath+"/"+orgPath}`);
			return;
		}
	}

	app.showWait("Working...");
	//Check if copy list need overwrite:
	n=srcList.length;
	for(i=0;i<n;i++){
		orgPath=srcList[i];
		tgtPath=dstDirPath+"/"+orgPath;
		tgtEntry=await tabFS.getEntry(tgtPath);
		if(tgtEntry){
			if(tgtEntry.dir){
				window.alert(`Can't overwrite dir ${tgtPath} with file ${basePath+"/"+orgPath}`);
				app.closeWait();
				return;
			}
			if(replaceAll){
				//This is OK:
			}else if(skipAll){
				srcList.splice(i,1);
				i--;n--;
			}else if(askAll){
				if(!window.confirm(`Replace ${tgtPath}?`)){
					srcList.splice(i,1);
					i--;n--;
				}
			}else{
				if(window.confirm(`Replace ${tgtPath} and all other files?`)){
					replaceAll=1;
				}else if(isMove){
					window.alert("Move operation aborted.");
					app.closeWait();
					return;							
				}else if(window.confirm(`Abort copy opteration?`)){
					app.closeWait();
					return;							
				}else if(window.confirm(`Skip all existing files?`)){
					skipAll=1;
				}else{
					askAll=1;
				}
			}
		}
	}

	let delItems,newItems;
	newItems=[];
	n=srcDirs.length;
	for(i=0;i<n;i++){
		tgtPath=dstDirPath+"/"+srcDirs[i];
		await tabFS.newDir(tgtPath,{recursive:true});
		newItems.push(tgtPath);
	}

	n=srcList.length;
	for(i=0;i<n;i++){
		orgPath=basePath+"/"+srcList[i];
		tgtPath=dstDirPath+"/"+srcList[i];
		await tabFS.copy(orgPath,tgtPath,{force:true});
		newItems.push(tgtPath);
	}

	if(isMove){
		delItems=[];
		//Remove dirs:
		n=srcDirs.length;
		for(i=0;i<n;i++){
			orgPath=basePath+"/"+srcDirs[i];
			await tabFS.del(orgPath,{recursive:true});
			delItems.push(orgPath);
		}
		//Remove root files:
		n=srcList.length;
		for(i=0;i<n;i++){
			orgPath=srcList[i];
			if(orgPath.indexOf("/")<0){
				orgPath=basePath+"/"+orgPath;
				await tabFS.del(orgPath,{recursive:true});
				delItems.push(orgPath);
			}
		}
	}
	app.closeWait();
	return {new:newItems,del:delItems};
}

//----------------------------------------------------------------------------
async function makeZip(path,items,tty=null){
	return await path2Zip(path,items,tty);
};

//----------------------------------------------------------------------------
async function extractZip(path,zipFile,tty=null){
	return await zip2Path(path,zipFile,0,tty);
};

//----------------------------------------------------------------------------
function downloadDataAsFile(data,fileName){
	let blob, url;
	let e;
	blob = new Blob([data], {type: "application/octet-stream"});
	url = URL.createObjectURL(blob);
	VFACT.webFileDownload.download = fileName;
	VFACT.webFileDownload.href = url;

	//Generate a mouse click:
	e = document.createEvent('MouseEvents');
	e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
	VFACT.webFileDownload.dispatchEvent(e);

	//Release the URLData:
	window.setTimeout(() => {
		URL.revokeObjectURL(url);
	}, 10000);
}

//----------------------------------------------------------------------------
// Wrap readEntries in a promise to make working with readEntries easier
// readEntries will return only some of the entries in a directory
// e.g. Chrome returns at most 100 entries at a time
async function readEntriesPromise(directoryReader) {
	try {
		return await new Promise((resolve, reject) => {
			directoryReader.readEntries(resolve, reject);
		});
	} catch (err) {
		console.log(err);
	}
}

// Get all the entries (files or sub-directories) in a directory 
// by calling readEntries until it returns empty array
async function readAllDirectoryEntries(directoryReader) {
	let entries = [];
	let readEntries = await readEntriesPromise(directoryReader);
	while (readEntries.length > 0) {
		entries.push(...readEntries);
		readEntries = await readEntriesPromise(directoryReader);
	}
	return entries;
}

async function getDataTransferFiles(dataTransferItemList,wantDir=true) {
	let fileEntries = [];
	// Use BFS to traverse entire directory/file structure
	let queue = [];
	// Unfortunately dataTransferItemList is not iterable i.e. no forEach
	for (let i = 0; i < dataTransferItemList.length; i++) {
		queue.push(dataTransferItemList[i].webkitGetAsEntry());
	}
	while (queue.length > 0) {
		let entry = queue.shift();
		if(entry){
			if (entry.isFile) {
				fileEntries.push(entry);
			} else if (entry.isDirectory) {
				if(wantDir){
					fileEntries.push(entry);
				}
				queue.push(...await readAllDirectoryEntries(entry.createReader()));
			}
		}
	}
	return fileEntries;
}

//----------------------------------------------------------------------------
async function copyDataTransfer(app,dt,dstDirPath){
	let basePath,mainUI;

	function getItemFile(item){
		return new Promise((OnDone,OnError)=>{
			item.file(OnDone);
		});
	}

	mainUI=app.mainUI;
	basePath=dstDirPath;
	if(!basePath){
		return;
	}
	if(dt){
		let item,path,oldEntry,file;
		let files2Copy=[];
		let dirs2Make=[];
		let files=await getDataTransferFiles(dt.items);
		let overWriteAll=false;
		let ignoreAll=false;
		let askOneByOne=false;
		let filesCopied=[];
		app.showWait("Copying files...");
		if(files.length===1 && files[0].name.toLowerCase().endsWith(".zip")){
			if(window.confirm((($ln==="CN")?("在这里解压缩zip文件?"):/*EN*/("Extract zip file here?")))){
				app.showWait("Unpackaging zip...");
				file=await getItemFile(files[0]);
				filesCopied=await extractZip(basePath,file,0);
				app.closeWait();
				return filesCopied;
			}
		}
		//First check overwrites:
		for(let i=0,n=files.length;i<n;i++){
			item=files[i];
			if(item.isFile){
				path=pathLib.join(basePath,item.fullPath.substring(1));
				oldEntry=await tabFS.getEntry(path);
				if(!oldEntry){
					files2Copy.push(item);
				}else{
					if(oldEntry.dir){
						//Can't overwrite a dir with file:
						window.alert((($ln==="CN")?(`中止：无法用文件覆盖文件夹"${path}"，未复制任何文件。`):/*EN*/(`Abort: can't overwrite folder "${path} with a file, no files copied.`)));
						app.closeWait();
						return;
					}
					if(overWriteAll){
						files2Copy.push(item);
					}else if(ignoreAll){
						//Pass this file:
					}else if(askOneByOne){
						if(window.confirm((($ln==="CN")?(`${path} 文件已存在，是否覆盖？`):/*EN*/(`${path} file existed, overwrite it?`)))){
							files2Copy.push(item);
						}
					}else{
						if(window.confirm((($ln==="CN")?(`${path} file existed, overwrite it and all other files?`):/*EN*/(`${path} file existed, overwrite it and all other files?`)))){
							files2Copy.push(item);
							overWriteAll=true;
						}else if(window.confirm((($ln==="CN")?(`您是否要忽略所有已存在的文件？`):/*EN*/(`Do you want to ignore all existed files?`)))){
							ignoreAll=true;
						}else if(window.confirm((($ln==="CN")?(`是否继续复制并逐个询问是否覆盖文件？`):/*EN*/(`Continue to copy and ask overwrite file one by one?`)))){
							askOneByOne=true;
						}else{
							app.closeWait();
							return;
						}
					}
				}
			}else if(item.isDirectory){
				path=pathLib.join(basePath,item.fullPath.substring(1));
				oldEntry=await tabFS.getEntry(path);
				if(!oldEntry){
					dirs2Make.push(path);
				}else{
					if(!oldEntry.dir){
						window.alert((($ln==="CN")?(`中止：无法用文件夹覆盖文件 "${path}"，未复制任何文件。`):/*EN*/(`Abort: can't overwrite file "${path}" with a folder, no files copied.`)));
						app.closeWait();
						return;
					}
				}
			}
		}
		//2) Make dirs:
		for(let i=0,n=dirs2Make.length;i<n;i++){
			path=dirs2Make[i];
			await tabFS.newDir(path);
			mainUI.OnNewDir(path);
		}
		//3) Copy files:
		for(let i=0,n=files2Copy.length;i<n;i++){
			item=files2Copy[i];
			file=await getItemFile(item);
			if(!file){
				continue;
			}
			path=pathLib.join(basePath,item.fullPath.substring(1));
			await tabFS.writeFile(path,file);
			filesCopied.push(path);
		}
		//4) Update view:
		app.closeWait();
		return filesCopied;
	}
};

//----------------------------------------------------------------------------
async function uploadOneFile(path,file,overwrite){
	if(overwrite){
		await tabFS.writeFile(path,file);
		return true;
	}
	let entry;
	entry=await tabFS.getEntry(path);
	if(entry)
		return false;
	await tabFS.writeFile(path,file);
	return true;
};

//----------------------------------------------------------------------------
async function openDeviceFile(multi){
	let pms,callback;
	const fileInput = document.createElement('input');
	fileInput.type = 'file';
	if(multi){
		fileInput.multiple = true;
	}
	fileInput.style.display = 'none';

	document.body.appendChild(fileInput);

	fileInput.addEventListener('change', (event) => {
		const files = event.target.files;
		callAfter(()=>{
			document.body.removeChild(fileInput);
		},30000);
		callback(files);
	});
	pms=new Promise((resolve,reject)=>{
		callback=resolve;
	});

	fileInput.click();
	return await pms;
};

//----------------------------------------------------------------------------
//This is for browser upload dialog and paste action
async function uploadFiles2Path(app,files,path){
	let basePath,i,n,pathes,overPathes;
	let overwrite;
	basePath=path;
	if(!basePath){
		return;
	}
	n=files.length;
	if(n===1 && files[0].name.toLowerCase().endsWith(".zip")){
		if(window.confirm((($ln==="CN")?("在这里解压缩zip文件?"):/*EN*/("Extract zip file here?")))){
			app.showWait("Unpackaging zip...");
			extractZip(basePath,files[0],0);
			app.closeWait();
			return;
		}
	}
	app.showWait("Upload files...");
	pathes=[];
	for(i=0;i<n;i++){
		pathes.push(basePath+"/"+files[i].name);
	}
	overPathes=await checkFilesExist(pathes);
	if(overPathes && overPathes.length>0){
		let info;
		info=overPathes.length>1?(""+overPathes[0]+" and more files already exist, overwrite?"):(""+overPathes[0]+" already exists, overwrite?");
		if(window.confirm(info)){
			overwrite=1;
		}else{
			if(window.confirm((($ln==="CN")?("上传不存在的文件？"):/*EN*/("Upload none-exist file(s)?")))){
				overwrite=0;
			}
		}
	}
	{
		let pList=[],fList=[],i,n;
		n=files.length;
		for(i=0;i<n;i++){
			fList.push(files[i].name);
			pList.push(uploadOneFile(basePath+"/"+files[i].name,files[i],overwrite));
		}
		await Promise.all(pList);
	}
	app.closeWait();
};

//----------------------------------------------------------------------------
function applyFileMenu(hud,options){
	let path,entry,opSet,addOn;
	async function showMenu(evt){
		let items,item;
		if(options.menuItems){
			items=options.menuItems;
		}else if(entry.dir){
			items=[
				{text:(($ln==="CN")?("打开"):/*EN*/("Open")),action:"Open"},
				{text:(($ln==="CN")?("重命名"):/*EN*/("Rename")),action:"Rename"},
				{text:(($ln==="CN")?("拷贝"):/*EN*/("Copy")),action:"Copy"},
				"_",
				{text:(($ln==="CN")?("创建Zip包"):/*EN*/("Make zip")),action:"MakeZip"},
				{text:(($ln==="CN")?("上传文件到此目录"):/*EN*/("Upload file(s) to this folder")),action:"Upload"},
				{text:(($ln==="CN")?("下载目录为zip"):/*EN*/("Download folder zip")),action:"Download"},
				"_",
				{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),action:"Delete"},
			];
		}else{
			items=[
				{text:(($ln==="CN")?("打开"):/*EN*/("Open")),action:"Open"},
				{text:(($ln==="CN")?("编辑"):/*EN*/("Edit")),action:"Edit"},
				{text:(($ln==="CN")?("重命名"):/*EN*/("Rename")),action:"Rename"},
				"_",
				{text:(($ln==="CN")?("拷贝"):/*EN*/("Copy")),action:"Copy"},
				{text:(($ln==="CN")?("创建Zip包"):/*EN*/("Make zip")),action:"MakeZip"},
				{text:(($ln==="CN")?("下载"):/*EN*/("Download")),action:"Download"},
				"_",
				{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),action:"Delete"},
			];
		}
		opSet=options.fileMenuOps;
		if(Array.isArray(opSet)){
			let i,n;
			opSet=new Set(opSet);
			n=items.length;
			items=items.filter((item)=>{
				return opSet.has(item.action);
			});
		}
		addOn=VFACT.app.addOn;
		if(addOn){
			let calls,call;
			calls=addOn.getSlot("FileMenu");
			for(call of calls){
				call(entry,items);
			}
		}
		item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:hud,w:150,event:evt,
			items:items
		});
		if(!item){
			return;
		}
		let callback;
		callback=item.exec||hud["handleFileMenu"+item.action]||options.handleFileMenu;
		if(callback){
			callback(item.action,hud,entry);
		}
	}
	path=hud.path;
	entry=hud.entry;
	hud.webObj.addEventListener('contextmenu', e => {
		e.preventDefault();
	});
	hud.showFileMenu=showMenu;
}

//----------------------------------------------------------------------------
function applyFileDrag(hud,listBox,opts){
	opts=opts||{};
	VFACT.applyDrag(hud,{
		OnDragStart(evt){
			let data,entry;
			entry=hud.pathEntry;
			if(entry){
				if(listBox && listBox.selected.size>1){
					let list;
					list=Array.from(listBox.selected).map(node=>node.itemObj.path);
					data=`{"type":"pathlist","list":${JSON.stringify(list)}}`;
					evt.dataTransfer.setDragImage(dragIcons.multi,16,16);
					evt.dataTransfer.setData("tabos/pathlist",data);
					evt.dataTransfer.dropEffect="move";
				}else{
					data=`{"type":"path","path":"${entry.path}","dir":${!!entry.dir}}`;
					evt.dataTransfer.setData("tabos/path",data);
					if(entry.dir){
						evt.dataTransfer.setDragImage(dragIcons.dir,16,16);
					}else{
						evt.dataTransfer.setDragImage(dragIcons.file,16,16);
					}
					evt.dataTransfer.dropEffect="move";
				}
			}
		},
		OnDragEnd(evt){
			if(opts.OnDragEnd){
				opts.OnDragEnd(hud);
			}else{
				hud.OnDragEnd && hud.OnDragEnd();
			}
			evt.preventDefault();
		}
	});
}

//----------------------------------------------------------------------------
function applyFileDrop(hud,opts){
	let webObj;
	let dragOverCnt=0;
	let dragging=0;
	let app=VFACT.app;
	opts=opts||{};
	webObj=opts.webObj||hud.webObj;
	VFACT.applyDrop(hud,{
		OnDragEnter(evt){
			if(evt.target===webObj || opts.allowTree){
				let types;
				types=[...evt.dataTransfer.types];
				if(types.includes("tabos/path")||types.includes("tabos/pathlist")||types.includes("Files")){
					dragging=1;
					evt.dataTransfer.dropEffect="move";
					evt.preventDefault();
					evt.stopPropagation();
				}
				hud.showFace("over");
			}
		},
		OnDragOver(evt){
			if(dragging && (evt.target===webObj || opts.allowTree)){
				if(dragOverCnt>0){
					dragOverCnt++;
					dragOverCnt=dragOverCnt&15;
					evt.stopPropagation();
					evt.preventDefault();
					return;
				}
				if(evt.metaKey|| evt.ctrlKey||evt.shiftKey){
					evt.dataTransfer.dropEffect="copy";
				}else{
					evt.dataTransfer.dropEffect="move";
				}
				evt.stopPropagation();
				evt.preventDefault();
			}
		},
		OnDragLeave(evt){
			if(evt.target===webObj|| opts.allowTree){
				dragging=0;
				hud.showFace("up");
			}
		},
		OnDrop(evt){
			let types,pathList,tgtPath;
			if(dragging){
				if(!hud.path){
					return;
				}
				tgtPath=opts.path||hud.path;
				types=[...evt.dataTransfer.types];
				if(types.includes("tabos/path")){
					let data,path;
					data=evt.dataTransfer.getData("tabos/path");
					data=JSON.parse(data);
					path=data.path;
					if(tgtPath.startsWith(path)){
						window.alert(`Can't copy/ move ${path} into ${tgtPath}`);
						return;
					}
					console.log(`Will copy ${path} into dir ${tgtPath}`);
					if(evt.shiftKey){
						copyMoveFile(app,path,tgtPath,false).then((result)=>{
							if(result && result.new){
								if(result.new){
									if(opts.OnDropFile){
										opts.OnDropFile(result.new,hud);
									}else{
										hud.OnDropFile && hud.OnDropFile(result.new,hud);
									}
								}
							}
						});
					}else{
						copyMoveFile(app,path,tgtPath,true).then((result)=>{
							if(result){
								if(result.new){
									if(opts.OnDropFile){
										opts.OnDropFile(result.new,hud);
									}else{
										hud.OnDropFile && hud.OnDropFile(result.new,hud);
									}
								}
								if(result.del){
									if(opts.OnDropDel){
										opts.OnDropDel(result.del,hud);
									}
								}
							}
						});
					}
					evt.preventDefault();
					evt.stopPropagation();
				}else if(types.includes("tabos/pathlist")){
					let data,pathList;
					data=evt.dataTransfer.getData("tabos/pathlist");
					data=JSON.parse(data);
					pathList=data.list;
					console.log(`Will copy ${pathList} into dir ${hud.path}`);
					if(evt.shiftKey){
						copyMoveFile(app,pathList,tgtPath,false).then((result)=>{
							if(result && result.new){
								if(result.new){
									if(opts.OnDropFile){
										opts.OnDropFile(result.new,hud);
									}else{
										hud.OnDropFile && hud.OnDropFile(result.new,hud);
									}
								}
							}
						});
					}else{
						copyMoveFile(app,pathList,tgtPath,true).then((result)=>{
							if(result && result.new){
								if(result.new){
									if(opts.OnDropFile){
										opts.OnDropFile(result.new,hud);
									}else{
										hud.OnDropFile && hud.OnDropFile(result.new,hud);
									}
								}
								if(result.del){
									if(opts.OnDropDel){
										opts.OnDropDel(result.del,hud);
									}
								}
							}
						});
					}
					evt.preventDefault();
					evt.stopPropagation();
				}else if(types.includes("Files")){
					let dt=evt.dataTransfer;
					copyDataTransfer(app,dt,tgtPath).then((pathList)=>{
						if(opts.OnDropFile){
							opts.OnDropFile(pathList,hud);
						}else{
							hud.OnDropFile && hud.OnDropFile(pathList,hud);
						}
					});
					evt.preventDefault();
					evt.stopPropagation();
				}
			}
		}
	});
}

//----------------------------------------------------------------------------
async function doPasteFiles(app,copyVO,toPath){
	let dstBase,srcBase,files,srcPath,dstPath,fileName,dstEntry,srcEntry,extName;
	let plist,overwrite=-1,stub;
	let copyList=[],newDirList=[];
	dstBase=toPath;
	if(!dstBase){
		return;
	}
	app.showWait("Copying files...");
	files=copyVO.files;
	srcBase=copyVO.basePath;
	if(srcBase===dstBase){
		let cnt;
		for(srcPath of files){
			srcEntry=await tabFS.getEntry(srcPath);
			if(srcEntry){
				fileName=pathLib.basename(srcPath);
				extName=pathLib.extname(fileName);
				fileName=fileName.substring(0,fileName.length-extName.length);
				cnt=0;
				dstPath=dstBase+"/"+fileName+" copy"+extName;
				dstEntry=await tabFS.getEntry(dstPath);
				while(dstEntry){
					cnt++;
					dstPath=dstBase+"/"+fileName+" copy"+cnt+extName;
					dstEntry=await tabFS.getEntry(dstPath);
				}
				copyList.push([srcPath,dstPath]);
				if(srcEntry.dir){
					newDirList.push(dstPath);
				}
			}
		}
	}else{
		for(srcPath of files){
			fileName=pathLib.basename(srcPath);
			dstPath=dstBase+"/"+fileName;
			srcEntry=await tabFS.getEntry(srcPath);
			if(srcEntry){
				dstEntry=await tabFS.getEntry(dstPath);
				if(!dstEntry || overwrite===1){
					copyList.push([srcPath,dstPath]);
					if(srcEntry.dir){
						newDirList.push(dstPath);
					}
				}else if(overwrite===-1){
					if(window.confirm((($ln==="CN")?(`是否覆盖${dstPath}和其他文件？`):/*EN*/(`Overwrite ${dstPath} and other files?`)))){
						overwrite=1;
						copyList.push([srcPath,dstPath]);
						if(srcEntry.dir){
							newDirList.push(dstPath);
						}
					}else if(window.confirm((($ln==="CN")?(`放弃粘贴操作？`):/*EN*/(`Give up paste operation?`)))){
						return;
					}else if(window.confirm((($ln==="CN")?(`忽略所有覆盖文件？`):/*EN*/(`Ignore all overwrite files?`)))){
						overwrite=0;
					}else{
						overwrite=2;
					}
				}else if(overwrite===2){
					if(window.confirm((($ln==="CN")?(`覆盖 ${dstPath} 吗？`):/*EN*/(`Overwrite ${dstPath}?`)))){
						copyList.push([srcPath,dstPath]);
						if(srcEntry.dir){
							newDirList.push(dstPath);
						}
					}
				}
			}
		}
	}
	plist=[];
	for(stub of copyList){
		plist.push(tabFS.copy(stub[0],stub[1],{force:1}));
	}
	await Promise.allSettled(plist);
	app.closeWait();
};

//----------------------------------------------------------------------------
async function pasteToPath(app,e,path){
	let dt,cpText;
	dt=e.clipboardData;
	cpText=dt.getData("text/plain");
	if(cpText){
		let cpVO;
		try{
			cpVO=JSON.parse(cpText);
			if(cpVO && cpVO["$CokeFilesCopy"]){
				cpVO=cpVO["$CokeFilesCopy"];
			}
		}catch(err){
			cpVO=null;
		}
		if(cpVO){
			await doPasteFiles(app,cpVO,path);
		}
		return;
	}
	return await copyDataTransfer(app,dt,path)
}

export {getDiskName,readPath,readPathInfo,readDirInfo,downloadDataAsFile,copyMoveFile,copyDataTransfer,applyFileMenu,applyFileDrag,applyFileDrop,extractZip,makeZip,openDeviceFile,pasteToPath,uploadFiles2Path};