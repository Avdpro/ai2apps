import pathLib from "/@path";
import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;
let url=import.meta.url;
let dir=pathLib.dirname(url);
export default {
	type:"app",
	name:"Terminal",
	caption:(($ln==="CN")?("终端"):/*EN*/("Terminal")),
	main:`${dir}/app.html`,
	package:"terminal",
	catalog:["System"],
	icon:`${dir}/favicon.svg`,
	iconApp:null,
	appFrame:{
		main:`${dir}/app.html`,
		group:`${dir}/app.html`,
		title:(($ln==="CN")?("终端"):/*EN*/("Terminal")),
		icon:`${dir}/favicon.svg`,
		multiFrame:true,
		width:800,height:450,
		maxable:true,
	}
};
