import pathLib from "/@path";
import {VFACT} from "/@vfact";
let url=import.meta.url;
let dir=pathLib.dirname(url);
let $ln=VFACT.lanCode;
export default {
	type:"app",
	name:"Files",
	caption:(($ln==="CN")?("文件管理器"):/*EN*/("Files")),
	main:`${dir}/app.html`,
	package:"files",
	catalog:["System"],
	icon:`${dir}/favicon.svg`,
	iconApp:null,
	appFrame:{
		main:`${dir}/app.html`,
		group:`${dir}/app.html`,
		title:(($ln==="CN")?("文件管理器"):/*EN*/("Files")),
		icon:`${dir}/favicon.svg`,
		width:800,height:600,
		maxable:false,
		multiFrame:true,
	}
};
