//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnModelCard} from "./BtnModelCard.js";
/*#{1J2OJ9QB10StartDoc*/
import pathLib from "/@path";
import {tabNT,tabFS} from "/@tabos";
import {getLocalAppInfo} from "/@pkg/pkgUtil.js";
/*}#1J2OJ9QB10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIModels=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxCatalog,txtCatalog,boxSort,txtSort,txtFind,boxPageBtns,btnPrevPage,txtPage,btnNextPage,installedOnlyChecked,boxModels,tipLoading;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1J2OJ9QB11LocalVals*/
	const app=VFACT.app;
	let catalog="Chat";//"Agent";//"Deployable";
	let sortBy="Score";
	let pageIndex=0;
	let loadVersion=0;
	let curPageModels=null;
	let nextPageModels=null;
	let prevPageModels=null;
	let showInstalledOnly=false;
	/*}#1J2OJ9QB11LocalVals*/
	
	/*#{1J2OJ9QB11PreState*/
	/*}#1J2OJ9QB11PreState*/
	/*#{1J2OJ9QB11PostState*/
	/*}#1J2OJ9QB11PostState*/
	cssVO={
		"hash":"1J2OJ9QB11",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1J2OJFTUD0",
				"type":"hud","id":"BoxTop","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,10,0,10],"minW":"","minH":40,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,
				children:[
					{
						"hash":"1J2OJT20R0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("分类:"):("Catalog:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1J2OJKSUM0",
						"type":"box","id":"BoxCatalog","position":"relative","x":0,"y":0,"w":160,"h":28,"cursor":"pointer","margin":[0,20,0,0],"padding":[0,1,0,10],"minW":"",
						"minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"corner":8,"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1J2OJM6FC0",
								"type":"text","id":"TxtCatalog","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBody"],"text":(($ln==="CN")?("对话模型"):("Chat models")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","flex":true,
							},
							{
								"hash":"1J2OJNJDT0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.setCatalog(this,event);
								},
							}
						],
						"OnClick":function(event){
							self.setCatalog(this,event);
						},
					},
					{
						"hash":"1J2OJRR5D0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("排序:"):("Sort:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1J2OJOSLE0",
						"type":"box","id":"BoxSort","position":"relative","x":0,"y":0,"w":160,"h":28,"cursor":"pointer","padding":[0,1,0,10],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"corner":8,"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1J2OJOSLF0",
								"type":"text","id":"TxtSort","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBody"],"text":(($ln==="CN")?("综合评分"):("Overall score")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","flex":true,
							},
							{
								"hash":"1J2OJOSLG3",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.setSort(this,event);
								},
							}
						],
						"OnClick":function(event){
							self.setSort(this,event);
						},
					},
					{
						"hash":"1J43FF2BJ0",
						"type":"text","id":"TxtFind","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"100%","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":"Find: OpenAI:","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1J4S3513G0",
						"type":"hud","id":"BoxPageBtns","position":"relative","x":0,"y":0,"w":150,"h":40,"margin":[0,0,0,20],"padding":[0,10,0,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,"flex":true,
						children:[
							{
								"hash":"1J4S2RIB30",
								"type":BtnText("secondary",40,24,"<",false,""),"id":"BtnPrevPage","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.prePage(this,event);
								},
							},
							{
								"hash":"1J4S35S580",
								"type":"text","id":"TxtPage","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBody"],"text":(($ln==="CN")?("第 - 页"):("Page: -")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"",
							},
							{
								"hash":"1J4S2V9HK0",
								"type":BtnText("secondary",40,24,">",false,""),"id":"BtnNextPage","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.nextPage(this,event);
								},
							},
							{
								"hash":"1JGOGVFS40",
								"type":BtnCheck(20,(($ln==="CN")?("仅看已安装"):("Show installed only")),false,false),"id":"InstalledOnlyChecked","position":"relative","x":18,"y":0,
								/*#{1JGOGVFS40Codes*/
								OnCheck(check){
									showInstalledOnly=check;
									pageIndex=0;
									self.loadModels();
								}
								/*}#1JGOGVFS40Codes*/
							}
						],
					}
				],
			},
			{
				"hash":"1J4U9RB1B0",
				"type":"hud","id":"BoxScroll","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"auto-y","padding":[0,0,80,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y","flex":true,
				children:[
					{
						"hash":"1J2OJTV600",
						"type":"hud","id":"BoxModels","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,10,10,10],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-x","itemsWrap":1,
						children:[
						],
					}
				],
			},
			{
				"hash":"1JJDI4QJ70",
				"type":"text","id":"tipLoading","position":"relative","x":0,"y":"-50%","w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
				"text":(($ln==="CN")?("加载中..."):("Loading...")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
			}
		],
		/*#{1J2OJ9QB11ExtraCSS*/
		/*}#1J2OJ9QB11ExtraCSS*/
		faces:{
			"find":{
				"#1J2OJT20R0":{
					"display":0
				},
				/*BoxCatalog*/"#1J2OJKSUM0":{
					"display":0
				},
				"#1J2OJRR5D0":{
					"display":0
				},
				/*BoxSort*/"#1J2OJOSLE0":{
					"display":0
				},
				/*TxtFind*/"#1J43FF2BJ0":{
					"display":1
				},
				/*BoxPageBtns*/"#1J4S3513G0":{
					"display":0
				}
			},"!find":{
				"#1J2OJT20R0":{
					"display":1
				},
				/*BoxCatalog*/"#1J2OJKSUM0":{
					"display":1
				},
				"#1J2OJRR5D0":{
					"display":1
				},
				/*BoxSort*/"#1J2OJOSLE0":{
					"display":1
				},
				/*TxtFind*/"#1J43FF2BJ0":{
					"display":0
				},
				/*BoxPageBtns*/"#1J4S3513G0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxCatalog=self.BoxCatalog;txtCatalog=self.TxtCatalog;boxSort=self.BoxSort;txtSort=self.TxtSort;txtFind=self.TxtFind;boxPageBtns=self.BoxPageBtns;btnPrevPage=self.BtnPrevPage;txtPage=self.TxtPage;btnNextPage=self.BtnNextPage;installedOnlyChecked=self.InstalledOnlyChecked;boxModels=self.BoxModels;tipLoading=self.tipLoading;
			/*#{1J2OJ9QB11Create*/
			//self.loadModels();
			/*}#1J2OJ9QB11Create*/
		},
		/*#{1J2OJ9QB11EndCSS*/
		/*}#1J2OJ9QB11EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.loadModels=async function(){
		/*#{1J2SDTLIJ0Start*/
		let res,version;
		boxModels.clearChildren();
		boxPageBtns.display=false;
		tipLoading.display=true;
		tipLoading.text=(($ln==="CN")?(`加载中...`):/*EN*/(`Loading...`));
		version=++loadVersion;
		const loadStart=Date.now();
		if(showInstalledOnly){
			const ids=await self.getInstalledModelsByPage(pageIndex);
			if(ids.length == 0){
				res={code:200, models:[]}
			}else{
				res=await tabNT.makeCall("AfGetModelInfo",{
					//catalog:catalog == "Agent" ? "All" : catalog,
					ids:ids,
					//sort:sortBy,
					//page:pageIndex,
					//platform:appCfg.platform,
					language:$ln,
					//deploy:"Agent"
				});
				
				if(res?.models && res?.models?.length>0){
					res.models=res.models.filter(v=>v.catalogs?.includes(catalog))
					const sortCode=await self.convSortCode(sortBy)
					res.models=await self.sortLocal(res.models, sortCode)
				}
			}
		}else{
			res=await tabNT.makeCall("AfGetModelList",{
				catalog:catalog == "Agent" ? "All" : catalog,
				sort:sortBy,
				page:pageIndex,
				platform:appCfg.platform,
				language:$ln,
				deploy:"Agent",
				sortCode: await self.convSortCode(sortBy)
			});
		}
		
		console.log(`LoadModels duration ${Date.now()-loadStart}ms`)
		if(!res || res.code!==200){
			//TODO: Code this:
			return;
		}
		if(version===loadVersion){
			curPageModels=res.models;
			
			self.showModels(curPageModels);
			self.checkNextPage();
		}
		/*}#1J2SDTLIJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModels=async function(models,find){
		/*#{1J2SE2MNE0Start*/
		let model;
		tipLoading.display=false;
		
		if(find){
			self.showFace("find");
			if(models?.length>0){
				txtFind.text=(($ln==="CN")?(`找到名称或简介中包含"${find}"的模型:`):/*EN*/(`Find models with "${find}" in name or brief:`));
			}else{
				txtFind.text=(($ln==="CN")?(`在名称或简介中找不到包含"${find}"的模型.`):/*EN*/(`Can't find models with "${find}" in name or brief.`));
			}
		}else{
			self.showFace("!find");
			if(pageIndex>0){
				btnPrevPage.enable=true;
			}else{
				btnPrevPage.enable=false;
			}
			txtPage.text=(($ln==="CN")?(`第 ${pageIndex+1} 页`):/*EN*/(`Page: ${pageIndex+1}`));
			btnNextPage.enable=false;
			
			if(models?.length==0){
				tipLoading.text=(($ln==="CN")?(`暂无模型`):/*EN*/(`No models available`));
				tipLoading.display=true;
			}
		}
		boxModels.clearChildren();
		for(model of models){
			boxModels.appendNewChild({
				type:BtnModelCard(model,catalog),model:model,margin:10,
				OnClick(){
					self.openModel(this.model);
				}
			});
		}
		/*}#1J2SE2MNE0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openModel=async function(model){
		/*#{1J2PU8J7N0Start*/
		app.mainUI.showModel(model, catalog);
		/*}#1J2PU8J7N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.findModels=async function(find){
		/*#{1J2PU83CQ0Start*/
		let res;
		boxModels.clearChildren();
		tipLoading.display=true;
		tipLoading.text=(($ln==="CN")?(`加载中...`):/*EN*/(`Loading...`));
		
		res=await tabNT.makeCall("AfFindModels",{
			find:find,language:$ln
		});
		if(!res || res.code!==200){
			self.showFace("!find");
			txtFind.text=(($ln==="CN")?(`在名称或简介中找不到包含"${find}"的模型.`):/*EN*/(`Can't find models with "${find}" in name or brief.`));
			return;
		}
		self.showModels(res.models,find);
		/*}#1J2PU83CQ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setCatalog=async function(){
		/*#{1J2SO4F8P0Start*/
		let items,item;
		items=[
			//{text:(($ln==="CN")?("全部模型"):/*EN*/("All models")),code:"Agent"},
			{text:(($ln==="CN")?("对话模型"):/*EN*/("Chat models")),code:"Chat"},
			{text:(($ln==="CN")?("图像模型"):/*EN*/("Image models")),code:"Image"},
			{text:(($ln==="CN")?("声音/语音模型"):/*EN*/("Audio models")),code:"Audio"},
			{text:(($ln==="CN")?("编程模型"):/*EN*/("Code models")),code:"Code"},
			{text:(($ln==="CN")?("视频模型"):/*EN*/("Video models")),code:"Video"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:boxCatalog,
			items:items
		});
		if(!item){
			return;
		}
		catalog=item.code;
		txtCatalog.text=item.text;
		pageIndex=0;
		self.loadModels();
		/*}#1J2SO4F8P0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setSort=async function(){
		/*#{1J2SO5AIC0Start*/
		let items,item;
		items=[
			{text:(($ln==="CN")?("综合评分"):/*EN*/("Overall score")),code:"Score"},
			{text:(($ln==="CN")?("能力"):/*EN*/("Capability")),code:"Capability"},
			{text:(($ln==="CN")?("可部署性"):/*EN*/("Capability")),code:"Deployability"},
			{text:(($ln==="CN")?("热度"):/*EN*/("Capability")),code:"Popularity"},
			{text:(($ln==="CN")?("新鲜度"):/*EN*/("Capability")),code:"Freshness"},
			{text:(($ln==="CN")?("速度"):/*EN*/("Capability")),code:"Speed"},
			{text:(($ln==="CN")?("成本"):/*EN*/("Capability")),code:"Cost"},
			//{text:(($ln==="CN")?("更新时间"):/*EN*/("Update time")),code:"Time"},
			//{text:(($ln==="CN")?("部署能力"):/*EN*/("Deploy")),code:"Deploy"},
			//{text:(($ln==="CN")?("模型能力"):/*EN*/("Model capability")),code:"Capability"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:boxSort,
			items:items
		});
		if(!item){
			return;
		}
		sortBy=item.code;
		txtSort.text=item.text;
		self.loadModels();
		/*}#1J2SO5AIC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showUI=async function(vo){
		/*#{1J43G9GM10Start*/
		self.loadModels();
		/*}#1J43G9GM10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkNextPage=async function(){
		/*#{1J4S476LT0Start*/
		let page,res;
		page=pageIndex;
		nextPageModels=null;
		//res=await tabNT.makeCall("AfGetModelList",{
		//	catalog:catalog,
		//	sort:sortBy,
		//	page:page+1,
		//	platform:appCfg.platform,
		//	language:$ln
		//});
		if(showInstalledOnly){
			const ids=await self.getInstalledModelsByPage(page+1);
			if(ids.length == 0){
				res={code:200, models:[]}
			}else{
				res=await tabNT.makeCall("AfGetModelInfo",{
					//catalog:catalog == "Agent" ? "All" : catalog,
					ids:ids,
					//sort:sortBy,
					//page:page+1,
					//platform:appCfg.platform,
					language:$ln,
					//deploy:"Agent"
				});
				
				if(res?.models && res?.models?.length>0){
					res.models=res.models.filter(v=>v.catalogs?.includes(catalog))
					const sortCode=await self.convSortCode(sortBy)
					res.models= await self.sortLocal(res.models, sortCode)
				}
			}
		
		}else{
			res=await tabNT.makeCall("AfGetModelList",{
				catalog:catalog == "Agent" ? "All" : catalog,
				sort:sortBy,
				page:page+1,
				platform:appCfg.platform,
				language:$ln,
				deploy:"Agent",
				sortCode: await self.convSortCode(sortBy)
			});
		}
		if(!res || res.code!==200){
			//TODO: Code this:
			return;
		}
		if(res.models && res.models.length>0 && page===pageIndex){
			btnNextPage.enable=true;
			nextPageModels=res.models;
		}
		/*}#1J4S476LT0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.nextPage=async function(){
		/*#{1J4S4JJOM0Start*/
		if(nextPageModels){
			pageIndex=pageIndex+1;
			self.showModels(nextPageModels);
			prevPageModels=curPageModels;
			curPageModels=nextPageModels;
			nextPageModels=null;
			self.checkNextPage();
		}
		/*}#1J4S4JJOM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.prePage=async function(){
		/*#{1J4S4JU6A0Start*/
		if(prevPageModels){
			pageIndex=pageIndex-1;
			self.showModels(prevPageModels);
			nextPageModels=curPageModels;
			curPageModels=prevPageModels;
			prevPageModels=null;
			btnNextPage.enable=true;
		}else if(pageIndex>0){
			pageIndex=pageIndex-1;
			await self.loadModels();
		}
		/*}#1J4S4JU6A0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getInstalledModelsByPage=async function(page){
		/*#{1JHDJNOAF0Start*/
		const pageSize = 25
		const start = (page || 0) * pageSize
		const end = start + pageSize
		
		try{
			let modelJSON=await tabFS.readFile(pathLib.join("/doc/ModelHunt/","model.json"),"utf8");
			modelJSON=JSON.parse(modelJSON);
			const deployed_models = modelJSON.deployable || [];
			const ids = deployed_models.slice(start, end);
			return ids;
		}catch(e){
			console.log("getInstalledModelsByPage error ",e)
			
			return [];
		}
		
		/*}#1JHDJNOAF0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.convSortCode=async function(sort){
		/*#{1JM2AKBI50Start*/
		switch(sort){
		case "Score":
			return `categoryScores.${catalog}.aaPick`
		case "Capability":
			return `categoryScores.${catalog}.scoreCapability`
		case "Deployability":
			return `categoryScores.${catalog}.deployability`
		case "Popularity":
			return `categoryScores.${catalog}.scorePopularity`
		case "Freshness":
			return `categoryScores.${catalog}.freshness`
		case "Speed":
			return `categoryScores.${catalog}.scoreSpeed`
		case "Cost":
			return `categoryScores.${catalog}.scoreCost`
		default:
			return ""
		}
		/*}#1JM2AKBI50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.sortLocal=async function(list,sortCode){
		/*#{1JM2CDR9C0Start*/
		if (!Array.isArray(list) || list.length === 0) return list;
		if (typeof sortCode !== 'string' || sortCode.trim() === '') return list;

		// 解析排序规则
		const sortRules = sortCode.split(',').map(rule => {
			const [field, order = 'desc'] = rule.trim().split(':');
			return {
				field: field.trim(),
				order: order.trim().toLowerCase() === 'asc' ? 1 : -1
			};
		}).filter(rule => rule.field);

		if (sortRules.length === 0) return list;

		// 通过路径字符串获取对象的值（支持点号路径）
		function getValueByPath(obj, path) {
			if (!obj || typeof obj !== 'object') return undefined;

			const keys = path.split('.');
			let value = obj;

			for (const key of keys) {
				if (value === null || value === undefined) return undefined;
				value = value[key];
			}

			return value;
		}

		// 比较两个值（处理不同类型和大小写）
		function compareValues(a, b) {
			// 处理 null/undefined
			if (a === undefined && b === undefined) return 0;
			if (a === undefined) return 1;
			if (b === undefined) return -1;
			if (a === null && b === null) return 0;
			if (a === null) return 1;
			if (b === null) return -1;

			// 数字比较
			if (typeof a === 'number' && typeof b === 'number') {
				return a - b;
			}

			// 日期比较
			if (a instanceof Date && b instanceof Date) {
				return a.getTime() - b.getTime();
			}

			// 字符串比较（不区分大小写）
			const strA = String(a).toLowerCase();
			const strB = String(b).toLowerCase();

			if (strA < strB) return -1;
			if (strA > strB) return 1;
			return 0;
		}

		// 执行排序
		list.sort((itemA, itemB) => {
			for (const rule of sortRules) {
				const valueA = getValueByPath(itemA, rule.field);
				const valueB = getValueByPath(itemB, rule.field);

				let comparison = compareValues(valueA, valueB);

				if (comparison !== 0) {
					return comparison * rule.order;
				}
			}
			return 0;
		});

		return list;
		/*}#1JM2CDR9C0Start*/
	};
	/*#{1J2OJ9QB11PostCSSVO*/
	/*}#1J2OJ9QB11PostCSSVO*/
	cssVO.constructor=UIModels;
	return cssVO;
};
/*#{1J2OJ9QB11ExCodes*/
/*}#1J2OJ9QB11ExCodes*/

//----------------------------------------------------------------------------
UIModels.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2OJ9QB11PreAISpot*/
	/*}#1J2OJ9QB11PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2OJ9QB11PostAISpot*/
	/*}#1J2OJ9QB11PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
UIModels.gearExport={
	framework: "jax",
	hudType: "view",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["find","!find"],
	subContainers:{
	},
	/*#{1J2OJ9QB10ExGearInfo*/
	/*}#1J2OJ9QB10ExGearInfo*/
};
/*#{1J2OJ9QB10EndDoc*/
/*}#1J2OJ9QB10EndDoc*/

export default UIModels;
export{UIModels};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1J2OJ9QB10",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2OJ9QB12",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2OJ9QB13",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2OJ9QB14",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2OJ9QB15",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1J2OJ9QB16",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2OJ9QB17",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2SDTLIJ0",
//					"attrs": {
//						"id": "loadModels",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2SE332P0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2SE332P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2SE332P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2SE2MNE0",
//					"attrs": {
//						"id": "showModels",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2SE332P3",
//							"attrs": {
//								"models": {
//									"type": "auto",
//									"valText": ""
//								},
//								"find": {
//									"type": "auto",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2SE332P4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2SE332P5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PU8J7N0",
//					"attrs": {
//						"id": "openModel",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PU8UOR0",
//							"attrs": {
//								"model": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PU8UOR1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PU8UOR2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PU83CQ0",
//					"attrs": {
//						"id": "findModels",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PU89LF0",
//							"attrs": {
//								"find": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PU89LF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PU89LF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2SO4F8P0",
//					"attrs": {
//						"id": "setCatalog",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2SO5JJJ0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2SO5JJJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2SO5JJJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2SO5AIC0",
//					"attrs": {
//						"id": "setSort",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2SO5JJJ3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2SO5JJJ4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2SO5JJJ5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J43G9GM10",
//					"attrs": {
//						"id": "showUI",
//						"label": "New AI Seg",
//						"x": "500",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J43G9PIA0",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J43G9PIA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J43G9PIA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J4S476LT0",
//					"attrs": {
//						"id": "checkNextPage",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J4S480O90",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J4S480O91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J4S480O92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J4S4JJOM0",
//					"attrs": {
//						"id": "nextPage",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J4S4K77M0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J4S4K77M1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J4S4K77M2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J4S4JU6A0",
//					"attrs": {
//						"id": "prePage",
//						"label": "New AI Seg",
//						"x": "500",
//						"y": "365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J4S4K77M3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J4S4K77M4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J4S4K77M5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JHDJNOAF0",
//					"attrs": {
//						"id": "getInstalledModelsByPage",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "435",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JHDJPA410",
//							"attrs": {
//								"page": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JHDJPA411",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JHDJPA412",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JM2AKBI50",
//					"attrs": {
//						"id": "convSortCode",
//						"label": "New AI Seg",
//						"x": "340",
//						"y": "455",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JM2AMA7H0",
//							"attrs": {
//								"sort": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JM2AMA7H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JM2AMA7H2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JM2CDR9C0",
//					"attrs": {
//						"id": "sortLocal",
//						"label": "New AI Seg",
//						"x": "600",
//						"y": "450",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JM2CFFIJ0",
//							"attrs": {
//								"list": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								},
//								"sortCode": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JM2CFFIJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JM2CFFIJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2OJ9QB18",
//			"attrs": {
//				"find": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J43FGDTS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J43FIULL0",
//							"attrs": {}
//						}
//					}
//				},
//				"!find": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J43FGIIK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J43FIULL1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2OJ9QB19",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1J2OJ9QB11",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2OJ9QB110",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2OJFTUD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2OJGVNG0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTop",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OJT20R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OJT20R1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "Catalog:",
//															"localize": {
//																"EN": "Catalog:",
//																"CN": "分类:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OJT20S0",
//													"attrs": {
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														},
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OJT20S1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OJT20S2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J2OJKSUM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OJOAVQ0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxCatalog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "160",
//														"h": "28",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[0,20,0,0]",
//														"padding": "[0,1,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "8",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J2OJM6FC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OJOAVR0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtCatalog",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Chat models",
//																			"localize": {
//																				"EN": "Chat models",
//																				"CN": "对话模型"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OJOAVR1",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OJOAVR2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OJOAVR3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J2OJNJDT0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OJOAVR4",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OJOAVR5",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OJOAVR6",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OJOAVR7",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J2SOCLG20",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J2SOCLG21",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J2SO4F8P0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OJOAVR8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OJOAVR9",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OJOAVR10",
//													"attrs": {
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														},
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OJOAVR11",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2SOCLG22",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2SOCLG23",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2SO4F8P0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OJOAVR12",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OJRR5D0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OJT0SA0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "Sort:",
//															"localize": {
//																"EN": "Sort:",
//																"CN": "排序:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OJT0SA1",
//													"attrs": {
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														},
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OJT0SA2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OJT0SA3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J2OJOSLE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OJOSLE1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxSort",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "160",
//														"h": "28",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,1,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "8",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J2OJOSLF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OJOSLF1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtSort",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Overall score",
//																			"localize": {
//																				"EN": "Overall score",
//																				"CN": "综合评分"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OJOSLG0",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OJOSLG1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OJOSLG2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J2OJOSLG3",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OJOSLG4",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OJOSLH0",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OJOSLH1",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM62",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM63",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OJOSLH2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J2SPCKA70",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J2SPCKA71",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J2SO5AIC0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OJOSLH3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OJOSLH4",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OJOSLH5",
//													"attrs": {
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL23",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														},
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL25",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OJOSLH6",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2SPCKA72",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2SPCKA73",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2SO5AIC0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OJOSLH7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J43FF2BJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J43FIULL26",
//													"attrs": {
//														"type": "text",
//														"id": "TxtFind",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "100%",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "Find: OpenAI:",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J43FIULL27",
//													"attrs": {
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL29",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														},
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43FIULL30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43FIULL31",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J43FIULL32",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J43FIULL33",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J4S3513G0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J4S39MMV0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxPageBtns",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "150",
//														"h": "40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,20]",
//														"padding": "[0,10,0,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center",
//														"subAlign": "Start",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J4S2RIB30",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J4S2ST980",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "40",
//																		"h": "24",
//																		"text": "<",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J4S2ST981",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",40,24,\"<\",false,\"\")",
//																		"id": "BtnPrevPage",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J4S2ST982",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J4S2ST983",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J4S4L5DE0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J4S4L5DE1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J4S4JU6A0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J4S2ST984",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J4S2ST985",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J4S2ST986",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J4S35S580",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J4S35S581",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPage",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Page: -",
//																			"localize": {
//																				"EN": "Page: -",
//																				"CN": "第 - 页"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J4S35S590",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J4S35S591",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J4S35S592",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J4S2V9HK0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J4S2V9HK1",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "40",
//																		"h": "24",
//																		"text": ">",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J4S2V9HK2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",40,24,\">\",false,\"\")",
//																		"id": "BtnNextPage",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J4S2V9HK3",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J4S2V9HK4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J4S4L5DE2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J4S4L5DE3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J4S4JJOM0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J4S2V9HK5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J4S2V9HK6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J4S2V9HK7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1JGOGVFS40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1JGOGVL5O0",
//																	"attrs": {
//																		"size": "20",
//																		"text": {
//																			"type": "string",
//																			"valText": "Show installed only",
//																			"localize": {
//																				"EN": "Show installed only",
//																				"CN": "仅看已安装"
//																			},
//																			"localizable": true
//																		},
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1JGOGVL5O1",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(20,(($ln===\"CN\")?(\"仅看已安装\"):(\"Show installed only\")),false,false)",
//																		"id": "InstalledOnlyChecked",
//																		"position": "relative",
//																		"x": "18",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1JGOGVL5O2",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM610",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM611",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1JGOGVL5O3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1JGOGVL5O4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1JGOGVL5O5",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J4S39MMV1",
//													"attrs": {
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J4S3EGMB14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J4S3EGMB15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														},
//														"1J43FGIIK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J4S3EGMB16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J4S3EGMB17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGIIK0",
//															"faceTagName": "!find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J4S39MMV2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J4S39MMV3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2OJGVNG1",
//									"attrs": {
//										"1J43FGDTS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JJDI7PM612",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JJDI7PM613",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J43FGDTS0",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2OJGVNG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OJGVNG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J4U9RB1B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J4U9T78P0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxScroll",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,80,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2OJTV600",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OJVL2S0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxModels",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,10,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Start",
//														"itemsWrap": "Wrap",
//														"subAlign": "Start",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1J2NAC36L0",
//															"jaxId": "1J2OK0L7I0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OK218T0",
//																	"attrs": {
//																		"model": "",
//																		"catalog": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OK218T1",
//																	"attrs": {
//																		"type": "#null#>BtnModelCard(undefined,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "180",
//																		"y": "100",
//																		"display": "On",
//																		"face": "",
//																		"margin": "10"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OK218T2",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM614",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM615",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OK218T3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OK218T4",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OK218T5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2NAC36L0",
//															"jaxId": "1J2OK22730",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OK22731",
//																	"attrs": {
//																		"model": "",
//																		"catalog": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OK22732",
//																	"attrs": {
//																		"type": "#null#>BtnModelCard(undefined,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "180",
//																		"y": "100",
//																		"display": "On",
//																		"face": "",
//																		"margin": "10"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OK22733",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM616",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM617",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OK22734",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OK22735",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OK22736",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2NAC36L0",
//															"jaxId": "1J2OK2A4O0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OK2A4O1",
//																	"attrs": {
//																		"model": "",
//																		"catalog": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OK2A4O2",
//																	"attrs": {
//																		"type": "#null#>BtnModelCard(undefined,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "180",
//																		"y": "100",
//																		"display": "On",
//																		"face": "",
//																		"margin": "10"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OK2A4P0",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM618",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM619",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OK2A4P1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OK2A4P2",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OK2A4P3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2NAC36L0",
//															"jaxId": "1J2OK4QG50",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OK4QG51",
//																	"attrs": {
//																		"model": "",
//																		"catalog": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OK4QG52",
//																	"attrs": {
//																		"type": "#null#>BtnModelCard(undefined,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "180",
//																		"y": "100",
//																		"display": "On",
//																		"face": "",
//																		"margin": "10"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OK4QG53",
//																	"attrs": {
//																		"1J43FGDTS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JJDI7PM620",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JJDI7PM621",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J43FGDTS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OK4QG54",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OK4QG55",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2OK4QG56",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OJVL2S1",
//													"attrs": {
//														"1J43FGDTS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JJDI7PM622",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JJDI7PM623",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J43FGDTS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OJVL2T0",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OJVL2T1",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J4U9T78P1",
//									"attrs": {
//										"1J43FGDTS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JJDI7PM624",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JJDI7PM625",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J43FGDTS0",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J4U9T78P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J4U9T78P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1JJDI4QJ70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JJDI7PM626",
//									"attrs": {
//										"type": "text",
//										"id": "tipLoading",
//										"position": "relative",
//										"x": "0",
//										"y": "-50%",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": {
//											"type": "string",
//											"valText": "Loading...",
//											"localize": {
//												"EN": "Loading...",
//												"CN": "加载中..."
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "16",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JJDI7PM627",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1JJDI7PM628",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JJDI7PM629",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2OJ9QB111",
//					"attrs": {
//						"1J43FGDTS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JJDI7PM630",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JJDI7PM631",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J43FGDTS0",
//							"faceTagName": "find"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2OJ9QB112",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2OJ9QB113",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2OJ9QB114",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}