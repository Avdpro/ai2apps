//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {UIModels} from "./UIModels.js";
import {UIModelDetails} from "./UIModelDetails.js";
import {UIAdmin} from "./UIAdmin.js";
/*#{1GGJKM84D0StartDoc*/
import pathLib from "/@path";
import {tabNT} from "/@tabos";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edFind,btnAdmin,dkViews,uiModels,uiDetails,uiAdmin;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let helpText=(($ln==="CN")?("这是如何使用“智能体聊天界面视图”的演示。"):("This is a demo of how to use the 'Agent Chat View'."));
	
	/*#{1GGJKM84D1LocalVals*/
	const app=VFACT.app;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	let viewVo=null;
	let viewCallback=null;
	let viewCallerror=null;
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":"50%","y":0,"w":"100%","h":"100%","anchorX":1,"padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"itemsAlign":1,
		children:[
			{
				"hash":"1J2PS7B9F0",
				"type":"box","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":40,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":1,"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1J2PT736B0",
						"type":"box","position":"relative","x":0,"y":0,"w":36,"h":36,"cursor":"pointer","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["fontBodySub"],"maskImage":"assets/aifrontier.svg",
						"OnClick":function(event){
							self.showModels(this,event);
						},
					},
					{
						"hash":"1J2PTA2RK0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","cursor":"pointer","margin":[0,20,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":(($ln==="CN")?("模型精选"):("Models")),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
						"OnClick":function(event){
							self.showModels(this,event);
						},
					},
					{
						"hash":"1J2PTEKRK0",
						"type":"box","position":"relative","x":0,"y":0,"w":200,"h":28,"padding":[0,10,0,5],"minW":"","minH":"","maxW":300,"maxH":"","styleClass":"","background":cfgColor["tool"],
						"borderColor":cfgColor["tool"],"corner":16,"contentLayout":"flex-x","itemsAlign":1,"flex":true,
						children:[
							{
								"hash":"1J2PTJ7MH0",
								"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
								"maskImage":appCfg.sharedAssets+"/find.svg",
							},
							{
								"hash":"1J2PTO3SN0",
								"type":"edit","id":"EdFind","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("搜索模型项目"):("Search models")),
								"color":[0,0,0],"background":[255,255,255,0],"outline":0,"flex":true,
								"OnKeyDown":function(event){
									self.edFindOnKeyDown(this,event);
								},
							}
						],
					},
					{
						"hash":"1J2PTCTO30",
						"type":"hud","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
					},
					{
						"hash":"1J2PSJVVR0",
						"type":BtnText("warning",100,24,"Admin",false,""),"id":"BtnAdmin","position":"relative","x":0,"y":0,"display":0,
						"OnClick":function(event){
							self.showAdmin(this,event);
						},
					}
				],
			},
			{
				"hash":"1J2PS93H00",
				"type":"dock","id":"DkViews","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 40px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"coverAction":1,"ui":0,
				children:[
					{
						"hash":"1J2PSCG0N0",
						"type":UIModels(),"id":"UiModels","x":0,"y":0,
					},
					{
						"hash":"1J2PSHOBI0",
						"type":UIModelDetails(),"id":"UiDetails","x":"50%","y":0,"display":0,
					},
					{
						"hash":"1J2PSIV9P0",
						"type":UIAdmin(),"id":"UiAdmin","x":0,"y":0,"display":0,
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			edFind=self.EdFind;btnAdmin=self.BtnAdmin;dkViews=self.DkViews;uiModels=self.UiModels;uiDetails=self.UiDetails;uiAdmin=self.UiAdmin;
			/*#{1GGJKM84D1Create*/
			app.mainUI=self;
			if(session && session.addChatText){
				//Now, set init chat text, won't trigger "red-dot" on show-chat-button.
				session.addChatText("assistant",(($ln==="CN")?("欢迎使用计算器智能体！"):/*EN*/("Welcome to the Calculator AI Agent!")),{});
			}
			self.checkAdmin();
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	//------------------------------------------------------------------------
	/**
	 * This function will be called when showing the Chat-View. Agent can send args to manpualte view contents.
	 * This function should wait until generated an action that will sent to the AI-Agent to handle.
	 * 
	 * @param {*} args - 
	 * @returns {void} 
	 */
	cssVO.showChatView=async function(args){
		/*#{1J0UJAAHG0Start*/
		viewVo=args||{};
		if(viewVo.action==="Text"){//Demo how changes view content by agent
			txtText.text=viewVo.text;
		}
		let pms;
		pms=new Promise((resolve,reject)=>{
			viewCallback=resolve;
			viewCallerror=reject;
		});
		//Wait until user input or UI-Action that will trigger AI-Chat
		return await pms;
		/*}#1J0UJAAHG0Start*/
	};
	//------------------------------------------------------------------------
	/**
	 * This is the function will be called when user input text in chat, so chat-view will finish it's wait promise.
	 * @returns {void} 
	 */
	cssVO.cancelChatView=async function(){
		/*#{1J0UK2NJN0Start*/
		let callback=viewCallback;
		if(callback){
			viewCallback=null;
			viewCallerror=null;
			callback();
		}
		/*}#1J0UK2NJN0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showHelp=async function(){
		/*#{1J0UK3E010Start*/
		let callback=viewCallback;
		if(callback){
			viewCallback=null;
			callback({command:"Help",text:helpText});
		}
		/*}#1J0UK3E010Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModels=async function(){
		/*#{1J2PUC2T50Start*/
		dkViews.showUI(uiModels,{});
		/*}#1J2PUC2T50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModel=async function(model){
		/*#{1J2PUCHN20Start*/
		dkViews.showUI(uiDetails,model);
		/*}#1J2PUCHN20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAdmin=async function(){
		/*#{1J2PUDIMM0Start*/
		dkViews.showUI(uiAdmin);
		/*}#1J2PUDIMM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkAdmin=async function(){
		/*#{1J2V4C30S0Start*/
		let res;
		await tabNT.checkLogin();
		res=await tabNT.makeCall("AfPublishModel",{});
		if(res && res.code===400){
			btnAdmin.display=true;
		}else{
			btnAdmin.display=false;
		}
		/*}#1J2V4C30S0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.edFindOnKeyDown=async function(sender,event){
		/*#{1J43FMATA0Start*/
		if(event.code==="Enter"){
			if((!event.isComposing) &&(!event.shiftKey)){
				event.stopPropagation();
				event.preventDefault();
				uiModels.findModels(sender.text);
			}
		}
		/*}#1J43FMATA0Start*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	/*}#1GGJKM84D1PostCSSVO*/
	cssVO.constructor=MainUI;
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

//----------------------------------------------------------------------------
MainUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GGJKM84D1PreAISpot*/
	/*}#1GGJKM84D1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GGJKM84D1PostAISpot*/
	/*}#1GGJKM84D1PostAISpot*/
	return exposeVO;
};

/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H90TKKV70",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"helpText": {
//					"type": "string",
//					"valText": "This is a demo of how to use the 'Agent Chat View'.",
//					"localize": {
//						"EN": "This is a demo of how to use the 'Agent Chat View'.",
//						"CN": "这是如何使用“智能体聊天界面视图”的演示。"
//					},
//					"localizable": true
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J0UJAAHG0",
//					"attrs": {
//						"id": "showChatView",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "160",
//						"desc": "This function will be called when showing the Chat-View. Agent can send args to manpualte view contents.\nThis function should wait until generated an action that will sent to the AI-Agent to handle.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J0UJAQN80",
//							"attrs": {
//								"args": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J0UJAQN81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J0UJAQN82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J0UK2NJN0",
//					"attrs": {
//						"id": "cancelChatView",
//						"label": "New AI Seg",
//						"x": "370",
//						"y": "160",
//						"desc": "This is the function will be called when user input text in chat, so chat-view will finish it's wait promise.",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J0UK34HI0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J0UK34HI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J0UK34HI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J0UK3E010",
//					"attrs": {
//						"id": "showHelp",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "255",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J0UK4AEO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J0UK4AEO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J0UK4AEO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PUC2T50",
//					"attrs": {
//						"id": "showModels",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PUDPT90",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PUDPT91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PUDPT92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PUCHN20",
//					"attrs": {
//						"id": "showModel",
//						"label": "New AI Seg",
//						"x": "370",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PUDPT93",
//							"attrs": {
//								"model": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PUDPT94",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PUDPT95",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PUDIMM0",
//					"attrs": {
//						"id": "showAdmin",
//						"label": "New AI Seg",
//						"x": "625",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PUDPT96",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PUDPT97",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PUDPT98",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2V4C30S0",
//					"attrs": {
//						"id": "checkAdmin",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "360",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2V4CJGK0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2V4CJGK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2V4CJGK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J43FMATA0",
//					"attrs": {
//						"id": "edFindOnKeyDown",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "460",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J43FNQJR0",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J43FNQJR1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J43FNQJR2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HDBOJDB10",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "0",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1J2PS7B9F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2PS88U60",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J2PT736B0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2PT98B00",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "36",
//														"h": "36",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "assets/aifrontier.svg"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PT98B01",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PT98B02",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2TUOIVM0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2TUOIVM1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2PUC2T50"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PT98B03",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2PTA2RK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2PTC5F10",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[0,20,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "Models",
//															"localize": {
//																"EN": "Models",
//																"CN": "模型精选"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PTC5F11",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PTC5F12",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2TUOIVM2",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2TUOIVN0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2PUC2T50"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PTC5F13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J2PTEKRK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2PTH1P20",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "200",
//														"h": "28",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "300",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"tool\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"tool\"]",
//														"corner": "16",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J2PTJ7MH0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2PTPROE0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/find.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2PTPROE1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1J2PTPROE2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2PTPROE3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1J2PTO3SN0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2PTPROE4",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdFind",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": "",
//																		"placeHolder": {
//																			"type": "string",
//																			"valText": "Search models",
//																			"localize": {
//																				"EN": "Search models",
//																				"CN": "搜索模型项目"
//																			},
//																			"localizable": true
//																		},
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,0.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2PTPROE5",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1J2PTPROE6",
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J43FNQJR3",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J43FNQJR4",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J43FMATA0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2PTPROE7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2PTH1P21",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PTH1P22",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PTH1P23",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2PTCTO30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2PTH1P24",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PTH1P25",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PTH1P26",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PTH1P27",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1J2PSJVVR0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2PSKS830",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": "Admin",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1J2PSKS831",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,\"Admin\",false,\"\")",
//														"id": "BtnAdmin",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PSKS832",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PSKS833",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2PUITUN0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2PUITUN1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2PUDIMM0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PSKS834",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2PSKS835",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1J2PSKS836",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2PS88U61",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1J2PS88U62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2PS88U63",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "dock",
//							"jaxId": "1J2PS93H00",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2PS9TQC0",
//									"attrs": {
//										"type": "dock",
//										"id": "DkViews",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%-40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"coverAction": "Dispose",
//										"ui": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1J2OJ9QB10",
//											"jaxId": "1J2PSCG0N0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2PSCO200",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1J2PSCO201",
//													"attrs": {
//														"type": "#null#>UIModels()",
//														"id": "UiModels",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PSCO202",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PSCO203",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PSCO204",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2PSCO205",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1J2OD445V0",
//											"jaxId": "1J2PSHOBI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2PSIGEJ0",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1J2PSIGEJ1",
//													"attrs": {
//														"type": "#null#>UIModelDetails()",
//														"id": "UiDetails",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PSIGEJ2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PSIGEJ3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PSIGEJ4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2PSIGEJ5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1J2OUG1LD0",
//											"jaxId": "1J2PSIV9P0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2PSJ7MR0",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1J2PSJ7MR1",
//													"attrs": {
//														"type": "#null#>UIAdmin()",
//														"id": "UiAdmin",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2PSJ7MR2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2PSJ7MR3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2PSJ7MR4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2PSJ7MR5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2PS9TQC1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1J2PS9TQC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2PS9TQC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}