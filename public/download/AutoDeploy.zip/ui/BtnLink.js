//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1J2U2D1IQ0StartDoc*/
/*}#1J2U2D1IQ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnLink=function(title){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1J2U2D1IQ1LocalVals*/
	let link=null;
	/*}#1J2U2D1IQ1LocalVals*/
	
	/*#{1J2U2D1IQ1PreState*/
	/*}#1J2U2D1IQ1PreState*/
	/*#{1J2U2D1IQ1PostState*/
	/*}#1J2U2D1IQ1PostState*/
	cssVO={
		"hash":"1J2U2D1IQ1",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":"","cursor":"pointer","margin":[3,0,3,0],"padding":[0,10,0,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1J2U2DP970",
				"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"uiEvent":-1,"styleClass":"","background":cfgColor["secondary"],"maskImage":appCfg.sharedAssets+"/link.svg",
			},
			{
				"hash":"1J2U2GMO10",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"margin":[0,0,0,5],"styleClass":"","color":cfgColor["fontBody"],"text":title,
				"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			}
		],
		/*#{1J2U2D1IQ1ExtraCSS*/
		/*}#1J2U2D1IQ1ExtraCSS*/
		faces:{
			"up":{
				"#1J2U2DP970":{
					"background":cfgColor["secondary"]
				},
				"#1J2U2GMO10":{
					"textDecoration":""
				}
			},"over":{
				"#1J2U2DP970":{
					"background":cfgColor["fontBody"]
				},
				"#1J2U2GMO10":{
					"textDecoration":"underline"
				}
			},"down":{
				"#1J2U2DP970":{
					"background":cfgColor["fontBody"]
				},
				"#1J2U2GMO10":{
					"textDecoration":"underline"
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1J2U2D1IQ1Create*/
			/*}#1J2U2D1IQ1Create*/
		},
		/*#{1J2U2D1IQ1EndCSS*/
		/*}#1J2U2D1IQ1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.setLink=async function(url){
		/*#{1J2U2O2NG0Start*/
		link=url;
		this.display=!!link;
		/*}#1J2U2O2NG0Start*/
	};
	/*#{1J2U2D1IQ1PostCSSVO*/
	cssVO.OnClick=function(){
		if(window.taApi){
			window.taApi.shellExec(link);
		}else{
			window.open(link, "_blank");
		}
	}
	/*}#1J2U2D1IQ1PostCSSVO*/
	cssVO.constructor=BtnLink;
	return cssVO;
};
/*#{1J2U2D1IQ1ExCodes*/
/*}#1J2U2D1IQ1ExCodes*/

//----------------------------------------------------------------------------
BtnLink.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2U2D1IQ1PreAISpot*/
	/*}#1J2U2D1IQ1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2U2D1IQ1PostAISpot*/
	/*}#1J2U2D1IQ1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnLink.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "GitHub"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down"],
	subContainers:{
	},
	/*#{1J2U2D1IQ0ExGearInfo*/
	/*}#1J2U2D1IQ0ExGearInfo*/
};
/*#{1J2U2D1IQ0EndDoc*/
/*}#1J2U2D1IQ0EndDoc*/

export default BtnLink;
export{BtnLink};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1J2U2D1IQ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2U2D1IQ2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2U2D1IQ3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2U2D1IQ4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2U2D1IQ5",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "GitHub"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1J2U2D1IQ6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2U2D1IQ7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2U2O2NG0",
//					"attrs": {
//						"id": "setLink",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "60",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2U2OBE10",
//							"attrs": {
//								"url": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2U2OBE11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2U2OBE12",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2U2D1IQ8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U2ICE70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U2IOTS0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U2IGB00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U2IOTS1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U2IJBQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U2IOTS2",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2U2D1IQ9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1J2U2D1IQ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2U2D1IQ10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[3,0,3,0]",
//						"padding": "[0,10,0,10]",
//						"minW": "",
//						"minH": "20",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"flex": "false",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1J2U2DP970",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U2HTN30",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "20",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/link.svg\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2U2HTN31",
//									"attrs": {
//										"1J2U2IGB00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2IOTS7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2IOTT0",
//													"attrs": {
//														"background": "#cfgColor[\"fontBody\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2IGB00",
//											"faceTagName": "over"
//										},
//										"1J2U2IJBQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2MMNH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2MMNH1",
//													"attrs": {
//														"background": "#cfgColor[\"fontBody\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2IJBQ0",
//											"faceTagName": "down"
//										},
//										"1J2U2ICE70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2MMNH2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2MMNH3",
//													"attrs": {
//														"background": "#cfgColor[\"secondary\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2ICE70",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2U2HTN32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2U2HTN33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1J2U2GMO10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U2HTN34",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#title",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2U2HTN35",
//									"attrs": {
//										"1J2U2IJBQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2IOTT1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2IOTT2",
//													"attrs": {
//														"underline": "true"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2IJBQ0",
//											"faceTagName": "down"
//										},
//										"1J2U2IGB00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2IOTT5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2IOTT6",
//													"attrs": {
//														"underline": "true"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2IGB00",
//											"faceTagName": "over"
//										},
//										"1J2U2ICE70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U2JNGQ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2JNGQ3",
//													"attrs": {
//														"underline": "false"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U2ICE70",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2U2HTN36",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2U2HTN37",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2U2D1IQ11",
//					"attrs": {
//						"1J2U2IGB00": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2U2IOTT11",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U2IOTT12",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2U2IGB00",
//							"faceTagName": "over"
//						},
//						"1J2U2IJBQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2U2MMNH4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U2MMNH5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2U2IJBQ0",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2U2D1IQ12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2U2D1IQ13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2U2D1IQ14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}