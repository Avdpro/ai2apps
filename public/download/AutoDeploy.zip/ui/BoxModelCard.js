//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1J2OAIJ350StartDoc*/
import drawScore from "../DrawScore.js";
import {tabNT} from "/@tabos";
/*}#1J2OAIJ350StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxModelCard=function(model,opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxScore,txtScore,boxConent,txtDownloads,txtTime,boxTags;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let modelId=model?.id||model;
	
	/*#{1J2OAIJ351LocalVals*/
	const app=VFACT.app;
	/*}#1J2OAIJ351LocalVals*/
	
	/*#{1J2OAIJ351PreState*/
	/*}#1J2OAIJ351PreState*/
	state={
		"name":"ChatGPT 5","brief":"Phi 4 reasoning model is trained via supervised fine-tuning of Phi 4 on carefully curated reasoning demonstrations from OpenAI’s o3-mini. This model demonstrates meticulous data curation and high quality synthetic datasets allow smaller models to compete with larger counterparts.",
		"downloads":"1202","time":"2025-08-15","deploy":"Deploy","score":"- . -",
		/*#{1J2OAIJ357ExState*/
		/*}#1J2OAIJ357ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1J2OAIJ351PostState*/
	function formatDate(ts = Date.now()) {
		const d = new Date(ts);
		const y = d.getFullYear();
		const m = String(d.getMonth() + 1).padStart(2, "0"); // 月份从0开始
		const day = String(d.getDate()).padStart(2, "0");
		return `${y}-${m}-${day}`;
	}	
	/*}#1J2OAIJ351PostState*/
	cssVO={
		"hash":"1J2OAIJ351",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":opts.autoHeight?"":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1J2OAMUF50",
				"type":"hud","id":"BoxTop","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x",
				children:[
					{
						"hash":"1J2OAMUF52",
						"type":"hud","id":"BoxLeft","position":"relative","x":0,"y":0,"w":80,"h":"100%","minW":"","minH":85,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"itemsAlign":1,"subAlign":1,"attached":opts.scores,
						children:[
							{
								"hash":"1J2OAMUF60",
								"type":"hud","id":"BoxScore","position":"relative","x":0,"y":0,"w":80,"h":70,"padding":[10,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1J2RG09CU0",
								"type":"box","id":"BoxScoreLoading...","position":"relative","x":0,"y":0,"w":80,"h":80,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontBodyLit"],"maskImage":"assets/aifrontier.svg",
							},
							{
								"hash":"1J2SM89KL0",
								"type":"text","id":"TxtScore","position":"relative","x":0,"y":0,"w":"80%","h":"","margin":[-5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBody"],"text":$P(()=>(state.score),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
								"alignH":2,
							}
						],
					},
					{
						"hash":"1J2OAMUF616",
						"type":"hud","id":"BoxConent","position":"relative","x":0,"y":0,"w":">calc(100% - 80px)","h":"","padding":[15,0,0,5],"minW":"","minH":50,"maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1J2OAMUF71",
								"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":$P(()=>(state.name),state),"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1J2OAMUF89",
								"type":"hud","id":"BoxStates","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,
								children:[
									{
										"hash":"1J2OAMUF811",
										"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
										"borderColor":cfgColor["secondary"],"maskImage":appCfg.sharedAssets+"/download.svg",
									},
									{
										"hash":"1J2OAMUF97",
										"type":"text","id":"TxtDownloads","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,8,0,0],"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","color":cfgColor["secondary"],"text":$P(()=>(state.downloads),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
										"textDecoration":"",
									},
									{
										"hash":"1J2OAMUFA16",
										"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
										"borderColor":cfgColor["secondary"],"maskImage":appCfg.sharedAssets+"/datetime.svg",
									},
									{
										"hash":"1J2OAMUFB7",
										"type":"text","id":"TxtTime","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,8,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["secondary"],"text":$P(()=>(state.time),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2OAMUFB16",
										"type":"box","id":"BoxDeployMark","position":"relative","x":0,"y":0,"w":20,"h":20,"display":$P(()=>(state.deploy!=="NA"),state),"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],"borderColor":cfgColor["secondary"],"maskImage":appCfg.sharedAssets+"/check_fat.svg",
									},
									{
										"hash":"1J2OAMUFC7",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","display":$P(()=>(state.deploy!=="NA"),state),"margin":[0,8,0,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","color":cfgColor["secondary"],"text":$P(()=>(state.deploy),state),"fontSize":txtSize.small,"fontWeight":"normal",
										"fontStyle":"normal","textDecoration":"",
									}
								],
							},
							{
								"hash":"1J2RF4EAF0",
								"type":"hud","id":"BoxStateLoading","position":"relative","x":0,"y":0,"w":"100%","h":20,"display":0,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1J2RF78D50",
										"type":"box","position":"relative","x":0,"y":0,"w":14,"h":14,"margin":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									},
									{
										"hash":"1J2RFA94B0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,15,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
										"text":"- - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2RFB9Q90",
										"type":"box","position":"relative","x":0,"y":0,"w":14,"h":14,"margin":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									},
									{
										"hash":"1J2RFBC9L0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,15,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
										"text":"- - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2RFBED60",
										"type":"box","position":"relative","x":0,"y":0,"w":14,"h":14,"margin":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									},
									{
										"hash":"1J2RFBI4F0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,15,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
										"text":"- - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									}
								],
							},
							{
								"hash":"1J2OAMUFF0",
								"type":"hud","id":"BoxTags","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x","itemsWrap":1,
								children:[
									{
										"hash":"1J2OAMUFF2",
										"type":"box","position":"relative","x":0,"y":0,"w":"","h":20,"margin":[0,5,5,0],"padding":[0,12,0,10],"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","background":cfgColor["fontBodyLit"],"corner":6,
										children:[
											{
												"hash":"1J2OAMUFF4",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
												"text":"TTS","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
											}
										],
									}
								],
							},
							{
								"hash":"1J2RFCLCB0",
								"type":"hud","id":"BoxTagLoading","position":"relative","x":0,"y":0,"w":"100%","h":20,"display":0,"alpha":0.5,"margin":[5,0,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1J2RFCLCC0",
										"type":"box","position":"relative","x":0,"y":0,"w":50,"h":20,"margin":4,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
										"corner":6,
									},
									{
										"hash":"1J2RFFEDM0",
										"type":"box","position":"relative","x":0,"y":0,"w":50,"h":20,"margin":4,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
										"corner":6,
									},
									{
										"hash":"1J2RFFFPI0",
										"type":"box","position":"relative","x":0,"y":0,"w":50,"h":20,"margin":4,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
										"corner":6,
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1J2OBHCKN0",
				"type":"hud","id":"BoxInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":1,"padding":[5,10,5,10],"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","flex":true,"contentLayout":"flex-y",
				children:[
					{
						"hash":"1J2OBHCKO0",
						"type":"text","id":"TxtBrief","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.brief),state),"fontSize":txtSize.small+1,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"lineClamp":opts.autoHeight?100:5,
					},
					{
						"hash":"1J2RFL8C60",
						"type":"hud","id":"BoxBriefLoading","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"alpha":0.5,"padding":10,"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","itemsAlign":1,
						children:[
							{
								"hash":"1J2RFMQ1O0",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
							},
							{
								"hash":"1J2RFNPSL0",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
							},
							{
								"hash":"1J2RFNR830",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
							}
						],
					}
				],
			}
		],
		/*#{1J2OAIJ351ExtraCSS*/
		/*}#1J2OAIJ351ExtraCSS*/
		faces:{
			"loading":{
				/*BoxScore*/"#1J2OAMUF60":{
					"display":0
				},
				/*BoxScoreLoading...*/"#1J2RG09CU0":{
					"display":1
				},
				/*BoxStates*/"#1J2OAMUF89":{
					"display":0
				},
				/*BoxStateLoading*/"#1J2RF4EAF0":{
					"display":1
				},
				/*BoxTags*/"#1J2OAMUFF0":{
					"display":0
				},
				/*BoxTagLoading*/"#1J2RFCLCB0":{
					"display":1
				},
				/*TxtBrief*/"#1J2OBHCKO0":{
					"display":0
				},
				/*BoxBriefLoading*/"#1J2RFL8C60":{
					"display":1
				}
			},"ready":{
				/*BoxScore*/"#1J2OAMUF60":{
					"display":1
				},
				/*BoxScoreLoading...*/"#1J2RG09CU0":{
					"display":0
				},
				/*BoxStates*/"#1J2OAMUF89":{
					"display":1
				},
				/*BoxStateLoading*/"#1J2RF4EAF0":{
					"display":0
				},
				/*BoxTags*/"#1J2OAMUFF0":{
					"display":1
				},
				/*BoxTagLoading*/"#1J2RFCLCB0":{
					"display":0
				},
				/*TxtBrief*/"#1J2OBHCKO0":{
					"display":1
				},
				/*BoxBriefLoading*/"#1J2RFL8C60":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxScore=self.BoxScore;txtScore=self.TxtScore;boxConent=self.BoxConent;txtDownloads=self.TxtDownloads;txtTime=self.TxtTime;boxTags=self.BoxTags;
			/*#{1J2OAIJ351Create*/
			if(model && model.id){
				self.showModel();
			}else if(model){
				self.loadModel();
			}
			/*}#1J2OAIJ351Create*/
		},
		/*#{1J2OAIJ351EndCSS*/
		/*}#1J2OAIJ351EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.loadModel=async function(){
		/*#{1J2REVBSC0Start*/
		let res;
		self.showFace("loading");
		res=await tabNT.makeCall("AfGetModelInfo",{model:modelId});
		if(!res || res.code!==200){
			//TODO: show error:
			state.name="Read model error.";
			return;	
		}
		model=res.model;
		self.showModel();
		/*}#1J2REVBSC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModel=async function(md){
		/*#{1J2REVKMH0Start*/
		let platform=appCfg.platform;
		let tags,tag,tagColor;
		const dpTexts={
			"Deploy":(($ln==="CN")?("可部署"):/*EN*/("deployable")),
			"Agent":(($ln==="CN")?("有智能体"):/*EN*/("agentic")),
		};
		self.showFace("ready");
		if(md){
			model=md;
			modelId=md.id;
		}
		state.name=model.name;
		state.brief=model.brief;
		state.downloads=model.downloads;
		state.time=formatDate(model.updateTime);
		state.deploy=dpTexts[model.deploy?(model.deploy[platform]||"NA"):"NA"]||"NA";
		state.score=""+model.scoreOverall;
		if(state.score.length===1){
			state.score+=".0";
		}
		tagColor=[...cfgColor["fontBodyLit"]];tagColor[3]=0.5
		tags=model.capabilities||[];
		tags=[...tags];
		if(model.size>0){
			tags.unshift(`${model.size}B`);
		}
		boxTags.clearChildren();
		for(tag of tags){
			boxTags.appendNewChild({
				"type":"box","position":"relative","x":0,"y":0,"w":"","h":20,"margin":[0,5,0,0],"padding":[0,12,0,10],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":tagColor,"corner":6,margin:[0,5,5,0],
				children:[
					{
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":tag,"fontSize":txtSize.small,"alignV":1,
					}
				],
			});
		}
		if(boxScore){
			boxScore.webObj.innerHTML="";//Clear
			if(model.openSource){
				boxScore.webObj.appendChild(drawScore([model.scoreCapability,model.scoreDeployment,model.scorePopularity,model.scoreObjective,model.scoreTiming,model.scoreSize],10,{size:60}));
			}else{
				boxScore.webObj.appendChild(drawScore([model.scoreCapability,model.scorePopularity,model.scoreObjective,model.scoreTiming,],10,{size:60}));
			}
		}
		/*}#1J2REVKMH0Start*/
	};
	/*#{1J2OAIJ351PostCSSVO*/
	/*}#1J2OAIJ351PostCSSVO*/
	cssVO.constructor=BoxModelCard;
	return cssVO;
};
/*#{1J2OAIJ351ExCodes*/
/*}#1J2OAIJ351ExCodes*/

//----------------------------------------------------------------------------
BoxModelCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2OAIJ351PreAISpot*/
	/*}#1J2OAIJ351PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2OAIJ351PostAISpot*/
	/*}#1J2OAIJ351PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxModelCard.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"model": {"name":"model","showName":"model","type":"auto","key":true,"fixed":true}, 
		"opts": {
			"type": "object", "name": "opts", "showName": "opts", "icon": undefined, 
			"def": {
				"attrs": {
					"scores": {
						"name": "scores", "showName": "scores", "type": "bool", "key": true, "fixed": true, "initVal": true
					}, 
					"autoHeight": {
						"name": "autoHeight", "showName": "autoHeight", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"fontSize": {
						"name": "fontSize", "showName": "fontSize", "type": "number", "key": true, "fixed": true, "initVal": 14, "initValText": "#appCfg.txtSize.smallPlus"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","display","uiEvent"],
	faces:["loading","ready"],
	subContainers:{
	},
	/*#{1J2OAIJ350ExGearInfo*/
	/*}#1J2OAIJ350ExGearInfo*/
};
/*#{1J2OAIJ350EndDoc*/
/*}#1J2OAIJ350EndDoc*/

export default BoxModelCard;
export{BoxModelCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1J2OAIJ350",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2OAIJ352",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "200",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2OAIJ353",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2OAIJ354",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2OAIJ355",
//			"attrs": {
//				"model": {
//					"type": "auto",
//					"valText": ""
//				},
//				"opts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1J2OCD7PH0",
//					"attrs": {
//						"scores": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"autoHeight": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"fontSize": {
//							"type": "number",
//							"valText": "#appCfg.txtSize.smallPlus"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1J2OAIJ356",
//			"attrs": {
//				"modelId": {
//					"type": "auto",
//					"valText": "#model?.id||model"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2OAIJ357",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "ChatGPT 5"
//				},
//				"brief": {
//					"type": "string",
//					"valText": "Phi 4 reasoning model is trained via supervised fine-tuning of Phi 4 on carefully curated reasoning demonstrations from OpenAI’s o3-mini. This model demonstrates meticulous data curation and high quality synthetic datasets allow smaller models to compete with larger counterparts."
//				},
//				"downloads": {
//					"type": "string",
//					"valText": "1202"
//				},
//				"time": {
//					"type": "string",
//					"valText": "2025-08-15"
//				},
//				"deploy": {
//					"type": "string",
//					"valText": "Deploy"
//				},
//				"score": {
//					"type": "string",
//					"valText": "- . -"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2REVBSC0",
//					"attrs": {
//						"id": "loadModel",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2RF5VNO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2RF5VNO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2RF5VNO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2REVKMH0",
//					"attrs": {
//						"id": "showModel",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2RF5VNO3",
//							"attrs": {
//								"md": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2RF5VNO4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2RF5VNO5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2OAIJ358",
//			"attrs": {
//				"loading": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2RFKG9I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2RFRHN70",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2RFKN240",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2RFRHN71",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2OAIJ359",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1J2OAIJ351",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2OAIJ3510",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "#opts.autoHeight?\"\":\"100%\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2OAMUF50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2OAMUF51",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTop",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2OAMUF52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OAMUF53",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxLeft",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "80",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "85",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center",
//														"subAlign": "Center",
//														"attach": "#opts.scores"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2OAMUF60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OAMUF61",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxScore",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "80",
//																		"h": "70",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[10,10,0,10]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OAMUF62",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFUN1A0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFUN1A1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RG3QSB0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RG3QSB1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OAMUF67",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OAMUF68",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J2RG09CU0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RG3QSB2",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxScoreLoading...",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "80",
//																		"h": "80",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "assets/aifrontier.svg"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2RG3QSB3",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RG3QSB4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RG3QSB5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RG3QSB6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RG3QSB7",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RG3QSB8",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RG3QSB9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J2SM89KL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2SMA00V0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtScore",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "80%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[-5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.score},state",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Right",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2SMA00V1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1J2SMA00V2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2SMA00V3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OAMUF69",
//													"attrs": {
//														"1J2RFKG9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2S386BM0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2S386BM1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKG9I0",
//															"faceTagName": "loading"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OAMUF614",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OAMUF615",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2OAMUF616",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OAMUF70",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxConent",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-80",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[15,0,0,5]",
//														"minW": "",
//														"minH": "50",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J2OAMUF71",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OAMUF72",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtName",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "${state.name},state",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OAMUF80",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2S386BN0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2S386BN1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OAMUF87",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OAMUF88",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2OAMUF89",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OAMUF810",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxStates",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center",
//																		"itemsWrap": "Wrap"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUF811",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUF812",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "20",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor[\"secondary\"]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/download.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUF90",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUF95",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUF96",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2OAMUF97",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUF98",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtDownloads",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,8,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"secondary\"]",
//																						"text": "${state.downloads},state",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUF99",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUF914",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUF915",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUFA16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFA17",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "20",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor[\"secondary\"]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/datetime.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFB0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFB5",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFB6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2OAMUFB7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFB8",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtTime",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,8,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"secondary\"]",
//																						"text": "${state.time},state",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFB9",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFB14",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFB15",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUFB16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFB17",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxDeployMark",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "20",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "${state.deploy!==\"NA\"},state",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor[\"secondary\"]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/check_fat.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFC0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFC5",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFC6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2OAMUFC7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFC8",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "${state.deploy!==\"NA\"},state",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,8,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"secondary\"]",
//																						"text": "${state.deploy},state",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFC9",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFC14",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFC15",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2OAMUFC16",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFRHN724",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFRHN725",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFUN1A22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFUN1A23",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OAMUFC21",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OAMUFC22",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2RF4EAF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RF5VNP0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxStateLoading",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RF78D50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFB91N0",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "14",
//																						"h": "14",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "2",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFB91N1",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFB91N2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFB91O0",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2RFA94B0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFBBKH0",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,15,0,3]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodyLit\"]",
//																						"text": "- - -",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFBBKH1",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFBBKH2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFBBKH3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RFB9Q90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFB9Q91",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "14",
//																						"h": "14",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "2",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFB9QA0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFB9QA1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFB9QA2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2RFBC9L0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFBC9L1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,15,0,3]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodyLit\"]",
//																						"text": "- - -",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFBC9M0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFBC9M1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFBC9M2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RFBED60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFBED61",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "14",
//																						"h": "14",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "2",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFBED70",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFBED71",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFBED72",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2RFBI4F0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFBI4F1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,15,0,3]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodyLit\"]",
//																						"text": "- - -",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFBI4G0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFBI4G1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFBI4G2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2RF5VNP1",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFRHN812",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFRHN813",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFUN1A36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFUN1A37",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RF5VNP2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RF5VNP3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2OAMUFF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2OAMUFF1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxTags",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsWrap": "Wrap"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUFF2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFF3",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,5,5,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J2OAMUFF4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2OAMUFF5",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "TTS",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J2OAMUFG0",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J2S386BN26",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J2S386BN27",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J2OAMUFG5",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J2OAMUFG6",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFG7",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFG12",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFG13",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUFG14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFG15",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,5,0,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J2OAMUFG16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2OAMUFG17",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Tool",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J2OAMUFH0",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J2S386BN30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J2S386BN31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J2OAMUFH5",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J2OAMUFH6",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFH7",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFH12",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFH13",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2OAMUFH14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2OAMUFH15",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,5,0,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J2OAMUFH16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2OAMUFH17",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "70B",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J2OAMUFH18",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J2S386BN34",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J2S386BN35",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J2OAMUFH23",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J2OAMUFH24",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J2OAMUFH25",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2OAMUFH30",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2OAMUFH31",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J3NE11MC0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J3NE11MC1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,5,0,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J3NE11MC2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE11MC3",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Tool",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J3NE11MD0",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J3NE11MD1",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J3NE11MD2",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J3NE11MD3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J3NE11MD4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J3NE11MD5",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J3NE11MD6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE11MD7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J3NE11MD8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J3NE11MD9",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J3NE4IG20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J3NE4IG21",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,5,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J3NE4IG22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE4IG30",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Tool",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J3NE4IG31",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J3NE4IG32",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J3NE4IG33",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J3NE4IG34",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J3NE4IG35",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J3NE4IG36",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J3NE4IG37",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE4IG38",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J3NE4IG39",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J3NE4IG310",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J3NE4K7S0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J3NE4K7S1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,5,0,0]",
//																						"padding": "[0,12,0,10]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1J3NE4K7T0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE4K7T1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Tool",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J3NE4K7T2",
//																									"attrs": {
//																										"1J2RFKG9I0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J3NE4K7T3",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J3NE4K7T4",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J2RFKG9I0",
//																											"faceTagName": "loading"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J3NE4K7T5",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J3NE4K7T6",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1J3NE4K7T7",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J3NE4K7T8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J3NE4K7T9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J3NE4K7T10",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J3NE4K7T11",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2OAMUFH32",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFRHN826",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFRHN827",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFUN1A50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFUN1A51",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OAMUFH37",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OAMUFH38",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2RFCLCB0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFCLCB1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxTagLoading",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "0.50",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RFCLCC0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFCLCC1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "50",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "4",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFCLCC2",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFCLCC3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFCLCC4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RFFEDM0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFFEDM1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "50",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "4",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFFEDN0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFFEDN1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFFEDN2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2RFFFPI0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFFFPI1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "50",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "4",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2RFFFPJ0",
//																					"attrs": {
//																						"1J2RFKG9I0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J2S386BN42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J2S386BN43",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J2RFKG9I0",
//																							"faceTagName": "loading"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2RFFFPJ1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2RFFFPJ2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2RFCLCF8",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFRHN834",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFRHN835",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		},
//																		"1J2RFKN240": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2RFUN1B6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2RFUN1B7",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKN240",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RFCLCF9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RFCLCF10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OAMUFH39",
//													"attrs": {
//														"1J2RFKG9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2S386BN44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2S386BN45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKG9I0",
//															"faceTagName": "loading"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OAMUFH44",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OAMUFH45",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2OAMUFI0",
//									"attrs": {
//										"1J2RFKG9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2S386BN46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2S386BN47",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2RFKG9I0",
//											"faceTagName": "loading"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2OAMUFI5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OAMUFI6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2OBHCKN0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2OBHCKN1",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxInfo",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,10,5,10]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OBHCKO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OBHCKO1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtBrief",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.brief},state",
//														"font": "",
//														"fontSize": "#txtSize.small+1",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "#opts.autoHeight?100:5",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OBHCKP0",
//													"attrs": {
//														"1J2RFKG9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2RFRHN840",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFRHN841",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKG9I0",
//															"faceTagName": "loading"
//														},
//														"1J2RFKN240": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2RFUN1B12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFUN1B13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKN240",
//															"faceTagName": "ready"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OBHCKP3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OBHCKP4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2RFL8C60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2RFRHN842",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxBriefLoading",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "0.5",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J2RFMQ1O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFNORI0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "16",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "5",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2RFNORI1",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2S386BN48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2S386BN49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RFNORI2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RFNORI3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J2RFNPSL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFNPSL1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "16",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "5",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2RFNPSM0",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2S386BN50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2S386BN51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RFNPSM1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RFNPSM2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J2RFNR830",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFNR831",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "16",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "5",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2RFNR840",
//																	"attrs": {
//																		"1J2RFKG9I0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J2S386BN52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2S386BN53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J2RFKG9I0",
//																			"faceTagName": "loading"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2RFNR841",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2RFNR842",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2RFRHN849",
//													"attrs": {
//														"1J2RFKG9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2RFRHN850",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFRHN851",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKG9I0",
//															"faceTagName": "loading"
//														},
//														"1J2RFKN240": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2RFUN1C2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2RFUN1C3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2RFKN240",
//															"faceTagName": "ready"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2RFRHN852",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2RFRHN853",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2OBHCKP5",
//									"attrs": {
//										"1J2RFKG9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2S386BN54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2S386BN55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2RFKG9I0",
//											"faceTagName": "loading"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2OBHCKP8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OBHCKP9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2OAIJ3511",
//					"attrs": {
//						"1J2RFKG9I0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2S386BN56",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2S386BN57",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2RFKG9I0",
//							"faceTagName": "loading"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2OAIJ3512",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2OAIJ3513",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2OAIJ360",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}