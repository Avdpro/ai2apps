//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1J2U0851Q0StartDoc*/
/*}#1J2U0851Q0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnArticle=function(article){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1J2U0851Q1LocalVals*/
	/*}#1J2U0851Q1LocalVals*/
	
	/*#{1J2U0851Q1PreState*/
	/*}#1J2U0851Q1PreState*/
	/*#{1J2U0851Q1PostState*/
	/*}#1J2U0851Q1PostState*/
	cssVO={
		"hash":"1J2U0851Q1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"pointer","margin":[10,0,10,0],"padding":[0,10,0,10],"minW":"","minH":50,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1J2U0A1V60",
				"type":"box","id":"BoxIcon","position":"relative","x":20,"y":20,"w":40,"h":40,"anchorX":1,"anchorY":1,"overflow":1,"uiEvent":-1,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":2,"borderColor":cfgColor["secondary"],"corner":8,
				children:[
					{
						"hash":"1J2U098CP0",
						"type":"image","id":"ImgIcon","position":"relative","x":"50%","y":"50%","w":36,"h":36,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","image":article.icon||(appCfg.sharedAssets+"/web.svg"),"fitSize":true,"repeat":false,
					}
				],
			},
			{
				"hash":"1J2U0D5CR0",
				"type":"hud","id":"Box","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"padding":[0,10,0,10],"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","flex":true,"contentLayout":"flex-y",
				children:[
					{
						"hash":"1J2U0H2PH0",
						"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":article.title,"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1J2U0JBRI0",
						"type":"text","id":"TxtBrief","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBodySub"],"text":article.brief,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
						"lineClamp":3,
					},
					{
						"hash":"1J2U0FCGL0",
						"type":"text","id":"TxtSite","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":article.site,"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					}
				],
			}
		],
		/*#{1J2U0851Q1ExtraCSS*/
		/*}#1J2U0851Q1ExtraCSS*/
		faces:{
			"up":{
				/*BoxIcon*/"#1J2U0A1V60":{
					"scale":1
				},
				/*TxtTitle*/"#1J2U0H2PH0":{
					"textDecoration":""
				}
			},"over":{
				/*BoxIcon*/"#1J2U0A1V60":{
					"scale":1.1
				},
				/*TxtTitle*/"#1J2U0H2PH0":{
					"textDecoration":"underline"
				}
			},"down":{
				/*BoxIcon*/"#1J2U0A1V60":{
					"scale":1
				},
				/*TxtTitle*/"#1J2U0H2PH0":{
					"textDecoration":"underline"
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1J2U0851Q1Create*/
			/*}#1J2U0851Q1Create*/
		},
		/*#{1J2U0851Q1EndCSS*/
		/*}#1J2U0851Q1EndCSS*/
	};
	/*#{1J2U0851Q1PostCSSVO*/
	cssVO.OnClick=function(){
		if(window.taApi){
			window.taApi.shellExec(article.url);
		}else{
			window.open(article.url, "_blank");
		}
	}
	/*}#1J2U0851Q1PostCSSVO*/
	cssVO.constructor=BtnArticle;
	return cssVO;
};
/*#{1J2U0851Q1ExCodes*/
/*}#1J2U0851Q1ExCodes*/

//----------------------------------------------------------------------------
BtnArticle.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2U0851Q1PreAISpot*/
	/*}#1J2U0851Q1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2U0851Q1PostAISpot*/
	/*}#1J2U0851Q1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnArticle.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"article": {
			"type": "object", "name": "article", "showName": "article", "icon": undefined, 
			"def": {
				"attrs": {
					"site": {
						"name": "site", "showName": "site", "type": "string", "key": true, "fixed": true, "initVal": "www.google.com"
					}, 
					"title": {
						"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Hands on: AI2Apps"
					}, 
					"icon": {
						"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": ""
					}, 
					"brief": {
						"name": "brief", "showName": "brief", "type": "string", "key": true, "fixed": true, "initVal": "FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down"],
	subContainers:{
	},
	/*#{1J2U0851Q0ExGearInfo*/
	/*}#1J2U0851Q0ExGearInfo*/
};
/*#{1J2U0851Q0EndDoc*/
/*}#1J2U0851Q0EndDoc*/

export default BtnArticle;
export{BtnArticle};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1J2U0851Q0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2U0851Q2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2U0851Q3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2U0851Q4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2U0851Q5",
//			"attrs": {
//				"article": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1J2U0SSOD0",
//					"attrs": {
//						"site": {
//							"type": "string",
//							"valText": "www.google.com"
//						},
//						"title": {
//							"type": "string",
//							"valText": "Hands on: AI2Apps"
//						},
//						"icon": {
//							"type": "string",
//							"valText": ""
//						},
//						"brief": {
//							"type": "string",
//							"valText": "FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1J2U0851Q6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2U0851Q7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2U0851Q8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U1Q75J0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U1T4S20",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U1QANB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U1T4S21",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2U1QDT40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2U1T4S22",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2U0851Q9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1J2U0851Q1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2U0851Q10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[10,0,10,0]",
//						"padding": "[0,10,0,10]",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1J2U0A1V60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U0M3320",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "20",
//										"y": "20",
//										"w": "40",
//										"h": "40",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"secondary\"]",
//										"corner": "8",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1J2U098CP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U0APJO0",
//													"attrs": {
//														"type": "image",
//														"id": "ImgIcon",
//														"position": "relative",
//														"x": "50%",
//														"y": "50%",
//														"w": "36",
//														"h": "36",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#article.icon||(appCfg.sharedAssets+\"/web.svg\")",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "false",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2U0APJO1",
//													"attrs": {
//														"1J2U1Q75J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S23",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S24",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1Q75J0",
//															"faceTagName": "up"
//														},
//														"1J2U1QANB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S25",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S26",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1QANB0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U0APJO2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U0APJO3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2U0M3321",
//									"attrs": {
//										"1J2U1QDT40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U1T4S27",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U1T4S28",
//													"attrs": {
//														"scale": {
//															"type": "auto",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U1QDT40",
//											"faceTagName": "down"
//										},
//										"1J2U1Q75J0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U1T4S29",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U1T4S210",
//													"attrs": {
//														"scale": {
//															"type": "auto",
//															"valText": "1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U1Q75J0",
//											"faceTagName": "up"
//										},
//										"1J2U1QANB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U1T4S211",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U1T4S212",
//													"attrs": {
//														"scale": {
//															"type": "auto",
//															"valText": "1.1"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U1QANB0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2U0M3322",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2U0M3323",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2U0D5CR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U0M3324",
//									"attrs": {
//										"type": "hud",
//										"id": "Box",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2U0H2PH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U0JAKD0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "#article.title",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2U0JAKE0",
//													"attrs": {
//														"1J2U1QDT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S213",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S214",
//																	"attrs": {
//																		"underline": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1QDT40",
//															"faceTagName": "down"
//														},
//														"1J2U1Q75J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S215",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S216",
//																	"attrs": {
//																		"underline": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1Q75J0",
//															"faceTagName": "up"
//														},
//														"1J2U1QANB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S217",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S218",
//																	"attrs": {
//																		"underline": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1QANB0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U0JAKE1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U0JAKE2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2U0JBRI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U0JBRI1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtBrief",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#article.brief",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "3",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2U0JBRJ0",
//													"attrs": {
//														"1J2U1Q75J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S219",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S220",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1Q75J0",
//															"faceTagName": "up"
//														},
//														"1J2U1QANB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S221",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S222",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1QANB0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U0JBRJ1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U0JBRJ2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2U0FCGL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U0M3325",
//													"attrs": {
//														"type": "text",
//														"id": "TxtSite",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "#article.site",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2U0M3326",
//													"attrs": {
//														"1J2U1Q75J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S223",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S224",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1Q75J0",
//															"faceTagName": "up"
//														},
//														"1J2U1QANB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J2U1T4S225",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2U1T4S226",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J2U1QANB0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U0M3327",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U0M3328",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2U0M3330",
//									"attrs": {
//										"1J2U1Q75J0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U1T4S227",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U1T4S228",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U1Q75J0",
//											"faceTagName": "up"
//										},
//										"1J2U1QANB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2U1T4S229",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U1T4S230",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2U1QANB0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2U0M3331",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2U0M3332",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2U0851Q11",
//					"attrs": {
//						"1J2U1Q75J0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2U1T4S231",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U1T4S232",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2U1Q75J0",
//							"faceTagName": "up"
//						},
//						"1J2U1QANB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2U1T4S233",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2U1T4S234",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2U1QANB0",
//							"faceTagName": "over"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2U0851Q12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2U0851Q13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2U0851Q14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}