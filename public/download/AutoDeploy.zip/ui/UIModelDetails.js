//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxModelCard} from "./BoxModelCard.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnLink} from "./BtnLink.js";
import {BtnArticle} from "./BtnArticle.js";
/*#{1J2OD445V0StartDoc*/
import pathLib from "/@path";
import {makeScorePolygonDiv} from "../DrawScore.js";
import {tabNT,tabFS} from "/@tabos";
import {getLocalAppInfo,getCloudAppInfo} from "/@pkg/pkgUtil.js";
import {runAgent,showChatThread,runAppAsAgent} from "/@AgentBuilder/ai/RunAgent.js";
/*}#1J2OD445V0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIModelDetails=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxCard,btnDeploy,btnInstall,btnRunAgent,btnUpdate,txtModelId,boxScoreShape,txtScoreOverall,txtDeployMacOS,txtDeployLinux,txtDeployWin32,lnkHomepage,lnkGitHub,lnkHuggingFace,txtMedia,boxMedia,txtReadme;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let modelId=null;
	let modelData=null;
	let appStub=null;
	
	/*#{1J2OD445V1LocalVals*/
	const app=VFACT.app;
	/*}#1J2OD445V1LocalVals*/
	
	/*#{1J2OD445V1PreState*/
	/*}#1J2OD445V1PreState*/
	/*#{1J2OD445V1PostState*/
	/*}#1J2OD445V1PostState*/
	cssVO={
		"hash":"1J2OD445V1",nameHost:true,
		"type":"view","x":"50%","y":0,"w":"100%","h":"100%","anchorX":1,"overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1J2TUBRN90",
				"type":"hud","id":"BoxContents","position":"relative","x":"50%","y":0,"w":"100%","h":"","anchorX":1,"minW":"","minH":"","maxW":600,"maxH":"","styleClass":"",
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1J2OD7KN50",
						"type":"hud","id":"BoxCard","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1J2OD8M7R0",
								"type":BoxModelCard(undefined,{"scores":false,"autoHeight":false,"fontSize":txtSize.mid}),"id":"boxCard","position":"relative","x":0,"y":0,
							},
							{
								"hash":"1J2ODU80H0",
								"type":BtnText("secondary",120,28,(($ln==="CN")?("智能部署"):("Deploy")),false,appCfg.sharedAssets+"/lab.svg"),"id":"BtnDeploy","x":">calc(100% - 130px)",
								"y":16,"display":0,
								"OnClick":function(event){
									self.deployModel(this,event);
								},
							},
							{
								"hash":"1J4394FON0",
								"type":BtnText("primary",120,28,(($ln==="CN")?("安装智能体"):("Install Agent")),false,appCfg.sharedAssets+"/download.svg"),"id":"BtnInstall","x":">calc(100% - 130px)",
								"y":16,"display":0,
								"OnClick":function(event){
									self.installApp(this,event);
								},
							},
							{
								"hash":"1J439RQB80",
								"type":BtnText("success",120,28,(($ln==="CN")?("执行智能体"):("Open Agent")),false,appCfg.sharedAssets+"/run.svg"),"id":"BtnRunAgent","x":">calc(100% - 130px)",
								"y":16,
								"OnClick":function(event){
									self.OpenApp(this,event);
								},
							},
							{
								"hash":"1J4396KI20",
								"type":BtnText("primary",120,28,(($ln==="CN")?("更新智能体"):("Update Agent")),false,appCfg.sharedAssets+"/update.svg"),"id":"BtnUpdate","x":">calc(100% - 130px)",
								"y":16,"display":0,
								"OnClick":function(event){
									self.updateApp(this,event);
								},
							},
							{
								"hash":"1JBP1Q4EK0",
								"type":BtnText("primary",100,28,"Search Any",false,""),"id":"SearchAny","x":363,"y":16,
								"OnClick":function(event){
									self.chatOnClick(this,event);
								},
								"OnButtonDown":function(code,event){
									/*#{1JGMI8FML0FunctionBody*/
									/*}#1JGMI8FML0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1J2TL1P660",
						"type":"text","id":"TxtModelId","position":"relative","x":"50%","y":0,"w":"100%","h":"","anchorX":1,"display":0,"scale":1,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["secondary"],"text":"- - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignH":1,"selectable":true,
					},
					{
						"hash":"1J2OISEMA0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["secondary"],
						"text":(($ln==="CN")?("模型评分:"):("Scores:")),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1J2OD9NAC0",
						"type":"hud","id":"BoxScores","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,20,0],"minW":"","minH":100,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y","itemsAlign":1,
						children:[
							{
								"hash":"1J2ODAKOE0",
								"type":"hud","id":"BoxScoreShape","position":"relative","x":0,"y":0,"w":240,"h":240,"padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x","subAlign":1,"itemsAlign":1,
							},
							{
								"hash":"1J2ODBH8H0",
								"type":"hud","id":"LineCap","position":"relative","x":0,"y":0,"w":"100%","h":24,"margin":[20,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x","itemsAlign":1,"subAlign":1,
								children:[
									{
										"hash":"1J2ODDUPN0",
										"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","padding":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":(($ln==="CN")?("综合评分:"):("Overall:")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
										"textDecoration":"","alignH":2,
									},
									{
										"hash":"1J2ODGH3C0",
										"type":"text","id":"TxtScoreOverall","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":"8.9","fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
									}
								],
							},
							{
								"hash":"1J2TJLTJ40",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["secondary"],
								"text":(($ln==="CN")?("对模型的评分系统很难做到完全客观，结果仅供参考。"):("Scoring models is difficult to be completely objective, the results are for reference only.")),
								"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					},
					{
						"hash":"1J2VDC4VB0",
						"type":"text","id":"TxtDeploy","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["secondary"],"text":(($ln==="CN")?("部署项目:"):("Deployment:")),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
						"textDecoration":"",
					},
					{
						"hash":"1J2VDDN070",
						"type":"hud","id":"BoxDeploy","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,20,0],"padding":[10,30,10,36],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1J2VDEU960",
								"type":"hud","id":"LineMacOS","position":"relative","x":0,"y":0,"w":"60%","h":30,"margin":[0,0,10,0],"minW":280,"minH":"","maxW":"","maxH":"",
								"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1J2VDGDRE0",
										"type":"box","position":"relative","x":0,"y":0,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
										"maskImage":appCfg.sharedAssets+"/macos.svg",
									},
									{
										"hash":"1J2VDHRA50",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Mac OS:",
										"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2VDOPVK0",
										"type":"text","id":"TxtDeployMacOS","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":"NA","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":2,
										"flex":true,
									},
									{
										"hash":"1J2VDURMI0",
										"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									}
								],
							},
							{
								"hash":"1J2VDNAS80",
								"type":"hud","id":"LineLinux","position":"relative","x":0,"y":0,"w":"60%","h":30,"margin":[0,0,10,0],"minW":280,"minH":"","maxW":"","maxH":"",
								"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1J2VDNAS82",
										"type":"box","position":"relative","x":0,"y":0,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
										"maskImage":appCfg.sharedAssets+"/linux.svg",
									},
									{
										"hash":"1J2VDNAS93",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Ubentu / Linux:",
										"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2VDR6Q60",
										"type":"text","id":"TxtDeployLinux","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":"NA","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":2,
										"flex":true,
									},
									{
										"hash":"1J2VDVSBF0",
										"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									}
								],
							},
							{
								"hash":"1J2VDK85H0",
								"type":"hud","id":"LineWin32","position":"relative","x":0,"y":0,"w":"60%","h":30,"minW":280,"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1J2VDK85I0",
										"type":"box","position":"relative","x":0,"y":0,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
										"maskImage":appCfg.sharedAssets+"/win32.svg",
									},
									{
										"hash":"1J2VDK85I5",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Windows:",
										"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J2VDQQ1F0",
										"type":"text","id":"TxtDeployWin32","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":"NA","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":2,
										"flex":true,
									},
									{
										"hash":"1J2VDVQTU0",
										"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
									}
								],
							}
						],
					},
					{
						"hash":"1J2U2Q70R0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["secondary"],
						"text":(($ln==="CN")?("项目网址:"):("Model address links:")),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1J2U2S3CT0",
						"type":"hud","id":"BoxLinks","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,20,0],"padding":[0,20,0,20],"minW":"","minH":30,"maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1J2U2UDQP0",
								"type":BtnLink("Homepage"),"id":"LnkHomepage","position":"relative","x":0,"y":0,
							},
							{
								"hash":"1J2U2U5BB0",
								"type":BtnLink("GitHub Project"),"id":"LnkGitHub","position":"relative","x":0,"y":0,
							},
							{
								"hash":"1J2U2UMRO0",
								"type":BtnLink("Huggingface Model"),"id":"LnkHuggingFace","position":"relative","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1J2OIL8MP0",
						"type":"text","id":"TxtMedia","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["secondary"],"text":(($ln==="CN")?("媒体文章:"):("Media reviews:")),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
						"textDecoration":"",
					},
					{
						"hash":"1J2ODQ0670",
						"type":"hud","id":"BoxMedia","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,10,10,10],"minW":"","minH":100,"maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1J2U1BVIQ0",
								"type":BtnArticle({"site":"www.google.com","title":"Hands on: AI2Apps","icon":"","brief":"FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"}),
								"position":"relative","x":0,"y":0,
							},
							{
								"hash":"1J2U1CEO40",
								"type":BtnArticle({"site":"www.yahoo.com","title":"ChatGPT 5 Review","icon":"","brief":"FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"}),
								"position":"relative","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1J2OIMG640",
						"type":"text","id":"TxtReadme","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["secondary"],"text":(($ln==="CN")?("项目说明:"):("Readme:")),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
						"textDecoration":"",
					}
				],
			}
		],
		/*#{1J2OD445V1ExtraCSS*/
		/*}#1J2OD445V1ExtraCSS*/
		faces:{
			"noDeploy":{
				/*BtnDeploy*/"#1J2ODU80H0":{
					"display":0
				},
				/*BtnInstall*/"#1J4394FON0":{
					"display":0
				},
				/*BtnRunAgent*/"#1J439RQB80":{
					"display":0
				},
				/*BtnUpdate*/"#1J4396KI20":{
					"display":0
				},
				/*SearchAny*/"#1JBP1Q4EK0":{
					"display":1,"id":"ChatBtn"
				}
			},"deploy":{
				/*BtnDeploy*/"#1J2ODU80H0":{
					"display":1
				},
				/*BtnInstall*/"#1J4394FON0":{
					"display":0
				},
				/*BtnRunAgent*/"#1J439RQB80":{
					"display":0
				},
				/*BtnUpdate*/"#1J4396KI20":{
					"display":0
				},
				/*SearchAny*/"#1JBP1Q4EK0":{
					"display":1
				}
			},"install":{
				/*BtnDeploy*/"#1J2ODU80H0":{
					"display":0
				},
				/*BtnInstall*/"#1J4394FON0":{
					"display":1
				},
				/*BtnRunAgent*/"#1J439RQB80":{
					"display":0
				},
				/*BtnUpdate*/"#1J4396KI20":{
					"display":0
				}
			},"update":{
				/*BtnDeploy*/"#1J2ODU80H0":{
					"display":0
				},
				/*BtnInstall*/"#1J4394FON0":{
					"display":0
				},
				/*BtnRunAgent*/"#1J439RQB80":{
					"display":0
				},
				/*BtnUpdate*/"#1J4396KI20":{
					"display":1
				}
			},"open":{
				/*BtnDeploy*/"#1J2ODU80H0":{
					"display":0
				},
				/*BtnInstall*/"#1J4394FON0":{
					"display":0
				},
				/*BtnRunAgent*/"#1J439RQB80":{
					"display":1
				},
				/*BtnUpdate*/"#1J4396KI20":{
					"display":0
				}
			},"qa":{
			}
		},
		OnCreate:function(){
			self=this;
			boxCard=self.boxCard;btnDeploy=self.BtnDeploy;btnInstall=self.BtnInstall;btnRunAgent=self.BtnRunAgent;btnUpdate=self.BtnUpdate;txtModelId=self.TxtModelId;boxScoreShape=self.BoxScoreShape;txtScoreOverall=self.TxtScoreOverall;txtDeployMacOS=self.TxtDeployMacOS;txtDeployLinux=self.TxtDeployLinux;txtDeployWin32=self.TxtDeployWin32;lnkHomepage=self.LnkHomepage;lnkGitHub=self.LnkGitHub;lnkHuggingFace=self.LnkHuggingFace;txtMedia=self.TxtMedia;boxMedia=self.BoxMedia;txtReadme=self.TxtReadme;
			/*#{1J2OD445V1Create*/
			self._isChatShow = false;  
			/*}#1J2OD445V1Create*/
		},
		/*#{1J2OD445V1EndCSS*/
		/*}#1J2OD445V1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showUI=async function(model){
		/*#{1J2TK36A70Start*/
		let modelId;
		if(!model){
			return;
		}
		if(app.mainUI){
			txtModelId.display=app.mainUI.BtnAdmin?.display;
		}
		if(model.id){
			modelId=model.id;
			modelData=model;
			self.model=modelId;
			self.showModel(model);
		}else{
			self.loadModel(modelId);
		}
		// 添加窗口焦点监听，当用户回到页面时自动刷新状态
		if(!self._focusListenerAdded){
			self._focusListenerAdded=true;
			window.addEventListener('focus', async function(){
				console.log("[UIModelDetails] Window focused, refreshing deploy status...");
				if(modelData && modelData.deploy){
					await self.checkDeploy();
				}
			});
		}
		/*}#1J2TK36A70Start*/
	};
	//------------------------------------------------------------------------
	cssVO.loadModel=async function(modelId){
		/*#{1J2TK9IDT0Start*/
		boxCard.showFace("loading");
		//TODO: Code this?
		/*}#1J2TK9IDT0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModel=async function(model){
		/*#{1J2TK9ON10Start*/
		const dpTexts={
			"Deploy":(($ln==="CN")?("可部署"):/*EN*/("Deployable")),
			"Agent":(($ln==="CN")?("有智能体"):/*EN*/("Agentic")),
		};
		function fixScore(text){
			return text.length===1?(text+".0"):text;
		}
		self.showFace("noDeploy");
		boxCard.showModel(model);
		self.checkDeploy();
		txtModelId.text=`Model-Id: "${model.id}"`;
		//Draw shape:
		boxScoreShape.webObj.innerHTML="";
		if(model.openSource){
			boxScoreShape.webObj.appendChild(makeScorePolygonDiv(
				[model.scoreCapability,model.scoreDeployment,model.scorePopularity,model.scoreObjective,model.scoreTiming,model.scoreSize],10,
				{
					size:200,
					labels:[
						(($ln==="CN")?("模型能力:"):("Capability:")),
						(($ln==="CN")?("部署应用:"):("Deployment:")),
						(($ln==="CN")?("热度:"):("Popularity:")),
						(($ln==="CN")?("主观评价:"):("Objective:")),
						(($ln==="CN")?("时间/新鲜度:"):("Timing:")),
						(($ln==="CN")?("模型尺寸:"):("Size:")),
					]
				}
			));
			txtScoreOverall.text=fixScore(model.scoreOverall);
		}else{
			boxScoreShape.webObj.appendChild(makeScorePolygonDiv(
				[model.scoreCapability,model.scorePopularity,model.scoreObjective,model.scoreTiming,],10,
				{
					size:200,
					labels:[
						(($ln==="CN")?("模型能力:"):("Capability:")),
						(($ln==="CN")?("热度:"):("Popularity:")),
						(($ln==="CN")?("主观评价:"):("Objective:")),
						(($ln==="CN")?("时间/新鲜度:"):("Timing:")),
					]
				}
			));
			txtScoreOverall.text=fixScore(model.scoreOverall);
		}
		//Show deploy:
		txtDeployWin32.text=dpTexts[model.deploy.windows]||"NA";
		txtDeployMacOS.text=dpTexts[model.deploy.mac]||"NA";
		txtDeployLinux.text=dpTexts[model.deploy.linux]||"NA";
		//Show links:
		lnkHomepage.setLink(model.urlHomepage);
		lnkGitHub.setLink(model.urlGitHub);
		lnkHuggingFace.setLink(model.urlHuggingFace);
		//Show media articles:
		if(model.articles?.length){
			let article;
			boxMedia.display=true;
			txtMedia.display=true;
			boxMedia.clearChildren();
			for(article of model.articles){
				boxMedia.appendNewChild(BtnArticle(article));
			}
		}else{
			boxMedia.display=false;
			txtMedia.display=false;
		}
		//TODO: Show project readme:
		if(model.readme){
			txtReadme.display=true;
		}else{
			txtReadme.display=false;
		}
		/*}#1J2TK9ON10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkDeploy=async function(){
		/*#{1J436NJ7K0Start*/
		let platform,deploy,appId,localInfo;
		platform=appCfg.platform;
		deploy=modelData.deploy;
		console.log("[CheckDeploy] Platform:", platform, "Deploy config:", deploy);
		if(!deploy){
			return;
		}
		deploy=deploy[platform];
		if(deploy==="Agent"){
			const filePath = pathLib.join("/doc/ModelHunt", "model.json");
			let modelJSON;
			try {
				let fileContent = await tabFS.readFile(filePath, "utf8");
				modelJSON = JSON.parse(fileContent);
			} catch (error) {
				modelJSON = { deployable: [] };
				await tabFS.writeFile(filePath, JSON.stringify(modelJSON, null, 2), "utf8");
			}
			let deployed_models = modelJSON.deployable || [], model = self.model;
			if(deployed_models.includes(model)){
				self.showFace("open");
			}
			else if(deploy==="Agent"){
				self.showFace("install");
			}
		}
		else{
			self.showFace("noDeploy");
		}
		/*}#1J436NJ7K0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.deployModel=async function(){
		/*#{1J2TKA1Q60Start*/
		let appInfo,agentPath;
		let appFrame=app.appFrame;
		appInfo=await getLocalAppInfo("auto_deploy");
		agentPath="/@AutoDeploy/ai/AutoDeploy.js";
		
		if(appFrame.runTool){
			appFrame.runTool(agentPath,{prjURL:modelData.urlGitHub,url:modelData.urlGitHub});
		}else{
			let callAgent;
			callAgent=(await import("/@AgentBuilder/ai/RunAgent.js")).callAgent;
			if(callAgent){
				await callAgent({agent:agentPath,args:{prjURL:modelData.urlGitHub},title:(($ln==="CN")?("安装项目"):/*EN*/("Deploy Project"))});
				self.checkVersion();
			}
		}
		/*}#1J2TKA1Q60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.installApp=async function(){
		/*#{1J43A88VB0Start*/
		let appFrame=app.appFrame;
		console.log("[InstallApp] Starting installation...");
		
		let installed=false;
		let checkInterval=setInterval(async ()=>{
		let modelJSON=await tabFS.readFile(pathLib.join("/doc/ModelHunt","model.json"),"utf8");
		modelJSON=JSON.parse(modelJSON);
		let deployed_models=modelJSON.deployable||[];
		if(deployed_models.includes(self.model)){
			installed=true;
			clearInterval(checkInterval);
			await self.checkDeploy();
			}
		},2000);
		
		if(appFrame.runTool){
			appFrame.runTool("/~/-AutoDeploy/ai/ModelHunt.js",{model:self.model,_chatTitle:modelData.name});
		}else{
			let callAgent;
			callAgent=(await import("/@AgentBuilder/ai/RunAgent.js")).callAgent;
			if(callAgent){
			try{
				await callAgent({agent:"/-AutoDeploy/ai/ModelHunt.js",args:{model:self.model},title:(($ln==="CN")?("安装智能体/应用"):/*EN*/("Installing agent/application"))});
			}catch(e){}
			finally{
				clearInterval(checkInterval);
				if(!installed){
					await self.checkDeploy();
				}
			}
		}
		}
		/*}#1J43A88VB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateApp=async function(){
		/*#{1J43A8LDU0Start*/
		let appFrame=app.appFrame;
		if(appFrame.runTool){
			await appFrame.runTool("/@AgentBuilder/ai/SysInstallApp.js",{appStub:appStub});
			// 更新完成后刷新按钮状态
			await self.checkDeploy();
		}else{
			let callAgent;
			callAgent=(await import("/@AgentBuilder/ai/RunAgent.js")).callAgent;
			if(callAgent){
				await callAgent({agent:"/@AgentBuilder/ai/SysInstallApp.js",args:{appStub:appStub},title:(($ln==="CN")?("安装智能体/应用"):/*EN*/("Installing agent/application"))});
				// 更新完成后刷新按钮状态
				await self.checkDeploy();
			}
		}
		/*}#1J43A8LDU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OpenApp=async function(){
		/*#{1J43A8TPH0Start*/
		let appFrame=app.appFrame;
		if(appFrame.runTool){
			appFrame.runTool("/~/-AutoDeploy/ai/ModelHunt.js",{model:self.model,_chatTitle:modelData.name});
		}else{
			let callAgent;
			callAgent=(await import("/@AgentBuilder/ai/RunAgent.js")).callAgent;
			if(callAgent){
				callAgent({agent:"/-AutoDeploy/ai/ModelHunt.js",args:{model:self.model},title:(($ln==="CN")?("打开智能体/应用"):/*EN*/("Opening agent/application"))});
			}
		}
		/*}#1J43A8TPH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chatOnClick=async function(sender){
		/*#{1JBU96O0K0Start*/
		let appFrame=app.appFrame;
		await appFrame.runTool("/~/-AgentBuilder/ai/AnySearch.js",{modelName:modelData.name});
		/*}#1JBU96O0K0Start*/
	};
	/*#{1J2OD445V1PostCSSVO*/
	/*}#1J2OD445V1PostCSSVO*/
	cssVO.constructor=UIModelDetails;
	return cssVO;
};
/*#{1J2OD445V1ExCodes*/
/*}#1J2OD445V1ExCodes*/

//----------------------------------------------------------------------------
UIModelDetails.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2OD445V1PreAISpot*/
	/*}#1J2OD445V1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2OD445V1PostAISpot*/
	/*}#1J2OD445V1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
UIModelDetails.gearExport={
	framework: "jax",
	hudType: "view",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["noDeploy","deploy","install","update","open","qa"],
	subContainers:{
	},
	/*#{1J2OD445V0ExGearInfo*/
	/*}#1J2OD445V0ExGearInfo*/
};
/*#{1J2OD445V0EndDoc*/
/*}#1J2OD445V0EndDoc*/

export default UIModelDetails;
export{UIModelDetails};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1J2OD445V0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2OD445V2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "1600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2OD445V3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2OD445V4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2OD445V5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1J2OD445V6",
//			"attrs": {
//				"modelId": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"modelData": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appStub": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2OD445V7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2TK36A70",
//					"attrs": {
//						"id": "showUI",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "60",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2TK3GI10",
//							"attrs": {
//								"model": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2TK3GI11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2TK3GI12",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2TK9IDT0",
//					"attrs": {
//						"id": "loadModel",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2TK9TV80",
//							"attrs": {
//								"modelId": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2TK9TV81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2TK9TV82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2TK9ON10",
//					"attrs": {
//						"id": "showModel",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2TK9TV83",
//							"attrs": {
//								"model": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2TK9TV84",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2TK9TV85",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J436NJ7K0",
//					"attrs": {
//						"id": "checkDeploy",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J436NP240",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J436NP241",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J436NP242",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2TKA1Q60",
//					"attrs": {
//						"id": "deployModel",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2TKAF050",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2TKAF051",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2TKAF052",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J43A88VB0",
//					"attrs": {
//						"id": "installApp",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J43A967N0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J43A967N1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J43A967N2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J43A8LDU0",
//					"attrs": {
//						"id": "updateApp",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J43A967N3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J43A967N4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J43A967N5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J43A8TPH0",
//					"attrs": {
//						"id": "OpenApp",
//						"label": "New AI Seg",
//						"x": "810",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J43A967N6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J43A967N7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J43A967N8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JBU96O0K0",
//					"attrs": {
//						"id": "chatOnClick",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "385",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JBU98ELT0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JBU98ELT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JBU98ELT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2OD445V8",
//			"attrs": {
//				"noDeploy": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J439Q7C90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J439TKOI0",
//							"attrs": {}
//						}
//					}
//				},
//				"deploy": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J439QDH40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J439TKOI1",
//							"attrs": {}
//						}
//					}
//				},
//				"install": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J439QINP0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J439TKOI2",
//							"attrs": {}
//						}
//					}
//				},
//				"update": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J439QNNB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J439TKOI3",
//							"attrs": {}
//						}
//					}
//				},
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J439R14U0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J439TKOI4",
//							"attrs": {}
//						}
//					}
//				},
//				"qa": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JC0DGGKO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JC0DGJ610",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2OD445V9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1J2OD445V1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2OD445V10",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2TUBRN90",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2TUK5PD0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "600",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2OD7KN50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OD8J7U0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCard",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "5",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1J2OAIJ350",
//															"jaxId": "1J2OD8M7R0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OD970N0",
//																	"attrs": {
//																		"model": "",
//																		"opts": {
//																			"jaxId": "1J2OD970N1",
//																			"attrs": {
//																				"scores": "false",
//																				"autoHeight": "false",
//																				"fontSize": "#txtSize.mid"
//																			}
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OD970N2",
//																	"attrs": {
//																		"type": "#null#>BoxModelCard(undefined,{\"scores\":false,\"autoHeight\":false,\"fontSize\":txtSize.mid})",
//																		"id": "boxCard",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OD970N3",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7I4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7I5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFQ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFQ1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQP2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQP3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OD970N4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OD970N5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J2OD970N6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J2ODU80H0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2OE01440",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "120",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Deploy",
//																			"localize": {
//																				"EN": "Deploy",
//																				"CN": "智能部署"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/lab.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2OE01441",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",120,28,(($ln===\"CN\")?(\"智能部署\"):(\"Deploy\")),false,appCfg.sharedAssets+\"/lab.svg\")",
//																		"id": "BtnDeploy",
//																		"position": "Absolute",
//																		"x": "100%-130",
//																		"y": "16",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2OE01442",
//																	"attrs": {
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK11",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439Q7C90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK13",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439Q7C90",
//																			"faceTagName": "noDeploy"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK15",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK17",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2OE01443",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J43CBKT40",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J43CCITV0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J2TKA1Q60"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2OE01444",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J2OE01445",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J2OE01446",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J4394FON0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J4394FON1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "120",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Install Agent",
//																			"localize": {
//																				"EN": "Install Agent",
//																				"CN": "安装智能体"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/download.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J4394FON2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",120,28,(($ln===\"CN\")?(\"安装智能体\"):(\"Install Agent\")),false,appCfg.sharedAssets+\"/download.svg\")",
//																		"id": "BtnInstall",
//																		"position": "Absolute",
//																		"x": "100%-130",
//																		"y": "16",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J4394FON3",
//																	"attrs": {
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439Q7C90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK23",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439Q7C90",
//																			"faceTagName": "noDeploy"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK25",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK27",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK29",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J4394FON4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J43CBSGM0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J43CCITV1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J43A88VB0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J4394FON5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J4394FON6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J4394FON7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J439RQB80",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J439RQB81",
//																	"attrs": {
//																		"style": "success",
//																		"w": "120",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Open Agent",
//																			"localize": {
//																				"EN": "Open Agent",
//																				"CN": "执行智能体"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/run.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J439RQB90",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",120,28,(($ln===\"CN\")?(\"执行智能体\"):(\"Open Agent\")),false,appCfg.sharedAssets+\"/run.svg\")",
//																		"id": "BtnRunAgent",
//																		"position": "Absolute",
//																		"x": "100%-130",
//																		"y": "16",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J439RQB91",
//																	"attrs": {
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK31",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439Q7C90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK33",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439Q7C90",
//																			"faceTagName": "noDeploy"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK35",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK37",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK39",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J439RQB92",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J43CCBJF0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J43CCITV2",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J43A8TPH0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J439RQB93",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J439RQB94",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J439RQB95",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1J4396KI20",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J4396KI21",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "120",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Update Agent",
//																			"localize": {
//																				"EN": "Update Agent",
//																				"CN": "更新智能体"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/update.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J4396KI22",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",120,28,(($ln===\"CN\")?(\"更新智能体\"):(\"Update Agent\")),false,appCfg.sharedAssets+\"/update.svg\")",
//																		"id": "BtnUpdate",
//																		"position": "Absolute",
//																		"x": "100%-130",
//																		"y": "16",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J4396KI23",
//																	"attrs": {
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK41",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439Q7C90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK43",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439Q7C90",
//																			"faceTagName": "noDeploy"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK45",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK47",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK49",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J4396KI24",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J43CC5330",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J43CCITV3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J43A8LDU0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J4396KI25",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J4396KI26",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1J4396KI27",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1JBP1Q4EK0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1JBP1QEAV13",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "28",
//																		"text": "Search Any",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1JBP1QEAV14",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,28,\"Search Any\",false,\"\")",
//																		"id": "SearchAny",
//																		"position": "Absolute",
//																		"x": "363",
//																		"y": "16",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1JBP1QEAV15",
//																	"attrs": {
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBP1RV876",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBP1RV877",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		},
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBP1RV8710",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBP1RV8711",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439Q7C90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBP1RV8714",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBP1RV8715",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						},
//																						"id": {
//																							"type": "string",
//																							"valText": "ChatBtn"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439Q7C90",
//																			"faceTagName": "noDeploy"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7J0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7J1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1JBP1QEAV16",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1JBU98ELT3",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1JBU98ELT4",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1JBU96O0K0"
//																			}
//																		},
//																		"OnButtonDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1JGMI8FML0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1JGMI8FMR0",
//																					"attrs": {
//																						"code": "",
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1JBP1QEAV17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1JBP1QEAV18",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1JBP1QEAV19",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2OD8J7U1",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGK58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGK59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7J6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7J7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQQ7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQQ8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OD8J7U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OD8J7U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2TL1P660",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2TL3VJ80",
//													"attrs": {
//														"type": "text",
//														"id": "TxtModelId",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": "- - -",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "true",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2TL3VJ90",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGK68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGK69",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7J12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7J13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQQ13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQQ14",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2TL3VJ91",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2TL3VJ92",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OISEMA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OISEMA1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": {
//															"type": "string",
//															"valText": "Scores:",
//															"localize": {
//																"EN": "Scores:",
//																"CN": "模型评分:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OISEMB0",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGK78",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGK79",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7J18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7J19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQQ19",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQQ20",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OISEMB1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OISEMB2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2OD9NAC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2ODMGJM0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxScores",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,20,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "100",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2ODAKOE0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2ODMGJM1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxScoreShape",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "240",
//																		"h": "240",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "0",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"subAlign": "Center",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2ODMGJM2",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK89",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7J28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7J29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQQ25",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQQ26",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2ODMGJM3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2ODMGJM4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2ODBH8H0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2ODHF9I0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineCap",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[20,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2ODDUPN0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2ODHF9I1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "[0,10,0,0]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "Overall:",
//																							"localize": {
//																								"EN": "Overall:",
//																								"CN": "综合评分:"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2ODHF9I2",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK98",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK99",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQQ31",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQQ32",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2ODHF9I3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2ODHF9I4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2ODGH3C0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2ODHF9I5",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtScoreOverall",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": "8.9",
//																						"font": "",
//																						"fontSize": "#txtSize.midPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2ODHF9I6",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK108",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK109",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQQ37",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQQ38",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2ODHF9I7",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2ODHF9I8",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2ODHF9I9",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK118",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK119",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7J46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7J47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQQ43",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQQ44",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2ODHF9I10",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2ODHF9I11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J2TJLTJ40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2TJOC9M0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"secondary\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Scoring models is difficult to be completely objective, the results are for reference only.",
//																			"localize": {
//																				"EN": "Scoring models is difficult to be completely objective, the results are for reference only.",
//																				"CN": "对模型的评分系统很难做到完全客观，结果仅供参考。"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2TJOC9M1",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK128",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK129",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7J52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7J53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR31",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQQ49",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQQ50",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2TJOC9M2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2TJOC9M3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2ODMGJM5",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGK138",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGK139",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7J58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7J59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQQ113",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQQ114",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2ODMGJM6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2ODMGJM7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2VDC4VB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2VDC4VB1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtDeploy",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": {
//															"type": "string",
//															"valText": "Deployment:",
//															"localize": {
//																"EN": "Deployment:",
//																"CN": "部署项目:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2VDC4VC0",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGK148",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGK149",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7J64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7J65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2VDC4VC1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2VDC4VC2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2VDDN070",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2VDEMC00",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxDeploy",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,20,0]",
//														"padding": "[10,30,10,36]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2VDEU960",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2VDK7AU0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineMacOS",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "60%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "280",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDGDRE0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDK7AU1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "30",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/macos.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDK7AU2",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK158",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK159",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR66",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR67",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDK7AU3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDK7AU4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDHRA50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDK7AV0",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Mac OS:",
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDK7AV1",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK168",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK169",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J76",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J77",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDK7AV2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDK7AV3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDOPVK0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDQONM0",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtDeployMacOS",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": "NA",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDQONN0",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK178",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK179",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J82",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J83",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR74",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR75",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDQONN1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDQONN2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDURMI0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDVOLP0",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "100%",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDVOLP1",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK188",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK189",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J88",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J89",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR78",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR79",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDVOLP2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDVOLP3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2VDK7AV4",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK198",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK199",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7J94",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7J95",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2VDK7AV5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2VDK7AV6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2VDNAS80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2VDNAS81",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineLinux",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "60%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "280",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDNAS82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDNAS83",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "30",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/linux.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDNAS90",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK208",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK209",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7J100",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7J101",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR86",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR87",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDNAS91",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDNAS92",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDNAS93",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDNAS94",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Ubentu / Linux:",
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDNAS95",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK218",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK219",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR90",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR91",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR45",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDNAS96",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDNAS97",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDR6Q60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDR6Q61",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtDeployLinux",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": "NA",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDR6Q62",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK228",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK229",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR94",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR95",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR51",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDR6Q63",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDR6Q64",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDVSBF0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDVSBF1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "100%",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDVSBG0",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK238",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK239",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR98",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR99",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDVSBG1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDVSBG2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2VDNAS98",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGK248",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGK249",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR102",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR103",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR62",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR63",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2VDNAS99",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2VDNAS910",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1J2VDK85H0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J2VDK85H1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "LineWin32",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "60%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "0",
//																		"padding": "",
//																		"minW": "280",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDK85I0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDK85I1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "30",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/win32.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDK85I2",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK258",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK259",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR106",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR107",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR68",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR69",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDK85I3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDK85I4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDK85I5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDK85I6",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Windows:",
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDK85J0",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGK268",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGK269",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR110",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR111",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR74",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR75",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDK85J1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDK85J2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J2VDQQ1F0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDQQ1F1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtDeployWin32",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": "NA",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDQQ1G0",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGL5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGL6",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR114",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR115",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR81",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDQQ1G1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDQQ1G2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1J2VDVQTU0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J2VDVQTU1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "100%",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J2VDVQTU2",
//																					"attrs": {
//																						"1J439QNNB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J43A5RGL15",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J43A5RGL16",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QNNB0",
//																							"faceTagName": "update"
//																						},
//																						"1J439R14U0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBTUMF7K46",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBTUMF7K47",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439R14U0",
//																							"faceTagName": "open"
//																						},
//																						"1J439QINP0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBU9HJFR118",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBU9HJFR119",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QINP0",
//																							"faceTagName": "install"
//																						},
//																						"1J439QDH40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JBUBGPQR86",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JBUBGPQR87",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J439QDH40",
//																							"faceTagName": "deploy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J2VDVQTU3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J2VDVQTU4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J2VDK85J3",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL25",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL26",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR92",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR93",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2VDK85J4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2VDK85J5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2VDEMC01",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL35",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL36",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR126",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR127",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR98",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR99",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2VDEMC02",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2VDEMC03",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2U2Q70R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2Q70R1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": {
//															"type": "string",
//															"valText": "Model address links:",
//															"localize": {
//																"EN": "Model address links:",
//																"CN": "项目网址:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2U2Q70S0",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL45",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL46",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFR130",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFR131",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR104",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR105",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U2Q70S1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U2Q70S2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2U2S3CT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2U2TNGE0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxLinks",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,20,0]",
//														"padding": "[0,20,0,20]",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1J2U2D1IQ0",
//															"jaxId": "1J2U2UDQP0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2U2V74T0",
//																	"attrs": {
//																		"title": "Homepage"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2U2V74T1",
//																	"attrs": {
//																		"type": "#null#>BtnLink(\"Homepage\")",
//																		"id": "LnkHomepage",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2U2V74T2",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL55",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL56",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K71",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR134",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR135",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR110",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR111",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2U2V74T3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2U2V74T4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J2U2V74T5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2U2D1IQ0",
//															"jaxId": "1J2U2U5BB0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2U2V74T6",
//																	"attrs": {
//																		"title": "GitHub Project"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2U2V74T7",
//																	"attrs": {
//																		"type": "#null#>BtnLink(\"GitHub Project\")",
//																		"id": "LnkGitHub",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2U2V74T8",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL65",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL66",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFR138",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFR139",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR116",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR117",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2U2V74T9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2U2V74T10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J2U2V74T11",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2U2D1IQ0",
//															"jaxId": "1J2U2UMRO0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2U2V74T12",
//																	"attrs": {
//																		"title": "Huggingface Model"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2U2V74T13",
//																	"attrs": {
//																		"type": "#null#>BtnLink(\"Huggingface Model\")",
//																		"id": "LnkHuggingFace",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2U2V74T14",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL75",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL76",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFS0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFS1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2U2V74T15",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2U2V74T16",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J2U2V74T17",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2U2TNGE1",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL85",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL86",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K89",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFS4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFS5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR128",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR129",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2U2TNGE2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2U2TNGE3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OIL8MP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OIL8MP1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtMedia",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": {
//															"type": "string",
//															"valText": "Media reviews:",
//															"localize": {
//																"EN": "Media reviews:",
//																"CN": "媒体文章:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OIL8MQ0",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL95",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL96",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K94",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K95",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFS8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFS9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR134",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR135",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OIL8MQ1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OIL8MQ2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J2ODQ0670",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2ODQIPM0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMedia",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,10,10]",
//														"minW": "",
//														"minH": "100",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1J2U0851Q0",
//															"jaxId": "1J2U1BVIQ0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2U1EU7N0",
//																	"attrs": {
//																		"article": {
//																			"jaxId": "1J2U1EU7N1",
//																			"attrs": {
//																				"site": "www.google.com",
//																				"title": "Hands on: AI2Apps",
//																				"icon": "",
//																				"brief": "FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"
//																			}
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2U1EU7N2",
//																	"attrs": {
//																		"type": "#null#>BtnArticle({\"site\":\"www.google.com\",\"title\":\"Hands on: AI2Apps\",\"icon\":\"\",\"brief\":\"FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。\"})",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2U1EU7N3",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL105",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL106",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K100",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K101",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFS12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFS13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR140",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR141",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2U1EU7N4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2U1EU7N5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2U1EU7N6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1J2U0851Q0",
//															"jaxId": "1J2U1CEO40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J2U1EU7N7",
//																	"attrs": {
//																		"article": {
//																			"jaxId": "1J2U1EU7N8",
//																			"attrs": {
//																				"site": "www.yahoo.com",
//																				"title": "ChatGPT 5 Review",
//																				"icon": "",
//																				"brief": "FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。"
//																			}
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J2U1EU7N9",
//																	"attrs": {
//																		"type": "#null#>BtnArticle({\"site\":\"www.yahoo.com\",\"title\":\"ChatGPT 5 Review\",\"icon\":\"\",\"brief\":\"FLUX.1 是 Black Forest Labs 推出的新一代文本生成图像模型，结合 Transformer 与扩散架构，生成质量接近 Midjourney 与 DALL·E 3，并支持快速、开源与专业多种版本。\"})",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J2U1EU7N10",
//																	"attrs": {
//																		"1J439QNNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J43A5RGL115",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J43A5RGL116",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QNNB0",
//																			"faceTagName": "update"
//																		},
//																		"1J439R14U0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBTUMF7K106",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBTUMF7K107",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439R14U0",
//																			"faceTagName": "open"
//																		},
//																		"1J439QINP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBU9HJFS16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBU9HJFS17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QINP0",
//																			"faceTagName": "install"
//																		},
//																		"1J439QDH40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JBUBGPQR146",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JBUBGPQR147",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J439QDH40",
//																			"faceTagName": "deploy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J2U1EU7N11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J2U1EU7N12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1J2U1EU7N13",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J2ODQIPM1",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL125",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL126",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K112",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K113",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFS20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFS21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR152",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR153",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2ODQIPM2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2ODQIPM3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1J2OIMG640",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OIMG641",
//													"attrs": {
//														"type": "text",
//														"id": "TxtReadme",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"secondary\"]",
//														"text": {
//															"type": "string",
//															"valText": "Readme:",
//															"localize": {
//																"EN": "Readme:",
//																"CN": "项目说明:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OIMG660",
//													"attrs": {
//														"1J439QNNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J43A5RGL135",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J43A5RGL136",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QNNB0",
//															"faceTagName": "update"
//														},
//														"1J439R14U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBTUMF7K118",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBTUMF7K119",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439R14U0",
//															"faceTagName": "open"
//														},
//														"1J439QINP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBU9HJFS24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBU9HJFS25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QINP0",
//															"faceTagName": "install"
//														},
//														"1J439QDH40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JBUBGPQR158",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JBUBGPQR159",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J439QDH40",
//															"faceTagName": "deploy"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J2OIMG661",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OIMG662",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2TUK5PD1",
//									"attrs": {
//										"1J439QNNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J43A5RGL145",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J43A5RGL146",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J439QNNB0",
//											"faceTagName": "update"
//										},
//										"1J439R14U0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JBTUMF7K124",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JBTUMF7K125",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J439R14U0",
//											"faceTagName": "open"
//										},
//										"1J439QINP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JBU9HJFS28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JBU9HJFS29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J439QINP0",
//											"faceTagName": "install"
//										},
//										"1J439QDH40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JBUBGPQR164",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JBUBGPQR165",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J439QDH40",
//											"faceTagName": "deploy"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2TUK5PD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2TUK5PD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2OD445V11",
//					"attrs": {
//						"1J439QNNB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J43A5RGL155",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J43A5RGL156",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J439QNNB0",
//							"faceTagName": "update"
//						},
//						"1J439R14U0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JBTUMF7L1",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JBTUMF7L2",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J439R14U0",
//							"faceTagName": "open"
//						},
//						"1J439QINP0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JBU9HJFS36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JBU9HJFS37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J439QINP0",
//							"faceTagName": "install"
//						},
//						"1J439QDH40": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JBUBGPQS10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JBUBGPQS11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J439QDH40",
//							"faceTagName": "deploy"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2OD445V12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2OD445V13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2OD445V14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}