//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxModelCard} from "./BoxModelCard.js";
/*#{1J2NAC36L0StartDoc*/
/*}#1J2NAC36L0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnModelCard=function(model){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1J2NAC36L1LocalVals*/
	/*}#1J2NAC36L1LocalVals*/
	
	/*#{1J2NAC36L1PreState*/
	/*}#1J2NAC36L1PreState*/
	/*#{1J2NAC36L1PostState*/
	/*}#1J2NAC36L1PostState*/
	cssVO={
		"hash":"1J2NAC36L1",nameHost:true,
		"type":"button","position":"relative","x":180,"y":100,"w":360,"h":200,"anchorX":1,"anchorY":1,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1J2NAE2LG0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":1,"corner":12,
			},
			{
				"hash":"1J2OCP5V70",
				"type":BoxModelCard(model,{"scores":true,"autoHeight":false,"fontSize":txtSize.smallPlus}),"position":"relative","x":0,"y":0,"uiEvent":-1,
			}
		],
		/*#{1J2NAC36L1ExtraCSS*/
		/*}#1J2NAC36L1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"scale":1
				},
				/*BoxBG*/"#1J2NAE2LG0":{
					"background":cfgColor["body"],"border":1
				}
			},"over":{
				"#self":{
					"scale":1
				},
				/*BoxBG*/"#1J2NAE2LG0":{
					"border":3
				}
			},"down":{
				"#self":{
					"scale":0.98
				},
				/*BoxBG*/"#1J2NAE2LG0":{
					"border":3,"background":cfgColor["itemOver"]
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1J2NAC36L1Create*/
			/*}#1J2NAC36L1Create*/
		},
		/*#{1J2NAC36L1EndCSS*/
		/*}#1J2NAC36L1EndCSS*/
	};
	/*#{1J2NAC36L1PostCSSVO*/
	/*}#1J2NAC36L1PostCSSVO*/
	cssVO.constructor=BtnModelCard;
	return cssVO;
};
/*#{1J2NAC36L1ExCodes*/
/*}#1J2NAC36L1ExCodes*/

//----------------------------------------------------------------------------
BtnModelCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2NAC36L1PreAISpot*/
	/*}#1J2NAC36L1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2NAC36L1PostAISpot*/
	/*}#1J2NAC36L1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnModelCard.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"model": {"name":"model","showName":"model","type":"auto","key":true,"fixed":true}
	},
	state:{
	},
	properties:["id","position","x","y","display","margin"],
	faces:["up","over","down"],
	subContainers:{
	},
	/*#{1J2NAC36L0ExGearInfo*/
	/*}#1J2NAC36L0ExGearInfo*/
};
/*#{1J2NAC36L0EndDoc*/
/*}#1J2NAC36L0EndDoc*/

export default BtnModelCard;
export{BtnModelCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1J2NAC36L0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2NAC36L2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2NAC36L3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2NAC36L4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2NAC36L5",
//			"attrs": {
//				"model": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1J2NAC36L6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2NAC36L7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2NAC36L8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2NADI080",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2NAJ1HN0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2NADN790",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2NAJ1HN1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J2NADQO20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J2NAJ1HN2",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1J2NAC36L9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1J2NAC36L1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2NAC36L10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "180",
//						"y": "100",
//						"w": "360",
//						"h": "200",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1J2NAE2LG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2NAJ1HN3",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "12",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2NAJ1HN4",
//									"attrs": {
//										"1J2NADI080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2NDSEEI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2NDSEEI1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2NADI080",
//											"faceTagName": "up"
//										},
//										"1J2NADN790": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2NDSEEI2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2NDSEEI3",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "3",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2NADN790",
//											"faceTagName": "over"
//										},
//										"1J2NADQO20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2NDSEEI4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2NDSEEI5",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "3",
//															"editMode": "edges"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2NADQO20",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2NAJ1HN5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2NAJ1HN6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1J2OAIJ350",
//							"jaxId": "1J2OCP5V70",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1J2OCPD8V0",
//									"attrs": {
//										"model": "#model",
//										"opts": {
//											"jaxId": "1J2OCPD8V1",
//											"attrs": {
//												"scores": "true",
//												"autoHeight": "false",
//												"fontSize": "#txtSize.smallPlus"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1J2OCPD8V2",
//									"attrs": {
//										"type": "#null#>BoxModelCard(model,{\"scores\":true,\"autoHeight\":false,\"fontSize\":txtSize.smallPlus})",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"uiEvent": "Tree Off"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2OCPD8V3",
//									"attrs": {
//										"1J2NADN790": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2OCSJMD2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OCSJMD3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2NADN790",
//											"faceTagName": "over"
//										},
//										"1J2NADQO20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J2OCSJMD4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OCSJMD5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J2NADQO20",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J2OCPD8V4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OCPD8V5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1J2OCPD8V6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2NAC36L11",
//					"attrs": {
//						"1J2NADI080": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2NDSEEK31",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2NDSEEK32",
//									"attrs": {
//										"scale": {
//											"type": "auto",
//											"valText": "1"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2NADI080",
//							"faceTagName": "up"
//						},
//						"1J2NADN790": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2NDSEEK33",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2NDSEEK34",
//									"attrs": {
//										"scale": {
//											"type": "auto",
//											"valText": "1"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2NADN790",
//							"faceTagName": "over"
//						},
//						"1J2NADQO20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J2NE3ESC40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2NE3ESC41",
//									"attrs": {
//										"scale": {
//											"type": "auto",
//											"valText": "0.98"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J2NADQO20",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1J2NAC36L12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2NAC36L13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2NAC36L14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}