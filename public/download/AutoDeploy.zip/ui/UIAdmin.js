//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1J2OUG1LD0StartDoc*/
import {AfModel} from "../data/AfModel.js";
import {tabNT} from "/@tabos";
/*}#1J2OUG1LD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIAdmin=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edFind,btnRemove,btnUpdate,dvModel,boxModels;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1J2OUG1LD1LocalVals*/
	const app=VFACT.app;
	/*}#1J2OUG1LD1LocalVals*/
	
	/*#{1J2OUG1LD1PreState*/
	function formatDate(ts = Date.now()) {
		const d = new Date(ts);
		const y = d.getFullYear();
		const m = String(d.getMonth() + 1).padStart(2, "0"); // 月份从0开始
		const day = String(d.getDate()).padStart(2, "0");
		return `${y}-${m}-${day}`;
	}	
	/*}#1J2OUG1LD1PreState*/
	/*#{1J2OUG1LD1PostState*/
	/*}#1J2OUG1LD1PostState*/
	cssVO={
		"hash":"1J2OUG1LD1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1J2OULG7L0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":40,"padding":[0,0,0,10],"styleClass":"","background":cfgColor["body"],"border":[0,0,1,0],
				"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1J2P10SFM0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnNewModel","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
						"OnClick":function(event){
							self.newModel(this,event);
						},
					},
					{
						"hash":"1J2OUNG8P0",
						"type":"edit","id":"EdFind","position":"relative","x":0,"y":0,"w":300,"h":24,"styleClass":"","placeHolder":"Model Id / URL","color":[0,0,0],"outline":0,
						"border":[0,0,1,0],
					},
					{
						"hash":"1J2OUPPJL0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/find.svg",null),"id":"BtnFind","position":"relative","x":0,"y":0,"margin":[0,20,0,0],
						"OnClick":function(event){
							self.findModel(this,event);
						},
					},
					{
						"hash":"1J2P0BCAG0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","position":"relative","x":0,"y":0,"enable":false,
						"OnClick":function(event){
							self.deleteModel(this,event);
						},
					},
					{
						"hash":"1J2P06UKQ0",
						"type":BtnText("primary",100,24,"Submit",false,""),"id":"BtnUpdate","position":"relative","x":0,"y":0,"margin":[0,5,0,10],"enable":false,
						"OnClick":function(event){
							self.updateModel(this,event);
						},
					}
				],
			},
			{
				"hash":"1J2OVV6500",
				"type":DataView(null,"1J2JN2H2P0",null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":5,"labelSize":14,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},"Model Properties:"),
				"id":"DvModel","position":"relative","x":15,"y":0,"display":0,"h":"","w":">calc(100% - 30px)",
			},
			{
				"hash":"1J2R426RU0",
				"type":"hud","id":"BoxModels","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 40px)","display":0,"overflow":"auto-y","styleClass":"",
				"contentLayout":"flex-x","itemsWrap":1,
			}
		],
		/*#{1J2OUG1LD1ExtraCSS*/
		/*}#1J2OUG1LD1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			edFind=self.EdFind;btnRemove=self.BtnRemove;btnUpdate=self.BtnUpdate;dvModel=self.DvModel;boxModels=self.BoxModels;
			/*#{1J2OUG1LD1Create*/
			/*}#1J2OUG1LD1Create*/
		},
		/*#{1J2OUG1LD1EndCSS*/
		/*}#1J2OUG1LD1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.newModel=async function(){
		/*#{1J2PVINT40Start*/
		await dvModel.setObject(AfModel,null);
		dvModel.display=true;
		btnUpdate.enable=true;//TODO: fix this
		btnRemove.enable=false;//TODO: fix this
		/*}#1J2PVINT40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateModel=async function(){
		/*#{1J2Q0BGLH0Start*/
		let modelInfo,res;
		modelInfo=dvModel.getEditedVO();
		if(!modelInfo){
			return null;
		}
		await tabNT.checkLogin();
		res=await tabNT.makeCall("AfPublishModel",{model:modelInfo});
		if(res && res.code===200){
			window.alert(`Publis/update model finished.`);
		}else{
			window.alert(`Publish/update model failed ${res?(" "+res.code):""}${res?(": "+res.info):""}.`);
		}
		/*}#1J2Q0BGLH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.findModel=async function(){
		/*#{1J2R2ACFB0Start*/
		let res,find,modelInfo;
		find=edFind.text;
		if(!find){
			edFind.focus();
			app.showTip(edFind,"Input your find first.");
			return;
		}
		await tabNT.checkLogin();
		res=await tabNT.makeCall("AfAdminFindModel",{find:find});
		if(!res || res.code!==200){
			window.alert(`FindModel failed ${res?(" "+res.code):""}${res?(": "+res.info):""}.`);
			dvModel.display=false;
			boxModels.display=false;
			btnUpdate.enable=false;//TODO: fix this
			btnRemove.enable=false;//TODO: fix this
			return;
		}
		modelInfo=res.model;
		if(modelInfo){
			modelInfo.id=modelInfo._id;
			modelInfo.publishTime=formatDate(modelInfo.publishTime||Date.now());
			modelInfo.updateTime=formatDate(modelInfo.updateTime||Date.now());
			await dvModel.setObject(AfModel,modelInfo);
			dvModel.display=true;
			boxModels.display=false;
			btnUpdate.enable=true;//TODO: fix this
			btnRemove.enable=true;//TODO: fix this
		}else if(res.models){
			//TODO: list find models:
		}else{
			window.alert(`Can't find model.`);
			dvModel.display=false;
			boxModels.display=false;
			btnUpdate.enable=false;//TODO: fix this
			btnRemove.enable=false;//TODO: fix this
		}
		/*}#1J2R2ACFB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModels=async function(models){
		/*#{1J2R40I4J0Start*/
		dvModel.display=false;
		boxModels.display=true;
		btnUpdate.enable=false;//TODO: fix this
		btnRemove.enable=false;//TODO: fix this
		//TODO: List models:
		/*}#1J2R40I4J0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.deleteModel=async function(){
		/*#{1J2R4P6450Start*/
		let modelInfo,res;
		modelInfo=dvModel.getEditedVO();
		if(!modelInfo){
			return null;
		}
		if(!window.confirm("确定删除模型么？")){
			return;
		}
		await tabNT.checkLogin();
		res=await tabNT.makeCall("AfAdminRemoveModel",{id:modelInfo.id});
		if(res && res.code===200){
			window.alert(`Remove model finished.`);
			dvModel.display=false;
			boxModels.display=false;
			btnUpdate.enable=false;//TODO: fix this
			btnRemove.enable=false;//TODO: fix this
		}else{
			window.alert(`Remove model failed ${res?(" "+res.code):""}${res?(": "+res.info):""}.`);
		}
		/*}#1J2R4P6450Start*/
	};
	/*#{1J2OUG1LD1PostCSSVO*/
	/*}#1J2OUG1LD1PostCSSVO*/
	cssVO.constructor=UIAdmin;
	return cssVO;
};
/*#{1J2OUG1LD1ExCodes*/
/*}#1J2OUG1LD1ExCodes*/

//----------------------------------------------------------------------------
UIAdmin.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1J2OUG1LD1PreAISpot*/
	/*}#1J2OUG1LD1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1J2OUG1LD1PostAISpot*/
	/*}#1J2OUG1LD1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
UIAdmin.gearExport={
	framework: "jax",
	hudType: "view",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1J2OUG1LD0ExGearInfo*/
	/*}#1J2OUG1LD0ExGearInfo*/
};
/*#{1J2OUG1LD0EndDoc*/
/*}#1J2OUG1LD0EndDoc*/

export default UIAdmin;
export{UIAdmin};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1J2OUG1LD0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1J2OUG1LD2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1J2OUG1LD3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1J2OUG1LD4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1J2OUG1LD5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1J2OUG1LD6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1J2OUG1LD7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2PVINT40",
//					"attrs": {
//						"id": "newModel",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2PVIUV90",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2PVIUV91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2PVIUV92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2Q0BGLH0",
//					"attrs": {
//						"id": "updateModel",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "230",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2Q0BO9P0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2Q0BO9P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2Q0BO9P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2R2ACFB0",
//					"attrs": {
//						"id": "findModel",
//						"label": "New AI Seg",
//						"x": "295",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2R2AKCN0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2R2AKCN1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2R2AKCN2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2R40I4J0",
//					"attrs": {
//						"id": "showModels",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "140",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2R419500",
//							"attrs": {
//								"models": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2R419501",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2R419502",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J2R4P6450",
//					"attrs": {
//						"id": "deleteModel",
//						"label": "New AI Seg",
//						"x": "295",
//						"y": "230",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J2R4PEN00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J2R4PEN01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J2R4PEN02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1J2OUG1LD8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1J2OUG1LD9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1J2OUG1LD1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1J2OUG1LD10",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Auto Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"flex": "false",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1J2OULG7L0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2OULTJN0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1J2P10SFM0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2P10SFM1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1J2P10SFM2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//														"id": "BtnNewModel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,10,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2P10SFM3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2P10SFM4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2PVPE880",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2PVPE881",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2PVINT40"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2P10SFM5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1J2P10SFM6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1J2OUNG8P0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J2OVRO4E0",
//													"attrs": {
//														"type": "edit",
//														"id": "EdFind",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "300",
//														"h": "24",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "Model Id / URL",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OVRO4E1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2OVRO4E2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OVRO4E3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1J2OUPPJL0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2OVRO4E4",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1J2OVRO4E5",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/find.svg\",null)",
//														"id": "BtnFind",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,20,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2OVRO4E6",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2OVRO4E7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2R30DA50",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2R30DA51",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2R2ACFB0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2OVRO4E8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1J2OVRO4E9",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1J2P0BCAG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2P0BCAG1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1J2P0BCAG2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//														"id": "BtnRemove",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2P0BCAG3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2P0BCAG4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2R4V8LF0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2R4V8LF1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2R4P6450"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2P0BCAG5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2P0BCAG6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1J2P06UKQ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J2P07S4M0",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": "Submit",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1J2P07S4M1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,\"Submit\",false,\"\")",
//														"id": "BtnUpdate",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,10]",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J2P07S4M2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1J2P07S4M3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J2Q0BUJP0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J2Q0C1PB0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J2Q0BGLH0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J2P07S4M4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J2P07S4M5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1J2P07S4M6",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J2OULTJN1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1J2OULTJN2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OULTJN3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/DataView.js",
//							"jaxId": "1J2OVV6500",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1J2OVVHTI0",
//									"attrs": {
//										"box": "null",
//										"template": "\"1J2JN2H2P0\"",
//										"dataObj": "null",
//										"property": "",
//										"options": {
//											"jaxId": "1J2OVVHTI1",
//											"attrs": {
//												"titleHeight": "30",
//												"titleSize": "18",
//												"titleColor": "#cfgColor[\"fontBody\"]",
//												"titleBold": "true",
//												"lineHeight": "30",
//												"lineGap": "5",
//												"labelSize": "14",
//												"labelColor": "#cfgColor[\"fontBody\"]",
//												"labelBold": "true",
//												"labelLine": "false",
//												"valueSize": "14",
//												"valueColor": "#cfgColor[\"fontBody\"]",
//												"valueBold": "false",
//												"segHeight": "20",
//												"segSize": "14",
//												"segBold": "true",
//												"segColor": "#cfgColor[\"fontBody\"]",
//												"trace": "false",
//												"edit": "true",
//												"noteSize": "12",
//												"autoCollapse": "false",
//												"hideCollapse": "false",
//												"valueRightAlign": "false",
//												"gridLine": "false"
//											}
//										},
//										"title": "Model Properties:"
//									}
//								},
//								"properties": {
//									"jaxId": "1J2OVVHTI2",
//									"attrs": {
//										"type": "#null#>DataView(null,\"1J2JN2H2P0\",null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":5,\"labelSize\":14,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"Model Properties:\")",
//										"id": "DvModel",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"display": "Off",
//										"face": "",
//										"h": "",
//										"w": "100%-30"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2OVVHTI3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1J2OVVHTI4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2OVVHTI5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1J2OVVHTI6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J2R426RU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J2R44KR70",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxModels",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%-40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Start",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J2R44KR71",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1J2R44KR72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J2R44KR73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1J2OUG1LD11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1J2OUG1LD12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1J2OUG1LD13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1J2OUG1LD14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}