//Auto genterated by Cody
import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
/*#{MoreImports*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {MainUI} from "./ui/MainUI.js";
import {DlgTask} from "/@homekit/ui/DlgTask.js";
/*}#MoreImports*/
VFACT.appCfg=appCfg;
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	
	document.title="Tab-OS App";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);
	
	uiDef=MainUI(app,appFrame);
	if(!appFrame){
		//uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		DlgTask:DlgTask,
		appFrame:appFrame,
	});
	/*}#AppCode*/
}
tabOS.setup().then(()=>{startApp();});

// ModelHunt SSE: listen for install triggers from external tools (e.g. Claude Code)
(function setupModelHuntSSE() {
	const es = new EventSource('/api/modelhunt/events');
	es.onmessage = async (e) => {
		let vo;
		try { vo = JSON.parse(e.data); } catch { return; }
		if ((vo.type !== 'install' && vo.type !== 'delete' && vo.type !== 'test') || !vo.model) return;
		if (vo.type === 'test' && !vo.task) return;
		// Store on top window so sibling RunAgent frames can access it
		(window.top || window).__modelhunt_task_id = vo.taskId;
		//ModelUseAgentTest.js
		const agentPath =
			vo.type === 'delete'
			? "/~/-AutoDeploy/ai/DeleteModelAgent.js"
			: vo.type === 'test'
			  ? "/~/-AutoDeploy/ai/ModelUseAgentTest.js"
			  : "/~/-AutoDeploy/ai/ModelHunt.js";
		const callAgentPath =
		  	vo.type === 'delete'
			? "/-AutoDeploy/ai/DeleteModelAgent.js"
			: vo.type === 'test'
			  ? "/-AutoDeploy/ai/ModelUseAgentTest.js"
			  : "/-AutoDeploy/ai/ModelHunt.js";
		const ln = window.$ln || "EN";
		const agentTitle = vo.type === 'delete'
			? (ln === "CN" ? "删除模型" : "Deleting model")
			: vo.model;
		const args =
		  	vo.type === 'test'
			? { model: vo.model, task: vo.task }
			: { model: vo.model };
		if (window.appFrame && window.appFrame.runTool && vo.type !== "delete") {
			window.appFrame.runTool(agentPath, {...args, _chatTitle: agentTitle});
		} else {
			const { callAgent } = await import('/@AgentBuilder/ai/RunAgent.js');
			if (callAgent) {
				callAgent({
					// For callAgent, we need the path without /~/ prefix
					agent: callAgentPath,
					args: args,
					title: agentTitle,
					keepOpen: true
				});
			}
		}
	};
	es.onerror = () => {
		// SSE will auto-reconnect; no action needed
	};
})();
/*#{EndDoc*/
/*}#EndDoc*/

/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "app",
//	"jaxId": "1GGJKJ38Q0",
//	"editVersion": 52,
//	"attrs": {
//		"fonts": {
//			"type": "object",
//			"def": "Fonts",
//			"jaxId": "1GGJKJ38Q1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "VFACT document",
//		"localize": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				"EN",
//				{
//					"type": "string",
//					"valText": "CN"
//				}
//			]
//		},
//		"language": "EN",
//		"useTabOS": "true",
//		"title": "Tab-OS App",
//		"bgColor": "[255,255,255]",
//		"icon": "",
//		"fullScreen": "false",
//		"multiTouch": "false",
//		"location": "false",
//		"camera": "false",
//		"photo": "false",
//		"notification": "false",
//		"contacts": "false",
//		"payment": "false"
//	}
//}