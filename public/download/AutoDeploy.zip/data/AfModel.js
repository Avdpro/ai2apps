//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1J2JN2H2O0StartDoc*/
/*}#1J2JN2H2O0StartDoc*/
let AfModel={
	name:"AfModel",//1J2JN2H2P0
	type:"object",
	label:undefined,
	properties:{
		id:{
			name:"id",type:"string",
			desc:"模型项目的唯一ID",
		},
		name:{
			name:"name",type:"string",
			desc:"模型的名称，支持通过对象表达多语言。例如: {\"CN\":\"千问2.5\"，\"EN\":\"QWen2.5\"}。",
		},
		brief:{
			name:"brief",type:"string",
			desc:"显示在卡片上的短说明，用对象实现多语言。",
		},
		size:{
			name:"size",type:"number",
			desc:"模型尺寸，以B为单位",
		},
		readme:{
			name:"readme",type:"string",
			desc:"模型说明的MD文本，通过对象支持多语言。例如: {\"CN\":\"千问2.5是一个...\"，\"EN\":\"QWen2.5 is a ....\"}。",
		},
		articles:{
			name:"articles",type:"array",
			initLength:0,
			element:{
				"type":"object","label":'###:',"class":"1J2TUVPAT0"
			},
			desc:"有关这个项目的第三方评测文章链接列表。",
		},
		pictures:{
			name:"pictures",type:"array",
			initLength:0,
			element:{
				"type":"auto","label":'###:'
			},
			desc:"图片URL列表。支持DataURL",
		},
		videos:{
			name:"videos",type:"array",
			initLength:0,
			element:{
				"type":"auto","label":'###:'
			},
			desc:"视频URL列表。",
		},
		urlGitHub:{
			name:"urlGitHub",type:"string",
			desc:"项目的GitHub地址",
		},
		urlHuggingFace:{
			name:"urlHuggingFace",type:"string",
			desc:"项目的HuggingFace地址",
		},
		urlHomepage:{
			name:"urlHomepage",type:"string",
			desc:"项目主页地址",
		},
		catalogs:{
			name:"catalogs",type:"array",
			initLength:0,
			element:{
				"type":"auto","label":'###:'
			},
			desc:"项目所属分类，支持多个",
		},
		capabilities:{
			name:"capabilities",type:"array",
			initLength:0,
			element:{
				"type":"auto","label":'###:'
			},
			desc:"项目的能力标签列表",
		},
		updateTime:{
			name:"updateTime",type:"auto",
			desc:"项目最近一次更新时间",
		},
		publishTime:{
			name:"publishTime",type:"auto",
			desc:"项目发布时间",
		},
		openSource:{
			name:"openSource",type:"bool",
			desc:"项目的开源类型",
		},
		scoreOverall:{
			name:"scoreOverall",type:"auto",
			desc:"综合评分",
		},
		scoreSize:{
			name:"scoreSize",type:"auto",
			desc:"对于尺寸的评分",
		},
		scoreTiming:{
			name:"scoreTiming",type:"auto",
			desc:"新鲜度分数",
		},
		scoreDeployment:{
			name:"scoreDeployment",type:"auto",
			desc:"部署难度评分",
		},
		scorePopularity:{
			name:"scorePopularity",type:"auto",
			desc:"流行程度评分",
		},
		scoreCapability:{
			name:"scoreCapability",type:"auto",
			desc:"能力评分，通常8分代表达到普通人相关能力水平。",
		},
		scoreObjective:{
			name:"scoreObjective",type:"auto",
			desc:"主观加权评分",
		},
		application:{
			name:"application",type:"string",
			desc:"在AA里对应的Agent Mart（Application）Id。",
		},
		deploy:{
			name:"deploy",type:"object",
			class:"1J2QUCP630",
			desc:"在不同平台的部署能力。",
		},
		downloads:{
			name:"downloads",type:"int",
			defaultValue:0,
			desc:"模型的下载/安装数量",
		},
		/*#{1J2JN2H2P0MoreProperties*/
		/*}#1J2JN2H2P0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1J2JN2H2P0MoreFunctions*/
	/*}#1J2JN2H2P0MoreFunctions*/
};
VFACT.regUITemplate("1J2JN2H2P0",AfModel);
VFACT.regUITemplate("AfModel",AfModel);
/*#{1J2JN2H2P0MoreCodes*/
/*}#1J2JN2H2P0MoreCodes*/
let AfPlatforms={
	name:"AfPlatforms",//1J2QUCP630
	type:"object",
	label:undefined,
	properties:{
		windows:{
			name:"windows",type:"string",
			defaultValue:"NA",
			choices:[
				"NA","Deploy","Agent"
			],
		},
		mac:{
			name:"mac",type:"string",
			defaultValue:"NA",
			choices:[
				"NA","Deploy","Agent"
			],
		},
		linux:{
			name:"linux",type:"string",
			choices:[
				"NA","Deploy","Agent"
			],
		},
		/*#{1J2QUCP630MoreProperties*/
		/*}#1J2QUCP630MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1J2QUCP630MoreFunctions*/
	/*}#1J2QUCP630MoreFunctions*/
};
VFACT.regUITemplate("1J2QUCP630",AfPlatforms);
VFACT.regUITemplate("AfPlatforms",AfPlatforms);
/*#{1J2QUCP630MoreCodes*/
/*}#1J2QUCP630MoreCodes*/
let AfArticle={
	name:"AfArticle",//1J2TUVPAT0
	type:"object",
	label:undefined,
	properties:{
		title:{
			name:"title",type:"auto",
		},
		site:{
			name:"site",type:"auto",
		},
		icon:{
			name:"icon",type:"auto",
		},
		brief:{
			name:"brief",type:"auto",
		},
		url:{
			name:"url",type:"auto",
		},
		/*#{1J2TUVPAT0MoreProperties*/
		/*}#1J2TUVPAT0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1J2TUVPAT0MoreFunctions*/
	/*}#1J2TUVPAT0MoreFunctions*/
};
VFACT.regUITemplate("1J2TUVPAT0",AfArticle);
VFACT.regUITemplate("AfArticle",AfArticle);
/*#{1J2TUVPAT0MoreCodes*/
/*}#1J2TUVPAT0MoreCodes*/

/*#{1J2JN2H2O0EndDoc*/
/*}#1J2JN2H2O0EndDoc*/

export{AfModel,AfPlatforms,AfArticle};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1J2JN2H2O0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1J2JN2H2O1",
//			"attrs": {
//				"AfModel": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1J2JN2H2P0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1J2JN2H2P1",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1J2JN2H2P2",
//							"attrs": {
//								"id": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2E0",
//									"attrs": {
//										"type": "string",
//										"desc": "模型项目的唯一ID"
//									}
//								},
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2E1",
//									"attrs": {
//										"type": "string",
//										"desc": "模型的名称，支持通过对象表达多语言。例如: {\"CN\":\"千问2.5\"，\"EN\":\"QWen2.5\"}。"
//									}
//								},
//								"brief": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2NCO5EK0",
//									"attrs": {
//										"type": "string",
//										"desc": "显示在卡片上的短说明，用对象实现多语言。"
//									}
//								},
//								"size": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2SHCMT60",
//									"attrs": {
//										"type": "number",
//										"desc": "模型尺寸，以B为单位"
//									}
//								},
//								"readme": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2E2",
//									"attrs": {
//										"type": "string",
//										"desc": "模型说明的MD文本，通过对象支持多语言。例如: {\"CN\":\"千问2.5是一个...\"，\"EN\":\"QWen2.5 is a ....\"}。"
//									}
//								},
//								"articles": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1J2N3IA2E3",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1J2N3IA2E4",
//											"attrs": {
//												"type": "Object",
//												"label": "#'###:'",
//												"class": "\"1J2TUVPAT0\""
//											}
//										},
//										"initLength": "0",
//										"desc": "有关这个项目的第三方评测文章链接列表。"
//									}
//								},
//								"pictures": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1J2N3IA2E5",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1J2N3IA2E6",
//											"attrs": {
//												"type": "Auto",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "图片URL列表。支持DataURL"
//									}
//								},
//								"videos": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1J2N3IA2E7",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1J2N3IA2E8",
//											"attrs": {
//												"type": "Auto",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "视频URL列表。"
//									}
//								},
//								"urlGitHub": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F0",
//									"attrs": {
//										"type": "string",
//										"desc": "项目的GitHub地址"
//									}
//								},
//								"urlHuggingFace": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F1",
//									"attrs": {
//										"type": "string",
//										"desc": "项目的HuggingFace地址"
//									}
//								},
//								"urlHomepage": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F2",
//									"attrs": {
//										"type": "string",
//										"desc": "项目主页地址"
//									}
//								},
//								"catalogs": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1J2N3IA2F3",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1J2N3IA2F4",
//											"attrs": {
//												"type": "Auto",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "项目所属分类，支持多个"
//									}
//								},
//								"capabilities": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1J2N3IA2F5",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1J2N3IA2F6",
//											"attrs": {
//												"type": "Auto",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "项目的能力标签列表"
//									}
//								},
//								"updateTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F7",
//									"attrs": {
//										"type": "Auto",
//										"desc": "项目最近一次更新时间"
//									}
//								},
//								"publishTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F8",
//									"attrs": {
//										"type": "Auto",
//										"desc": "项目发布时间"
//									}
//								},
//								"openSource": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F9",
//									"attrs": {
//										"type": "bool",
//										"desc": "项目的开源类型"
//									}
//								},
//								"scoreOverall": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F10",
//									"attrs": {
//										"type": "auto",
//										"desc": "综合评分"
//									}
//								},
//								"scoreSize": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F11",
//									"attrs": {
//										"type": "auto",
//										"desc": "对于尺寸的评分"
//									}
//								},
//								"scoreTiming": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F15",
//									"attrs": {
//										"type": "auto",
//										"desc": "新鲜度分数"
//									}
//								},
//								"scoreDeployment": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F12",
//									"attrs": {
//										"type": "auto",
//										"desc": "部署难度评分"
//									}
//								},
//								"scorePopularity": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F13",
//									"attrs": {
//										"type": "auto",
//										"desc": "流行程度评分"
//									}
//								},
//								"scoreCapability": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F14",
//									"attrs": {
//										"type": "auto",
//										"desc": "能力评分，通常8分代表达到普通人相关能力水平。"
//									}
//								},
//								"scoreObjective": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N3IA2F16",
//									"attrs": {
//										"type": "auto",
//										"desc": "主观加权评分"
//									}
//								},
//								"application": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2N4OINA0",
//									"attrs": {
//										"type": "string",
//										"desc": "在AA里对应的Agent Mart（Application）Id。"
//									}
//								},
//								"deploy": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1J2QUQHME0",
//									"attrs": {
//										"type": "object",
//										"class": "\"1J2QUCP630\"",
//										"desc": "在不同平台的部署能力。"
//									}
//								},
//								"downloads": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2R1V9F10",
//									"attrs": {
//										"type": "int",
//										"desc": "模型的下载/安装数量",
//										"defaultValue": "0"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1J2JN2H2P3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"AfPlatforms": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1J2QUCP630",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1J2QUD6HV0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1J2QUD6HV1",
//							"attrs": {
//								"windows": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2QUO1UE0",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "NA"
//												},
//												{
//													"type": "string",
//													"valText": "Deploy"
//												},
//												{
//													"type": "string",
//													"valText": "Agent"
//												}
//											]
//										},
//										"defaultValue": "NA"
//									}
//								},
//								"mac": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2QUO1UF0",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "NA",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "NA"
//												},
//												{
//													"type": "string",
//													"valText": "Deploy"
//												},
//												{
//													"type": "string",
//													"valText": "Agent"
//												}
//											]
//										}
//									}
//								},
//								"linux": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2QUO1UF1",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "NA"
//												},
//												{
//													"type": "string",
//													"valText": "Deploy"
//												},
//												{
//													"type": "string",
//													"valText": "Agent"
//												}
//											]
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1J2QUD6HV2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"AfArticle": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1J2TUVPAT0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1J2TV60LB0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1J2TV60LB1",
//							"attrs": {
//								"title": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2TV60LB2",
//									"attrs": {
//										"type": "auto"
//									}
//								},
//								"site": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2TV60LB3",
//									"attrs": {
//										"type": "auto"
//									}
//								},
//								"icon": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2TV60LB4",
//									"attrs": {
//										"type": "auto"
//									}
//								},
//								"brief": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2TV60LB5",
//									"attrs": {
//										"type": "auto"
//									}
//								},
//								"url": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1J2U02KIC0",
//									"attrs": {
//										"type": "auto"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1J2TV60LB6",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}