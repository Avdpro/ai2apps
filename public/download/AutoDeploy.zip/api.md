## API列表
### 1. AfGetModelList：获得模型列表：
- URL: www.ai2apps.com/ws
- Post:
    ```
	{
		msg:"AfGetModelList",
		vo:{
			userId?:"10001",		//可选
			token?:"xxx-xxx-xx",	//可选
			catalog:catalog,
			sort:"score",		//"time","score","deploy","capability"
			page:pageIndex,		//null for get all models
			platform:"mac",		//"mac","windows","linux"
			language:"CN"		//"CN"/"EN"
		}
	}
    ```
	
- Result:
    ```
	{
		code:200,
		models::[
			{
				"id": "SparkTTS",
				"name": "Spark TTS",
				"brief": "“Spark TTS” 是一个先进的基于大语言模型（LLM）的文本转语音（TTS）系统，由 SparkAudio 及相关研究团队开发，具有高效率、定制化和高自然度等特点",
				"size": 3,
				"updateTime": 1755216000000,
				"publishTime": 1741996800000,
				"deploy": {
					"windows": "NA",
					"mac": "Deploy",
					"linux": "NA"
				},
				"downloads": 120,
				"scoreOverall": 7,
				"scoreTiming": 5,
				"scoreCapability": 7,
				"scorePopularity": 7,
				"scoreDeployment": 9,
				"scoreSize": 6,
				"scoreObjective": 6,
				"readMe": null,
				"articles": [],
				"pictures": [],
				"videos": [],
				"urlGitHub": "https://www.github.com/Avdpro/ai2apps",
				"urlHuggingFace": "",
				"urlHomepage": "",
				"catalogs": ["Audio"],
				"capabilities": ["TTS","Train Voice"],
				"openSource": 1,
				"application": ""
			}
			//...
		]
	}
    ```

### 2. AfPublishModel
- URL: www.ai2apps.com/ws
- Post:
    ```
	{
		msg:"AfPublishModel",
		vo:{
			userId:"10001",			//必填
			token:"xxx-xxx-xx",		//必填
			model:{
				"id": "SparkTTS",
				"name": "Spark TTS",
				"brief": "“Spark TTS” 是一个先进的基于大语言模型（LLM）的文本转语音（TTS）系统，由 SparkAudio 及相关研究团队开发，具有高效率、定制化和高自然度等特点",
				"size": 3,
				"updateTime": 1755216000000,
				"publishTime": 1741996800000,
				"deploy": {
					"windows": "NA",
					"mac": "Deploy",
					"linux": "NA"
				},
				"downloads": 120,
				"scoreOverall": 7,
				"scoreTiming": 5,
				"scoreCapability": 7,
				"scorePopularity": 7,
				"scoreDeployment": 9,
				"scoreSize": 6,
				"scoreObjective": 6,
				"readMe": null,
				"articles": [],
				"pictures": [],
				"videos": [],
				"urlGitHub": "https://www.github.com/Avdpro/ai2apps",
				"urlHuggingFace": "",
				"urlHomepage": "",
				"catalogs": ["Audio"],
				"capabilities": ["TTS","Train Voice"],
				"openSource": 1,
				"application": ""
			}
		}
	}
    ```
	

