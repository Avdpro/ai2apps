/**
 * 生成分数多边形 SVG（雷达图样式），支持顶点标签
 * @param {number[]} scores - 分数数组（长度即边数）
 * @param {number} maxScore - 满分值（>0）
 * @param {object} [opts]
 * @param {number} [opts.size=260]
 * @param {number} [opts.padding=16]
 * @param {string} [opts.scoreStroke="#1f78ff"]
 * @param {string} [opts.scoreFill="#1f78ff"]
 * @param {number} [opts.scoreFillOpacity=0.30]
 * @param {string[]} [opts.labels] - 每个顶点的名称文本
 * @param {number} [opts.labelOffset=10] - 标签相对顶点向外偏移距离
 * @param {string} [opts.labelColor="#333"]
 * @param {number} [opts.labelFontSize=12]
 * @returns {SVGSVGElement}
 */
function makeScorePolygonSVG(scores, maxScore, opts = {}) {
  const {
    size = 260,
    padding = 0,
    scoreStroke = "#000",
    scoreFill = "#AAA",
    scoreFillOpacity = 0.30,
    labels,
    labelOffset = 10,
    labelColor = "#333",
    labelFontSize = 12,
  } = opts;

  if (!Array.isArray(scores) || scores.length < 3) {
    throw new Error("scores 至少需要 3 个值。");
  }
  if (!(maxScore > 0)) throw new Error("maxScore 必须为正数。");
  if (labels && labels.length !== scores.length) {
    throw new Error("labels 长度必须与 scores 相同。");
  }

  const NS = "http://www.w3.org/2000/svg";
  const n = scores.length;
  const cx = size / 2, cy = size / 2;
  const rMax = Math.max(0, size / 2 - padding);
  const step = (Math.PI * 2) / n;
  const startAng = -Math.PI / 2; // 顶点朝上
  const eps = 1e-3; // 判断“正上/正下”的容差

  const clamp01 = v => Math.max(0, Math.min(1, v));
  const fmt = (x) => x.toFixed(2);

  const pt = (val, i, m = maxScore) => {
    const ang = startAng + i * step;
    const rr = rMax * clamp01(val / m);
    return [cx + rr * Math.cos(ang), cy + rr * Math.sin(ang), ang];
  };

  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("width", size);
  svg.setAttribute("height", size);
  svg.setAttribute("viewBox", `0 0 ${size} ${size}`);

  // 放射线
  for (let i = 0; i < n; i++) {
    const [x, y] = pt(maxScore, i);
    const line = document.createElementNS(NS, "line");
    line.setAttribute("x1", fmt(cx));
    line.setAttribute("y1", fmt(cy));
    line.setAttribute("x2", fmt(x));
    line.setAttribute("y2", fmt(y));
    line.setAttribute("stroke", "#999");
    line.setAttribute("stroke-width", "1");
    svg.appendChild(line);
  }

  // 底多边形
  const basePts = Array.from({ length: n }, (_, i) => pt(maxScore, i))
    .map(([x, y]) => `${fmt(x)},${fmt(y)}`).join(" ");
  const basePoly = document.createElementNS(NS, "polygon");
  basePoly.setAttribute("points", basePts);
  basePoly.setAttribute("fill", "none");
  basePoly.setAttribute("stroke", "#000");
  basePoly.setAttribute("stroke-width", "2");
  svg.appendChild(basePoly);

  // 分数多边形
  const scorePts = scores.map((v, i) => pt(v, i))
    .map(([x, y]) => `${fmt(x)},${fmt(y)}`).join(" ");
  const scorePoly = document.createElementNS(NS, "polygon");
  scorePoly.setAttribute("points", scorePts);
  scorePoly.setAttribute("fill", scoreFill);
  scorePoly.setAttribute("fill-opacity", String(scoreFillOpacity));
  scorePoly.setAttribute("stroke", scoreStroke);
  scorePoly.setAttribute("stroke-width", "2");
  svg.appendChild(scorePoly);

  // 顶点标签（可选）
  if (labels) {
    for (let i = 0; i < n; i++) {
      const [vx, vy, ang] = pt(maxScore, i); // 顶点坐标（满分轮廓）
      // 标签位置：沿顶点方向再外移 labelOffset
      const lx = vx + Math.cos(ang) * labelOffset;
      const ly = vy + Math.sin(ang) * labelOffset;

      // 计算对齐方式
      const cosA = Math.cos(ang);
      const sinA = Math.sin(ang);

      let textAnchor = "middle";
      let dominantBaseline = "middle";

      // 判断是否近似正上/正下（cos ≈ 0）
      if (Math.abs(cosA) < eps) {
        // 正上：sin < 0
        if (sinA < 0) {
          textAnchor = "middle";
          // 文本在点的外侧上方，底对齐（基线在文字框底部）
          dominantBaseline = "text-after-edge";
        } else {
          // 正下
          textAnchor = "middle";
          // 文本在点的外侧下方，顶对齐（基线在文字框顶部）
          dominantBaseline = "hanging";
        }
      } else {
        // 左右两侧：水平对齐依据左右
        if (cosA > 0) {
          textAnchor = "start"; // 在中心右侧 → 左对齐（靠左起）
        } else {
          textAnchor = "end";   // 在中心左侧 → 右对齐（靠右起）
        }
        dominantBaseline = "middle"; // 竖直方向居中
      }

      const text = document.createElementNS(NS, "text");
      text.setAttribute("x", fmt(lx));
      text.setAttribute("y", fmt(ly));
      text.setAttribute("fill", labelColor);
      text.setAttribute("font-size", String(labelFontSize));
      text.setAttribute("text-anchor", textAnchor);
      text.setAttribute("dominant-baseline", dominantBaseline);
      // 兼容性微调（有些环境 dominant-baseline 支持较弱，可用 dy 辅助）
      if (dominantBaseline === "text-after-edge") {
        text.setAttribute("dy", "0"); // 已经靠底
      } else if (dominantBaseline === "hanging") {
        text.setAttribute("dy", "0");
      } else {
        text.setAttribute("dy", "0.35em"); // 近似中线
      }
      text.textContent = labels[i] ?? `Item ${i + 1}`;
      svg.appendChild(text);
    }
  }

  return svg;
}

/**
 * 生成一个包含雷达图SVG（仅图形）+ HTML标签覆盖层的容器div
 * @param {number[]} scores
 * @param {number} maxScore
 * @param {object} [opts]
 * @param {number} [opts.size=260]  - 画布尺寸（方形）
 * @param {number} [opts.padding=16]
 * @param {string} [opts.scoreStroke="#1f78ff"]
 * @param {string} [opts.scoreFill="#1f78ff"]
 * @param {number} [opts.scoreFillOpacity=0.30]
 * @param {string[]} [opts.labels]   - 顶点名称（可选）
 * @param {number} [opts.labelOffset=10] - 标签相对顶点向外偏移
 * @param {string} [opts.labelColor="#333"]
 * @param {number} [opts.labelFontSize=12]
 * @param {string} [opts.classPrefix="radar"] - 生成的DOM类名前缀
 * @returns {HTMLDivElement}
 */
function makeScorePolygonDiv(scores, maxScore, opts = {}) {
  const {
    size = 260,
    padding = 0,
    scoreStroke = "#000",
    scoreFill = "#AAA",
    scoreFillOpacity = 0.30,
    labels,
    labelOffset = 10,
    labelColor = "#333",
    labelFontSize = 12,
    classPrefix = "radar",
  } = opts;

  if (!Array.isArray(scores) || scores.length < 3) {
    throw new Error("scores 至少需要 3 个值。");
  }
  if (!(maxScore > 0)) throw new Error("maxScore 必须为正数。");
  if (labels && labels.length !== scores.length) {
    throw new Error("labels 长度必须与 scores 相同。");
  }

  const NS = "http://www.w3.org/2000/svg";
  const n = scores.length;
  const cx = size / 2, cy = size / 2;
  const rMax = Math.max(0, size / 2 - padding);
  const step = (Math.PI * 2) / n;
  const startAng = -Math.PI / 2;
  const eps = 1e-3;

  const clamp01 = v => Math.max(0, Math.min(1, v));
  const fmt = x => x.toFixed(2);
  const fmtScore = v => Number(v).toFixed(1); // ← 分数专用格式
  const pt = (val, i, m = maxScore) => {
    const ang = startAng + i * step;
    const rr = rMax * clamp01(val / m);
    return [cx + rr * Math.cos(ang), cy + rr * Math.sin(ang), ang];
  };

  const container = document.createElement("div");
  container.className = `${classPrefix}-wrap`;
  container.style.position = "relative";
  container.style.width = `${size}px`;
  container.style.height = `${size}px`;

  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("width", size);
  svg.setAttribute("height", size);
  svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
  svg.classList.add(`${classPrefix}-svg`);

  // 放射线
  for (let i = 0; i < n; i++) {
    const [x, y] = pt(maxScore, i);
    const line = document.createElementNS(NS, "line");
    line.setAttribute("x1", fmt(cx));
    line.setAttribute("y1", fmt(cy));
    line.setAttribute("x2", fmt(x));
    line.setAttribute("y2", fmt(y));
    line.setAttribute("stroke", "#999");
    line.setAttribute("stroke-width", "1");
    svg.appendChild(line);
  }

  // 底多边形
  const basePts = Array.from({ length: n }, (_, i) => pt(maxScore, i))
    .map(([x, y]) => `${fmt(x)},${fmt(y)}`).join(" ");
  const basePoly = document.createElementNS(NS, "polygon");
  basePoly.setAttribute("points", basePts);
  basePoly.setAttribute("fill", "none");
  basePoly.setAttribute("stroke", "#000");
  basePoly.setAttribute("stroke-width", "2");
  svg.appendChild(basePoly);

  // 分数多边形
  const scorePts = scores.map((v, i) => pt(v, i))
    .map(([x, y]) => `${fmt(x)},${fmt(y)}`).join(" ");
  const scorePoly = document.createElementNS(NS, "polygon");
  scorePoly.setAttribute("points", scorePts);
  scorePoly.setAttribute("fill", scoreFill);
  scorePoly.setAttribute("fill-opacity", String(scoreFillOpacity));
  scorePoly.setAttribute("stroke", scoreStroke);
  scorePoly.setAttribute("stroke-width", "2");
  svg.appendChild(scorePoly);

  container.appendChild(svg);

  // 覆盖的标签层
  if (labels) {
    for (let i = 0; i < n; i++) {
      const [vx, vy, ang] = pt(maxScore, i);
      const lx = vx + Math.cos(ang) * labelOffset;
      const ly = vy + Math.sin(ang) * labelOffset;

      const cosA = Math.cos(ang);
      const sinA = Math.sin(ang);

      const lab = document.createElement("div");
      lab.className = `${classPrefix}-label`;
      lab.innerHTML = `${labels[i] ?? `Item ${i + 1}`} <strong>${fmtScore(scores[i])}</strong>`;

      lab.style.position = "absolute";
      lab.style.left = `${lx}px`;
      lab.style.top = `${ly}px`;
      lab.style.color = labelColor;
      lab.style.fontSize = `${labelFontSize}px`;
      lab.style.lineHeight = "1.2";
      lab.style.whiteSpace = "nowrap";
      lab.style.pointerEvents = "none";
      lab.style.userSelect = "none";

      if (Math.abs(cosA) < eps) {
        if (sinA < 0) {
          lab.style.transform = "translate(-50%, -100%)";
          lab.style.textAlign = "center";
        } else {
          lab.style.transform = "translate(-50%, 0)";
          lab.style.textAlign = "center";
        }
      } else if (cosA > 0) {
        lab.style.transform = "translate(0, -50%)";
        lab.style.textAlign = "left";
      } else {
        lab.style.transform = "translate(-100%, -50%)";
        lab.style.textAlign = "right";
      }

      container.appendChild(lab);
    }
  }

  return container;
}
export default makeScorePolygonSVG;
export {makeScorePolygonSVG,makeScorePolygonDiv};

