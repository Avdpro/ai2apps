import {VFACT} from "/@vfact";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditDoc,EditDocDef} from "../editdoc/EditDoc.js";
import inherits from "/@inherits";
import pathLib from "/@path";
let $ln=VFACT.lanCode||"EN";
let DocBackEnd,docBackEnd;
const FlowSegArrayDef={elementType:"flowseg",allowExtraAttr:1};

const DocBackEndDef={
	name:"DocBackEnd",
	icon:"gears.svg",allowExtraAttr:0,navi:"prj",
	constructFunc:DocBackEnd,
	exporter:"DocBackEnd",
	attrs:{
		...EditDocDef.attrs,//basic attr: path
		"docObj":{
			name:"docObj",showName:(($ln==="CN")?("处理器组"):/*EN*/("Handler group")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:"doc",
			newAttrMode:"GearArg",watchTree:false,
		},
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"HudLocalVal",watchTree:true
		},
		"segs":{
			name:"segs",showName:(($ln==="CN")?("代码片段"):/*EN*/("Code Segments")),type:"array",icon:"array.svg",def:FlowSegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?("这是一组网络请求处理器。"):/*EN*/("This is group of request handlers.")),
		}
	},
	objAttrs:{
		getLocalizableObjs(){
			return [this.getAttr("docObj"),this.segsVal]
		}
	}
};
//****************************************************************************
//:DocBackEnd:
//****************************************************************************
DocBackEnd=function(owner,def,init){
	let self,objDef,app;
	self=this;
	EditDoc.call(this,owner,def,true);
	app=this.prj.app;
	this.isBackEndDoc=true;
	objDef=this.objDef;
	//Agent dummy:
	this.docObjVal=this.getAttr("docObj");
	this.docObjVal.getEditRootPpts=this.getEditRootPpts.bind(this);
	//Sub segs:
	this.segsVal=this.getAttr("segs");
	this.segsList=this.segsVal.attrList;
	this.naviState={
		hotItem:null
	};
};
inherits(DocBackEnd,EditDoc);
docBackEnd=DocBackEnd.prototype;
EditDoc.regDocDef("DocBackEnd",DocBackEndDef);
DocBackEndDef.constructFunc=DocBackEnd;

//****************************************************************************
//:I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	docBackEnd.loadFromCodeSaveVO=function(vo){
		let list,i,n,seg;
		EditDoc.prototype.loadFromCodeSaveVO.call(this,vo);
		list=this.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			seg.postLoadLink();
		}
		if(this.dataDoc){
			this.dataDoc.on("Blured",()=>{this.OnDocBlur();});
		}
		return vo;
	};
}

//****************************************************************************
//:Seg access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docBackEnd.runOnAllSegs=function(func,...args){
		let seg;
		for(seg of this.segsList){
			func(seg,...args);
		}
	};
}

//****************************************************************************
//:Edit hud:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docBackEnd.findSeg=function(jaxId,segsList){
		let seg,findSeg;
		segsList=segsList||this.segsList;;
		for(seg of segsList){
			if(seg.jaxId===jaxId){
				return seg;
			}
			if(seg.segsList){
				findSeg=this.findSeg(jaxId,seg.segsList);
				if(findSeg){
					return findSeg;
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	docBackEnd.dropSegLiveObjs=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.dropLiveObj();
		}
	};
	
	//-----------------------------------------------------------------------
	docBackEnd.renderPath=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.renderPath();
		}
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docBackEnd.getEditRootPpts=function(){
		let list=[];
		list.push({obj:this.getAttr("localVars"),open:true});
		list.push({attr:this.getAttr("desc")});
		return list;
	};

	//------------------------------------------------------------------------
	docBackEnd.getNaviDocRoot=function(){
		let list=[];
		list.push(this.docObjVal);
		list.push(this.segsVal);
		return list;
	};

	//------------------------------------------------------------------------
	docBackEnd.naviDocReady=function(){
		let naviBox,treeBox,state,obj;
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let selected,obj,node;
			obj=state.hotItem;
			if(obj){
				this.prj.setEditSubObj(obj);
			}
		}
	};

	//------------------------------------------------------------------------
	docBackEnd.OnDocBlur=function(){
		let naviBox,treeBox,state;
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let node;
			treeBox=naviBox.treeBox;
			node=treeBox.hotNode;
			state.hotItem=node?node.nodeObj:null;
		}
	};
}
export {DocBackEnd};