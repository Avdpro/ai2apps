import {VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {esprima} from "/@tabos/utils/esprima.mjs";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
import {EditAISegOutlet,EditAISeg} from "../aiagent/EditAISeg.js";
//Hud:

const $ln=VFACT.lanCode;
let EditBackEndFlowSeg,editBackEndFlowSeg;
//****************************************************************************
//:EditBackEndFlowSeg
//****************************************************************************
EditBackEndFlowSeg=function(owner,def,init){
	let self;
	self=this;
	EditAISeg.call(this,owner,def,true);
	this.isFlowSeg=true;
	//Sub segs:
	this.segsVal=this.getAttr("segs");
	if(this.segsVal){
		let item,doc;
		doc=this.doc;
		this.segsList=this.segsVal.attrList;
		item=this.owner;
		this.segsVal.on("AttrAdd",(...args)=>{doc.emit("SegAttrAdd",...args)});
		this.segsVal.on("AttrInsert",(...args)=>{doc.emit("SegAttrInsert",...args)});
		this.segsVal.on("AttrRemove",(...args)=>{doc.emit("SegAttrRemove",...args)});
		this.segsVal.on("AttrMoveUp",(...args)=>{doc.emit("SegAttrMoveUp",...args)});
		this.segsVal.on("AttrMoveDown",(...args)=>{doc.emit("SegAttrMoveDown",...args)});
		this.segsVal.on("AttrReplace",(...args)=>{doc.emit("SegAttrReplace",...args)});
	}
};
inherits(EditBackEndFlowSeg,EditAISeg);
EditAttr.regAttrType("flowseg",EditBackEndFlowSeg);
editBackEndFlowSeg=EditBackEndFlowSeg.prototype;
if(VFACT.classRegs){
	VFACT.classRegs.EditBackEndFlowSeg=EditBackEndFlowSeg;
}

//****************************************************************************
//:EditBackEndFlowSeg def registers
//****************************************************************************
{
	let segDefRegs={};
	EditBackEndFlowSeg.regDef=function(def){
		let name=def.name;
		let catalogs=def.catalog;
		if(def){
			segDefRegs[name]=def;
		}
		if(catalogs){
			let catalog;
			for(name of catalogs){
				catalog=EditBackEndFlowSeg.getCatalog(name);
				if(catalog){
					catalog.defs.push(def);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	EditBackEndFlowSeg.getDef=function(name){
		return segDefRegs[name];
	};

	//------------------------------------------------------------------------
	EditBackEndFlowSeg.getDefs=function(){
		return Array.from(Object.values(segDefRegs));
	};
	let defCatalogs={};
	//------------------------------------------------------------------------
	EditBackEndFlowSeg.regCatalog=function(def){
		let name,catalog;
		name=def.name;
		catalog=defCatalogs[name];
		if(!catalog){
			defCatalogs[name]={...def,defs:[]};
		}
	};
	
	//------------------------------------------------------------------------
	EditBackEndFlowSeg.getCatalog=function(name){
		return defCatalogs[name];
	};

	//------------------------------------------------------------------------
	EditBackEndFlowSeg.getCatalogs=function(){
		return Object.values(defCatalogs);
	};
}

//****************************************************************************
//:Scope:
//****************************************************************************
{
	editBackEndFlowSeg.initScope=function(){
		let self,doc,appCfg,argObj,localVars,docLocalVars,willUpdate;
		self=this;
		willUpdate=false;
		this.scopeObj={};
		appCfg=this.prj.objConfig;
		doc=this.doc;
		docLocalVars=doc.getAttr("localVars");
		argObj=this.getAttr("args");
		localVars=this.getAttr("localVars");
		this.setScopeObj("$ln",appCfg.getAttr("lanCode"),false);
		this.setScopeObj("docLocalVars",docLocalVars,true);
		if(argObj){
			this.setScopeObj("args",argObj,true);
		}
		if(localVars){
			this.setScopeObj("localVars",localVars,true);
		}
		function update(){
			if(willUpdate)
				return;
			willUpdate=true;
			callAfter(()=>{
				self.buildScopeEnv();
				self.updateHyperAttrs();
				willUpdate=false;
			});
		}
		docLocalVars.on("Changed",update);
		if(argObj){
			argObj.traceOn(update);
		}
		if(localVars){
			localVars.traceOn(update);
		}
	};
}

export {EditBackEndFlowSeg};
