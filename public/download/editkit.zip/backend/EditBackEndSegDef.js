import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditAISegOutlet} from "../aiagent/EditAISeg.js";
import {EditBackEndFlowSeg} from "./EditBackEndFlowSeg.js";
const $ln=VFACT.lanCode;

const SegObjShellAttr={
	"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false},
	"x":{name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false},
	"y":{name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false},
	"desc":{name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?(""):/*EN*/(""))},
	"codes":{name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false},
};

const ConditionOutletDef={
	name:"ConditionOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Condition",
		},
		"condition":{
			name:"condition",showName:(($ln==="CN")?("判断条件"):/*EN*/("Condition")),type:"string",key:1,fixed:1,initVal:"",export:false,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("条件输出节点。"):/*EN*/("Condition outlet.")),
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(ConditionOutletDef);
const CoditionOutletArrayDef={
	elementType:"aioutlet",elementDef:ConditionOutletDef,allowExtraAttr:1,
	attrs:[
		{type:"aioutlet",def:ConditionOutletDef,key:1,fixed:1}
	]
};

const SwitchOutletDef={
	name:"SwitchOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Condition",
		},
		"condition":{
			name:"condition",showName:(($ln==="CN")?("判断条件"):/*EN*/("Condition")),type:"string",key:1,fixed:1,initVal:"",export:false,
		},
		"merge":{
			name:"merge",showName:(($ln==="CN")?("向下合并"):/*EN*/("Merge down")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"break":{
			name:"break",showName:(($ln==="CN")?("break结尾"):/*EN*/("Ends with break")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",key:1,fixed:1,initVal:"",
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(SwitchOutletDef);
const SwitchOutletArrayDef={
	elementType:"aioutlet",elementDef:SwitchOutletDef,allowExtraAttr:1,
	attrs:[
		{type:"aioutlet",def:SwitchOutletDef,key:1,fixed:1}
	]
};

//************************************************************************
//:Define catalogs:
//************************************************************************
EditBackEndFlowSeg.regCatalog({
	name:"Common",showName:(($ln==="CN")?("常用"):/*EN*/("Common"))
});

EditBackEndFlowSeg.regCatalog({
	name:"Code",showName:(($ln==="CN")?("代码"):/*EN*/("Code"))
});

EditBackEndFlowSeg.regCatalog({
	name:"Database",showName:(($ln==="CN")?("数据库"):/*EN*/("Database"))
});

EditBackEndFlowSeg.regCatalog({
	name:"Flow",showName:(($ln==="CN")?("流程控制"):/*EN*/("Flow Control"))
});

EditBackEndFlowSeg.regCatalog({
	name:"Code",showName:(($ln==="CN")?("代码"):/*EN*/("Code"))
});

const FlowSegArrayDef={elementType:"flowseg",allowExtraAttr:1};
//************************************************************************
//:Define segs:
//************************************************************************
//:Code seg that is a reqeust handler function
EditBackEndFlowSeg.regDef({
	name:"Handler",showName:(($ln==="CN")?("处理函数"):/*EN*/("Request Handler")),icon:"appdata.svg",catalog:["Common","Code"],rootOnly:true,
	attrs:{
		...SegObjShellAttr,
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"HudLocalVal",watchTree:true
		},
		"segs":{
			name:"segs",showName:(($ln==="CN")?("子片段"):/*EN*/("Sub Segs")),type:"array",icon:"array.svg",def:FlowSegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				}
			}
		},
	},
	listHint:[
		"id","localVars","codes","desc",
	],
	objAttrs:{
		addCallArg:function(name,def){
			let args=this.getAttr("args");
			let attrDef={...def,name:name,key:0,fixed:0};
			return args.addAttr(attrDef);
		}
	}
});

//:Code seg that start an function:
EditBackEndFlowSeg.regDef({
	name:"Entry",showName:(($ln==="CN")?("函数入口"):/*EN*/("Entry")),icon:"func.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Arguments")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"GearArg",watchTree:true
		},
		"argPack":{
			name:"argPack",showName:(($ln==="CN")?("参数打包"):/*EN*/("Arguments Pack")),type:"choice",key:1,fixed:1,initVal:"Normal",
			vals:[
				["Normal","Normal","Normal"],
				["Object","Object","Object"],
			],
		},
		"async":{
			name:"async",showName:(($ln==="CN")?("异步函数"):/*EN*/("Async")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false
		},
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"HudLocalVal",watchTree:true
		},
		"segs":{
			name:"segs",showName:(($ln==="CN")?("子片段"):/*EN*/("Sub Segs")),type:"array",icon:"array.svg",def:FlowSegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				}
			}
		},
	},
	listHint:[
		"id","args","argPack","async","localVars","codes","desc",
	],
	objAttrs:{
		addCallArg:function(name,def){
			let args=this.getAttr("args");
			let attrDef={...def,name:name,key:0,fixed:0};
			return args.addAttr(attrDef);
		}
	}
});

//------------------------------------------------------------------------
//:CodeSeg that just code:
EditBackEndFlowSeg.regDef({
	name:"Code",showName:(($ln==="CN")?("代码片段"):/*EN*/("Code Seg")),icon:"tab_css.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",showName:"next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
			}
		}
	},
	listHint:[
		"id","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Raw-Block-Code, can be if/while/do-while/event function...
EditBackEndFlowSeg.regDef({
	name:"CodeBlock",showName:(($ln==="CN")?("代码块"):/*EN*/("Code Block")),icon:"code.svg",catalog:["Common","Code"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"prefix":{
			name:"prefix",showName:(($ln==="CN")?("前缀"):/*EN*/("Prefix")),type:"string",key:1,fixed:1,initVal:"",
		},
		"postfix":{
			name:"postfix",showName:(($ln==="CN")?("后缀"):/*EN*/("Postfix")),type:"string",key:1,fixed:1,initVal:"",
		},
		"catchlet":{
			name:"catchlet",showName:"Body",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Body",
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		}
	},
	listHint:[
		"id","prefix","postfix","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Condition brunches:
EditBackEndFlowSeg.regDef({
	name:"Condition",showName:(($ln==="CN")?("条件分支"):/*EN*/("Condition")),icon:"condition.svg",catalog:["Common","Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlets":{
			name:"outlets",showName:"Conditions",type:"array",def:CoditionOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"catchlet":{
			name:"catchlet",showName:"Else",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"else",
				},
				"codes":{
					name:"codes",showName:(($ln==="CN")?("代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","desc","codes",
	]
});

//------------------------------------------------------------------------
//:Function Call
EditBackEndFlowSeg.regDef({
	name:"Call",showName:(($ln==="CN")?("函数调用"):/*EN*/("Call function")),icon:"args.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"callName":{
			name:"callName",showName:(($ln==="CN")?("调用函数名"):/*EN*/("Function Name")),type:"string",key:1,fixed:1,initVal:"",
		},
		"argPack":{
			name:"argPack",showName:(($ln==="CN")?("参数打包"):/*EN*/("Arguments Pack")),type:"choice",key:1,fixed:1,initVal:"Normal",
			vals:[
				["Normal","Normal","Normal"],
				["Object","Object","Object"],
			],
		},
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call arguments")),type:"object",def:"Object",key:1,fixed:1
		},
		"assign":{
			name:"assign",showName:(($ln==="CN")?("赋值结果"):/*EN*/("Assign Result")),type:"string",key:1,fixed:1,initVal:"",
		},
		"await":{
			name:"await",showName:(($ln==="CN")?("等待"):/*EN*/("Await")),type:"bool",key:1,fixed:1,initVal:true
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","callName","argPack","args","assign","await","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Code seg that finish the request and return value:
EditBackEndFlowSeg.regDef({
	name:"Response",showName:(($ln==="CN")?("返回请求"):/*EN*/("Response")),icon:"share.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"result":{
			name:"result",showName:(($ln==="CN")?("返回值"):/*EN*/("Result Value")),type:"object",def:"Object",key:1,fixed:1,initVal:undefined,
			attrs:{
				"code":{name:"code",type:"int",key:1,fixed:1,initVal:200}
			}
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				}
			}
		},
	},
	listHint:[
		"id","result","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Code seg that end the function and return value:
EditBackEndFlowSeg.regDef({
	name:"Return",showName:(($ln==="CN")?("退出函数"):/*EN*/("Exit")),icon:"flag.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"result":{
			name:"result",showName:(($ln==="CN")?("返回值"):/*EN*/("Result Value")),type:"auto",key:1,fixed:1,initVal:undefined,
		},
	},
	listHint:[
		"id","result","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Code seg path connect:
const connectorDef={
	name:"connector",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowleft.svg",segIcon:"arrowright.svg",catalog:["Common","Flow"],
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"New AI Seg",export:false,edit:false,
		},
		"x":{
			name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"y":{
			name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"outlet":{
			name:"outlet",showName:"Outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Outlet",
				},
			},
		},
		"dir":{
			name:"dir",showName:(($ln==="CN")?("方向"):("Direction")),type:"choice",
			vals:(($ln==="CN")?([["L2R","L2R","左至右"],["R2L","R2L","右至左"],["T2B","T2B","上至下"],["B2T","B2T","下至上"]]):/*EN*/([["L2R","L2R","Left to right"],["R2L","R2L","Right to left"],["T2B","T2B","Top to bottom"],["B2T","B2T","Bottom to top"]])),
			initVal:"R2L",hideVal:1,key:1,fixed:1
		},
	},
	listHint:[
		"dir"
	],
	objAttrs:{
		isConnector:true,
		getName(){
			return (($ln==="CN")?("连接器"):/*EN*/("Connector"));
		}
	},
};
EditBackEndFlowSeg.regDef(connectorDef);
EditBackEndFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorL",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowright.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"L2R"}
}));
EditBackEndFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorT",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowdown.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"T2B"}
}));
EditBackEndFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorB",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowup.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"B2T"}
}));

//------------------------------------------------------------------------
//:Swtich brunches:
EditBackEndFlowSeg.regDef({
	name:"Switch",showName:(($ln==="CN")?("Switch块"):/*EN*/("Switch Block")),icon:"condition.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"expression":{
			name:"expression",showName:"Expression",type:"string",fixed:1,key:1,edit:false,initVal:"expression",
		},
		"outlets":{
			name:"outlets",showName:"Conditions",type:"array",def:SwitchOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","expression","codes","desc",
	]
});

//------------------------------------------------------------------------
//:CodeSeg that make loop on an array:
EditBackEndFlowSeg.regDef({
	name:"LoopObj",showName:(($ln==="CN")?("遍历数组/对象"):/*EN*/("Items Loop")),icon:"loop_array.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"loopObj":{
			name:"loopObj",showName:(($ln==="CN")?("循环目标"):/*EN*/("Loop Target")),type:"string",key:1,fixed:1,rawEdit:false,initVal:"list",//TODO: Choose array attr?
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"",
		},
		"loopVal":{
			name:"loopVal",showName:(($ln==="CN")?("循环变量"):/*EN*/("Loop Val")),type:"string",key:1,fixed:1,initVal:"item",
		},
		"letVal":{
			name:"letVal",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local Val")),type:"bool",key:1,fixed:1,rawEdit:false,initVal:true,
		},
		"loopMode":{
			name:"loopMode",showName:(($ln==="CN")?("循环模式"):/*EN*/("Loop Mode")),type:"choice",key:1,fixed:1,initVal:"of",rawEdit:false,
			vals:[
				["of","of","of"],
				["in","in","in"],
			],
		},
		"catchlet":{
			name:"catchlet",showName:"Looper",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Looper",
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		},
	},
	listHint:[
		"id","loopObj","loopVal","letVal","label","loopMode","desc","codes",
	]
});

//------------------------------------------------------------------------
//:CodeSeg that catch error in sub-flow:
EditBackEndFlowSeg.regDef({
	name:"TryCatch",showName:(($ln==="CN")?("捕获异常"):/*EN*/("Catch Error")),icon:"trycatch.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlets":{
			name:"outlets",showName:"TryCatch",type:"object",key:1,fixed:1,edit:false,navi:"doc",
			def:{
				allowExtraAttr:false,
				attrs:{
					"try":{
						name:"try",showName:"Try",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
						attrs:{
							"id":{
								name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Try",
							},
							"codes":{
								name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,
							},
						},
					},
					"catch":{
						name:"catch",showName:"catch",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
						attrs:{
							"id":{
								name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Catch",
							},
							"codes":{
								name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,
							},
						},
					}
				}
			}
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		}
	},
	listHint:[
		"id","desc","codes",
	]
});

//****************************************************************************
//Database segs:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//:MongoDB.findOne
	EditBackEndFlowSeg.regDef({
		name:"DBFindOne",showName:(($ln==="CN")?("读出一项"):/*EN*/("Read One")),icon:"dbload.svg",catalog:["Database"],
		attrs:{
			...SegObjShellAttr,
			"collection":{
				name:"collection",showName:(($ln==="CN")?("数据集"):/*EN*/("Collection")),type:"string",key:1,fixed:1,initVal:"users",
			},
			"query":{
				name:"query",showName:(($ln==="CN")?("查询条件"):/*EN*/("Query")),type:"object",def:"Object",key:1,fixed:1
			},
			"projection":{
				name:"projection",showName:(($ln==="CN")?("映射"):/*EN*/("Projection")),type:"object",def:"Object",key:0,fixed:1
			},
			"assign":{
				name:"assign",showName:(($ln==="CN")?("赋值"):/*EN*/("Assign")),type:"string",key:1,fixed:1,initVal:"item",
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
				}
			},
		},
		listHint:[
			"id","assign","collection","query","projection","codes","desc",
		],
	});

	//------------------------------------------------------------------------
	//:MongoDB.updateOne
	EditBackEndFlowSeg.regDef({
		name:"DBUpdateOne",showName:(($ln==="CN")?("更新一项"):/*EN*/("Update One")),icon:"dbsave.svg",catalog:["Database"],
		attrs:{
			...SegObjShellAttr,
			"collection":{
				name:"collection",showName:(($ln==="CN")?("数据集"):/*EN*/("Collection")),type:"string",key:1,fixed:1,initVal:"users",
			},
			"query":{
				name:"query",showName:(($ln==="CN")?("查询条件"):/*EN*/("Query")),type:"object",def:"Object",key:1,fixed:1
			},
			"update":{
				name:"update",showName:(($ln==="CN")?("更新内容"):/*EN*/("Update")),type:"object",def:"Object",key:1,fixed:1
			},
			"await":{
				name:"await",showName:(($ln==="CN")?("等待"):/*EN*/("Await")),type:"bool",key:1,fixed:1,initVal:true,
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
				}
			},
		},
		listHint:[
			"id","collection","query","update","await","codes","desc",
		],
	});

	//------------------------------------------------------------------------
	//:MongoDB.insertOne
	EditBackEndFlowSeg.regDef({
		name:"DBInsertOne",showName:(($ln==="CN")?("插入一项"):/*EN*/("Insert One")),icon:"dbinsert.svg",catalog:["Database"],
		attrs:{
			...SegObjShellAttr,
			"collection":{
				name:"collection",showName:(($ln==="CN")?("数据集"):/*EN*/("Collection")),type:"string",key:1,fixed:1,initVal:"users",
			},
			"item":{
				name:"item",showName:(($ln==="CN")?("项目"):/*EN*/("Item")),type:"object",def:"Object",key:1,fixed:1
			},
			"await":{
				name:"await",showName:(($ln==="CN")?("等待"):/*EN*/("Await")),type:"bool",key:1,fixed:1,initVal:true,
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
				}
			},
		},
		listHint:[
			"id","collection","item","await","codes","desc",
		],
	});

	//------------------------------------------------------------------------
	//:MongoDB.deleteOne
	EditBackEndFlowSeg.regDef({
		name:"DBDeleteOne",showName:(($ln==="CN")?("删除一项"):/*EN*/("Delete One")),icon:"dbdelete.svg",catalog:["Database"],
		attrs:{
			...SegObjShellAttr,
			"collection":{
				name:"collection",showName:(($ln==="CN")?("数据集"):/*EN*/("Collection")),type:"string",key:1,fixed:1,initVal:"users",
			},
			"query":{
				name:"query",showName:(($ln==="CN")?("查询条件"):/*EN*/("Query")),type:"object",def:"Object",key:1,fixed:1
			},
			"await":{
				name:"await",showName:(($ln==="CN")?("等待"):/*EN*/("Await")),type:"bool",key:1,fixed:1,initVal:true,
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
				}
			},
		},
		listHint:[
			"id","collection","query","await","codes","desc",
		],
	});
}

//------------------------------------------------------------------------
//:WebCall
EditBackEndFlowSeg.regDef({
	name:"WebFetch",showName:(($ln==="CN")?("调用网络API"):/*EN*/("Call WEB API")),icon:"web.svg",catalog:["Code"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("调用URL"):/*EN*/("Call URL")),type:"string",key:1,fixed:1,initVal:"https://api.google.com",
		},
		"method":{
			name:"method",showName:(($ln==="CN")?("请求方法"):/*EN*/("Request Method")),type:"choice",key:1,fixed:1,initVal:"POST",
			vals:[
				["GET","GET","GET"],
				["POST","POST","POST"],
				["PUT","PUT","PUT"],
				["DELETE","DELETE","DELETE"],
			],
		},
		"argMode":{
			name:"argMode",showName:(($ln==="CN")?("参数传递方法"):/*EN*/("Arguments embeding")),type:"choice",key:1,fixed:1,initVal:"JSON",rawEdit:false,
			vals:[
				["URL","URL","URL"],
				["JSON","JOSN","JSON in body"],
				["TEXT","Text","String"],
			],
		},
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call arguments")),type:"object",def:"Object",key:1,fixed:1
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("调用文本"):/*EN*/("Call text")),type:"string",key:1,fixed:1,initVal:"",
		},
		"headers":{
			name:"headers",showName:(($ln==="CN")?("HTTP 头参数"):/*EN*/("HTTP Header")),type:"object",def:"Object",key:1,fixed:1
		},
		"assign":{
			name:"assign",showName:(($ln==="CN")?("赋值结果"):/*EN*/("Assign Result")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","url","method","headers","argMode","args","text","assign","codes","desc",
	]
});

