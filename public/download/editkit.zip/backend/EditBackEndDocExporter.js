import pathLib from "/@path";
import inherits from "/@inherits";
import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditDocExporter,genAttrValText,genLocalizeValText} from "../exporters/EditDocExporter.js";
import {CdyCoder} from "../exporters/coder.js";
import {DocClassExporter} from "../exporters/DocClassExporter.js";

var DocBackEndExporter,docBackEndExporter;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
let segTypeExporters={};
let exportVsn=0;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocBackEndExporter=function(prj){
	EditDocExporter.call(this,prj);
};
DocBackEndExporter.segTypeExporters=segTypeExporters;
EditDocExporter.regExporter("DocBackEnd",DocBackEndExporter);
inherits(DocBackEndExporter,EditDocExporter);
docBackEndExporter=DocBackEndExporter.prototype;
if(VFACT.classRegs){
	VFACT.classRegs.DocBackEndExporter=DocBackEndExporter;
}

//----------------------------------------------------------------------------
docBackEndExporter.export=function(editDoc,opts){
	let list,i,n,coder,exportObjs,subStates;
	let path,baseName,exportName;
	opts=opts||{};
	subStates=[];
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	path=editDoc.getAttr("path").val;
	baseName=pathLib.basename(path);
	exportVsn+=1;
	{
		let pos=baseName.indexOf(".");
		exportName=(pos>0)?(baseName.substring(0,pos)):baseName;
		exportObjs.push(exportName);
	}

	//Imports:
	{
		let imports,path,stub,items;
		let orgPath=opts.path||editDoc.selfProxy.path;
		let orgDir=opts.orgDir||pathLib.dirname(orgPath);
		let prjPath=editDoc.prj.path;
		{
			coder.packText(`import fs from "fs";`,0);
			coder.newLine();
			coder.packText(`import asyncFS from "node:fs/promises";`,0);
			coder.newLine();
			coder.packText(`import pathLib from "path";`,0);
			coder.newLine();
		}
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(!stub.isUsed()){
				continue;
			}
			if(path.startsWith(prjPath)){//In same prj, use relative path
				if(path.startsWith(orgDir)){
					path="./"+pathLib.basename(path);
				}else if(!path.startsWith("/@")){
					path=pathLib.relative(orgDir,path);
				}
			}
			if(opts.fixExt){
				let ext;
				ext=pathLib.extname(path);
				if(ext!==".js"){
					path=path.substring(0,path.length-ext.length)+".js";
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"MoreImports");
	coder.endDocObjTagBlcok(editDoc,"MoreImports",0);
	coder.newLine();
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);
	coder.newLine();

	//Export Major hud-gear:
	{
		let exportObj,attr,localVars,seg0,segNames;
		exportObj=editDoc;
		coder.packText("//----------------------------------------------------------------------------");
		coder.newLine();
		coder.packText(`let ${exportName}=async function(app,router,apiMap){`);
		{
			coder.indentMore();
			coder.newLine();
			seg0=exportObj.segsList[0];
			//Add localVars;
			localVars=editDoc.getAttr("localVars").attrList;
			if(localVars.length>0){
				for(attr of localVars){
					this.genLocalVar(attr,subStates);
				}
			}
			coder.beginDocObjTagBlcok(exportObj,"PreCodes");
			coder.endDocObjTagBlcok(exportObj,"PreCodes",0);
			coder.maybeNewLine();
			
			//Export functions:
			{
				let segsList,seg;
				segsList=exportObj.segsList;
				for(seg of segsList){
					if(seg.objDef.name==="Entry"){
						this.exportSeg(editDoc,seg);
					}
				}
			}

			//Export handlers:
			{
				let segsList,seg;
				segsList=exportObj.segsList;
				for(seg of segsList){
					if(seg.objDef.name==="Handler"){
						this.exportSeg(editDoc,seg);
					}
				}
			}
			
			coder.beginDocObjTagBlcok(exportObj,"PostCode");
			coder.endDocObjTagBlcok(exportObj,"PostCode",0);
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("};");
		coder.maybeNewLine();
		coder.newLine();
		coder.beginDocObjTagBlcok(exportObj,"ExCodes");
		coder.endDocObjTagBlcok(exportObj,"ExCodes",0);
		coder.newLine();
	}

	//------------------------------------------------------------------------
	//export
	coder.packText(`export default ${exportObjs[0]};`);coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docBackEndExporter.genLocalVar=function(attr,subStates=null){
	let coder=this.coder;
	coder.packText(`let ${attr.name}=`);
	this.genAttrStatement(attr);
	coder.packText(`;`);
	coder.newLine();
};

//----------------------------------------------------------------------------
docBackEndExporter.exportSeg=function(editDoc,seg){
	let typeName,func;
	typeName=seg.objDef.name;
	if(typeName!=="Entry" && typeName!=="Handler"){
		return;
	}
	this.coder.newLine();
	func=segTypeExporters[typeName];
	if(func){
		func(editDoc,seg,this);
	}
};

let packExtraCodes;
//****************************************************************************
//:Util fuctions:
//****************************************************************************
{
	//------------------------------------------------------------------------
	packExtraCodes=function(coder,seg,mark="Codes"){
		let codes=seg.getAttr("codes");
		if(codes){
			codes=!!codes.val;
		}
		if(codes){
			coder.beginDocObjTagBlcok(seg,mark);
			coder.endDocObjTagBlcok(seg,mark,0);
		}
	};
	docBackEndExporter.packExtraCodes=packExtraCodes;
}

//****************************************************************************
//:Seg export functions
//****************************************************************************
{
	//------------------------------------------------------------------------
	function exportOutletFlow(editDoc,outlet,exporter){
		let nextSeg,segType,expFunc;
		nextSeg=outlet.getLinkedSeg();
		while(nextSeg){
			segType=nextSeg.objDef.name;
			expFunc=segTypeExporters[segType];
			if(expFunc){
				expFunc(editDoc,nextSeg,exporter);
			}
			outlet=nextSeg.outlet;
			if(outlet){
				nextSeg=outlet.getLinkedSeg();
			}else{
				nextSeg=null;
			}
		}
	}

	//------------------------------------------------------------------------
	segTypeExporters["Entry"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		let name=seg.getAttr("id").val;
		let isAsync=seg.getAttrVal("async");
		let args=seg.getAttr("args").attrList;
		let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
		if((!name) || (!varNameRegex.test(name))){
			name="SEG"+seg.jaxId;
		}
		coder.maybeNewLine();
		coder.packBreakLine();
		if(comment){
			coder.packComment(comment);
		}
		coder.packText(`let ${name}=${isAsync?"async ":""}function(`);//TODO: add mark?
		{
			let arg;
			for(arg of args){
				coder.packText(arg.name+",");
			}
			coder.eatPreComa();
		}
		coder.packText(`){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			//localVals
			{
				let localVars,attr;
				localVars=seg.getAttr("localVars").attrList;
				for(attr of localVars){
					exporter.genLocalVar(attr,[]);
				}
			}
			coder.beginDocObjTagBlcok(seg,"Start");
			coder.endDocObjTagBlcok(seg,"Start",0);
			exportOutletFlow(editDoc,seg.outlet,exporter);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText("};");
		coder.newLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["Handler"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		let name=seg.getAttr("id").val;
		let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
		if((!name) || (!varNameRegex.test(name))){
			name="SEG"+seg.jaxId;
		}
		coder.maybeNewLine();
		coder.packBreakLine();
		if(comment){
			coder.packComment(comment);
		}
		coder.packText(`apiMap["${name}"]=async function(req, res){//:${seg.jaxId}`);//TODO: add mark?
		coder.indentMore();
		coder.newLine();
		{
			//localVals
			{
				let localVars,attr;
				localVars=seg.getAttr("localVars").attrList;
				for(attr of localVars){
					exporter.genLocalVar(attr,[]);
				}
			}
			coder.beginDocObjTagBlcok(seg,"Start");
			coder.endDocObjTagBlcok(seg,"Start",0);
			exportOutletFlow(editDoc,seg.outlet,exporter);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText("};");
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["Code"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		coder.beginDocObjTagBlcok(seg,"");
		coder.endDocObjTagBlcok(seg,"",0);
		coder.maybeNewLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["CodeBlock"]=
	function(editDoc,seg,exporter){
		let coder,prefix,postfix;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		prefix=seg.getAttrVal("prefix")||"";
		postfix=seg.getAttrVal("postfix")||"";
		coder.packText(`${prefix}{`);
		coder.indentMore();
		coder.newLine();
		{
			let outlet,bodySeg;
			outlet=seg.getAttr("catchlet");
			bodySeg=outlet.getLinkedSeg();
			if(bodySeg){
				if(seg.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(seg,"");
					coder.endDocObjTagBlcok(seg,"",0);
				}
				exportOutletFlow(editDoc,outlet,exporter);
				if(seg.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(seg,"Post");
					coder.endDocObjTagBlcok(seg,"Post",0);
				}
			}else{
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}${postfix}`);
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["Call"]=
	function(editDoc,seg,exporter){
		let coder,funcName,argPack,argsAttr,isAwait,assign,hasCode;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		funcName=seg.getAttrVal("callName");
		argPack=seg.getAttrVal("argPack");
		argsAttr=seg.getAttr("args");
		assign=seg.getAttrValText("assign");
		isAwait=seg.getAttrVal("await");
		hasCode=seg.getAttrVal("codes");

		if(hasCode && argPack==="Object"){
			coder.packText("{");
			coder.indentMore();
			coder.newLine();
			{
				let list,attr;
				list=argsAttr.attrList;
				coder.packText(`let $args={`);
				for(attr of list){
					coder.packText(`${attr.name}: `);
					exporter.genAttrStatement(attr);
					coder.packText(",");
				}
				coder.eatPreComa();
				coder.packText(`};`);
				coder.newLine();
				coder.beginDocObjTagBlcok(seg,"");
				coder.endDocObjTagBlcok(seg,"",0);
				if(assign){
					coder.packText(`${assign} = `);
				}
				if(isAwait){
					coder.packText(`await `);
				}
				coder.packText(`${funcName}($args);`);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			if(hasCode){
				coder.beginDocObjTagBlcok(seg,"Pre");
				coder.endDocObjTagBlcok(seg,"Pre",0);
			}
			if(assign){
				coder.packText(`${assign} = `);
			}
			if(isAwait){
				coder.packText(`await `);
			}
			coder.packText(`${funcName}(`);
			{
				let list,attr;
				list=argsAttr.attrList;
				if(argPack==="Normal"){
					for(attr of list){
						exporter.genAttrStatement(attr);
						coder.packText(",");
					}
					coder.eatPreComa();
				}else{
					coder.packText("{");
					for(attr of list){
						coder.packText(`${attr.name}: `);
						exporter.genAttrStatement(attr);
						coder.packText(",");
					}
					coder.eatPreComa();
					coder.packText("}");
				}
			}
			coder.packText(`);`);
		}
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["Return"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		let hasResult=seg.getAttrValText("result");
		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(seg.getAttrVal("codes")){
			coder.beginDocObjTagBlcok(seg,"");
			coder.endDocObjTagBlcok(seg,"",0);
		}
		if(hasResult){
			coder.packText(`return `);exporter.genAttrStatement(seg.getAttr("result"));coder.packText(";");
		}else{
			coder.packText(`return;`);
		}
		coder.maybeNewLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["Response"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		let resultAttr=seg.getAttr("result");
		let hasCode=seg.getAttrVal("codes");
		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(hasCode){
			coder.packText("{");
			coder.indentMore();
			coder.newLine();
			{
				coder.packText("let $r=");exporter.genAttrStatement(resultAttr);coder.packText(`;`);
				coder.beginDocObjTagBlcok(seg,"");
				coder.endDocObjTagBlcok(seg,"",0);
				coder.packText(`res.json($r);`);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			coder.packText(`res.json(`);exporter.genAttrStatement(resultAttr);coder.packText(`);`);
		}
		coder.maybeNewLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["Condition"]=
	function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		let i,n,cdnList,cdn;

		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		cdnList=seg.outletsList;
		n=cdnList.length;
		for(i=0;i<n;i++){
			cdn=cdnList[i];
			if(i===0){
				coder.packText(`if(`);
			}else{
				coder.packText(`}else if(`);
			}
			coder.packText(cdn.getAttrVal("condition"));
			coder.packText(`){`);
			coder.indentMore();
			coder.newLine();
			{
				let nextSeg;
				nextSeg=cdn.getLinkedSeg();
				if(nextSeg){
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"");
						coder.endDocObjTagBlcok(cdn,"",0);
					}
					exportOutletFlow(editDoc,cdn,exporter);
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"Post");
						coder.endDocObjTagBlcok(cdn,"Post",0);
					}
				}else{
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"");
						coder.endDocObjTagBlcok(cdn,"",0);
					}
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
		}
		cdn=seg.catchlet;
		if(cdn.getAttrVal("codes")||cdn.getLinkedSeg()){
			coder.packText(`}else{`);
			coder.indentMore();
			coder.newLine();
			{
				let nextSeg;
				nextSeg=cdn.getLinkedSeg();
				if(nextSeg){
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"");
						coder.endDocObjTagBlcok(cdn,"",0);
					}
					exportOutletFlow(editDoc,cdn,exporter);
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"Post");
						coder.endDocObjTagBlcok(cdn,"Post",0);
					}
				}else{
					if(cdn.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(cdn,"");
						coder.endDocObjTagBlcok(cdn,"",0);
					}
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText(`}`);
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["Switch"]=
	function(editDoc,seg,exporter){
		let i,n,csList,csObj,csText,cdn,cmt;
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;

		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		coder.packText(`switch(${seg.getAttrVal("expression")}){`);
		coder.indentMore();
		coder.newLine();
		{
			csList=seg.outletsList;
			n=csList.length;
			for(i=0;i<n;i++){
				csObj=csList[i];
				cmt=csObj.getAttrVal("desc");
				if(cmt){
					coder.packComment(cmt);
				}
				cdn=csObj.getAttrVal("condition");
				if(!cdn||cdn==="default"){
					if(csObj.getAttrVal("merge")){
						coder.packText(`default:`);
						coder.newLine();
						continue;
					}
					coder.packText(`default:{`);
				}else{
					if(csObj.getAttrVal("merge")){
						coder.packText(`case ${cdn}:`);
						coder.newLine();
						continue;
					}
					coder.packText(`case ${cdn}:{`);
				}
				coder.indentMore();
				coder.newLine();
				{
					let nextSeg;
					nextSeg=csObj.getLinkedSeg();
					if(nextSeg){
						if(csObj.getAttrVal("codes")){
							coder.beginDocObjTagBlcok(csObj,"");
							coder.endDocObjTagBlcok(csObj,"",0);
						}
						exportOutletFlow(editDoc,csObj,exporter);
						if(csObj.getAttrVal("codes")){
							coder.beginDocObjTagBlcok(csObj,"Post");
							coder.endDocObjTagBlcok(csObj,"Post",0);
						}
					}else{
						if(csObj.getAttrVal("codes")){
							coder.beginDocObjTagBlcok(csObj,"");
							coder.endDocObjTagBlcok(csObj,"",0);
						}
					}
				}
				if(csObj.getAttrVal("break")){
					coder.packText(`break;`);
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["LoopObj"]
	=function(editDoc,seg,exporter){
		let coder,arrayName,labelName,valName,loopMode,letVal;
		if(seg.exportVsn===exportVsn){
			return;
		}
		arrayName=seg.getAttrVal("loopObj");
		labelName=seg.getAttrVal("label");
		valName=seg.getAttrVal("loopVal");
		loopMode=seg.getAttrVal("loopMode");
		letVal=seg.getAttrVal("letVal");
		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(labelName){
			coder.packText(`${labelName}:{`);
			coder.indentMore();
			coder.newLine();
		}
		coder.packText(`for(${letVal?"let ":""}${valName} ${loopMode} ${arrayName}){`);
		coder.indentMore();
		coder.newLine();
		{
			let outlet,loopSeg;
			outlet=seg.getAttr("catchlet");
			loopSeg=outlet.getLinkedSeg();
			if(loopSeg){
				if(seg.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(seg,"");
					coder.endDocObjTagBlcok(seg,"",0);
				}
				exportOutletFlow(editDoc,outlet,exporter);
				if(seg.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(seg,"Post");
					coder.endDocObjTagBlcok(seg,"Post",0);
				}
			}else{
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
		}
		coder.maybeNewLine();
		coder.indentLess();
		coder.packText(`}`);

		if(labelName){
			coder.maybeNewLine();
			coder.indentLess();
			coder.packText(`}`);
		}
		coder.newLine();
	};
	
	//----------------------------------------------------------------------------
	segTypeExporters["TryCatch"]
	=function(editDoc,seg,exporter){
		let coder;
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		coder.maybeNewLine();
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		coder.packText(`try{`);
		coder.indentMore();
		coder.newLine();
		{
			let outlet,nextSeg;
			outlet=seg.getAttr("outlets").getAttr("try");
			nextSeg=outlet.getLinkedSeg();
			if(nextSeg){
				if(outlet.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(outlet,"");
					coder.endDocObjTagBlcok(outlet,"",0);
				}
				exportOutletFlow(editDoc,outlet,exporter);
				if(outlet.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(outlet,"Post");
					coder.endDocObjTagBlcok(outlet,"Post",0);
				}
			}else{
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}catch(error){`);
		coder.indentMore();
		coder.newLine();
		{
			let outlet,nextSeg;
			outlet=seg.getAttr("outlets").getAttr("catch");
			nextSeg=outlet.getLinkedSeg();
			if(nextSeg){
				if(outlet.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(outlet,"");
					coder.endDocObjTagBlcok(outlet,"",0);
				}
				exportOutletFlow(editDoc,outlet,exporter);
				if(outlet.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(outlet,"Post");
					coder.endDocObjTagBlcok(outlet,"Post",0);
				}
			}else{
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["DBFindOne"]=
	function(editDoc,seg,exporter){
		let coder;
		let tabName=seg.getAttrVal("collection");
		let queryVal=seg.getAttr("query");
		let projectVal=seg.getAttr("project");
		let assign=seg.getAttrValText("assign");
		let hasCode=seg.getAttrVal("codes");
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(hasCode){
			coder.packText("{");
			coder.indentMore();
			coder.newLine();
			{
				coder.packText("let $q=");exporter.genAttrStatement(queryVal);coder.packText(";");coder.newLine();
				if(projectVal){
					coder.packText("let $p=");exporter.genAttrStatement(projectVal);coder.packText(";");coder.newLine();
				}
				coder.beginDocObjTagBlcok(seg,"Pre");
				coder.endDocObjTagBlcok(seg,"Pre",0);
				if(projectVal){
					coder.packText(`${assign}=await ${tabName}.findOne($q,$p);`);
				}else{
					coder.packText(`${assign}=await ${tabName}.findOne($q);`);
				}
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			coder.packText(`${assign}=await ${tabName}.findOne(`);
			exporter.genAttrStatement(queryVal);
			if(projectVal){
				coder.packText(",");
				exporter.genAttrStatement(projectVal);
			}
			coder.packText(`);`);
		}
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	segTypeExporters["DBUpdateOne"]=
	function(editDoc,seg,exporter){
		let coder;
		let tabName=seg.getAttrVal("collection");
		let queryVal=seg.getAttr("query");
		let updateVal=seg.getAttr("update");
		let isAwait=seg.getAttrVal("await");
		let hasCode=seg.getAttrVal("codes");
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(hasCode){
			coder.indentMore();
			coder.newLine();
			{
				coder.packText("let $q=");exporter.genAttrStatement(queryVal);coder.packText(";");coder.newLine();
				coder.packText("let $u=");exporter.genAttrStatement(updateVal);coder.packText(";");coder.newLine();
				coder.beginDocObjTagBlcok(seg,"Pre");
				coder.endDocObjTagBlcok(seg,"Pre",0);
				if(isAwait){
					coder.packText(`await `);
				}
				coder.packText(`${tabName}.updateOne($q,$u);`);
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			if(isAwait){
				coder.packText(`await `);
			}
			coder.packText(`${tabName}.updateOne(`);
			exporter.genAttrStatement(queryVal);
			coder.packText(",");
			exporter.genAttrStatement(updateVal);
			coder.packText(`);`);
		}
		coder.newLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["DBInsertOne"]=
	function(editDoc,seg,exporter){
		let coder;
		let tabName=seg.getAttrVal("collection");
		let objVal=seg.getAttr("item");
		let isAwait=seg.getAttrVal("await");
		let hasCode=seg.getAttrVal("codes");
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(hasCode){
			coder.packText("{");
			coder.indentMore();
			coder.newLine();
			{
				coder.packText("let $o=");exporter.genAttrStatement(objVal);coder.packText(";");coder.newLine();
				coder.beginDocObjTagBlcok(seg,"Pre");
				coder.endDocObjTagBlcok(seg,"Pre",0);
				if(isAwait){
					coder.packText(`await `);
				}
				coder.packText(`${tabName}.insert($o);`);
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			if(isAwait){
				coder.packText(`await `);
			}
			coder.packText(`${tabName}.insert(`);
			exporter.genAttrStatement(objVal);
			coder.packText(`);`);
		}
		coder.newLine();
	};

	//------------------------------------------------------------------------
	segTypeExporters["DBDeleteOne"]=
	function(editDoc,seg,exporter){
		let coder;
		let tabName=seg.getAttrVal("collection");
		let queryVal=seg.getAttr("query");
		let isAwait=seg.getAttrVal("await");
		let hasCode=seg.getAttrVal("codes");
		if(seg.exportVsn===exportVsn){
			return;
		}
		seg.exportVsn=exportVsn;
		coder=exporter.coder;
		{
			let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
			if(comment){
				coder.maybeGapLine();
				coder.packComment(comment);
			}
		}
		if(hasCode){
			coder.indentMore();
			coder.newLine();
			{
				coder.packText("let $q=");exporter.genAttrStatement(queryVal);coder.packText(";");coder.newLine();
				coder.beginDocObjTagBlcok(seg,"Pre");
				coder.endDocObjTagBlcok(seg,"Pre",0);
				if(isAwait){
					coder.packText(`await `);
				}
				coder.packText(`${tabName}.deleteOne($q);`);
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("}");
		}else{
			if(isAwait){
				coder.packText(`await `);
			}
			coder.packText(`${tabName}.deleteOne(`);
			exporter.genAttrStatement(queryVal);
			coder.packText(`);`);
		}
		coder.newLine();
	};
}



