import {VFACT} from "/@vfact";
import {EditPrj,EditPrjObjDef} from "../EditPrj.js";
import {DocBackEnd} from "./EditBackEndDoc.js";
import {EditBackEndFlowSeg} from "./EditBackEndFlowSeg.js";
import {} from "./EditBackEndSegDef.js";
import {} from "./EditBackEndDocExporter.js";
import {UIEditWithCanvas} from "../ui/UIEditWithCanvas.js";
import {UIAICanvas} from "../ui/UIAICanvas.js";
let $ln=VFACT.lanCode||"EN";

//Inject new attr:
{
	let oldAttrs=EditPrjObjDef.attrs;
	let newAttrs={};
	for(let name in oldAttrs){
		if(name==="docGears"){
			newAttrs.docHandlers={
				name:"docHandlers",showName:(($ln==="CN")?("请求处理器"):/*EN*/("Request Handlers")),icon:"folder.svg",type:"object",def:"DocsObj",docType:"DocBackEnd",dir:"handlers",fileExt:".mjs",
				key:1,fixed:1,edit:false,navi:"prj",
				
			};
		}
		newAttrs[name]=oldAttrs[name];
	};
	EditPrjObjDef.attrs=newAttrs;
}
//Hide Nouse NaviPrj entries:
{
	let prjAttrs=EditPrjObjDef.attrs;
	prjAttrs["cssFiles"].navi="";
	prjAttrs["docConfig"].navi="";
	prjAttrs["docGears"].navi="";
	prjAttrs["docViews"].navi="";
	prjAttrs["docApp"].navi="";
	prjAttrs["docAIAgents"].navi="";
}

//:Doc edtior:
{
	let curEditor=null;
	let uiCanvas=null;
	//------------------------------------------------------------------------
	let UIBackEndDoc=function(app){
		return UIAICanvas(app,EditBackEndFlowSeg);
	};

	//------------------------------------------------------------------------
	UIBackEndDoc.scoreDoc=function(doc){
		let editDoc;
		editDoc=doc.codyDoc;
		if(editDoc && editDoc.isBackEndDoc){
			return 100;
		}
		return 0;
	};

	//------------------------------------------------------------------------
	UIBackEndDoc.bindToEditor=function(docEditor){
		if(!uiCanvas){
			let def;
			curEditor=docEditor;
			def=UIAICanvas(docEditor.app,EditBackEndFlowSeg,true);
			uiCanvas=curEditor.BoxCanvas.appendNewChild(def);
			uiCanvas.hold();
			uiCanvas.bindToEditor(curEditor);
			return uiCanvas;
		}
		if(curEditor){
			if(curEditor===docEditor){
				uiCanvas.rebindToEditor && uiCanvas.rebindToEditor();
				return uiCanvas;
			}
			uiCanvas.saveDocState();
			curEditor.BoxCanvas.removeChild(uiCanvas);
		}
		curEditor=docEditor;
		if(curEditor){
			curEditor.BoxCanvas.appendChild(uiCanvas);
			uiCanvas.bindToEditor(curEditor);
			return uiCanvas;
		}
		return null;
	};
	
	//Reigster AI-Edit-Canvas:
	UIEditWithCanvas.regCanvas(UIBackEndDoc);
}