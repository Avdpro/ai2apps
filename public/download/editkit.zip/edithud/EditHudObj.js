import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
import inherits from "/@inherits";
import {esprima} from "/@tabos/utils/esprima.mjs";
import {VFACT} from "/@vfact";

const $ln=VFACT.lanCode;
//****************************************************************************
//Default def:
//****************************************************************************
let HudArrayDef,HudObjShellAttr;
{
	HudArrayDef={elementType:"hudobj",allowExtraAttr:1};

	HudObjShellAttr={
		"subHuds":{
			name:"subHuds",type:"array",def:HudArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"faces":{
			name:"faces",showName:"Faces",type:"object",key:1,fixed:1,navi:"doc",edit:false,
			def:{
				attrs:{},attrType:"hudface",attrTypeDef:"HudFace",
				objAttrs:{isFacesEntry:1,renameAttr:null},
			},
		},
		"functions":{
			name:"functions",showName:"Functions",type:"object",def:"Functions",key:1,fixed:1,navi:"doc",edit:1,
		},
		"extraPpts":{
			name:"extraPpts",showName:(($ln==="CN")?("附加属性"):/*EN*/("Extra Properties")),type:"object",def:"Object",key:1,fixed:1,navi:"doc",edit:1,
		},
		"mockup":{name:"mockup",showName:(($ln==="CN")?("仅供展示"):/*EN*/("Mockup Item")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false},
		"codes":{name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false},
		"locked":{name:"locked",showName:(($ln==="CN")?("位置尺寸锁定"):/*EN*/("Lock Pose")),type:"bool",initVal:false,vals:(($ln==="CN")?(["未锁定","已锁定"]):/*EN*/(["Not Locked","Locked"])),key:1,fixed:1,edit:1,rawEdit:false},
		"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:true,rawEdit:false},
		"nameVal":{name:"nameVal",showName:(($ln==="CN")?("控件名变量"):/*EN*/("ID Name Variable")),type:"bool",initVal:false,key:1,fixed:1,edit:true,rawEdit:false}
	};
}

//****************************************************************************
//Constructor and static functions:
//****************************************************************************
let EditHudObj,editHudObj;
{
	//----------------------------------------------------------------------------
	EditHudObj=function(owner,def,init){
		let ppts,self;
		self=this;
		EditObj.call(this,owner,def,true);
		this.isHudObj=1;
		ppts=this.properties=this.getAttr("properties");
		this.extraPpts=this.getAttr("extraPpts");
		this.faces=this.getAttr("faces");
		this.subHuds=this.getAttr("subHuds");
		this.functions=this.getAttr("functions");
		this.mockup=this.getAttr("mockup");
		this.hasCodes=this.getAttr("codes");
		this.locked=this.getAttr("locked");
		//container:
		this.attrContainer=this.getAttr("container");
		this.isContainer=!!this.attrContainer.val;
		this.attrContainer.traceOn(()=>{
			self.isContainer=!!self.attrContainer.val;
		});

		//exposeName:
		this.exposeNameVal=this.getAttr("nameVal");
		this.isExposeNameVal=!!this.exposeNameVal.val;
		this.exposeNameVal.traceOn(()=>{
			self.isExposeNameVal=!!self.exposeNameVal.val;
			self.emitObjChange();
		});
		
		this.curFace=null;
		this.facePpt2Attr=null;

		//live-obj
		this.liveEdObj=null;

		//Handle subHuds modify events:
		this.subHuds.on("AttrAdd",(...args)=>{self.OnSubAdd(...args);this.emit("AttrAdd",...args)});
		this.subHuds.on("AttrInsert",(...args)=>{self.OnSubInsert(...args);this.emit("AttrInsert",...args)});
		this.subHuds.on("AttrRemove",(...args)=>{self.OnSubRemove(...args);this.emit("AttrRemove",...args)});
		this.subHuds.on("AttrMoveUp",(...args)=>{self.OnSubMoveUp(...args);this.emit("AttrMoveUp",...args)});
		this.subHuds.on("AttrMoveDown",(...args)=>{self.OnSubMoveDown(...args);this.emit("AttrMoveDown",...args)});

		//Handle properties change:
		ppts.on("AttrChanged",(...args)=>{self.OnPptChange(...args);});
		ppts.on("AttrAdd",(...args)=>{self.OnPptAdd(...args);});
		ppts.on("AttrRemove",(...args)=>{self.OnPptRemove(...args);});
		ppts.on("ObjChanged",()=>{self.emitObjChange()});

		this.attrId=ppts.getAttr("id");
		this.attrId.traceOn(()=>{
			this.emitChanged();
		});
	};
	inherits(EditHudObj,EditObj);
	EditAttr.regAttrType("hudobj",EditHudObj);
	editHudObj=EditHudObj.prototype;

	var hudDefRegs={};
	var hudCatalogRegs={
		"Basic":{},"Texts":{},"Buttons":{},"Inputs":{},"Containers":{},"Medias":{},"Views":{},"Gears":{},"ExternGears":{},"View":{},
		"GearTemplates":{},"ViewTemplates":{},
	};
	
	EditHudObj.regCatalogHudDef=function(catalog,name,def){
		let reg;
		if(!catalog)
			return;
		if(catalog.indexOf(",")>0){
			let list=catalog.split(",");
			for(catalog of list){
				if(catalog){
					EditHudObj.regCatalogHudDef(catalog.trim(),name,def);
				}
			}
			return;
		}
		reg=hudCatalogRegs[catalog];
		if(!reg){
			hudCatalogRegs[catalog]=reg={};
		}
		if(def){
			reg[name]=def;
		}else{
			delete reg[name];
		}
	};
	EditHudObj.regHudDef=function(name,def){
		if(def){
			hudDefRegs[name]=def;
		}else{
			delete hudDefRegs[name];
		}
	};
	EditHudObj.getDef=EditHudObj.getHudDef=function(name){
		return hudDefRegs[name];
	};
	EditHudObj.getDefList=EditHudObj.getHudDefs=function(){
		return Object.values(hudDefRegs);
	};
	EditHudObj.getCatalogDefs=function(catalog){
		let defs= hudCatalogRegs[catalog];
		if(defs){
			return Object.values(defs);
		}
		return [];
	};
	EditHudObj.getCatalogs=function(){
		return Object.keys(hudCatalogRegs);
	};
}

//----------------------------------------------------------------------------
editHudObj.OnDocFocus=function(){
	let list,hud;
	list=this.subHuds.attrList;
	for(hud of list){
		hud.OnDocFocus();
	}
};

//****************************************************************************
//:Sub hud Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//If func return false, stop...
	editHudObj.runOnAllHuds=function(func,hasGearSlot,...args){
		let list,hud;
		if(func(this,...args)===false){
			return;
		}
		list=this.subHuds.attrList;
		for(hud of list){
			hud.runOnAllHuds(func,hasGearSlot,...args);
		}
	};
	
	//------------------------------------------------------------------------
	editHudObj.runOnSubHuds=function(func,...args){
		let list,hud;
		list=this.subHuds.attrList;
		for(hud of list){
			func(hud,...args);
		}
	};
	
	//------------------------------------------------------------------------
	editHudObj.addSubHud=function(def){
		return this.subHuds.addAttr({type:"hudobj",def:def});
	};
}

//****************************************************************************
//:Face access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editHudObj.enterFaceEdit=function(faceTag,applyAttrs,notifyUsed=true){
		let face,subs,sub,ppt2Attr,faceState,valText;
		face=this.curFace;
		if(!face){
			this.facePpt2Attr=ppt2Attr={...this.properties.attrHash};
		}else{
			if(!face.attrList.length && !face.anis.attrList.length){
				//Remove this empty face:
				this.faces.removeAttr(face);
			}
			ppt2Attr=this.facePpt2Attr;
		}
		face=this.faces.getAttr(faceTag.faceTagId);
		//Update liveHudObj's ppt if there is state change:
		faceState=faceTag.getAttr("state");
		if(faceState){
			let name,attr,liveObj;
			liveObj=this.liveEdObj;
			for(name in ppt2Attr){
				attr=ppt2Attr[name];
				if(attr.hyper){
					valText=attr.valText;
					if(valText[0]==="$"){
						if(valText.endsWith("},state")){
							attr.setValByText(valText);
							liveObj[name]=attr.val;
						}
					}
				}
			}
		}
		if(!face){
			let def;
			def={name:faceTag.faceTagId,type:"hudface",def:"HudFace",faceTag:faceTag,extraAttr:1};
			face=this.faces.addAttr(def);
			//face has no active attr
			//TODO: Emit unuse message
		}else if(applyAttrs){
			let liveObj,attrList,attr,attrDef,attrName,val;
			liveObj=this.liveEdObj;
			if(liveObj){
				attrList=face.faceAttrList;
				for(attr of attrList){
					attrDef=attr.def;
					if(!attrDef.notLiveVal){
						ppt2Attr[attr.name]=attr;
						attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
						if("liveVal" in attrDef){
							val=attrDef.liveVal;
							if(val instanceof Function){
								val=val(attr);
							}
							liveObj[attrName]=val;
						}else{
							liveObj[attrName]=attr.val;
						}
						
					}
				}
			}
			if(notifyUsed && (face.faceAttrList.length||face.anis.attrList.length)){
				this.doc.emit("FaceOnUsed",this);
			}
		}
		this.curFace=face;
		subs=this.subHuds.attrList;
		for(sub of subs){
			sub.enterFaceEdit(faceTag,applyAttrs,notifyUsed);
		}
		this.emit("FaceOn");
	};
	
	//------------------------------------------------------------------------
	editHudObj.exitFaceEdit=function(updateAttr=true){
		let face,subs,sub;
		let liveObj,ppts,attrName,attrDefs,attrDef,attr,val,liveAttrName;
		face=this.curFace;
		if(face && !face.faceAttrList.length && !face.anis.attrList.length){
			this.faces.removeAttr(face);
		}
		this.curFace=null;
		this.facePpt2Attr=null;
		
		//Reset all attr of live-ed-object
		liveObj=this.liveEdObj;
		if(liveObj && updateAttr){
			if(liveObj.id==="BtnReload"){
				this.curFace=null;
			}
			ppts=this.properties.attrHash;
			attrDefs=this.properties.objDef.attrs;
			for(attrName in attrDefs){
				attrDef=attrDefs[attrName];
				if(!attrDef.extraAttr && !attrDef.notLiveVal){
					attr=ppts[attrName];
					if(attr){
						if(attrDef.liveVal){
							val=attrDef.liveVal;
							if(val instanceof Function){
								val=val(attr);
							}
						}else{
							if(attr.hyper){
								attr.setValByText(attr.valText);
							}
							val=attr.val;
						}
					}else{
						if(attrDef.liveVal){
							val=attrDef.liveVal;
							if(val instanceof Function){
								val=val(null,this.properties);
							}
						}else{
							val=attrDef.initVal;
						}
					}
					attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
					if(liveObj[attrName]!==val){
						liveObj[attrName]=val;
					}
				}
			}
		}

		subs=this.subHuds.attrList;
		for(sub of subs){
			sub.exitFaceEdit(updateAttr);
		}
		this.emit("FaceOff");
	};
	
	//------------------------------------------------------------------------
	editHudObj.updateFaceState=function(faceTag,init=false){
		let sub,subs,ppt2Attr,liveObj;
		ppt2Attr=this.facePpt2Attr;
		liveObj=this.liveEdObj;
		if(init && !ppt2Attr){
			this.facePpt2Attr=ppt2Attr={...this.properties.attrHash};
		}
		if(ppt2Attr && liveObj){
			let name,attr,valText;
			for(name in ppt2Attr){
				attr=ppt2Attr[name];
				if(attr.hyper){
					valText=attr.valText;
					if(valText[0]==="$"){
						if(valText.endsWith("},state")){
							attr.setValByText(valText);
							liveObj[name]=attr.val;
						}
					}
				}
			}
		}
		subs=this.subHuds.attrList;
		for(sub of subs){
			sub.updateFaceState(faceTag,init);
		}
	};
}

//****************************************************************************
//:Live Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Create a JAXHudObj as child of [fatherHud], with [args] as createArgs
	editHudObj.genHudCSS=function(hyper){
		let hudCSS;
		let subHuds,i,n;
		let stateObj,statePpts,traceFunc,exStatePpts;
		//Basic properties:
		hudCSS=ExportObj.export(this.properties,hyper);
		hudCSS.hash=this.jaxId;
		hudCSS.$inEditor=true;
		
		//Children huds:
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		if(subHuds.length>0){
			let items;
			hudCSS.children=items=[];
			for(i=0;i<n;i++){
				items[i]=subHuds[i].genHudCSS(hyper);
			}
		}
		return hudCSS;
	};

	//------------------------------------------------------------------------
	editHudObj.bindLiveObj=function(liveObj,assignAttr,inTree){
		let subHuds,items,i,n;
		if(this.liveEdObj){
			this.dropLiveObj(this.liveEdObj);
		}
		this.liveEdObj=liveObj;
		subHuds=this.subHuds.attrList;
		items=liveObj.children;
		n=subHuds.length;
		if(items){
			if(items.length!==n){
				throw new Error("EditHudObj subHuds number not match live-obj's sub-items number.");
			}
			for(i=0;i<n;i++){
				subHuds[i].bindLiveObj(items[i],assignAttr,true);
			}
		}
	};

	//------------------------------------------------------------------------
	editHudObj.dropLiveObj=function(liveObj,inTree=false){
		let subHuds,i,n;
		if(liveObj && liveObj!==this.liveEdObj){
			return;
		}
		this.liveEdObj=null;
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		for(i=0;i<n;i++){
			subHuds[i].dropLiveObj(null,true);
		}
		return;
	};
	
	//------------------------------------------------------------------------
	editHudObj.rebuildLiveObj=function(){
		let oldObj,hudCSS,newObj;
		oldObj=this.liveEdObj;
		if(oldObj){
			hudCSS=this.genHudCSS(this.doc);
			if(!hudCSS.faces){
				hudCSS.faces={};
			}
			newObj=oldObj.parent.insertNewBefore(hudCSS,oldObj);
			oldObj.parent.removeChild(oldObj);
			this.bindLiveObj(newObj);
		}
	};
}

//****************************************************************************
//:Handle edit events 
//****************************************************************************
{
	//------------------------------------------------------------------------
	editHudObj.OnPptChange=function(attr){
		if(this.liveEdObj){
			let attrDef,attrName,val;
			attrDef=attr.def;
			if(attrDef.notLiveVal){
				return;
			}
			attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
			if("liveVal" in attrDef){
				val=attrDef.liveVal;
				if(val instanceof Function){
					val=val(attr);
				}
				this.liveEdObj[attrName]=val;
			}else{
				this.liveEdObj[attrName]=attr.val;
			}
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnPptAdd=function(attr){
		if(this.liveEdObj){
			let attrDef,attrName,val;
			attrDef=attr.def;
			if(attrDef.notLiveVal){
				return;
			}
			attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
			if("liveVal" in attrDef){
				val=attrDef.liveVal;
				if(val instanceof Function){
					val=val(attr);
				}
				this.liveEdObj[attrName]=val;
			}else{
				this.liveEdObj[attrName]=attr.val;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editHudObj.OnPptRemove=function(attr){
		if(this.liveEdObj){
			let attrDef,attrName,val;
			attrDef=attr.def;
			if(attrDef.notLiveVal){
				return;
			}
			attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
			if("liveVal" in attrDef){
				val=attrDef.liveVal;
				if(val instanceof Function){
					val=val(null);
				}
				this.liveEdObj[attrName]=val;
			}else{
				this.liveEdObj[attrName]=attr.def.initVal;
			}
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnPptInsert=function(attr,idx){
		if(this.liveEdObj){
			let attrDef,attrName,val;
			attrDef=attr.def;
			if(attrDef.notLiveVal){
				return;
			}
			attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
			if("liveVal" in attrDef){
				val=attrDef.liveVal;
				if(val instanceof Function){
					val=val(attr);
				}
				this.liveEdObj[attrName]=val;
			}else{
				this.liveEdObj[attrName]=attr.val;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editHudObj.OnThisHudAdd=function(){
		let list,hud;
		list=this.subHuds.attrList;
		for(hud of list){
			hud.OnThisHudAdd && hud.OnThisHudAdd();
		}
	};
	
	//------------------------------------------------------------------------
	editHudObj.OnThisHudRemove=function(){
		let list,hud;
		list=this.subHuds.attrList;
		for(hud of list){
			hud.OnThisHudRemove && hud.OnThisHudRemove();
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnSubAdd=function(subHud){
		subHud.OnThisHudAdd && subHud.OnThisHudAdd();
		if(this.liveEdObj){
			let css,liveObj;
			css=subHud.genHudCSS(this.doc);
			liveObj=this.liveEdObj.appendNewChild(css);
			subHud.bindLiveObj(liveObj);
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnSubInsert=function(subHud,idx){
		subHud.OnThisHudAdd && subHud.OnThisHudAdd();
		if(this.liveEdObj){
			let css,liveObj,nextHud;
			css=subHud.genHudCSS(this.doc);
			nextHud=this.liveEdObj.children[idx];
			if(nextHud){
				liveObj=this.liveEdObj.insertNewBefore(css,nextHud);
			}else{
				liveObj=this.liveEdObj.appendNewChild(css);
			}
			subHud.bindLiveObj(liveObj);
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnSubRemove=function(subHud){
		subHud.OnThisHudRemove && subHud.OnThisHudRemove();
		if(this.liveEdObj){
			let liveObj;
			liveObj=subHud.liveEdObj;
			if(liveObj){
				this.liveEdObj.removeChild(liveObj);
			}
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnSubMoveUp=function(subHud){
		if(this.liveEdObj){
			let liveObj,preObj;
			liveObj=subHud.liveEdObj;
			if(liveObj){
				preObj=liveObj.previousSibling;
				if(preObj){
					liveObj.hold();
					this.liveEdObj.removeChild(liveObj);
					this.liveEdObj.insertBefore(liveObj,preObj);
					liveObj.release();
				}
			}
		}
	};

	//------------------------------------------------------------------------
	editHudObj.OnSubMoveDown=function(subHud){
		let liveObj,nxtObj;
		liveObj=subHud.liveEdObj;
		if(liveObj){
			nxtObj=liveObj.nextSibling;
			if(nxtObj){
				nxtObj.hold();
				this.liveEdObj.removeChild(nxtObj);
				this.liveEdObj.insertBefore(nxtObj,liveObj);
				nxtObj.release();
			}
		}
	};
}

//****************************************************************************
//:I/O
//****************************************************************************
{
	//Seems no overwrite funcion code needed		
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editHudObj.getName=function(){
		let id;
		id=this.properties.getAttr("id").val;
		id=id||"";
		return `${id}[${this.objDef.showName}]`;
	};
	
	//------------------------------------------------------------------------
	//Return sub-hud-nodes:
	editHudObj.getNaviSubList=function(){
		let slist,tlist,i,n,attr,navi;
		tlist=[];
		slist=this.subHuds.attrList;
		n=slist.length;
		for(i=0;i<n;i++){
			attr=slist[i];
			tlist.push(attr);
		}
		return tlist.length?tlist:null;
	};
	
	//------------------------------------------------------------------------
	editHudObj.getEditRootPpts=function(){
		let list,events,exposeContainer;
		if(this.curFace){
			return [{obj:this.curFace,open:true}];
		}
		events=this.getAttr("events");
		exposeContainer=this.getAttr("exposeContainer");
		list=[
			{attr:this.prj.docApp.attrLocalize},
			{attr:this.prj.docApp.attrLanguage},
			{attr:this.locked},{obj:this.properties,open:true},{attr:this.exposeNameVal},{attr:this.attrContainer},{obj:this.extraPpts,open:false},{attr:this.mockup},{attr:this.hasCodes}
		];
		if(exposeContainer){
			list.push({attr:exposeContainer});
		}
		list.push({obj:this.functions,open:false});
		if(events){
			list.push({obj:events,open:false});
		}
		return list;
	};
}

//****************************************************************************
//UIForge utility functions:
//****************************************************************************
{
	let chk0=/(^")|(^')|(^`)/;//Is an JSON string?
	let chk1=/(^\d\d*%$)/;//aa%
	let chk2=/(^\d\dpx*)|(^\d\d*$)/;//100px or 100
	let chk3=/^\d\d*%\s*[+]\s*\d\d*$/;//aa%+b
	let chk3_1=/^\d\d*%\s*[-]\s*\d\d*$/;//aa%-b
	let chk4=/^calc\([.0-9\+\-\*\/\%\s\w]+\)$/;//calc(100% + 100px)
	let chk4_1=/.*\s+[+]\s+\d+px\s*\)$/;//cal(100% + 100px)
	let chk4_2=/.*\s+[-]\s+\d+px\s*\)$/;//cal(100% + 100px)
	
	//------------------------------------------------------------------------
	editHudObj.getMoveHudTexts=function(dx,dy,dw,dh){
		var attr,esp,ppts;
		let txtX,txtY,txtW,txtH;
		const MODE_NUM=0;
		const MODE_TEXT=1;
		const MODE_HYPER=2;
		const SHELL_NONE=0;
		const SHELL_HASH=1;
		const SHELL_HYPER=2;

		ppts=this.properties;
		esp=esprima;
		function maybeBrackets(text,tokens,n){
			if(n>2 && tokens[0].value==="(" && tokens[n-1].value===")"){
				return text;
			}
			return "("+text+")";
		}
		function maybeNotBrackets(text,tokens,n){
			if(n>2 && tokens[0].value==="(" && tokens[n-1].value===")"){
				return text.substring(tokens[1].range[0],tokens[n - 1].range[0]);
			}
			return text;
		}

		function moveAttr(attr,d){
			let oldText,oldVal,valType,attrText,val,mode,shell,newText,tokens,n,hyper,hyperPostfix;

			hyper=false;
			shell=SHELL_NONE;
			oldText=attrText=attr.valText.trim();
			oldVal=attr.val;
			val=parseFloat(attrText);
			if((val>=0 || val<0)&&val===oldVal){
				//Just a number:
				val+=d;
				return ""+val;
			}
			if(chk1.test(attrText)){//100%
				if(d>0){
					return attrText+" + "+d;
				}else if(d<0){
					return attrText+" - "+(-d);
				}
				return attrText;
			}
			//100% + 100 or 100%-100
			{
				if(chk3.test(attrText)){//100%+100
					let pos=attrText.indexOf("+");
					let num;
					num=parseFloat(attrText.substring(pos+1).trim());
					num+=d;
					if(num>0){
						return `${attrText.substring(0,pos)} + ${num}`;
					}else if(num===0){
						return `${attrText.substring(0,pos)}`;
					}
					return `${attrText.substring(0,pos)} - ${-num}`;
				}

				if(chk3_1.test(attrText)){//100%-100
					let pos=attrText.indexOf("-");
					let num;
					num=-parseFloat(attrText.substring(pos+1).trim());
					num+=d;
					if(num>0){
						return `${attrText.substring(0,pos)} + ${num}`;
					}else if(num===0){
						return `${attrText.substring(0,pos)}`;
					}
					return `${attrText.substring(0,pos)} - ${-num}`;
				}
			}
			
			//calc(...)
			if(chk4.test(attrText)){
				let pos,num;
				if(chk4_1.test(attrText)){
					pos=attrText.lastIndexOf("+");
					num=parseFloat(attrText.substring(pos+1));
					num+=d;
					if(num>0){
						attrText=attrText.substring(0,pos)+"+ "+num+"px)";
					}else if(num<0){
						attrText=attrText.substring(0,pos)+"- "+(-num)+"px)";
					}else{
						attrText=attrText.substring(0,pos).trimRight()+")";
					}
					return attrText;
				}else if(chk4_2.test(attrText)){
					pos=attrText.lastIndexOf("-");
					num=-parseFloat(attrText.substring(pos+1));
					num+=d;
					if(num>0){
						attrText=attrText.substring(0,pos)+"+ "+num+"px)";
					}else if(num<0){
						attrText=attrText.substring(0,pos)+"- "+(-num)+"px)";
					}else{
						attrText=attrText.substring(0,pos).trimRight()+")";
					}
					return attrText;
				}else{
					if(d>0){
						attrText=attrText.substring(0,attrText.length-1).trim()+" + "+d+"px)";
					}else if(d<0){
						attrText=attrText.substring(0,attrText.length-1).trim()+" - "+(-d)+"px)";
					}
					return attrText;
				}
			}
			
			//Find the "real" attrText:
			if(attrText.startsWith("#")){
				attrText=attrText.substring(1);
				shell=SHELL_HASH;
				hyper=true;
			}else if(attrText.startsWith("${")){
				let pos;
				//Get Postfix:
				pos=attrText.lastIndexOf("}");
				if(pos>0){
					hyperPostfix=attrText.substring(pos);
				}else{
					pos=attrText.length;
					hyperPostfix="}";
				}
				attrText=attrText.substring(2,pos);
				shell=SHELL_HYPER;
				hyper=true;
			}
			try {
				tokens = esp.tokenize(attrText,{range:true});
				if (tokens.length === 1 && tokens[0].type === "Numeric") {//Just a plain number
					mode = MODE_NUM;
					val = parseFloat(attrText);
				}else if(hyper){
					let num;
					valType=typeof(oldVal);
					if(valType==="number"){
						mode = MODE_HYPER;
						n=tokens.length;
						if(n>3 && tokens[n-3].value===")" && tokens[0].value==="(" &&
						   tokens[n-1].type==="Numeric" && (tokens[n - 2].value === "+" || tokens[n - 2].value === "-")){
							num = parseFloat(tokens[n - 1].value);
							if (tokens[n - 2].value === "-") {
								num = -num;
							}
							num += d;
							newText = attrText.substring(0, tokens[n - 2].range[0]);
							if (num > 0) {
								newText=maybeBrackets(newText,tokens,n-2);
								newText += "+" + num;
							} else if(num<0){
								newText=maybeBrackets(newText,tokens,n-2);
								newText += num;
							}else{
								newText=maybeNotBrackets(newText,tokens,n-2);
							}
						}else{
							newText=maybeNotBrackets(attrText,tokens,n);
							if (d > 0) {
								newText=maybeBrackets(newText,tokens,n);
								newText += "+ " + d;
							} else if(d<0){
								newText=maybeBrackets(newText,tokens,n);
								newText +=d;
							}
						}
					}else if(valType==="string"){
						mode = MODE_HYPER;
						n=tokens.length;
						if(chk4.test(oldVal)){
							return oldText;//We don't support this.
						}
						if(n>5 && tokens[0].value==="(" && tokens[n-5].value===")" && 
						   tokens[n-1].type==="Numeric" && tokens[n - 2].value === "+" &&
						   tokens[n - 3].value === '"+"' && tokens[n-4].value === "+"){
							num=parseFloat(tokens[n - 1].value);
							num += d;
							newText = attrText.substring(0, tokens[n - 4].range[0]);
							if (num > 0) {
								newText += "+ "+'"+"'+"+"+num;
							} else if(num<0){
								newText += "+(" + num+")";
							}else{
								newText=maybeNotBrackets(newText,tokens,n-2);
							}
						}else if(n>6 && tokens[0].value==="(" &&  tokens[n-6].value===")" &&
								 tokens[n-1].type==="Punctuator" && tokens[n - 1].value === ")" && 
								 tokens[n-2].type==="Numeric" &&tokens[n - 3].value === "-" && 
								 tokens[n-4].value==="(" && tokens[n-5].value==="+"){
							num=-parseFloat(tokens[n - 2].value);
							num += d;
							newText = attrText.substring(0, tokens[n - 5].range[0]);
							if (num > 0) {
								newText += "+" + num;
							} else if(num<0){
								newText += "+(" + num+")";
							}else{
								newText=maybeNotBrackets(newText,tokens,n-5);
							}
						}else if(n>2&&tokens[0].value==="calc"&&tokens[1].value==="("){
							return oldText;//We don't support?
						}else{
							newText = attrText;
							if (d > 0) {
								newText=maybeBrackets(newText,tokens,n);
								newText += "+" +'"+"'+ "+"+d;
							} else if(d<0){
								newText=maybeBrackets(newText,tokens,n);
								newText += "+(" + d+")";
							}else{
								newText = maybeNotBrackets(newText,tokens,n);
							}
						}
					}else{
						return oldText;//We don't support?
					}
				} else {
					if (tokens.length === 1 && tokens[0].type === "String"){
						attrText=JSON.parse(tokens[0].value);
						tokens=esp.tokenize(attrText,{range:true});
					}
					mode = MODE_TEXT;
					n = tokens.length;
					if(n>3 && tokens[n-3].value===")" && tokens[0].value==="("&& tokens[n-1].type==="Numeric" &&
					   tokens[n-2].type === "Punctuator" && (tokens[n - 2].value === "+" || tokens[n - 2].value === "-")){
						val = parseFloat(tokens[n - 1].value);
						if (tokens[n - 2].value === "-") {
							val = -val;
						}
						val += d;
						newText = attrText.substring(0, tokens[n - 2].range[0]);
						if (val > 0) {
							newText=maybeBrackets(newText,tokens,n-2);
							newText += "+" + val;
						} else if(val<0){
							newText=maybeBrackets(newText,tokens,n-2);
							newText += val;
						}else{
							newText=maybeNotBrackets(newText,tokens,n-2);
							newText = newText;
						}
					}else{
						if (d >0) {
							newText=maybeBrackets(attrText,tokens,n);
							newText = newText + "+" + d;
						} else if(d<0){
							newText=maybeBrackets(attrText,tokens,n);
							newText = newText  + d;
						}else{
							newText = attrText;
						}
					}
				}
			}catch (e) {
				//Parse error, can't move:
				return oldText;
			}
			switch(mode){
				case MODE_NUM:{
					val+=d;
					newText=""+val;
					break;
				}
				case MODE_TEXT:{
					newText=newText;
					break;
				}
				case MODE_HYPER:{
					break;
				}
			}
			//Re-wrap it:
			switch(shell){
				case SHELL_NONE:
					break;
				case SHELL_HASH:
					newText="#"+newText;
					break;
				case SHELL_HYPER:
					newText="${"+newText+hyperPostfix;
					break;
			}
			return newText;
		}

		attr=ppts.getAttr("x");
		if(attr && dx){
			txtX=moveAttr(attr,dx);
		}else{
			txtX=null;
		}

		attr=ppts.getAttr("y");
		if(attr && dy){
			txtY=moveAttr(attr,dy);
		}else{
			txtY=null;
		}
		if(this.isHudGear){
			let args=this.createArgs;
			attr=ppts.getAttr("w")||args.getAttr("w")||args.getAttr("width");
			if(attr && dw){
				txtW=moveAttr(attr,dw);
			}else{
				txtW=null;
			}

			attr=ppts.getAttr("h")||args.getAttr("h")||args.getAttr("height");
			if(attr && dh){
				txtH=moveAttr(attr,dh);
			}else{
				txtH=null;
			}
		}else{
			attr=ppts.getAttr("w");
			if(attr && dw){
				txtW=moveAttr(attr,dw);
			}else{
				txtW=null;
			}

			attr=ppts.getAttr("h");
			if(attr && dh){
				txtH=moveAttr(attr,dh);
			}else{
				txtH=null;
			}
		}
		return [txtX,txtY,txtW,txtH];
	};
}

export {EditHudObj,HudObjShellAttr};



