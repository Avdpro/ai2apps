import inherits from "/@inherits";
import {makeObjEventEmitter} from "/@events";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";

var DefFaceTag={
	name:"FaceTag",icon:"faces.svg",allowExtraAttr:0,naviAddAttr:1,navi:"doc",
	attrs:{
		"mockup":{name:"mockup",showName:"Mockup",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false,info:"Mokup and preview only, will not generate codes."},
		"previewEntry":{name:"previewEntry",showName:"Preview entry",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false,info:"In preview, show this face will reset UI first."},
		"mockupNext":{name:"mockupNext",showName:"Next face",type:"string",initVal:"",key:1,fixed:1,rawEdit:false,info:"In preview, next showing face when user click next button."},
		"description":{name:"description",showName:"Description",type:"string",initVal:"",key:1,fixed:1},
		"preFunc":{name:"preFunc",showName:"Pre Function",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
		"faceFunc":{name:"faceFunc",showName:"Post Function",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
		"delay":{name:"delay",showName:"Delay",type:"int",initVal:0,key:1,fixed:1,info:"Preview will pause for delay(ms) after showing this face."},
		"faceTimes":{
			name:"faceTimes",type:"object",elementType:"facetag",key:1,fixed:1,edit:false,
			def:{
				attrs:{},allowExtraAttr:1,attrType:"facetag",attrTypeDef:"FaceTag"
			}
		},
		"state":{
			name:"state",showName:"state",type:"object",key:0,fixed:1,
			def:{
				icon:"hudstate.svg",attrs:{},
				objAttrs:{
					isHudFacePtts:1,
					getAttrDef:function(name){
						let attr,defs,def;
						defs=this.stateAttrDefs;
						if(!defs){
							defs=this.stateAttrDefs={};
						}else{
							def=defs[name];
						};
						if(!def){
							attr=this.doc.stateObj.attrHash[name];
							if(attr){
								def=attr.def;
								def=defs[name]={...def,key:0};
							}
						}
						return def;
					},
					getEditSubPpts:function(){
						return this.doc.stateObj.getEditSubPpts();
					}
				},
				OnCreate(){
					let self=this;
					self.on("AttrAdd",(attr)=>{
						let liveObj,orgAttr,doc,attrDef,attrName,val;
						doc=self.doc;
						orgAttr=doc.stateObj.getAttr(attr.name);
						if(orgAttr){
							attr.setValByText(orgAttr.valText);
						}
					});
					self.on("Changed",(attr)=>{
						let doc;
						doc=self.doc;
						doc.updateFaceState(self.owner);
					});
				},
			}
		}
	},
	objAttrs:{isFaceTag:1},
	listHint:[
		"state","preFunc","faceFunc",
		{name:"Preview",showName:"Preview",attrs:["previewEntry","mockup","mockupNext","delay"],open:1},
		"description"
	]
};
var DefFaceTimeTag={
	name:"FaceTimeTag",icon:"faces.svg",allowExtraAttr:0,navi:"doc",allowRename:false,
	attrs:{
		"time":{name:"time",showName:"Time",type:"int",initVal:500,key:1,fixed:1},
		"preFunc":{name:"preFunc",showName:"Pre Function",type:"bool",initVal:false,key:1,fixed:1},
		"faceFunc":{name:"faceFunc",showName:"Post Function",type:"bool",initVal:false,key:1,fixed:1},
	},
	objAttrs:{isFaceTag:1,isFaceTimeTag:1}
};
var EditFaceTag,editFaceTag;
//****************************************************************************
//Face tag in HudGearDoc:
EditFaceTag=function(owner,def,init){
	let time,self;
	EditObj.call(this,owner,def,true);
	self=this;
	if(this.isFaceTimeTag){
		time=def.time;
		this.time=this.getAttr("time");
		if(time>0){
			this.time.val=time;
			this.time.valText=""+time;
		}
		makeObjEventEmitter(this.time);
		this.time.on("Change",(...args)=>{
			this.emitAttrChange();
		});
	}else{
		this.mockup=this.getAttr("mockup");
		this.faceTimes=this.getAttr("faceTimes");
		//Proxy facesTimes items update.
		this.faceTimes.on("AttrAdd",(...args)=>{
			this.emit("AttrAdd",...args);
		});
		this.faceTimes.on("AttrRemove",(...args)=>{
			this.emit("AttrRemove",...args);
		});
		this.faceTimes.on("AttrMoveUp",(...args)=>{
			this.emit("AttrMoveUp",...args);
		});
		this.faceTimes.on("AttrMoveDown",(...args)=>{
			this.emit("AttrMoveDown",...args);
		});
	}
	
	Object.defineProperty(this, 'faceTagId', {
		get: function () {
			if(this.isFaceTimeTag){
				return this.jaxId+"@"+this.owner.owner.jaxId;
			}
			return this.jaxId;
		},
		set: function (v) {
			throw new Error("Can't set faceTagid.");
		},
		enumerable: true
	});
	
};
inherits(EditFaceTag,EditObj);
editFaceTag=EditFaceTag.prototype;
EditFaceTag.getDef=function(name){
	switch(name){
		case "FaceTimeTag":
			return DefFaceTimeTag
	}
	return DefFaceTag;
};
EditAttr.regAttrType("facetag",EditFaceTag);

//----------------------------------------------------------------------------
editFaceTag.getName=function(){
	if(this.time && this.time.val>=0){
		let ownerFace=this.owner.owner;
		return ""+this.time.val+"@"+ownerFace.getName();
	}
	return this.name;
};
//----------------------------------------------------------------------------
editFaceTag.getNaviSubList=function(mode){
	let slist,tlist,i,n,attr,navi;
	tlist=[];
	slist=this.getAttr("faceTimes");
	if(!slist){
		return null;
	}
	slist=slist.attrList;
	n=slist.length;
	for(i=0;i<n;i++){
		attr=slist[i];
		navi=attr.def.navi;
		if(!navi && attr.objDef){
			navi=attr.objDef.navi;
		}
		if(navi && navi===mode){
			tlist.push(attr);
		}
	}
	return tlist.length?tlist:null;
};

//----------------------------------------------------------------------------
editFaceTag.getEditRootPpts=function(){
	return [{obj:this,open:1}];
};

//----------------------------------------------------------------------------
editFaceTag.getFaceTime=function(time){
	let list,tag;
	tag=this.faceTimes.getAttr(time);
	if(tag){
		return tag;
	}
	list=this.faceTimes.attrList;
	for(tag of list){
		if(tag.time.val===time){
			return tag;
		}
	}
};

//----------------------------------------------------------------------------
editFaceTag.genFaceCSS=function(hudObj,playSeq){
	let cssVO={};
	let self=this;
	let doc=hudObj.doc;
	let maxTime=0;
	let aniNum=0;
	function genHudTagVO(faceTag,hud,outVO){
		let faces,face,faceVO;
		faces=hud.faces.attrList;
		FindFace:{
			for(face of faces){
				if(face.faceTag===faceTag){
					break FindFace;
				}
			}
			return;
		}
		let attrs,attr;
		faceVO={}
		outVO["#"+hud.jaxId]=faceVO;
		//TODO: Deal with face-tag-state change:
		attrs=face.properties.attrList;
		for(attr of attrs){
			if(attr.arrayVal){
				faceVO[attr.name]=[...attr.val];
			}else{
				faceVO[attr.name]=attr.val;
			}
		}
		//Add anis:
		let anis,ani,aniList,aniVO;
		anis=face.anis.attrList;
		if(anis.length>0){
			aniList=[];
			for(ani of anis){
				aniVO={};
				attrs=ani.properties.attrList;
				for(attr of attrs){
					if(attr.arrayVal){
						aniVO[attr.name]=[...attr.val];
					}else{
						aniVO[attr.name]=attr.val;
					}
				}
				aniList.push(aniVO);
			}
			faceVO.ani=aniList;
		}
	}

	//Run all hud for faceVO:
	hudObj.runOnAllHuds((hud)=>{
		genHudTagVO(self,hud,cssVO);
	},false);
	if(this.faceTimes){
		let list,time,timeTag;
		list=this.faceTimes.attrList;
		for(timeTag of list){
			let timeVO;
			timeVO={};
			time=timeTag.time.val;
			cssVO["@"+time]=timeVO;
			hudObj.runOnAllHuds((hud)=>{
				genHudTagVO(timeTag,hud,timeVO);
			},false);
			if(time>maxTime){
				maxTime=time;
			}
			timeVO["$"]=function(){
				doc.switchPlayFaceTag(timeTag,playSeq);
			}
		}
	}
	cssVO["$"]=function(){
		doc.switchPlayFaceTag(self,playSeq);
	}
	if(playSeq){
		return {faceVO:cssVO,maxTime:maxTime>200?maxTime:200,aniNum:aniNum};
	}
	return cssVO;//{faceVO:cssVO,maxTime:maxTime,aniNum:aniNum};
};



