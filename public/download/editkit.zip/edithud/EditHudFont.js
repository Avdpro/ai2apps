import inherits from "/@inherits";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
var EditHudFont,editHudFont;
var fontDef={
	name:"Font",icon:"font.svg",
	attrs:{
		url:{name:"url",showName:"Font URL",type:"file",initVal:"",key:1,fixed:1},
		previewSize:{name:"previewSize",showName:"Preview size",type:"int",initVal:16,key:1,fixed:1,editType:"fontView"}
	}
};
var sysFonts=["Arial","Arial Black","Courier New","Georgia","Impact","Microsoft Sans Serif","Times New Roman","Verdana"];
var editFonts=[...sysFonts];
var willBuildFonts=0;
//****************************************************************************
//Font attr:
//****************************************************************************
EditHudFont=function(owner,def,init){
	let self=this;
	EditObj.call(this,owner,def,true);
	this.fontURL=this.getAttr("url");
	this.previewSize=this.getAttr("previewSize");
	this.webFontFace=null;
	let applyFont=()=>{
		let name,url,fonts;
		if(self.webFontFace){
			document.fonts.delete(self.webFontFace);
			self.webFontFace=null;
		}
		name=self.name;
		url=self.fontURL.val;
		if(url.startsWith("//")){
			url=document.location.origin+url;
		}
		if(name && url){
			self.webFontFace=new FontFace(name,`url(${url})`);
			self.webFontFace.load().then(loadedFont=>{
				document.fonts.add(loadedFont);
				self.previewSize.emitAttrChange();
			});
		}
		if(!willBuildFonts){
			willBuildFonts=1;
			window.setTimeout(()=>{
				let name;
				self.doc.emitObjChange();
				editFonts.splice(0);
				fonts=self.owner.attrHash;
				for(name in fonts){
					editFonts.push(name);
				}
				editFonts.push(...sysFonts);
				willBuildFonts=0;
			},0);
		}
	};
	this.onChange(applyFont);
	this.fontURL.onChange(applyFont);
};
inherits(EditHudFont,EditObj);
EditAttr.regAttrType("font",EditHudFont);
var fontDefs={};
EditHudFont.regDef=function(name,def){
	fontDefs[name]=def;
};
EditHudFont.getDef=function(name){
	return fontDefs[name];
};
EditHudFont.getDefList=function(){
	return Object.values(fontDefs);
};

editHudFont=EditHudFont.prototype;

EditObj.regDef("Fonts",{
	name:"Fonts",icon:"fonts.svg",attrs:{},attrType:"font",attrTypeDef:"Font",allowExtraAttr:1
});
EditHudFont.regDef("Font",fontDef);

export {EditHudFont,editFonts,sysFonts};

