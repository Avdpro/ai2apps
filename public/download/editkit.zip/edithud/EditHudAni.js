import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import inherits from "/@inherits";
var EditHudAni,editHudAni;
//****************************************************************************
EditHudAni=function(owner,def,init){
	EditObj.call(this,owner,def,true);
	this.properties=this.getAttr("properties");
	this.functions=this.getAttr("functions");
	this.liveAniWebObj=null;
	this.liveAni=null;
	this.savedStyle=null;
	this.OnAniFinish=null;
};
inherits(EditHudAni,EditObj);
EditAttr.regAttrType("hudani",EditHudAni);
var aniDefs={};
EditHudAni.regDef=function(name,def){
	aniDefs[name]=def;
};
EditHudAni.getDef=function(name){
	return aniDefs[name];
};
EditHudAni.getDefList=function(){
	return Object.values(aniDefs);
};

editHudAni=EditHudAni.prototype;
//****************************************************************************
//Test play ani:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editHudAni.genLiveAni=function(){
		let face,hudObj,liveHudObj,webObj,cssVO,liveAni;
		if(this.liveAni){
			return this.liveAni;
		}
		hudObj=this.owner;
		while(hudObj && !hudObj.isHudObj){
			hudObj=hudObj.owner;
		}
		if(!hudObj){
			return null;
		}
		liveHudObj=hudObj.liveEdObj;
		if(!liveHudObj){
			return null;
		}
		webObj=liveHudObj.webObj;
		this.savedStyle = webObj.style.cssText;
		cssVO = this.genLiveAniCSS();
		liveAni=liveHudObj.animate(cssVO,0);
		this.liveAni=liveAni;
		this.liveAniWebObj=webObj;
		return liveAni;
	};
	
	//------------------------------------------------------------------------
	editHudAni.genLiveAniCSS=function(){
		let vo,attrs,attr,self;
		self=this;
		vo={};
		attrs=this.properties.attrList;
		for(attr of attrs){
			if(("val" in attr)&&(attr.def.export!==false)){
				vo[attr.name]=attr.val;
			}
		}
		vo.OnFinish=()=>{
			self._OnAniFinish();
		};
		vo.OnCancel=()=>{
			self._OnAniCancel();
		};
		return vo;
	};

	//------------------------------------------------------------------------
	editHudAni.playAni=function(callback){
		let ani;
		if(this.liveAni){
			return;
		}
		this.OnAniFinish=callback;
		ani=this.genLiveAni();
		if(ani){
			ani.start();
		}
	};

	//------------------------------------------------------------------------
	editHudAni.finishAni=function(){
		if(this.liveAni){
			this.liveAni.finish();
		}
	};
	
	//-----------------------------------------------------------------------
	//Reset liveEdObj's webObj style:
	editHudAni.resetAni=function(){
		if(this.liveAniWebObj){
			this.liveAniWebObj.style=this.savedStyle;
		}
	};

	//-----------------------------------------------------------------------
	//Ani finish callback
	editHudAni._OnAniFinish=function(){
		this.liveAni=null;
		this.OnAniFinish&&this.OnAniFinish();
	};

	//-----------------------------------------------------------------------
	//Ani cancel callback
	editHudAni._OnAniCancel=function(){
		this.liveAni=null;
		this.OnAniCancel&&this.OnAniCancel();
		this.OnAniFinish&&this.OnAniFinish();
	};
}

//****************************************************************************
//For Editor 
//****************************************************************************
{
	editHudAni.getName=function(){
		return "Ani: "+(this.objDef.showName||this.objDef.name);
	};
}
//****************************************************************************
//Basic ani defs:
//****************************************************************************
{
	var HudAniShellAttr={
		"codes":{name:"codes",showName:"With Codes",type:"bool",initVal:false,key:1,fixed:1,edit:1,hyperEdit:false},
	};
	var HudAni_PoseDef={
		name:"Pose",icon:"ani.svg",
		attrs:{
			properties:{
				name:"properties",showName:"Properties",
				type:"object",key:1,fixed:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"pose",key:1,fixed:1,edit:false,},
						time:{name:"time",type:"int",initVal:200,key:1,fixed:1,hideVal:200},
						x:{name:"x",type:"number",initVal:0,key:0,fixed:1,hideVal:0},
						y:{name:"y",type:"number",initVal:0,key:0,fixed:1,hideVal:0},
						w:{name:"w",type:"number",initVal:0,key:0,fixed:1,hideVal:0},
						h:{name:"h",type:"number",initVal:0,key:0,fixed:1,hideVal:0},
						alpha:{name:"alpha",type:"number",initVal:1,key:0,fixed:1,hideVal:1},
						scale:{name:"scale",type:"number",initVal:1,key:0,fixed:1,hideVal:1},
					},
					listHint:["time","x","y","w","h","alpha","scale"]
				}
			},
			...HudAniShellAttr
		},
		//action:"playAni"
	};
	EditHudAni.regDef("Pose",HudAni_PoseDef);

	var HudAni_AutoDef={
		name:"Auto",icon:"ani.svg",
		attrs:{
			properties:{
				name:"properties",showName:"Properties",
				type:"object",key:1,fixed:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"auto",key:1,fixed:1,edit:false,},
						time:{name:"time",type:"int",initVal:200,key:1,fixed:1,hideVal:200},
					},
					listHint:["time"]
				}
			},
			...HudAniShellAttr
		},
	};
	EditHudAni.regDef("Auto",HudAni_AutoDef);

	var HudAni_FadeInDef={
		name:"In",icon:"ani.svg",
		attrs:{
			properties:{
				name:"properties",showName:"Properties",
				type:"object",key:1,fixed:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"in",key:1,fixed:1,edit:false,},
						time:{name:"time",type:"int",initVal:200,key:1,fixed:1,hideVal:200},
						alpha:{name:"alpha",type:"number",initVal:0,key:0,fixed:1},
						scale:{name:"scale",type:"number",initVal:1,key:0,fixed:1},
						dx:{name:"dx",type:"int",initVal:0,key:0,fixed:1},
						dy:{name:"dy",type:"int",initVal:0,key:0,fixed:1},
						showX:{name:"showX",showName:"x",type:"int",initVal:0,key:0,fixed:1},
						showY:{name:"showY",showName:"y",type:"int",initVal:0,key:0,fixed:1},
						showW:{name:"showW",showName:"w",type:"int",initVal:0,key:0,fixed:1},
						showH:{name:"showH",showName:"h",type:"int",initVal:0,key:0,fixed:1},
						hideX:{name:"hideX",showName:"x",type:"int",initVal:0,key:0,fixed:1},
						hideY:{name:"hideY",showName:"y",type:"int",initVal:0,key:0,fixed:1},
						hideW:{name:"hideW",showName:"w",type:"int",initVal:0,key:0,fixed:1},
						hideH:{name:"hideH",showName:"h",type:"int",initVal:0,key:0,fixed:1},
					},
					listHint:[
						"time","alpha","scale","dx","dy",
						{name:"show",showName:"Show",attrs:["showX","showY","showW","showH"],open:0},
						{name:"hide",showName:"Hide",attrs:["hideX","hideY","hideW","hideH"],open:0},
					]
				}
			},
			...HudAniShellAttr
		},
	};
	EditHudAni.regDef("In",HudAni_FadeInDef);

	var HudAni_FadeOutDef={
		name:"Out",icon:"ani.svg",
		attrs:{
			properties:{
				name:"properties",showName:"Properties",
				type:"object",key:1,fixed:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"out",key:1,fixed:1,edit:false,},
						time:{name:"time",type:"int",initVal:200,key:1,fixed:1,hideVal:200},
						alpha:{name:"alpha",type:"number",initVal:0,key:0,fixed:1},
						scale:{name:"scale",type:"number",initVal:1,key:0,fixed:1},
						dx:{name:"dx",type:"int",initVal:0,key:0,fixed:1},
						dy:{name:"dy",type:"int",initVal:0,key:0,fixed:1},
						showX:{name:"showX",showName:"x",type:"int",initVal:0,key:0,fixed:1},
						showY:{name:"showY",showName:"y",type:"int",initVal:0,key:0,fixed:1},
						showW:{name:"showW",showName:"w",type:"int",initVal:0,key:0,fixed:1},
						showH:{name:"showH",showName:"h",type:"int",initVal:0,key:0,fixed:1},
						hideX:{name:"hideX",showName:"x",type:"int",initVal:0,key:0,fixed:1},
						hideY:{name:"hideY",showName:"y",type:"int",initVal:0,key:0,fixed:1},
						hideW:{name:"hideW",showName:"w",type:"int",initVal:0,key:0,fixed:1},
						hideH:{name:"hideH",showName:"h",type:"int",initVal:0,key:0,fixed:1},
					},
					listHint:[
						"time","alpha","scale","dx","dy",
						{name:"show",showName:"Show",attrs:["showX","showY","showW","showH"],open:0},
						{name:"hide",showName:"Hide",attrs:["hideX","hideY","hideW","hideH"],open:0},
					]
				}
			},
			...HudAniShellAttr
		},
	};
	EditHudAni.regDef("Out",HudAni_FadeOutDef);
}
export {EditHudAni};