import {EditHudObj} from "./EditHudObj.js";
import {
	HudObjDef,
	HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,HudMemoDef,
	UIView,UIDock,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox
} from "./HudTypes.js";

EditHudObj.regHudDef("hud",HudObjDef);
EditHudObj.regCatalogHudDef("Basic","hud",HudObjDef);
EditHudObj.regCatalogHudDef("Containers","hud",HudObjDef);
EditHudObj.regCatalogHudDef("Raw","hud",HudObjDef);

EditHudObj.regHudDef("box",HudBoxDef);
EditHudObj.regCatalogHudDef("Basic","box",HudBoxDef);
EditHudObj.regCatalogHudDef("Containers","box",HudBoxDef);
EditHudObj.regCatalogHudDef("Raw","box",HudBoxDef);

EditHudObj.regHudDef("text",HudTextDef);
EditHudObj.regCatalogHudDef("Basic","text",HudTextDef);
EditHudObj.regCatalogHudDef("Texts","text",HudTextDef);
EditHudObj.regCatalogHudDef("Raw","text",HudTextDef);

EditHudObj.regHudDef("button",HudButtonDef);
EditHudObj.regCatalogHudDef("Buttons","button",HudButtonDef);
EditHudObj.regCatalogHudDef("Raw","button",HudButtonDef);

EditHudObj.regHudDef("image",HudImageDef);
EditHudObj.regCatalogHudDef("Basic","image",HudImageDef);
EditHudObj.regCatalogHudDef("Medias","image",HudImageDef);
EditHudObj.regCatalogHudDef("Raw","image",HudImageDef);

EditHudObj.regHudDef("edit",HudEditDef);
EditHudObj.regCatalogHudDef("Inputs","edit",HudEditDef);

EditHudObj.regHudDef("memo",HudMemoDef);
EditHudObj.regCatalogHudDef("Inputs","memo",HudMemoDef);

EditHudObj.regHudDef("view",UIView);
EditHudObj.regCatalogHudDef("Containers","view",UIView);
EditHudObj.regCatalogHudDef("Views","view",UIView);
EditHudObj.regCatalogHudDef("View","view",UIView);

EditHudObj.regHudDef("dock",UIDock);
EditHudObj.regCatalogHudDef("Containers","dock",UIDock);
EditHudObj.regCatalogHudDef("View","dock",UIDock);

EditHudObj.regHudDef("FlexBoxH",HudFlexHBox);
//EditHudObj.regCatalogHudDef("Containers","FlexBoxH",HudFlexHBox);

EditHudObj.regHudDef("FlexBoxV",HudFlexVBox);
//EditHudObj.regCatalogHudDef("Containers","FlexBoxV",HudFlexVBox);

EditHudObj.regHudDef("FlexBoxHR",HudFlexHRBox);
//EditHudObj.regCatalogHudDef("Containers","FlexBoxHR",HudFlexHRBox);

EditHudObj.regHudDef("FlexBoxVR",HudFlexVRBox);
//EditHudObj.regCatalogHudDef("Containers","FlexBoxVR",HudFlexVRBox);

EditHudObj.regHudDef("GridBox",HudGridBox);
//EditHudObj.regCatalogHudDef("Containers","GridBox",HudGridBox);

EditHudObj.regHudDef("TreeBox",HudTreeBox);
EditHudObj.regCatalogHudDef("Containers","TreeBox",HudTreeBox);

export {
	HudObjDef,
	HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,
	UIView,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox
}