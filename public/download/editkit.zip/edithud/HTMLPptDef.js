import {vfactLength,vfactColor,vfactLayout,vfactOverflow,vfactMargin,vfactAnhor,vfactUIEvent,
		vfactFlexDir,vfactBorderColor,vfactBorderStyle,vfactTextBold,vfactTextItalic,vfactTextUnderline,
		vfactTextAlign,vfactTextWrap,vfactImageSize,vfactImageRepeat,vfactImagePosition} from "/@vfact/vfact_react.js";
import {camelCSSName,getHyperAttrText,getHyperAttrCodeVO} from "/@vfact";

let vfactElmtPptMap={
	"id":{
		keyword:"id",attrName:"id",allowDynamic:false,hideValText:""
	},
};

let vfactCSSPptMap={
	//------------------------------------------------------------------------
	//Basic properties:
	"position":{
		keyword:"position",attrName:"position",allowDynamic:false
	},
	"left":{
		keyword:"left", attrName:"x", allowDynamic:true,
		attrVal2CSSVal:vfactLength,
	},
	"top":{
		keyword:"left", attrName:"y", allowDynamic:true,
		attrVal2CSSVal:vfactLength,
	},
	"width":{
		keyword:"width", attrName:"w",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"height":{
		keyword:"height", attrName:"h", allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"min-width":{
		keyword:"min-width",attrName:"minWidth",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"max-width":{
		keyword:"max-width",attrName:"maxWidth",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"min-height":{
		keyword:"min-height",attrName:"minheight",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"max-height":{
		keyword:"max-height",attrName:"maxheight",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"z-index":{
		keyword:"z-index", attrName:"zIndex", allowDynamic:true,hideValText:"0",
	},
	"pointerEvents":{
		keyword:"pointerEvents", attrName:"uiEvent", allowDynamic:true,hideValText:"auto",
		attrVal2CSSVal:vfactUIEvent,
	},
	"display":{
		"keyword":"display",allowDynamic:true,
		export(hudObj,vo,exporter){
			let attrDisplay,valDisplayText,displayCode,isDisplayDynamic;
			let attrLayout,valLayoutText,layoutCode,isLayoutDynamic,attrText;
			let pos;
			isLayoutDynamic=false;
			attrDisplay=hudObj.properties.getAttr("display");
			attrLayout=hudObj.properties.getAttr("contentLayout");
			if(attrLayout){
				valLayoutText=attrLayout.valText;
				if(exporter.allowDynamic && attrLayout.hyper){
					isLayoutDynamic=true;
					attrText=getHyperAttrText(valLayoutText);
					layoutCode=`(vfactLayout(${attrText}))`;
					if(exporter){
						exporter.regUtilFunc("vfactLayout");
					}
				}else{
					layoutCode=`"${vfactLayout(attrLayout.val,hudObj)}"`;
				}
			}else{
				layoutCode='"block"';
			}
			if(attrDisplay){
				valDisplayText=attrDisplay.valText;
				if(exporter.allowDynamic && attrDisplay.hyper){
					isDisplayDynamic=true;
					attrText=getHyperAttrText(valDisplayText);;
					displayCode=attrText;
					vo["display"]=`\`\$\{${(displayCode)}?${`${layoutCode}`}:"none"\}\``;
				}else{
					if(attrDisplay.val){
						if(isLayoutDynamic){
							vo["display"]="`${"+layoutCode+"}`";
						}else{
							if(layoutCode!=="block"){
								vo["display"]=layoutCode;
							}
						}
					}else{
						if(layoutCode!=="block"){
							vo["display"]=`"none"`;
						}
					}
				}
			}else{
				if(attrLayout){
					if(isLayoutDynamic){
						vo["display"]="`${"+layoutCode+"}`";
					}else{
						if(layoutCode!=="block"){
							vo["display"]=layoutCode;
						}
					}
				}
			}
		},
	},
	"flex-direction":{
		keyword:"flex-direction",attrName:"contentLayout",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactFlexDir,
	},
	"opacity":{
		keyword:"opacity",attrName:"alpha",allowDynamic:true,hideValText:"1",
	},
	"cursor":{
		keyword:"cursor",attrName:"cursor",allowDynamic:true,hideValText:"",
	},
	"filter":{
		keyword:"filter",attrName:"filter",allowDynamic:true,hideValText:"",
	},
	"flex":{
		keyword:"flex",attrName:"flex",allowDynamic:true,hideValText:"",
	},
	"overflow":{
		keyword:"overflow",attrName:"overflow",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactOverflow,
	},
	"margin":{
		keyword:"margin",attrName:"margin",allowDynamic:true,hideValText:"0",hideValText:"",
		attrVal2CSSVal:vfactMargin
	},
	"padding":{
		keyword:"padding",attrName:"padding",allowDynamic:true,hideValText:"0",hideValText:"",
		attrVal2CSSVal:vfactMargin
	},
	"transform":{
		keyword:"transform",
		export(hudObj,vo,exporter){
			let isHyperT,isHyperO,ppts,pos,code;
			let attrAx,valTxtAx,codeAx,codeTx;
			let attrAy,valTxtAy,codeAy,codeTy;
			let attrS,valTxtS,codeS;
			let attrR,valTxtR,codeR;
			let hyperMark,codeT,codeO;
			hyperMark=exporter.hyperValToken;
			isHyperT=false;
			isHyperO=false;
			ppts=hudObj.properties;
			attrAx=ppts.getAttr("anchorH");
			attrAy=ppts.getAttr("anchorV");
			attrS=ppts.getAttr("scale");
			attrR=ppts.getAttr("rotate");
			if(attrAx){
				valTxtAx=attrAx.valText;
				if(exporter.allowDynamic && attrAx.hyper){
					isHyperT=true;
					isHyperO=true;
					valTxtAx=getHyperAttrText(valTxtAx);
					codeAx=`\$\{vfactAnhor(${valTxtAx})[0]\}`;
					codeTx=`\$\{vfactAnhor(${valTxtAx})[1]\}`;
					if(exporter){
						exporter.regUtilFunc("vfactAnhor");
					}
				}else{
					[codeAx,codeTx]=vfactAnhor(attrAx.val);
				}
			}else{
				codeAx="0px";
				codeTx="0%";
			}
			if(attrAy){
				valTxtAy=attrAy.valText;
				if(exporter.allowDynamic && attrAy.hyper){
					isHyperT=true;
					isHyperO=true;
					valTxtAy=getHyperAttrText(valTxtAy);
					codeAy=`\$\{vfactAnhor(${valTxtAy})[0]\}`;
					codeTy=`\$\{vfactAnhor(${valTxtAy})[1]\}`;
					if(exporter){
						exporter.regUtilFunc("vfactAnhor");
					}
				}else{
					[codeAy,codeTy]=vfactAnhor(attrAy.val);
				}
			}else{
				codeAy="0px";
				codeTy="0%";
			}
			if(attrS){
				valTxtS=attrS.valText;
				if(exporter.allowDynamic && attrS.hyper){
					isHyperT=true;
					valTxtS=getHyperAttrText(valTxtS);
					codeS=`scale(\$\{${valTxtS}\})`;
				}else{
					let val=attrS.val;
					if(val>=0 || val<0){
						codeS=`scale(${val})`;
					}else{
						codeS=`scale(1)`;
					}
				}
			}else{
				codeS="scale(1)";
			}
			if(attrR){
				valTxtR=attrR.valText;
				if(exporter.allowDynamic && attrR.hyper){
					isHyperT=true;
					valTxtR=getHyperAttrText(valTxtR);
					codeR=`rotate(\$\{${valTxtR}\}deg)`;
				}else{
					let val=attrR.val;
					if(val>=0 || val<0){
						codeR=`rotate(${val}deg)`;
					}else{
						codeR=`rotate(0deg)`;
					}
				}
			}else{
				codeR="rotate(0deg)";
			}
			codeT=`translate(${codeAx}, ${codeAy}) ${codeR} ${codeS}`;
			codeO=`${codeTx} ${codeTy}`;
			if(codeT!=="translate(0px, 0px) rotate(0deg) scale(1)"){
				if(isHyperT){
					vo["transform"]="`"+codeT+"`";
				}else{
					vo["transform"]='"'+codeT+'"';
				}
			}
			if(codeO!=="0% 0%"){
				if(isHyperO){
					vo["transformOrigin"]="`"+codeO+"`";
				}else{
					vo["transformOrigin"]='"'+codeO+'"';
				}
			}
		}
	},
};

let vfactBoxCSSPptMap={
	//------------------------------------------------------------------------
	//Box:
	/*
	"outlineStyle",
	"inset",//shdow
	"maskImage","webkitMaskImage","webkitMaskSize",
	*/
	"background":{
		keyword:"background",attrName:"background",allowDynamic:true,
		attrVal2CSSVal:vfactColor,
	},
	"border-radius":{
		keyword:"border-radius",attrName:"corner",allowDynamic:true,hideValText:"0px",
		attrVal2CSSVal:vfactMargin,
	},
	"border-width":{
		keyword:"border-width",attrName:"border",allowDynamic:true,
		attrVal2CSSVal:vfactMargin,
	},
	"border-color":{
		keyword:"border-color",attrName:"borderColor",allowDynamic:true,
		attrVal2CSSVal:vfactBorderColor,
	},
	"border-style":{
		keyword:"border-style",attrName:"borderStyle",allowDynamic:true,
		attrVal2CSSVal:vfactBorderStyle,
	},
	"box-shadow":{
		keyword:"border-shadow",attrName:"shadow",
		export(hudObj,vo,exporter){
			let ppts;
			let attrShd,attrShdC,attrShdX,attrShdY,attrShdB,attrShdS;
			let codeShd,codeShdC,codeShdX,codeShdY,codeShdB,codeShdS;
			let attrText;
			ppts=hudObj.properties;
			attrShd=ppts.getAttr("shadow");
			attrShdX=ppts.getAttr("shadowX");
			attrShdY=ppts.getAttr("shadowY");
			attrShdC=ppts.getAttr("shadowColor");
			attrShdB=ppts.getAttr("shadowBlur");
			attrShdS=ppts.getAttr("shadowSpread");
			if(!attrShd){
				return;
			}
			if(!attrShd.hyper && !attrShd.val){
				return;
			}
			//Color:
			if(attrShdC){
				if(attrShdC.hyper){
					attrText=getHyperAttrText(attrShdC.valText);
					codeShdC=`\$\{vfactColor(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactColor");
					}
				}else{
					codeShdC=vfactColor(attrShdC.val);
				}
			}else{
				codeShdC="rgba(0,0,0,0.5)";
			}
			//X:
			if(attrShdX){
				if(attrShdX.hyper){
					attrText=getHyperAttrText(attrShdX.valText);
					codeShdX=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdX=vfactLength(attrShdX.val);
				}
			}else{
				codeShdX="2px";
			}
			//Y:
			if(attrShdY){
				if(attrShdY.hyper){
					attrText=getHyperAttrText(attrShdY.valText);
					codeShdY=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdY=vfactLength(attrShdY.val);
				}
			}else{
				codeShdX="2px";
			}
			//Blur:
			if(attrShdB){
				if(attrShdB.hyper){
					attrText=getHyperAttrText(attrShdB.valText);
					codeShdB=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdB=vfactLength(attrShdB.val);
				}
			}else{
				codeShdB="3px";
			}
			//Spread:
			if(attrShdS){
				if(attrShdS.hyper){
					attrText=getHyperAttrText(attrShdS.valText);
					codeShdS=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdS=vfactLength(attrShdS.val);
				}
			}else{
				codeShdS="0px";
			}
			codeShd=`${codeShdX} ${codeShdY} ${codeShdB} ${codeShdS} ${codeShdC}`
			if(attrShd.hyper){
				attrText=getHyperAttrText(attrShd.valText);
				codeShd=`\`\$\{(${attrText})?(\`${codeShd}\`):"none"\}\``;
			}else{
				codeShd="`"+codeShd+"`";
			}
			vo["boxShadow"]=codeShd;
		}
	},
	"mask-image":{
		keyword:"mask-image",attrName:"maskImage",
		export(hudObj,vo,exporter){
			let ppts,attr,attrText;
			ppts=hudObj.properties;
			attr=ppts.getAttr("maskImage");
			if(!attr){
				return;
			}
			if(attr.hyper){
				attrText=getHyperAttrText(attr.valText);
				vo["maskImage"]=`\`url(\$\{${attrText}\})\``;
				vo["webkitMaskSize"]="100% 100%"
			}else{
				if(attr.val){
					vo["maskImage"]=`"url(${attr.val})"`;
					vo["webkitMaskSize"]="100% 100%"
				}
			}
		}
	},
};

let vfactTextCSSPptMap={
	//-------------------------------------------------------------------------
	//Text:
	/*
	"wordBreak","whiteSpace","textOverflow",
	"textOverflow",//Inner-Div?
	*/
	"color":{
		keyword:"color",attrName:"color",allowDynamic:true,
		attrVal2CSSVal:vfactColor,
	},
	"font-family":{
		keyword:"font-family",attrName:"font",allowDynamic:true,hideValText:"",
	},
	"font-size":{
		keyword:"font-size",attrName:"fontSize",allowDynamic:true,hideValText:"",
		attrVal2CSSVal:vfactLength,
	},
	"font-weight":{
		keyword:"font-weight",attrName:"bold",allowDynamic:true,hideValText:"normal",
		attrVal2CSSVal:vfactTextBold,
	},
	"font-style":{
		keyword:"font-weight",attrName:"italic",allowDynamic:true,hideValText:"normal",
		attrVal2CSSVal:vfactTextItalic,
	},
	"text-decoration":{
		keyword:"text-decoration",attrName:"underline",allowDynamic:true,hideValText:"normal",
		attrVal2CSSVal:vfactTextUnderline,
	},
	"text-align":{
		keyword:"text-align",attrName:"alignH",allowDynamic:true,
		export(hudObj,vo,exporter){
			let ppts,attr,attrText,code;
			ppts=hudObj.properties;
			attr=ppts.getAttr("alignH");
			if(attr){
				if(attr.hyper){
					attrText=getHyperAttrText(attr.valText);
					vo["textAlign"]=vo["justifyContent"]=`\`vfactTextAlign(${attrText})\``;
					if(exporter){
						exporter.regUtilFunc("vfactTextAlign");
					}
				}else{
					code=vfactTextAlign(attr.val);
					if(code!=="start"){
						vo["textAlign"]='"'+code+'"';
						vo["justifyContent"]='"'+code+'"';
					}
				}
			}
		}
	},
	"align-items":{
		keyword:"align-items",attrName:"alignV",allowDynamic:true,
		export(hudObj,vo,exporter){
			let ppts,attr,attrText,code;
			ppts=hudObj.properties;
			attr=ppts.getAttr("alignH");
			if(attr){
				if(attr.hyper){
					attrText=getHyperAttrText(attr.valText);
					vo["alignItems"]=`\`vfactTextAlign(${attrText})\``;
					if(exporter){
						exporter.regUtilFunc("vfactTextAlign");
					}
				}else{
					code=vfactTextAlign(attr.val);
					if(code!=="start"){
						vo["alignItems"]='"'+code+'"';
					}
				}
			}
		}
	},
	"word-break":{
		keyword:"word-break",attrName:"wrap",allowDynamic:true,
		export(hudObj,vo,exporter){
			let ppts,attr,attrText,code;
			ppts=hudObj.properties;
			attr=ppts.getAttr("wrap");
			if(attr){
				if(attr.hyper){
					attrText=getHyperAttrText(attr.valText);
					vo["whiteSpace"]=`\`vfactTextWrap(${attrText})[0]\``;
					vo["wordBreak"]=`\`vfactTextWrap(${attrText})[1]\``;
					if(exporter){
						exporter.regUtilFunc("vfactTextWrap");
					}
				}else{
					code=vfactTextWrap(attr.val);
					vo["whiteSpace"]='"'+code[0]+'"';
					vo["wordBreak"]='"'+code[1]+'"';
				}
			}
		}
	},
	"display":{
		"keyword":"display",allowDynamic:true,
		export(hudObj,vo,exporter){
			let attrDisplay,valDisplayText,attrText,isDisplayDynamic;
			let attrLayout,layoutCode,isLayoutDynamic;
			let pos;
			attrDisplay=hudObj.properties.getAttr("display");
			if(attrDisplay){
				valDisplayText=attrDisplay.valText;
				if(exporter.allowDynamic && attrDisplay.hyper){
					isDisplayDynamic=true;
					attrText=getHyperAttrText(valDisplayText);
					vo["display"]=`\`\$\{(${attrText})?"flex":"none"\}\``;
				}else{
					vo["display"]=(attrDisplay.val)?'"flex"':'"none"';
				}
			}else{
				//Should in face, don't change it
			}
		},
	},
	"user-select":{
		keyword:"user-select",attrName:"select",allowDynamic:true,
		export(hudObj,vo,exporter){
			let ppts,attr,attrText,code;
			ppts=hudObj.properties;
			attr=ppts.getAttr("select");
			if(attr){
				if(attr.hyper){
					attrText=getHyperAttrText(attr.valText);
					vo["webkitUserSelect"]=
					vo["webkitTouchCallout"]=
					vo["userSelect"]=`\`\$\{(${attrText})?"text":"none"\}\``;
				}else{
					vo["webkitUserSelect"]=
					vo["webkitTouchCallout"]=
					vo["userSelect"]=(attr.val)?'"text"':'"none"';
				}
			}
		}
	},
	"text-shadow":{
		keyword:"text-shadow",attrName:"shadow",
		export(hudObj,vo,exporter){
			let ppts;
			let attrShd,attrShdC,attrShdX,attrShdY,attrShdB,attrShdS;
			let codeShd,codeShdC,codeShdX,codeShdY,codeShdB,codeShdS;
			let attrText;
			ppts=hudObj.properties;
			attrShd=ppts.getAttr("shadow");
			attrShdX=ppts.getAttr("shadowX");
			attrShdY=ppts.getAttr("shadowY");
			attrShdC=ppts.getAttr("shadowColor");
			attrShdB=ppts.getAttr("shadowBlur");
			if(!attrShd){
				return;
			}
			if(!attrShd.hyper && !attrShd.val){
				return;
			}
			//Color:
			if(attrShdC){
				if(attrShdC.hyper){
					attrText=getHyperAttrText(attrShdC.valText);
					codeShdC=`\$\{vfactColor(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactColor");
					}
				}else{
					codeShdC=vfactColor(attrShdC.val);
				}
			}else{
				codeShdC="rgba(0,0,0,0.5)";
			}
			//X:
			if(attrShdX){
				if(attrShdX.hyper){
					attrText=getHyperAttrText(attrShdX.valText);
					codeShdX=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdX=vfactLength(attrShdX.val);
				}
			}else{
				codeShdX="2px";
			}
			//Y:
			if(attrShdY){
				if(attrShdY.hyper){
					attrText=getHyperAttrText(attrShdY.valText);
					codeShdY=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdY=vfactLength(attrShdY.val);
				}
			}else{
				codeShdX="2px";
			}
			//Blur:
			if(attrShdB){
				if(attrShdB.hyper){
					attrText=getHyperAttrText(attrShdB.valText);
					codeShdB=`\$\{vfactLength(${attrText})\}`;
					if(exporter){
						exporter.regUtilFunc("vfactLength");
					}
				}else{
					codeShdB=vfactLength(attrShdB.val);
				}
			}else{
				codeShdB="3px";
			}
			codeShd=`${codeShdC} ${codeShdX} ${codeShdY} ${codeShdB} ${codeShdS}`
			if(attrShd.hyper){
				attrText=getHyperAttrText(attrShd.valText);
				codeShd=`\`\$\{(${attrText})?(\`${codeShd}\`):"none"\}\``;
			}else{
				codeShd="`"+codeShd+"`";
			}
			vo["textShadow"]=codeShd;
		}
	},
};

let vfactTextSubElmtPptMap={
	"id":{
		keyword:"id",attrName:"id",allowDynamic:false,
		export(hudObj,vo,exporter){
			vo["id"]='"TextDiv"';
		}
	},
};
let vfactTextSubCSSPptMap={
	"text-overflow":{
		keyword:"text-overflow",attrName:"wrap",allowDynamic:true,
		export(hudObj,vo,exporter){
			let ppts;
			let attrWrap,attrElps,attrText,code,elpsCode;
			ppts=hudObj.properties;
			attrWrap=ppts.getAttr("wrap");
			attrElps=ppts.getAttr("ellipsis");
			if(!attrElps){
				//vo["textOverflow"]='""';
				//vo["minWidth"]='""';
				//vo["overflow"]='""';
				return;
			}
			if(attrElps.hyper){
				elpsCode=getHyperAttrText(attrElps.valText);
			}else{
				if(!attrElps.val){
					//vo["textOverflow"]='""';
					//vo["minWidth"]='""';
					//vo["overflow"]='""';
					return;
				}
			}
			if(attrWrap){
				if(attrWrap.hyper){
					attrText=getHyperAttrText(attrWrap.valText);
					vo["textOverflow"]=`(${attrText})?"":(${elpsCode}?"ellipsis":"")`;
					vo["minWidth"]=`(${attrText})?"":(${elpsCode}?"0px":"")`;
					vo["overflow"]=`(${attrText})?"":(${elpsCode}?"hidden":"")`;
					return;
				}else{
					if(attrWrap.val){
						code=vfactTextWrap(attrWrap.val);
						//vo["textOverflow"]='""';
						//vo["minWidth"]="";
						//vo["overflow"]="";
						return;
					}
				}
			}
			//No wrap attr, or wrap attr is static and it's false:
			{
				if(attrElps){
					if(attrElps.hyper){
					vo["textOverflow"]=`(${elpsCode})?"ellipsis":""`;
					vo["minWidth"]=`(${elpsCode})?"0px":""`;
					vo["overflow"]=`(${elpsCode})?"hidden":""`;
					}else{
						if(attrElps.val){
							vo["textOverflow"]='"ellipsis"';
							vo["minWidth"]='"0px"';
							vo["overflow"]='"hidden"';
						}else{
							//vo["textOverflow"]="";
							//vo["minWidth"]="";
							//vo["overflow"]="";
						}
					}
				}else{
					//vo["textOverflow"]="";
					//vo["minWidth"]="";
					//vo["overflow"]="";
				}
			}
		}
	},
};

let vfactTextContent=function(editHudObj,vo,exporter){
	let textAttr,attrVO,attrText;
	textAttr=editHudObj.properties.getAttr("text");
	if(textAttr){
		if(textAttr.hyper){
			vo.hyper=true;
			attrVO=getHyperAttrCodeVO(textAttr.valText);
			vo.elmtContent={code:`${attrVO.code}`,trace:attrVO.trace};
		}else{
			vo.elmtContent=JSON.stringify(textAttr.val);
		}
		return true;
	}
	return false;
};

let vfactImageCSSPptMap={
	//-------------------------------------------------------------------------
	//Image:
	/*
	"backgroundImage",
	"borderImageSource","borderImageSlice","borderImageWidth","borderImageRepeat",
	"backgroundSize",
	"backgroundPosition"
	*/
	"background-image":{
		keyword:"background-image",attrName:"image",allowDynamic:true,
		export(hudObj,vo,exporter){
			let attrImage,attrText;
			let ppts=hudObj.properties;
			attrImage=ppts.getAttr("image");
			if(attrImage){
				if(attrImage.hyper){
					attrText=getHyperAttrText(attrImage.valText);
					vo["backgroundImage"]=`\`url(\$\{${attrText}\})\``;
				}else{
					vo["backgroundImage"]=`"url(${attrImage.val})"`;
				}
				vo["backgroundPosition"]='"center"';
			}
		}
	},
	"background-position":{
		keyword:"background-position",attrName:"repeat",allowDynamic:true,
		attrVal2CSSVal:vfactImagePosition,
	},
	"background-size":{
		keyword:"background-size",attrName:"fitSize",allowDynamic:true,
		export(hudObj,vo,exporter){
			let attrFit,attrRpt,attrText,rptCode,fitCode;
			let ppts=hudObj.properties;
			attrFit=ppts.getAttr("fitSize");
			attrRpt=ppts.getAttr("repeat");
			if(attrRpt){
				if(attrRpt.hyper){
					attrText=getHyperAttrText(attrRpt.valText);
					rptCode=`(${attrText})`;
				}else{
					rptCode=attrRpt.val;
				}
			}
			if(attrFit){
				if(attrFit.hyper){
					attrText=getHyperAttrText(attrFit.valText);
					fitCode=`(${attrText})`;
				}else{
					fitCode=attrFit.val;
				}
			}
			if(attrFit.hyper||attrRpt.hyper){
				if(exporter){
					exporter.regUtilFunc("vfactImageSize");
				}
				return `\`vfactImageSize(\$\{${fitCode}\},\$\{${rptCode}\})\``;
			}else{
				return '"'+vfactImageSize(fitCode,rptCode)+'"'
			}
		}
	},
	"background-repeat":{
		keyword:"background-repeat",attrName:"repeat",allowDynamic:true,
		attrVal2CSSVal:vfactImageRepeat,
	},
};

export {vfactElmtPptMap,vfactCSSPptMap,vfactBoxCSSPptMap,vfactTextCSSPptMap,vfactTextSubElmtPptMap,vfactTextSubCSSPptMap,vfactImageCSSPptMap,vfactTextContent};