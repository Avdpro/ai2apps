import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
import inherits from "/@inherits";

//****************************************************************************
//Default def:
//****************************************************************************
let HudArrayDef,GearContainerDef;
{
	HudArrayDef={elementType:"hudobj",allowExtraAttr:1};
	GearContainerDef={
		attrs:{
			"subHuds":{
				name:"subHuds",type:"array",def:HudArrayDef,fixed:1,key:1,edit:false,navi:"doc"
			},
			"container":{name:"container",showName:"Is Containter",type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
		}
	};
}
//****************************************************************************
//Constructor and static functions:
//****************************************************************************
let GearContainer,gearContainer;
{
	//----------------------------------------------------------------------------
	GearContainer=function(owner,def,init){
		let self;
		self=this;
		EditObj.call(this,owner,def,true);
		this.isGearSlot=true;
		this.isContainer=true;

		this.subHuds=this.getAttr("subHuds");
		//Handle subHuds modify events:
		this.subHuds.on("AttrAdd",(...args)=>{self.OnSubAdd(...args);this.emit("AttrAdd",...args)});
		this.subHuds.on("AttrInsert",(...args)=>{self.OnSubInsert(...args);this.emit("AttrInsert",...args)});
		this.subHuds.on("AttrRemove",(...args)=>{self.OnSubRemove(...args);this.emit("AttrRemove",...args)});
		this.subHuds.on("AttrMoveUp",(...args)=>{self.OnSubMoveUp(...args);this.emit("AttrMoveUp",...args)});
		this.subHuds.on("AttrMoveDown",(...args)=>{self.OnSubMoveDown(...args);this.emit("AttrMoveDown",...args)});

		this.editJaxId=def.editJaxId;
		this.liveEdObj=null;
	};
	inherits(GearContainer,EditObj);
	EditAttr.regAttrType("gearcontainer",GearContainer);
	gearContainer=GearContainer.prototype;
	
	//------------------------------------------------------------------------
	GearContainer.getDef=function(name){
		return GearContainerDef;
	};
}

//----------------------------------------------------------------------------
gearContainer.OnDocFocus=function(){
	let list,hud;
	list=this.subHuds.attrList;
	for(hud of list){
		hud.OnDocFocus();
	}
};

//****************************************************************************
//:Sub hud Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//If func return false, stop...
	gearContainer.runOnAllHuds=function(func,hasGearSlot,...args){
		let list,hud;
		if(hasGearSlot && func(this,...args)===false){
			return;
		}
		list=this.subHuds.attrList;
		for(hud of list){
			hud.runOnAllHuds(func,hasGearSlot,...args);
		}
	};
	
	//------------------------------------------------------------------------
	gearContainer.runOnSubHuds=function(func,...args){
		let list,hud;
		list=this.subHuds.attrList;
		for(hud of list){
			func(hud,...args);
		}
	};
	
	//------------------------------------------------------------------------
	gearContainer.addSubHud=function(def){
		return this.subHuds.addAttr({type:"hudobj",def:def});
	};
}

//****************************************************************************
//:Live Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Create a JAXHudObj as child of [fatherHud], with [args] as createArgs
	gearContainer.genHudCSS=function(hyper){
		let subDefs=[];
		let subHuds,i,n;
		//Check children huds:
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		if(subHuds.length>0){
			for(i=0;i<n;i++){
				subDefs[i]=subHuds[i].genHudCSS(hyper);
			}
		}
		return subDefs;
	};

	//------------------------------------------------------------------------
	gearContainer.bindLiveObj=function(liveObj,assignAttr,inTree){
		let subHuds,items,i,n;
		if(this.liveEdObj){
			this.dropLiveObj(this.liveEdObj);
		}
		this.liveEdObj=liveObj;
		subHuds=this.subHuds.attrList;
		items=liveObj.children;
		n=subHuds.length;
		if(items){
			if(items.length!==n && n>0){
				throw new Error("EditHudObj subHuds number not match live-obj's sub-items number.");
			}
			for(i=0;i<n;i++){
				subHuds[i].bindLiveObj(items[i],assignAttr,true);
			}
		}
	};

	//------------------------------------------------------------------------
	gearContainer.dropLiveObj=function(liveObj,inTree=false){
		let subHuds,i,n;
		if(liveObj && liveObj!==this.liveEdObj){
			return;
		}
		this.liveEdObj=null;
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		for(i=0;i<n;i++){
			subHuds[i].dropLiveObj(null,true);
		}
		return;
	};
	
	//------------------------------------------------------------------------
	gearContainer.rebuildLiveObj=function(){
		//GearContainer should not be rebuild.
	};
}

//****************************************************************************
//:Handle edit events 
//****************************************************************************
{
	//------------------------------------------------------------------------
	gearContainer.OnSubAdd=function(subHud){
		subHud.OnThisHudAdd && subHud.OnThisHudAdd();
		if(this.liveEdObj){
			let css,liveObj;
			css=subHud.genHudCSS(this.doc);
			liveObj=this.liveEdObj.appendNewChild(css);
			subHud.bindLiveObj(liveObj);
		}
	};

	//------------------------------------------------------------------------
	gearContainer.OnSubInsert=function(subHud,idx){
		subHud.OnThisHudAdd && subHud.OnThisHudAdd();
		if(this.liveEdObj){
			let css,liveObj,nextHud;
			css=subHud.genHudCSS(this.doc);
			nextHud=this.liveEdObj.children[idx];
			if(nextHud){
				liveObj=this.liveEdObj.insertNewBefore(css,nextHud);
			}else{
				liveObj=this.liveEdObj.appendNewChild(css);
			}
			subHud.bindLiveObj(liveObj);
		}
	};

	//------------------------------------------------------------------------
	gearContainer.OnSubRemove=function(subHud){
		subHud.OnThisHudRemove && subHud.OnThisHudRemove();
		if(this.liveEdObj){
			let liveObj;
			liveObj=subHud.liveEdObj;
			if(liveObj){
				this.liveEdObj.removeChild(liveObj);
			}
		}
	};

	//------------------------------------------------------------------------
	gearContainer.OnSubMoveUp=function(subHud){
		if(this.liveEdObj){
			let liveObj,preObj;
			liveObj=subHud.liveEdObj;
			if(liveObj){
				preObj=liveObj.previousSibling;
				if(preObj){
					liveObj.hold();
					this.liveEdObj.removeChild(liveObj);
					this.liveEdObj.insertBefore(liveObj,preObj);
					liveObj.release();
				}
			}
		}
	};

	//------------------------------------------------------------------------
	gearContainer.OnSubMoveDown=function(subHud){
		let liveObj,nxtObj;
		liveObj=subHud.liveEdObj;
		if(liveObj){
			nxtObj=liveObj.nextSibling;
			if(nxtObj){
				nxtObj.hold();
				this.liveEdObj.removeChild(nxtObj);
				this.liveEdObj.insertBefore(nxtObj,liveObj);
				nxtObj.release();
			}
		}
	};
}

//****************************************************************************
//:I/O
//****************************************************************************
{
	//Seems no overwrite funcion code needed		
}

//****************************************************************************
//:Face access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	gearContainer.enterFaceEdit=function(faceTag,applyAttrs,notifyUsed){
		let subHuds,i,n;
		//Check children huds:
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		if(subHuds.length>0){
			for(i=0;i<n;i++){
				subHuds[i].enterFaceEdit(faceTag,applyAttrs,notifyUsed);
			}
		}
	};

	//------------------------------------------------------------------------
	gearContainer.exitFaceEdit=function(updateAttr){
		let subHuds,i,n;
		//Check children huds:
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		if(subHuds.length>0){
			for(i=0;i<n;i++){
				subHuds[i].exitFaceEdit(updateAttr);
			}
		}
	};
	
	//------------------------------------------------------------------------
	gearContainer.updateFaceState=function(faceTag,init){
		let subHuds,i,n;
		//Check children huds:
		subHuds=this.subHuds.attrList;
		n=subHuds.length;
		if(subHuds.length>0){
			for(i=0;i<n;i++){
				subHuds[i].updateFaceState(faceTag,init);
			}
		}
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	gearContainer.getName=function(){
		return `${this.def.showName}`;
	};
	
	//------------------------------------------------------------------------
	//Return sub-hud-nodes:
	gearContainer.getNaviSubList=function(){
		let slist,tlist,i,n,attr,navi;
		tlist=[];
		slist=this.subHuds.attrList;
		n=slist.length;
		for(i=0;i<n;i++){
			attr=slist[i];
			tlist.push(attr);
		}
		return tlist.length?tlist:null;
	};
	
	//------------------------------------------------------------------------
	gearContainer.getEditRootPpts=function(){
		return [];
	};
	
}

export {GearContainer};
