import {EditHudObj} from "./EditHudObj.js";
import {HudObjDef,HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,UIView,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox} from "./HudTypes.js";
import {vfactElmtPptMap,vfactCSSPptMap,vfactTextCSSPptMap,vfactTextSubElmtPptMap,vfactTextSubCSSPptMap} from "./HTMLPptDef.js";

//Fix HudTypes for react export:
HudObjDef.HTMLElemntType="div";
//Box:
{
	HudBoxDef.HTMLElemntType="div";
	HudBoxDef.HTMLCSSPptMap={...vfactCSSPptMap,...vfactBoxCSSPptMap};
}
//----------------------------------------------------------------------------
//Text is 2-divs:
{
	HudTextDef.HTMLElemntType="div";
	HudTextDef.HTMLElmtPptMap=vfactElmtPptMap;
	HudTextDef.HTMLCSSPptMap=vfactTextCSSPptMap;
	HudTextDef.HTMLSubElements=[{
		elementType:"div",
		elmtPptMap:vfactTextSubElmtPptMap,
		cssPptMap:vfactTextSubCSSPptMap,
	}];
}
HudButtonDef.HTMLElemntType="div";
HudImageDef.HTMLElemntType="div";
HudEditDef.HTMLElemntType="div";
UIView.HTMLElemntType="div";
HudFlexHBox.HTMLElemntType="div";
HudFlexVBox.HTMLElemntType="div";
HudFlexHRBox.HTMLElemntType="div";
HudFlexVRBox.HTMLElemntType="div";
HudGridBox.HTMLElemntType="div";
HudTreeBox.HTMLElemntType="div";

EditHudObj.regHudDef("hud",HudObjDef);
EditHudObj.regCatalogHudDef("Basic","hud",HudObjDef);
EditHudObj.regCatalogHudDef("Containers","hud",HudObjDef);

EditHudObj.regHudDef("box",HudBoxDef);
EditHudObj.regCatalogHudDef("Basic","box",HudBoxDef);
EditHudObj.regCatalogHudDef("Containers","box",HudBoxDef);

EditHudObj.regHudDef("text",HudTextDef);
EditHudObj.regCatalogHudDef("Basic","text",HudTextDef);
EditHudObj.regCatalogHudDef("Texts","text",HudTextDef);

EditHudObj.regHudDef("button",HudButtonDef);
EditHudObj.regCatalogHudDef("Buttons","button",HudButtonDef);

EditHudObj.regHudDef("image",HudImageDef);
EditHudObj.regCatalogHudDef("Basic","image",HudImageDef);
EditHudObj.regCatalogHudDef("Medias","image",HudImageDef);

EditHudObj.regHudDef("edit",HudEditDef);
EditHudObj.regCatalogHudDef("Inputs","edit",HudEditDef);
