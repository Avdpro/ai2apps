import {EditHudObj} from "./EditHudObj.js";
import {HudObjDef,HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,UIView,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox} from "./HudTypes.js";
import {vfactElmtPptMap,vfactCSSPptMap,vfactBoxCSSPptMap,vfactTextCSSPptMap,vfactTextSubElmtPptMap,vfactTextSubCSSPptMap,vfactTextContent} from "./HTMLPptDef.js";

var eventsDef={
	name:"events",showName:"events",type:"object",key:1,fixed:1,navi:"doc",edit:1,
	def:{
		icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
		attrs:{
			//Keyboard Events:
			"onKeyDown":{name:"onKeyDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onKeyPress":{name:"onKeyPress",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onKeyUp":{name:"onKeyUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Clipboard Events:
			"onCopy":{name:"onCopy",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onCut":{name:"onCut",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPaste":{name:"onPaste",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Focus Events
			"onFocus":{name:"onFocus",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onBlur":{name:"onBlur",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Form Events
			"onChange":{name:"onChange",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onInput":{name:"onInput",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onInvalid":{name:"onInvalid",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onReset":{name:"onReset",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onSubmit":{name:"onSubmit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Generic Events
			"onError":{name:"onError",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onLoad":{name:"onLoad",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Mouse Events:
			"onClick":{name:"onClick",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onContextMenu":{name:"onContextMenu",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDoubleClick":{name:"onDoubleClick",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDrag":{name:"onDrag",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragEnd":{name:"onDragEnd",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragEnter":{name:"onDragEnter",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragExit":{name:"onDragExit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragLeave":{name:"onDragLeave",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragOver":{name:"onDragOver",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDragStart":{name:"onDragStart",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDrop":{name:"onDrop",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseDown":{name:"onMouseDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseEnter":{name:"onMouseEnter",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseLeave":{name:"onMouseLeave",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseMove":{name:"onMouseMove",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseOut":{name:"onMouseOut",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseOver":{name:"onMouseOver",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onMouseUp":{name:"onMouseUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Pointer Events
			"onPointerDown":{name:"onPointerDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerMove":{name:"onPointerMove",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerUp":{name:"onPointerUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerCancel":{name:"onPointerCancel",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onGotPointerCapture":{name:"onGotPointerCapture",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onLostPointerCapture":{name:"onLostPointerCapture",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerEnter":{name:"onPointerEnter",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerLeave":{name:"onPointerLeave",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerOver":{name:"onPointerOver",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPointerOut":{name:"onPointerOut",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Selection Events
			"onSelect":{name:"onSelect",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Touch Events
			"onTouchCancel":{name:"onTouchCancel",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onTouchEnd":{name:"onTouchEnd",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onTouchMove":{name:"onTouchMove",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onTouchStart":{name:"onTouchStart",type:"fixedFunc",arguments:["event"],fixed:1,key:0},

			//UI Events
			"onScroll":{name:"onScroll",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Wheel Events
			"onWheel":{name:"onWheel",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			
			//Media Events
			"onAbort":{name:"onAbort",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onCanPlay":{name:"onCanPlay",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onCanPlayThrough":{name:"onCanPlayThrough",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onDurationChange":{name:"onDurationChange",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onEmptied":{name:"onEmptied",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onEncrypted":{name:"onEncrypted",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onEnded":{name:"onEnded",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onLoadedData":{name:"onLoadedData",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onLoadedMetadata":{name:"onLoadedMetadata",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onLoadStart":{name:"onLoadStart",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPause":{name:"onPause",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPlay":{name:"onPlay",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onPlaying":{name:"onPlaying",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onProgress":{name:"onProgress",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onRateChange":{name:"onRateChange",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onSeeked":{name:"onSeeked",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onSeeking":{name:"onSeeking",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onStalled":{name:"onStalled",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onSuspend":{name:"onSuspend",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onTimeUpdate":{name:"onTimeUpdate",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onVolumeChange":{name:"onVolumeChange",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onWaiting":{name:"onWaiting",type:"fixedFunc",arguments:["event"],fixed:1,key:0},

			//Animation Events
			"onAnimationStart":{name:"onAnimationStart",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onAnimationEnd":{name:"onAnimationEnd",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onAnimationIteration":{name:"onAnimationIteration",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
			"onTransitionEnd":{name:"onTransitionEnd",type:"fixedFunc",arguments:["event"],fixed:1,key:0},

			//Other:
			"onToggle":{name:"onToggle",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
		},
		listHint:[
			"onClick","onLoad","onError","onFocus","onBlur","onSelect","onScroll",
			{name:"MouseEvents",showname:"Mouse Events",attrs:["onContextMenu","onDoubleClick","onDrag","onDragEnd","onDragEnter","onDragExit","onDragLeave","onDragOver","onDragStart","onDrop","onMouseDown","onMouseEnter","onMouseLeave","onMouseMove","onMouseOut","onMouseOver","onMouseUp","onWheel"]},
			{name:"KeyboardEvents",showname:"Keyboard Events",attrs:["onKeyDown","onKeyPress","onKeyUp"]},
			{name:"FormEvents",showname:"Form Events",attrs:["onChange","onInput","onInvalid","onReset","onSubmit"]},
			{name:"PointerEvents",showname:"Pointer Events",attrs:["onPointerDown","onPointerMove","onPointerUp","onPointerCancel","onGotPointerCapture","onLostPointerCapture","onPointerEnter","onPointerLeave","onPointerOver","onPointerOut"]},
			{name:"Touch Events",showname:"Touch Events",attrs:["onTouchCancel","onTouchEnd","onTouchMove","onTouchStart","onWheel"]},
			{name:"MediaEvents",showname:"Media Events",attrs:["onAbort","onCanPlay","onCanPlayThrough","onDurationChange","onEmptied","onEncrypted","onEnded","onLoadedData","onLoadedMetadata","onLoadStart","onPause","onPlay","onPlaying","onProgress","onRateChange","onSeeked","onSeeking","onStalled","onSuspend","onTimeUpdate","onVolumeChange","onWaiting"]},
			{name:"AnimationEvents",showname:"Animation Events",attrs:["onAnimationStart","onAnimationEnd","onAnimationIteration","onTransitionEnd"]},
			"onToggle"
		],
	}
};

//Fix HudTypes for react export:
HudObjDef.HTMLElemntType="div";
HudObjDef.attrs.events=eventsDef;
delete HudObjDef.attrs.functions;

//Box:
{
	HudBoxDef.HTMLElemntType="div";
	HudBoxDef.HTMLCSSPptMap={...vfactCSSPptMap,...vfactBoxCSSPptMap};
	HudBoxDef.attrs.events=eventsDef;
	delete HudBoxDef.attrs.functions;
}
//----------------------------------------------------------------------------
//Text is 2-divs:
{
	HudTextDef.HTMLElemntType="div";
	HudTextDef.HTMLElmtPptMap=vfactElmtPptMap;
	HudTextDef.HTMLCSSPptMap={...vfactCSSPptMap,...vfactTextCSSPptMap};
	HudTextDef.HTMLSubElements=[{
		elmtType:"div",
		elmtPptMap:vfactTextSubElmtPptMap,
		cssPptMap:vfactTextSubCSSPptMap,
		elmtContent:vfactTextContent
	}];
	HudTextDef.attrs.events=eventsDef;
}
HudButtonDef.HTMLElemntType="div";
HudButtonDef.attrs.events=eventsDef;

HudImageDef.HTMLElemntType="div";
HudImageDef.attrs.events=eventsDef;

HudEditDef.HTMLElemntType="div";
HudEditDef.attrs.events=eventsDef;

UIView.HTMLElemntType="div";
UIView.attrs.events=eventsDef;

HudFlexHBox.HTMLElemntType="div";
HudFlexHBox.attrs.events=eventsDef;

HudFlexVBox.HTMLElemntType="div";
HudFlexVBox.attrs.events=eventsDef;

HudFlexHRBox.HTMLElemntType="div";
HudFlexHRBox.attrs.events=eventsDef;

HudFlexVRBox.HTMLElemntType="div";
HudFlexVRBox.attrs.events=eventsDef;

HudGridBox.HTMLElemntType="div";
HudGridBox.attrs.events=eventsDef;

HudTreeBox.HTMLElemntType="div";
HudTreeBox.attrs.events=eventsDef;


EditHudObj.regHudDef("hud",HudObjDef);
EditHudObj.regCatalogHudDef("Basic","hud",HudObjDef);
EditHudObj.regCatalogHudDef("Containers","hud",HudObjDef);

EditHudObj.regHudDef("box",HudBoxDef);
EditHudObj.regCatalogHudDef("Basic","box",HudBoxDef);
EditHudObj.regCatalogHudDef("Containers","box",HudBoxDef);

EditHudObj.regHudDef("text",HudTextDef);
EditHudObj.regCatalogHudDef("Basic","text",HudTextDef);
EditHudObj.regCatalogHudDef("Texts","text",HudTextDef);

EditHudObj.regHudDef("button",HudButtonDef);
EditHudObj.regCatalogHudDef("Buttons","button",HudButtonDef);

EditHudObj.regHudDef("image",HudImageDef);
EditHudObj.regCatalogHudDef("Basic","image",HudImageDef);
EditHudObj.regCatalogHudDef("Medias","image",HudImageDef);

EditHudObj.regHudDef("edit",HudEditDef);
EditHudObj.regCatalogHudDef("Inputs","edit",HudEditDef);

EditHudObj.regHudDef("view",UIView);
EditHudObj.regCatalogHudDef("Containers","view",UIView);
EditHudObj.regCatalogHudDef("Views","view",UIView);
EditHudObj.regCatalogHudDef("View","view",UIView);

