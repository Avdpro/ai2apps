import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditHudObj,HudObjShellAttr} from "./EditHudObj.js";
import {genAttrValText,genLocalizeValText} from "../exporters/EditDocExporter.js";
import {ExportObj} from "../exporters/ExportObj.js";
import {VFACT} from "/@vfact";

const $ln=VFACT.lanCode;

let editObj=EditObj.prototype;
let ContainerArrayDef={elementType:"hudobj",allowExtraAttr:1};


var EditHudGear,editHudGear;
EditHudGear=function(owner,def,init){
	let objDef,self,typeAttr,faceAttr;
	self=this;
	EditHudObj.call(this,owner,def,init);
	this.isHudGear=true;
	objDef=this.objDef;
	this.gearFunc=objDef.gearFunc;
	this.createArgs=this.getAttr("createArgs");
	this.createArgs.onNotify("Changed",(attr)=>{
		self.updateTypeAttr();
		self.rebuildLiveObj();
		self.emitObjChange();
		self.properties.emitObjChange();
	});
	faceAttr=this.faceAttr=this.properties.getAttr("face");
	if(faceAttr){
		faceAttr.onChange(()=>{
			self.rebuildLiveObj();
		});
	}
	this.containerSlots=this.getAttr("containerSlots");
	this.gearArgVersion=this.createArgs.def.gearArgVersion;
	this.typeAttr=this.properties.getAttr("type");
	this.updateTypeAttr();
	this.isContainer=false;
};
inherits(EditHudGear,EditHudObj);
editHudGear=EditHudGear.prototype;

//****************************************************************************
//:GearDef generate functions
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Generate a gear's obj-def by a gearDoc in same project:
	EditHudGear.genInteralGearDef=function(gearDoc){
		let defVO;
		let gearPpts={},gearListHint;
		let createArgs={};
		let expAttrs;
		let path,importName,pos,gearIcon,catalog;
		let oneHud;
		let exposeStateAttrs,stateAttr,attrName,stateAttrHints;
		let gearStateAttrs,desc;
		path=gearDoc.getAttr("path").val;
		importName=pathLib.basename(path);
		pos=importName.lastIndexOf(".");
		if(pos>0){
			importName=importName.substring(0,pos);
		}
		oneHud=gearDoc.oneHud;
		oneHud=oneHud?oneHud.val:false;
		gearIcon=gearDoc.gearIcon.val;
		catalog=gearDoc.gearCatalog.val;
		exposeStateAttrs=gearDoc.exposeStateAttrs.attrList;
		stateAttrHints=[];
		gearStateAttrs=gearDoc.stateObj.attrHash;
		{
			desc=gearDoc.getAttr("description");
			let locs=desc.localize;
			if(locs){
				desc=locs[$ln]||desc.val||null;
			}else{
				desc=desc.val||null;
			}
		}
		defVO={
			name:"Gear"+gearDoc.jaxId,
			icon:gearIcon||"gears.svg",
			catalog:catalog||"",
			initW:gearDoc.gearW.val||100,
			initH:gearDoc.gearH.val||100,
			previewImg:gearDoc.getAttr("previewImg").val,
			fixPose:gearDoc.getAttr("fixPose").val,
			desc:desc,
			allowExtraAttr:!!oneHud,
			naviMultiSel:1,
			naviHasSub:false,
			gearFunc:gearDoc.gearCSSFunction.bind(gearDoc),
			constructFunc:EditHudGear,
			get showName(){
				let nameVal,name,extName,locs;
				nameVal=gearDoc.gearName;
				name=nameVal.val;
				if(name){
					locs=nameVal.localize;
					name=locs?(locs[$ln]||name):name;
					return name;
				}
				name=gearDoc.getName();
				extName=pathLib.extname(name);
				name=name.substring(0,name.length-extName.length);
				return name;
			},
			source:path,
			importName:importName,
			orgArgAttrs:gearDoc.createArgs,
		};
		//Generate ppts:
		if(oneHud){
			let defAttrs,attrHash,attr,orgAttr,name,attrDef;
			defAttrs=gearDoc.hudObj.properties.objDef.attrs;
			attrHash=gearDoc.hudObj.properties.attrHash;
			gearPpts={};
			defVO.majorEditAttr=gearDoc.hudObj.objDef.majorEditAttr;
			for(name in defAttrs){
				attrDef=defAttrs[name];
				attr=attrHash[name];
				switch(name){
					case "type":
					case "id":
					case "x":
					case "y":
					case "display":
					case "position":
							gearPpts[name]={...attrDef};
						break;
					default:
						if(attr){
							gearPpts[name]={...attrDef,key:false,initValText:attr.valText,initVal:attr.val};
						}else{
							gearPpts[name]={...attrDef,key:false};
						}
						break;
				}
			}
			if(defVO.majorEditAttr){
				gearPpts[defVO.majorEditAttr].key=1;
			}
			gearListHint=[...gearDoc.hudObj.properties.objDef.listHint,"face"];
		}else{
			let attr,orgAttrHash,orgAttrDefs,orgAttr,i,n,orgHints,hint;
			let baseDef,baseAttrs,attrs,attrDef;
			expAttrs=gearDoc.exposeAttrs.attrList;
			orgAttrHash=gearDoc.hudObj.properties.attrHash;
			orgAttrDefs=gearDoc.hudObj.properties.objDef.attrs;
			
			baseDef=EditHudObj.getDef("hud");
			baseAttrs=baseDef.attrs.properties.def.attrs;

			attrs=["id","position","x","y","display","exposeToAI","descAI"];
			for(attrName of attrs){
				attrDef=baseAttrs[attrName];
				gearPpts[attrName]={...attrDef,key:0};
			}
			
			//Generate gear attrs, by default, all attrs are not key:
			for(attr of expAttrs){
				if(attr.val){
					orgAttr=orgAttrHash[attr.name];
					if(orgAttr){
						gearPpts[attr.name]={...orgAttr.def,key:0,initVal:orgAttr.val};
					}else{
						let def=orgAttrDefs[attr.name];
						if(def){
							gearPpts[attr.name]={...def,key:0};
						}
					}
				}
			}
			//add exposed-state-attrs:
			for(attr of exposeStateAttrs){
				attrName=attr.val;
				attr=gearStateAttrs[attrName];
				if(attr && !gearPpts[attrName]){//state-attr can't overwrite component basic attr:
					gearPpts[attrName]={...attr.def,key:0,fixed:1,initVal:attr.val,gearStateAttr:1};
					stateAttrHints.push(attrName);
				}
			}
			//id, x, y should be key:
			if(gearPpts.id){gearPpts.id.key=1;}
			if(gearPpts.x){gearPpts.x.key=1;}
			if(gearPpts.y){gearPpts.y.key=1;}
			if(gearPpts.display){gearPpts.display.key=1;}
			if(gearPpts.position){gearPpts.position.key=1;}
			gearPpts["face"]={"name":"face",showName:(($ln==="CN")?("预设外观"):/*EN*/("Face")),type:"auto",editType:"face",initVal:undefined,key:1,fixed:1,hideVal:undefined};
			//Generate gear listHint:
			orgHints=gearDoc.hudObj.properties.objDef.listHint;
			if(orgHints){
				gearListHint=[];
				n=orgHints.length;
				for(i=0;i<n;i++){
					hint=orgHints[i];
					if(typeof(hint)==="string"){//An attr:
						if(gearPpts[hint]){
							gearListHint.push(hint);
						}
					}else{//Group:
						let group,a,attrs;
						attrs=[];
						for(a of hint.attrs){
							if(gearPpts[a]){
								attrs.push(a);
							}
						}
						if(attrs.length){
							group={
								name:hint.name,
								showName:hint.showName,
								open:hint.open,
								attrs:attrs
							};
							gearListHint.push(group);
						}
					}
				}
				//add state properties:
				gearListHint.unshift({name:"statePpts",showName:"State Properties",open:1,attrs:stateAttrHints});
				gearListHint.push("face");
			}
		}
		
		//Generate args:
		createArgs=gearDoc.createArgs.genEditObjAttrsDef();

		defVO.attrs={
			createArgs:{
				name:"createArgs",showName:(($ln==="CN")?("构造参数"):/*EN*/("Arguments")),type:"object",key:1,fixed:1,edit:1,watchTree:true,
				def:{
					icon:"args.svg",
					name:"gearCrateArgs",attrs:createArgs
				},
				gearArgVersion:0
			},
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...gearPpts
					},
					listHint:gearListHint
				},
				//TODO: Replace getEditSubPpts to support state?
				objAttrs:{
				}
			},
			...HudObjShellAttr,
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":{...gearDoc.hudObj.objDef.attrs.functions},
			"containerSlots":{
				name:"containerSlots",type:"object",fixed:1,key:1,edit:false,
				def:{
					attrs:gearDoc.genGearSlotsDef()
				}
			}
		};
		
		//Gear description:
		defVO.desc=gearDoc.getAttr("description").val||null;
		//Gear faces:
		{
			let faceTags,i,n,faces;
			faceTags=gearDoc.faceTags.attrList;
			faces=defVO.faces=[];
			n=faceTags.length;
			for(i=0;i<n;i++){
				faces.push(faceTags[i].name);
			}
		}
		return defVO;
	};

	//------------------------------------------------------------------------
	let updateGearArgsVsn=0;
	EditHudGear.updateGearArgs=function(gearDef,gearDoc){
		let createArgs,argsDef,gearArgs,orgAttr,tgtArgs,defName,newDef,oldDef;
		let exposeStateAttrs,stateAttr;
		let stateAttrHints,baseKeyAttrs;
		
		stateAttrHints=[];
		updateGearArgsVsn++;
		argsDef=gearDef.attrs.createArgs;
		gearDoc.createArgs.updateGenedAttrDef(argsDef);
		argsDef.gearArgVersion++;
		baseKeyAttrs=new Set(["id","position","x","y","display","exposeToAI","descAI"]);
		//update gear properties :
		{
			let gearPpts,expAttrs,attr,attrDef,orgAttrHash,orgAttr,gearAttrDef;
			let orgHints,gearListHint,n,i,hint,attrName;
			gearPpts=gearDef.attrs.properties.def.attrs;
			expAttrs=gearDoc.exposeAttrs.attrList;
			orgAttrHash=gearDoc.hudObj.properties.attrHash;
			//Update ppts:
			for(attr of expAttrs){
				gearAttrDef=gearPpts[attr.name];
				if(attr.val){
					if(!gearAttrDef){
						orgAttr=orgAttrHash[attr.name];
						if(orgAttr){
							gearPpts[attr.name]=({...orgAttr.def,key:0,initVal:orgAttr.val});
						}else{
							attrDef=gearDoc.hudObj.properties.objDef.attrs[attr.name];
							if(attrDef){
								gearPpts[attr.name]=({...attrDef,key:0,initVal:attrDef.initVal});
							}
						}
					}else{
						//Do nothing?
					}
				}else{
					if(gearAttrDef && !baseKeyAttrs.has(gearAttrDef.name)){
						gearAttrDef.deadOut=1;
						gearAttrDef.key=false;
						gearAttrDef.fixed=false;
						delete gearPpts[attr.name];
					}
				}
			}
			//Ensure state-attrs:
			exposeStateAttrs=gearDoc.exposeStateAttrs.attrList;
			for(attr of exposeStateAttrs){
				attrName=attr.val;
				stateAttr=gearDoc.stateObj.getAttr(attrName);
				if(stateAttr){
					attrDef=gearPpts[attrName];
					gearAttrDef=stateAttr.def;
					stateAttrHints.push(attrName);
					FindAttr:{
						if(gearAttrDef && attrDef){
							if(attrDef.type===gearAttrDef.type){
								attrDef.updateGearArgsVsn=updateGearArgsVsn;
								break FindAttr;
							}else{
								//Need change type:
								gearAttrDef.deadOut=1;
								gearAttrDef.key=false;
								gearAttrDef.fixed=false;
								delete gearPpts[attrName];
							}
						}
						//Add this attr:
						gearDef[attrName]={...gearAttrDef,key:0,initVal:stateAttr.val,gearStateAttr:1,updateGearArgsVsn:updateGearArgsVsn};
					}
				}
			}
			//Remove deleted state attr:
			for(attrName in gearPpts){
				gearAttrDef=gearPpts[attrName];
				if(gearAttrDef.gearStateAttr){
					if(gearAttrDef.updateGearArgsVsn===updateGearArgsVsn){
						delete gearAttrDef.updateGearArgsVsn;
					}else{
						gearAttrDef.deadOut=1;
						gearAttrDef.key=false;
						gearAttrDef.fixed=false;
						delete gearPpts[attrName];
					}
				}
			}
			//id, x, y should be key:
			if(gearPpts.id){gearPpts.id.key=1;}
			if(gearPpts.x){gearPpts.x.key=1;}
			if(gearPpts.y){gearPpts.y.key=1;}
			if(gearPpts.display){gearPpts.display.key=1;}
			if(gearPpts.position){gearPpts.position.key=1;}
			//Update listHint:
			orgHints=gearDoc.hudObj.properties.objDef.listHint;
			if(orgHints){
				gearListHint=gearDef.attrs.properties.def.listHint;
				gearListHint.splice(0);
				n=orgHints.length;
				for(i=0;i<n;i++){
					hint=orgHints[i];
					if(typeof(hint)==="string"){//An attr:
						if(gearPpts[hint]){
							gearListHint.push(hint);
						}
					}else{//Group:
						let group,a,attrs;
						attrs=[];
						for(a of hint.attrs){
							if(gearPpts[a]){
								attrs.push(a);
							}
						}
						if(attrs.length){
							group={
								name:hint.name,
								showName:hint.showName,
								open:hint.open,
								attrs:attrs
							};
							gearListHint.push(group);
						}
					}
				}
				//Add exposed state attrs:
				if(exposeStateAttrs.length){
					gearListHint.unshift({name:"StatePpts",showName:(($ln==="CN")?("状态对象属性"):/*EN*/("State Properties")),open:1,attrs:stateAttrHints});
				}
			}
		}
		//update gear icon:
		gearDef.icon=gearDoc.gearIcon.val||"gears.svg";
		//update init size:
		gearDef.initW=gearDoc.gearW.val||100;
		gearDef.initH=gearDoc.gearH.val||100;
		{
			let desc=gearDoc.getAttr("description");
			let locs=desc.localize;
			if(locs){
				gearDef.desc=locs[$ln]||desc.val||null;
			}else{
				gearDef.desc=desc.val||null;
			}
		}
		gearDef.previewImg=gearDoc.getAttr("previewImg").val;
		gearDef.fixPose=gearDoc.getAttr("fixPose").val;
		//update faces:
		{
			let faceTags,i,n,faces;
			faceTags=gearDoc.faceTags.attrList;
			faces=gearDef.faces;
			faces.splice(0);
			n=faceTags.length;
			for(i=0;i<n;i++){
				faces.push(faceTags[i].name);
			}
		}
		//update gear containerSlots:
		{
			let curSlots,defSlots,name,attr,slot;
			curSlots=gearDoc.genGearSlotsDef();
			defSlots=gearDef.attrs.containerSlots.def.attrs;
			for(name in curSlots){
				attr=defSlots[name];
				slot=curSlots[name];
				if(!attr){
					defSlots[name]=slot;
				}else{
					attr.showName=slot.showName;
					attr.contentLayout=slot.contentLayout;
				}
			}
			for(name in defSlots){
				if(!curSlots[name]){
					delete defSlots[name];
				}
			}
		}
	};

	//------------------------------------------------------------------------
	//Generate a gear's obj-def by a js-file-path:
	EditHudGear.genExteralGearDef=async function(gearPath){
		let gearMod,name,func,pos,exportVO;
		let defVO;
		let createArgs={};
		let gearPpts={};
		let gearListHint;
		try{
			gearMod=await import(gearPath);
		}catch(err){
			gearMod=null;
			console.error(`Error during import extern-gear: "${gearPath}"`);
			console.log(err);
		}
		if(!gearMod)
			return;
		FindObj:{
			for(name in gearMod){
				func=gearMod[name];
				if(name==="default"){
					continue;//Gear must be export with name.
				}
				exportVO=func.gearExport;
				if(exportVO){
					break FindObj;
				}
			}
			console.error(`No usable gear found in: "${gearPath}"`);
			return null;
		}
		
		defVO={
			name:"Gear"+gearPath,
			source:gearPath,
			importName:name,
			icon:exportVO.icon||"disk.svg",
			previewImg:exportVO.previewImg,
			initW:exportVO.initW||100,
			initH:exportVO.initH||100,
			fixPose:exportVO.fixPose,
			desc:exportVO.desc||"",
			catalog:exportVO.catalog,
			allowExtraAttr:false,
			naviMultiSel:1,
			naviHasSub:false,
			majorEditArg:exportVO.majorEditArg,
			gearFunc:(argsObj)=>{
				let attrList,args,attr;
				args=[];
				attrList=argsObj.attrList;
				for(attr of attrList){
					if(attr.def){
						switch(attr.def.type){
							case "object":
							case "array":
								args.push(attr.selfProxy);
								break;
							default:
								args.push(attr.val);
								break;
						}
					}else{
						args.push(attr.val);
					}
				}
				return func(...args);
			},
			constructFunc:EditHudGear,
			get showName(){
				return exportVO.showName||name;
			},
			orgArgAttrs:null,
		};
		
		//Generate create args:
		{
			let attrName,attrs,attrDef;
			attrs=exportVO.args;
			for(attrName in attrs){
				createArgs[attrName]={name:attrName,...attrs[attrName],key:1,fixed:1};
			}
		}
		//Generate properties:
		if(exportVO.oneHud){
			let baseDef,gearAttrs,attrName,attrDef,baseAttrs,gearAttr;
			let orgHints,i,n,hint;
			baseDef=EditHudObj.getDef(exportVO.hudType||"hud");
			if(!baseDef){
				baseDef=EditHudObj.getDef("hud");
			}
			baseAttrs=baseDef.attrs.properties.def.attrs;
			gearAttrs=exportVO.properties;
			for(attrName in baseAttrs){
				attrDef=baseAttrs[attrName];
				gearAttr=gearAttrs[attrName];
				if(!gearAttr){
					gearPpts[attrName]={...attrDef,key:0};
				}else{
					gearPpts[attrName]={...attrDef,...gearAttr,key:0};
				}
				gearListHint=[...baseDef.attrs.properties.def.listHint];
			}
			defVO.majorEditAttr=baseDef.majorEditAttr;
			if(defVO.majorEditAttr){
				gearPpts[defVO.majorEditAttr].key=1;
			}
		}else{
			let baseDef,attrs,attrName,attrDef,baseAttrs;
			let orgHints,i,n,hint;
			let statePpts;
			baseDef=EditHudObj.getDef(exportVO.hudType||"hud");
			if(!baseDef){
				baseDef=EditHudObj.getDef("hud");
			}
			baseAttrs=baseDef.attrs.properties.def.attrs;

			attrs=["id","position","x","y","display","exposeToAI","descAI"];
			for(attrName of attrs){
				attrDef=baseAttrs[attrName];
				gearPpts[attrName]={...attrDef,key:0};
			}
			statePpts=exportVO.state;
			for(attrName in statePpts){
				attrDef=statePpts[attrName];
				gearPpts[attrName]={...attrDef,key:0,fixed:1};
			}

			attrs=[...exportVO.properties];
			for(attrName of attrs){
				attrDef=baseAttrs[attrName];
				gearPpts[attrName]={...attrDef,key:0};
			}

			orgHints=baseDef.attrs.properties.def.listHint;
			if(orgHints){
				gearListHint=[];
				n=orgHints.length;
				for(i=0;i<n;i++){
					hint=orgHints[i];
					if(typeof(hint)==="string"){//An attr:
						if(gearPpts[hint]){
							gearListHint.push(hint);
						}
					}else{//Group:
						let group,a,attrs;
						attrs=[];
						for(a of hint.attrs){
							if(gearPpts[a]){
								attrs.push(a);
							}
						}
						if(attrs.length){
							group={
								name:hint.name,
								showName:hint.showName,
								open:hint.open,
								attrs:attrs
							};
							gearListHint.push(group);
						}
					}
				}
				if(statePpts){
					gearListHint.unshift({
						name:"statePpts",
						showName:(($ln==="CN")?("状态对象属性"):/*EN*/("State Properties")),
						open:1,
						attrs:Object.keys(statePpts)
					});
				}
			}
		}
		let baseDef;
		//id, x, y should be key:
		baseDef=EditHudObj.getDef(exportVO.hudType||"hud");
		if(!baseDef){
			baseDef=EditHudObj.getDef("hud");
		}
		if(gearPpts.id){gearPpts.id.key=1;}
		if(gearPpts.x){gearPpts.x.key=1;}
		if(gearPpts.y){gearPpts.y.key=1;}
		if(gearPpts.display){gearPpts.display.key=1;}
		if(gearPpts.position){gearPpts.position.key=1;}
		
		let gearSlots={};
		let subContainers=exportVO.subContainers;
		if(subContainers){
			let name,stub;
			for(name in subContainers){
				stub=subContainers[name];
				gearSlots["Slot"+name]={
					icon:"pin.svg",name:"Slot"+name,showName:stub.showName,type:"gearcontainer",editJaxId:name,key:1,fixed:1,
					contentLayout:stub.contentLayout,
				};
			}
		}
		
		defVO.attrs={
			createArgs:{
				name:"createArgs",showName:(($ln==="CN")?("构造参数"):/*EN*/("Arguments")),type:"object",key:1,fixed:1,edit:1,watchTree:true,
				def:{
					icon:"args.svg",
					name:"gearCrateArgs",attrs:createArgs
				}
			},
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:1,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...gearPpts,
						"face":{"name":"face",showName:(($ln==="CN")?("预设外观"):/*EN*/("Face")),type:"auto",editType:"face",initVal:undefined,key:1,fixed:1,hideVal:undefined}
					},
					listHint:gearListHint
				},
			},
			...HudObjShellAttr,
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":{...baseDef.attrs.functions},
			"containerSlots":{
				name:"containerSlots",type:"object",fixed:1,key:1,edit:false,
				def:{attrs:gearSlots}
			}
		};
		//Add face:
		if(exportVO.faces){
			defVO.faces=exportVO.faces.splice(0);
		}
		return defVO;
	};
}

//----------------------------------------------------------------------------
editHudGear.OnDocFocus=function(){
	let argObj,argDef;
	argObj=this.createArgs;
	argDef=argObj.def;
	if(this.gearArgVersion!==argDef.gearArgVersion){
		//Sync create-arg:
		this.createArgs.syncWithDef(false,true,true);
	}
};

//****************************************************************************
//:Sub hud Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//If func return false, stop...
	editHudGear.runOnAllHuds=function(func,hasGearSlot,...args){
		let list,hud;
		if(func(this,...args)===false){
			return;
		}
		list=this.containerSlots.attrList;
		for(hud of list){
			hud.runOnAllHuds(func,hasGearSlot,...args);
		}
	};

	//------------------------------------------------------------------------
	editHudGear.addSubHud=function(def){
		console.warn("EditHudGear can't add more sub Huds");
		return null;
	};
}

//****************************************************************************
//:Hyper attr access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editHudGear.updateTypeAttr=function(){
		let def,objDef,typeAttr,text,orgArgAttrs,orgAttr,attr,attrHash,attrList,attrText;
		let pos,cnt,doc,exportType;
		doc=this.doc;
		exportType=doc.getAttr("exportTarget");
		if(exportType){
			exportType=exportType.val;
		}
		//Update create args:
		typeAttr=this.typeAttr;
		text=`#null#>${this.objDef.importName}(`;
		orgArgAttrs=this.objDef.orgArgAttrs;
		attrHash=this.createArgs.attrHash;
		if(!orgArgAttrs){
			attrList=this.createArgs.attrList;
			for(attr of attrList){
				attrText=attr.valText||"";
				if(attr.localize){
					attrText=genLocalizeValText(attr);
				}else{
					attrText=genAttrValText(attr,attrText);
				}
				text+=attrText+",";
			}
		}else{
			orgArgAttrs=orgArgAttrs.attrList;
			for(orgAttr of orgArgAttrs){
				attr=attrHash[orgAttr.name]||orgAttr;
				attrText=attr.valText||"";
				if(attr.name==="opts"){
					pos="JS";
				}
				if(attr.localize){
					attrText=genLocalizeValText(attr);
				}else{
					attrText=genAttrValText(attr,attrText);
				}
				text+=attrText+",";
			}
		}
		if(text.endsWith(",")){
			text=text.substring(0,text.length-1);//Remove last ","
		}
		text+=")";
		typeAttr.valText=text;
	};

	//------------------------------------------------------------------------
	editHudGear.updateHyperAttrs=function(force=false){
		let attrs,attr,attrDef,attrList,i,n;
		attrs=this.createArgs.attrs;
		attrs.ensureKeys();
		attrs.ensureOnlyKeys();
		attrs=this.properties.attrs;
		attrs.ensureKeys();
		attrList=attrs.attrList;
		n=attrList.length;
		for(i=0;i<n;i++){
			attr=attrList[i];
			attrDef=attr.def;
			if(attrDef.deadOut){
				attrs.removeAttr(attr);
				n--;i--;
			}
		}
		this.updateTypeAttr();
		editObj.updateHyperAttrs.call(this,force);
	};
}

//****************************************************************************
//:Face access:
//****************************************************************************
{
	let editHudObj=EditHudObj.prototype;
	//------------------------------------------------------------------------
	editHudGear.enterFaceEdit=function(faceTag,applyAttrs,notifyUsed=true){
		editHudObj.enterFaceEdit.call(this,faceTag,applyAttrs,notifyUsed);
		//GearSlots:
		{
			let slots,i,n,slotHud;
			slots=this.containerSlots.attrList;
			n=slots.length;
			if(n>0){
				for(i=0;i<n;i++){
					slotHud=slots[i];
					slotHud.enterFaceEdit(faceTag,applyAttrs,notifyUsed);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	editHudGear.exitFaceEdit=function(updateAttr=true){
		let face,liveObj;
		face=this.curFace;
		if(face && !face.faceAttrList.length && !face.anis.attrList.length){
			this.faces.removeAttr(face);
		}
		//GearSlots:
		{
			let slots,i,n,slotHud;
			slots=this.containerSlots.attrList;
			n=slots.length;
			if(n>0){
				for(i=0;i<n;i++){
					slotHud=slots[i];
					slotHud.exitFaceEdit(updateAttr);
				}
			}
		}
		this.curFace=null;
		liveObj=this.liveEdObj;
		if(liveObj && updateAttr){
			this.rebuildLiveObj();
		}
		this.emit("FaceOff");
	};

	//------------------------------------------------------------------------
	editHudGear.updateFaceState=function(faceTag,init=false){
		editHudObj.updateFaceState.call(this,faceTag,init);
		//GearSlots:
		{
			let slots,i,n,slotHud;
			slots=this.containerSlots.attrList;
			n=slots.length;
			if(n>0){
				for(i=0;i<n;i++){
					slotHud=slots[i];
					slotHud.updateFaceState(faceTag,init);
				}
			}
		}
	};
}


//****************************************************************************
//:Live Obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Create a JAXHudObj as child of [fatherHud], with [args] as createArgs
	//The hud will apply this-gear=obj's createArg and stateObj, GearDoc is no use here.
	editHudGear.genHudCSS=function(hyperState=false){
		let hudCSS,def,liveVal;
		let ppts,attr,theType;
		let stateObj,statePpts,traceFunc,exStatePpts;
		//ppts=ExportObj.export(this.properties,hyperState);
		//Basic properties:
		hudCSS=this.gearFunc(this.createArgs);
		theType=hudCSS.type;
		ppts=this.properties.attrList;
		for(attr of ppts){
			if("val" in attr){
				def=attr.def;
				if(liveVal=def.liveVal){
					if(liveVal instanceof(Function)){
						hudCSS[attr.name]=liveVal(attr);
					}else{
						hudCSS[attr.name]=liveVal;
					}
				}else{
					hudCSS[attr.name]=attr.val;
				}
				
			}
		}
		hudCSS.type=theType;
		hudCSS.jaxId=this.jaxId;
		hudCSS.$inEditor=true;
		//GearSlots:
		{
			let defSlots,slots,i,n,slot;
			defSlots=this.containerSlots.attrList;
			n=defSlots.length;
			if(n>0){
				hudCSS.subContainers=slots={};
				for(i=0;i<n;i++){
					slot=defSlots[i];
					slots[slot.editJaxId]=slot.genHudCSS(hyperState);
				}
			}
		}
		return hudCSS;
	};

	//------------------------------------------------------------------------
	editHudGear.bindLiveObj=function(liveObj,assignAttr,inTree){
		let gearSlots,name,hud,jaxId;
		if(this.liveEdObj){
			this.dropLiveObj(this.liveEdObj);
		}
		this.liveEdObj=liveObj;
		//Locate and bind gear containers:
		gearSlots=liveObj.subContainers;
		if(gearSlots){
			let slotHash,slotObj;
			slotHash=this.containerSlots.attrHash;
			for(name in gearSlots){
				hud=gearSlots[name];
				jaxId=hud.hash;
				slotObj=slotHash["Slot"+jaxId];
				if(slotObj){
					slotObj.bindLiveObj(hud);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	editHudGear.dropLiveObj=function(liveObj,inTree=false){
		let subHuds,i,n;
		if(liveObj && liveObj!==this.liveEdObj){
			return;
		}
		this.liveEdObj=null;
		//TODO: Locate and drop gear containers:
	};
}

//****************************************************************************
//:Import related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Add import 
	editHudGear.OnThisHudAdd=function(){
		let thisDoc,path,name;
		thisDoc=this.doc;//is safe?
		path=this.objDef.source;
		name=this.objDef.importName;
		thisDoc.addImportObj(name,path);
	};

	//------------------------------------------------------------------------
	//Remove import 
	editHudGear.OnThisHudRemove=function(){
		let thisDoc,path,name;
		thisDoc=this.doc;//is safe?
		path=this.objDef.source;
		name=this.objDef.importName;
		thisDoc.subImportObj(name,path);
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//HudGear can't have sub-items
	editHudGear.getNaviSubList=function(){
		let list=this.containerSlots.attrList;
		if(!list || !list.length){
			return null;
		}
		return [...list];
	};
	
	//------------------------------------------------------------------------
	editHudGear.getEditRootPpts=function(){
		let events;
		if(this.curFace){
			return [{obj:this.curFace,open:true}];
		}
		events=this.getAttr("events");
		if(events){
			return [
				{attr:this.prj.docApp.attrLocalize},
				{attr:this.prj.docApp.attrLanguage},
				{attr:this.locked},{obj:this.createArgs,open:true},{obj:this.properties,open:true},{obj:this.extraPpts,open:false},{attr:this.exposeNameVal},{attr:this.mockup},{attr:this.hasCodes},{obj:events,open:false},{obj:this.functions,open:false}
			];
		}
		return [
			{attr:this.prj.docApp.attrLocalize},
			{attr:this.prj.docApp.attrLanguage},
			{attr:this.locked},{obj:this.createArgs,open:true},{obj:this.properties,open:true},{obj:this.extraPpts,open:false},{attr:this.exposeNameVal},{attr:this.mockup},{attr:this.hasCodes},{obj:this.functions,open:false}
		];
	};
}

export {EditHudGear};
