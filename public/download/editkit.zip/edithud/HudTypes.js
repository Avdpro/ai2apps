import {VFACT} from "/@vfact";
import {EditHudObj,HudObjShellAttr} from "./EditHudObj.js";
let HudAttr_Obj,HudObjDef,defFunctionDef;
let HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,HudMemoDef;
let UIView,UIDock,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox;

const $ln=VFACT.lanCode;
//****************************************************************************
//:Raw HudObj:
//****************************************************************************
{
	let convertMargin=function(owner,attrVO,attrsVO){
		let mgs,isHyper,hyperTgt,valText;
		if("margin" in attrsVO){
			let margin;
			margin=attrsVO.margin;
			if(margin.valText){
				return;
			}
			delete attrsVO.margin;
		}
		mgs=["0","0","0","0"];
		function apply(code,idx){
			if(code in attrsVO){
				mgs[idx]=attrsVO[code];
				mgs[idx]=mgs[idx].valText||mgs[idx];
			}else{
				mgs[idx]="0";
			}
			if(mgs[idx].startsWith("#")){
				isHyper=1;
				mgs[idx]=mgs[idx].substring(1);
			}else if(mgs[idx].startsWith("${")){
				let pos;
				isHyper=1;
				pos=mgs[idx].lastIndexOf("}");
				if(pos>0){
					mgs[idx]=mgs[idx].substring(2,pos);
					hyperTgt=mgs[idx].substring(pos+1);
				}else{
					mgs[idx]="0";
				}
			}
		}
		isHyper=0;hyperTgt=null;
		apply("marginT",0);
		apply("marginR",1);
		apply("marginB",2);
		apply("marginL",3);
		if(isHyper){
			if(hyperTgt){
				valText=`\$\{[${mgs[0]},${mgs[1]},${mgs[2]},${mgs[3]}]\}${hyperTgt}`;
			}else{
				valText=`#[${mgs[0]},${mgs[1]},${mgs[2]},${mgs[3]}]`;
			}
		}else{
			valText=`[${mgs[0]},${mgs[1]},${mgs[2]},${mgs[3]}]`;
		}
		owner.setAttrByText("margin",valText,true);
	};
	let convertPadding=function(owner,attrVO,attrsVO){
		let pds,isHyper,hyperTgt,valText;
		if("padding" in attrsVO){
			return;
		}
		pds=["0","0","0","0"];
		function apply(code,idx){
			if(code in attrsVO){
				pds[idx]=attrsVO[code];
				pds[idx]=pds[idx].valText||pds[idx];
			}else{
				pds[idx]="0";
			}
			if(pds[idx].startsWith("#")){
				isHyper=1;
				pds[idx]=pds[idx].substring(1);
			}else if(pds[idx].startsWith("${")){
				let pos;
				isHyper=1;
				pos=pds[idx].lastIndexOf("}");
				if(pos>0){
					pds[idx]=pds[idx].substring(2,pos);
					hyperTgt=pds[idx].substring(pos+1);
				}else{
					pds[idx]="0";
				}
			}
		}
		isHyper=0;hyperTgt=null;
		apply("paddingT",0);
		apply("paddingR",1);
		apply("paddingB",2);
		apply("paddingL",3);
		if(isHyper){
			if(hyperTgt){
				valText=`\$\{[${pds[0]},${pds[1]},${pds[2]},${pds[3]}]\}${hyperTgt}`;
			}else{
				valText=`#[${pds[0]},${pds[1]},${pds[2]},${pds[3]}]`;
			}
		}else{
			valText=`[${pds[0]},${pds[1]},${pds[2]},${pds[3]}]`;
		}
		owner.setAttrByText("padding",valText,true);
	};
	HudAttr_Obj={
		attrs:{
			"id":{name:"id",showName:(($ln==="CN")?("ID 名称"):("ID Name")),type:"string",initVal:"",key:1,fixed:1,hideVal:""},
			"position":{
				name:"position",showName:(($ln==="CN")?("位置关系"):("Position")),type:"choice",
				vals:(($ln==="CN")?([["absolute","Absolute","相对上一级"],["relative","Relative","相对前一个控件"]]):/*EN*/([["absolute","Absolute","Absolute"],["relative","Relative","Relative"]])),
				initVal:"absolute",hideVal:"absolute",key:1,fixed:1,
				execSetTextAtom(EditAtom,doc,obj,attr,text){
					let xyAttr;
					doc.execEditAtom(EditAtom.setAttrByText(obj,attr,text));
					if(attr.val==="relative"){
						xyAttr=obj.getAttr("x");
						if(xyAttr){
							doc.execEditAtom(EditAtom.setAttrByText(obj,xyAttr,"0"));
						}
						xyAttr=obj.getAttr("y");
						if(xyAttr){
							doc.execEditAtom(EditAtom.setAttrByText(obj,xyAttr,"0"));
						}
					}
				}
			},
			"x":{name:"x",showName:(($ln==="CN")?("横(X)坐标"):("X-Pos")),type:"length",FVal:"FW",initVal:0,key:1,fixed:1},
			"y":{name:"y",showName:(($ln==="CN")?("纵(Y)坐标"):("Y-Pos")),type:"length",FVal:"FH",initVal:0,key:1,fixed:1},
			"w":{
				name:"w",showName:(($ln==="CN")?("宽"):("Width")),type:"length",FVal:"FW",initVal:100,key:1,fixed:1,hideVal:0
			},
			"h":{
				name:"h",showName:(($ln==="CN")?("高"):("Height")),type:"length",FVal:"FH",initVal:100,key:1,fixed:1,hideVal:0
			},
			"anchorH":{name:"anchorH",showName:(($ln==="CN")?("横向(X)锚点"):("Anchor X")),exportName:"anchorX",type:"choice",vals:(($ln==="CN")?([[0,"Left","左对齐"],[1,"Center","居中对齐"],[2,"Right","右对齐"]]):/*EN*/([[0,"Left","Left"],[1,"Center","Center"],[2,"Right","Right"]])),initVal:0,key:1,fixed:1,hideVal:0},
			"anchorV":{name:"anchorV",showName:(($ln==="CN")?("纵向(Y)锚点"):("Anchor Y")),exportName:"anchorY",type:"choice",vals:(($ln==="CN")?([[0,"Top","上对齐"],[1,"Center","居中"],[2,"Bottom","下对齐"]]):/*EN*/([[0,"Top","Top"],[1,"Center","Center"],[2,"Bottom","Bottom"]])),initVal:0,key:1,fixed:1,hideVal:0},
			"autoLayout":{name:"autoLayout",showName:"Auto Layout",type:"bool",initVal:false,key:1,fixed:1,hideVal:false,liveVal:true},
			"display":{
				name:"display",showName:(($ln==="CN")?("显示"):("Display")),type:"choice",key:1,fixed:1,vals:(($ln==="CN")?([[0,"Off","不可见"],[1,"On","可见"]]):/*EN*/([[0,"Off","Off"],[1,"On","On"]])),initVal:1,hideVal:1,
				liveVal(attr){
					let owner=attr.owner;
					let display,attach;
					display=attr.val;
					attach=owner.getAttr("attach");
					attach=attach?attach.val:true;
					return attach&&display;
				}
			},
			"contentLayout":{
				name:"contentLayout",showName:(($ln==="CN")?("内部布局"):("Content Layout")),type:"choice",
				vals:(($ln==="CN")?([["","Block","标准布局"],["flex-x","Flex X","横向轻布局"],["flex-y","Flex Y","纵向轻布局"],["flex-xr","Flex XR","横向反向轻布局"],["flex-yr","Flex YR","纵向反向轻布局"]]):/*EN*/([["","Block","Block"],["flex-x","Flex X","Flex X"],["flex-y","Flex Y","Flex Y"],["flex-xr","Flex XR","Flex XR"],["flex-yr","Flex YR","Flex YR"]])),
				initVal:"",hideVal:"",key:0,fixed:1
			},
			"subAlign":{
				name:"subAlign",showName:(($ln==="CN")?("子级控件对齐"):("Content Align")),type:"choice",
				vals:(($ln==="CN")?([[0,"Start","起始端对齐"],[1,"Center","居中"],[2,"End","末尾对齐"],[3,"Space Around","空白环绕"],[4,"Space Evenly","空白均分"]]):/*EN*/([[0,"Start","Start"],[1,"Center","Center"],[2,"End","End"],[3,"Space Around","Space Around"],[4,"Space Evenly","Space Evenly"]])),
				initVal:0,hideVal:0,key:0,fixed:1
			},
			"itemsAlign":{
				name:"itemsAlign",showName:(($ln==="CN")?("子控件间对齐"):("In-Cell Align")),type:"choice",
				vals:(($ln==="CN")?([[0,"Start","起始对齐"],[1,"Center","居中"],[2,"End","末尾对齐"]]):/*EN*/([[0,"Start","Start"],[1,"Center","Center"],[2,"End","End"]])),initVal:0,hideVal:0,key:0,fixed:1
			},
			"itemsWrap":{
				name:"itemsWrap",showName:(($ln==="CN")?("轻布局换行"):("Children flex wrap")),type:"choice",
				vals:(($ln==="CN")?([[0,"No Wrap","不换行"],[1,"Wrap","换行"],[2,"Wrap reverse","反向换行"]]):/*EN*/([[0,"No Wrap","No Wrap"],[1,"Wrap","Wrap"],[2,"Wrap reverse","Wrap reverse"]])),initVal:0,hideVal:0,key:0,fixed:1
			},
			"innerLayout":{
				name:"innerLayout",showName:"Inner Layout",type:"converter",
				convert(owner,attrVO,attrsVO){
					let valText;
					if(typeof(attrVO)==="string"){
						valText=attrVO;
					}else{
						valText=attrVO.valText;
					}
					owner.setAttrByText("contentLayout",valText,true);
				},gearExpose:false
			},
			"clip":{
				name:"clip",showName:(($ln==="CN")?("剪裁/滚动"):("Clip/Scroll")),type:"choice",exportName:"overflow",key:1,fixed:1,
				vals:(($ln==="CN")?([[0,"Off","不剪裁溢出"],[1,"On","剪裁溢出"],["auto","Auto Scroll","自动滚动"],["scroll-x","Scroll X","横向滚动"],["auto-y","Auto Scroll Y","纵向自动滚动"],["auto-x","Auto Scroll X","横向自动滚动"],["scroll-y","Scroll Y","纵向滚动"],["scroll-xy","Scroll Both","横纵均滚动"]]):/*EN*/([[0,"Off","Show"],[1,"On","Hide"],["auto","Auto Scroll"],["scroll-x","Scroll X"],["auto-y","Auto Scroll Y"],["auto-x","Auto Scroll X"],["scroll-y","Scroll Y"],["scroll-xy","Scroll Both"]])),
				initVal:0,hideVal:0,
				exportValText:function(attr,docType){
					let val=attr.val;
					switch(val){
						case 0:
						case 1:
							return attr.valText;
						case "auto":
							return '#"auto"';
						case "scroll-x":
							return '#"scroll hidden"';
						case "scroll-y":
							return '#"hidden scroll"';
						case "scroll-xy":
							return '#"scroll"';
					}
					return attr.valText;
				}
			},
			"uiEvent":{
				name:"uiEvent",showName:(($ln==="CN")?("指针事件"):("Pointer Event")),type:"choice",
				vals:(($ln==="CN")?([[-1,"Tree Off","树关闭"],[0,"Off","关闭"],[1,"On","开启"]]):/*EN*/([[-1,"Tree Off","Tree Off"],[0,"Off","Off"],[1,"On","On"]])),
				initVal:1,hideVal:1,key:1,fixed:1
			},
			"alpha":{
				name:"alpha",showName:(($ln==="CN")?("不透明度"):("Opacity")),type:"number",initVal:1,range:[0,1],key:1,fixed:1,hideVal:1,
				editType:"range",editMode:"range",step:0.05,minVal:0,maxVal:1,valFixDigit:2
			},
			"rotate":{
				name:"rotate",showName:(($ln==="CN")?("旋转"):("Rotate")),type:"number",initVal:0,key:1,fixed:1,hideVal:0
			},
			"scale":{name:"scale",showName:(($ln==="CN")?("放缩"):("Scale")),type:"auto",initVal:undefined,key:1,fixed:1,hideVal:undefined},
			"filter":{name:"filter",showName:(($ln==="CN")?("过滤器"):("Filter")),type:"string",initVal:"",key:1,fixed:1,hideVal:""},
			"aspect":{name:"aspect",showName:(($ln==="CN")?("横纵比例"):("Aspect")),type:"string",initVal:"",key:0,fixed:1,hideVal:""},
			"cursor":{
				name:"cursor",showName:(($ln==="CN")?("光标"):("Cursor")),type:"string",initVal:"",key:1,fixed:1,hideVal:""//TODO: Make it choice
			},
			"zIndex":{
				name:"zIndex",showName:(($ln==="CN")?("远近(Z)值"):("Z-Index")),type:"int",initVal:0,key:1,fixed:1,hideVal:0
			},
			"flex":{
				name:"flex",showName:(($ln==="CN")?("轻布局填充"):("Flex to Fill")),type:"bool",initVal:false,key:0,fixed:1,hideVal:false
			},
			"margin":{
				name:"margin",showName:(($ln==="CN")?("边距"):("Margin")),type:"auto",initval:undefined,key:1,fixed:1,hideVal:undefined,editMode:"edges",
				checkHide(attr){
					let attrVal;
					attrVal=attr.val;
					if(!attr.val){
						return true;
					}
					if(Array.isArray(attrVal) && attrVal[0]===0 && attrVal[1]===0 && attrVal[2]===0 && attrVal[3]===0){
						return true;
					}
					return false;
				}
			},
			"traceSize":{
				name:"traceSize",showName:(($ln==="CN")?("追踪尺寸变化"):("Trace Size Change")),type:"bool",initVal:true,key:0,fixed:1,hideVal:false,
			},
			"marginL":{
				name:"marginL",type:"converter",convert:convertMargin,gearExpose:false
			},
			"marginR":{
				name:"marginR",type:"converter",convert:convertMargin,gearExpose:false
			},
			"marginT":{
				name:"marginT",type:"converter",convert:convertMargin,gearExpose:false
			},
			"marginB":{
				name:"marginB",type:"converter",convert:convertMargin,gearExpose:false
			},
			"padding":{
				name:"padding",showName:(($ln==="CN")?("留白"):("Padding")),type:"auto",initval:undefined,key:1,fixed:1,hideVal:undefined,editMode:"edges",
			},
			"paddingL":{
				name:"paddingL",type:"converter",convert:convertPadding,gearExpose:false
			},
			"paddingR":{
				name:"paddingR",type:"converter",convert:convertPadding,gearExpose:false
			},
			"paddingT":{
				name:"paddingT",type:"converter",convert:convertPadding,gearExpose:false
			},
			"paddingB":{
				name:"paddingB",type:"converter",convert:convertPadding,gearExpose:false
			},
			"minW":{
				name:"minW",showName:(($ln==="CN")?("最小宽度"):("Min width")),type:"length",FVal:"FW",initVal:undefined,key:1,fixed:1,hideVal:undefined,
			},
			"minH":{
				name:"minH",showName:(($ln==="CN")?("最小高度"):("Min height")),type:"length",FVal:"FH",initVal:undefined,key:1,fixed:1,hideVal:undefined,
			},
			"maxW":{
				name:"maxW",showName:(($ln==="CN")?("最大宽度"):("Max width")),type:"length",FVal:"FW",initVal:undefined,key:1,fixed:1,hideVal:undefined,
			},
			"maxH":{
				name:"maxH",showName:(($ln==="CN")?("最大高度"):("Max height")),type:"length",FVal:"FH",initVal:undefined,key:1,fixed:1,hideVal:undefined,
			},
			"face":{name:"face",showName:(($ln==="CN")?("容貌"):("Face")),type:"string",initVal:"",key:1,fixed:1,edit:false,export:false},
			"styleClass":{name:"styleClass",showName:"Style Class",type:"string",initVal:"",key:1,fixed:1,edit:true,export:true},
			"attach":{
				name:"attach",showName:(($ln==="CN")?("创建组件"):/*EN*/("Create component")),exportName:"attached",type:"bool",initVal:true,key:0,fixed:1,hideVal:true,
				liveValName:"display",
				liveVal(attr,owner){
					let display,attach;
					if(attr){
						owner=attr.owner;
						display=attr.val;
						attach=owner.getAttrVal("display");
					}else{//Must have owner argument:
						attach=true;
						display=owner.getAttrVal("display");
					}
					return attach&&display;
				},gearExpose:false
			},
			"exposeToAI":{
				name:"exposeToAI",showName:(($ln==="CN")?("向AI输出"):/*EN*/("Expose to AI")),type:"bool",initVal:true,key:0,fixed:1,rawEdit:false,
			},
			"descAI":{
				name:"descAI",showName:(($ln==="CN")?("面向AI的描述说明"):/*EN*/("Description for AI")),type:"string",initVal:"",key:0,fixed:1,localizable:true
			}
		},
		listHint:[
			"id","attach","display","position","x","y","w","h",
			{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","contentLayout","subAlign","itemsAlign","itemsWrap","margin","padding","flex","zIndex","traceSize","aspect"],open:0},
			{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
			"styleClass","clip","alpha","rotate","scale","filter","uiEvent","cursor",
			{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
		]
	};

	defFunctionDef={
		name:"functions",showName:(($ln==="CN")?("事件响应"):("Events")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
		def:{
			icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
			attrs:{
				"OnCreate":{name:"OnCreate",type:"fixedFunc",arguments:[],fixed:1,key:0},
				"OnFree":{name:"OnFree",type:"fixedFunc",arguments:[],fixed:1,key:0},
				"OnClick":{name:"OnClick",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
				"OnTreeClick":{name:"OnTreeClick",type:"fixedFunc",arguments:["isIn","event"],fixed:1,key:0},
				"OnMouseInOut":{name:"OnMouseInOut",type:"fixedFunc",arguments:["isIn","event"],fixed:1,key:0},
				"OnSize":{name:"OnSize",type:"fixedFunc",arguments:[],fixed:1,key:0},
			},
			listHint:["OnClick","OnMouseInOut","OnCreate","OnFree","OnTreeClick","OnSize"],
		}
	};

	HudObjDef={
		name:"hud",showName:(($ln==="CN")?("空元素"):("Dummy")),icon:"hudhud.svg",
		gearDocDef:"GearHud",//The GearDoc's def name
		info:(($ln==="CN")?("虚拟 UI 组件。可用于占位或作为容器。"):/*EN*/("Dummy UI component. Can be used to hold space or as a container.")),
		//For add sub-hud
		allowExtraAttr:1,attrType:"hud",naviMultiSel:1,
		//Hud properties:
		attrs:{
			"properties":{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs
					},
					listHint:[...HudAttr_Obj.listHint]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"exposeContainer":{name:"exposeContainer",type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false},
			"functions":defFunctionDef,
		},
		majorEditAttr:"id",
		withFillType:true,
	};
	
	//EditHudObj.regHudDef("hud",HudObjDef);
	//EditHudObj.regCatalogHudDef("Basic","hud",HudObjDef);
	//EditHudObj.regCatalogHudDef("Containers","hud",HudObjDef);
}
//****************************************************************************
//:Basic Group:
//****************************************************************************
{
	//----------------------------------------------------------------------------
	//:HudBox:
	HudBoxDef={
		name:"box",showName:(($ln==="CN")?("矩形"):("Box")),icon:"hudbox.svg",
		gearDocDef:"GearBox",//The GearDoc's def name
		info:(($ln==="CN")?("矩形盒子对象。盒子具有填充颜色、边框、阴影和其他外观属性。"):/*EN*/("Rectangle box object. The box has properties for fill color, border, shadow, and other appearance attributes.")),
		previewImg:"/-editkit/assets/Box.png",
		//For add sub-hud
		allowExtraAttr:1,attrType:"hud",naviMultiSel:1,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"box",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						"background":{
							name:"background",showName:(($ln==="CN")?("背景填充"):("Color")),type:"colorRGBA",initVal:[255,255,255,1],key:1,fixed:1,colorCfg:true
						},
						"color":{
							name:"color",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText,attrGnt;
								if("background" in attrsVO){
									return;
								}
								attrGnt=attrsVO["gradient"];
								if(attrGnt){
									attrGnt=attrGnt.valText||attrGnt;
									try{
										attrGnt=JSON.parse(attrGnt);
										if(attrGnt){
											return;
										}
									}catch(err){
									}
								}
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("background",valText,true);
							}
						},
						"gradient":{
							name:"gradient",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								try{
									valText=JSON.parse(valText);
								}catch(err){
								}
								if(valText){
									owner.setAttrByText("background",valText,true);
								}
							}
						},
						"border":{
							name:"border",showName:(($ln==="CN")?("尺寸"):("Size(s)")),type:"auto",initVal:1,hideVal:0,key:1,fixed:1,editMode:"edges",
						},
						"borders":{
							name:"borders",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("border",valText,true);
								attrsVO["border"]=valText;
							}
						},
						"borderStyle":{
							name:"borderStyle",showName:(($ln==="CN")?("样式"):("Style")),type:"choice",key:1,fixed:1,
							vals:(($ln==="CN")?([[0,"None","无"],[1,"Solid","实线"],[2,"Dashed","断续线"],[3,"Dotted","点画线"]]):/*EN*/([[0,"None","None"],[1,"Solid","Solid"],[2,"Dashed","Dashed"],[3,"Dotted","Dotted"]])),initVal:1,hideVal:1,
						},
						"borderColor":{
							name:"borderColor",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGBA",initVal:[0,0,0,1],hideVal:[0,0,0,1],key:1,fixed:1,colorCfg:true
						},
						"borderColors":{
							name:"borderColors",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("borderColor",valText,true);
								attrsVO["borderColor"]=valText;
							}
						},
						"corner":{
							name:"corner",showName:(($ln==="CN")?("边角尺寸"):("Corner size(s)")),type:"auto",initVal:0,hideVal:0,key:1,fixed:1,editMode:"corners",
						},
						"coner":{
							name:"coner",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(attrsVO.coners){
									return;
								}
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
						"coners":{
							name:"coners",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
						shadow:{name:"shadow",showName:(($ln==="CN")?("显示"):("Show")),type:"bool",initVal:false,hideVal:false,key:1,fixed:1},
						shadowX:{name:"shadowX",showName:(($ln==="CN")?("水平偏移量 x"):("Offset x")),type:"int",initVal:2,hideVal:2,key:1,fixed:1},
						shadowY:{name:"shadowY",showName:(($ln==="CN")?("垂直偏移量 y"):("Offset y")),type:"int",initVal:2,hideVal:2,key:1,fixed:1},
						shadowBlur:{name:"shadowBlur",showName:(($ln==="CN")?("模糊"):("Blur")),type:"int",initVal:3,hideVal:3,key:1,fixed:1},
						shadowSpread:{name:"shadowSpread",showName:(($ln==="CN")?("扩散"):("Spread")),type:"int",initVal:0,hideVal:0,key:1,fixed:1},
						shadowColor:{name:"shadowColor",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGBA",initVal:[0,0,0,0.5],hideVal:[0,0,0,0.5],key:1,fixed:1,colorCfg:true},
						maskImage:{name:"maskImage",showName:(($ln==="CN")?("遮罩图像"):("Mask Image")),type:"file",initVal:"",key:0,fixed:1,hideVal:"",isURL:true},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"background",
						{name:"border",showName:(($ln==="CN")?("边框和角落"):("Border and Coners")),attrs:["border","borderStyle","borderColor","corner"],open:1},
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","contentLayout","subAlign","itemsAlign","itemsWrap","margin","padding","flex","zIndex","traceSize","aspect"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale",
						{name:"shadow",showName:(($ln==="CN")?("阴影"):("Shadow")),attrs:["shadow","shadowColor","shadowX","shadowY","shadowBlur","shadowSpread"]},
						{name:"advanced",showName:(($ln==="CN")?("高级"):("Advanced")),attrs:["maskImage","filter"]},
						"uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"functions":defFunctionDef,
		},
		majorEditAttr:"id",
		withFillType:true,
	};
	//EditHudObj.regHudDef("box",HudBoxDef);
	//EditHudObj.regCatalogHudDef("Basic","box",HudBoxDef);
	//EditHudObj.regCatalogHudDef("Containers","box",HudBoxDef);
	
	//------------------------------------------------------------------------
	//:HudText:
	HudTextDef={
		name:"text",showName:(($ln==="CN")?("文本"):("Text")),icon:"hudtxt.svg",
		gearDocDef:"GearText",//The GearDoc's def name
		info:(($ln==="CN")?("文本对象。您可以双击文本组件来编辑其内容。除了文字内容，您还可以调整文本对象的字体、颜色、对齐方式、阴影等更多属性。"):/*EN*/("Text object. You can double-click on the text component to edit its content. In addition to text content, you can also adjust the font, color, alignment, shadow, and other properties of the text object.")),
		initW:100,initH:20,
		//For add sub-hud
		allowExtraAttr:0,attrType:"hud",naviMultiSel:1,naviHasSub:false,
		majorEditAttr:"text",
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"text",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):("Height")),type:"length",FVal:"FH",initVal:"",initValText:"",key:1,fixed:1,
						},
						color:{name:"color",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGB",initVal:[0,0,0],key:1,fixed:1},
						text:{name:"text",showName:(($ln==="CN")?("文本"):("Text")),type:"string",initVal:"text",key:1,fixed:1,hotOnlineEdit:1,localizable:true},
						font:{name:"font",showName:(($ln==="CN")?("字体"):("Font")),type:"string",initVal:"",key:1,fixed:1,hideVal:"",editType:"fontChoice"},
						fontSize:{name:"fontSize",showName:(($ln==="CN")?("尺寸"):("Size")),type:"int",initVal:16,key:1,fixed:1,hideVal:16,editType:"fontSize"},
						bold:{
							name:"bold",showName:(($ln==="CN")?("粗体"):("Bold")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false,
							exportName:"fontWeight",
							exportValText:function(attr,docType){
								let valText=attr.valText;
								if(valText.startsWith("#")){
									let pos=valText.indexOf("#>");
									if(pos>0){
										return `#(${attr.valText.substring(1,pos)})?"bold":"normal"`;
									}
									return `#(${attr.valText.substring(1)})?"bold":"normal"`;
								}else if(attr.valText.startsWith("${")){
									let code="";
									let pos=valText.lastIndexOf("}");
									{
										code+=`\$\{(${valText.substring(2,pos)})?"bold":"normal"}`;
									}
									if(valText[pos+1]===","){
										code+=valText.substring(pos+1);
									}
									return code;
								}else if(attr.val){
									return '#"bold"';
								}
								return '#"normal"';
							},
							liveVal:function(attr){
								if(attr.val){
									return 'bold';
								}
								return 'normal';
							}
						},
						italic:{
							name:"italic",showName:(($ln==="CN")?("斜体"):("Italic")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false,
							exportName:"fontStyle",
							exportValText:function(attr,docType){
								if(attr.val){
									return '#"italic"';
								}
								return '#"normal"';
							},
							liveVal:function(attr,docType){
								if(attr.val){
									return 'italic';
								}
								return 'normal';
							}
						},
						underline:{
							name:"underline",showName:(($ln==="CN")?("下划线"):("Underline")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false,
							exportName:"textDecoration",
							exportValText:function(attr,docType){
								if(attr.val){
									return '#"underline"';
								}else{
									return '#""';
								}
							},
							liveVal:function(attr,docType){
								if(attr.val){
									return 'underline';
								}
								return '';
							}
						},
						alignH:{name:"alignH",showName:(($ln==="CN")?("水平对齐"):("Horizontal align")),type:"choice",vals:(($ln==="CN")?([[0,"Left","左对齐"],[1,"Center","居中"],[2,"Right","右对齐"]]):/*EN*/([[0,"Left","Left"],[1,"Center","Center"],[2,"Right","Right"]])),initVal:0,key:1,fixed:1,hideVal:0},
						alignV:{name:"alignV",showName:(($ln==="CN")?("垂直对齐"):("Vertical align")),type:"choice",vals:(($ln==="CN")?([[0,"Top","上对齐"],[1,"Center","居中"],[2,"Bottom","下对齐"]]):/*EN*/([[0,"Top","Top"],[1,"Center","Center"],[2,"Bottom","Bottom"]])),initVal:0,key:1,fixed:1,hideVal:0},
						autoSizeW:{
							name:"autoSizeW",showName:(($ln==="CN")?("宽度"):("Width")),type:"bool",initVal:false,key:0,fixed:0,hideVal:false,
							exportName:"autoW",deprecated:true,
						},
						autoSizeH:{
							name:"autoSizeH",showName:(($ln==="CN")?("高度"):("Height")),type:"bool",initVal:false,key:0,fixed:0,hideVal:false,
							exportName:"autoH",deprecated:true,
						},
						wrap:{name:"wrap",showName:(($ln==="CN")?("自动换行"):("Wrap")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false},
						ellipsis:{name:"ellipsis",showName:(($ln==="CN")?("省略号"):("Ellipsis")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false},
						lineClamp:{name:"lineClamp",showName:(($ln==="CN")?("多行省略号"):("Line Clamp")),type:"int",initVal:0,key:1,fixed:1,hideVal:0},
						select:{name:"select",showName:(($ln==="CN")?("文本可以选择"):("Text can be selected")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false,exportName:"selectable"},
						shadow:{name:"shadow",showName:(($ln==="CN")?("影子"):("Shadow")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false},
						shadowX:{name:"shadowX",showName:(($ln==="CN")?("阴影偏移 X"):("Shadow Offset X")),type:"int",initVal:0,key:1,fixed:1,hideVal:0},
						shadowY:{name:"shadowY",showName:(($ln==="CN")?("阴影偏移量 Y"):("Shadow Offset Y")),type:"int",initVal:2,key:1,fixed:1,hideVal:2},
						shadowBlur:{name:"shadowBlur",showName:(($ln==="CN")?("阴影模糊"):("Shadow Blur")),type:"int",initVal:3,key:1,fixed:1,hideVal:3},
						shadowColor:{name:"shadowColor",showName:(($ln==="CN")?("阴影颜色"):("Shadow Color")),type:"colorRGBA",initVal:[0,0,0,1],key:1,fixed:1,hideVal:[0,0,0,1]},
						shadowEx:{name:"shadowEx",showName:(($ln==="CN")?("阴影扩展属性"):("Shadow Extra")),type:"string",initVal:"",key:1,fixed:1,hideVal:""},
						maxTextW:{name:"maxTextW",showName:"Max Width",type:"int",initVal:0,key:1,fixed:1,hideVal:0},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"text","color",
						{name:"font",showName:(($ln==="CN")?("字体"):("Font")),attrs:["font","fontSize","bold","italic","underline"],open:0},
						{name:"textLayout",showName:(($ln==="CN")?("文本布局"):("Text layout")),attrs:["alignH","alignV","wrap","ellipsis","lineClamp","maxTextW"],open:0},
						//{name:"autoSize",showName:(($ln==="CN")?("自动调整大小"):("Auto size")),attrs:["autoSizeW","autoSizeH"],open:0},
						"select",
						{name:"shadow",showName:(($ln==="CN")?("文本阴影"):("Text Shadow")),attrs:["shadow","shadowX","shadowY","shadowBlur","shadowColor","shadowEx"],open:0},
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"alpha","rotate","scale",
						"uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):("Is Containter")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};
	//EditHudObj.regHudDef("text",HudTextDef);
	//EditHudObj.regCatalogHudDef("Basic","text",HudTextDef);
	//EditHudObj.regCatalogHudDef("Texts","text",HudTextDef);
	
	//------------------------------------------------------------------------
	//:HudButton:
	HudButtonDef={
		name:"button",showName:(($ln==="CN")?("原始按钮"):("Raw Button")),icon:"hudbtn.svg",
		gearDocDef:"GearButton",//The GearDoc's def name
		info:(($ln==="CN")?(`按钮对象。您可以为不同的按钮状态分配“up”，“down”，“over”，“gray”面来表示不同的按钮外观。`):(`Button Object. You can assign "up", "down", "over", "gray" faces to indicate different button state apperences.`)),
		//For add sub-hud
		allowExtraAttr:1,attrType:"hud",naviMultiSel:1,
		initW:100,initH:32,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"button",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						display:{
							name:"display",type:"choice",key:1,fixed:1,
							vals:(($ln==="CN")?([[0,"Off","不可见"],[1,"On","可见"]]):/*EN*/([[0,"Off","Off"],[1,"On","On"]])),initVal:1,hideVal:1,
							liveVal(attr){
								let owner=attr.owner;
								let display,attach;
								display=attr.val;
								attach=owner.getAttr("attach");
								attach=attach?attach.val:true;
								return attach&&display;
							}
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):("Height")),type:"length",FVal:"FH",initVal:32,key:1,fixed:1,hideVal:0
						},
						enable:{name:"enable",showName:(($ln==="CN")?("启用"):("Enable")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true},
						drag:{name:"drag",showName:(($ln==="CN")?("拖动触发"):("Drag trigger")),type:"choice",vals:(($ln==="CN")?([[0,"NA","无拖拽"],[1,"Move out","光标移出时"],[2,"Pointer down","点击时"]]):/*EN*/([[0,"NA","NA"],[1,"Move out","Move out"],[2,"Pointer down","Pointer down"]])),initVal:0,key:1,fixed:1,hideVal:0},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"enable",
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","subAlign","itemsAlign","itemsWrap","traceSize","aspect"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"drag",
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"functions":{
				name:"functions",showName:(($ln==="CN")?("事件响应"):("Events")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
					attrs:{
						...defFunctionDef.def.attrs,
						"OnButtonDown":{name:"OnButtonDown",type:"fixedFunc",arguments:["code","event"],fixed:1,key:0},
						"OnButtonUp":{name:"OnButtonUp",type:"fixedFunc",arguments:["code","event"],fixed:1,key:0},
						"OnDragStart":{name:"OnDragStart",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnDrag":{name:"OnDrag",type:"fixedFunc",arguments:["event","dx","dy"],fixed:1,key:0},
						"OnDragEnd":{name:"OnDragEnd",type:"fixedFunc",arguments:["event","dx","dy"],fixed:1,key:0},
						"OnMouseUpOut":{name:"OnMouseUpOut",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
					},
					listHint:["OnClick","OnButtonDown","OnButtonUp","OnMouseUpOut","OnDragStart","OnDrag","OnDragEnd","OnMouseInOut","OnCreate","OnFree","OnTreeClick","OnSize"],
				}
			},
		}
	};
	
	//------------------------------------------------------------------------
	//:HudImage:
	HudImageDef={
		name:"image",showName:(($ln==="CN")?("图片"):("Image")),icon:"hudimg.svg",
		gearDocDef:"GearImage",//The GearDoc's def name
		info:(($ln==="CN")?(`图像对象。图像对象可以将 "SVG"，"PNG"，"JPEG" 分配给它的 "image" 属性作为内容。`):(`Image object. Image object can assign a "SVG", "PNG", "JPEG" to it's "image" property as content.`)),
		//For add sub-hud
		allowExtraAttr:1,attrType:"hud",naviMultiSel:1,
		majorEditAttr:"image",
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"image",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						image:{name:"image",showName:(($ln==="CN")?("图片源"):("Image")),type:"file",initVal:"",key:1,fixed:1,hideVal:"",isURL:true},
						autoSize:{name:"autoSize",showName:(($ln==="CN")?("自动大小"):("Auto size")),type:"bool",initVal:false,key:1,fixed:1,hideVal:false},
						fitSize:{
							name:"fitSize",showName:(($ln==="CN")?("尺寸适应"):("Image Size")),type:"choice",initVal:true,key:1,fixed:1,hideVal:false,
							vals:(($ln==="CN")?([[false,"auto","自动"],[true,"Fit","适应"],["contain","Contain","包含"],["cover","Cover","覆盖"]]):/*EN*/([[false,"auto","auto"],[true,"Fit","Fit"],["contain","Contain","Contain"],["cover","Cover","Cover"]])),
						},
						repeat:{name:"repeat",showName:(($ln==="CN")?("重复"):("Repeat")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true},
						alignX:{
							name:"alignX",showName:(($ln==="CN")?("水平对齐-X"):("Align-X")),type:"choice",initVal:0,key:1,fixed:1,hideVal:0,
							vals:(($ln==="CN")?([[0,"Left","左对齐"],[1,"Center","居中"],[2,"Right","右对齐"]]):/*EN*/([[0,"Left","Left"],[1,"Center","Center"],[2,"Right","Right"]])),
						},
						alignY:{
							name:"alignY",showName:(($ln==="CN")?("垂直对齐-Y"):("Align-Y")),type:"choice",initVal:0,key:1,fixed:1,hideVal:0,
							vals:(($ln==="CN")?([[0,"Top","上对齐"],[1,"Center","居中"],[2,"Bottom","下对齐"]]):/*EN*/([[0,"Top","Top"],[1,"Center","Center"],[2,"Bottom","Bottom"]])),
						},
						image3x3:{name:"image3x3",showName:(($ln==="CN")?("3x3 切片"):("3x3 Slice")),type:"auto",initVal:undefined,key:0,fixed:1,hideVal:false},
						image3x3Width:{name:"image3x3Width",showName:(($ln==="CN")?("3x3 尺寸"):("3x3 width")),type:"auto",initVal:undefined,key:0,fixed:1,hideVal:false},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"image","autoSize","fitSize","repeat","alignX","alignY",
						{name:"3x3",showName:(($ln==="CN")?("切片 3x3"):("Border 3x3")),attrs:["image3x3","image3x3Width"],open:0},
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","subAlign","itemsAlign","itemsWrap","traceSize","aspect"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"functions":{
				name:"functions",showName:(($ln==="CN")?("事件响应"):("Events")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
					attrs:{
						...defFunctionDef.def.attrs,
						"OnLoad":{name:"OnLoad",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnError":{name:"OnError",type:"fixedFunc",arguments:[],fixed:1,key:0},
					},
					listHint:["OnLoad","OnClick","OnError","OnMouseInOut","OnCreate","OnFree","OnTreeClick","OnSize"],
				}
			},
		}
	};

	//------------------------------------------------------------------------
	//:HudEdit:
	HudEditDef={
		name:"edit",showName:(($ln==="CN")?("编辑框"):("Edit Line")),icon:"hudedit.svg",
		gearDocDef:"GearEdit",//The GearDoc's def name
		info:(($ln==="CN")?("输入/编辑文本对象，用户可以使用此对象输入文本。外观，如背景颜色、文本颜色、字体、字体大小等，可以通过属性进行调整。"):("Input/edit text object, user can input text with this object. Appearence like background-color, text-color, font, font-size,can be adjusted with properties.")),
		//For add sub-hud
		allowExtraAttr:0,attrType:"hud",naviMultiSel:1,naviHasSub:false,
		initW:100,initH:20,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"edit",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						inputType:{
							name:"inputType",showName:(($ln==="CN")?("类型"):("Type")),type:"choice",key:1,fixed:1,
							vals:(($ln==="CN")?([["text","Text","文本"],["password","Password","密码"],["number","Number","数字"],["date","Date","日期"],["time","Time","时间"],["month","Month","月份"],["tel","Telephone","电话号码"]]):/*EN*/([["text","Text","Text"],["password","Password","Password"],["number","Number","Number"],["date","Date","Date"],["time","Time","Time"],["month","Month","Month"],["tel","Telephone","Telephone"]])),
							initVal:"text",hideVal:"text"
						},
						pattern:{
							name:"pattern",showName:(($ln==="CN")?("模式"):("Pattern")),type:"string",key:0,fixed:1,initVal:"",hideVal:""
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):("Height")),type:"length",FVal:"FW",initVal:20,key:1,fixed:1,hideVal:0,
						},
						text:{name:"text",showName:(($ln==="CN")?("文本"):("Text")),type:"string",initVal:"",key:1,fixed:1,hideVal:"",localizable:true},
						placeHolder:{name:"placeHolder",showName:(($ln==="CN")?("占位符"):("Placeholder")),type:"string",initVal:"",key:1,fixed:1,hideVal:"",localizable:true},
						color:{name:"color",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGB",initVal:[0,0,0],key:1,fixed:1},
						bgColor:{
							name:"bgColor",showName:(($ln==="CN")?("背景颜色"):("Background Color")),type:"colorRGBA",initVal:[255,255,255,1],key:1,fixed:1,hideVal:[255,255,255,1],
							exportName:"background",
						},
						font:{name:"font",showName:(($ln==="CN")?("字体"):("Font")),type:"string",initVal:"",key:1,fixed:1,hideVal:""},
						fontSize:{name:"fontSize",showName:(($ln==="CN")?("尺寸"):("Size")),type:"int",initVal:16,key:1,fixed:1,hideVal:16},
						outline:{name:"outline",showName:(($ln==="CN")?("外框"):("Outline")),type:"int",initVal:1,key:1,fixed:1,hideVal:1},
						border:{
							name:"border",showName:(($ln==="CN")?("尺寸"):("Size")),type:"auto",initVal:1,hideVal:0,key:1,fixed:1,editMode:"edges",
						},
						borderStyle:{
							name:"borderStyle",showName:(($ln==="CN")?("样式"):("Style")),type:"choice",key:1,fixed:1,
							vals:(($ln==="CN")?([[0,"None","无"],[1,"Solid","实线"],[2,"Dashed","断续线"],[3,"Dotted","点画线"]]):/*EN*/([[0,"None","None"],[1,"Solid","Solid"],[2,"Dashed","Dashed"],[3,"Dotted","Dotted"]])),
							initVal:1,hideVal:1,
						},
						borderColor:{
							name:"borderColor",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGBA",initVal:[0,0,0,1],hideVal:[0,0,0,1],key:1,fixed:1,
						},
						corner:{
							name:"corner",showName:(($ln==="CN")?("边角尺寸"):("Corner size(s)")),type:"auto",initVal:0,hideVal:0,key:1,fixed:1,editMode:"corners",
						},
						selectOnFocus:{
							name:"selectOnFocus",showName:(($ln==="CN")?("自动选中"):("Auto select")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true,
							exportName:"autoSelect",
						},
						spellCheck:{name:"spellCheck",showName:(($ln==="CN")?("拼写检查"):("Spell check")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true},
						"borders":{
							name:"borders",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("border",valText,true);
								attrsVO["border"]=valText;
							}
						},
						"coner":{
							name:"coner",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(attrsVO.coners){
									return;
								}
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
						"coners":{
							name:"coners",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"inputType","text","color","placeHolder","pattern","bgColor",
						{name:"font",showName:(($ln==="CN")?("字体"):("Font")),attrs:["font","fontSize"],open:1},
						{name:"border",showName:(($ln==="CN")?("边框和角落"):("Border and Corner")),attrs:["outline","border","borderStyle","borderColor","corner"],open:1},
						"selectOnFocus","spellCheck",
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):("Is Containter")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":{
				name:"functions",showName:(($ln==="CN")?("事件响应"):("Events")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
					attrs:{
						...defFunctionDef.def.attrs,
						"OnInput":{name:"OnInput",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnChange":{name:"OnChange",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnUpdate":{name:"OnUpdate",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnFocus":{name:"OnFocus",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnBlur":{name:"OnBlur",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnCancel":{name:"OnCancel",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnKeyDown":{name:"OnKeyDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnKeyUp":{name:"OnKeyUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPressKeyUp":{name:"OnPressKeyUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPressKeyDown":{name:"OnPressKeyDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnNextEdit":{name:"OnNextEdit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPreviousEdit":{name:"OnPreviousEdit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
					},
					listHint:["OnInput","OnClick","OnChange","OnUpdate","OnFocus","OnBlur","OnCancel","OnKeyDown","OnKeyUp","OnPressKeyUp","OnPressKeyDown","OnNextEdit","OnPreviousEdit","OnMouseInOut","OnCreate","OnFree","OnTreeClick","OnSize"],
				}
			},
		}
	};

	//------------------------------------------------------------------------
	//:HudMemo:
	HudMemoDef={
		name:"memo",showName:(($ln==="CN")?("多行编辑"):("Edit Memo")),icon:"hudmemo.svg",
		gearDocDef:"GearEdit",//The GearDoc's def name
		info:(($ln==="CN")?("输入/编辑文本区域，用户可以使用此对象输入多行文本。可以通过属性调整外观，如背景颜色、文本颜色、字体、字体大小。"):("Input/edit text area, user can input multi-line text with this object. Appearence like background-color, text-color, font, font-size,can be adjusted with properties.")),
		//For add sub-hud
		allowExtraAttr:0,attrType:"hud",naviMultiSel:1,naviHasSub:false,
		initW:100,initH:80,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"memo",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):("Height")),type:"length",FVal:"FW",initVal:80,key:1,fixed:1,hideVal:0,
						},
						clip:{
							name:"clip",showName:(($ln==="CN")?("剪裁/滚动"):("Clip/Scroll")),type:"string",initVal:"auto",key:0,fixed:0,
						},
						text:{name:"text",showName:(($ln==="CN")?("文本"):("Text")),type:"string",initVal:"",key:1,fixed:1,hideVal:"",localizable:true},
						color:{name:"color",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGB",initVal:[0,0,0],key:1,fixed:1},
						bgColor:{
							name:"bgColor",showName:(($ln==="CN")?("背景"):("Background")),type:"colorRGBA",initVal:[255,255,255,1],key:1,fixed:1,hideVal:[255,255,255,1],
							exportName:"background",
						},
						font:{name:"font",showName:(($ln==="CN")?("字体"):("Font")),type:"string",initVal:"",key:1,fixed:1,hideVal:""},
						fontSize:{name:"fontSize",showName:(($ln==="CN")?("尺寸"):("Size")),type:"int",initVal:16,key:1,fixed:1,hideVal:16},
						outline:{name:"outline",showName:"Outline",type:"int",initVal:1,key:1,fixed:1,hideVal:1},
						border:{
							name:"border",showName:(($ln==="CN")?("尺寸"):("Size")),type:"auto",initVal:1,hideVal:0,key:1,fixed:1,editMode:"edges",
						},
						borderStyle:{
							name:"borderStyle",showName:(($ln==="CN")?("样式"):("Style")),type:"choice",key:1,fixed:1,
							vals:(($ln==="CN")?([[0,"None","无"],[1,"Solid","实线"],[2,"Dashed","断续线"],[3,"Dotted","点画线"]]):/*EN*/([[0,"None","None"],[1,"Solid","Solid"],[2,"Dashed","Dashed"],[3,"Dotted","Dotted"]])),initVal:1,hideVal:1,
						},
						borderColor:{
							name:"borderColor",showName:(($ln==="CN")?("颜色"):("Color")),type:"colorRGBA",initVal:[0,0,0,1],key:1,fixed:1,
						},
						corner:{
							name:"corner",showName:(($ln==="CN")?("角落尺寸"):("Corner size")),type:"auto",initVal:0,hideVal:0,key:1,fixed:1,editMode:"corners",
						},
						readOnly:{
							name:"readOnly",showName:(($ln==="CN")?("只读"):("Read Only")),type:"bool",initVal:false,hideVal:false,key:1,fixed:1,
						},
						selectOnFocus:{
							name:"selectOnFocus",showName:(($ln==="CN")?("自动选中"):("Auto select")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true,
							exportName:"autoSelect",
						},
						spellCheck:{name:"spellCheck",showName:(($ln==="CN")?("拼写检查"):("Spell check")),type:"bool",initVal:true,key:1,fixed:1,hideVal:true},
						"borders":{
							name:"borders",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("border",valText,true);
								attrsVO["border"]=valText;
							}
						},
						"coner":{
							name:"coner",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(attrsVO.coners){
									return;
								}
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
						"coners":{
							name:"coners",type:"converter",
							convert(owner,attrVO,attrsVO){
								let valText;
								if(typeof(attrVO)==="string"){
									valText=attrVO;
								}else{
									valText=attrVO.valText;
								}
								owner.setAttrByText("corner",valText,true);
								attrsVO["corner"]=valText;
							}
						},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						"text","color","bgColor","readOnly",
						{name:"font",showName:(($ln==="CN")?("字体"):("Font")),attrs:["font","fontSize"],open:1},
						{name:"border",showName:(($ln==="CN")?("边框和角落"):("Border and Corner")),attrs:["outline","border","borderStyle","borderColor","corner"],open:1},
						"selectOnFocus","spellCheck",
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):("Is Containter")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":{
				name:"functions",showName:(($ln==="CN")?("事件响应"):("Events")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"event.svg",allowExtraAttr:0,attrType:"function",attrTypeDef:"Function",
					attrs:{
						...defFunctionDef.def.attrs,
						"OnInput":{name:"OnInput",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnChange":{name:"OnChange",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnUpdate":{name:"OnUpdate",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnFocus":{name:"OnFocus",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnBlur":{name:"OnBlur",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnCancel":{name:"OnCancel",type:"fixedFunc",arguments:[],fixed:1,key:0},
						"OnKeyDown":{name:"OnKeyDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnKeyUp":{name:"OnKeyUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPressKeyUp":{name:"OnPressKeyUp",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPressKeyDown":{name:"OnPressKeyDown",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnNextEdit":{name:"OnNextEdit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
						"OnPreviousEdit":{name:"OnPreviousEdit",type:"fixedFunc",arguments:["event"],fixed:1,key:0},
					},
					listHint:["OnInput","OnClick","OnChange","OnUpdate","OnFocus","OnBlur","OnCancel","OnKeyDown","OnKeyUp","OnPressKeyUp","OnPressKeyDown","OnNextEdit","OnPreviousEdit","OnMouseInOut","OnCreate","OnFree","OnTreeClick","OnSize"],
				}
			},
		}
	};
}

//****************************************************************************
//Containers Group:
//****************************************************************************
{
	//------------------------------------------------------------------------
	UIView={
		name:"view",showName:(($ln==="CN")?("UI视图"):("UI View")),icon:"hudview.svg",
		gearDocDef:"UIView",//The GearDoc's def name
		info:(($ln==="CN")?("UI视图。UI视图，对话框入口。"):/*EN*/("UI View. UI view, dialog entry.")),
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"view",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):("Height")),type:"length",FVal:"FH",initVal:50,key:1,fixed:1,hideVal:0,
						},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h",
						{name:"layout",showName:(($ln==="CN")?("布局"):("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","subAlign","itemsAlign","itemsWrap","traceSize"],open:1},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	UIDock={
		name:"dock",showName:(($ln==="CN")?("UI 管理器"):("UI Dock")),icon:"huddock.svg",
		gearDocDef:"UIDock",//The GearDoc's def name
		info:(($ln==="CN")?("UI Dock，dock 管理子界面/视图。"):/*EN*/("UI Dock, dock manages sub-ui/views.")),
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"dock",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):/*EN*/("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):/*EN*/("Height")),type:"length",FVal:"FH",initVal:300,key:1,fixed:1,hideVal:0,
						},
						coverAction:{
							name:"coverAction",showName:(($ln==="CN")?("当UI关闭时"):("When UI dismiss")),type:"choice",vals:[[0,"Hide","Hide"],[1,"Dispose","Dispose"]],initVal:1,key:1,fixed:1,
						},
						ui:{
							name:"ui",showName:(($ln==="CN")?("入口界面"):("EntryUI")),type:"auto",initVal:0,key:1,fixed:1,
						},
					},
					listHint:[
						"id","attach","display","position","x","y","w","h","coverAction","ui",
						{name:"layout",showName:(($ln==="CN")?("布局"):/*EN*/("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","subAlign","itemsAlign","itemsWrap","traceSize"],open:1},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):/*EN*/("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};
	
	//------------------------------------------------------------------------
	HudFlexHBox={
		name:"FlexBoxH",showName:"FlexBox-X ",icon:"hudflexh.svg",
		gearDocDef:"GearFlexBoxH",//The GearDoc's def name
		info:"Flex layout box. Inner objects are layouted side by side in horizontal direction from left to right",
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:50,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:(($ln==="CN")?("对象属性"):("properties")),showName:"Properties",type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						display:{
							name:"display",type:"choice",key:1,fixed:1,
							vals:[[0,"Off"],["flex-x","On"]],initVal:"flex-x"
						},
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):/*EN*/("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):/*EN*/("Height")),type:"length",FVal:"FH",initVal:50,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"flex-x",hideVal:"",key:1,fixed:1,edit:false},
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:(($ln==="CN")?("布局"):/*EN*/("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):/*EN*/("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	HudFlexVBox={
		name:"FlexBoxV",showName:"FlexBox-Y ",icon:"hudflexv.svg",
		gearDocDef:"GearFlexBoxV",//The GearDoc's def name
		info:"Flex layout box. Inner objects are layouted side by side in vertical direction from top to bottom",
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):/*EN*/("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):/*EN*/("Height")),type:"length",FVal:"FH",initVal:300,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"flex-y",hideVal:"",key:1,fixed:1,edit:false},
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:(($ln==="CN")?("布局"):/*EN*/("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):/*EN*/("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	HudFlexHRBox={
		name:"FlexBoxHR",showName:"FlexBox-XR ",icon:"hudflexhr.svg",
		gearDocDef:"GearFlexBoxHR",//The GearDoc's def name
		info:"Flex layout box. Inner objects are layouted side by side in horizontal direction from right to left",
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:50,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):/*EN*/("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):/*EN*/("Height")),type:"length",FVal:"FH",initVal:50,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"flex-xr",hideVal:"",key:1,fixed:1,edit:false},
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:(($ln==="CN")?("布局"):/*EN*/("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):/*EN*/("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("是容器"):/*EN*/("Is Containter")),type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	HudFlexVRBox={
		name:"FlexBoxVR",showName:"FlexBox-YR ",icon:"hudflexvr.svg",
		gearDocDef:"GearFlexBoxVR",//The GearDoc's def name
		info:"Flex layout box. Inner objects are layouted side by side in vertical direction from bottom to top",
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:"Properties",type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:"Width",type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:"Height",type:"length",FVal:"FH",initVal:300,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"flex-yr",hideVal:"",key:1,fixed:1,edit:false},
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:"Layout",attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:"Constraints",attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:"Is Containter",type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	HudGridBox={
		name:"GridBox",showName:"GridBox",icon:"hudgrid.svg",
		gearDocDef:"GearGridBox",//The GearDoc's def name
		info:"Grid box layouts it's inner-objects as grid.",
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:"Properties",type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"hud",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:"Width",type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:"Height",type:"length",FVal:"FH",initVal:300,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"grid",hideVal:"",key:1,fixed:1,edit:false},
						gridConfig:{name:"gridConfig",type:"string",initVal:"",hideVal:"",key:1,fixed:1},
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:"Layout",attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:"Constraints",attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:"Is Containter",type:"bool",initVal:true,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};

	//------------------------------------------------------------------------
	HudTreeBox={
		name:"TreeBox",showName:(($ln==="CN")?("树形框"):/*EN*/("TreeBox")),icon:"hudtbx.svg",
		gearDocDef:"GearTreeBox",//The GearDoc's def name
		info:(($ln==="CN")?("树控件是图形界面中用于显示层次化数据结构的元素，通过节点的父子关系和展开折叠功能实现数据的组织和导航。"):/*EN*/("A tree component is an UI object used to display hierarchical data structures, organizing and navigating data through the parent-child relationship and expand/collapse functionality.")),
		//For add sub-hud
		allowExtraAttr:1,
		attrType:"hud",
		naviMultiSel:1,
		initW:200,initH:300,
		withFillType:true,
		//Hud properties:
		attrs:{
			properties:{
				name:"properties",showName:(($ln==="CN")?("对象属性"):/*EN*/("Properties")),type:"object",key:1,fixed:1,navi:"doc",edit:1,
				def:{
					icon:"menu.svg",allowExtraAttr:0,
					attrs:{
						type:{name:"type",type:"string",initVal:"tree",key:1,fixed:1,edit:false,},
						...HudAttr_Obj.attrs,
						w:{
							name:"w",showName:(($ln==="CN")?("宽度"):/*EN*/("Width")),type:"length",FVal:"FW",initVal:200,key:1,fixed:1,hideVal:0,
						},
						h:{
							name:"h",showName:(($ln==="CN")?("高度"):/*EN*/("Height")),type:"length",FVal:"FH",initVal:300,key:1,fixed:1,hideVal:0,
						},
						contentLayout:{name:"contentLayout",type:"string",initVal:"flex-y",edit:false,key:1,fixed:1,hideVal:""}
					},
					listHint:[
						"id","display","attach","position","x","y","w","h",
						{name:"layout",showName:(($ln==="CN")?("布局"):/*EN*/("Layout")),attrs:["anchorH","anchorV","autoLayout","margin","padding","flex","zIndex","contentLayout","subAlign","itemsAlign","itemsWrap","traceSize"],open:0},
						{name:"constraints",showName:(($ln==="CN")?("尺寸约束"):/*EN*/("Constraints")),attrs:["minW","maxW","minH","maxH"]},
						"clip","alpha","rotate","scale","filter","uiEvent","cursor",
						{name:"AISpot",showName:(($ln==="CN")?("AI 聚焦"):("AI Spot")),attrs:["exposeToAI","descAI"]},
					]
					//TODO: Add functions?
				},
			},
			...HudObjShellAttr,//Basic hud attrs: faces, subHuds,functions
			"container":{name:"container",showName:(($ln==="CN")?("可编辑子节点"):/*EN*/("Editable Children")),type:"bool",initVal:false,key:1,fixed:1,edit:false,rawEdit:false},
			"functions":defFunctionDef,
		}
	};
}

export {
	HudObjDef,
	HudBoxDef,HudTextDef,HudButtonDef,HudImageDef,HudEditDef,HudMemoDef,
	UIView,UIDock,HudFlexHBox,HudFlexVBox,HudFlexHRBox,HudFlexVRBox,HudGridBox,HudTreeBox
}