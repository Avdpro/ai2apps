import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {} from "./EditHudAni.js";//Make sure ani feature is ready.
import inherits from "/@inherits";
var EditHudFace,editHudFace;
var DefHudFace={
	name:"HudFace",icon:"faces.svg",allowExtraAttr:0,
	attrs:{
		properties:{
			name:"properties",showName:"Properties",
			type:"object",key:1,fixed:1,
			def:{
				icon:"menu.svg",
				attrs:{},
				objAttrs:{
					isHudFacePtts:1,
					getAttrDef:function(name){
						let defs,def,self;
						self=this;
						defs=this.faceAttrDefs;
						if(!defs){
							defs=this.faceAttrDefs={};
						}else{
							def=defs[name];
						};
						if(!def){
							def=this.owner.hudPpts.objDef.attrs[name];
							if(def){
								def=defs[name]={
									...def,key:0,
								};
							}
						}
						return def;
						//return this.owner.hudPpts.objDef.attrs[name];
					},
					getEditSubPpts:function(){
						return this.owner.hudPpts.getEditSubPpts();
					},
					checkAttrAdd:function(attrDef){
						let config,orgAttr,faceObj;
						config=this.prj.config;
						if(!config.allowFaceReplaceTraceAttr){
							faceObj=this.owner;
							if(typeof(attrDef)==="string"){
								attrDef=this.getAttrDef(attrDef);
							}
							orgAttr=faceObj.hudPpts.getAttr(attrDef.name);
							if(orgAttr && orgAttr.trace){
								//return error info:
								return "Replace traced attr in face is not allowed by editKit.allowFaceReplaceTraceAttr project setting.";
							}
						}
						return null;//No error
					}
				},
				autoOpen:1
			}
		},
		anis:{
			name:"anis",showName:"Animates",newAttrMode:"HudAni",
			type:"array",elementType:"hudani",key:1,fixed:1
		}
	},
	objAttrs:{isHudFace:1,renameAttr:null}
};
//****************************************************************************
//HudObject's face entry:
EditHudFace=function(owner,def,init){
	let doc,hudObj,ppts;
	EditObj.call(this,owner,def,true);
	this.hudObj=hudObj=owner.owner;
	this.hudPpts=hudObj.properties;
	this.properties=ppts=this.getAttr("properties");
	this.faceAttrList=ppts.attrList;
	this.faceAttrHash=ppts.attrHash;
	this.anis=this.getAttr("anis");
	doc=this.doc;	
	if(init && def.faceTag){
		this.faceTag=def.faceTag;
		this.faceTagId=def.faceTag.faceTagId;
	}
	this.properties.on("AttrAdd",(attr)=>{
		let liveObj,orgAttr,doc,attrDef,attrName,val;
		orgAttr=hudObj.properties.getAttr(attr.name);
		if(orgAttr){
			attr.setValByText(orgAttr.valText);
		}else{
			liveObj=hudObj.liveEdObj;
			if(hudObj.curFace===this && liveObj){
				attrDef=attr.def;
				if(!attrDef.notLiveVal){
					attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
					if("liveVal" in attrDef){
						val=attrDef.liveVal;
						if(val instanceof Function){
							val=val(attr);
						}
						liveObj[attrName]=val;
					}else{
						liveObj[attrName]=attr.val;
					}
				}
			}
		}
		doc=hudObj.doc;
		doc.emit("FaceOnUsed",hudObj);
	});
	this.properties.on("AttrChanged",(attr)=>{
		let liveObj,attrDef,attrName,val;
		liveObj=hudObj.liveEdObj;
		if(hudObj.curFace===this && liveObj){
			attrDef=attr.def;
			if(!attrDef.notLiveVal){
				attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
				if("liveVal" in attrDef){
					val=attrDef.liveVal;
					if(val instanceof Function){
						val=val(attr);
					}
					liveObj[attrName]=val;
				}else{
					liveObj[attrName]=attr.val;
				}
			}
		}
		doc=hudObj.doc;
		doc.emit("FaceOnUsed",hudObj);
		hudObj.emitObjChange();
	});
};

inherits(EditHudFace,EditObj);
EditAttr.regAttrType("hudface",EditHudFace);
editHudFace=EditHudFace.prototype;
EditHudFace.getDef=function(name){
	return DefHudFace;
};

//--------------------------------------------------------------------
editHudFace.isFaceUsed=function(){
	return this.properties.attrList.length>0 || this.anis.attrList.length>0;
};

//--------------------------------------------------------------------
editHudFace.loadFromVO=function(vo){
	let faceTagId;
	this.muteNotify();
	EditObj.prototype.loadFromVO.call(this,vo);
	faceTagId=vo.faceTagId;
	this.faceTagId=faceTagId;
	this.faceTag=this.doc.getFaceTag(faceTagId);
	if(!this.faceTag){
		let faceName=vo.faceTagName;
		this.faceTag=this.doc.getFaceTagByName(faceName);
		if(this.faceTag){
			this.def.name=this.name=this.faceTagId=this.faceTag.jaxId;
		}
	}
	this.unmuteNotify();
};

//--------------------------------------------------------------------
//Add faceTagId into genSaveVO:
editHudFace.genSaveVO=function(){
	let vo;
	if(this.attrList.length>0){
		let faceTag=this.doc.getFaceTag(this.faceTagId);
		if(faceTag){
			vo=EditObj.prototype.genSaveVO.call(this);
			vo.faceTagId=this.faceTagId;
			vo.faceTagName=faceTag.getName();
			return vo;
		}
	}
};

//----------------------------------------------------------------------------
editHudFace.getName=function(){
	return this.faceTag.getName();
};

//--------------------------------------------------------------------
editHudFace.updateHyperAttrs=function(force=false){
	let attrList,attrHash,i,n,attr,prtObj,attrName;
	let curLan,loc,lanTxt;
	prtObj=this.protoObj;
	attrHash=this.attrHash;
	if(prtObj && this.protoVsn!==prtObj.editVersion){
		let prtList;
		prtList=prtObj.attrList;
		for(attr of prtList){
			attrName=attr.name;
			if(!attrHash[attrName]){
				//add this attr:
				attr.cloneAttrToObj(this,{key:1});
			}
		}
		this.protoVsn=prtObj.editVersion;
	}
	if(force && this.scopeObj){
		this.buildScopeEnv();
	}
	attrList=this.attrList;
	n=attrList.length;
	for(i=0;i<n;i++){
		attr=attrList[i];
		if(attr.updateHyperAttrs){
			attr.updateHyperAttrs(force);
		}else{
			loc=attr.localize;
			if(loc){
				lanTxt=loc[curLan]||loc["EN"];
				attr.setValByText(lanTxt);
			}else if(attr.hyper){
				attr.setValByText(attr.valText);
			}
		}
	}
};

export {EditHudFace};