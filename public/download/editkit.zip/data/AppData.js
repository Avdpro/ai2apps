//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HRK338IN0StartDoc*/
/*}#1HRK338IN0StartDoc*/
let AppData={
	name:"AppData",//1HRK338IN2
	type:"object",
	properties:{
		/*#{1HRK338IN2MoreProperties*/
		/*}#1HRK338IN2MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HRK338IN2MoreFunctions*/
	/*}#1HRK338IN2MoreFunctions*/
};
VFACT.regUITemplate("1HRK338IN2",AppData);
VFACT.regUITemplate("AppData",AppData);
/*#{1HRK338IN2MoreCodes*/
/*}#1HRK338IN2MoreCodes*/
let TMPNewClass={
	name:"TMPNewClass",//1HRK34UQ40
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
			label:"Class name:",
			required:true,
		},
		useMockup:{
			name:"useMockup",type:"string",
			label:"Use Mockup",
			defaultValue:"No",
			uiMode:"./DLSelects.js",
			choices:[
				{text:"No mockup",value:"No"},"Object","Template"
			],
		},
		mockup:{
			name:"mockup",type:"string",
			label:"Mockup:",
			uiMode:"./DLCode.js",
		},
		/*#{1HRK34UQ40MoreProperties*/
		/*}#1HRK34UQ40MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HRK34UQ40MoreFunctions*/
	/*}#1HRK34UQ40MoreFunctions*/
};
VFACT.regUITemplate("1HRK34UQ40",TMPNewClass);
VFACT.regUITemplate("TMPNewClass",TMPNewClass);
/*#{1HRK34UQ40MoreCodes*/
/*}#1HRK34UQ40MoreCodes*/

/*#{1HRK338IN0EndDoc*/
/*}#1HRK338IN0EndDoc*/

export{AppData,TMPNewClass};
