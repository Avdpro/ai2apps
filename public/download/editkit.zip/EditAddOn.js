import {$P,VFACT,callAfter,sleep} from "/@vfact";
import {EditAttr} from "./EditAttr.js";
import {EditObj} from "./EditObj.js";
import {EditArray} from "./EditArray.js";
import {EditPrj} from "./EditPrj.js";
import {} from "./exporters/DocAppExporter.js";//Exporter for app.js
import {} from "./exporters/DocCfgExporter.js";//Exporter for appCfg.js
import {} from "./exporters/DocClassExporter.js";//Exporter for data class source files
import {} from "./exporters/GearExporter.js";//Exporter for UI component/view source files
import {} from "./exporters/HTML_VFACTExporter.js";//Exporter for HTML
import {TBXNaviPrj} from "./ui/TBXNaviPrj.js";
import {TBXNaviDoc} from "./ui/TBXNaviDoc.js";
import {TBXEditObj} from "./ui/TBXEditObj.js";
import {TBXDebugAgent} from "./ui/TBXDebugAgent.js";
//AIChat:
import AIChatCommands from "./ai/AIAddOn.js";
//Attribute edit line:
import {} from "./ui/EALStdAttr.js";
import {} from "./ui/EALBoolAttr.js";
import {} from "./ui/EALColor.js";
import {} from "./ui/EALFace.js";
import {} from "./ui/EALChoiceAttr.js";
import {} from "./ui/EALFileAttr.js";
import {} from "./ui/EALFontPreview.js";
import {} from "./ui/EALLengthAttr.js";
import {} from "./ui/EALNote.js";
import {} from "./ui/EALStepAttr.js";
import {UIEditGear} from "./ui/UIEditGear.js";
import {} from "./ui/EALFunction.js";
import {} from "./ui/EALHyperObj.js";
import {} from "./ui/EALButton.js";
import {} from "./edithud/VFACTHudTypes.js";

//Reister editkit classes into VFACT:
let editClasses;
editClasses=VFACT.EditKitClasses=VFACT.classRegs||{};
editClasses.EditPrj=EditPrj;
editClasses.EditAttr=EditAttr;
editClasses.EditObj=EditObj;
editClasses.EditArray=EditArray;
//TODO: Reigster more key classes into editClasses:

async function EditAddOn(dataPrj){
	let prj;
	prj=new EditPrj(dataPrj);
	await prj.loadPrj(dataPrj.path);
};

export default {
	"Project":{
		"EditAddOn":EditAddOn
	},
	"NaviTool":{
		"NaviPrj":TBXNaviPrj,
		"NaviDoc":TBXNaviDoc
	},
	"InfoTool":{
		"EditObj":TBXEditObj,
		"DebugAgent":TBXDebugAgent
	},
	"DocEditor":{
		"GearEditor":UIEditGear
	},
	"AICommand":AIChatCommands
};
