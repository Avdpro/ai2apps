
var CdySnapBox,CdySnapLine,__Proto;
var deviceHud,deviceHudX,deviceHudY,deviceHudW,deviceHudH;
var baseHud,baseHudX,baseHudY;

let freeLines,liveLinesX,liveLinesY;
let liveBoxes=[];
let freeSnapBoxes=[];
let freeEdgeDivs=[];
let lineIdx=0;

const EDGE_LEFT=1;
const EDGE_MIDX=2;
const EDGE_RIGHT=4;
const EDGE_TOP=8;
const EDGE_MIDY=16;
const EDGE_BOTTOM=32;
const EDGE_SIZEW=64;
const EDGE_SIZEH=128;

freeLines=[];
liveLinesX=[];
liveLinesY=[];

let allocEdgeDiv,freeEdgeDiv;
let CdySnapHintPosX,CdySnapHintPosY,CdySnapHintSizeX,CdySnapHintSizeY,CdySnapHintGapX,CdySnapHintGapY

//****************************************************************************
//Snap-Hints:
//****************************************************************************
{
	//------------------------------------------------------------------------
	CdySnapHintPosX=function(x,orgMinY,orgMaxY,box){
		let div,style,minY,maxY;
		this.update=function(){
			if(box){
				minY=box.vals[1][0];
				maxY=box.vals[1][2];
				if(minY>maxY){
					minY+=maxY;
					maxY=minY-maxY;
					minY=minY-maxY;
				}
				minY=minY<orgMinY?minY:orgMinY;
				maxY=maxY>orgMaxY?maxY:orgMaxY;
			}else{
				minY=orgMinY;
				maxY=orgMaxY;
			}
			style.top=(minY-15-baseHudY)+"px";
			style.height=(maxY-minY+30)+"px";
		};
		this.clear=function(){
			baseHud.webObj.removeChild(div);
			freeEdgeDiv(div);
		};
		div=allocEdgeDiv();
		style=div.style;
		style.left=(x-baseHudX)+"px";
		style.width="1px";
		this.update();
		baseHud.webObj.appendChild(div);
	};

	//------------------------------------------------------------------------
	CdySnapHintPosY=function(y,orgMinX,orgMaxX,box){
		let div,style,minX,maxX;
		this.update=function(){
			if(box){
				minX=box.vals[0][0];
				maxX=box.vals[0][2];
				if(minX>maxX){
					minX+=maxX;
					maxX=minX-maxX;
					minX=minX-maxX;
				}
				minX=minX<orgMinX?minX:orgMinX;
				maxX=maxX>orgMaxX?maxX:orgMaxX;
			}else{
				minX=orgMinX;
				maxX=orgMaxX;
			}
			style.left=(minX-15-baseHudX)+"px";
			style.width=(maxX-minX+30)+"px";
		};
		this.clear=function(){
			baseHud.webObj.removeChild(div);
			freeEdgeDiv(div);
		};
		div=allocEdgeDiv();
		style=div.style;
		style.top=(y-baseHudY)+"px";
		style.height="1px";
		this.update();
		baseHud.webObj.appendChild(div);
	};//Synced

	//------------------------------------------------------------------------
	CdySnapHintSizeX=function(box,trace=false){
		let x1,y1,x2,y2,midY;
		let divSize,divL,divR,styleSize,styleL,styleR;
		
		this.update=function(force){
			if(!trace && !force){
				return;
			}
			x1=box.x[0];x2=box.x[2];
			y1=box.y[0];y2=box.y[2];
			midY=(y1+y2)*0.5;

			styleSize.left=(x1-baseHudX)+"px";
			styleSize.width=(x2-x1)+"px";
			styleSize.top=(midY-baseHudY)+"px";
			styleSize.height="1px";

			styleL.left=(x1-baseHudX)+"px";
			styleL.width="3px";
			styleL.top=(midY-3-baseHudY)+"px";
			styleL.height="7px";

			styleR.left=(x2-3-baseHudX)+"px";
			styleR.width="3px";
			styleR.top=(midY-3-baseHudY)+"px";
			styleR.height="7px";
		};
		this.clear=function(){
			baseHud.webObj.removeChild(divSize);
			freeEdgeDiv(divSize);
			baseHud.webObj.removeChild(divL);
			freeEdgeDiv(divL);
			baseHud.webObj.removeChild(divR);
			freeEdgeDiv(divR);
		};
		x1=box.x[0];x2=box.x[2];
		y1=box.y[0];y2=box.y[2];
		divSize=allocEdgeDiv();
		styleSize=divSize.style;
		divL=allocEdgeDiv();
		styleL=divL.style;
		divR=allocEdgeDiv();
		styleR=divR.style;
		this.update(1);
		baseHud.webObj.appendChild(divL);
		baseHud.webObj.appendChild(divR);
		baseHud.webObj.appendChild(divSize);
	};

	//------------------------------------------------------------------------
	CdySnapHintSizeY=function(box,trace=false){
		let x1,y1,x2,y2,midX;
		let divSize,divL,divR,styleSize,styleL,styleR;
		
		this.update=function(force){
			if(!trace && !force){
				return;
			}
			x1=box.x[0];x2=box.x[2];
			y1=box.y[0];y2=box.y[2];
			midX=(x1+x2)*0.5;

			styleSize.top=(y1-baseHudY)+"px";
			styleSize.height=(y2-y1)+"px";
			styleSize.left=(midX-baseHudX)+"px";
			styleSize.width="1px";

			styleL.top=(y1-baseHudY)+"px";
			styleL.height="3px";
			styleL.left=(midX-3-baseHudX)+"px";
			styleL.width="7px";

			styleR.top=(y2-3-baseHudY)+"px";
			styleR.height="3px";
			styleR.left=(midX-3-baseHudX)+"px";
			styleR.width="7px";
		};
		this.clear=function(){
			baseHud.webObj.removeChild(divSize);
			freeEdgeDiv(divSize);
			baseHud.webObj.removeChild(divL);
			freeEdgeDiv(divL);
			baseHud.webObj.removeChild(divR);
			freeEdgeDiv(divR);
		};
		x1=box.x[0];x2=box.x[2];
		y1=box.y[0];y2=box.y[2];
		divSize=allocEdgeDiv();
		styleSize=divSize.style;
		divL=allocEdgeDiv();
		styleL=divL.style;
		divR=allocEdgeDiv();
		styleR=divR.style;
		this.update(1);
		baseHud.webObj.appendChild(divL);
		baseHud.webObj.appendChild(divR);
		baseHud.webObj.appendChild(divSize);
	};//Synced
	
	//------------------------------------------------------------------------
	CdySnapHintGapX=function(xL,ysL,xR,ysR,box){
		let divSide1,divSide2,divGap,swap;
		let styleSide1,styleSide2,styleGap;
		let boxY1,boxY2,minYL,maxYL,minYR,maxYR,minY,maxY,midY;
		
		if(box){
			ysR=box.y;
		}
		if(xL>xR){
			swap=xL;xL=xR;xR=swap;
			swap=ysL;ysL=ysR;ysR=swap;
		}
		this.update=function(){
			minYL=ysL[0];maxYL=ysL[2];
			minYR=ysR[0];maxYR=ysR[2];
			minY=minYL>minYR?minYL:minYR;
			maxY=maxYL<maxYR?maxYL:maxYR;
			midY=(minY+maxY)*0.5;
			styleGap.top=(midY-baseHudY)+"px";
			if(maxY>minY){
				styleSide1.top=(midY-2-baseHudY)+"px";
				styleSide1.height=(5)+"px";
				styleSide2.top=(midY-2-baseHudY)+"px";
				styleSide2.height=(5)+"px";
			}else{
				if(ysL[0]>=midY){
					styleSide1.top=(midY-2-baseHudY)+"px";
					styleSide1.height=(ysL[0]-midY+4)+"px";
				}else{
					styleSide1.top=(ysL[2]-2-baseHudY)+"px";
					styleSide1.height=(midY-ysL[2]+4)+"px";
				}
				
				if(ysR[0]>=midY){
					styleSide2.top=(midY-2-baseHudY)+"px";
					styleSide2.height=(ysR[0]-midY+4)+"px";
				}else{
					styleSide2.top=(ysR[2]-2-baseHudY)+"px";
					styleSide2.height=(midY-ysR[2]+4)+"px";
				}
			}
		}
		this.clear=function(){
			baseHud.webObj.removeChild(divSide1);
			baseHud.webObj.removeChild(divSide2);
			baseHud.webObj.removeChild(divGap);
			
		};
		
		divGap=allocEdgeDiv();
		styleGap=divGap.style;
		styleGap.left=(xL-baseHudX)+"px";
		styleGap.width=(xR-xL)+"px";
		styleGap.height="1px";

		divSide1=allocEdgeDiv();
		styleSide1=divSide1.style;
		styleSide1.left=(xL-baseHudX)+"px";
		styleSide1.width="3px";
		
		divSide2=allocEdgeDiv();
		styleSide2=divSide2.style;
		styleSide2.left=(xR-baseHudX-3)+"px";
		styleSide2.width="3px";

		this.update();
		baseHud.webObj.appendChild(divSide1);
		baseHud.webObj.appendChild(divSide2);
		baseHud.webObj.appendChild(divGap);
	};

	//------------------------------------------------------------------------
	CdySnapHintGapY=function(xsT,yT,xsB,yB,box){
		let divSide1,divSide2,divGap,swap;
		let styleSide1,styleSide2,styleGap;
		let boxX1,boxX2,minXT,maxXT,minXB,maxXB,minX,maxX,midX;
		
		if(box){
			xsB=box.x;
		}
		if(yT>yB){
			swap=yT;yT=yB;yB=swap;
			swap=xsT;xsT=xsB;xsB=swap;
		}
		this.update=function(){
			minXT=xsT[0];maxXT=xsT[2];
			minXB=xsB[0];maxXB=xsB[2];
			minX=minXT>minXB?minXT:minXB;
			maxX=maxXT<maxXB?maxXT:maxXB;
			midX=(minX+maxX)*0.5;
			styleGap.left=(midX-baseHudX)+"px";
			if(maxX>minX){
				styleSide1.left=(midX-2-baseHudX)+"px";
				styleSide1.width=(5)+"px";
				styleSide2.left=(midX-2-baseHudX)+"px";
				styleSide2.width=(5)+"px";
			}else{
				if(xsT[0]>=midX){
					styleSide1.left=(midX-2-baseHudX)+"px";
					styleSide1.width=(xsT[0]-midX+4)+"px";
				}else{
					styleSide1.left=(xsT[2]-2-baseHudX)+"px";
					styleSide1.width=(midX-xsT[2]+4)+"px";
				}
				
				if(xsB[0]>=midX){
					styleSide2.left=(midX-2-baseHudX)+"px";
					styleSide2.width=(xsB[0]-midX+4)+"px";
				}else{
					styleSide2.left=(xsB[2]-2-baseHudX)+"px";
					styleSide2.width=(midX-xsB[2]+4)+"px";
				}
			}
		}
		this.clear=function(){
			baseHud.webObj.removeChild(divSide1);
			baseHud.webObj.removeChild(divSide2);
			baseHud.webObj.removeChild(divGap);
			
		};
		
		divGap=allocEdgeDiv();
		styleGap=divGap.style;
		styleGap.top=(yT-baseHudY)+"px";
		styleGap.height=(yB-yT)+"px";
		styleGap.width="1px";

		divSide1=allocEdgeDiv();
		styleSide1=divSide1.style;
		styleSide1.top=(yT-baseHudY)+"px";
		styleSide1.height="3px";
		
		divSide2=allocEdgeDiv();
		styleSide2=divSide2.style;
		styleSide2.top=(yB-baseHudY-3)+"px";
		styleSide2.height="3px";

		this.update();
		baseHud.webObj.appendChild(divSide1);
		baseHud.webObj.appendChild(divSide2);
		baseHud.webObj.appendChild(divGap);
	};//Synced
}

//****************************************************************************
//Align-Line:
//****************************************************************************
{
	
	//-----------------------------------------------------------------------
	//Align-Line:
	CdySnapLine=function(){
		var div;
		this.dir=0;//0:V, 1:H;
		this.pos=0;
		this.posIdx=0;//0,1,2
		this.box=null;
		div=this.div=document.createElement("div");//
		div.style.backgroundColor="rgba(255,0,255,1)";
		div.style.position="absolute";
		this.edgeDiv=null;
		this.gapDiv=null;
		this.edgeGap=0;
		this.lineIdx=lineIdx++;
	};

	//-----------------------------------------------------------------------
	//Reset test buffer
	CdySnapLine.resetBuff=function(baseHud_,deviceHud_){
		let line,rect,div,pNode;

		baseHud=baseHud_;
		deviceHud=deviceHud_||baseHud;
		rect=baseHud.webObj.getClientRects()[0];
		deviceHudX=deviceHud.x-5;
		deviceHudY=deviceHud.y-5;
		deviceHudW=deviceHud.father.w-10;
		deviceHudH=deviceHud.father.h-10;
		if(rect) {
			baseHudX = Math.round(rect.left);
			baseHudY = Math.round(rect.top);
		}
		for(line of liveLinesX){
			freeLines.push(line);
			div=line.div;
			pNode=div.parentNode;
			if(pNode){
				pNode.removeChild(div);
			}
			div=line.edgeDiv;
			if(div){
				freeEdgeDiv(div);
				line.edgeDiv=null;
			}
			div=line.gapDiv;
			if(div){
				freeEdgeDiv(div);
				line.gapDiv=null;
			}
			line.edgeGap=0;
		}
		liveLinesX.splice(0);

		for(line of liveLinesY){
			freeLines.push(line);
			div=line.div;
			pNode=div.parentNode;
			if(pNode){
				pNode.removeChild(div);
			}
			div=line.edgeDiv;
			if(div){
				freeEdgeDiv(div);
				line.edgeDiv=null;
			}
			div=line.gapDiv;
			if(div){
				freeEdgeDiv(div);
				line.gapDiv=null;
			}
			line.edgeGap=0;
		}
		liveLinesY.splice(0);

		freeSnapBoxes=freeSnapBoxes.concat(liveBoxes);
		liveBoxes.splice(0);
	};

	//-----------------------------------------------------------------------
	//Alloc a line by box edge:
	CdySnapLine.allocLine=function(box,dir,idx){
		var line,style;
		line=freeLines.pop();
		if(!line){
			line=new CdySnapLine();
		}
		line.dir=dir;
		line.box=box;
		line.hudObj=box.hudObj;
		line.posIdx=idx;
		line.pos=box.vals[dir][idx];
		style=line.div.style;
		if(dir===0){//X-pos line, width 1
			style.left=(line.pos-baseHudX)+"px";
			style.width="1px";
			style.top=-deviceHudY+"px";
			style.height=deviceHudH+"px";
			liveLinesX.push(line);
		}else{//Y-pos line height 1
			style.top=(line.pos-baseHudY)+"px";
			style.height="1px";
			style.left=-deviceHudX+"px";
			style.width=deviceHudW+"px";
			liveLinesY.push(line);
		}
	};

	//------------------------------------------------------------------------
	//Free a line:
	CdySnapLine.freeLine=function(line){
		freeLines.push(line);
		if(line.parentNode){
			line.parentNode.removeChild(line);
		}
		if(line.edgeDiv){
			freeEdgeDiv(line.edgeDiv);
			line.edgeDiv=null;
		}
		if(line.gapDiv){
			freeEdgeDiv(line.gapDiv);
			line.gapDiv=null;
		}
		line.edgeGap=0;
	};

	//-----------------------------------------------------------------------
	//Alloc a HTML-DIV for edge:
	CdySnapLine.allocEdgeDiv=allocEdgeDiv=function(){
		var div;
		div=freeEdgeDivs.pop();
		if(!div){
			div=document.createElement('div');
			div.style.backgroundColor="rgba(255,0,255,0.5)";
			div.style.position="absolute";
		}
		return div;
	};

	//-----------------------------------------------------------------------
	//Free a edge's HTML-DIV:
	CdySnapLine.freeEdgeDiv=freeEdgeDiv=function(div){
		if(div.parentNode){
			div.parentNode.removeChild(div);
		}
		freeEdgeDivs.push(div);
	};

	//-----------------------------------------------------------------------
	//排序查询缓存:
	CdySnapLine.commitBuff=function(){
		liveLinesX.sort((a,b)=>a.pos-b.pos);
		liveLinesY.sort((a,b)=>a.pos-b.pos);
	};

	//-----------------------------------------------------------------------
	//找到最近的纵向Line:
	CdySnapLine.locateLineX=function(pos,edge,gap){
		let n,idx,line,delta,list,minLine,minDelta;
		let minIdx,maxIdx;
		list=liveLinesX;
		n=list.length;
		minIdx=0;maxIdx=n;
		idx=n;
		minLine=null;
		minDelta=100000;
		while(maxIdx>minIdx) {
			idx=(minIdx+maxIdx)>>1;
			line = list[idx];
			if(!line){
				break;
			}
			if (line.pos < pos) {
				minIdx=idx+1;
				delta=line.pos-pos;
				delta=delta<0?-delta:delta;
				if(delta<minDelta){
					minDelta=delta;
					minLine=line;
				}
				idx+=n;
			} else if (line.pos > pos) {
				maxIdx=idx;
				delta=line.pos-pos;
				delta=delta<0?-delta:delta;
				if(delta<minDelta){
					minDelta=delta;
					minLine=line;
				}
			} else {
				minDelta=0;
				minLine=line;
				break;
			}
		}
		line=minLine;
		if(line) {
			if (minDelta < gap) {
				return [line,minDelta];
			}
		}
		return [null,10000000];
	};

	//-----------------------------------------------------------------------
	//找到最近的纵向Line:
	CdySnapLine.locateLineY=function(pos,edge,gap){
		let n,idx,line,delta,list,minLine,minDelta;
		let minIdx,maxIdx;
		list=liveLinesY;
		n=list.length;
		minIdx=0;maxIdx=n;
		idx=n;
		minLine=null;
		minDelta=100000;
		while(maxIdx>minIdx) {
			idx=(minIdx+maxIdx)>>1;
			line = list[idx];
			if(!line){
				break;
			}
			if (line.pos < pos) {
				minIdx=idx+1;
				delta=line.pos-pos;
				delta=delta<0?-delta:delta;
				if(delta<minDelta){
					minDelta=delta;
					minLine=line;
				}
				idx+=n;
			} else if (line.pos > pos) {
				maxIdx=idx;
				delta=line.pos-pos;
				delta=delta<0?-delta:delta;
				if(delta<minDelta){
					minDelta=delta;
					minLine=line;
				}
			} else {
				minDelta=0;
				minLine=line;
				break;
			}
		}
		line=minLine;
		if(line) {
			if (minDelta < gap) {
				return [line,minDelta];
			}
		}
		return [null,10000000];
	};//Synced

	//-----------------------------------------------------------------------
	//找到横向间距对齐位置:
	CdySnapLine.locateGapX=function(box,gap,edgeFlags){
		let boxX1,boxX2,boxY1,boxY2;
		let lineList,n,i,line,lineBox,lineBoxY1,lineBoxY2,ovlpY1,ovlpY2,idxL;
		let gapLineL,gapLineIdxL,gapLineR,gapLineIdxR,gapSizeL,gapSizeR;
		let gapLineF,gapLineIdxF,gapSizeF,gapSideF,gapEdge;
		let dSize,adSize;
		gapSizeR=100000;
		gapSizeL=100000;
		boxX1=box.x[0];boxX2=box.x[2];
		boxY1=box.y[0];boxY2=box.y[2];
		lineList=liveLinesX;
		n=lineList.length;
		idxL=n;
		//先找到左侧最近的线:
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.pos>=boxX1){//找到了左侧最近的线，找Box有纵向有重叠的Line:
				idxL=i;
				if(edgeFlags&EDGE_LEFT){
					i--;
					for(;i>=0;i--){
						line=lineList[i];
						if(line.posIdx!==1){
							lineBox=line.box;
							lineBoxY1=lineBox.y[0];lineBoxY2=lineBox.y[2];
							ovlpY1=lineBoxY1>boxY1?lineBoxY1:boxY1;
							ovlpY2=lineBoxY2<boxY2?lineBoxY2:boxY2;
							if(ovlpY2>ovlpY1){
								gapLineL=line;
								gapLineIdxL=i;
								gapSizeL=boxX1-line.pos;
								break;
							}
						}
					}
				}
				break;
			}
		}
		if(edgeFlags&EDGE_RIGHT){
			//向右寻找离右边最近的第一个Line:
			for(i=idxL;i<n;i++){
				line=lineList[i];
				if(line.posIdx!==1){
					if(line.pos>boxX2){//这条线在box右侧，看看两个Box纵向有没有重叠
						lineBox=line.box;
						lineBoxY1=lineBox.y[0];lineBoxY2=lineBox.y[2];
						ovlpY1=lineBoxY1>boxY1?lineBoxY1:boxY1;
						ovlpY2=lineBoxY2<boxY2?lineBoxY2:boxY2;
						if(ovlpY2>ovlpY1){
							gapLineR=line;
							gapLineIdxR=i;
							gapSizeR=line.pos-boxX2;
							break;
						}
					}
				}
			}
		}
		if(gapLineL && gapLineR){
			dSize=(gapSizeL+gapSizeR)*0.5-gapSizeL;
			adSize=dSize<0?-dSize:dSize;
		}else{
			adSize=100000;
		}
		if(adSize<gapSizeL && adSize<gapSizeR && adSize<gap){
			gapLineF=gapLineL;
			gapSizeF=(gapSizeL+gapSizeR)*0.5;
			gapLineIdxF=gapLineIdxL;
			gapSideF=1;
			gapEdge=EDGE_LEFT|EDGE_RIGHT;
			return [gapSizeF,dSize,gapEdge];
		}else if(gapSizeL<=gapSizeR){
			gapLineF=gapLineL;
			gapSizeF=gapSizeL;
			gapLineIdxF=gapLineIdxL;
			gapSideF=1;
			gapEdge=EDGE_LEFT;
			if(gapSizeL===gapSizeR){
				gapEdge|=EDGE_RIGHT;
			}
		}else{
			gapLineF=gapLineR;
			gapSizeF=gapSizeR;
			gapLineIdxF=gapLineIdxR;
			gapSideF=-1;
			gapEdge=EDGE_RIGHT;
		}
		if(gapLineF){
			let curLine,nxtLine,curBox,nxtBox,curGap,delta;
			let curY1,curY2,nxtY1,nxtY2,ovlpY1,ovlpY2;
			//看看有没有接近的LineGap:
			for(i=1;i<n;i++){
				curLine=lineList[i-1];
				nxtLine=lineList[i];
				if(curLine.posIdx!==1 && nxtLine.posIdx!==1){
					curGap=nxtLine.pos-curLine.pos;
					if(curGap>0){
						delta=curGap-gapSizeF;
						if(delta>=-gap && delta<=gap){
							curBox=curLine.box;
							nxtBox=nxtLine.box;
							if(curBox!==nxtBox){
								curY1=curBox.y[0];curY2=curBox.y[2];
								nxtY1=nxtBox.y[0];nxtY2=nxtBox.y[2];
								ovlpY1=curY1>nxtY1?curY1:nxtY1;
								ovlpY2=curY2<nxtY2?curY2:nxtY2;
								if(ovlpY2>ovlpY1){
									//找到了一个可以吸的Gap:
									//console.log(`Found gap: ${curGap},${gapSideF*delta},${gapEdge}`);
									return [curGap,gapSideF*delta,gapEdge];
								}
							}
						}
					}
				}
			}
			return [0,0,0];
		}
		return [0,0,0];
	};

	//-----------------------------------------------------------------------
	//找到纵向间距对齐位置:
	CdySnapLine.locateGapY=function(box,gap,edgeFlags){
		let boxX1,boxX2,boxY1,boxY2;
		let lineList,n,i,line,lineBox,lineBoxX1,lineBoxX2,ovlpX1,ovlpX2,idxT;
		let gapLineT,gapLineIdxT,gapLineB,gapLineIdxB,gapSizeT,gapSizeB;
		let gapLineF,gapLineIdxF,gapSizeF,gapSideF,gapEdge;
		let dSize,adSize;
		gapSizeT=100000;
		gapSizeB=100000;
		boxX1=box.x[0];boxX2=box.x[2];
		boxY1=box.y[0];boxY2=box.y[2];
		lineList=liveLinesY;
		n=lineList.length;
		idxT=n;
		//先找到顶侧最近的线:
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.pos>=boxY1){//找到了顶侧最近的线，找Box有纵向有重叠的Line:
				idxT=i;
				if(edgeFlags&EDGE_TOP){
					i--;
					for(;i>=0;i--){
						line=lineList[i];
						if(line.posIdx!==1){
							lineBox=line.box;
							lineBoxX1=lineBox.x[0];lineBoxX2=lineBox.x[2];
							ovlpX1=lineBoxX1>boxX1?lineBoxX1:boxX1;
							ovlpX2=lineBoxX2<boxX2?lineBoxX2:boxX2;
							if(ovlpX2>ovlpX1){
								gapLineT=line;
								gapLineIdxT=i;
								gapSizeT=boxY1-line.pos;
								break;
							}
						}
					}
				}
				break;
			}
		}
		if(edgeFlags&EDGE_BOTTOM){
			//向右寻找离右边最近的第一个Line:
			for(i=idxT;i<n;i++){
				line=lineList[i];
				if(line.posIdx!==1){
					if(line.pos>boxY2){//这条线在box右侧，看看两个Box纵向有没有重叠
						lineBox=line.box;
						lineBoxX1=lineBox.x[0];lineBoxX2=lineBox.x[2];
						ovlpX1=lineBoxX1>boxX1?lineBoxX1:boxX1;
						ovlpX2=lineBoxX2<boxX2?lineBoxX2:boxX2;
						if(ovlpX2>ovlpX1){
							gapLineB=line;
							gapLineIdxB=i;
							gapSizeB=line.pos-boxY2;
							break;
						}
					}
				}
			}
		}
		if(gapLineT && gapLineB){
			dSize=(gapSizeT+gapSizeB)*0.5-gapSizeT;
			adSize=dSize<0?-dSize:dSize;
		}else{
			adSize=100000;
		}
		if(adSize<gapSizeT && adSize<gapSizeB && adSize<gap){
			gapLineF=gapLineT;
			gapSizeF=(gapSizeT+gapSizeB)*0.5;
			gapLineIdxF=gapLineIdxT;
			gapSideF=1;
			gapEdge=EDGE_TOP|EDGE_BOTTOM;
			return [gapSizeF,dSize,gapEdge];
		}else if(gapSizeT<=gapSizeB){
			gapLineF=gapLineT;
			gapSizeF=gapSizeT;
			gapLineIdxF=gapLineIdxT;
			gapSideF=1;
			gapEdge=EDGE_TOP;
			if(gapSizeT===gapSizeB){
				gapEdge|=EDGE_BOTTOM;
			}
		}else{
			gapLineF=gapLineB;
			gapSizeF=gapSizeB;
			gapLineIdxF=gapLineIdxB;
			gapSideF=-1;
			gapEdge=EDGE_BOTTOM;
		}
		if(gapLineF){
			let curLine,nxtLine,curBox,nxtBox,curGap,delta;
			let curX1,curX2,nxtX1,nxtX2,ovlpX1,ovlpX2;
			//看看有没有接近的LineGap:
			for(i=1;i<n;i++){
				curLine=lineList[i-1];
				nxtLine=lineList[i];
				if(curLine.posIdx!==1 && nxtLine.posIdx!==1){
					curGap=nxtLine.pos-curLine.pos;
					if(curGap>0){
						delta=curGap-gapSizeF;
						if(delta>=-gap && delta<=gap){
							curBox=curLine.box;
							nxtBox=nxtLine.box;
							if(curBox!==nxtBox){
								curX1=curBox.x[0];curX2=curBox.x[2];
								nxtX1=nxtBox.x[0];nxtX2=nxtBox.x[2];
								ovlpX1=curX1>nxtX1?curX1:nxtX1;
								ovlpX2=curX2<nxtX2?curX2:nxtX2;
								if(ovlpX2>ovlpX1){
									//找到了一个可以吸的Gap:
									//console.log(`Found gapY: ${curGap},${gapSideF*delta},${gapEdge}`);
									return [curGap,gapSideF*delta,gapEdge];
								}
							}
						}
					}
				}
			}
			return [0,0,0];
		}
		return [0,0,0];
	};//Synced:
	
	//------------------------------------------------------------------------
	//找到横向的尺寸对齐位置
	CdySnapLine.locateSizeX=function(box,gap,edgeFlags){
		let lineList,i,n,line,lineBox,boxSize,lineBoxSize,dSize,minDSize,minSize;
		minDSize=10000;
		boxSize=box.x[2]-box.x[0];
		lineList=liveLinesX;
		n=lineList.length;
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.posIdx===0){
				lineBox=line.box;
				lineBoxSize=lineBox.x[2]-lineBox.x[0];
				if(lineBoxSize>0){
					dSize=lineBoxSize-boxSize;
					dSize=dSize<0?-dSize:dSize;
					if(dSize<minDSize){
						minDSize=dSize;
						minSize=lineBoxSize;
					}
				}
			}
		}
		if(minDSize<gap){
			return [minSize,minSize-boxSize];
		}
		return [0,0];
	};

	//------------------------------------------------------------------------
	//找到纵向的尺寸对齐位置
	CdySnapLine.locateSizeY=function(box,gap,edgeFlags){
		let lineList,i,n,line,lineBox,boxSize,lineBoxSize,dSize,minDSize,minSize;
		minDSize=10000;
		boxSize=box.y[2]-box.y[0];
		lineList=liveLinesX;
		n=lineList.length;
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.posIdx===0){
				lineBox=line.box;
				lineBoxSize=lineBox.y[2]-lineBox.y[0];
				if(lineBoxSize>0){
					dSize=lineBoxSize-boxSize;
					dSize=dSize<0?-dSize:dSize;
					if(dSize<minDSize){
						minDSize=dSize;
						minSize=lineBoxSize;
					}
				}
			}
		}
		if(minDSize<gap){
			return [minSize,minSize-boxSize];
		}
		return [0,0];
	};//Synced
	
	let snapXLineHints=[];
	let snapYLineHints=[];
	//------------------------------------------------------------------------
	CdySnapLine.showSnapXPosHints=function(x,box){
		let minY=10000,maxY=-10000;
		let line,hint,style,lineBox,minBoxY,maxBoxY;
		for(line of liveLinesX){
			if(line.pos===x){
				lineBox=line.box;
				if(lineBox){
					minBoxY=lineBox.vals[1][0];
					maxBoxY=lineBox.vals[1][2];
					if(maxBoxY<minBoxY){//Swap
						minBoxY+=maxBoxY;
						maxBoxY=minBoxY-maxBoxY;
						minBoxY=minBoxY-maxBoxY;
					}
					if(minBoxY<minY){
						minY=minBoxY;
					}
					if(maxBoxY>maxY){
						maxY=maxBoxY;
					}
				}
			}else if(line.pos>x){
				break;
			}
		}
		//Add the hint:
		snapXLineHints.push(new CdySnapHintPosX(x,minY,maxY,box));
	};
	//------------------------------------------------------------------------
	CdySnapLine.showSnapXGapHints=function(gap,box,side){
		let line,i,n,nxtLine,div,curBox,nxtBox,curY1,curY2,nxtY1,nxtY2,maxY2;
		let boxPosL,boxEdgePosL,boxPosR,boxEdgePosR,boxLineL,boxLineR;
		let ds;
		if(side){//===EDGE_LEFT&EDGE_RIGHT){
			if(side&EDGE_LEFT){//Left
				boxEdgePosL=box.x[0];
				boxPosL=boxEdgePosL-gap;
			}
			if(side&EDGE_RIGHT){
				boxEdgePosR=box.x[2];
				boxPosR=boxEdgePosR+gap;
			}
			n=liveLinesX.length-1;
			for(i=0;i<n;i++){
				line=liveLinesX[i];
				if(line.posIdx!==1){
					nxtLine=liveLinesX[i+1];
					while(nxtLine.posIdx===1){
						i++;
						nxtLine=liveLinesX[i+1];
					}
					curBox=line.box;
					nxtBox=nxtLine.box;
					if(curBox!==nxtBox){
						if(nxtLine.pos-line.pos===gap){
							//Show this gap:
							snapXLineHints.push(new CdySnapHintGapX(line.pos,curBox.y,nxtLine.pos,nxtBox.y,null));
						}
					}
					ds=line.pos-boxPosL;
					ds=ds<0?-ds:ds;
					if(ds<1){
						boxLineL=line;
					}
					ds=line.pos-boxPosR;
					ds=ds<0?-ds:ds;
					if(ds<1){
						boxLineR=line;
					}
				}
			}
			if(!boxLineL){
				ds=nxtLine.pos-boxPosL;
				ds=ds<0?-ds:ds;
				if(ds<1){
					boxLineL=nxtLine;
				}
			}
			if(!boxLineR){
				ds=nxtLine.pos-boxPosR;
				ds=ds<0?-ds:ds;
				if(ds<1){
					boxLineR=nxtLine;
				}
			}
			if(boxLineL){
				curBox=boxLineL.box;
				//Show gap div of the box:
				snapXLineHints.push(new CdySnapHintGapX(boxLineL.pos,curBox.y,boxEdgePosL,box.y,box));
			}
			if(boxLineR){
				curBox=boxLineR.box;
				//Show gap div of the box:
				snapXLineHints.push(new CdySnapHintGapX(boxLineR.pos,curBox.y,boxEdgePosR,box.y,box));
			}
		}
	};
	//------------------------------------------------------------------------
	CdySnapLine.showSnapXSizeHints=function(size,box){
		let lineList,i,n,line,lineBox,lineBoxSize;
		lineList=liveLinesX;
		n=lineList.length;
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.posIdx===0){
				lineBox=line.box;
				lineBoxSize=lineBox.x[2]-lineBox.x[0];
				if(lineBoxSize===size){
					snapXLineHints.push(new CdySnapHintSizeX(lineBox,false));
				}
			}
		}
		snapXLineHints.push(new CdySnapHintSizeX(box,true));
	};
	//------------------------------------------------------------------------
	CdySnapLine.updateSnapXHints=function(){
		let hint;
		for (hint of snapXLineHints) {
			hint.update();
		}
	};
	//------------------------------------------------------------------------
	CdySnapLine.clearSnapXHints=function(){
		let hint;
		for (hint of snapXLineHints) {
			hint.clear();
		}
		snapXLineHints.splice(0);
	};
	
	//------------------------------------------------------------------------
	CdySnapLine.showSnapYPosHints=function(y,box){
		let minX=10000,maxX=-10000;
		let line,hint,style,lineBox,minBoxX,maxBoxX;
		for(line of liveLinesY){
			if(line.pos===y){
				lineBox=line.box;
				if(lineBox){
					minBoxX=lineBox.x[0];
					maxBoxX=lineBox.x[2];
					if(maxBoxX<minBoxX){//Swap
						minBoxX+=maxBoxX;
						maxBoxX=minBoxX-maxBoxX;
						minBoxX=minBoxX-maxBoxX;
					}
					if(minBoxX<minX){
						minX=minBoxX;
					}
					if(maxBoxX>maxX){
						maxX=maxBoxX;
					}
				}
			}else if(line.pos>y){
				break;
			}
		}
		//Add the hint:
		snapYLineHints.push(new CdySnapHintPosY(y,minX,maxX,box));
	};//Synced
	//------------------------------------------------------------------------
	CdySnapLine.showSnapYGapHints=function(gap,box,side){
		let line,i,n,nxtLine,div,curBox,nxtBox,curX1,curX2,nxtX1,nxtX2,maxX2;
		let boxPosT,boxEdgePosT,boxPosB,boxEdgePosB,boxLineT,boxLineB;
		let ds;
		if(side){//===EDGE_TOP&EDGE_BOTTOM){
			if(side&EDGE_TOP){//Left
				boxEdgePosT=box.y[0];
				boxPosT=boxEdgePosT-gap;
			}
			if(side&EDGE_BOTTOM){
				boxEdgePosB=box.y[2];
				boxPosB=boxEdgePosB+gap;
			}
			n=liveLinesY.length-1;
			for(i=0;i<n;i++){
				line=liveLinesY[i];
				if(line.posIdx!==1){
					nxtLine=liveLinesY[i+1];
					while(nxtLine.posIdx===1){
						i++;
						nxtLine=liveLinesY[i+1];
					}
					curBox=line.box;
					nxtBox=nxtLine.box;
					if(curBox!==nxtBox){
						if(nxtLine.pos-line.pos===gap){
							//Show this gap:
							snapYLineHints.push(new CdySnapHintGapY(curBox.x,line.pos,nxtBox.x,nxtLine.pos,null));
						}
					}
					ds=line.pos-boxPosT;
					ds=ds<0?-ds:ds;
					if(ds<1){
						boxLineT=line;
					}
					ds=line.pos-boxPosB;
					ds=ds<0?-ds:ds;
					if(ds<1){
						boxLineB=line;
					}
				}
			}
			if(!boxLineT){
				ds=nxtLine.pos-boxPosT;
				ds=ds<0?-ds:ds;
				if(ds<1){
					boxLineT=nxtLine;
				}
			}
			if(!boxLineB){
				ds=nxtLine.pos-boxPosB;
				ds=ds<0?-ds:ds;
				if(ds<1){
					boxLineB=nxtLine;
				}
			}
			if(boxLineT){
				curBox=boxLineT.box;
				//Show gap div of the box:
				snapYLineHints.push(new CdySnapHintGapY(curBox.x,boxLineT.pos,box.x,boxEdgePosT,box));
			}
			if(boxLineB){
				curBox=boxLineB.box;
				//Show gap div of the box:
				snapYLineHints.push(new CdySnapHintGapY(curBox.x,boxLineB.pos,box.x,boxEdgePosB,box));
			}
		}
	};//Synced
	//------------------------------------------------------------------------
	CdySnapLine.showSnapYSizeHints=function(size,box){
		let lineList,i,n,line,lineBox,lineBoxSize;
		lineList=liveLinesY;
		n=lineList.length;
		for(i=0;i<n;i++){
			line=lineList[i];
			if(line.posIdx===0){
				lineBox=line.box;
				lineBoxSize=lineBox.y[2]-lineBox.y[0];
				if(lineBoxSize===size){
					snapYLineHints.push(new CdySnapHintSizeY(lineBox,false));
				}
			}
		}
		snapYLineHints.push(new CdySnapHintSizeY(box,true));
	};//Synced
	//------------------------------------------------------------------------
	CdySnapLine.updateSnapYHints=function(){
		let hint;
		for (hint of snapYLineHints) {
			hint.update();
		}
	};//Synced
	//------------------------------------------------------------------------
	CdySnapLine.clearSnapYHints=function(){
		let hint;
		for (hint of snapYLineHints) {
			hint.clear();
		}
		snapYLineHints.splice(0);
	};//Synced

	__Proto=CdySnapLine.prototype={};

	//-----------------------------------------------------------------------
	//显示一个Line:
	__Proto.show=function(){
		baseHud.webObj.appendChild(this.div);
		if(this.edgeGap){
			this.showEdgeGap();
		}else {
			this.showEdge();
		}
	};

	//-----------------------------------------------------------------------
	//隐藏一个Line:
	__Proto.hide=function(){
		let pNode;
		pNode=this.div.parentNode;
		if(pNode){
			pNode.removeChild(this.div);
		}
		this.hideEdge();
		this.hideEdgeGap();
		this.edgeGap=0;
	};

	//-----------------------------------------------------------------------
	//显示line的edge:
	__Proto.showEdge=function(){
		let div,style,box;
		if(this.edgeDiv){
			return;
		}
		div=allocEdgeDiv();
		this.edgeDiv=div;
		box=this.box;
		style=div.style;
		switch(this.dir){
			case 0:{//垂直:
				style.left=(this.pos-1-baseHudX)+"px";
				style.width="3px";
				style.top=(box.y[0]-baseHudY)+"px";
				style.height=(box.y[2]-box.y[0])+"px";
				break;
			}
			case 1:{//水平:
				style.top=(this.pos-1-baseHudY)+"px";
				style.height="3px";
				style.left=(box.x[0]-baseHudX)+"px";
				style.width=(box.x[2]-box.x[0])+"px";
				break;
			}
		}
		baseHud.webObj.appendChild(div);
	};

	//-----------------------------------------------------------------------
	//隐藏edge
	__Proto.hideEdge=function(){
		let div;
		div=this.edgeDiv;
		if(div){
			freeEdgeDiv(div);
			this.edgeDiv=null;
		}
	};

	//-----------------------------------------------------------------------
	//显示line的Gap:
	__Proto.showEdgeGap=function() {
		let div,style,box;
		if(this.gapDiv){
			return;
		}
		div=allocEdgeDiv();
		this.gapDiv=div;
		box=this.box;
		style=div.style;
		switch(this.dir){
			case 0:{//垂直:
				style.top=(box.y[1]-3-baseHudY)+"px";
				style.height="7px";
				if(this.posIdx===0){//左边
					style.left=(this.pos-this.edgeGap-baseHudX)+"px";
					style.width=this.edgeGap+"px";
				}else if(this.posIdx===2){//右边
					style.left=(this.pos-baseHudX)+"px";
					style.width=this.edgeGap+"px";
				}
				else{
					this.gapDiv=null;
					freeEdgeDiv(div);
					return;
				}
				break;
			}
			case 1:{//水平:
				style.left=(box.x[1]-3-baseHudX)+"px";
				style.width="7px";
				if(this.posIdx===0){//上边
					style.top=(this.pos-this.edgeGap-baseHudY)+"px";
					style.height=this.edgeGap+"px";
				}else if(this.posIdx===2){//下边
					style.top=(this.pos-baseHudY)+"px";
					style.height=this.edgeGap+"px";
				}
				else{
					this.gapDiv=null;
					freeEdgeDiv(div);
					return;
				}
				break;
			}
		}
		baseHud.webObj.appendChild(div);
	};

	//-----------------------------------------------------------------------
	//隐藏line的Gap:
	__Proto.hideEdgeGap=function(){
		let div;
		div=this.gapDiv;
		if(div){
			freeEdgeDiv(div);
			this.gapDiv=null;
		}
	};
}

//***************************************************************************
//对齐盒子
//***************************************************************************
{
	//-----------------------------------------------------------------------
	//构造函数
	CdySnapBox = function () {
		this.hudObj = null;
		this.liveObj = null;
		this.alignObj=null;
		this.x = [0, 0, 0];
		this.y = [0, 0, 0];
		this.vals=[this.x,this.y];
		this.gapL=-1;
		this.gapR=-1;
		this.lineT=null;
		this.lineB=null;
		this.lineL=null;
		this.lineR=null;
	};

	//-----------------------------------------------------------------------
	//分配一个box
	CdySnapBox.allocBox = function (hudObj,buildLine=1) {
		var box;
		box = freeSnapBoxes.pop();
		if (!box) {
			box = new CdySnapBox();
		}
		if(hudObj){
			if(!box.bindHud(hudObj,buildLine)){
				this.freeBox(box);
				return null;
			}
		}else{
			box.mergeStart();
		}
		return box;
	};

	//------------------------------------------------------------------------
	//Alloc lines for editHudObj's bound box, also alloc a box
	CdySnapBox.allocBoxLine = function (hudObj,isOwner=false) {
		var box;
		box = freeSnapBoxes.pop();
		if (!box) {
			box = new CdySnapBox();
		}
		if(!box.bindHud(hudObj,1,isOwner)){
			this.freeBox(box);
			return 0;
		}
		liveBoxes.push(box);
		return 1;
	};

	//------------------------------------------------------------------------
	CdySnapBox.allocDeviceBoxLine=function(deviceHud){
		var box;
		box = freeSnapBoxes.pop();
		if (!box) {
			box = new CdySnapBox();
		}
		if(!box.bindWebObj(deviceHud.webObj,1)){
			this.freeBox(box);
			return 0;
		}
		liveBoxes.push(box);
	};

	//------------------------------------------------------------------------
	//Free and recycle a box
	CdySnapBox.freeBox = function (box) {
		var webObj;
		freeSnapBoxes.push(box);
		if(box.lineT){
			webObj=baseHud.webObj;
			webObj.removeChild(box.lineT);
			webObj.removeChild(box.lineB);
			webObj.removeChild(box.lineL);
			webObj.removeChild(box.lineR);
			box.lineT=null;
			box.lineB=null;
			box.lineL=null;
			box.lineR=null;
		}
	};

	__Proto = CdySnapBox.prototype = {};

	//-----------------------------------------------------------------------
	//Bind a EditHudObj
	__Proto.bindHud=function(hudObj,buildLine=1,exBorder=false) {
		var webObj,liveObj,rect,list,x,y;
		this.hudObj=hudObj;
		liveObj=this.liveObj=hudObj.liveEdObj;
		webObj=liveObj.webObj;
		list=webObj.getClientRects();
		if(!list.length){
			return 0;
		}
		rect=list[0];
		x=this.x;
		y=this.y;

		if(hudObj.isHudGroup){
			let x1,x2,y1,y2,liveObj;
			liveObj=hudObj.liveEdObj;
			[x1,y1,x2,y2]=hudObj.getGroupRect(0);
			x2+=x1;
			y2+=y1;
			[x[0],y[0]]=liveObj.findRelatedPos(x1, y1);
			[x[2],y[2]]=liveObj.findRelatedPos(x2, y2);
			x[1]=(x[0]+x[2])*0.5;
			y[1]=(y[0]+y[2])*0.5;
		}else {
			if(exBorder){
				let bw,bh,ow,oh,scaleX,scaleY;
				bw=rect.right-rect.left;
				bh=rect.bottom-rect.top;
				ow=webObj.offsetWidth;
				oh=webObj.offsetHeight;
				scaleX=bw?ow/bw:0;
				scaleY=bh?oh/bh:0;
				x[0] = Math.round(rect.left+webObj.clientLeft*scaleX);
				x[2] = Math.round(x[0]+webObj.clientWidth*scaleX);
				
				y[0] = Math.round(rect.top+webObj.clientTop*scaleY);
				y[2] = Math.round(y[0]+webObj.clientHeight*scaleY);
			}else{
				x[0] = Math.round(rect.left);
				x[2] = Math.round(rect.right);

				y[0] = Math.round(rect.top);
				y[2] = Math.round(rect.bottom);
			}

			x[1] = (x[0] + x[2]) * 0.5;
			y[1] = (y[0] + y[2]) * 0.5;
		}

		if(buildLine) {
			CdySnapLine.allocLine(this, 0, 0);
			CdySnapLine.allocLine(this, 0, 1);
			CdySnapLine.allocLine(this, 0, 2);

			CdySnapLine.allocLine(this, 1, 0);
			CdySnapLine.allocLine(this, 1, 1);
			CdySnapLine.allocLine(this, 1, 2);
		}
		return 1;
	};

	//-----------------------------------------------------------------------
	//Bind with a HTML element
	__Proto.bindWebObj=function(webObj,buildLine=1) {
		var rect,list,x,y;
		this.hudObj=null;
		this.liveObj=null;
		list=webObj.getClientRects();
		if(!list.length){
			return 0;
		}
		rect=list[0];
		x=this.x;
		y=this.y;

		x[0] = Math.round(rect.left);
		x[2] = Math.round(rect.right);
		x[1] = (x[0] + x[2]) * 0.5;

		y[0] = Math.round(rect.top);
		y[2] = Math.round(rect.bottom);
		y[1] = (y[0] + y[2]) * 0.5;

		if(buildLine) {
			CdySnapLine.allocLine(this, 0, 0);
			CdySnapLine.allocLine(this, 0, 1);
			CdySnapLine.allocLine(this, 0, 2);

			CdySnapLine.allocLine(this, 1, 0);
			CdySnapLine.allocLine(this, 1, 1);
			CdySnapLine.allocLine(this, 1, 2);
		}
		return 1;
	};
	
	//-----------------------------------------------------------------------
	__Proto.mergeStart=function(){
		let x,y;
		this.hudObj=null;
		this.liveObj=null;
		this.alignObj=null;
		this.dx=0;this.dy=0;
		x=this.x;y=this.y;
		x[0]=1000000;
		x[2]=-1000000;
		y[0]=1000000;
		y[2]=-1000000;
	};

	//-----------------------------------------------------------------------
	__Proto.mergeHud=function(hudObj,exBorder=false){
		var webObj,liveObj,rect,list,x,y,x0,y0,x2,y2;
		liveObj=hudObj.liveEdObj;
		webObj=liveObj.webObj;
		list=webObj.getClientRects();
		if(!list.length){
			return 0;
		}
		rect=list[0];
		x=this.x;
		y=this.y;

		if(exBorder){
			let bw,bh,ow,oh,scaleX,scaleY;
			bw=rect.right-rect.left;
			bh=rect.bottom-rect.top;
			ow=webObj.offsetWidth;
			oh=webObj.offsetHeight;
			scaleX=bw?ow/bw:0;
			scaleY=bh?oh/bh:0;
			
			x0=Math.round(rect.left+webObj.clientLeft*scaleX);
			x[0]=x0<x[0]?x0:x[0];
			x2=Math.round(x[0]+webObj.clientWidth*scaleX);
			x[2]=x2>x[2]?x2:x[2];

			y0=Math.round(rect.top+webObj.clientTop*scaleY);
			y[0]=y0<y[0]?y0:y[0];
			y2=Math.round(y[0]+webObj.clientHeight*scaleY);
			y[2]=y2>y[2]?y2:y[2];
		}else{
			x0=Math.round(rect.left);
			x[0]=x0<x[0]?x0:x[0];
			x2=Math.round(rect.right);;
			x[2]=x2>x[2]?x2:x[2];
			
			y0=Math.round(rect.top);;
			y[0]=y0<y[0]?y0:y[0];
			y2=Math.round(rect.bottom);
			y[2]=y2>y[2]?y2:y[2];
		}
		this.alignObj=liveObj;
		this.dx=x[0]-Math.round(rect.left);
		this.dy=y[0]-Math.round(rect.top);
		console.log(`x=${x[0]}, dx=${this.dx}`);
	};
	
	//-----------------------------------------------------------------------
	__Proto.mergeEnd=function(buildLine=true){
		let x,y;
		x=this.x;
		y=this.y;
		x[1] = (x[0] + x[2]) * 0.5;
		y[1] = (y[0] + y[2]) * 0.5;
		if(buildLine) {
			CdySnapLine.allocLine(this, 0, 0);
			CdySnapLine.allocLine(this, 0, 1);
			CdySnapLine.allocLine(this, 0, 2);

			CdySnapLine.allocLine(this, 1, 0);
			CdySnapLine.allocLine(this, 1, 1);
			CdySnapLine.allocLine(this, 1, 2);
		}
	};

	//-----------------------------------------------------------------------
	//Update box position:
	__Proto.update=function(webObj,dx=0,dy=0,w=null,h=null){
		var liveObj,rect,list,x,y,dw,dh;
		if(!webObj) {
			liveObj = this.liveObj;
			if(liveObj){
				webObj = liveObj.webObj;
			}else if(liveObj=this.alignObj){
				webObj=liveObj.webObj;
				list=webObj.getClientRects();
				if(!list.length){
					return 0;
				}
				rect=list[0];
				x=this.x;y=this.y;
				dx=Math.round(rect.left+this.dx+dx)-x[0];
				dy=Math.round(rect.top+this.dy+dy)-y[0];
				x[0]+=dx; x[1]+=dx; x[2]+=dx;
				y[0]+=dy; y[1]+=dy; y[2]+=dy;
				//console.log(`x=${x[0]}, y=${y[0]}, dx=${this.dx}`);
				return 1;
			}else{
				return 0;
			}
		}
		list=webObj.getClientRects();
		if(!list.length){
			return 0;
		}
		rect=list[0];
		x=this.x;
		y=this.y;
		if(w===null){
			w=rect.right-rect.left;
		}else{
			dw=w-(x[2]-x[0]);
		}
		x[0]=Math.round(rect.left+dx);
		x[2]=Math.round(rect.left+w+dx);
		x[1]=x[0]+(x[2]-x[0])*0.5;

		if(h===null){
			w=rect.bottom-rect.top;
		}else{
			dh=h-(y[2]-y[0]);
		}
		y[0]=Math.round(rect.top+dy);
		y[2]=Math.round(rect.top+h+dy);
		y[1]=y[0]+(y[2]-y[0])*0.5;
		//console.log(`dx:${dx}, dy:${dy}, w:${w}, h:${h}`);
		//console.log(`x:${x}, y:${y}`);
	};

	//-----------------------------------------------------------------------
	//Find X snap pos-line:
	__Proto.findSnapX=function(vo){
		let line1,line2,line3,gap1,gap2,gap3;
		let minPosDelta,pos,cnt,delta,minDelta;
		let minGapDelta,gapDelta,gapSize,gapEdge;
		let minSizeDelta,sizeDelta,sizeSize;
		let flag=0;
		var hud=this.hudObj;
		let x=this.x;

		//Factors from vo:
		let lineList=vo.snapLines;
		let gap=vo.checkGap;
		let edgeFlags=vo.edgeFlags;
		let boxDxFactor=vo.boxDxFactor;
		let boxDwFactor=vo.boxDwFactor;
		//let boxDyFactor=vo.boxDyFactor;
		//let boxDhFactor=vo.boxDhFactor;

		//Find edge align location:
		gap3=gap2=gap1=100000;
		minPosDelta=minGapDelta=minSizeDelta=100000;
		if(edgeFlags){
			if(edgeFlags&EDGE_LEFT){
				[line1,gap1] = CdySnapLine.locateLineX(x[0], 0, gap, hud);
			}
			if(edgeFlags&EDGE_MIDX){
				[line2,gap2] = CdySnapLine.locateLineX(x[1], 1, gap, hud);
			}
			if(edgeFlags&EDGE_RIGHT){
				[line3,gap3] = CdySnapLine.locateLineX(x[2], 2, gap, hud);
			}
		}
		minPosDelta=gap1<gap2?(gap3<gap1?gap3:gap1):(gap3<gap2?gap3:gap2);
		//Find gap snap delta:
		{
			[gapSize,gapDelta,gapEdge]=CdySnapLine.locateGapX(this,gap,edgeFlags);
			if(gapSize){
				minGapDelta=gapDelta>0?gapDelta:-gapDelta;
			}
		}
		//Find size snap delta:
		if(edgeFlags&EDGE_SIZEW && vo.boxDwFactor){
			[sizeSize,sizeDelta]=CdySnapLine.locateSizeX(this,gap,edgeFlags);
			if(sizeSize){
				minSizeDelta=sizeDelta>0?sizeDelta:-sizeDelta;
			}
		}
		minDelta=minPosDelta<minGapDelta?(minPosDelta<minSizeDelta?minPosDelta:minSizeDelta):(minGapDelta<minSizeDelta?minGapDelta:minSizeDelta);
		if(minDelta<gap){
			if(minPosDelta===minDelta){
				cnt=0;
				if(line1 && gap1===minPosDelta){
					pos=line1.pos;
					delta=(pos-x[0]);///boxDxFactor;
					cnt++;
					flag|=EDGE_LEFT;
					vo.snaped=1;
					vo.snapPos=1;
					vo.dx=delta;
					vo.snapPoses.push(pos);
				}
				if(line2 && gap2===minPosDelta){
					pos=line2.pos;
					vo.snapPoses.push(pos);
					if(!cnt){//TODO:后面的条件有必要么? || pos===line2.pos){
						delta=(pos-x[1]);///boxDxFactor;
						cnt++;
						flag|=EDGE_MIDX;
						vo.snapPos=1;
						vo.snaped=1;
						vo.dx=delta;
					}
				}
				if(line3 && gap3===minPosDelta){
					pos=line3.pos;
					vo.snapPoses.push(pos);
					if(!cnt){//TODO:后面的条件有必要么? || pos===line3.pos){
						delta=(pos-x[2]);///boxDxFactor;
						cnt++;
						flag|=EDGE_RIGHT;
						vo.snaped=1;
						vo.snapPos=1;
						vo.dx=delta;
					}
				}
			}else{
				vo.snapPos=0;
			}
			if(minSizeDelta===minDelta){
				flag=EDGE_SIZEW;
				vo.snaped=1;
				vo.snapSize=1;
				vo.snapSizeSize=sizeSize;
				vo.dx=sizeDelta/vo.boxDwFactor;
				cnt++;
			}else{
				vo.snapSize=0;
				vo.snapSizeSize=0;
			}
			if(minGapDelta===minDelta){
				vo.snaped=1;
				vo.dx=gapDelta;
				vo.snapGap=1;
				vo.snapGapEdge=gapEdge;
				vo.snapGapSize=gapSize;
				cnt++;
			}else{
				vo.snapGap=0;
				vo.snapGapSize=0;
			}
			vo.edges=flag;
			return delta;
		}
		return 0;
	};
	
	//------------------------------------------------------------------------
	//Find H snap line:
	__Proto.findSnapY=function(vo){
		let line1,line2,line3,gap1,gap2,gap3;
		let minPosDelta,pos,cnt,delta,minDelta;
		let minGapDelta,gapDelta,gapSize,gapEdge;
		let minSizeDelta,sizeDelta,sizeSize;
		let flag=0;
		var hud=this.hudObj;
		let y=this.y;

		//Factors from vo:
		let lineList=vo.snapLines;
		let gap=vo.checkGap;
		let edgeFlags=vo.edgeFlags;
		let boxDyFactor=vo.boxDyFactor;
		let boxDhFactor=vo.boxDhFactor;
		//let boxDyFactor=vo.boxDyFactor;
		//let boxDhFactor=vo.boxDhFactor;

		//Find edge align location:
		gap3=gap2=gap1=100000;
		minPosDelta=minGapDelta=minSizeDelta=100000;
		if(edgeFlags){
			if(edgeFlags&EDGE_TOP){
				[line1,gap1] = CdySnapLine.locateLineY(y[0], 0, gap, hud);
			}
			if(edgeFlags&EDGE_MIDY){
				[line2,gap2] = CdySnapLine.locateLineY(y[1], 1, gap, hud);
			}
			if(edgeFlags&EDGE_BOTTOM){
				[line3,gap3] = CdySnapLine.locateLineY(y[2], 2, gap, hud);
			}
		}
		minPosDelta=gap1<gap2?(gap3<gap1?gap3:gap1):(gap3<gap2?gap3:gap2);
		//Find gap snap delta:
		{
			[gapSize,gapDelta,gapEdge]=CdySnapLine.locateGapY(this,gap,edgeFlags);
			if(gapSize){
				minGapDelta=gapDelta>0?gapDelta:-gapDelta;
			}
		}
		//Find size snap delta:
		if(edgeFlags&EDGE_SIZEH && vo.boxDhFactor){
			[sizeSize,sizeDelta]=CdySnapLine.locateSizeY(this,gap,edgeFlags);
			if(sizeSize){
				minSizeDelta=sizeDelta>0?sizeDelta:-sizeDelta;
			}
		}
		minDelta=minPosDelta<minGapDelta?(minPosDelta<minSizeDelta?minPosDelta:minSizeDelta):(minGapDelta<minSizeDelta?minGapDelta:minSizeDelta);
		if(minDelta<gap){
			if(minPosDelta===minDelta){
				cnt=0;
				if(line1 && gap1===minPosDelta){
					pos=line1.pos;
					delta=(pos-y[0]);
					cnt++;
					flag|=EDGE_LEFT;
					vo.snaped=1;
					vo.snapPos=1;
					vo.dy=delta;
					vo.snapPoses.push(pos);
				}
				if(line2 && gap2===minPosDelta){
					pos=line2.pos;
					vo.snapPoses.push(pos);
					if(!cnt){
						delta=(pos-y[1]);
						cnt++;
						flag|=EDGE_MIDX;
						vo.snapPos=1;
						vo.snaped=1;
						vo.dy=delta;
					}
				}
				if(line3 && gap3===minPosDelta){
					pos=line3.pos;
					vo.snapPoses.push(pos);
					if(!cnt){
						delta=(pos-y[2]);
						cnt++;
						flag|=EDGE_RIGHT;
						vo.snaped=1;
						vo.snapPos=1;
						vo.dy=delta;
					}
				}
			}else{
				vo.snapPos=0;
			}
			if(minSizeDelta===minDelta){
				flag=EDGE_SIZEH;
				vo.snaped=1;
				vo.snapSize=1;
				vo.snapSizeSize=sizeSize;
				vo.dy=sizeDelta/vo.boxDhFactor;
				cnt++;
			}else{
				vo.snapSize=0;
				vo.snapSizeSize=0;
			}
			if(minGapDelta===minDelta){
				vo.snaped=1;
				vo.dy=gapDelta;
				vo.snapGap=1;
				vo.snapGapEdge=gapEdge;
				vo.snapGapSize=gapSize;
				cnt++;
			}else{
				vo.snapGap=0;
				vo.snapGapSize=0;
			}
			vo.edges=flag;
			return delta;
		}
		return 0;
	};//Synced

	//------------------------------------------------------------------------
	//Generate align lines:
	__Proto.buildLines=function(){
		CdySnapLine.allocLine(this, 0, 0);
		CdySnapLine.allocLine(this, 0, 1);
		CdySnapLine.allocLine(this, 0, 2);

		CdySnapLine.allocLine(this, 1, 0);
		CdySnapLine.allocLine(this, 1, 1);
		CdySnapLine.allocLine(this, 1, 2);
	};
	
	//------------------------------------------------------------------------
	//Show the box:
	__Proto.show=function(){
		let div,style,webObj;
		if(this.lineT){
			//Already showing:
			return;
		}
		webObj=baseHud.webObj;
		//Top:
		div=CdySnapLine.allocEdgeDiv();
		this.lineT=div;
		style=div.style;
		style.left=(this.x[0]-10-baseHudX)+"px";
		style.width=(this.x[2]-this.x[0]+20)+"px";
		style.top=(this.y[0]-baseHudY)+"px";
		style.height="1px";
		webObj.appendChild(div);

		//Bottom:
		div=CdySnapLine.allocEdgeDiv();
		this.lineB=div;
		style=div.style;
		style.left=(this.x[0]-10-baseHudX)+"px";
		style.width=(this.x[2]-this.x[0]+20)+"px";
		style.top=(this.y[2]-baseHudY)+"px";
		style.height="1px";
		webObj.appendChild(div);

		//Left:
		div=CdySnapLine.allocEdgeDiv();
		this.lineL=div;
		style=div.style;
		style.left=(this.x[0]-baseHudX)+"px";
		style.width="1px";
		style.top=(this.y[0]-10-baseHudY)+"px";
		style.height=(this.y[2]-this.y[0]+20)+"px";
		webObj.appendChild(div);

		//Right:
		div=CdySnapLine.allocEdgeDiv();
		this.lineR=div;
		style=div.style;
		style.left=(this.x[2]-baseHudX)+"px";
		style.width="1px";
		style.top=(this.y[0]-10-baseHudY)+"px";
		style.height=(this.y[2]-this.y[0]+20)+"px";
		webObj.appendChild(div);
	};
}

export {CdySnapBox,CdySnapLine};