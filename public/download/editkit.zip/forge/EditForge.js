import {EditAttr} from "../EditAttr.js";
import {EditPrj} from "../EditPrj.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {ForgeSelBox,ForgeHotBox,forgeHotBox} from "./ToolBox.js";
import {callAfter} from "/@events";
import {CdySnapBox,CdySnapLine} from "./SnapBox.js";
import {DLGCreateHud} from "../ui/DLGCreateHud.js";

var editApp=null;
var EditForge,editForge;//Class
var naviView=null;
var infoView=null;
var hudForge=null;//The UIForge Hud-object
var boxScroll=null;
var boxDevice=null;//The device box
var deviceBG=null;//The device background
var imgChecker=false;//Show check background
var boxGear=null;//The UI parent node
var boxNotes=null;//The notes root node
var boxHelpers=null;//The helper root node
var boxLines=null;//The lines
var boxNewHud=null;//The drag-new-hud box:
var boxNewHudOwner=null;//The owner out-line box 
var boxRangeSel=null;//The range select box:
var dataPrj=null;
var editPrj=null;
var dataDoc=null;//The editing doc
var editDoc=null;
var editDocHud=null;//The doc's gear's EditHudObj
var gearLiveObj=null;//The doc's gear's EditHudObj's liveEdObj

var naviBox=null;//The TBXNaviDoc

let isDraging=false;//Is now dragging?
let targetHud=null;//Current new hud-add-owner hud

var isHotEditing=false;//Is doing hot-online-edit
var hotEdHudObj=null;//Current focused editHudObj
var hotGearSlot=null;//Current focused gearSlot
var willSyncNavi=false;
var lockSelect=false;//If lock selected item(s)
var isRangeSel=false;//If current mouse move is range select
var selMarkId=1;//If an HudObj's selMarkId eq this value, it's selected.
var rangeSelMode=0;//0: intersect, 1: contain
var rangeSelOrgObjs=null;//If not null, will be list of org selected objs on start range select.

const ADDPLACE_TOP=0;
const ADDPLACE_CHILD=1;

const SNAPMODE_OFF=0;
const SNAPMODE_AUTO=1;
const SNAPMODE_OBJ=2;
const SNAP_GAP1=2;
const SNAP_GAP2=5;

const ACTION_SELECT=0;
const ACTION_CREATE=1;
const ACTION_SKETCH=2;

const EDGE_LEFT=1;
const EDGE_MIDX=2;
const EDGE_RIGHT=4;
const EDGE_TOP=8;
const EDGE_MIDY=16;
const EDGE_BOTTOM=32;
const EDGE_SIZEW=64;
const EDGE_SIZEH=128;

var isMouseDown=false;
var hotSnapBox,snapXLines,snapObjBoxes,snapXEdgeFlg,snapYLines,snapYBoxFlg;
let snapCheckVO={edges:0,delta:null};
let snapXDPos,snapYDPos,snapBoxDx,snapObjDx,snapBoxDw,snapObjDw,snapBoxDy,snapObjDy,snapBoxDh,snapObjDh;
let curSnapGapX=0,curSnapGapY=0;
var excludeSnapPosX=new Set();
var excludeSnapPosY=new Set();
var excludeTargetHud=new Set();

const liveSelBoxes=ForgeSelBox.liveBoxes;
//Functions:
let checkPick;
let pickSelHudObj;
//****************************************************************************
EditForge=function(uiForge){
	var self=this;
	if(hudForge){
		throw new Error(`EditForge can have only one instance!`);
	}
	this.zoom=1;
	this.addPlace=ADDPLACE_TOP;
	this.snapMode=SNAPMODE_AUTO;
	this.actMode=ACTION_SELECT;
	this.drawSnap=false;
	this.drawSnapSize=5;

	EditForge.instance=this;
	EditPrj.theForge=this;
	editApp=uiForge.app;
	naviView=editApp.naviView;
	infoView=editApp.infoView;
	dataPrj=editApp.prj;
	editPrj=dataPrj.codyPrj;
	editPrj.theForge=this;
	hudForge=uiForge;
	boxScroll=hudForge.BoxScroll;
	boxDevice=hudForge.BoxDevice;
	boxGear=hudForge.BoxGear;
	boxNotes=hudForge.BoxNotes;
	boxHelpers=hudForge.BoxHelpers;
	boxLines=hudForge.BoxLines;
	deviceBG=hudForge.BoxDeviceBG;
	imgChecker=hudForge.ImgChecker;
	boxNewHud=hudForge.BoxNewHud;
	boxNewHudOwner=hudForge.BoxNewHudOwner;
	boxRangeSel=hudForge.BoxRangeSel;
	ForgeSelBox.setForge(this);
	
	function syncSelects(){
		if(!willSyncNavi){
			callAfter(()=>{
				self.syncNaviSelects();
			});
			willSyncNavi=1;
		}
	}
	
	editPrj.on("EditSubObj",syncSelects);
	editPrj.on("SelectSubObj",syncSelects);
	editPrj.on("SelectSubObjList",syncSelects);
	
	//Add events:
	boxScroll.webObj.addEventListener("mousedown",(e)=>{self.OnMouseDown(e);});
	boxScroll.webObj.addEventListener("mousemove",(e)=>{self.OnMouseMove(e);},true);
	boxScroll.webObj.addEventListener("mouseup",(e)=>{self.OnMouseUp(e);},true);
	
	this.OnFaceOn=this._OnFaceOn.bind(this);
	this.OnFaceOff=this._OnFaceOff.bind(this);
};
editForge=EditForge.prototype={};

//----------------------------------------------------------------------------
editForge.clear=function(){
	let state;
	if(!dataDoc){
		return;
	}

	//Keep edit state:
	state=editDoc.forgeState;
	state.zoom=this.zoom;
	state.devicePos[0]=boxDevice.x;
	state.devicePos[1]=boxDevice.y;
	
	//Ensure exit face-edit
	editDoc.exitFaceEdit();

	editDoc.offNotify("DeviceChanged",this.updateDevice);

	if(editDocHud){
		gearLiveObj=editDocHud.liveEdObj;
		if(gearLiveObj){
			editDocHud.dropLiveObj(gearLiveObj);
		}
	}
	//Reset tool boxes:
	ForgeSelBox.clear();
	forgeHotBox.unbind();

	
	dataDoc=null;
	editDocHud=null;
	gearLiveObj=null;
	
	isMouseDown=false;
	
	//Reset tool boxes andlines:
	boxGear.clearChildren();
	boxNotes.clearChildren();
	boxHelpers.clearChildren();//TODO: recycle items?
	boxLines.clearChildren();//TODO: recycle items?
};

//----------------------------------------------------------------------------
editForge.startEdit=function(doc){
	let css,self,state;
	self=this;
	this.clear();
	dataDoc=doc;
	editDoc=doc.editDoc||doc.codyDoc;
	this.updateDevice();
	editDocHud=editDoc.hudObj;
	css=editDoc.genHudCSS();
	gearLiveObj=boxGear.appendNewChild(css);
	editDocHud.bindLiveObj(gearLiveObj);
	this.maybeSyncSelects();
	editDoc.onNotify("DeviceChanged",this.updateDevice);
	editDoc.on("FaceOn",this.OnFaceOn);
	editDoc.on("FaceOff",this.OnFaceOff);
	
	if(editDoc.curFaceTag){
		hudForge.showFace("FaceOn");
	}else{
		hudForge.showFace("FaceOff");
	}
	
	state=editDoc.forgeState;
	boxDevice.x=state.devicePos[0];
	boxDevice.y=state.devicePos[1];
	self.setZoom(state.zoom||1);
	naviBox=EditPrj.boxNaviDoc;
	//Ensure dataDock is focused by editApp:
	editApp.setFocusBox(editApp.mainUI);
};

//****************************************************************************
//Edit device related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editForge.updateDevice=function(){
		let cfg,w,h;
		cfg=editDoc.editEnv;
		w=editDoc.scrW.val;
		h=editDoc.scrH.val;
		boxDevice.w=w;
		boxDevice.h=h;
		boxGear.w=w;
		boxGear.h=h;
		deviceBG.style.background=`rgba(${editDoc.bgColor.val})`;
		imgChecker.display=!!editDoc.bgChecker.val;
	};
	
	//------------------------------------------------------------------------
	editForge.setZoom=function(zoom){
		this.zoom=zoom;
		boxDevice.scale=zoom;
		boxLines.scale=boxHelpers.scale=1.0/zoom;
		ForgeSelBox.clear();
		forgeHotBox.unbind();
		this.maybeSyncSelects(true);
	};
}

//****************************************************************************
//:Tool box related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editForge.lockSelect=function(lock){
		lockSelect=lock;
	};
	
	//------------------------------------------------------------------------
	editForge.maybeSyncSelects=function(){
		if(willSyncNavi){
			return;
		}
		willSyncNavi=1;
		callAfter(()=>{
			this.syncNaviSelects();
		});
	};
	
	//------------------------------------------------------------------------
	editForge.syncNaviSelects=function(force=false){
		let treeBox,list,node,edHud,hotHud;
		if(!dataDoc){
			willSyncNavi=0;
			return;
		}
		if(!willSyncNavi && !force){
			return;
		}
		selMarkId++;
		if(selMarkId>6553600){
			selMarkId=-6553600
		}
		willSyncNavi=0;
		//Reset boxes:
		ForgeSelBox.clear();
		forgeHotBox.unbind();

		naviBox=EditPrj.boxNaviDoc;
		if(naviBox){
			treeBox=naviBox.treeBox;
			hotHud=treeBox.hotNode&&treeBox.hotNode.nodeObj;
			list = treeBox.selected;
			for(node of list){
				edHud=node.nodeObj;
				if(edHud!==hotHud && edHud.liveEdObj){
					ForgeSelBox.addBox(edHud,boxHelpers);
				}
				edHud.selMarkId=selMarkId;
			}
		}
		if(!hotHud){
			hotHud=editPrj.curEditSubObj;
		}
		if(hotHud){
			if(hotHud.isHudObj){
				hotEdHudObj=hotHud;
				hotGearSlot=null;
				forgeHotBox.bindToObj(hotHud,boxHelpers);
			}else if(hotHud.isGearSlot){
				hotEdHudObj=null;
				hotGearSlot=hotHud;				
				forgeHotBox.bindToObj(hotHud,boxHelpers);
			}else{
				hotEdHudObj=null;
				hotGearSlot=null;
			}
		}else{
			hotEdHudObj=null;
			hotGearSlot=null;
		}
	};
}

//****************************************************************************
//:Snap related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editForge.setSnapMode=function(mode){
		let box;
		CdySnapLine.resetBuff(boxLines,boxDevice);
		snapObjBoxes=snapObjBoxes?snapObjBoxes:[];
		for(box of snapObjBoxes) {
			CdySnapBox.freeBox(box);
		}
		snapObjBoxes.splice(0);
		switch(mode){
			case 0:
				this.snapMode=SNAPMODE_OFF;
				return 0;
			case 1:
				this.snapMode=SNAPMODE_AUTO;
				return 1;
			case 2: {
				let selBoxes,selBox,hud;
				if(forgeHotBox){
					hud=forgeHotBox.editHudObj;
					if(hud){
						box = CdySnapBox.allocBox(hud, 0);
						if(box) {
							snapObjBoxes.push(box);
							box.show();
						}
					}
				}
				selBoxes=ForgeSelBox.getLiveBoxes();
				for(selBox of selBoxes){
					hud=selBox.editHudObj;
					box = CdySnapBox.allocBox(hud, 0);
					if(box) {
						snapObjBoxes.push(box);
						box.show();
					}
				}
				this.snapMode=SNAPMODE_OBJ;
				//TODO: Code this:
				return 2;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editForge.buildSnaps=function(){
		let mode;
		mode=this.snapMode;//0: No snap; 1: Auto snap; 2:Snap to selected items

		//--------------------------------------------------------------------
		//Add a snap target:
		function addSnap(hud,isOwner=false){
			if(hud===hotEdHudObj){
				return;
			}
			if(hud.selMarkId===selMarkId){
				return;
			}
			if(!hud.liveEdObj || !hud.liveEdObj.webObj || !hud.liveEdObj.webObj.offsetParent){
				//We don't snap to hidden items
				return;
			}
			CdySnapBox.allocBoxLine(hud,isOwner);
		}

		function addParentSnap(hud,addSub){
			var pHud;
			pHud=hud.owner;
			while(pHud && !(pHud instanceof EditHudObj)){
				pHud=pHud.owner;
			};
			if(pHud){
				addSnap(pHud,true);
				if(addSub){
					//Add children items
					pHud.runOnSubHuds((subHud)=>{
						addSnap(subHud,false);
					});
				}
				if(pHud!==editDocHud){
					addParentSnap(pHud,0);
				}
			}
		}

		if(mode===0){
			//No-snap:
			CdySnapLine.resetBuff(boxLines,boxDevice);
		}else if(mode===1){
			//Auto-snap
			CdySnapLine.resetBuff(boxLines,boxDevice);
			if(hotEdHudObj){
				addParentSnap(hotEdHudObj,1);
			}
			//TODO: Add device snap-box:
			CdySnapBox.allocDeviceBoxLine(boxDevice);
		}else if(mode===2){
			let box;
			CdySnapLine.resetBuff(boxLines,boxDevice);
			for(box of snapObjBoxes) {
				//addSnap(box.hudObj);
				box.buildLines();
			}
		}
		snapXLines=[];
		snapYLines=[];
		snapXEdgeFlg=0;
		snapYBoxFlg=[0,0,0];
		CdySnapLine.commitBuff();
		excludeSnapPosX.clear();
		excludeSnapPosY.clear();
	};
		
}

//****************************************************************************
//:Edit by mouse:
//****************************************************************************
{
	//Pickup-mode:
	const PICKMODE_STD=0;
	const PICKMODE_CHANGE=1;
	const PICKMODE_TOP=2;
	
	//Mouse-Action-Mode:
	const MouseACT_NONE=-1;
	const MouseACT_MOVEBG=0;
	const MouseACT_MOVEOBJ=1;
	const MouseACT_SIZETL=2;
	const MouseACT_SIZETR=3;
	const MouseACT_SIZEBL=4;
	const MouseACT_SIZEBR=5;
	const MouseACT_RANGESELECT=6;
	const MouseACT_SIZET=7;
	const MouseACT_SIZEB=8;
	const MouseACT_SIZEL=9;
	const MouseACT_SIZER=10;
	
	const MouseMoveGap=3;
	
	var isMouseDownSame=false;
	var mouseDownTool=null;
	var mouseDownX,mouseDownY;
	let mouseDownOX,mouseDownOY;
	var lastMouseDownX=0;
	var lastMouseDownY=0;
	var lastMouseDownTime=0;
	var mouseDownShiftKey=false;
	var mouseDownMetaKey=false;
	var mouseDownAltKey=false;
	var mouseAct=null;
	var isMouseMoved=false;
	var mouseMoveOrgX=0;
	var mouseMoveOrgY=0;
	var mouseMoveBGOrgX=0;
	var mouseMoveBGOrgY=0;
	var rangeDragOX=0;
	var rangeDragOY=0;
	let pickTarget=false;
	let moveTargetBoxes=null;
	
	//------------------------------------------------------------------------
	editForge.setRangeSelMode=function(mode){
		rangeSelMode=mode?1:0;
	};

	//------------------------------------------------------------------------
	editForge.OnMouseDown=function(e){
		let time,curHot,edHudObj,liveObj,boxDiv;

		if(e.button==2){
			//If dragging, canel it:
			if(isDraging){
				this.cancelDrag();
			}else if(isMouseDown){
				this.cancelMouseMove();
			}
			return;
		}
		
		if(isMouseDown){
			return;
		}
		if(isHotEditing){
			return;
		}
		
		//Ensure dataDock is focused by editApp:
		editApp.setFocusBox(editApp.mainUI);
		if(e.button!==0){
			return;
		}

		time=Date.now();
		isMouseDown=true;
		isMouseMoved=false;
		isRangeSel=false;
		
		//--------------------------------------------------------------------
		//Draw to create item?
		if(this.actMode===ACTION_CREATE){
			let rect,ox,oy,ow,oh,curObj;
			boxRangeSel.display=1;
			mouseDownX=e.x;
			mouseDownY=e.y;
			rect=hudForge.getBoundingClientRect();
			rangeDragOX=Math.round(rect.x);
			rangeDragOY=Math.round(rect.y);
			boxRangeSel.x=mouseDownX-rangeDragOX;
			boxRangeSel.y=mouseDownY-rangeDragOY;
			boxRangeSel.w=0;
			boxRangeSel.h=0;
			targetHud=null;
			//Clear selections:
			rangeSelOrgObjs=null;
			editPrj.setEditSubObj(null);
			editPrj.selectEditSubObjList([]);
			rect=hudForge.getBoundingClientRect();
			mouseDownOX=Math.round(rect.x);
			mouseDownOY=Math.round(rect.y);
			
			if(this.addPlace===ADDPLACE_TOP){
				curObj=editDocHud;
				pickTarget=true;
			}else{
				curObj=hotEdHudObj||editDocHud;
				pickTarget=false;
			}
			if(!curObj){
				return false;
			}
			if(!curObj.isHudObj){
				//TODO: notify user
				return false;
			}
			if(curObj.objDef.naviHasSub===false){
				do{
					curObj=curObj.owner;
				}while(curObj && ((!curObj.isHudObj) || (curObj.objDef.naviHasSub===false)));
				if(!curObj){
					//TODO: notify user
					return false;
				}
			}
			targetHud=curObj;
			rect=targetHud.liveEdObj.getBoundingClientRect();
			ox=rect.left;oy=rect.top;
			ow=rect.width;oh=rect.height;
			ox -= mouseDownOX;
			oy -= mouseDownOY;
			boxNewHudOwner.display=1;
			boxNewHudOwner.x=ox-3;
			boxNewHudOwner.y=oy-3;
			boxNewHudOwner.w=ow+6;
			boxNewHudOwner.h=oh+6;
			return;
		}

		//--------------------------------------------------------------------
		//Click to select or move:
		mouseAct=MouseACT_NONE;
		mouseDownTool=forgeHotBox.pickTool(e);
		if(mouseDownTool){
			let rect;
			edHudObj=forgeHotBox.editHudObj;
			boxDiv=forgeHotBox.boxDiv;
			liveObj=edHudObj.liveEdObj;
			isMouseDownSame=false;
			isMouseMoved=1;
			mouseMoveOrgX=mouseDownX=e.x;
			mouseMoveOrgY=mouseDownY=e.y;
			mouseAct=mouseDownTool.mouseAct;
			forgeHotBox.moveOrgObjX=liveObj.x;
			forgeHotBox.moveOrgObjY=liveObj.y;
			/*forgeHotBox.moveOrgPS=liveObj.position;
			if(forgeHotBox.moveOrgPS!=="absolute"){
				liveObj.position="absolute";
				liveObj.x=forgeHotBox.moveOrgObjX;
				liveObj.y=forgeHotBox.moveOrgObjY;
			}*/
			forgeHotBox.moveOrgObjW=liveObj.w;
			forgeHotBox.moveOrgObjH=liveObj.h;
			forgeHotBox.moveOrgBoxX=boxDiv.offsetLeft;
			forgeHotBox.moveOrgBoxY=boxDiv.offsetTop;
			forgeHotBox.moveOrgBoxW=boxDiv.clientWidth;
			forgeHotBox.moveOrgBoxH=boxDiv.clientHeight;
			forgeHotBox.moveFactorX=null;
			forgeHotBox.moveFactorY=null;
			rect=liveObj.webObj.getBoundingClientRect();
			forgeHotBox.moveOrgObjBDX=Math.round(rect.x);
			forgeHotBox.moveOrgObjBDY=Math.round(rect.y);
			//TODO: clicked on a control-tool, follow the tools' act-mode
			if(editDoc.curFaceTag){
				isMouseDown=false;
			}
			hotSnapBox=CdySnapBox.allocBox(hotEdHudObj,0);
			moveTargetBoxes=null;
			this.buildSnaps();
		}else{
			mouseDownX=e.x;
			mouseDownY=e.y;
			if(naviBox){
				if(!naviBox.isShowing()){
					//TODO: Code this:
					//editApp.mainUI.showNaviBox("editDoc");
				}
			}
			
			FindSelect:{
				isMouseDownSame=0;
				if(e.shiftKey){//Range select:
					let rect;
					isRangeSel=true;
					boxRangeSel.display=1;
					rect=hudForge.getBoundingClientRect();
					rangeDragOX=Math.round(rect.x);
					rangeDragOY=Math.round(rect.y);
					boxRangeSel.x=mouseDownX-rangeDragOX;
					boxRangeSel.y=mouseDownY-rangeDragOY;
					boxRangeSel.w=0;
					boxRangeSel.h=0;
					if(e.metaKey || e.ctrlKey){
						rangeSelOrgObjs=null;
						rangeSelOrgObjs=naviBox.getSelectedObjsList();
						editPrj.setEditSubObj(null);
						editPrj.selectEditSubObjList(rangeSelOrgObjs);
					}else{
						rangeSelOrgObjs=null;
						editPrj.setEditSubObj(null);
						editPrj.selectEditSubObjList([]);
					}
					
				}else if(e.metaKey||e.ctrlKey){//Will add more to select:
					edHudObj=this.pickOneEditHud(e,PICKMODE_TOP);
					if(hotEdHudObj && edHudObj!==hotEdHudObj && lockSelect){
						editApp.showStateText("Selection is locked");
					}else if(edHudObj){
						editPrj.selectEditSubObj(edHudObj);
						naviView.showView("NaviDoc");
						infoView.showView("EditObj");
					}
					isMouseDown=false;
				}else if(e.altKey){
					edHudObj=this.pickOneEditHud(e,PICKMODE_CHANGE);
					if(hotEdHudObj && edHudObj!==hotEdHudObj && lockSelect){
						editApp.showStateText("Selection is locked");
					}else{
						if(edHudObj){
							if(edHudObj!==hotEdHudObj){
								editPrj.setEditSubObj(edHudObj);
								naviView.showView("NaviDoc");
								infoView.showView("EditObj");
							}
						}else{
							editPrj.setEditSubObj(editDoc.editEnv||null);
							naviView.showView("NaviDoc");
						}
					}
					isMouseDown=false;
				}else{
					curHot=hotEdHudObj||hotGearSlot;
					if(mouseDownX===lastMouseDownX && mouseDownY===lastMouseDownY){//Click at same position, double clike to start hotEdit or loop selection:
						if(time-lastMouseDownTime<500 && hotEdHudObj){//Double clicked, maybe start text edit?
							let objDef=hotEdHudObj.objDef;
							let attr=objDef.majorEditAttr;
							let attrBox;
							
							if(attr){
								attr=hotEdHudObj.properties.getAttr(attr);
								if(attr.def.hotOnlineEdit){
									//Start hot-online-edit mode
									if(attr.valText.startsWith("#")||attr.valText.startsWith("${")){
										attrBox=EditPrj.boxObjAttr;
										if(attrBox){
											attrBox.editAttr(attr);
										}
									}else{
										this.startHotLineEdit(attr);
									}
								}else{
									attrBox=EditPrj.boxEditObj;
									if(attrBox){
										if(attrBox.isFocused){
											attrBox.startEditAttr(attr);
										}else{
											infoView.showView("EditObj").then(view=>{
												view.startEditAttr(attr);
											});
										}
									}else{
										infoView.showView("EditObj").then(view=>{
											view.startEditAttr(attr);
										});
									}
								}
								lastMouseDownTime=time;
								isMouseDown=false;
								return;
							}
							attr=objDef.majorEditArg;
							if(attr){
								attr=hotEdHudObj.createArgs.getAttr(attr);
								if(attr.def.hotOnlineEdit){
									//Start hot-online-edit mode
									if(attr.valText.startsWith("#")||attr.valText.startsWith("${")){
										attrBox=EditPrj.boxEditObj;
										if(attrBox){
											attrBox.startEditAttr(attr);
										}
									}else{
										this.startHotLineEdit(attr);
									}
								}else{
									attrBox=EditPrj.boxObjAttr;
									if(attrBox){
										attrBox.startEditAttr(attr);
									}
								}
							}
							lastMouseDownTime=time;
							isMouseDown=false;
							return;
						}else{//Not dobule click: 
							if(time-lastMouseDownTime<2000){//loop between comoponents:
								edHudObj=this.pickOneEditHud(e,PICKMODE_CHANGE);
								if(curHot && edHudObj!==curHot && lockSelect){
									editApp.showStateText("Selection is locked");
								}else{
									if(edHudObj){
										if(edHudObj!==hotEdHudObj){
											editPrj.setEditSubObj(edHudObj);
											naviView.showView("NaviDoc");
											infoView.showView("EditObj");
										}
									}else{
										editPrj.setEditSubObj(editDoc.editEnv||null);
										naviView.showView("NaviDoc");
									}
								}
								//isMouseDown=false;
							}else{
								edHudObj=this.pickOneEditHud(e,PICKMODE_TOP);
							}
						}
					}else{//Click at new pos, select top element:
						if(hotEdHudObj && checkPick(e,hotEdHudObj)){
							isRangeSel=false;
							isMouseDown=true;
							isMouseDownSame=1;
							edHudObj=hotEdHudObj;
						}else{
							edHudObj=pickSelHudObj(e);
							if(edHudObj){
								editPrj.selectEditSubObj(edHudObj,true);
								naviView.showView("NaviDoc");
								infoView.showView("EditObj");
								break FindSelect;
							}else{
								edHudObj=this.pickOneEditHud(e,PICKMODE_TOP);
							}
						}
					}
					if(curHot && edHudObj!==curHot && lockSelect){
						if(!this.checkPick(e,curHot)){
							editApp.showStateText("Selection is locked");
							isMouseDown=false;
						}
					}else if(edHudObj){
						if(edHudObj!==hotEdHudObj){
							editPrj.setEditSubObj(edHudObj);
							naviView.showView("NaviDoc");
							infoView.showView("EditObj");
							this.maybeSyncSelects();
						}
					}else{
						editPrj.setEditSubObj(editDoc.editEnv||null);
						naviView.showView("NaviDoc");
						this.maybeSyncSelects();
					}
				}
			}
			lastMouseDownTime=time;
			lastMouseDownX=mouseDownX;
			lastMouseDownY=mouseDownY;
			if(editDoc.curFaceTag){
				isMouseDown=false;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editForge.OnMouseMove=function(e){
		let x,y,dx,dy,dw,dh,adx,ady,box,n,liveObj;
		let snapW,snapH;
		let self=this;
		
		if(!isMouseDown)
			return;
		x=e.x;y=e.y;
		//Create by drag:
		if(this.actMode===ACTION_CREATE){
			let dx,dy,ox,oy,w,h;
			let selList;
			dx=x-mouseDownX;
			dy=y-mouseDownY;
			if(dx<0){
				ox=x-rangeDragOX;
				w=-dx;
			}else{
				ox=mouseDownX-rangeDragOX;
				w=dx;
			}
			if(dy<0){
				oy=y-rangeDragOY;
				h=-dy;
			}else{
				oy=mouseDownY-rangeDragOY;
				h=dy;
			}
			if(this.drawSnap){
				let snap=this.drawSnapSize;
				w=Math.round(w/snap)*snap;
				h=Math.round(h/snap)*snap;
			}
			boxRangeSel.x=ox;
			boxRangeSel.y=oy;
			boxRangeSel.w=w;
			boxRangeSel.h=h;
			//highlight owner item:
			if(pickTarget){
				let newTgt,fakeE;
				fakeE={x:mouseDownX+dx*0.5,y:mouseDownY+dy*0.5}
				newTgt=this.pickContainer(fakeE)||editDocHud;
				if(newTgt!==targetHud){
					let webObj,rect,ox,oy,ow,oh;
					targetHud=newTgt;
					webObj=newTgt.liveEdObj.webObj;
					rect=webObj.getBoundingClientRect();
					ox=rect.left;oy=rect.top;
					ow=rect.width;oh=rect.height;

					ox -= mouseDownOX;
					oy -= mouseDownOY;
					boxNewHudOwner.x=ox-3;
					boxNewHudOwner.y=oy-3;
					boxNewHudOwner.w=ow+6;
					boxNewHudOwner.h=oh+6;
					if(naviBox){
						naviBox.setTargetObj(targetHud);
					}
				}
			}
			hudForge.BoxTip.display=1;
			if(targetHud){
				ox=boxRangeSel.x-boxNewHudOwner.x;
				oy=boxRangeSel.y-boxNewHudOwner.y;
				if(this.drawSnap){
					let snap=this.drawSnapSize;
					ox=Math.round(ox/snap)*snap;
					oy=Math.round(oy/snap)*snap;
				}
				hudForge.TxtMoveTip.text=`(x: ${ox}, y: ${oy}) (w: ${w}, h: ${h})`;
			}else{
				hudForge.TxtMoveTip.text=`(w: ${w}, h: ${h})`;
			}
			return;
		}
		//Range select:
		if(isRangeSel){
			let dx,dy,ox,oy,w,h;
			let selList;
			dx=x-mouseDownX;
			dy=y-mouseDownY;
			if(dx<0){
				ox=x-rangeDragOX;
				w=-dx;
			}else{
				ox=mouseDownX-rangeDragOX;
				w=dx;
			}
			if(dy<0){
				oy=y-rangeDragOY;
				h=-dy;
			}else{
				oy=mouseDownY-rangeDragOY;
				h=dy;
			}
			boxRangeSel.x=ox;
			boxRangeSel.y=oy;
			boxRangeSel.w=w;
			boxRangeSel.h=h;

			selList=this.pickRange(ox+rangeDragOX,oy+rangeDragOY,w,h);
			//Check Meta-Select:
			if(rangeSelOrgObjs){
				let obj,index,orgList,newList=[];
				for(obj of rangeSelOrgObjs){
					index=selList.indexOf(obj);
					if(index>=0){
						selList.splice(index,1);
					}else{
						newList.push(obj);
					}
				}
				editPrj.selectEditSubObjList(newList.concat(selList));
			}else{
				editPrj.selectEditSubObjList(selList);
			}
			return;
		}
		//About drag to move:
		if(!isMouseMoved){
			dx=x-mouseDownX;
			dy=y-mouseDownY;
			adx=dx<0?-dx:dx;
			ady=dy<0?-dy:dy;
			if(adx>MouseMoveGap||ady>MouseMoveGap){
				isMouseMoved=true;
				mouseMoveOrgX=x;
				mouseMoveOrgY=y;
				if(hotEdHudObj && hotEdHudObj.liveEdObj){
					moveTargetBoxes=ForgeSelBox.buildMoveTargets();
					n=moveTargetBoxes.length;
					if(n){
						let div,obj,webObj,rect;
						mouseAct=MouseACT_MOVEOBJ;
						for(box of moveTargetBoxes){
							div=box.boxDiv;
							box.moveOrgBoxX=box.moveCurBoxX=div.offsetLeft;
							box.moveOrgBoxY=box.moveCurBoxY=div.offsetTop;
							box.moveOrgBoxW=div.clientWidth;
							box.moveOrgBoxH=div.clientHeight;
							if(box.willMoveObj){
								obj=box.editHudObj.liveEdObj;
								box.moveOrgObjX=obj.x;
								box.moveOrgObjY=obj.y;
								box.moveOrgObjW=obj.W;
								box.moveOrgObjH=obj.H;
								webObj=obj.webObj;
								rect=webObj.getBoundingClientRect();
								box.moveOrgObjBDX=Math.round(rect.x);
								box.moveOrgObjBDY=Math.round(rect.y);
								box.moveFactorX=null;
								box.moveFactorY=null;
							}
						}
						if(n>1){
							hotSnapBox=CdySnapBox.allocBox(null,0);
							for(box of moveTargetBoxes){
								if(box.willMoveObj){
									hotSnapBox.mergeHud(box.editHudObj,false);
								}
							}
							hotSnapBox.mergeEnd(true);
							this.buildSnaps();
						}else{
							if(hotEdHudObj){
								hotSnapBox=CdySnapBox.allocBox(hotEdHudObj,0);
								this.buildSnaps();
							}
							box=forgeHotBox;
							if(box && box.editHudObj){
								liveObj=hotEdHudObj.liveEdObj;
								hudForge.BoxTip.display=1;
								hudForge.TxtMoveTip.text=`(x: ${liveObj.x}, y: ${liveObj.y}) (w: ${liveObj.w}, h: ${liveObj.h})`;
							}
						}
					}else{
						mouseAct=MouseACT_NONE;
					}
				}else{
					mouseAct=MouseACT_MOVEBG;
					mouseMoveBGOrgX=boxDevice.x;
					mouseMoveBGOrgY=boxDevice.y;
					hudForge.BoxTip.display=1;
					hudForge.TxtMoveTip.text="Moving blueprint.";
					hudForge.TxtSnapTip.display=0;
				}
			}
		}else{//Drag-moving
			let objDx,objDy,objDw,objDh,boxDx,boxDy,boxDw,boxDh;
			let objDxFactor,objDyFactor,objDwFactor,objDhFactor;
			let boxDxFactor,boxDyFactor,boxDwFactor,boxDhFactor;
			let i,n,editHudObj,box;
			let snapCheckXEdges,snapCheckYEdges;
			dx=x-mouseMoveOrgX;
			dy=y-mouseMoveOrgY;
			dw=0;dh=0;
			adx=dx<0?-dx:dx;
			ady=dy<0?-dy:dy;
			if(mouseAct===MouseACT_MOVEBG){
				boxDevice.x=mouseMoveBGOrgX+dx;
				boxDevice.y=mouseMoveBGOrgY+dy;
				return;
			}
			moveTargetBoxes=moveTargetBoxes||ForgeSelBox.buildMoveTargets();
			n=moveTargetBoxes.length;
			if(!n){
				return;
			}
			box=moveTargetBoxes[0];
			editHudObj=box.editHudObj;
			liveObj=editHudObj.liveEdObj;
			switch(mouseAct){
				case MouseACT_MOVEOBJ:{
					if(e.shiftKey){
						if(adx>=ady){
							dy=0;
						}else if(ady>adx){
							dx=0;
						}
					}
					objDxFactor=1;objDyFactor=1;
					objDwFactor=0;objDhFactor=0;
					boxDxFactor=1;boxDyFactor=1;
					boxDwFactor=0;boxDhFactor=0;
					objDw=0;objDh=0;boxDw=0; boxDh=0;
					snapW=0;snapH=0;
					snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_RIGHT;
					snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_BOTTOM;
					break;
				}
				case MouseACT_SIZETL:{
					if(e.shiftKey){
						if(adx>=ady){
							dy=0;
						}else if(ady>adx){
							dx=0;
						}
					}
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 1;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor =-2;
							boxDxFactor = 1;boxDwFactor =-2;
							snapCheckXEdges=EDGE_LEFT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 0;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
					}
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 1;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor =-2;
							boxDyFactor = 1;boxDhFactor =-2;
							snapCheckYEdges=EDGE_TOP|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 0;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=1;snapH=1;
					break;
				}
				case MouseACT_SIZETR:{
					if(e.shiftKey){
						if(adx>=ady){
							dy=0;
						}else if(ady>adx){
							dx=0;
						}
					}
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 0;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor = 2;
							boxDxFactor =-1;boxDwFactor = 2;
							snapCheckXEdges=EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 1;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
					}
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 1;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor =-2;
							boxDyFactor = 1;boxDhFactor =-2;
							snapCheckYEdges=EDGE_TOP|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 0;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=1;snapH=1;
					break;
				}
				case MouseACT_SIZEBL:{
					if(e.shiftKey){
						if(adx>=ady){
							dy=0;
						}else if(ady>adx){
							dx=0;
						}
					}
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 1;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor =-2;
							boxDxFactor = 1;boxDwFactor =-2;
							snapCheckXEdges=EDGE_LEFT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 0;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
					}
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 0;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor = 2;
							boxDyFactor =-1;boxDhFactor = 2;
							snapCheckYEdges=EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 1;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=1;snapH=1;
					break;
				}
				case MouseACT_SIZEBR:{
					if(e.shiftKey){
						if(adx>=ady){
							dy=0;
						}else if(ady>adx){
							dx=0;
						}
					}
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 0;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor = 2;
							boxDxFactor =-1;boxDwFactor = 2;
							snapCheckXEdges=EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 1;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
					}
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 0;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor = 2;
							boxDyFactor =-1;boxDhFactor = 2;
							snapCheckYEdges=EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 1;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=1;snapH=1;
					break;
				}
				case MouseACT_SIZET:{
					boxDxFactor = 0;boxDwFactor = 0;
					objDxFactor = 0;objDwFactor = 0;
					snapCheckXEdges=0;
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 1;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor =-2;
							boxDyFactor = 1;boxDhFactor =-2;
							snapCheckYEdges=EDGE_TOP|EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 0;objDhFactor =-1;
							boxDyFactor = 1;boxDhFactor =-1;
							snapCheckYEdges=EDGE_TOP|EDGE_MIDY|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=0;snapH=1;
					break;
				}
				case MouseACT_SIZEB:{
					boxDxFactor = 0;boxDwFactor = 0;
					objDxFactor = 0;objDwFactor = 0;
					snapCheckXEdges=0;
					switch (liveObj.anchorV) {
						case 0:
							objDyFactor = 0;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 1:
							objDyFactor = 0;objDhFactor = 2;
							boxDyFactor =-1;boxDhFactor = 2;
							snapCheckYEdges=EDGE_TOP|EDGE_BOTTOM|EDGE_SIZEH;
							break;
						case 2:
							objDyFactor = 1;objDhFactor = 1;
							boxDyFactor = 0;boxDhFactor = 1;
							snapCheckYEdges=EDGE_MIDY|EDGE_BOTTOM|EDGE_SIZEH;
							break;
					}
					n=1;
					snapW=0;snapH=1;
					break;
				}
				case MouseACT_SIZEL:{
					boxDyFactor = 0;boxDhFactor = 0;
					objDyFactor = 0;objDhFactor = 0;
					snapCheckYEdges=0;
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 1;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor =-2;
							boxDxFactor = 1;boxDwFactor =-2;
							snapCheckXEdges=EDGE_LEFT|EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 0;objDwFactor =-1;
							boxDxFactor = 1;boxDwFactor =-1;
							snapCheckXEdges=EDGE_LEFT|EDGE_MIDX|EDGE_SIZEW;
							break;
					}
					objDyFactor = 0;objDhFactor = 0;
					n=1;
					snapW=1;snapH=0;
					break;
				}
				case MouseACT_SIZER:{
					boxDyFactor = 0;boxDhFactor = 0;
					objDyFactor = 0;objDhFactor = 0;
					snapCheckYEdges=0;
					switch (liveObj.anchorH) {
						case 0:
							objDxFactor = 0;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 1:
							objDxFactor = 0;objDwFactor = 2;
							boxDxFactor =-1;boxDwFactor = 2;
							snapCheckXEdges=EDGE_LEFT|EDGE_RIGHT|EDGE_SIZEW;
							break;
						case 2:
							objDxFactor = 1;objDwFactor = 1;
							boxDxFactor = 0;boxDwFactor = 1;
							snapCheckXEdges=EDGE_MIDX|EDGE_RIGHT|EDGE_SIZEW;
							break;
					}
					objDyFactor = 0;objDhFactor = 0;
					n=1;
					snapW=1;snapH=0;
					break;
				}
			}
			boxDx=dx*boxDxFactor;objDx=dx*objDxFactor;
			boxDy=dy*boxDyFactor;objDy=dy*objDyFactor;
			boxDw=dx*boxDwFactor;objDw=dx*objDwFactor;
			boxDh=dy*boxDhFactor;objDh=dy*objDhFactor;
			snapCheckVO.boxDxFactor=boxDxFactor;snapCheckVO.boxDwFactor=boxDwFactor;
			snapCheckVO.boxDyFactor=boxDyFactor;snapCheckVO.boxDhFactor=boxDhFactor;
			//Check if snap needed and snap the movement;
			//if(n===1){
			if(hotSnapBox){
				let snaped,snapDx,snapDy,line,snapLines,delta,style,rect;
				//Check snap:
				box=moveTargetBoxes[0];
				editHudObj=box.editHudObj;
				snaped=0;
				snapDx=box.moveOrgBoxX+boxDx-box.moveCurBoxX;
				snapDy=box.moveOrgBoxY+boxDy-box.moveCurBoxY;
				//Deal with X/W:
				{
					let webObj;
					webObj=n===1?forgeHotBox.webObj:null;
					if(curSnapGapX>0){
						//In snap, check if leave:
						delta = dx - snapXDPos;
						if (delta >= -curSnapGapX && delta <= curSnapGapX) {
							//Still in Snap:
							dx = snapXDPos;
							boxDx=snapBoxDx;objDx=snapObjDx;
							boxDw=snapBoxDw;objDw=snapObjDw;
							snaped=1;
							hotSnapBox.update(webObj,0,0,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
							CdySnapLine.updateSnapXHints();
						} else {
							CdySnapLine.clearSnapXHints();
							curSnapGapX=0;
						}
					}
					if(curSnapGapX===0){
						hotSnapBox.update(webObj,snapDx,0,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
						snapCheckVO.snaped=0;
						snapCheckVO.checkGap=SNAP_GAP1;
						snapCheckVO.snapPoses=[];
						snapCheckVO.snapSizes=[];
						snapCheckVO.snapGaps=[];
						snapCheckVO.edgeFlags=snapCheckXEdges;
						hotSnapBox.findSnapX(snapCheckVO);
						curSnapGapX=0;
						if(!snapCheckVO.snaped){
							hudForge.TxtSnapTip.display=0;
						}
						if (snapCheckVO.snaped) {//Find snaped lines:
							delta = Math.round(snapCheckVO.dx);
							dx+=delta;
							hotSnapBox.update(webObj,snapDx+delta,0,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
							if(excludeSnapPosX.has(dx)){
								dx-=delta;
							}else{
								snapXDPos = dx;
								boxDx=dx*boxDxFactor;objDx=dx*objDxFactor;
								boxDw=dx*boxDwFactor;objDw=dx*objDwFactor;
								snapBoxDx = boxDx;	snapObjDx = objDx;
								snapBoxDw = boxDw;	snapObjDw = objDw;
								if(snapCheckVO.snapPos){
									let pos,list;
									hudForge.TxtSnapTip.display=1;
									snaped=1;
									curSnapGapX=SNAP_GAP2;
									list=snapCheckVO.snapPoses;
									for(pos of list){
										CdySnapLine.showSnapXPosHints(pos,hotSnapBox);
									}
								}
								if(snapCheckVO.snapGap){
									snaped=1;
									hudForge.TxtSnapTip.display=1;
									curSnapGapX=SNAP_GAP2;
									CdySnapLine.showSnapXGapHints(snapCheckVO.snapGapSize,hotSnapBox,snapCheckVO.snapGapEdge);
								}
								if(snapCheckVO.snapSize){
									snaped=1;
									hudForge.TxtSnapTip.display=1;
									curSnapGapX=SNAP_GAP2;
									CdySnapLine.showSnapXSizeHints(snapCheckVO.snapSizeSize,hotSnapBox);
								}
							}
						}
					}
				}
				//Deal with Y/H:
				{
					if(curSnapGapY>0){
						//In snap, check if leave:
						delta = dy - snapYDPos;
						if (delta >= -curSnapGapY && delta <= curSnapGapY) {
							//Still in Snap:
							dy = snapYDPos;
							boxDy=snapBoxDy;objDy=snapObjDy;
							boxDh=snapBoxDh;objDh=snapObjDh;
							snaped=1;
							hotSnapBox.update(forgeHotBox.webObj,0,0,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
							CdySnapLine.updateSnapYHints();
						} else {
							CdySnapLine.clearSnapYHints();
							curSnapGapY=0;
						}
					}
					if(curSnapGapY===0){
						hotSnapBox.update(forgeHotBox.webObj,0,snapDy,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
						snapCheckVO.snaped=0;
						snapCheckVO.checkGap=SNAP_GAP1;
						snapCheckVO.snapPoses=[];
						snapCheckVO.snapSizes=[];
						snapCheckVO.snapGaps=[];
						snapCheckVO.edgeFlags=snapCheckYEdges;
						hotSnapBox.findSnapY(snapCheckVO);
						curSnapGapY=0;
						if (snapCheckVO.snaped) {//Find snaped lines:
							delta = Math.round(snapCheckVO.dy);
							dy+=delta;
							hotSnapBox.update(forgeHotBox.webObj,0,snapDy+delta,box.moveOrgBoxW+boxDw,box.moveOrgBoxH+boxDh);
							if(excludeSnapPosY.has(dy)){
								dy-=delta;
							}else{
								snapYDPos = dy;
								boxDy=dy*boxDyFactor;objDy=dy*objDyFactor;
								boxDh=dy*boxDhFactor;objDh=dy*objDhFactor;
								snapBoxDy = boxDy;	snapObjDy = objDy;
								snapBoxDh = boxDh;	snapObjDh = objDh;
								if(snapCheckVO.snapPos){
									let pos,list;
									hudForge.TxtSnapTip.display=1;
									snaped=1;
									curSnapGapY=SNAP_GAP2;
									list=snapCheckVO.snapPoses;
									for(pos of list){
										CdySnapLine.showSnapYPosHints(pos,hotSnapBox);
									}
								}
								if(snapCheckVO.snapGap){
									snaped=1;
									hudForge.TxtSnapTip.display=1;
									curSnapGapY=SNAP_GAP2;
									CdySnapLine.showSnapYGapHints(snapCheckVO.snapGapSize,hotSnapBox,snapCheckVO.snapGapEdge);
								}
								if(snapCheckVO.snapSize){
									snaped=1;
									hudForge.TxtSnapTip.display=1;
									curSnapGapY=SNAP_GAP2;
									CdySnapLine.showSnapYSizeHints(snapCheckVO.snapSizeSize,hotSnapBox);
								}
							}
						}
					}
				}//Sycned
			}
			//Apply move to every selected item if it can be moved:
			{
				let rect,style,delta,div;
				//Move each items:
				for(box of moveTargetBoxes){
					editHudObj=box.editHudObj;
					if(editHudObj.locked.val){
						continue;
					}
					rect=null;
					div=box.boxDiv;
					style=div.style;
					style.left=(box.moveOrgBoxX+boxDx)+"px";
					style.top=(box.moveOrgBoxY+boxDy)+"px";
					style.width=(box.moveOrgBoxW+boxDw)+"px";
					style.height=(box.moveOrgBoxH+boxDh)+"px";
					box.moveCurBoxX=div.offsetLeft;
					box.moveCurBoxY=div.offsetTop;
					//Move liveHudObj:
					if(box.willMoveObj){
						liveObj=editHudObj.liveEdObj;
						if(objDx||objDw){
							if(box.moveFactorX===null){
								liveObj.x=box.moveOrgObjX+10;
								rect=liveObj.webObj.getBoundingClientRect();
								delta=Math.round(rect.x)-box.moveOrgObjBDX;
								box.moveFactorX=delta?10/delta:0;
							}
							liveObj.x=box.moveOrgObjX+objDx*box.moveFactorX;
							liveObj.w=box.moveOrgObjW+objDw*box.moveFactorX;
						}else{
							liveObj.x=box.moveOrgObjX;
							liveObj.w=box.moveOrgObjW;
						}
						if(objDy||objDh){
							if(box.moveFactorY===null){
								liveObj.y=box.moveOrgObjY+10;
								rect=liveObj.webObj.getBoundingClientRect();
								delta=Math.round(rect.y)-box.moveOrgObjBDY;
								box.moveFactorY=delta?10/delta:0;
							}
							liveObj.y=box.moveOrgObjY+objDy*box.moveFactorY;
							liveObj.h=box.moveOrgObjH+objDh*box.moveFactorY;
						}else{
							liveObj.y=box.moveOrgObjY;
							liveObj.h=box.moveOrgObjH;
						}
					}
				}
			}
			box=forgeHotBox;
			if(box && box.editHudObj){
				liveObj=hotEdHudObj.liveEdObj;
				hudForge.BoxTip.display=1;
				hudForge.TxtMoveTip.text=`(x: ${liveObj.x}, y: ${liveObj.y}) (w: ${liveObj.w}, h: ${liveObj.h})`;
			}
		}
	};

	//------------------------------------------------------------------------
	editForge.OnMouseUp=function(e){
		let box,editHudObj,liveObj,dx,dy,dw,dh;
		if(!isMouseDown){
			return;
		}
		if(this.actMode===ACTION_CREATE){
			let x,y,rect,dir,w,h,curObj,prj,pfx,pfy,pfw,pfh;
			isMouseDown=false;
			hudForge.BoxTip.display=0;
			this.createItemByItem(null);
			return;
		}
		if(isRangeSel){
			boxRangeSel.display=0;
			isMouseDown=false;
		}
		
		CdySnapLine.clearSnapXHints();
		CdySnapLine.clearSnapYHints();
		curSnapGapX=0;
		curSnapGapY=0;

		CdySnapLine.resetBuff(boxLines,boxDevice);
		if(hotSnapBox){
			CdySnapBox.freeBox(hotSnapBox);
			hotSnapBox=null;
		}
		isMouseDown=false;
		if(!isMouseMoved){
			if(isMouseDownSame && !lockSelect){
				//Pick top hud:
				editHudObj=this.pickOneEditHud(e,PICKMODE_TOP);
				if(editHudObj && editHudObj!==hotEdHudObj){
					editPrj.setEditSubObj(editHudObj);
					naviView.showView("NaviDoc");
				}
			}
			return;
		}
		hudForge.BoxTip.display=0;
		switch(mouseAct){
			case MouseACT_MOVEOBJ:{
				editPrj.editAttr_StartMoveHud(editDoc);
				for(box of moveTargetBoxes){
					editHudObj=box.editHudObj;
					if(editHudObj.locked.val){
						continue;
					}
					if(box.willMoveObj){
						liveObj=editHudObj.liveEdObj;
						dx=liveObj.x-box.moveOrgObjX;
						dy=liveObj.y-box.moveOrgObjY;
						//liveObj.position=box.moveOrgPS;
						this.moveEditHudObj(box.editHudObj,dx,dy,0,0);
					}
				}
				editPrj.editAttr_EndMoveHud(editDoc);
				this.maybeSyncSelects();//TODO: Is this needed?
				break;
			}
			case MouseACT_SIZET:
			case MouseACT_SIZEB:
			case MouseACT_SIZEL:
			case MouseACT_SIZER:
			case MouseACT_SIZETL:
			case MouseACT_SIZETR:
			case MouseACT_SIZEBL:
			case MouseACT_SIZEBR:{
				editPrj.editAttr_StartMoveHud(editDoc);
				box=forgeHotBox;
				liveObj=box.editHudObj.liveEdObj;
				dx=liveObj.x-box.moveOrgObjX;
				dy=liveObj.y-box.moveOrgObjY;
				dw=liveObj.w-box.moveOrgObjW;
				dh=liveObj.h-box.moveOrgObjH;
				this.moveEditHudObj(box.editHudObj,dx,dy,dw,dh);
				editPrj.editAttr_EndMoveHud(editDoc);
				break;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editForge.cancelMouseMove=function(){
		let box,editHudObj,liveObj,dx,dy,dw,dh;
		if(!isMouseDown){
			return;
		}
		CdySnapLine.clearSnapXHints();
		CdySnapLine.clearSnapYHints();
		curSnapGapX=0;
		curSnapGapY=0;

		CdySnapLine.resetBuff(boxLines,boxDevice);
		if(hotSnapBox){
			CdySnapBox.freeBox(hotSnapBox);
			hotSnapBox=null;
		}
		isMouseDown=false;
		if(!isMouseMoved){
			return;
		}
		hudForge.BoxTip.display=0;
		for(box of moveTargetBoxes){
			editHudObj=box.editHudObj;
			if(editHudObj.locked.val){
				continue;
			}
			if(box.willMoveObj){
				liveObj=editHudObj.liveEdObj;
				liveObj.x=box.moveOrgObjX;
				liveObj.w=box.moveOrgObjW;
				liveObj.y=box.moveOrgObjY;
				liveObj.h=box.moveOrgObjH;
				this.moveEditHudObj(box.editHudObj,0,0,0,0);
			}
		}
		this.maybeSyncSelects();//Is this needed?
	};
	
	//------------------------------------------------------------------------
	pickSelHudObj=function(e){
		let box,hudObj;
		for(box of liveSelBoxes){
			hudObj=box.editHudObj;
			if(checkPick(e,hudObj)){
				return hudObj;
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	checkPick=editForge.checkPick=function(e,edHudObj){
		let mX,mY;
		let w, h, x, y, x2, y2, hud, webObj,rect;
		mX = e.x;
		mY = e.y;
		hud = edHudObj.liveEdObj;
		if (hud) {
			webObj=hud.webObj;
			if(!webObj.offsetParent){
				return false;
			}
			w = hud.w;
			h = hud.h;
			rect=webObj.getBoundingClientRect();
			x=rect.x;y=rect.y;
			w=rect.width;h=rect.height;
			x2=x+w;y2=y+h;
			if (mX >= x && mY >= y && x2 > mX && y2 > mY) {
				return true;
			}
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	editForge.pickOneEditHud=function(e,mode){
		let tgtList,mX,mY,oX,oY,rect;
		let n;
		tgtList=[];
		mX = e.x;
		mY = e.y;
		rect=boxGear.getBoundingClientRect();
		oX=rect.x;
		oY=rect.y;

		function checkOne(edHudObj, checkOnly = 0) {
			let w, h, x, y, x2, y2, hud, webObj,rect;
			hud = edHudObj.liveEdObj;
			if (hud) {
				webObj=hud.webObj;
				if(!webObj.offsetParent){
					return 0;
				}
				w = hud.w;
				h = hud.h;
				rect=webObj.getBoundingClientRect();
				x=rect.x;y=rect.y;
				w=rect.width;h=rect.height;
				x2=x+w;y2=y+h;
				if (mX >= x && mY >= y && x2 > mX && y2 > mY) {
					if (checkOnly) {
						return 1;
					}
					tgtList.push(edHudObj);
				}
			}
			return 0;
		}
		
		if(mode===PICKMODE_STD){
			if(hotEdHudObj && checkOne(hotEdHudObj,1)){
				return hotEdHudObj;
			}
		}
		//Build hit-list:
		editDocHud.runOnAllHuds(checkOne,true);
		//TODO: Build with notes:
		n=tgtList.length;
		if(!n){
			return null;
		}
		if(mode===PICKMODE_TOP){
			return tgtList[n-1];
		}else if(mode===PICKMODE_STD){
			return tgtList[n-1];
		}else if(mode===PICKMODE_CHANGE){
			let idx,hotObj;
			hotObj=hotEdHudObj||hotGearSlot
			if(hotObj){
				idx=tgtList.indexOf(hotObj);
				if(idx>0){
					return tgtList[idx-1]||tgtList[0];
				}else{
					return tgtList[n-1];
				}
			}
		}
		return tgtList[n-1];//Return top most one
	};
	
	//------------------------------------------------------------------------
	editForge.pickContainer=function(e){
		let tgtList,mX,mY,oX,oY,rect;
		let n;
		tgtList=[];
		mX = e.x;
		mY = e.y;
		rect=boxGear.getBoundingClientRect();
		oX=rect.x;
		oY=rect.y;

		function checkOne(edHudObj, checkOnly = 0) {
			let w, h, x, y, x2, y2, hud, webObj,rect;
			if(!edHudObj.isContainer){
				return;
			}
			hud = edHudObj.liveEdObj;
			if (hud) {
				webObj=hud.webObj;
				if(!webObj.offsetParent){
					return false;
				}
				w = hud.w;
				h = hud.h;
				rect=webObj.getBoundingClientRect();
				x=rect.x;y=rect.y;
				w=rect.width;h=rect.height;
				x2=x+w;y2=y+h;
				if (mX >= x && mY >= y && x2 > mX && y2 > mY) {
					if (checkOnly) {
						return true;
					}
					if(!excludeTargetHud.has(edHudObj)){
						tgtList.push(edHudObj);
					}
				}
				return true;
			}
			return false;
		}
		
		//Build hit-list:
		editDocHud.runOnAllHuds(checkOne,true);
		//TODO: Build with notes:
		n=tgtList.length;
		if(!n){
			return null;
		}

		return tgtList[n-1];//Return top most one
	};
	
	//------------------------------------------------------------------------
	editForge.pickRange=function(x,y,w,h){
		let tgtList,cx1,cx2,cy1,cy2;
		
		cx1=x;cx2=cx1+w;
		cy1=y;cy2=cy1+h;
		tgtList=[];
		function checkOne0(edHudObj) {
			let hud, webObj,rect;
			let ox1,ox2,oy1,oy2;
			let minX,maxX,minY,maxY;
			hud = edHudObj.liveEdObj;
			if (hud) {
				webObj=hud.webObj;
				if(!webObj.offsetParent){
					return false;
				}
				rect=webObj.getBoundingClientRect();
				ox1=rect.x;oy1=rect.y;
				ox2=ox1+rect.width;oy2=oy1+rect.height;
				minX=ox1>cx1?ox1:cx1;
				maxX=ox2<cx2?ox2:cx2;
				minY=oy1>cy1?oy1:cy1;
				maxY=oy2<cy2?oy2:cy2;
				if(minX<maxX && minY<maxY){
					tgtList.push(edHudObj);
				}
				return true;
			}
			return false;
		}
		function checkOne1(edHudObj) {
			let hud, webObj,rect;
			let ox1,ox2,oy1,oy2;
			let minX,maxX,minY,maxY;
			hud = edHudObj.liveEdObj;
			if (hud) {
				webObj=hud.webObj;
				if(!webObj.offsetParent){
					return false;
				}
				rect=webObj.getBoundingClientRect();
				ox1=rect.x;oy1=rect.y;
				ox2=ox1+rect.width;oy2=oy1+rect.height;
				if(ox1>=cx1 && ox2<=cx2 && oy1>=cy1 && oy2<=cy2){
					tgtList.push(edHudObj);
				}
				return true;
			}
			return false;
		}
		if(rangeSelMode===0){
			editDocHud.runOnAllHuds(checkOne0,false);
		}else{
			editDocHud.runOnAllHuds(checkOne1,false);
		}
		return tgtList;		
	};
	
	//------------------------------------------------------------------------
	//Move
	editForge.moveEditHudObj=function(editHudObj,dx,dy,dw,dh){
		let xTxt,yTxt,wTxt,hTxt;
		if(editHudObj.isHudGroup){
			//TODO: Move each of it's sub-items:
			return;
		}
		[xTxt, yTxt, wTxt, hTxt] = editHudObj.getMoveHudTexts(dx, dy, dw, dh);
		editPrj.editAttr_MoveOneHud(editHudObj,xTxt,yTxt,wTxt,hTxt);
	};
	
	//------------------------------------------------------------------------
	/*
	Ask user component type then create a component:
	boxRangeSel: the target rect to create the component:
	boxNewHudOwner: the target-owner, naviBox should highlight it
	*/
	editForge.createItemByItem=function(next){
		let rect,pfx,pfy,pfw,pfh,x,dir,y,curObj;
		rect=boxRangeSel.getBoundingClientRect();
		pfx=rect.x;
		pfy=rect.y;
		pfw=rect.width;
		pfh=rect.height;
		if(pfw<5 && pfh<5){
			boxNewHudOwner.display=0;
			boxRangeSel.display=0;
			if(naviBox){
				naviBox.setTargetObj(null);
			}
			return;
		}
		if(this.drawSnap){
			let snap=this.drawSnapSize;
			pfx=Math.round(pfx/snap)*snap;
			pfy=Math.round(pfy/snap)*snap;
			pfw=Math.round(pfw/snap)*snap;
			pfh=Math.round(pfh/snap)*snap;
		}
		x=rect.x+rect.width*0.5;
		if(rect.y+rect.height<window.innerHeight-250){
			dir=0;
			y=rect.y+rect.height+20;
		}else{
			dir=1;
			y=rect.y-250;
		}
		curObj=targetHud;
		boxNewHudOwner.display=0;
		editApp.showDlg(DLGCreateHud,{
			x,y,dir,
			next(vo){
				let def,prj,newHud,webObj,ox,oy,ow,oh,sw,scale,pfId;
				boxRangeSel.display=0;
				if(naviBox){
					naviBox.setTargetObj(null);
				}
				if(vo && vo.def){
					pfId=vo.id;
					//TODO: Create a def typed component at the position
					prj=editDoc.prj;
					def=vo.def;
					webObj=curObj.liveEdObj.webObj;
					rect=webObj.getBoundingClientRect();
					ox=Math.round(rect.x);oy=Math.round(rect.y);
					pfx-=ox;pfy-=oy;
					//TODO: Adjust position:
					ow=rect.width;oh=rect.height;
					sw=webObj.offsetWidth;
					if(sw>=0){
						scale=sw/ow;
					}else{
						scale=1;
					}
					let importPath=def.source;
					if(importPath){
						let doc=curObj.doc;
						let error;
						if(importPath.startsWith(prj.path)){
							error=prj.editAttr_CanImportDoc(doc,def.source);
							if(error){
								window.alert(error);
								return false;
							}
						}
					}
					newHud=prj.editAttr_AddSubHud(curObj,def,pfx*scale,pfy*scale,pfw*scale,pfh*scale,pfId);
					if(newHud){
						callAfter(()=>{
							naviView.showView("NaviDoc");
							editPrj.setEditSubObj(newHud);
							if(next){
								next(newHud);
							}
						});
					}
				}
			}
		});
	};
}

//****************************************************************************
//:Drag to add components:
//****************************************************************************
{
	let dragNewHudDef=null;
	let dragStartOX,dragStartOY,dragNewHudW,dragNewHudH;
	let dragStartMx,dragStartMy,dragDx,dragDy;
	const dragGap=20;
	let pickTarget=false;
	let dragSizeType=null;
	//------------------------------------------------------------------------
	editForge.OnNewHudDragStart=function(def, e){
		let w,h,mX,mY,ppts;
		let curObj,webObj,rect,x,y,ox,oy,ow,oh,sw,scale;
		if(naviBox){
			if(!naviBox.isShowing()){
				naviView.showView("NaviDoc");
			}
		}else{
			naviView.showView("NaviDoc");
			return false;
		}
		if(editDoc.curFaceTag){
			return false;
		}
		if(this.addPlace===ADDPLACE_TOP){
			curObj=editDocHud;
			pickTarget=true;
		}else{
			if(hotEdHudObj){
				curObj=hotEdHudObj;
			}else if(naviBox){
				let node;
				node=naviBox.treeBox.hotNode;
				if(node){
					curObj=node.nodeObj;
					if(!curObj.isGearSlot && !curObj.isHudObj){
						curObj=editDocHud;
					}
				}else{
					curObj=editDocHud;
				}
			}else{
				curObj=editDocHud;
			}
			pickTarget=false;
		}
		if(!curObj){
			return false;
		}
		if(!curObj.isHudObj && !curObj.isGearSlot){
			//TODO: notify user
			return false;
		}
		if(curObj.objDef.naviHasSub===false){
			//TODO: notify user
			return false;
		}
		targetHud=curObj;
		webObj=curObj.liveEdObj.webObj;
		rect=webObj.getBoundingClientRect();
		ox=rect.left;oy=rect.top;
		ow=rect.width;oh=rect.height;
		sw=webObj.offsetWidth;
		if(sw>=0){
			scale=ow/sw;
		}else{
			scale=1;
		}
		
		dragNewHudDef=def;
		dragStartMx = mX = e.x;
		dragStartMy = mY = e.y;
		rect=hudForge.getBoundingClientRect();
		dragStartOX=Math.round(rect.x);
		dragStartOY=Math.round(rect.y);
		mX -= dragStartOX;
		mY -= dragStartOY;
		ox -= dragStartOX;
		oy -= dragStartOY;
		dragSizeType=def.curEditFillType;
		switch(dragSizeType){
			case "auto":
			default:
				w=def.initW||(def.attrs.w?(def.attrs.w.initVal>0?def.attrs.w.initVal:100):100);
				h=def.initH||(def.attrs.h?(def.attrs.h.initVal>0?def.attrs.h.initVal:100):100);
				break;
			case "size_all":
				w=ow;
				h=oh;
				break;
			case "size_w":
				w=ow;
				h=def.initH||(def.attrs.h?(def.attrs.h.initVal>0?def.attrs.h.initVal:100):100);
				break;
			case "size_h":
				w=def.initW||(def.attrs.w?(def.attrs.w.initVal>0?def.attrs.w.initVal:100):100);
				h=oh;
				break;
		}
		boxNewHudOwner.display=1;
		boxNewHudOwner.x=ox-3;
		boxNewHudOwner.y=oy-3;
		boxNewHudOwner.w=ow+6;
		boxNewHudOwner.h=oh+6;
		
		boxNewHud.display=1;
		boxNewHud.x=mX;
		boxNewHud.y=mY;
		boxNewHud.w=w*scale;
		boxNewHud.h=h*scale;
		dragNewHudW=w;
		dragNewHudH=h;
		isDraging=1;
		dragDx=0;
		dragDy=0;
		if(naviBox){
			naviBox.setTargetObj(targetHud);
		}
	};

	//------------------------------------------------------------------------
	let lastDragX,lastDragY;
	editForge.OnNewHudDrag=function(e){
		let mX,mY,newTgt;
		if(isDraging){
			if(e){
				mX = e.x;
				mY = e.y;
				lastDragX=mX;
				lastDragY=mY;
			}else{
				mX=lastDragX;
				mY=lastDragY;
				e={x:mX,y:mY};
			}
			dragDx=mX-dragStartMx;
			dragDy=mY-dragStartMy;
			mX -= dragStartOX;
			mY -= dragStartOY;
			boxNewHud.x=mX;
			boxNewHud.y=mY;
			if(pickTarget){
				newTgt=this.pickContainer(e)||editDocHud;
				if(newTgt!==targetHud){
					let webObj,rect,ox,oy,ow,oh,w,h,sw,scale;
					targetHud=newTgt;
					webObj=newTgt.liveEdObj.webObj;
					rect=webObj.getBoundingClientRect();
					ox=rect.left;oy=rect.top;
					ow=rect.width;oh=rect.height;
					sw=webObj.offsetWidth;
					if(sw>=0){
						scale=ow/sw;
					}else{
						scale=1;
					}
					
					ox -= dragStartOX;
					oy -= dragStartOY;
					boxNewHudOwner.x=ox-3;
					boxNewHudOwner.y=oy-3;
					boxNewHudOwner.w=ow+6;
					boxNewHudOwner.h=oh+6;
			
					switch(dragSizeType){
						case "size_all":
							w=ow;
							h=oh;
							boxNewHud.w=w*scale;
							boxNewHud.h=h*scale;
							break;
						case "size_w":
							w=ow;
							boxNewHud.w=w*scale;
							break;
						case "size_h":
							h=oh;
							boxNewHud.h=h*scale;
							break;
					}
					if(naviBox){
						naviBox.setTargetObj(targetHud);
					}
				}
			}
		}
	};

	//------------------------------------------------------------------------
	editForge.OnNewHudDragEnd=function(e){
		let attr,curObj,def,prj,newHud;
		let webObj,rect,x,y,w,h,ox,oy,ow,oh,sw,scale;
		let adx,ady;

		if(!isDraging){
			return false;
		}
		if(e.button===2){
			this.cancelDrag();
			return;
		}
		isDraging=false;
		excludeTargetHud.clear();

		prj=editDoc.prj;
		def=dragNewHudDef;
		curObj=targetHud;
		if(!curObj || (!curObj.isHudObj && !curObj.isGearSlot)){
			curObj=editDocHud;
		}
		
		if(!curObj){
			return false;
		}
		
		if(curObj.objDef.naviHasSub===false){
			//TODO: notify user?
			return false;
		}

		adx=dragDx<0?-dragDx:dragDx;
		ady=dragDy<0?-dragDy:dragDy;
		if(adx+ady>dragGap){
			if(!def){
				return false;
			}
			webObj=boxNewHud.webObj;
			rect=webObj.getBoundingClientRect();
			x=Math.round(rect.x);y=Math.round(rect.y);
			w=boxNewHud.w;h=boxNewHud.h;
			//x=Math.round(x-w*0.5);y=Math.round(y-h*0.5);

			webObj=curObj.liveEdObj.webObj;
			rect=webObj.getBoundingClientRect();
			ox=Math.round(rect.x);oy=Math.round(rect.y);
			x-=ox;y-=oy;
			//TODO: Adjust position:
			ow=rect.width;oh=rect.height;
			sw=webObj.offsetWidth;
			if(sw>=0){
				scale=sw/ow;
			}else{
				scale=1;
			}
		}else{
			x=0;y=0;
		}
		boxNewHudOwner.display=0;
		boxNewHud.display=0;
		let importPath=def.source;
		if(importPath){
			let doc=curObj.doc;
			let error;
			if(importPath.startsWith(prj.path)){
				error=prj.editAttr_CanImportDoc(doc,def.source);
				if(error){
					window.alert(error);
					return false;
				}
			}
		}
		newHud=prj.editAttr_AddSubHud(curObj,def,x*scale,y*scale);
		if(newHud){
			callAfter(()=>{
				editPrj.setEditSubObj(newHud);
				naviView.showView("NaviDoc");
			});
		}
		if(naviBox){
			naviBox.setTargetObj(null);
		}
	};
	
	//------------------------------------------------------------------------
	editForge.cancelDrag=function(){
		if(!isDraging){
			return false;
		}
		targetHud=null;
		isDraging=false;
		excludeTargetHud.clear();
		boxNewHudOwner.display=0;
		boxNewHud.display=0;
		//TODO: Add app state text
		if(naviBox){
			naviBox.setTargetObj(null);
		}
	};
}

//****************************************************************************
//:Edit by keyboard:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editForge.handleShortcut=function(cmd){
		if(isHotEditing)
			return false;
		switch(cmd){
			case "MoveUp":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(0,-1);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveDown":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(0,1);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveLeft":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(-1,0);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveRight":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(1,0);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveUpMore":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(0,-5);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveDownMore":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(0,5);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveLeftMore":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(-5,0);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "MoveRightMore":{
				if(!editDoc.curFaceTag){
					this.doMoveObj(5,0);
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			}
			case "Escape":{
				if(isDraging){
					excludeTargetHud.add(targetHud);
					this.OnNewHudDrag();
				}else{
					if(curSnapGapX>0){
						//In snap, check if leave:
						CdySnapLine.clearSnapXHints();
						curSnapGapX=0;
						excludeSnapPosX.add(snapXDPos);
					}
					if(curSnapGapY>0){
						//In snap, check if leave:
						CdySnapLine.clearSnapYHints();
						curSnapGapY=0;
						excludeSnapPosY.add(snapYDPos);

					}
				}
				break;
			}
			case "Delete":{
				if(!editDoc.curFaceTag){
					this.doRemoveObj();
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				break;
			}
			case "Copy":
				this.doCopyObj();
				return 1;
			case "HitSpace":{
				lockSelect=!lockSelect;
				hudForge.setLockSelect(lockSelect);
				return 1;
			}
			case "Cut":
				if(!editDoc.curFaceTag){
					this.doCutObj();
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			case "Paste":
				if(!editDoc.curFaceTag){
					this.doPasteObj();
				}else{
					editApp.showStateText("Can't mouse-move obj in face-edit-mode.");
				}
				return 1;
			case "Undo":
				this.doUndo();
				return 1;
			case "Redo":
				this.doRedo();
				return 1;
		}
	};
	
	//------------------------------------------------------------------------
	editForge.doMoveObj=function(dx,dy){
		let moveTargetBoxes,box,editHudObj,liveObj;
		moveTargetBoxes=ForgeSelBox.buildMoveTargets();
		if(moveTargetBoxes.length>0){
			editPrj.editAttr_StartMoveHud(editDoc);
			for(box of moveTargetBoxes){
				editHudObj=box.editHudObj;
				if(editHudObj.locked.val){
					continue;
				}
				if(box.willMoveObj){
					liveObj=editHudObj.liveEdObj;
					this.moveEditHudObj(box.editHudObj,dx,dy,0,0);
				}
			}
			editPrj.editAttr_EndMoveHud(editDoc);
			this.maybeSyncSelects();
		}
	};
	
	//------------------------------------------------------------------------
	editForge.doRemoveObj=function(){
		if(naviBox){
			naviBox.doDelObj();
		}
	};

	//------------------------------------------------------------------------
	editForge.doCopyObj=function(){
		if(naviBox){
			naviBox.doCopyObj();
		}
	};

	//------------------------------------------------------------------------
	editForge.doCutObj=function(){
		if(naviBox){
			naviBox.doCutObj();
		}
	};

	//------------------------------------------------------------------------
	editForge.doPasteObj=function(){
		if(naviBox){
			naviBox.doPasteObj();
		}
	};

	//------------------------------------------------------------------------
	editForge.doUndo=function(){
		let dataDoc,editor;
		if(!editDoc){
			return;
		}
		dataDoc=editDoc.dataDoc;
		editor=dataDoc.editBox;
		if(editor){
			editor.undo();
		}
	};

	//------------------------------------------------------------------------
	editForge.doRedo=function(){
		let dataDoc,editor;
		if(!editDoc){
			return;
		}
		dataDoc=editDoc.dataDoc;
		editor=dataDoc.editBox;
		if(editor){
			editor.redo();
		}
	};
}

//****************************************************************************
//:Hot online edit
//****************************************************************************
{
	let hotEditAttr=null;
	let hotEditWebObj=null;
	let hotEditTextObj=null;
	let hotEditOrgText=null;
	let hotEidtLiveObj=null;
	//------------------------------------------------------------------------
	editForge.startHotLineEdit=function(attr){
		let liveObj,webObj,chd;
		let self=this;
		liveObj=hotEdHudObj.liveEdObj;
		if(liveObj){
			hotEditAttr=attr;
			isHotEditing=true;
			boxHelpers.display=0;
			boxGear.uiEvent=1;
			liveObj.uiEvent=1;
			editApp.showFloatDlg(liveObj,[255,255,255,0.5]);
			webObj=liveObj.webObj;
			chd=webObj.firstChild;//The text-div:
			chd.contentEditable="true";
			chd.style.cursor="text";
			chd.style.outline="#305060 dashed 1px";
			hotEditOrgText=chd.innerText;
			window.setTimeout(()=>{
				chd.focus();
				document.execCommand("selectAll",false,null);
			},20);
			chd.onkeydown=function(evt){
				let text;
				if(evt.code==="Enter"){
					if(evt.shiftKey){
						return;
					}
					self.endHotLineEdit(true);
					evt.stopPropagation();
					evt.preventDefault();
				}else if(evt.code==="Escape"){
					text=hotEditTextObj.innerText;
					if(text!==hotEditOrgText){
						hotEditTextObj.innerText=hotEditOrgText;
						document.execCommand("selectAll",false,null);
					}else{
						self.endHotLineEdit(false);
					}
				}
			}
			chd.oninput=function(){
			};
			liveObj.OnBGClick=function(){
				self.endHotLineEdit(true);
			}
			hotEidtLiveObj=liveObj;
			hotEditWebObj=webObj;
			hotEditTextObj=chd;
		}
	};

	//------------------------------------------------------------------------
	editForge.endHotLineEdit=function(applyAttr=true){
		if(!isHotEditing)
			return;
		isHotEditing=false;
		if(!hotEditTextObj){
			return;
		}
		boxGear.uiEvent=-1;
		hotEidtLiveObj.uiEvent=-1;
		hotEditTextObj.contentEditable="false";
		hotEditTextObj.style.cursor="default";
		hotEditTextObj.style.outline="0px";
		boxHelpers.display=1;
		editApp.closeFloatDlg();
		if(applyAttr){
			let text,obj,prj;
			text=hotEditTextObj.innerText;
			if(text!==hotEditOrgText){
				obj=hotEditAttr.owner;
				prj=obj.prj;
				prj.editAttr_SetAttrByText(obj,hotEditAttr,text);
			}
		}else{
			hotEditTextObj.innerText=hotEditOrgText;
		}
		this.maybeSyncSelects();
	};
}

//****************************************************************************
//:FaceTag related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editForge._OnFaceOn=function(){
		hudForge.showFace("FaceOn");
	};
	
	//------------------------------------------------------------------------
	editForge._OnFaceOff=function(){
		hudForge.showFace("FaceOff");
	};
}

//****************************************************************************
//:Utilities: Capture etc...
//****************************************************************************
{
	//------------------------------------------------------------------------
	//editForge.captureGear=function(){};
}
export {EditForge};