import inherits from "/@inherits";
var ForgeSelBox,forgeSelBox,ForgeHotBox,forgeHotBox,theHotBox;
var forge=null;
//****************************************************************************
ForgeSelBox=function(){
	let div,style,self;
	self=this;
	div=this.boxDiv=document.createElement("div");
	style=div.style;
	style.position="absolute";
	style.borderStyle="dashed";
	style.borderWidth="2px";
	style.borderColor="rgba(0,255,255,0.5)";
	this.editHudObj=null;
	this.editHudObj=null;
	this.OnObjChanged=()=>{
		self.update();
	};
};
forgeSelBox=ForgeSelBox.prototype={};
//----------------------------------------------------------------------------
ForgeSelBox.setForge=function(fg){
	forge=fg;
};

//----------------------------------------------------------------------------
const freeSelBoxes=[];
const liveSelBoxes=[];
ForgeSelBox.alloc=function(){
	let box;
	box=freeSelBoxes.pop();
	if(box){
		return box;
	}
	return new ForgeSelBox();
};
ForgeSelBox.liveBoxes=liveSelBoxes;
//----------------------------------------------------------------------------
ForgeSelBox.free=function(box){
	box.unbind();
	freeSelBoxes.push(box);
};

//----------------------------------------------------------------------------
ForgeSelBox.getLiveBoxes=function(){
	return liveSelBoxes.slice(0);
};
//----------------------------------------------------------------------------
ForgeSelBox.clear=function(){
	let box;
	for(box of liveSelBoxes){
		ForgeSelBox.free(box);
	}
	liveSelBoxes.splice(0);
};

//----------------------------------------------------------------------------
ForgeSelBox.addBox=function(editHudObj,boxHelpers){
	let box;
	box=ForgeSelBox.alloc();
	box.bindToObj(editHudObj,boxHelpers);
	liveSelBoxes.push(box);
};

//----------------------------------------------------------------------------
ForgeSelBox.buildMoveTargets=function(){
	let tgtList,i,n,box,allList;
	allList=liveSelBoxes.slice(0);
	tgtList=[];
	function isChild(fobj,cobj){
		let obj;
		obj=cobj;
		while(obj){
			if(obj===fobj){
				return true;
			}
			obj=obj.owner;
		}
		return false;
	}
	function checkBox(box){
		let edHudObj,i,n,chkObj,isAdded;
		isAdded=0;
		edHudObj=box.editHudObj;
		n=tgtList.length;
		for(i=0;i<n;i++){
			chkObj=tgtList[i].editHudObj;
			if(isChild(chkObj,edHudObj)){
				return;
			}
			if(isChild(edHudObj,chkObj)){
				if(!isAdded){
					tgtList[i]=box;
					isAdded=1;
				}else{
					tgtList.splice(i,1);
					n--;i--;
				}
			}
		}
		if(!isAdded){
			tgtList.push(box);
		}
	}
	n=allList.length;
	for(i=0;i<n;i++){
		box=allList[i];
		box.willMoveObj=false;
		checkBox(box);
	}
	if(theHotBox && theHotBox.editHudObj){
		allList.push(theHotBox);
		theHotBox.willMoveObj=false;
		checkBox(theHotBox);
	}
	for(box of tgtList){
		box.willMoveObj=true;
	}
	return allList;
};

//----------------------------------------------------------------------------
forgeSelBox.bindToObj=function(editHudObj,boxHelpers){
	let oldEditObj;
	if(editHudObj && editHudObj===this.editHudObj){
		this.update();
		return true;
	}
	oldEditObj=this.editHudObj;
	if(oldEditObj && oldEditObj.properties){
		oldEditObj.properties.offNotify("Changed",this.OnObjChanged);
	}
	if(!editHudObj.liveEdObj){
		return false;
	}
	this.editHudObj=editHudObj;
	this.boxHelpers=boxHelpers;
	if(this.update()){
		//Add to DOM-tree:
		boxHelpers.webObj.appendChild(this.boxDiv);
		//Watch editHudObj pos/ size change?
		if(this.editHudObj.properties){
			this.editHudObj.properties.onNotify("Changed",this.OnObjChanged);
		}
		return true;
	}
	return false;
};

//----------------------------------------------------------------------------
forgeSelBox.update=function(){
	let editHudObj,boxHelpers,div,liveObj,webObj,rect,x,y,w,h,style,ox,oy;
	//let zoom;
	div=this.boxDiv;
	style=div.style;
	editHudObj=this.editHudObj;
	if(!editHudObj){
		return false;
	}
	boxHelpers=this.boxHelpers;
	if(!boxHelpers){
		return false;
	}
	liveObj=editHudObj.liveEdObj;
	if(!liveObj){
		return false;
	}
	webObj=liveObj.webObj;
	if(!webObj){
		return false;
	}
	if(!webObj.offsetParent){
		return false;
	}
	rect=webObj.getBoundingClientRect();
	x=rect.x;y=rect.y;w=rect.width;h=rect.height;
	rect=boxHelpers.getBoundingClientRect();
	ox=rect.x;oy=rect.y;
	x-=ox;y-=oy;
	x-=2;y-=2;
	style.left=x+"px";
	style.top=y+"px";
	style.width=w+"px";
	style.height=h+"px";
	return true;
};

//----------------------------------------------------------------------------
forgeSelBox.unbind=function(){
	let div=this.boxDiv;
	//Remove from DOM-tree
	if(div && div.parentNode){
		div.parentNode.removeChild(div);
	}
	if(this.editHudObj){
		//unwatch editHudObj pos/size change?
		if(this.editHudObj.properties){
			this.editHudObj.properties.offNotify("Changed",this.OnObjChanged);
		}
		this.editHudObj=null;
	}
};

const MouseACT_NONE=-1;
const MouseACT_MOVEBG=0;
const MouseACT_MOVEOBJ=1;
const MouseACT_SIZETL=2;
const MouseACT_SIZETR=3;
const MouseACT_SIZEBL=4;
const MouseACT_SIZEBR=5;
const MouseACT_RANGESELECT=6;
const MouseACT_SIZET=7;
const MouseACT_SIZEB=8;
const MouseACT_SIZEL=9;
const MouseACT_SIZER=10;

//****************************************************************************
ForgeHotBox=function(){
	let div,style,boxes;
	ForgeSelBox.call(this);
	div=this.boxDiv;
	style=div.style;
	style.borderColor="rgba(128,235,255,1)";
	style.borderStyle="solid";
	style.borderWidth="2px";
	div.innerHTML=`
	<div id="MoveHTools" style="position:absolute;left:0px;top:0px;width:100%;height:100%;">
		<div id="BtnL" style="position:absolute;right:100%;top:0;width:5px;height:100%;background:rgba(255,255,255,0);cursor:col-resize"></div>
		<div id="BtnR" style="position:absolute;left:100%;top:0;width:5px;height:100%;background:rgba(255,255,255,0);cursor:col-resize"></div>
	</div>
	<div id="MoveVTools" style="position:absolute;left:0px;top:0px;width:100%;height:100%;">
		<div id="BtnT" style="position:absolute;left:0px;bottom:100%;width:100%;height:5px;background:rgba(255,255,255,0);cursor:row-resize"></div>
		<div id="BtnB" style="position:absolute;left:0px;top:100%;width:100%;height:5px;background:rgba(255,255,255,0);cursor:row-resize"></div>
	</div>
	<div id="MoveTools" style="position:absolute;left:0px;top:0px;width:100%;height:100%;">
		<div id="BtnTL" style="position:absolute;left:0px;top:0px;width:7px;height:7px;border-style:solid;border-size:2;background:rgba(55,235,255,1);border-color:rgba(55,235,255,1);cursor:pointer;transform:translate(-5px, -5px);border-radius:5px"></div>
		<div id="BtnTR" style="position:absolute;right:0px;top:0px;width:7px;height:7px;border-style:solid;border-size:2;background:rgba(55,235,255,1);border-color:rgba(55,235,255,1);cursor:pointer;transform:translate(5px, -5px);border-radius:5px"></div>
		<div id="BtnBR" style="position:absolute;right:0px;bottom:0px;width:7px;height:7px;border-style:solid;border-size:2;background:rgba(55,235,255,1);border-color:rgba(55,235,255,1);cursor:pointer;transform:translate(5px, 5px);border-radius:5px"></div>
		<div id="BtnBL" style="position:absolute;left:0px;bottom:0px;width:7px;height:7px;border-style:solid;border-size:2;background:rgba(55,235,255,1);border-color:rgba(55,235,255,1);cursor:pointer;transform:translate(-5px, 5px);border-radius:5px"></div>
	</div>
	<div id="LockTools" style="position:absolute;left:-2px;top:-2px;right:-2px;bottom:-2px;border-style:dashed;border-size:2;border-color:#000000">
	</div>
	`;
	this.ctrlBoxes=boxes=[];
	this.boxMove=div.querySelector("#MoveTools");
	this.boxMoveH=div.querySelector("#MoveHTools");
	this.boxMoveV=div.querySelector("#MoveVTools");
	this.boxLock=div.querySelector("#LockTools");
	boxes[0]=this.btnTL=div.querySelector("#BtnTL");
	boxes[1]=this.btnTR=div.querySelector("#BtnTR");
	boxes[2]=this.btnBR=div.querySelector("#BtnBR");
	boxes[3]=this.btnBL=div.querySelector("#BtnBL");
	boxes[4]=this.btnT=div.querySelector("#BtnT");
	boxes[5]=this.btnB=div.querySelector("#BtnB");
	boxes[6]=this.btnL=div.querySelector("#BtnL");
	boxes[7]=this.btnR=div.querySelector("#BtnR");
	boxes[0].mouseAct=MouseACT_SIZETL;
	boxes[1].mouseAct=MouseACT_SIZETR;
	boxes[2].mouseAct=MouseACT_SIZEBR;
	boxes[3].mouseAct=MouseACT_SIZEBL;
	boxes[4].mouseAct=MouseACT_SIZET;
	boxes[5].mouseAct=MouseACT_SIZEB;
	boxes[6].mouseAct=MouseACT_SIZEL;
	boxes[7].mouseAct=MouseACT_SIZER;
};
inherits(ForgeHotBox,ForgeSelBox);
forgeHotBox=ForgeHotBox.prototype;
theHotBox=ForgeHotBox.instance=new ForgeHotBox();

//----------------------------------------------------------------------------
forgeHotBox.update=function(){
	let editHudObj,noMove;
	editHudObj=this.editHudObj;
	if(!forgeSelBox.update.call(this)){
		return;
	}
	//Check obj's lock state:
	if(editHudObj.isHudObj){
		if(editHudObj.locked.val){
			this.boxMove.style.display="none";
			this.boxMoveV.style.display="none";
			this.boxMoveH.style.display="none";
			this.boxLock.style.display="";
		}else{
			this.boxMoveH.style.display="";
			this.boxLock.style.display="none";
			noMove=0;
			if(editHudObj.isHudGear){
				let args=editHudObj.createArgs;
				if(editHudObj.properties.getAttr("w")||args.getAttr("w")||args.getAttr("width")){
					this.boxMoveH.style.display="";
				}else{
					this.boxMoveH.style.display="none";
					noMove=1;
				}
				if(editHudObj.properties.getAttr("h")||args.getAttr("h")||args.getAttr("height")){
					this.boxMoveV.style.display="";
				}else{
					this.boxMoveV.style.display="none";
					noMove=1;
				}
			}else{
				this.boxMoveH.style.display="";
				this.boxMoveV.style.display="";
			}
			this.boxMove.style.display=noMove?"none":"";
		}
	}else{
		this.boxMove.style.display="none";
		this.boxMoveV.style.display="none";
		this.boxMoveH.style.display="none";
		this.boxLock.style.display="";
	}
	return true;
};

//----------------------------------------------------------------------------
forgeHotBox.pickTool=function(e){
	let boxes,box,rect,x,y;
	x=e.x;y=e.y;
	boxes=this.ctrlBoxes;
	for(box of boxes){
		rect=box.getBoundingClientRect();
		if(x>=rect.left && x<rect.right && y>rect.top && y<rect.bottom){
			return box;
		}
	}
	return null;
};
export {ForgeSelBox,ForgeHotBox,theHotBox as forgeHotBox};