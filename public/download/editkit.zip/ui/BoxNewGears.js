//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GAP55UKN0StartDoc*/
import {BtnIcon} from "/@homekit/ui/BtnIcon.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";

var cssCatalog,cssHud,cssSizeBox,theForge;
const localPath=VFACT.appPath+"/assets";
//***************************************************************************
//Catalog entry component:
//***************************************************************************
cssCatalog=function(app,catalog,node,box){
	let cssVO,self;
	let cfgColor=appCfg.color;
	cssVO={
		nameHost:true,
		type:"button",id:"HudDefCatlog",x:0,y:0,w:"100%",h:26,
		children:[
			{
				type:"box",x:0,y:0,w:"100%",h:"100%",autoLayout:1,
				background:"linear-gradient(to right, rgba(220,220,220,1), 75%, rgba(220,220,220,0))",
				"borderColor":cfgColor.lineBodySub,"border":[1,0,1,0],
			},
			{
				type:"image",id:"ImgOpen",x:8,y:">calc(50% - 1px)",w:"12",h:"12",anchorH:1,anchorV:1,rotate:0,
				image:appCfg.sharedAssets+"/collapse.svg",fitSize:1
			},
			//CatalogName:
			{
				type:"text",id:"txtName",x:5+10,y:0,w:">calc(100% - 16px)",h:">calc(100% - 2px)",alignV:1,
				fontSize:appCfg.txtSize.small,bold:0,color:[0,0,0],
				text:catalog.name,
			},
		],
		faces:{
			"normal":{
			},
			"hot":{
			},
			"open":{
				"$":function(){
					self.isOpen=1;
				},
				"ImgOpen":{rotate:90},
				"btmLine":{display:0}
			},
			"close":{
				"$":function(){
					self.isOpen=0;
				},
				"ImgOpen":{rotate:0},
				"btmLine":{display:1}
			},
		},
		catalog:catalog,isOpen:0,
		OnCreate:function(){
			self=this;
		},
		OnClick(){
			if(self.isOpen){
				self.close();
			}else{
				self.open();
			}
		},
		open:function(){
			box.openNode(node);
		},
		close:function(){
			box.closeNode(node);
		}
	};
	return cssVO;
};

//***************************************************************************
//HudType button, can be draged to add:
//***************************************************************************
cssHud=function(app,def,func,box){
	let cssVO,cfgColor,self,boxSize;
	let isFocus=0;
	let fillType;
	let boxIcon;
	let imgPath;
	fillType=def.curEditFillType||"auto";
	cfgColor=appCfg.color;
	imgPath=def.icon;
	if(imgPath[0]==="/"){
	}else if(imgPath[0]==="."){
		imgPath=localPath+imgPath;
	}else{
		imgPath=appCfg.sharedAssets+"/"+def.icon;
	}
	cssVO={
		type:"button",x:0,y:0,w:"100%",h:70,autoLayout:1,drag:2,nameHost:1,margin:[0,0,2,0],
		children:[
			{
				type:"box",id:"BoxBG",x:0,y:0,w:"100%",h:"100%",background:[255,255,255,0]
			},
			{
				type:"image",id:"icon",x:"50%",y:30,w:40,h:40,anchorX:1,anchorY:1,uiEvent:-1,
				image:imgPath,fitSize:1,autoLayout:1,
			},
			{
				type:"text",id:"text",x:"50%",y:">calc(100% - 18px)",w:"100%",h:10,color:[0,0,0],anchorX:1,autoLayout:1,uiEvent:-1,
				alignH:1,alignV:0,text:def.showName||def.name,fontSize:appCfg.txtSize.small,//scale:0.75
			},
		],
		faces:{
			"up":{
				$(){
					return isFocus?false:true;
				},
				"BoxBG":{
					background:[255,255,255,0]
				},
				"icon":{
					y:30,
				}
			},
			"over":{
				$(){
					return isFocus?false:true;
				},
				"BoxBG":{
					background:cfgColor.hot
				},
				$1(){
					return def.withFillType?true:false;
				},
				"icon":{
					y:23
				}
			},
			"down":{
				$(){
					return isFocus?false:true;
				},
				"BoxBG":{
					background:cfgColor.lineBodySub
				}
			},
			"focus":{
				$(){
					isFocus=1;
				},
				"BoxBG":{
					background:cfgColor.hot
				},
			},
			"blur":{
				$(){
					isFocus=0;
				},
				"BoxBG":{
					background:[255,255,255,0]
				}
			}
		},
		def:def,
		OnCreate(){
			self=this;
			boxIcon=self.icon;
		},
		OnClick:function(){
			func(this);
		},
		OnDragStart:function(e){
			this.uiEvent=-1;
			def.curEditFillType="auto";
			box.OnHudDragStart(def,e);
		},
		OnDrag:function(e,dx,dy){
			box.OnHudDrag(e);
		},
		OnDragEnd:function(e,cancel,dx,dy){
			box.OnHudDragEnd(e,cancel);
			this.uiEvent=1;
		},
	};
	//Show Image hint:
	cssVO.OnMouseInOut=function(isIn){
		if(isIn){
			if(def.withFillType){
				box.bindSizeBox(this,def);
			}
			app.uiForge.showGearPV(def);
			app.showStateText((($ln==="CN")?("添加新组件：拖放选择位置或单击创建在默认位置（x=0，y=0）"):/*EN*/("Add new component: Drag & drop or single click create at default position (x=0, y=0).")));
		}else{
			app.uiForge.hideGearPV(def);
			box.unbindSizeBox(this);
		}
	};
	return cssVO;
};

//***************************************************************************
//Size Box:
//***************************************************************************
cssSizeBox=function(app,box){
	let cssVO,cfgColor,ownerBtn,def;
	cfgColor=appCfg.color;
	let OnDragStart=function(e){
		def.curEditFillType=this.sizeCode;
		this.uiEvent=-1;
		box.OnHudDragStart(def,e);
	};
	let OnDrag=function(e,dx,dy){
		box.OnHudDrag(e);
	};
	let OnDragEnd=function(e,cancel,dx,dy){
		box.OnHudDragEnd(e,cancel);
		this.uiEvent=1;
	};
	cssVO={
		type:"box",x:3,y:">calc(100% - 28px)",w:">calc(100% - 6px)",h:24,autoLayout:1,nameHost:1,border:1,bolorColor:cfgColor.lineBody,background:cfgColor.body,
		children:[
			{
				"type":BtnIcon(app,20,20,appCfg.sharedAssets+"/size_w.svg",0),"x":">calc(50% - 24px)","y":"50%","anchorX":1,"anchorY":1,drag:2,
				tip:(($ln==="CN")?("初始大小：填充父元素宽度"):/*EN*/("Init Size: Fill Parent Width")),sizeCode:"size_w",
				OnDragStart:OnDragStart,OnDrag:OnDrag,OnDragEnd:OnDragEnd,
			},
			{
				"type":BtnIcon(app,20,20,appCfg.sharedAssets+"/size_all.svg",0),"x":"50%","y":"50%","anchorX":1,"anchorY":1,drag:2,
				tip:(($ln==="CN")?("初始尺寸：填充父元素"):/*EN*/("Init Size: Fill Parent")),sizeCode:"size_all",
				OnDragStart:OnDragStart,OnDrag:OnDrag,OnDragEnd:OnDragEnd,
			},
			{
				"type":BtnIcon(app,20,20,appCfg.sharedAssets+"/size_h.svg",0),"x":">calc(50% + 24px)","y":"50%","anchorX":1,"anchorY":1,drag:2,
				tip:(($ln==="CN")?("初始尺寸：填满父元素高度"):/*EN*/("Init Size: Fill Parent Height")),sizeCode:"size_h",
				OnDragStart:OnDragStart,OnDrag:OnDrag,OnDragEnd:OnDragEnd,
			},
		],
		bindBtn:function(btn,hudDef){
			ownerBtn=btn;
			def=hudDef
		}
	};
	return cssVO;
};
/*}#1GAP55UKN0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxNewGears=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GAP55UKN7LocalVals*/
	let appPrj,editPrj;
	let sizeBox,sizeBoxOwner;
	appPrj=app.prj;
	editPrj=appPrj.codyPrj;
	/*}#1GAP55UKN7LocalVals*/
	
	/*#{1GAP55UKN7PreState*/
	/*}#1GAP55UKN7PreState*/
	/*#{1GAP55UKN7PostState*/
	/*}#1GAP55UKN7PostState*/
	cssVO={
		"hash":"1GAP55UKN7",nameHost:true,
		"type":"tree","id":"BoxNewGears","x":0,"y":0,"w":"100%","h":"100%","contentLayout":"flex-y","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"",
		/*#{1GAP55UKN7ExtraCSS*/
		/*}#1GAP55UKN7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GAP55UKN7Create*/
			self.initList();
			/*}#1GAP55UKN7Create*/
		},
		/*#{1GAP55UKN7EndCSS*/
		/*}#1GAP55UKN7EndCSS*/
	};
	/*#{1GAP55UKN7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.nodeDef=function(obj,node){
		if(obj.icon){
			return cssHud(app,obj,hud=>{
				//TODO: Code this:
			},self);
		}else{
			return cssCatalog(app,obj,node,self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getSubObjs=function(obj,node){
		return EditHudObj.getCatalogDefs(obj.catalog);
	};
	
	//-------------------------------------------------------------------
	cssVO.initList=function(){
		let list,listBox,i,n,catalog,node;
		listBox=this;
		listBox.clear();
		list=[
			{name:(($ln==="CN")?("基础控件"):/*EN*/("Basic")),catalog:"Basic"},
			{name:(($ln==="CN")?("文本控件"):/*EN*/("Texts")),catalog:"Texts"},
			{name:(($ln==="CN")?("按钮控件"):/*EN*/("Buttons")),catalog:"Buttons"},
			{name:(($ln==="CN")?("输入控件"):/*EN*/("Inputs")),catalog:"Inputs"},
			{name:(($ln==="CN")?("媒体控件"):/*EN*/("Medias")),catalog:"Medias"},
			{name:(($ln==="CN")?("控件容器"):/*EN*/("Containers")),catalog:"Containers"},
			{name:(($ln==="CN")?("视图控件"):/*EN*/("Views")),catalog:"Views"},
			{name: (($ln==="CN")?("内部组件"):/*EN*/("Gears")), catalog: "Gears"},
			{name: (($ln==="CN")?("外部组件"):/*EN*/("Extern gears")), catalog: "ExternGears"}
		];
		n=list.length;
		for(i=0;i<n;i++){
			catalog=list[i];
			node=listBox.addNode(catalog,null);
			if(i===0) {
				listBox.openNode(node);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.bindSizeBox=function(btn,def){
		if(!sizeBox){
			sizeBox=btn.appendNewChild(cssSizeBox(app,self));
			sizeBox.hold();
		}else{
			if(btn===sizeBoxOwner){
				return;
			}
			if(sizeBoxOwner){
				sizeBoxOwner.removeChild(sizeBox);
			}
			btn.appendChild(sizeBox);
		}
		sizeBoxOwner=btn;
		sizeBox.bindBtn(btn,def);
	};
	
	//------------------------------------------------------------------------
	cssVO.unbindSizeBox=function(btn){
		if(sizeBoxOwner===btn){
			sizeBoxOwner.removeChild(sizeBox);
			sizeBoxOwner=null;
		}
	};
	
	//-------------------------------------------------------------------
	cssVO.OnHudDragStart=function(def,e){
		theForge||(theForge=editPrj.theForge);
		theForge.OnNewHudDragStart(def,e);
	};
	
	//-------------------------------------------------------------------
	cssVO.OnHudDrag=function(e){
		theForge.OnNewHudDrag(e);
	};
	
	//-------------------------------------------------------------------
	cssVO.OnHudDragEnd=function(e,cancel){
		theForge.OnNewHudDragEnd(e,cancel);
	};
	/*}#1GAP55UKN7PostCSSVO*/
	return cssVO;
};
/*#{1GAP55UKN7ExCodes*/
/*}#1GAP55UKN7ExCodes*/

BoxNewGears.gearExport={
	framework: "vfact",
	hudType: "tree",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1GAP55UKN0ExGearInfo*/
	/*}#1GAP55UKN0ExGearInfo*/
};
/*#{1GAP55UKN0EndDoc*/
/*}#1GAP55UKN0EndDoc*/

export default BoxNewGears;
export{BoxNewGears};
