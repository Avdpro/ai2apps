//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HHQ15QEF0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {EditAttr} from "../EditAttr.js";
import {editFonts} from "../edithud/EditHudFont.js";
/*}#1HHQ15QEF0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALFunction=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GAHN8JGD7LocalVals*/
	let attrDef;
	let mode,menuItems;
	attrDef=attrObj.def;
	if(attrDef.editType==="fontChoice"){
		mode="Font";
	}else if(attrDef.editType==="fontSize"){
		mode="FontSize";
	}else if(attrDef.type==="mockup"){
		mode="Mockup";
	}else if(attrDef.editType==="language"){
		mode="Language";
	}else{
		mode="Choice";
	}
	menuItems=null;
	icon=attrObj.icon||attrDef.icon||null;
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GAHN8JGD7LocalVals*/
	
	/*#{1GAHN8JGD7PreState*/
	/*}#1GAHN8JGD7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":"",
		/*#{1GAHN8JGD5ExState*/
		/*}#1GAHN8JGD5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GAHN8JGD7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	if(attrObj.entrySeg){
		if(attrObj.entrySeg.inGearDoc){
			state.value=attrObj.entrySeg.getAttrVal("id");
		}else{
			state.value="";
		}
	}else{
		state.value="";
	}
	/*}#1GAHN8JGD7PostState*/
	cssVO={
		"hash":"1GAHN8JGD7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GAHO6RVO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GAHO913P0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GAHOBANN0",
				"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
				/*#{1GAHOBANN0Codes*/
				OnClick(){
					self.showMenu();
				}
				/*}#1GAHOBANN0Codes*/
			},
			{
				"hash":"1GAHO97S50",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GAHOAOU70",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":"","h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(`${state.value}`),state),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","alignV":1,
			},
			{
				"hash":"1GAMJCOSD0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GAHN8JGD7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GAHN8JGD7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":true
				},
				/*TxtVal*/"#1GAHOAOU70":{
					"display":0
				},
				/*#{1GAHO48HT0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GAHO48HT0Code*/
			},"editOff":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":false
				},
				/*TxtVal*/"#1GAHOAOU70":{
					"display":1
				},
				/*#{1GAHO4CNK0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GAHO4CNK0Code*/
			},"showEdit":{
				/*#{1GDV43B6P0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV43B6P0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GAHN8JGD7Create*/
			box.regAttrLine(attrObj,self);
			boxBG=self.BoxBG;
			attrObj.traceOn(self.OnAttrChange);
			
			if(mode==="Font"){
				self.BtnMenu.hint=`Append a font candidate: hold "Ctrl" key while choosing font.`;
			}
			/*}#1GAHN8JGD7Create*/
		},
		/*#{1GAHN8JGD7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					app.showStateText(`${state.name}: ${attrDef.info}`);
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GAHN8JGD7EndCSS*/
	};
	/*#{1GAHN8JGD7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		if(attrObj.entrySeg){
			if(attrObj.entrySeg.inGearDoc){
				state.value=attrObj.entrySeg.getAttrVal("id");
			}else{
				state.value="";
			}
		}else{
			state.value="";
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=function(){
		let doc=attrObj.doc;
		let def=attrDef;
		let segsList,i,n,seg,segDef;
		segsList=doc.segsList;
		menuItems=[];
		n=segsList.length;
		menuItems.push({text:"Clear flow-function",seg:"",icon:appCfg.sharedAssets+"/trash.svg"});
		for(i=0;i<n;i++){
			seg=segsList[i];
			segDef=seg.objDef;
			if(segDef.name==="Entry"){
				let name;
				name=seg.getAttrVal("id");
				if(name){
					menuItems.push({text:name,seg:seg,icon:appCfg.sharedAssets+"/func.svg"});
				}
			}
		}
		menuItems.push({text:"Create new flow-function",seg:null,icon:appCfg.sharedAssets+"/additem.svg"});
		self.state=0;
		app.showDlg(DlgMenu,{
			hud:self.BtnMenu,items:menuItems,
			callback:(item,evt)=>{
				if(item){
					//Code this:
					if(item.seg){
						attrObj.entrySeg=item.seg;
						box.setAttrByText(attrObj.getAttr("seg"),item.seg.jaxId);
					}else if(item.seg===null){
						let newSeg;
						//Add new seg
						newSeg=doc.createNewFunctionSeg(attrObj);
						if(newSeg){
							attrObj.entrySeg=newSeg;
							box.setAttrByText(attrObj.getAttr("seg"),newSeg.jaxId);
						}
					}else{
						//Clear seg:
						attrObj.entrySeg=null;
						box.setAttrByText(attrObj.getAttr("seg"),"");
					}
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		let doc,editBox,seg;
		if(evt.button===0){
			doc=attrObj.doc;
			seg=attrObj.entrySeg;
			if(!seg || !seg.inGearDoc){
				return;
			}
			if(doc && doc.dataDoc){
				editBox=doc.dataDoc.editBox;
				if(editBox){
					editBox.focus();
					editBox.gotoLine(seg?seg.jaxId:attrObj.jaxId);
					doc.gotoMarkAfterUpdateDoc=seg?seg.jaxId:attrObj.jaxId;//This is ensure code foucsed after add this attr.
				}
			}
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(raw=false){
		self.showMenu();
	};
	//------------------------------------------------------------------------
	/*}#1GAHN8JGD7PostCSSVO*/
	return cssVO;
};
/*#{1GAHN8JGD7ExCodes*/
EditAttrsBox.regAttrBox("fixedFunc",EALFunction);
/*}#1GAHN8JGD7ExCodes*/


/*#{1HHQ15QEF0EndDoc*/
/*}#1HHQ15QEF0EndDoc*/

export default EALFunction;
export{EALFunction};
