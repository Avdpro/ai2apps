//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GAIT3V7R0StartDoc*/
import {tabFS} from "/@tabos";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {EALGroup} from "./EALGroup.js";
import {LineCard} from "./LineCard.js";
import pathLib from "/@path";
/*}#1GAIT3V7R0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgNewGear=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxDlg,boxHeader;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GAIT3V7R7LocalVals*/
	let dlgVO,mode,baseDir,appPrj;
	let curLine=null;
	let listBox=null;
	let edName=null;
	let txtInfo=null;
	appPrj=app.prj;
	/*}#1GAIT3V7R7LocalVals*/
	
	/*#{1GAIT3V7R7PreState*/
	/*}#1GAIT3V7R7PreState*/
	/*#{1GAIT3V7R7PostState*/
	/*}#1GAIT3V7R7PostState*/
	cssVO={
		"hash":"1GAIT3V7R7",nameHost:true,
		"type":"box","x":0,"y":0,"w":380,"h":650,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,"borderColor":cfgColor.lineBodySub,
		"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
		children:[
			{
				"hash":"1GAIT6UTS0",
				"type":"hud","id":"BoxDlg","x":0,"y":0,"w":"100%","h":"","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1IA6UJNL50",
						"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"styleClass":"",
						children:[
							{
								"hash":"1IA6ULIFR0",
								"type":"text","x":10,"y":0,"w":"","h":"100%","uiEvent":0,"styleClass":"","color":cfgColor["fontBodySub"],"text":(($ln==="CN")?("新建控件文件"):("New Component File")),
								"fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1IA6VO3FR0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 28px)","y":"50%","anchorY":1,
								"OnClick":function(event){
									/*#{1IA6VO3FS3FunctionBody*/
									self.close();
									/*}#1IA6VO3FS3FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1IA6VPVFB0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["gntLine"],
					},
					{
						"hash":"1GAIT6UTT9",
						"type":"hud","id":"BoxInfo","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAIT6UTU0",
								"type":"text","id":"TxtInfo","x":10,"y":0,"w":"","h":txtSize.smallMid,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
								"text":(($ln==="CN")?("请输入新组件文件名："):("Input new component file name:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"",
							}
						],
					},
					{
						"hash":"1GAIT6UTU6",
						"type":"hud","id":"BoxName","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAIT6UTU8",
								"type":"edit","id":"EdName","x":20,"y":"FH/2","w":">calc(100% - 100px)","h":25,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"placeHolder":(($ln==="CN")?("文件名"):("File name")),"color":cfgColor["fontBody"],"background":cfgColor.body,"fontSize":txtSize.smallMid,"outline":0,
								"border":[0,0,1,0],"borderColor":cfgColor.lineBody,
								/*#{1GAIT6UTU8Codes*/
								OnUpdate(){
									self.doCreateGearDoc();
								},
								OnInput(){
									self.updateBtn();
								}
								/*}#1GAIT6UTU8Codes*/
							}
						],
					},
					{
						"hash":"1GAITDQE00",
						"type":"hud","id":"BoxInfo2","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAITDQE02",
								"type":"text","x":10,"y":0,"w":"","h":txtSize.smallMid,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("选择组件基本类型："):("Choose component base Type:")),
								"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					},
					{
						"hash":"1IA6U6D4D0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["gntLine"],
					},
					{
						"hash":"1GAIT6UTT5",
						"type":"hud","id":"TypeList","position":"relative","x":0,"y":0,"w":"100%","h":500,"overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
					},
					{
						"hash":"1IA6U9SE00",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["gntLine"],
					},
					{
						"hash":"1GAIT6UTV4",
						"type":"hud","id":"BoxBtns","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAIT6UTV11",
								"type":BtnText("",100,24,"Button",false,""),"id":"BtnAdd","x":">calc(50% - 60px)","y":"50%","anchorX":1,"anchorY":1,"text":(($ln==="CN")?("创建文件"):("Create File")),
								"corner":3,
								/*#{1GAIT6UTV11Codes*/
								OnClick(){
									self.doCreateGearDoc();
								}
								/*}#1GAIT6UTV11Codes*/
							},
							{
								"hash":"1GAIT6UU00",
								"type":BtnText("warning",100,24,"Button",false,""),"id":"BtnClose","x":">calc(50% + 60px)","y":"50%","anchorX":1,"anchorY":1,"text":(($ln==="CN")?("关闭"):("Close")),
								"corner":3,
								/*#{1GAIT6UU00Codes*/
								OnClick(){
									self.close();
								}
								/*}#1GAIT6UU00Codes*/
							}
						],
					}
				],
			}
		],
		/*#{1GAIT3V7R7ExtraCSS*/
		/*}#1GAIT3V7R7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxDlg=self.BoxDlg;boxHeader=self.BoxHeader;
			/*#{1GAIT3V7R7Create*/
			VFACT.applyMoveDrag(boxHeader,self);
			listBox=self.TypeList;
			edName=self.EdName;
			txtInfo=self.TxtInfo;
			/*}#1GAIT3V7R7Create*/
		},
		/*#{1GAIT3V7R7EndCSS*/
		/*}#1GAIT3V7R7EndCSS*/
	};
	/*#{1GAIT3V7R7PostCSSVO*/
	function getHudCatalogGroup(catalogName,open){
		let defs;
		defs=EditHudObj.getCatalogDefs(catalogName);
		if(!defs || !defs.length){
			return null;
		}
		return {
			group:1,name:catalogName,defs:defs,open:!!open
		};
	};
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let types,x,group;
		dlgVO=vo;
		baseDir=vo.dir||"";
		types=[];
		curLine=null;
		listBox.clearChildren();
		if(vo.mode==="view"){
			types.push(getHudCatalogGroup("View",true));
			types.push(getHudCatalogGroup("Raw",true));
			group=getHudCatalogGroup("ViewTemplates",true);
			if(group && group.defs.length>0){
				types.push(group);
			}
		}else{
			types.push(getHudCatalogGroup("Raw",true));
			group=getHudCatalogGroup("GearTemplates",true);
			if(group && group.defs.length>0){
				types.push(group);
			}
		}
		
		self.addTypes(types,self.TypeList);
		//TODO: Add more catalogs
		self.BtnAdd.enable=0;
		if(vo.x>=0){
			let rect,hud;
			hud=vo.hud||vo.uiObj;
			if(hud){
				rect=hud.getBoundingClientRect();
				x=rect.x+vo.x;
				if(vo.align===2){
					x-=self.w;
				}
			}
			self.x=x;
		}
		txtInfo.text=(($ln==="CN")?("输入组件名称:"):/*EN*/("Input component gear name:"));
		let h=boxDlg.h;
		self.h=h-50;
		self.animate({type:"pose",h:h,time:80});
	};
	
	//------------------------------------------------------------------------
	cssVO.addTypes=function(types,ownerBox){
		let stub,css,line;
		function addTypeLine(stub,ownerBox){
			if(stub.group){
				css=EALGroup(app,stub,self,ownerBox);
				line=ownerBox.appendNewChild(css);
				self.addTypes(stub.defs,line.boxLines);
				if(stub.open){
					line.open();
				}
			}else{
				css={
					type:LineCard(app,stub,self),stub:stub,
					OnClick(){
						self.focusLine(this);
					}
				};
				line=ownerBox.appendNewChild(css);
			}
		}
		for(stub of types){
			addTypeLine(stub,ownerBox);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focusLine=function(line){
		if(line===curLine){
			return;
		}
		if(curLine){
			curLine.showFace("blur");
		}
		curLine=line;
		if(curLine){
			curLine.showFace("focus");
		}
		edName.focus();
		self.updateBtn();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateBtn=function(){
		let name;
		name=edName.text;
		if(!name || !curLine){
			self.BtnAdd.enable=0;
			return;
		}
		self.BtnAdd.enable=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.doCreateGearDoc=async function(){
		let name,stub,path,entry,ext;
		if(!curLine){
			return;
		}
		name=edName.text;
		if(!name){
			return;
		}
		ext=pathLib.extname(name);
		if(!ext){
			edName.text+=".js";
			return;
		}
		
		//Check file path:
		path=pathLib.join(appPrj.path,baseDir,name);
		entry=await tabFS.getEntry(path);
		if(entry){
			window.alert(`File ${path} is already exist.`);
			self.BtnAdd.enable=0;
			return;
		}
		self.close();
		if(dlgVO.callback){
			stub=curLine.stub;
			dlgVO.callback(name,path,stub,false);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		app.closeDlg(self);
	};
	/*}#1GAIT3V7R7PostCSSVO*/
	return cssVO;
};
/*#{1GAIT3V7R7ExCodes*/
/*}#1GAIT3V7R7ExCodes*/


/*#{1GAIT3V7R0EndDoc*/
/*}#1GAIT3V7R0EndDoc*/

export default DlgNewGear;
export{DlgNewGear};
