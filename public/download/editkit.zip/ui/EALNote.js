//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HCM67NJG0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgLongText} from "./DlgLongText.js";
import markdownit from "/@markdownit";
/*}#1HCM67NJG0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALNote=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtVal,frameMD,boxMD;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1HCM67NJG1LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	icon=attrObj.icon||attrDef.icon||(attrDef.def?attrDef.def.icon:null)||"";
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1HCM67NJG1LocalVals*/
	
	/*#{1HCM67NJG1PreState*/
	/*}#1HCM67NJG1PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":""+attrObj.val,"hyper":attrObj.hyper,
		"valText":attrObj.valText,"localized":!!attrObj.localize,
		/*#{1HCM67NJG7ExState*/
		/*}#1HCM67NJG7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HCM67NJG1PostState*/
	/*}#1HCM67NJG1PostState*/
	cssVO={
		"hash":"1HCM67NJG1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,2,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HCM6QQRK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1HCM6BQSM0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1HCM6J0650",
						"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
					},
					{
						"hash":"1HCM6JSGR0",
						"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":"100%","margin":[0,3,0,2],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,"autoW":true,
					}
				],
			},
			{
				"hash":"1HCM6L8NU0",
				"type":"text","id":"txtVal","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto","margin":[0,0,5,0],"padding":[0,5,0,15],"minW":"",
				"minH":16,"maxW":"","maxH":100,"styleClass":"","color":cfgColor["fontBodySub"],"text":$P(()=>(`${state.value}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"attached":!attrObj.def.markdown,
			},
			{
				"hash":"1HFMM1U1T0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
				"attached":!!attrObj.def.markdown,
			},
			{
				"hash":"1HFMKRLEK0",
				"type":"hud","id":"FrameMD","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto","padding":[5,5,10,15],"minW":"","minH":250,"maxW":"",
				"maxH":360,"styleClass":"","attached":!!attrObj.def.markdown,
				children:[
					{
						"hash":"1HFMLN7NI0",
						"type":"hud","id":"BoxMD","x":0,"y":0,"w":"125%","h":"","scale":0.8,"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
					}
				],
			},
			{
				"hash":"1HCM6M95J0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1HCM67NJG1ExtraCSS*/
		attrObj:attrObj,
		/*}#1HCM67NJG1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1HCM6QQRK0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1HCM6QQRK0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1HCM6QQRK0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1HCM6QQRK0":{
					"shadow":true
				}
			},"editOff":{
				/*BoxBG*/"#1HCM6QQRK0":{
					"shadow":false
				}
			},"showEdit":{
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtVal=self.txtVal;frameMD=self.FrameMD;boxMD=self.BoxMD;
			/*#{1HCM67NJG1Create*/
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			if(attrObj.def.markdown){
				let content=markdownit().render(attrObj.valText);
				boxMD.webObj.innerHTML=content;
			}
			/*}#1HCM67NJG1Create*/
		},
		/*#{1HCM67NJG1EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1HCM67NJG1EndCSS*/
	};
	/*#{1HCM67NJG1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=""+attrObj.val;
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
		state.localized=!!attrObj.localize;
		if(attrObj.def.markdown){
			let content=markdownit().render(attrObj.valText);
			boxMD.webObj.innerHTML=content;
			return boxMD;
		}
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(attrObj.startEdit){
			attrObj.startEdit(attrObj,self);
		}else{
			if(attrObj.localize){
				app.showLocalizerDlg({attrObj:attrObj,hud:self,box:box});
				//app.showDlg(DlgEditLocString,{attrObj:attrObj,hud:self,box:box});
			}else{
				//Show long text editor:
				let text;
				let attrDef=attrObj.def;
				let attrName=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name)
				text=attrObj.valText;
				app.showDlg(DlgLongText,{
					text:text,hud:self,readOnly:attrObj.def.readOnly===true,
					title:(($ln==="CN")?(`编辑：${attrName}`):/*EN*/(`Edit: ${attrName}`)),
					next(apply,text){
						if(apply){
							box.setAttrByText(attrObj,text);
						}
					}
				});
			}
		}
	};
	/*}#1HCM67NJG1PostCSSVO*/
	return cssVO;
};
/*#{1HCM67NJG1ExCodes*/
EditAttrsBox.regAttrBox("note",EALNote);
/*}#1HCM67NJG1ExCodes*/


/*#{1HCM67NJG0EndDoc*/
/*}#1HCM67NJG0EndDoc*/

export default EALNote;
export{EALNote};
