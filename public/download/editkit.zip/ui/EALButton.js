//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HVLA7VOM0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
import {EditAttr} from "../EditAttr.js";
import {editFonts} from "../edithud/EditHudFont.js";
/*}#1HVLA7VOM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALButton=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnAction;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GAHN8JGD7LocalVals*/
	let attrDef,attrObjDef;
	let mode,menuItems;
	attrDef=attrObj.def;
	attrObjDef=attrObj.objDef;
	menuItems=null;
	icon=attrObj.icon||attrDef.icon||null;
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GAHN8JGD7LocalVals*/
	
	/*#{1GAHN8JGD7PreState*/
	/*}#1GAHN8JGD7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val2ShowText?(attrObj.val2ShowText(attrObj.val)):attrObj.val,
		"hyper":attrObj.hyper,"valText":attrObj.valText,
		/*#{1GAHN8JGD5ExState*/
		/*}#1GAHN8JGD5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GAHN8JGD7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GAHN8JGD7PostState*/
	cssVO={
		"hash":"1GAHN8JGD7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1GAHO6RVO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GAMJCOSD0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			},
			{
				"hash":"1HVLAA06H0",
				"type":BtnText("",120,cfgSize.attrLineH-6,state.name,false,""),"id":"BtnAction","position":"relative","x":"50%","y":0,"anchorX":1,"corner":3,
				"OnClick":function(event){
					/*#{1HVLAKRD90FunctionBody*/
					self.doAction();
					/*}#1HVLAKRD90FunctionBody*/
				},
			}
		],
		/*#{1GAHN8JGD7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GAHN8JGD7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.body
				}
			},"over":{
			},"down":{
			},"editOn":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":true
				},
				/*#{1GAHO48HT0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GAHO48HT0Code*/
			},"editOff":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":false
				},
				/*#{1GAHO4CNK0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GAHO4CNK0Code*/
			},"showEdit":{
				/*#{1GDV43B6P0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV43B6P0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnAction=self.BtnAction;
			/*#{1GAHN8JGD7Create*/
			box.regAttrLine(attrObj,self);
			boxBG=self.BoxBG;
			attrObj.traceOn(self.OnAttrChange);
			
			if(mode==="Font"){
				self.BtnMenu.hint=`Append a font candidate: hold "Ctrl" key while choosing font.`;
			}
			/*}#1GAHN8JGD7Create*/
		},
		/*#{1GAHN8JGD7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GAHN8JGD7EndCSS*/
	};
	/*#{1GAHN8JGD7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
	};
	
	//------------------------------------------------------------------------
	cssVO.doAction=async function(){
		let actionFunc;
		actionFunc=attrDef.OnAction||(attrObjDef?attrObjDef.OnAtction:null);
		if(!actionFunc){
			return;
		}
		actionFunc(attrObj,btnAction,self,box);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		//Do nothing;
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(raw=false){
		//Do nothing.
	};
	//------------------------------------------------------------------------
	/*}#1GAHN8JGD7PostCSSVO*/
	return cssVO;
};
/*#{1GAHN8JGD7ExCodes*/
EditAttrsBox.regAttrBox("action",EALButton);
/*}#1GAHN8JGD7ExCodes*/


/*#{1HVLA7VOM0EndDoc*/
/*}#1HVLA7VOM0EndDoc*/

export default EALButton;
export{EALButton};
