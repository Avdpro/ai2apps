//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIOutlet} from "./BoxAIOutlet.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HC1VRLSV0StartDoc*/
import {EditAISeg} from "../aiagent/EditAISeg.js";
import {SegOutletDef} from "../aiagent/EditAISegDefs.js";
/*}#1HC1VRLSV0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAISeg=function(seg,canvas){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,boxNames,txtID,boxOutlets,boxHeader,txtInput,boxMark,boxMarkImg;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=appCfg.sharedAssets+"/aichat.svg";
	let app=null;
	let bgColor=cfgColor["body"];
	
	/*#{1HC1VRLSV1LocalVals*/
	app=VFACT.app;
	let editPrj=seg.prj;
	let outletsVal=seg.outletsVal;
	let headerRect={x:0,y:0,width:0,height:0};
	let focused=false;
	let boxSegs=canvas.BoxSegs;
	icon=seg.objDef.segIcon||seg.objDef.icon;
	if(icon[0]!=="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	let dirVal=null;
	let mini=false;
	let note=false;
	let dragMeta=null;
	let iconImage=null;
	let reverseOutlets=seg.objDef.reverseOutlets||false;
	
	/*}#1HC1VRLSV1LocalVals*/
	
	/*#{1HC1VRLSV1PreState*/
	/*}#1HC1VRLSV1PreState*/
	state={
		"segId":"ChatSeg01","mark":"trash.svg",
		/*#{1HC1VRLSV7ExState*/
		/*}#1HC1VRLSV7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HC1VRLSV1PostState*/
	state.segId=seg.nameVal.val||seg.idVal.val||"- - -";
	if(seg.isNote){
		bgColor=[255,248,235,1];
	}
	state.mark=seg.getAttrVal("segMark");
	/*}#1HC1VRLSV1PostState*/
	cssVO={
		"hash":"1HC1VRLSV1",nameHost:true,
		"type":"button","x":48,"y":65,"w":"","h":"","anchorY":1,"padding":[5,5,5,20],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"itemsAlign":1,"traceSize":true,
		"seg":seg,
		children:[
			{
				"hash":"1HC1VS1VT0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":2,"borderColor":cfgColor["fontBody"],"corner":[60,8,8,60],
			},
			{
				"hash":"1HC20CG5T0",
				"type":"hud","id":"BoxNames","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"minW":2,"minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","traceSize":true,
				children:[
					{
						"hash":"1HC20RD040",
						"type":"text","id":"TxtID","position":"relative","x":0,"y":0,"w":"","h":"","minW":30,"minH":"","maxW":100,"maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.segId),state),"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,
					}
				],
				"OnSize":function(){
					/*#{1HC2OS57H0FunctionBody*/
					self.adjustSize();
					/*}#1HC2OS57H0FunctionBody*/
				},
			},
			{
				"hash":"1HC210R4F0",
				"type":"hud","id":"BoxOutlets","position":"relative","x":0,"y":0,"w":"","h":"","minW":5,"minH":16,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				"traceSize":true,
				children:[
				],
				"OnSize":function(){
					/*#{1HC2OSS990FunctionBody*/
					self.adjustSize();
					/*}#1HC2OSS990FunctionBody*/
				},
			},
			{
				"hash":"1HC21AFC50",
				"type":"box","id":"BoxHeader","x":0,"y":"50%","w":38,"h":38,"anchorX":1,"anchorY":1,"overflow":1,"cursor":"move","padding":3,"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor["body"],"border":2,"borderColor":cfgColor["fontBody"],"corner":20,
				children:[
					{
						"hash":"1HC22I4C60",
						"type":"box","id":"BoxIcon","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"maskImage":icon,
					}
				],
			},
			{
				"hash":"1HC21N4GE0",
				"type":"box","id":"BoxAddOutlet","x":"100%","y":"100%","w":25,"h":25,"anchorX":1,"anchorY":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":2,"corner":15,"attached":(!!seg.outletsVal)&&(seg.outletsVal.objDef.allowExtraAttr!==false),
				children:[
					{
						"hash":"1HC21P9R20",
						"type":BtnIcon("front",16,0,appCfg.sharedAssets+"/add.svg",null),"x":"50%","y":"50%","anchorX":1,"anchorY":1,"padding":0,
						"tip":(($ln==="CN")?("添加输出节点"):("Add outlet")),
						"OnClick":function(event){
							/*#{1HC539E130FunctionBody*/
							self.addOutlet(this);
							/*}#1HC539E130FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HCP09U210",
				"type":"text","id":"TxtInput","x":"50%","y":-2,"w":"90%","h":txtSize.mid,"anchorX":1,"anchorY":2,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["primary"],"text":"1+1=?","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignH":1,"alignV":1,"ellipsis":true,
			},
			{
				"hash":"1I0EEMCTP0",
				"type":"box","id":"BoxMark","x":5,"y":">calc(50% + 5px)","w":24,"h":25,"display":$P(()=>(!!state.mark),state),"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor["body"],"border":2,"borderColor":cfgColor["fontBody"],"corner":8,
				children:[
					{
						"hash":"1IL8GLNF90",
						"type":"image","id":"BoxMarkImg","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"styleClass":"","image":$P(()=>(appCfg.sharedAssets+"/"+state.mark),state),
						"fitSize":true,
					}
				],
			}
		],
		/*#{1HC1VRLSV1ExtraCSS*/
		headerRect:headerRect,
		/*}#1HC1VRLSV1ExtraCSS*/
		faces:{
			"up":{
				/*#{1HC21QQOV0PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC21QQOV0PreCode*/
				/*BoxBG*/"#1HC1VS1VT0":{
					"background":bgColor
				}
			},"over":{
				/*#{1HC21QQOV2PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC21QQOV2PreCode*/
				/*BoxBG*/"#1HC1VS1VT0":{
					"background":cfgColor["iconBtnOver"]
				}
			},"down":{
				/*#{1HC21QQOV4PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC21QQOV4PreCode*/
				/*BoxBG*/"#1HC1VS1VT0":{
					"background":cfgColor["hot"]
				}
			},"focus":{
				/*BoxBG*/"#1HC1VS1VT0":{
					"background":cfgColor["hot"],"border":3,"borderColor":cfgColor["fontBody"]
				},
				/*BoxAddOutlet*/"#1HC21N4GE0":{
					"display":1
				},
				/*#{1HC21QQOV6Code*/
				$(){
					focused=true;
				},
				/*}#1HC21QQOV6Code*/
			},"blur":{
				/*BoxBG*/"#1HC1VS1VT0":{
					"background":bgColor,"border":2
				},
				/*BoxAddOutlet*/"#1HC21N4GE0":{
					"display":0
				},
				/*#{1HC21QQOV8Code*/
				$(){
					focused=false;
				},
				/*}#1HC21QQOV8Code*/
			},"picked":{
				/*BoxHeader*/"#1HC21AFC50":{
					"borderColor":cfgColor["primary"],"border":4
				}
			},"!picked":{
				/*BoxHeader*/"#1HC21AFC50":{
					"border":2,"borderColor":cfgColor["fontBody"]
				}
			},"mini":{
				"#self":{
					"padding":[5,5,5,0]
				},
				/*TxtID*/"#1HC20RD040":{
					"display":0
				},
				"#1HC213TJ30":{
					"face":"mini"
				},
				/*BoxHeader*/"#1HC21AFC50":{
					"w":28,"h":28
				},
				/*#{1HCA90GIS0Code*/
				$(){
					let box=boxOutlets.children[0];
					mini=true;
					if(box){
						box.showFace("mini");
					}
				},
				/*}#1HCA90GIS0Code*/
			},"L2R":{
				"#self":{
					"rotate":0
				},
				/*#{1HCAAGFTE0Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("L2R");
					}
					seg.pathDir=[-1,0];
				},
				/*}#1HCAAGFTE0Code*/
			},"R2L":{
				"#self":{
					"rotate":180
				},
				/*#{1HCAAENTN0Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("R2L");
					}
					seg.pathDir=[1,0];
				},
				/*}#1HCAAENTN0Code*/
			},"T2B":{
				"#self":{
					"rotate":90
				},
				/*#{1HCAAGFTE3Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("T2B");
					}
					seg.pathDir=[0,-1];
				},
				/*}#1HCAAGFTE3Code*/
			},"B2T":{
				"#self":{
					"rotate":270
				},
				/*#{1HCAAGFTE5Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("B2T");
					}
					seg.pathDir=[0,1];
				},
				/*}#1HCAAGFTE5Code*/
			},"traced":{
				/*BoxHeader*/"#1HC21AFC50":{
					"background":cfgColor["primary"]
				},
				/*BoxIcon*/"#1HC22I4C60":{
					"background":cfgColor["fontPrimary"]
				},
				/*TxtInput*/"#1HCP09U210":{
					"display":1
				},
				/*#{1HCMBQK1E0Code*/
				$(){
					let text=""+(seg.lastTracedInput||"(Input: NA)");
					text=text.substring(0,200);
					txtInput.text=text;
				}
				/*}#1HCMBQK1E0Code*/
			},"!traced":{
				/*BoxHeader*/"#1HC21AFC50":{
					"background":cfgColor["body"]
				},
				/*BoxIcon*/"#1HC22I4C60":{
					"background":cfgColor["fontBody"]
				},
				/*TxtInput*/"#1HCP09U210":{
					"display":0
				}
			},"note":{
				"#self":{
					"minH":30
				},
				/*BoxOutlets*/"#1HC210R4F0":{
					"display":0
				},
				/*#{1HFMISL2B0Code*/
				$(){
					note=true;
				}
				/*}#1HFMISL2B0Code*/
			},"selected":{
				/*BoxBG*/"#1HC1VS1VT0":{
					"border":3,"borderColor":cfgColor["lineBodyLit"]
				}
			},"!selected":{
				/*BoxBG*/"#1HC1VS1VT0":{
					"border":2,"borderColor":[0,0,0,1]
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;boxNames=self.BoxNames;txtID=self.TxtID;boxOutlets=self.BoxOutlets;boxHeader=self.BoxHeader;txtInput=self.TxtInput;boxMark=self.BoxMark;boxMarkImg=self.BoxMarkImg;
			/*#{1HC1VRLSV1Create*/
			seg.bindLiveObj(self);
			seg.traceOn(self.syncSegObj);
			if(outletsVal){
				outletsVal.on("AttrAdd",self.OnOutletAdd);
				outletsVal.on("AttrRemove",self.OnOutletRemove);
				outletsVal.on("AttrMoveUp",self.OnOutletMoveUp);
				outletsVal.on("AttrMoveDown",self.OnOutletMoveDown);
				outletsVal.on("AttrReplace",self.OnOutletReplace);
			}
			dragMeta=VFACT.applyMoveDrag(boxHeader,self);
			//dragMeta=VFACT.applyMoveDrag(self,self);
			dragMeta.setCallbacks((...args)=>{dragMeta.setScale(1.0/canvas.zoom,1.0/canvas.zoom);canvas.OnSegDragStart(...args)},null,canvas.OnSegDragEnd,canvas.OnSegDrag);
			self.initOutlets();
			if(seg.isConnector){
				dirVal=seg.getAttr("dir");
				dirVal.traceOn(self.OnDirChange);
				self.showFace("mini");
				self.showFace(dirVal.val);
			}else if(seg.isNote){
				self.showFace("note");
			}
			self.adjustSize();
			if(seg.traced){
				self.showFace("traced");
			}else{
				self.showFace("!traced");
			}
			iconImage=new Image();
			iconImage.crossOrigin = "Anonymous";
			iconImage.src = icon;
			/*}#1HC1VRLSV1Create*/
		},
		/*#{1HC1VRLSV1EndCSS*/
		/*}#1HC1VRLSV1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HC2JRUAI0FunctionBody*/
		seg.dropLiveObj(self);
		seg.traceOff(self.syncSegObj);
		if(outletsVal){
			outletsVal.off("AttrAdd",self.OnOutletAdd);
			outletsVal.off("AttrRemove",self.OnOutletRemove);
			outletsVal.off("AttrMoveUp",self.OnOutletMoveUp);
			outletsVal.off("AttrMoveDown",self.OnOutletMoveDown);
			outletsVal.off("AttrReplace",self.OnOutletReplace);
		}
		if(seg.isConnector){
			dirVal.traceOff(self.OnDirChange);
		}
		/*}#1HC2JRUAI0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HEHIGL8I0FunctionBody*/
		self.renderPath();
		/*}#1HEHIGL8I0FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.setMark=async function(sender,event){
		/*#{1I0EIAQC50Start*/
		let items,item;
		items=[
			{text:"None",file:""},
			{text:"Checked",icon:appCfg.sharedAssets+"/check_fat.svg",file:"check_fat.svg"},
			{text:"Working",icon:appCfg.sharedAssets+"/working.svg",file:"working.svg"},
			{text:"Flag",icon:appCfg.sharedAssets+"/flag.svg",file:"flag.svg"},
			{text:"Notify",icon:appCfg.sharedAssets+"/event.svg",file:"event.svg"},
			{text:"Review",icon:appCfg.sharedAssets+"/faces.svg",file:"faces.svg"},
			{text:"Test",icon:appCfg.sharedAssets+"/lab.svg",file:"lab.svg"},
			{text:"Run",icon:appCfg.sharedAssets+"/run.svg",file:"run.svg"},
			{text:"Pin",icon:appCfg.sharedAssets+"/pin.svg",file:"pin.svg"},
			{text:"Bug",icon:appCfg.sharedAssets+"/lint_bug.svg",file:"lint_bug.svg"},
			{text:"Link",icon:appCfg.sharedAssets+"/link.svg",file:"link.svg"},
			{text:"Trash",icon:appCfg.sharedAssets+"/trash.svg",file:"trash.svg"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:boxHeader,
			items:items
		});
		if(!item)
			return;
		editPrj.editAttr_SetAttrByText(seg,seg.getAttr("segMark"),item.file);
		/*}#1I0EIAQC50Start*/
	};
	/*#{1HC1VRLSV1PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.syncSegObj=function(){
		let x,y;
		state.segId=seg.nameVal.val||seg.idVal.val||"- - -";
		state.mark=seg.getAttrVal("segMark");
		if(seg.traced){
			self.showFace("traced");
		}else{
			self.showFace("!traced");
		}
		x=seg.getAttrVal("x");
		y=seg.getAttrVal("y");
		if(self.x!==x || self.y!==y){
			let list,outlet;
			self.x=x;
			self.y=y;
			self.syncHeaderPose(true);
			//Update lines linked into this one:
			list=seg.linkedOutlets;
			for(outlet of list){
				outlet.renderPath();
			}
		}else{
			self.renderPath();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.adjustSize=function(){
		if(mini){
			self.w=boxNames.w+boxOutlets.w+10;
		}else if(note){
			self.w=boxNames.w+30;
		}else{
			self.w=boxNames.w+boxOutlets.w+30;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.syncHeaderPose=function(force=false){
		let webRect,cvsRect,x,y;
		cvsRect=boxSegs.getBoundingClientRect();
		webRect=boxHeader.getBoundingClientRect();
		x=webRect.x-cvsRect.x;
		y=webRect.y-cvsRect.y;
		if(force || x!==headerRect.x || y!==headerRect.y){
			headerRect.x=x;
			headerRect.y=y;
			headerRect.width=webRect.width;
			headerRect.height=webRect.height;
			self.renderPath();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.renderPath=function(){
		let list,i,n,outlet;
		list=seg.linkedOutlets;
		for(outlet of list){
			outlet.renderPath();
		}
		list=boxOutlets.children;
		n=list.length;
		for(i=0;i<n;i++){
			outlet=list[i].outlet;
			if(outlet){
				outlet.renderPath();
			}
		}
	};
	
	//************************************************************************
	//:Outlets:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.initOutlets=function(){
			if(!reverseOutlets){
				if(seg.outlet){
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(seg.outlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
				if(seg.catchlet){
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(seg.catchlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
			}
			if(outletsVal){
				let i,n,list,outlet;
				list=outletsVal.attrList;
				n=list.length;
				for(i=0;i<n;i++){
					outlet=list[i];
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(outlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
			}
			if(reverseOutlets){
				if(seg.catchlet){
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(seg.catchlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
				if(seg.outlet){
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(seg.outlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addOutlet=function(sender){
			let outletsDef,outlet,def;
			if(!seg.outletsVal){
				return;
			}
			outletsDef=seg.outletsVal.def.def;
			if(outletsDef.allowExtraAttr){
				if(outletsDef.allowExtraAttr>1 && seg.outletsVal.attrList.length>=outletsDef.allowExtraAttr){
					app.showTip(sender,(($ln==="CN")?("无法添加更多outlet"):/*EN*/("Can't add more outlets")));
					return null;
				}
				def={type:"aioutlet",def:outletsDef.elementDef,extraAttr:1,navi:"doc"};
				outlet=editPrj.editAttr_AddAttr(seg.outletsVal,def);
				//TODO: Focus this outlet:
				editPrj.setEditSubObj(outlet);
				canvas.maybeSyncSelects();
				return outlet;
			}
			return null;
		};
		
		//--------------------------------------------------------------------
		cssVO.showOutletMenu=function(menu){
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		cssVO.OnOutletAdd=function(outlet){
			if(reverseOutlets){
				let list,i,n,hud,item,pre;
				pre=null;
				list=boxOutlets.children;
				n=list.length;
				for(i=n-1;i>=0;i--){
					hud=list[i];
					item=hud.outlet;
					if(item.owner===seg){
						pre=hud;
					}else{
						break;
					}
				}
				if(pre){
					boxOutlets.insertNewBefore({
						type:BoxAIOutlet(outlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					},pre);
				}else{
					boxOutlets.appendNewChild({
						type:BoxAIOutlet(outlet,self,canvas),position:"relative",x:0,y:0,
						OnClick:function(evt){
							self.OnOutletClick(this,evt);
						}
					});
				}
			}else{
				boxOutlets.appendNewChild({
					type:BoxAIOutlet(outlet,self,canvas),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnOutletRemove=function(outlet){
			let box;
			box=outlet.liveHudObj;
			if(box){
				boxOutlets.removeChild(box);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnOutletInsert=function(outlet,idx){
			let pre;
			pre=boxOutlets.children[idx];
			if(pre){
				boxOutlets.insertNewBefore({
					type:BoxAIOutlet(outlet,self,canvas),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				},pre);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnOutletMoveUp=function(outlet){
			let box,pre;
			box=outlet.liveHudObj;
			if(box){
				pre=box.previousSibling;
				if(pre){
					box.hold();
					boxOutlets.removeChild(box);
					boxOutlets.insertBefore(box,pre);
					box.release();
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnOutletMoveDown=function(outlet){
			let next,box;
			box=outlet.liveHudObj;
			next=box.nextSibling;
			if(next){
				self.OnOutletMoveUp(next.outlet);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnOutletReplace=function(newAttr,oldAttr){
			let box;
			box=oldAttr.liveHudObj;
			if(box){
				boxOutlets.insertNewBefore({
					type:BoxAIOutlet(newAttr,self,canvas),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				},box);
				boxOutlets.removeChild(box);
			}
		};
	}
	
	//************************************************************************
	//:Connector related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnDirChange=function(){
			self.showFace(dirVal.val);
			self.renderPath();
		};
	}
	
	//************************************************************************
	//:Render snap to canvas:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.renderToCanvas=function(ctx,ox,oy){
			let rect,list,i,n,hud;
			
			//Render Round BGBox:
			rect=boxBG.getBoundingClientRect();
			rect.x-=ox;rect.y-=oy;
			ctx.fillStyle="white";
			ctx.strokeStyle="black";
			ctx.lineWidth = 2;
			ctx.beginPath();
			ctx.roundRect(rect.x,rect.y,rect.width,rect.height,[rect.height*0.5,8,8,rect.height*0.5]);
			ctx.fill();	
			ctx.stroke();	
	
			//Render Text:
			if(boxNames.display){
				rect=txtID.getBoundingClientRect();
				rect.x-=ox;rect.y-=oy;
				ctx.fillStyle="black";
				ctx.textBaseline="top";
				ctx.font = "bold 12px arial";
				ctx.fillText(txtID.text,rect.x,rect.y+1,rect.width+10);
			}
			
			//Render outlets:
			list=boxOutlets.children;
			n=list.length;
			for(i=0;i<n;i++){
				hud=list[i];
				hud.renderToCanvas(ctx,ox,oy);
			}
	
			//Render IconBox
			ctx.fillStyle="white";
			ctx.strokeStyle="black";
			ctx.lineWidth = 2;
			rect=boxHeader.getBoundingClientRect();
			rect.x-=ox;rect.y-=oy;
			ctx.beginPath();
			ctx.ellipse(rect.x+rect.width*0.5, rect.y+rect.height*0.5, rect.width*0.5, rect.width*0.5, 0, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			//Render Icon:
			ctx.drawImage(iconImage,rect.x+5,rect.y+5,rect.width-10,rect.height-10);
			
			//Render mark icon:
			if(state.mark){
				let markImg;
				markImg=boxMarkImg.imageObj;
				if(markImg){
					ctx.fillStyle="white";
					ctx.strokeStyle="black";
					ctx.lineWidth = 1;
					rect=boxMark.getBoundingClientRect();
					rect.x-=ox;rect.y-=oy;
					ctx.beginPath();
					ctx.ellipse(rect.x+rect.width*0.5, rect.y+rect.height*0.5, rect.width*0.5, rect.width*0.5, 0, 0, 2 * Math.PI);
					ctx.fill();
					ctx.stroke();
					//Render Icon:
					ctx.drawImage(markImg,rect.x+1,rect.y+1,rect.width-2,rect.height-2);
				}
			}
			
			//Render jumper icon:
			if(seg.isJumper){
				let tgtName,tgtSeg;
				tgtName=self.jumpCode;
				ctx.fillStyle="white";
				ctx.strokeStyle="black";
				ctx.lineWidth = 2;
				rect=boxHeader.getBoundingClientRect();
				rect.x-=ox;rect.y-=oy;
				ctx.beginPath();
				ctx.ellipse(rect.x+rect.width-2, rect.y, 12, 12, 0, 0, 2 * Math.PI);
				ctx.fill();
				ctx.stroke();
				if(tgtName){
					ctx.fillStyle="black";
					ctx.textAlign="center";
					const metrics = ctx.measureText(tgtName);
					const textHeight = metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;
					ctx.textBaseline="top";
					ctx.font = "bold 16px arial";
					ctx.fillText(tgtName,rect.x+rect.width-2,rect.y-textHeight/2-2);
					ctx.textAlign="start";
				}
			}

			//Render jump slot icon:
			if(self.jumpSlotCode){
				let tgtName,tgtSeg;
				tgtName=self.jumpSlotCode;
				ctx.fillStyle="white";
				ctx.strokeStyle="black";
				ctx.lineWidth = 2;
				rect=boxHeader.getBoundingClientRect();
				rect.x-=ox;rect.y-=oy;
				ctx.beginPath();
				ctx.ellipse(rect.x-2, rect.y+rect.height-2, 12, 12, 0, 0, 2 * Math.PI);
				ctx.fill();
				ctx.stroke();
				ctx.fillStyle="black";
				ctx.textAlign="center";
				const metrics = ctx.measureText(tgtName);
				const textHeight = metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;
				ctx.textBaseline="top";
				ctx.font = "bold 16px arial";
				ctx.fillText(tgtName,rect.x-2,rect.y+rect.height-2-textHeight/2-2);
				ctx.textAlign="start";
			}
		};
	}
	/*}#1HC1VRLSV1PostCSSVO*/
	cssVO.constructor=BoxAISeg;
	return cssVO;
};
/*#{1HC1VRLSV1ExCodes*/
/*}#1HC1VRLSV1ExCodes*/

//----------------------------------------------------------------------------
BoxAISeg.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HC1VRLSV1PreAISpot*/
	/*}#1HC1VRLSV1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HC1VRLSV1PostAISpot*/
	/*}#1HC1VRLSV1PostAISpot*/
	return exposeVO;
};

/*#{1HC1VRLSV0EndDoc*/
/*}#1HC1VRLSV0EndDoc*/

export default BoxAISeg;
export{BoxAISeg};
