//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NaviTreeBox} from "./NaviTreeBox.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GA757RST0StartDoc*/
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {EditPrj} from "../EditPrj.js";
import {DlgAddHud} from "./DlgAddHud.js";
/*}#1GA757RST0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXNaviDoc=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA757RST7LocalVals*/
	let appPrj,editPrj,dataDocs;
	let treeBox,rootObj,isFocused,isFaceOn;
	appPrj=app.prj;
	dataDocs=appPrj.docs;
	editPrj=appPrj.codyPrj;
	treeBox=null;
	rootObj=null;
	isFocused=0;
	isFaceOn=0;
	/*}#1GA757RST7LocalVals*/
	
	/*#{1GA757RST7PreState*/
	/*}#1GA757RST7PreState*/
	/*#{1GA757RST7PostState*/
	/*}#1GA757RST7PostState*/
	cssVO={
		"hash":"1GA757RST7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GA7595MS0",
				"type":NaviTreeBox(app,"doc"),"id":"TreeBox","x":0,"y":0,
				/*#{1GA7595MS0Codes*/
				OnLineClick(line,obj,node,evt){
					self.OnLineClick(line,obj,node,evt);
				},
				OnAddNaviObject(obj,node){
					callAfter(()=>{
						let line=node.hud;
						self.OnLineClick(line,obj,node,{});
					});
				}
				/*}#1GA7595MS0Codes*/
			},
			{
				"hash":"1GA758QSK0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1GA758QSL0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddObj","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA758QSL0Codes*/
						tip:(($ln==="CN")?("添加新项目"):/*EN*/("Add new item")),
						OnClick:function(){
							self.doAddObj();
						}
						/*}#1GA758QSL0Codes*/
					},
					{
						"hash":"1GDS9G6ME0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GDS9G6ME0Codes*/
						tip:(($ln==="CN")?("保存"):/*EN*/("Save")),
						OnClick(){
							app.mainUI.doSaveDoc()
						}
						/*}#1GDS9G6ME0Codes*/
					},
					{
						"hash":"1GA758QSL5",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDelObj","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA758QSL5Codes*/
						tip:(($ln==="CN")?("删除所选项目"):/*EN*/("Delete selected item(s)")),
						OnClick:function(){
							self.doDelObj();
						}
						/*}#1GA758QSL5Codes*/
					},
					{
						"hash":"1GA758QSL10",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/movefront.svg",null),"id":"BtnMoveUp","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA758QSL10Codes*/
						tip:(($ln==="CN")?("向上移动选定项目"):/*EN*/("Move up selected item(s)")),
						OnClick:function(){
							self.doMoveUpObj();
						}
						/*}#1GA758QSL10Codes*/
					},
					{
						"hash":"1GA758QSM4",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/moveback.svg",null),"id":"BtnMoveDown","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA758QSM4Codes*/
						tip:(($ln==="CN")?("向下移动选定的项目"):/*EN*/("Move down selected item(s)")),
						OnClick:function(){
							self.doMoveDownObj();
						}
						/*}#1GA758QSM4Codes*/
					},
					{
						"hash":"1GJ3IRF4T0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GJ3IRF4T0Codes*/
						tip:(($ln==="CN")?("运行项目"):/*EN*/("Run project")),
						OnClick(){
							app.runPrj(this);
						}
						/*}#1GJ3IRF4T0Codes*/
					},
					{
						"hash":"1GAMRQ31N0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnEndFaceEdit","position":"relative","x":0,"y":"FH/2","display":0,"anchorY":1,
						"padding":1,
						/*#{1GAMRQ31N0Codes*/
						tip:(($ln==="CN")?("退出编辑预设外观模式"):/*EN*/("Exit face edit mode")),
						OnClick:function(){
							self.endFaceEdit();
						}
						/*}#1GAMRQ31N0Codes*/
					},
					{
						"hash":"1GAMRRHBO0",
						"type":"text","id":"TxtFace","position":"relative","x":0,"y":0,"w":100,"h":"FH","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontTool,"text":"Face: ","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			}
		],
		/*#{1GA757RST7ExtraCSS*/
		/*}#1GA757RST7ExtraCSS*/
		faces:{
			"faceOff":{
				/*BtnAddObj*/"#1GA758QSL0":{
					"display":1
				},
				/*BtnSave*/"#1GDS9G6ME0":{
					"display":1
				},
				/*BtnDelObj*/"#1GA758QSL5":{
					"display":1
				},
				/*BtnMoveUp*/"#1GA758QSL10":{
					"display":1
				},
				/*BtnMoveDown*/"#1GA758QSM4":{
					"display":1
				},
				/*BtnRun*/"#1GJ3IRF4T0":{
					"display":1
				},
				/*BtnEndFaceEdit*/"#1GAMRQ31N0":{
					"display":0
				},
				/*TxtFace*/"#1GAMRRHBO0":{
					"display":0
				},
				/*#{1GAMRP5E70Code*/
				$(){
					isFaceOn=0;
				}
				/*}#1GAMRP5E70Code*/
			},"faceOn":{
				/*BtnAddObj*/"#1GA758QSL0":{
					"display":0
				},
				/*BtnSave*/"#1GDS9G6ME0":{
					"display":0
				},
				/*BtnDelObj*/"#1GA758QSL5":{
					"display":0
				},
				/*BtnMoveUp*/"#1GA758QSL10":{
					"display":0
				},
				/*BtnMoveDown*/"#1GA758QSM4":{
					"display":0
				},
				/*BtnRun*/"#1GJ3IRF4T0":{
					"display":0
				},
				/*BtnEndFaceEdit*/"#1GAMRQ31N0":{
					"display":1
				},
				/*TxtFace*/"#1GAMRRHBO0":{
					"display":1
				},
				/*#{1GAMRPBIK0Code*/
				$(){
					isFaceOn=1;
				}
				/*}#1GAMRPBIK0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA757RST7Create*/
			treeBox=self.treeBox=self.TreeBox;
			treeBox.naviBox=self;
			//Relocate BtnBox:
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			
			EditPrj.boxNaviDoc=self;
			
			editPrj.on("EditRootObj",(obj)=>{
				if(isFocused){
					self.setRootObj(obj);
				}
			});
			editPrj.on("EditSubObj",(obj,oldObj,addSelect)=>{
				if(isFocused){
					if(obj){
						treeBox.showObjNode(obj,true,true,addSelect);
					}else{
						treeBox.setHotNode(null);
					}
					self.OnFocusObj(obj);
				}
			});
			editPrj.on("DeslectSubObj",(obj,hotObj)=>{
				let node
				if(isFocused){
					if(obj){
						node=treeBox.showObjNode(obj,true,false,false);
						treeBox.deselectNode(node);
					}else{
						treeBox.setHotNode(null);
					}
					self.OnFocusObj(hotObj);
				}
			});
			editPrj.on("SelectSubObj",(obj,cf)=>{
				if(isFocused){
					let node,isHot;
					node=treeBox.showObjNode(obj,true,false,false);
					if(node){
						if(treeBox.selected.has(node)){
							if(treeBox.selected.size>1){
								if(cf){
									//Change select focus:
									editPrj.setEditSubObj(obj,true);
								}else{
									//This is not select, this is deselect:
									isHot=(node===treeBox.hotNode);
									treeBox.deselectNode(node);
									if(isHot){
										let newHotNode;
										editPrj.setEditSubObj(null,false);
										newHotNode=treeBox.selected.values().next().value;
										if(newHotNode){
											editPrj.setEditSubObj(newHotNode.nodeObj,true);
										}
									}
								}
							}
						}else{
							//Select and focus this obj:
							editPrj.setEditSubObj(obj,true);
						}
					}
				}
			});
			editPrj.on("SelectSubObjList",(list)=>{
				if(isFocused){
					let obj,node,isHot;
					treeBox.clearSelects();
					for(obj of list){
						node=treeBox.showObjNode(obj,true,false,false);
						if(node){
							//Select and focus this obj:
							treeBox.selectNode(node);
							//editPrj.setEditSubObj(obj,true);
						}
					}
				}
			});
			let prjCfg;
			prjCfg=appPrj.prjConfig;
			if(prjCfg){
				self.BtnRun.enable=!!prjCfg.run;
			}
			/*}#1GA757RST7Create*/
		},
		/*#{1GA757RST7EndCSS*/
		/*}#1GA757RST7EndCSS*/
	};
	/*#{1GA757RST7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		let obj;
		isFocused=1;
		obj=editPrj.curEditRootObj;
		this.setRootObj(obj);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		isFocused=0;
		this.setRootObj(null);
	};
	
	//------------------------------------------------------------------------
	cssVO.isShowing=function(){
		return isFocused;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnLineClick=function(line,obj,node,evt){
		let addSelect,hotNode,curObj;
		hotNode=treeBox.hotNode;
		addSelect=(evt.shiftKey || evt.metaKey);
		if(hotNode){
			curObj=hotNode.nodeObj;
			if(addSelect){
				if(curObj.isAISeg){
					if(!obj.isAISeg){
						addSelect=false;
					}
				}else if(obj.isAISeg){
					addSelect=false;
				}else if(!curObj.isHudObj || !obj.isHudObj){
					addSelect=false;
				}
			}
		}
		if(obj && addSelect &&(obj.isHudObj||obj.isAISeg)){
			editPrj.selectEditSubObj(obj);
		}else{
			editPrj.setEditSubObj(obj);
		}
		if(obj.jaxId){
			let doc,editor;
			doc=obj.doc.dataDoc;
			editor=doc.editBox;
			if(editor){
				if(editor.getEditMode()==="Code"){
					editor.gotoLine(obj.jaxId);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	let curTgtNode=null;
	cssVO.setTargetObj=function(obj,openUp){
		if(curTgtNode && curTgtNode.hud){
			curTgtNode.hud.showFace("targetOff");
		}
		if(obj){
			curTgtNode=treeBox.showObjNode(obj,openUp,false,false);
			if(curTgtNode){
				curTgtNode.hud.showFace("targetOn");
			}
		}else{
			curTgtNode=null;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setRootObj=function(obj){
		let hotObj;
		if(rootObj===obj){
			return;
		}
		if(rootObj){
			rootObj.naviDocBlur();
			rootObj.off("FaceOn",self.OnFaceOn);
			rootObj.off("FaceOff",self.OnFaceOff);
			rootObj.off("FaceSwitch",self.OnFaceSwitch);
			rootObj.off("FaceOnUsed",self.OnFaceOnUsed);
		}
		treeBox.clear();
		rootObj=obj;
		if(rootObj){
			rootObj.naviDocFocus();
			treeBox.showRootObj(rootObj.getNaviDocRoot());
			rootObj.naviDocReady();
			hotObj=editPrj.curEditSubObj;
			if(hotObj){
				treeBox.showObjNode(hotObj);
			}
			//TODO: Trace doc face change:
			rootObj.on("FaceOn",self.OnFaceOn);
			rootObj.on("FaceOff",self.OnFaceOff);
			rootObj.on("FaceSwitch",self.OnFaceSwitch);
			rootObj.on("FaceOnUsed",self.OnFaceOnUsed);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getSelectedObjsList=function(){
		let list;
		list=Array.from(treeBox.selected.values());
		list=list.map((node)=>node.nodeObj);
		return list;
	};
	
	//************************************************************************
	//Handle events/ notify:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnFocusObj=function(obj){
			let doc,attrDef,objDef;
			let allowAdd=0,allowMove=0,allowDel=1;
			if(!obj){
				self.BtnAddObj.enable=0;
				self.BtnDelObj.enable=0;
				self.BtnMoveUp.enable=0;
				self.BtnMoveDown.enable=0;
				return;
			}
			attrDef=obj.def;
			objDef=obj.objDef;
			if(attrDef.key){
				allowDel=0;
			}
			allowAdd=objDef.naviHasSub===false?0:(objDef.allowExtraAttr||(objDef.naviAllowAdd===true));
			doc=obj.doc;
			if(obj.isFaceTags){
				allowAdd=1;
				allowMove=0;
				//This is the faceTags:
				if(doc.curFaceTag){
					self.endFaceEdit();
				}
			}else if(obj.isFaceTag){
				allowAdd=obj.isFaceTimeTag?0:1;
				allowMove=1;
				//This is a single face entry, enter edit:
				doc.enterFaceEdit(obj);
			}else if(obj.isHudObj||obj.isEditClass){
				//This is a hudObj
				allowMove=1;
			}else if(obj.owner instanceof EditArray){
				//This is a Array element:
				allowMove=1;
			}
			self.BtnAddObj.enable=allowAdd;
			self.BtnDelObj.enable=allowDel;
			self.BtnMoveUp.enable=allowMove;
			self.BtnMoveDown.enable=allowMove;
		};
		
		//--------------------------------------------------------------------
		cssVO.OnFaceOn=function(faceTag){
			let doc;
			doc=rootObj;//rootObj is a GearDoc
			self.TxtFace.text=(($ln==="CN")?(`外观: ${faceTag.name}`):/*EN*/(`Face: ${faceTag.name}`));
			self.showFace("faceOn");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnFaceSwitch=function(){
			let nodes,i,n,node;
			nodes=treeBox.nodes;
			n=nodes.length;
			for(i=0;i<n;i++){
				node=nodes[i];
				node.hud.showFace("faceOff");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnFaceOff=function(){
			let nodes,i,n,node;
			self.showFace("faceOff");
			nodes=treeBox.nodes;
			n=nodes.length;
			for(i=0;i<n;i++){
				node=nodes[i];
				node.hud.showFace("faceOff");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnFaceOnUsed=function(hudObj){
			let node;
			node=treeBox.showObjNode(hudObj,true,false,false);
			if(node){
				node.hud.showFace("faceOn");
			}
		};
	}
	
	//------------------------------------------------------------------------
	cssVO.endFaceEdit=function(){
		let doc=rootObj.doc;
		doc.exitFaceEdit(true);
	};
	
	//************************************************************************
	//Edit object:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doAddObj=function(){
			let curNode,curObj,curDoc,prj;
			let def,attr;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curDoc=dataDocs.hotDoc;
			if(!curDoc){
				return;
			}
			curDoc=curDoc.codyDoc;
			prj=curDoc.prj;
			curObj=curNode.nodeObj;
			if(curObj.doc!==curDoc){
				return;
			}
	
			if(curDoc.curFaceTag){//In face-edit-mode?
				window.alert((($ln==="CN")?("无法在编辑预设外观模式下添加项目。"):/*EN*/("Can't add item in face-edit mode.")));
				return;
			}
	
			if(curObj.isFaceTag){//Add a sub-timer-face in face:
				let time,name,tag,prj;
				//time=window.prompt((($ln==="CN")?("输入新的预设外观时间:"):/*EN*/("Input new face-time's time:")),"500");
				app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新的预设外观时间:"):/*EN*/("Input new face-time's time:")),text:"500"}).then((time)=>{
					time=parseInt(time);
					if(time>0){
						tag=curObj.getFaceTime(time);
						if(tag){
							window.alert((($ln==="CN")?(`时间 ${time} 已经有一个预设外观占用了。`):/*EN*/(`Time ${time} is already has an face entry.`)));
							return;
						}
						name=EditObj.genObjId();
						def={name:name,type:"facetag",def:"FaceTimeTag",extraAttr:1,navi:"doc",time:time,edit:false};
						prj=curObj.prj;
						if(prj && prj.editAttr_AddAttr){
							attr=prj.editAttr_AddAttr(curObj.faceTimes,def);
						}else{
							attr=curObj.faceTimes.addAttr(def);
						}
					}
				});
			}else if(curObj instanceof EditArray){
				let elementType,elementDef;
				elementType=curObj.objDef.elementType;
				elementDef=curObj.objDef.elementDef;
				if(elementType && elementDef){
					def={type:elementType,def:elementDef,extraAttr:1,navi:"doc"};
					if(prj && prj.editAttr_AddAttr){
						attr=prj.editAttr_AddAttr(curObj,def);
					}else{
						attr=curObj.addAttr(def);
					}
				}
			}else{
				let objDef,attrType,attrTypeDef,name,objType;
				objDef=curObj.objDef;
				if(objDef && objDef.naviHasSub!==false){
					prj=curObj.prj;
					objType=curObj.def.type;
					attrType=objDef.attrType;
					attrTypeDef=objDef.attrTypeDef;
					if(attrType && attrTypeDef){
						if(attrType==="objclass"){
							app.showDlg("/@editkit/DlgNewClass.js",{
								curObj:curObj,
								callback(classVO){
									let name=classVO.name;
									if(!name){
										return;
									}
									def={name:name,type:attrType,def:attrTypeDef,extraAttr:1,navi:"doc"};
									if(prj && prj.editAttr_AddAttr){
										attr=prj.editAttr_AddAttr(curObj,def);
									}else{
										attr=curObj.addAttr(def);
									}
									if(classVO.mockup){
										try{
											let mockup=JSON.parse(classVO.mockup);
											if(classVO.useMockup==="Template"){
												attr.applyMockTemplate(mockup);
											}else if(classVO.useMockup==="Object"){
												let tmpt;
												tmpt=VFACT.genTemplateByObject(mockup);
												attr.applyMockTemplate(tmpt);
											}
										}catch(err){
											console.error(err);
										}
									}
								}
							});
						}else{
							//No need ask type, just need a name
							//name=window.prompt((($ln==="CN")?("输入新项目名称"):/*EN*/("Input new item name")),"newItem");
							app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新项目名称"):/*EN*/("Input new item name")),text:"newItem"}).then((name)=>{
								if(!name){
									return;
								}
								def={name:name,type:attrType,def:attrTypeDef,extraAttr:1,navi:"doc"};
								if(prj && prj.editAttr_AddAttr){
									attr=prj.editAttr_AddAttr(curObj,def);
								}else{
									attr=curObj.addAttr(def);
								}
							});
						}
					}else{
						if(attrType==="hud"){
							app.showDlg(DlgAddHud,{
								callback:async function(def){
									if(prj && prj.editAttr_AddSubHud){
										let importPath=def.source;
										if(importPath){//Check import
											let doc=curObj.doc;
											if(importPath.startsWith(prj.path)){
												if(!prj.editAttr_CanImportDoc(doc,def.source)){
													window.alert((($ln==="CN")?(`${doc.path} 无法导入文件 ${def.source}`):/*EN*/(`${doc.path} can not import file ${def.source}`)));
													return;
												}
											}
										}
										attr=prj.editAttr_AddSubHud(curObj,def);
									}else{
										attr=curObj.addSubHud(def);
									}
									//Select new node?
									if(attr){
										treeBox.showObjNode(attr,true,true,false);
									}
								}
							});
						}else if(objType==="objclass"){
							curObj=curObj.owner;
							objDef=curObj.objDef;
							attrType=objDef.attrType;
							attrTypeDef=objDef.attrTypeDef;
							app.showDlg("/@editkit/DlgNewClass.js",{
								curObj:curObj,
								callback(classVO){
									let name=classVO.name;
									if(!name){
										return;
									}
									def={name:name,type:attrType,def:attrTypeDef,extraAttr:1,navi:"doc"};
									if(prj && prj.editAttr_AddAttr){
										attr=prj.editAttr_AddAttr(curObj,def);
									}else{
										attr=curObj.addAttr(def);
									}
									if(classVO.mockup){
										try{
											let mockup=JSON.parse(classVO.mockup);
											if(classVO.useMockup==="Template"){
												attr.applyMockTemplate(mockup);
											}else if(classVO.useMockup==="Object"){
												let tmpt;
												tmpt=VFACT.genTemplateByObject(mockup);
												attr.applyMockTemplate(tmpt);
											}
										}catch(err){
											console.error(err);
										}
									}
								}
							});
						}
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.doDelObj=function(){
			let selected,curNode,curDoc,prj,curObj,ownerObj;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curDoc=dataDocs.hotDoc;
			if(!curDoc){
				return;
			}
			curDoc=curDoc.codyDoc;
			prj=curDoc.prj;
			curObj=curNode.nodeObj;
			ownerObj=curObj.owner;
			if(curObj.doc!==curDoc){
				return;
			}
			selected=treeBox.selected;
			if(selected.size>1){
				//If got here, it should all be EditHudObjs
				if(window.confirm((($ln==="CN")?(`确定要删除所选项目吗？`):/*EN*/(`Are you sure to remove selected items?`)))){
					selected=Array.from(selected);
					selected=EditObj.cutTree(selected);
					selected=selected.map(node=>node.nodeObj);
					prj.editAttr_RemoveAttrList(selected);
					editPrj.setEditSubObj(null);//The curSubObj is deleted for sure.
				}
			}else{
				if(window.confirm((($ln==="CN")?(`你确定要删除项目：“${curObj.getName?curObj.getName():curObj.name}”吗？`):/*EN*/(`Are you sure to remove item: "${curObj.getName?curObj.getName():curObj.name}"?`)))){
					treeBox.closeNode(curNode);
					if(ownerObj.isFaceTag){
						self.exitFaceEdit();
					}
					if(prj && prj.editAttr_RemoveAttr){
						prj.editAttr_RemoveAttr(ownerObj,curObj);
					}else{
						ownerObj.removeAttr(curObj);//No undo
					}
					editPrj.setEditSubObj(null);//The curSubObj is deleted for sure.
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.doCopyObj=function(){
			let saveVO,selected,curNode,curObj;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curObj=curNode.nodeObj;
			if(curObj instanceof EditHudObj){
				selected=Array.from(treeBox.selected);
				selected=selected.map((node)=>node.nodeObj);
				selected=EditObj.cutTree(selected);
				selected=selected.map((obj)=>obj.genSaveVO());
				EditPrj.copiedHudItems=selected;
			}else if(curObj.isFaceTag){
				//TODO: Directly clone face entry?
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.doCutObj=function(){
			let saveVO,selected,curNode,curObj;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curObj=curNode.nodeObj;
			if(curObj instanceof EditHudObj){
				selected=Array.from(treeBox.selected);
				selected=selected.map((node)=>node.nodeObj);
				selected=EditObj.cutTree(selected);
				//Remove items and recored it in EditPrj
				editPrj.editAttr_RemoveAttrList(selected);
				EditPrj.copiedHudItems=selected;
				editPrj.setEditSubObj(null);//The curSubObj is deleted for sure.
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.doPasteObj=function(){
			let saveList,i,n,list,curNode,curObj;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curObj=curNode.nodeObj;
			if(curObj.objDef.naviHasSub!==false){
				if((curObj instanceof EditHudObj)||curObj.isGearSlot){
					list=editPrj.editAttr_PasteHud(curObj);
					if(list && list.length>0){
						editPrj.setEditSubObj(list[0]);
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.doMoveUpObj=function(){
			let curNode,curObj,doc,ownerObj,prj,selected;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curObj=curNode.nodeObj;
			if(!curObj){
				return;
			}
			if(curObj.def.key||curObj.def.fixed){
				return;
			}
			doc=curObj.doc;
			prj=doc.prj;
			ownerObj=curObj.owner;
			selected=treeBox.selected;
			if(selected.size>1){
				selected=Array.from(selected);
				selected=treeBox.sortNodes(selected);
				selected=selected.map(node=>node.nodeObj);
				if(!selected.every(item=>item.owner===ownerObj)){
					window.alert((($ln==="CN")?("不能移动不同所有者的项目"):/*EN*/("Can't move items with differnt owners")));
					return;
				}
				prj.editAttr_MoveUpAttr(ownerObj,selected);
			}else{
				if(prj && prj.editAttr_MoveUpAttr){
					prj.editAttr_MoveUpAttr(ownerObj,curObj);
				}else{
					ownerObj.moveUpAttr(curObj);
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.doMoveDownObj=function(){
			let curNode,curObj,doc,ownerObj,prj,selected;
			curNode=treeBox.hotNode;
			if(!curNode){
				return;
			}
			curObj=curNode.nodeObj;
			if(!curObj){
				return;
			}
			if(curObj.def.key||curObj.def.fixed){
				return;
			}
			doc=curObj.doc;
			prj=doc.prj;
			ownerObj=curObj.owner;
			selected=treeBox.selected;
			if(selected.size>1){
				selected=Array.from(selected);
				selected=treeBox.sortNodes(selected);
				selected=selected.map(node=>node.nodeObj);
				if(!selected.every(item=>item.owner===ownerObj)){
					window.alert((($ln==="CN")?("不能移动不同所有者的项目"):/*EN*/("Can't move items with differnt owners")));
					return;
				}
				prj.editAttr_MoveDownAttr(ownerObj,selected);
			}else{
				if(prj && prj.editAttr_MoveUpAttr){
					prj.editAttr_MoveDownAttr(ownerObj,curObj);
				}else{
					ownerObj.moveDownAttr(curObj);
				}
			}
		};
	}
	/*}#1GA757RST7PostCSSVO*/
	cssVO.constructor=TBXNaviDoc;
	return cssVO;
};
/*#{1GA757RST7ExCodes*/
TBXNaviDoc.tbxCodeName="NaviDoc";
TBXNaviDoc.tbxTip=(($ln==="CN")?("文档内容结构"):/*EN*/("Document Hierarchy"));
TBXNaviDoc.tbxIcon=appCfg.sharedAssets+"/uitree.svg";
TBXNaviDoc.tbxIconPad=2;
/*}#1GA757RST7ExCodes*/

//----------------------------------------------------------------------------
TBXNaviDoc.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GA757RST7PreAISpot*/
	/*}#1GA757RST7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GA757RST7PostAISpot*/
	/*}#1GA757RST7PostAISpot*/
	return exposeVO;
};

/*#{1GA757RST0EndDoc*/
/*}#1GA757RST0EndDoc*/

export default TBXNaviDoc;
export{TBXNaviDoc};
