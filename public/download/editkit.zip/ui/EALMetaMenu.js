//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GA9UHEBU0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {DlgLongText} from "./DlgLongText.js";
/*}#1GA9UHEBU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALMetaMenu=function(app,box){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA9UHEBU7LocalVals*/
	let attrObj,attrDef,attrLine;
	let btnMoveUp,btnMoveDown;
	let menuItems,inMenu=0;
	let curLine=null;
	/*}#1GA9UHEBU7LocalVals*/
	
	/*#{1GA9UHEBU7PreState*/
	/*}#1GA9UHEBU7PreState*/
	/*#{1GA9UHEBU7PostState*/
	/*}#1GA9UHEBU7PostState*/
	cssVO={
		"hash":"1GA9UHEBU7",nameHost:true,
		"type":"hud","id":"MetaMenu","x":"100%","y":0,"w":(cfgSize.attrLineH-6)*3+3,"h":cfgSize.attrLineH,"anchorX":2,"autoLayout":true,"minW":"","minH":"",
		"maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GD2JHIV00",
				"type":"box","id":"BoxBG","x":"FW-3","y":"FH/2","w":22,"h":22,"anchorX":2,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":1,"borderColor":cfgColor.lineBodyLit,"corner":3,
			},
			{
				"hash":"1GA9UKAR10",
				"type":"box","id":"BoxIcon","x":"FW-3","y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorX":2,"anchorY":1,"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor.fontBodySub,"maskImage":appCfg.sharedAssets+"/menu.svg",
			},
			{
				"hash":"1GA9UOA9L0",
				"type":"hud","id":"BoxMenu","x":0,"y":0,"w":"FW","h":"FH","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GA9UTJ8G0",
						"type":BtnIcon("front",cfgSize.attrLineH-6,0,appCfg.sharedAssets+"/movefront.svg",null),"id":"BtnMoveUp","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA9UTJ8G0Codes*/
						OnClick(){
							self.attrMoveUp();
						}
						/*}#1GA9UTJ8G0Codes*/
					},
					{
						"hash":"1GA9UTO1K0",
						"type":BtnIcon("front",cfgSize.attrLineH-6,0,appCfg.sharedAssets+"/moveback.svg",null),"id":"BtnMoveDown","x":cfgSize.attrLineH-6,"y":"FH/2","anchorY":1,
						"padding":1,
						/*#{1GA9UTO1K0Codes*/
						OnClick(){
							self.attrMoveDown();
						}
						/*}#1GA9UTO1K0Codes*/
					},
					{
						"hash":"1GA9UTSOD0",
						"type":BtnIcon("front",cfgSize.attrLineH-6,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","x":(cfgSize.attrLineH-6)*2,"y":"FH/2","anchorY":1,
						"padding":0,
						/*#{1GA9UTSOD0Codes*/
						OnClick(evt){
							self.showMenu();
						}
						/*}#1GA9UTSOD0Codes*/
					}
				],
			}
		],
		/*#{1GA9UHEBU7ExtraCSS*/
		/*}#1GA9UHEBU7ExtraCSS*/
		faces:{
			"icon":{
				/*BoxBG*/"#1GD2JHIV00":{
					"w":22,"h":22,"x":"FW-3"
				},
				/*BoxIcon*/"#1GA9UKAR10":{
					"display":1
				},
				/*BoxMenu*/"#1GA9UOA9L0":{
					"display":0
				}
			},"menu":{
				/*BoxBG*/"#1GD2JHIV00":{
					"w":"FW+6","h":26,"x":"FW"
				},
				/*BoxIcon*/"#1GA9UKAR10":{
					"display":0
				},
				/*BoxMenu*/"#1GA9UOA9L0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA9UHEBU7Create*/
			box=self.parent;
			btnMoveUp=self.BtnMoveUp;
			btnMoveDown=self.BtnMoveDown;
			/*}#1GA9UHEBU7Create*/
		},
		/*#{1GA9UHEBU7EndCSS*/
		/*}#1GA9UHEBU7EndCSS*/
	};
	/*#{1GA9UHEBU7PostCSSVO*/
	menuItems={
		rename:{text:(($ln==="CN")?("重命名"):/*EN*/("Rename")),value:"Rename",icon:appCfg.sharedAssets+"/edit.svg",enable:1},
		localize:{text:(($ln==="CN")?("多语言"):/*EN*/("Localize")),value:"Localize",icon:appCfg.sharedAssets+"/web.svg",enable:1,checked:1},
		retype:{text:(($ln==="CN")?("更改类型"):/*EN*/("Change Type")),value:"Retype",icon:appCfg.sharedAssets+"/group.svg",enable:1},
		copyObj:{text:(($ln==="CN")?("复制对象"):/*EN*/("Copy Object")),value:"CopyObj",icon:appCfg.sharedAssets+"/copy.svg",enable:1},
		copyAttr:{text:(($ln==="CN")?("复制属性"):/*EN*/("Copy Attr")),value:"CopyAttr",icon:appCfg.sharedAssets+"/copy.svg",enable:1},
		pasteInObj:{text:(($ln==="CN")?("粘贴以添加属性"):/*EN*/("Paste to Add Attr")),value:"PasteInObj",icon:appCfg.sharedAssets+"/paste.svg",enable:1},
		pasteAttr:{text:(($ln==="CN")?("粘贴属性内容"):/*EN*/("Paste Attr")),value:"PasteAttr",icon:appCfg.sharedAssets+"/paste.svg",enable:1},
		comment:{text:(($ln==="CN")?("注释"):/*EN*/("Comment")),value:"Comment",icon:appCfg.sharedAssets+"/hudnotes.svg",enable:1},
		delete:{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),value:"Delete",icon:appCfg.sharedAssets+"/trash.svg",enable:1},
	}
	//------------------------------------------------------------------------
	cssVO.isBusy=function(){
		return inMenu;
	};
	
	//------------------------------------------------------------------------
	cssVO.dockInLine=function(line){
		if(inMenu){
			return false;
		}
		curLine=line;
		attrObj=line.attrObj;
		attrDef=attrObj.def;
		attrLine=line;
		if(attrDef.fixed){
			btnMoveUp.enable=0;	
			btnMoveDown.enable=0;	
		}else{
			btnMoveUp.enable=1;	
			btnMoveDown.enable=1;	
		}
		self.showFace("icon");
		inMenu=0;
		return true;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn){
		if(isIn){
			self.showFace("menu");
		}else{
			self.showFace("icon");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=function(hud){
		let items,clipAttr,curAttr,attrDef,objDef;
		if(hud && hud!==curLine){
			return;
		}
		//Setup menuItems:
		curAttr=attrObj;
		attrDef=attrObj.def;
		objDef=attrObj.objDef;
		attrLine.showFace("up");
		clipAttr=app.copiedEditAttr;
		items=[];
		menuItems.retype.text=(($ln==="CN")?("类型: "+attrDef.type):/*EN*/("Type: "+attrDef.type));
		menuItems.rename.enable=(objDef && objDef.allowRename===false)?false:((attrDef.key||attrDef.fixed)?false:true);
		items.push(menuItems.rename);
		if(!attrObj.attrList){
			items.push(menuItems.retype);
			items.push(menuItems.copyAttr);
			items.push(menuItems.pasteAttr);
			menuItems.retype.enable=!(curAttr.def.fixed);
			menuItems.comment.enable=(!(curAttr.def.fixed))||(curAttr.def.comment);
			menuItems.pasteAttr.enable=clipAttr &&clipAttr.type==="attr" && clipAttr.def.type===attrObj.def.type;
		}else{
			items.push(menuItems.copyObj);
		}
		items.push(menuItems.comment);
		items.push(menuItems.delete);
		menuItems.delete.enable=attrObj.def.key?false:true;
		if(attrDef.localizable){
			items.push(menuItems.localize);
			menuItems.localize.checked=!!curAttr.localize;
		}
		inMenu=1;
		app.showDlg(DlgMenu,{
			hud:hud||self.BtnMenu,items:items,width:120,
			callback:async (item,evt)=>{
				if(!item){
					inMenu=0;
					return;
				}
				switch(item.value){
					case "Rename":{
						box.startEditAttrName(attrObj,attrLine);
						break;
					}
					case "CopyObj":{
						if(attrObj instanceof EditObj){
							app.copiedEditAttr={
								type:"clipObject",
								saveVO:attrObj.genSaveVO()
							};
						}
						break;
					}
					case "CopyAttr":{
						let vo={};
						vo.type="clipAttr";
						vo.name=attrObj.name;
						vo.def={...attrObj.def}
						vo.valText=attrObj.valText;
						vo.val=attrObj.val;
						app.copiedEditAttr=vo;
						break;
					}
					case "PasteInObj":{
						if(attrObj instanceof EditObj){
							let name,orgAttr,newAttr;
							name=clipAttr.name;
							orgAttr=attrObj.getAttr(name);
							while(orgAttr){
								name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:"New attr name",text:name+"1"});
								//name=window.prompt("New attr name:",name+"1");
								if(!name){
									inMenu=0;
									return;
								}
								orgAttr=attrObj.getAttr(name);
							}
							clipAttr.name=name;
						}
						clipAttr.jaxId=EditObj.genObjId();
						box.pasteAddObjAttr(attrObj,clipAttr);
						break;
					}
					case "Retype":{
						let items=[
							{text:(($ln==="CN")?("自动类型(auto)"):/*EN*/("Auto")),value:"auto"},
							{text:(($ln==="CN")?("字符串(string)"):/*EN*/("String")),value:"string"},
							{text:(($ln==="CN")?("本地化字符串(localized string)"):/*EN*/("Localized String")),value:{type:"string",localizable:true}},
							{text:(($ln==="CN")?("整数(int)"):/*EN*/("Integer")),value:"int"},
							{text:(($ln==="CN")?("数字(number)"):/*EN*/("Number")),value:"number"},
							{text:(($ln==="CN")?("布尔型(bool)"):/*EN*/("Boolean")),value:"bool"},
							{text:(($ln==="CN")?("字体大小(fontSize)"):/*EN*/("Font Size")),value:{type:"int",editType:"fontSize"}},
							{text:(($ln==="CN")?("RGB 颜色(colorRGB)"):/*EN*/("Color RGB")),value:"colorRGB"},
							{text:(($ln==="CN")?("RGBA 颜色(colorRGBA)"):/*EN*/("Color RGBA")),value:"colorRGBA"},
							{text:(($ln==="CN")?("文件路径(file)"):/*EN*/("File Path")),value:"file"},
							{text:(($ln==="CN")?("URL路径(url)"):/*EN*/("URL Path")),value:"url"},
						];
						app.showDlg(DlgMenu,{
							hud:attrLine,items:items,x:attrLine.w,alignH:2,w:150,
							callback:(item,evt)=>{
								if(!item){
									inMenu=0;
									return;
								}
								box.resetAttrType(curAttr,item.value);
							}
						});
						break;
					}
					case "PasteAttr":{
						box.setAttrByText(attrObj,clipAttr.valText);
						break;
					}
					case "Delete":{
						box.removeAttr(attrObj,attrLine);
						break;
					}
					case "Localize":{
						if(attrObj.localize){
							if(!window.confirm("Are you sure to remove localize from this attribute?")){
								inMenu=0;
								return;
							}
						}
						box.localizeAttr(attrObj,attrLine);
						break;
					}
					case "Comment":{
						let text;
						text=attrObj.comment||"";
						app.showDlg(DlgLongText,{
							text:text,
							title:(($ln==="CN")?("编辑注释"):/*EN*/("Edit comment")),
							next(apply,text){
								if(apply){
									box.commentAttr(attrObj,text);
								}
							}
						});
						break;
					}
				};
				inMenu=0;
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.attrMoveUp=function(){
		box.moveUpAttr(attrObj);
	};
	
	//------------------------------------------------------------------------
	cssVO.attrMoveDown=function(){
		box.moveDownAttr(attrObj);
	};
	/*}#1GA9UHEBU7PostCSSVO*/
	cssVO.constructor=EALMetaMenu;
	return cssVO;
};
/*#{1GA9UHEBU7ExCodes*/
/*}#1GA9UHEBU7ExCodes*/

//----------------------------------------------------------------------------
EALMetaMenu.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GA9UHEBU7PreAISpot*/
	/*}#1GA9UHEBU7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GA9UHEBU7PostAISpot*/
	/*}#1GA9UHEBU7PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
EALMetaMenu.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"box": {
			"name": "box", "showName": "box", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["icon","menu"],
	subContainers:{
	},
	/*#{1GA9UHEBU0ExGearInfo*/
	/*}#1GA9UHEBU0ExGearInfo*/
};
/*#{1GA9UHEBU0EndDoc*/
/*}#1GA9UHEBU0EndDoc*/

export default EALMetaMenu;
export{EALMetaMenu};
