//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxTabLine} from "/@StdUI/ui/BoxTabLine.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GTDFRE260StartDoc*/
import {BtnGear} from "./BtnGear.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
/*}#1GTDFRE260StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DLGCreateHud=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GTDFRE261LocalVals*/
	let dlgVO,curCatalog,inited;
	let boxFrame,boxIcons,edId,curBtn,btnCreate;
	/*}#1GTDFRE261LocalVals*/
	
	/*#{1GTDFRE261PreState*/
	/*}#1GTDFRE261PreState*/
	/*#{1GTDFRE261PostState*/
	/*}#1GTDFRE261PostState*/
	cssVO={
		"hash":"1GTDFRE261",nameHost:true,
		"type":"hud","id":"DlgCreateHud","x":313,"y":178,"w":720,"h":258,"anchorX":1,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GTDFT3PU0",
				"type":"box","id":"BoxFrame","x":20,"y":25,"w":"FW-40","h":200,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":1,"corner":6,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
				children:[
					{
						"hash":"1GTDG9HJ30",
						"type":"text","x":0,"y":7,"w":"100%","h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":"New Component",
						"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,
					},
					{
						"hash":"1GTDGGKVJ0",
						"type":BoxTabLine(24,80,[{"text":"Basic","msg":"Basic","hot":1},{"text":"Texts","msg":"Texts"},{"text":"Buttons","msg":"Buttons"},{"text":"Inputs","msg":"Inputs"},{"text":"Medias","msg":"Medias"},{"text":"Containers","msg":"Containers"},{"text":"Views","msg":"Viewss"},{"text":"Gears","msg":"Gears"}]),
						"id":"TabLine","x":10,"y":35,"w":"FW-20","autoLayout":true,
					},
					{
						"hash":"1GTDV7DST0",
						"type":"hud","id":"BoxIcons","x":10,"y":65,"w":">calc(100% - 20px)","h":80,"autoLayout":true,"overflow":"scroll hidden","minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-x",
					},
					{
						"hash":"1GTDVB5PT0",
						"type":"text","x":120,"y":164,"w":80,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"Item ID:",
						"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1GTDVD6SI0",
						"type":"edit","id":"EdId","x":206,"y":164,"w":200,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"outline":0,
						"border":[0,0,1,0],
						"OnUpdate":function(){
							/*#{1GTEJ6CDR0FunctionBody*/
							if(btnCreate.enable){
								self.createItem();
							}
							/*}#1GTEJ6CDR0FunctionBody*/
						},
					},
					{
						"hash":"1GTDVED7P0",
						"type":BtnText("success",100,28,"Create",false,""),"id":"BtnCreate","x":436,"y":161,"corner":3,"fontSize":txtSize.smallMid,
						"OnClick":function(event){
							/*#{1GTE099VU0FunctionBody*/
							self.createItem();
							/*}#1GTE099VU0FunctionBody*/
						},
					},
					{
						"hash":"1GTDVEV0D0",
						"type":BtnText("warning",100,30,"Cancel",false,""),"x":551,"y":159,"corner":3,"fontSize":txtSize.smallMid,
						"OnClick":function(event){
							/*#{1GTE09PMN0FunctionBody*/
							self.close(0);
							/*}#1GTE09PMN0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1GTDFRE261ExtraCSS*/
		/*}#1GTDFRE261ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GTDFRE261Create*/
			boxFrame=self.BoxFrame;
			boxIcons=self.BoxIcons;
			edId=self.EdId;
			btnCreate=self.BtnCreate;
			self.TabLine.on("TabChanged",(msg)=>{
				self.showCatalog(msg);
			})
			
			/*}#1GTDFRE261Create*/
		},
		/*#{1GTDFRE261EndCSS*/
		/*}#1GTDFRE261EndCSS*/
	};
	/*#{1GTDFRE261PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let catalog,x,y,dir;
		dlgVO=vo;
		if(!inited){
			catalog=vo.catalog||"Basic";
			curBtn=null;
			self.showCatalog(catalog);
			inited=true;
		}
		x=vo.x||"50%";
		y=vo.y||"50%";
		self.x=x;
		self.y=y;
		dir=vo.dir||0;
		if(dir===0){
			boxFrame.y=8;
			boxFrame.alpha=1;
			boxFrame.animate({type:"in",dy:-50,alpha:0,time:100});
		}else{
			boxFrame.y=8;
			boxFrame.alpha=1;
			boxFrame.animate({type:"in",dy:50,alpha:0,time:100});
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showCatalog=function(catalog){
		let list,i,n,def,btn;
		boxIcons.clearChildren();
		list=EditHudObj.getCatalogDefs(catalog);
		n=list.length;
		for(i=0;i<n;i++){
			def=list[i];
			boxIcons.appendNewChild({
				type:BtnGear(app,def),
				OnClick(){
					self.setCurBtn(this);
				}
			});
		}
		btn=boxIcons.firstChild;
		if(btn){
			btn.showFace("focus");
			curBtn=btn;
			btnCreate.enable=true;
		}else{
			curBtn=null;
			btnCreate.enable=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setCurBtn=function(btn){
		if(curBtn){
			curBtn.showFace("blur");
		}
		curBtn=btn;
		if(curBtn){
			curBtn.showFace("focus");
			btnCreate.enable=true;
		}else{
			btnCreate.enable=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.createItem=function(){
		let vo={};
		vo.def=curBtn.def;
		vo.id=self.EdId.text;
		self.close(vo);
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(code){
		let next;
		app.closeDlg(self);
		next=dlgVO.next||dlgVO.callback;
		if(next){
			next(code);
		}
	};
	/*}#1GTDFRE261PostCSSVO*/
	return cssVO;
};
/*#{1GTDFRE261ExCodes*/
/*}#1GTDFRE261ExCodes*/


/*#{1GTDFRE260EndDoc*/
/*}#1GTDFRE260EndDoc*/

export default DLGCreateHud;
export{DLGCreateHud};
