//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1IEL76JHR0StartDoc*/
import {EditPrj} from "../EditPrj.js";
import {InfoCard} from "/@StdUI/ui/InfoCard.js";
/*}#1IEL76JHR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXDebugAgent=function(app,box,tab){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edAddress,txtState,btnStep,btnRun,boxLogs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IEL76JHR1LocalVals*/
	let ws=null;
	let connected=false;
	let orgTitle;
	/*}#1IEL76JHR1LocalVals*/
	
	/*#{1IEL76JHR1PreState*/
	/*}#1IEL76JHR1PreState*/
	/*#{1IEL76JHR1PostState*/
	/*}#1IEL76JHR1PostState*/
	cssVO={
		"hash":"1IEL76JHR1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","padding":[5,5,5,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1IELQ5LPI0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"borderColor":cfgColor["fontBodySub"],
			},
			{
				"hash":"1IEL772FU0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"100%","h":30,"autoLayout":true,"display":0,"padding":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IEL772FU2",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnReload","position":"relative","x":0,"y":"FH/2","display":0,"anchorY":1,
						"padding":1,
						/*#{1IEL772FU2Codes*/
						/*}#1IEL772FU2Codes*/
					},
					{
						"hash":"1IEL772FU9",
						"type":"box","position":"relative","x":0,"y":0,"w":26,"h":26,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"maskImage":appCfg.sharedAssets+"/ghost.svg",
					},
					{
						"hash":"1IEL772FV3",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("远程调试智能体"):("Remote debug agent")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,
					}
				],
			},
			{
				"hash":"1IELCGCLA0",
				"type":"hud","id":"BoxOffline","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","itemsAlign":1,
				children:[
					{
						"hash":"1IELCK5450",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"Agent node address:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IELCIJ4O0",
						"type":"edit","id":"EdAddress","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,6,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"placeHolder":"Websocket address, like: ws://localhost:3301","color":[0,0,0],"outline":0,"border":[0,0,1,0],
					},
					{
						"hash":"1IELCLSMS0",
						"type":BtnText("primary",100,24,"Connect",false,""),"position":"relative","x":0,"y":0,
						"OnClick":function(event){
							self.connect(this,event);
						},
					}
				],
			},
			{
				"hash":"1IELCPAHE0",
				"type":"hud","id":"BoxOnline","position":"relative","x":0,"y":0,"w":"100%","h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				"flex":true,
				children:[
					{
						"hash":"1IELD4OP70",
						"type":"text","id":"TxtState","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":[0,0,0],"text":"Connected","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IEMV0LRI0",
						"type":"hud","id":"BoxTools","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IEMV1LC10",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":0,"padding":0,
								"tip":"Disconnect",
								"OnClick":function(event){
									self.disconnect(this,event);
								},
							},
							{
								"hash":"1IEN1V5VA0",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClear","position":"relative","x":0,"y":0,"padding":0,
								"tip":(($ln==="CN")?("清除日志"):("Clear logs")),
								"OnClick":function(event){
									self.clearLogs(this,event);
								},
							},
							{
								"hash":"1IEMV3T4G0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("单步执行"):("Step run")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1IEMV2CKF0",
								"type":BtnSwitch(16,false),"id":"BtnStep","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
								/*#{1IEMV2CKF0Codes*/
								OnCheck(checked){
									if(checked){
										ws.send(JSON.stringify({cmd:"StepRunOn"}));
									}else{
										self.showPaused(false);
										ws.send(JSON.stringify({cmd:"StepRunOff"}));
									}
								}
								/*}#1IEMV2CKF0Codes*/
							},
							{
								"hash":"1IEMV6CJ30",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":0,"enable":false,"margin":[0,0,0,5],
								"OnClick":function(event){
									self.stepRun(this,event);
								},
							}
						],
					},
					{
						"hash":"1IELD1N6J0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Logs from agent node","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,
					},
					{
						"hash":"1IELPNAGK0",
						"type":"box","id":"BoxLogs","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"auto-y","padding":0,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"],"flex":true,
					}
				],
			}
		],
		/*#{1IEL76JHR1ExtraCSS*/
		/*}#1IEL76JHR1ExtraCSS*/
		faces:{
			"offline":{
				/*BoxOffline*/"#1IELCGCLA0":{
					"display":1
				},
				/*BoxOnline*/"#1IELCPAHE0":{
					"display":0
				}
			},"online":{
				/*BoxOffline*/"#1IELCGCLA0":{
					"display":0
				},
				/*BoxOnline*/"#1IELCPAHE0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			edAddress=self.EdAddress;txtState=self.TxtState;btnStep=self.BtnStep;btnRun=self.BtnRun;boxLogs=self.BoxLogs;
			/*#{1IEL76JHR1Create*/
			EditPrj.boxDebugAgent=self;
			edAddress.text=localStorage.getItem("DebugAgent_Host")||"";
			//Tool bar			
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="100%";
			self.toolBtnBox.display=true;
			self.showFace("offline");
			self.showPaused(false);
			/*}#1IEL76JHR1Create*/
		},
		/*#{1IEL76JHR1EndCSS*/
		/*}#1IEL76JHR1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.connect=async function(){
		/*#{1IELQ9KCS0Start*/
		let addr,connecting;
		addr=edAddress.text;
		if(!addr.startsWith("ws://")){
			addr="ws://"+addr;
		}
		boxLogs.clearChildren();
		connecting=true;
		ws=this.ws=new WebSocket(addr);
		ws.addEventListener('open',()=>{
			connected=true;
			connecting=false;
			txtState.text=(($ln==="CN")?("已连接"):/*EN*/("Connected"));
			btnStep.checked=false;
			btnRun.enable=false;
			btnRun.display=false;
			localStorage.setItem("DebugAgent_Host",edAddress.text);
			console.log("Agent Debug WS connected.");
			self.showFace("online");
			self.showPaused(false);
		});
		ws.addEventListener('message', (msg) => {
			let log,msgCode,css,icon;
			log=JSON.parse(msg.data);
			console.log("Log from debug server:");
			console.log(log)
			icon=null;
			switch(log.type){
				case "StepRunOn":
					btnStep.checked=true;
					btnRun.display=true;
					break;
				case "StepRunOff":
					btnStep.checked=false;
					btnRun.display=false;
					break;
				case "StepPaused":
					btnRun.enable=true;
					txtState.text=(($ln==="CN")?("已单步暂停"):/*EN*/("Step paused"));
					self.showPaused(true);
					break;
				case "StartAgent":{
					let info;
					app.emit("AIAgentExec",log.agent);
					icon=appCfg.sharedAssets+("/fat_down.svg");
					info=JSON.stringify(log.input)||"";
					css={
						type:InfoCard(log.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:5,log:log
					};
					boxLogs.appendNewChild(css);
					self.scrollLogs();
					break;
				}
				case "EndAgent":{
					let info;
					app.emit("AIAgentEnd",log.agent);
					icon=appCfg.sharedAssets+("/fat_up.svg");
					info=JSON.stringify(log.result)||"";
					css={
						type:InfoCard(log.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:5,log:log
					};
					boxLogs.appendNewChild(css);
					self.scrollLogs();
					break;
				}
				case "StartSeg":{
					let seg,info;
					seg=log.seg;
					if(seg.jaxId){
						app.emit("AISegExec",seg.agent,seg.fromSeg,seg.fromOutlet,seg.jaxId,seg.input,seg.id);
						icon=appCfg.sharedAssets+("/arrowright.svg");
						info=JSON.stringify(seg.input)||"";
						css={
							type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
							border:1,sizeCap:14,sizeLabel:12,margin:5,log:log,
							OnClick(){
								self.showAISegLog(log);
							}
						};
						boxLogs.appendNewChild(css);
						self.scrollLogs();
					}
					break;
				}
				case "EndSeg":{
					let seg,info;
					seg=log.seg;
					if(seg.jaxId){
						app.emit("AISegEnd",seg.agent,seg.jaxId,seg.result,seg.id);
						icon=appCfg.sharedAssets+("/arrowleft.svg");
						info=JSON.stringify(seg.result)||"";
						css={
							type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
							border:1,sizeCap:14,sizeLabel:12,margin:5,log:log,
							OnClick(){
								self.showAISegLog(log);
							}
						};
						boxLogs.appendNewChild(css);
						self.scrollLogs();
					}
					break;
				}
				case "LlmCall":{
					let options;
					options=log.options;
					icon=appCfg.sharedAssets+("/aichat.svg");
					css={
						type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:5,log:log,
						OnClick(){
							self.showCallLLMLog(log);
						}
					};
					//Emit app message
					boxLogs.appendNewChild(css);
					self.scrollLogs();
					{
						let seg;
						seg=log.seg;
						if(seg.jaxId){
							let messages,text;
							text="OPTIONS-----------------------------\n";
							text+=JSON.stringify(log.options,null,"\t");
							text+="\n\nMESSAGES:------------------------------\n\nMESSAGE---------------------------\n\n";
							messages=log.messages.map(item=>(item.content||"NO-CONTENT"));
							text+=messages.join("\n\nMESSAGE---------------------------\n\n");
							app.emit("AISegCallLLMInput",log.agent,seg.jaxId,text,log.callId);
						}
					}
					break;
				}
				case "LlmResult":{
					let options;
					options=log.options;
					icon=appCfg.sharedAssets+("/agent.svg");
					css={
						type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:5,log:log,
						OnClick(){
							self.showCallLLMLog(log);
						}
					};
					boxLogs.appendNewChild(css);
					//Emit app message
					{
						let seg;
						seg=log.seg;
						if(seg.jaxId){
							app.emit("AISegCallLLMResult",log.agent,seg.jaxId,log.result,log.callId);
						}
					}
					self.scrollLogs();
					break;
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			if(connected){
				connected=false;
				self.showFace("offline");
				this.isConnected=false;
				console.log("Agent Debug WS closed.");
			}else{
				self.showFace("offline");
			}
			ws=null;
		});
		ws.addEventListener('error', (msg) => {
			if(connecting){
				self.showFace("offline");
			}else if(connected){
				console.log("Agent Debug WS error.");
				console.error(msg);
			}
		});
		/*}#1IELQ9KCS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.disconnect=async function(){
		/*#{1IELQ9QJU0Start*/
		if(!ws)
			return;
		await ws.close();
		ws=null;
		connected=false;
		/*}#1IELQ9QJU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.stepRun=async function(){
		/*#{1IEMVNF6T0Start*/
		if(ws){
			self.showPaused(false);
			btnRun.enable=false;
			await ws.send(JSON.stringify({cmd:"RunStep"}));
			txtState.text=(($ln==="CN")?("已连接"):/*EN*/("Connected"));
		}
		/*}#1IEMVNF6T0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearLogs=async function(){
		/*#{1IEN20PMU0Start*/
		boxLogs.clearChildren();
		/*}#1IEN20PMU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showCallLLMLog=async function(log){
		/*#{1IEP2QO7G0Start*/
		let opts,messages,result;
		let codes,msg;
		opts=log.options;
		messages=log.messages;
		codes="[LLM-call options]\n";
		codes+=JSON.stringify(opts,null,"\t");codes+="\n\n";
		codes+="[LLM-call Messages]\n";
		for(msg of messages){
			codes+=`<${msg.role}>\n`;
			codes+=msg.content+"\n";
			if(msg.image){
				codes+="[Image]\n"
			}
			codes+="\n"
		}
		result=log.result;
		if(result){
			codes+="\n[LLM-call result]\n"
			codes+=log.result;
		}
		//Show dlg:
		await app.modalDlg("/@editkit/ui/DlgLongText.js",{title:"LLM Call Log",text:codes});
		/*}#1IEP2QO7G0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAISegLog=async function(log){
		/*#{1IEP2RAUM0Start*/
		let codes,seg;
		seg=log.seg;
		codes=`[AISeg]:\n${seg.url}\n`;
		if(seg.input){
			codes+=`[Input]\n`;
			codes+=JSON.stringify(seg.input,null,"\t")+"\n";
		}
		if(seg.result){
			codes+=`[Result]\n`;
			codes+=JSON.stringify(seg.result,null,"\t")+"\n";
		}
		//Show dlg:
		await app.modalDlg("/@editkit/ui/DlgLongText.js",{title:"Run AI-Seg",text:codes});
		/*}#1IEP2RAUM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showPaused=async function(isPaused){
		/*#{1IEP73TQ40Start*/
		if(isPaused){
			if(!orgTitle){
				orgTitle=document.title;
				document.title="🔴"+orgTitle;
			}
			tab.showFace("mark");
		}else{
			if(orgTitle){
				document.title=orgTitle;
				orgTitle=null;
			}
			tab.showFace("!mark");
		}
		/*}#1IEP73TQ40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.scrollLogs=function(){
		/*#{1IEP7HRCB0Start*/
		let webObj;
		webObj=boxLogs.webObj;
		webObj.scrollTop = webObj.scrollHeight;		
		/*}#1IEP7HRCB0Start*/
	};
	/*#{1IEL76JHR1PostCSSVO*/
	/*}#1IEL76JHR1PostCSSVO*/
	cssVO.constructor=TBXDebugAgent;
	return cssVO;
};
/*#{1IEL76JHR1ExCodes*/
TBXDebugAgent.tbxCodeName="DebugAgent";
TBXDebugAgent.tbxTip=(($ln==="CN")?("远程调试智能体"):/*EN*/("Remote debug agent"));
TBXDebugAgent.tbxIcon=appCfg.sharedAssets+"/trycatch.svg";
TBXDebugAgent.tbxIconPad=2;
/*}#1IEL76JHR1ExCodes*/

//----------------------------------------------------------------------------
TBXDebugAgent.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IEL76JHR1PreAISpot*/
	/*}#1IEL76JHR1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IEL76JHR1PostAISpot*/
	/*}#1IEL76JHR1PostAISpot*/
	return exposeVO;
};

/*#{1IEL76JHR0EndDoc*/
/*}#1IEL76JHR0EndDoc*/

export default TBXDebugAgent;
export{TBXDebugAgent};
