//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GCLCQBQT0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GCLCQBQT0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALColor=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnMenu;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GCLCQBQT7LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	/*}#1GCLCQBQT7LocalVals*/
	
	/*#{1GCLCQBQT7PreState*/
	/*}#1GCLCQBQT7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val,"valText":attrObj.valText,
		"hyper":attrObj.hyper,"valShowText":attrObj.valText,
		/*#{1GCLCQBQT5ExState*/
		/*}#1GCLCQBQT5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GCLCQBQT7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GCLCQBQT7PostState*/
	cssVO={
		"hash":"1GCLCQBQT7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GCLD5A2N0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GCLD710V0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"FH","h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GCLD8TVU0",
						"type":"image","x":3,"y":3,"w":"FW-6","h":"FH-6","alpha":0.65,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":appCfg.sharedAssets+"/checker.svg",
						"fitSize":true,"repeat":false,
					},
					{
						"hash":"1GCLDCHCB0",
						"type":"box","x":3,"y":3,"w":"FW-6","h":"FH-6","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.value),state),
						"border":1,
					}
				],
			},
			{
				"hash":"1IA75CDQB0",
				"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
				"OnClick":function(event){
					/*#{1IA75D8K20FunctionBody*/
					self.chooseColor();
					/*}#1IA75D8K20FunctionBody*/
				},
			},
			{
				"hash":"1GCLD64DI0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GCLD6D7M0",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.valShowText}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
			},
			{
				"hash":"1GCLD6LP20",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GCLCQBQT7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GCLCQBQT7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GCLD5A2N0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GCLD5A2N0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GCLD5A2N0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GCLD5A2N0":{
					"shadow":true
				},
				/*TxtVal*/"#1GCLD6D7M0":{
					"display":0
				},
				/*#{1GCLD4QPI0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GCLD4QPI0Code*/
			},"editOff":{
				/*BoxBG*/"#1GCLD5A2N0":{
					"shadow":false
				},
				/*TxtVal*/"#1GCLD6D7M0":{
					"display":1
				},
				/*#{1GCLD4V4U0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GCLD4V4U0Code*/
			},"showEdit":{
				/*#{1GDV47T6V0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV47T6V0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnMenu=self.BtnMenu;
			/*#{1GCLCQBQT7Create*/
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			/*}#1GCLCQBQT7Create*/
		},
		/*#{1GCLCQBQT7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.valShowText}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GCLCQBQT7EndCSS*/
	};
	/*#{1GCLCQBQT7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val;
		state.valShowText=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		let attrDef;
		attrDef=attrObj.def;
		app.showDlg(DlgRawEditAttr,{
			line:self,box:box,mode:attrObj.def.type,
			attrObj:attrObj,
			choice:attrDef.colorCfg!==false,
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseColor=function(){
		let items,prj,item,ownerObj,doc;
		ownerObj=attrObj.owner;
		doc=ownerObj.doc;
		prj=doc.prj;
		items=[];
		if(prj && doc!==prj.docConfig){
			let attr,colors;
			colors=prj.objConfig.getAttr("color");
			if(colors){
				colors=colors.attrList;
				for(attr of colors){
					item={text:attr.name,name:attr.name};
					items.push(item);
					if(attr.def.type==="colorRGB"||attr.def.type==="colorRGBA"||Array.isArray(attr.val)){
						item.icon="";
						item.iconColor=attr.val;
					}
				}
				app.showDlg("/@StdUI/ui/DlgMenu.js",{
					hud:btnMenu,maxLines:10,items:items,
					callback(item){
						let valText;
						if(!item){
							return;
						}
						valText=`#cfgColor["${item.name}"]`;
						box.setAttrByText(attrObj,valText);
					}
				});
			}
		}
	};
	/*}#1GCLCQBQT7PostCSSVO*/
	return cssVO;
};
/*#{1GCLCQBQT7ExCodes*/
EditAttrsBox.regAttrBox("colorRGB",EALColor);
EditAttrsBox.regAttrBox("colorRGBA",EALColor);
/*}#1GCLCQBQT7ExCodes*/


/*#{1GCLCQBQT0EndDoc*/
/*}#1GCLCQBQT0EndDoc*/

export default EALColor;
export{EALColor};
