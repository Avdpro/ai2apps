//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxSteps} from "/@StdUI/ui/BoxSteps.js";
/*#{1GAHP4NLN0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GAHP4NLN0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALStepAttr=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GAHP4NLN7LocalVals*/
	let attrDef,stepDelta;
	attrDef=attrObj.def;
	icon=attrObj.icon||attrDef.icon||null;
	stepDelta=attrDef.step||1;
	/*}#1GAHP4NLN7LocalVals*/
	
	/*#{1GAHP4NLN7PreState*/
	/*}#1GAHP4NLN7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val2ShowText(attrObj.val),
		"hyper":attrObj.hyper,"valText":attrObj.valText,
		/*#{1GAHP4NLN5ExState*/
		/*}#1GAHP4NLN5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GAHP4NLN7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GAHP4NLN7PostState*/
	cssVO={
		"hash":"1GAHP4NLN7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GAHQF4D10",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GAHPBGTV0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GAHQFBKP0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GAHPC72U0",
				"type":BoxSteps(20),"id":"BtnStep","position":"relative","x":0,"y":"FH/2","anchorY":1,
				/*#{1GAHPC72U0Codes*/
				OnStep(dir){
					self.updateVal(dir);
				}
				/*}#1GAHPC72U0Codes*/
			},
			{
				"hash":"1GAHQFGP30",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.value}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
			},
			{
				"hash":"1HHTL68EU0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GAHP4NLN7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GAHP4NLN7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GAHQF4D10":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GAHQF4D10":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GAHQF4D10":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GAHQF4D10":{
					"shadow":true
				},
				/*TxtVal*/"#1GAHQFGP30":{
					"display":0
				},
				/*#{1GAHQEP0J0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GAHQEP0J0Code*/
			},"editOff":{
				/*BoxBG*/"#1GAHQF4D10":{
					"shadow":false
				},
				/*TxtVal*/"#1GAHQFGP30":{
					"display":1
				},
				/*#{1GAHQEROH0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GAHQEROH0Code*/
			},"showEdit":{
				/*#{1GDV460AP0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV460AP0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GAHP4NLN7Create*/
			box.regAttrLine(attrObj,self);
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			attrObj.traceOn(self.OnAttrChange);
			/*}#1GAHP4NLN7Create*/
		},
		/*#{1GAHP4NLN7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GAHP4NLN7EndCSS*/
	};
	/*#{1GAHP4NLN7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
	};
	
	//------------------------------------------------------------------------
	cssVO.updateVal=function(dir){
		let d,val,valText;
		valText=attrObj.valText;
		if(!Number.isFinite(parseFloat(valText))){
			app.showStateText(`Value expression "${valText}" can't be steped.`);
			return;
		}
		d=dir*stepDelta;
		val=attrObj.val+d;
		if("minVal" in attrDef){
			if(val<attrDef.minVal){
				val=attrDef.minVal;
			}
		}
		if("maxVal" in attrDef){
			if(val>attrDef.maxVal){
				val=attrDef.maxVal;
			}
		}
		if("valFixDigit" in attrDef){
			val=val.toFixed(attrDef.valFixDigit);
		}
		valText=`${val}`;
		box.setAttrByText(attrObj,valText);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			if(attrDef.rawEdit!==false && box.rawEdit!==false){
				self.startEdit();
			}
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		app.showDlg(DlgRawEditAttr,{
			line:self,box:box,
			attrObj:attrObj
		});
	};
	/*}#1GAHP4NLN7PostCSSVO*/
	return cssVO;
};
/*#{1GAHP4NLN7ExCodes*/
EditAttrsBox.regAttrBox("step",EALStepAttr);
/*}#1GAHP4NLN7ExCodes*/


/*#{1GAHP4NLN0EndDoc*/
/*}#1GAHP4NLN0EndDoc*/

export default EALStepAttr;
export{EALStepAttr};
