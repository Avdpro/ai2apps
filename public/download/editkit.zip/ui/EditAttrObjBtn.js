//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GA8H0C960StartDoc*/
/*}#1GA8H0C960StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EditAttrObjBtn=function(app,obj,box){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	let allowAddAttr=true;
	
	/*#{1GA8H0C967LocalVals*/
	let attrDef,objDef;
	let isOpen=0;
	let line=null;
	attrDef=obj.def;
	objDef=obj.objDef;
	allowAddAttr=objDef.allowExtraAttr;
	icon=(obj.icon||attrDef.icon||objDef.icon||"object.svg");
	if(icon[0]!=="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GA8H0C967LocalVals*/
	
	/*#{1GA8H0C967PreState*/
	/*}#1GA8H0C967PreState*/
	state={
		"canOpen":true,"name":"Object",
		/*#{1GA8H0C965ExState*/
		/*}#1GA8H0C965ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GA8H0C967PostState*/
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	let name;
	name=obj.getName?obj.getName(obj):(obj.showName||attrDef.showName||obj.name||attrDef.name);;
	if(name instanceof Function){
		name=name.call(obj);
	}
	state.name=name;
	/*}#1GA8H0C967PostState*/
	cssVO={
		"hash":"1GA8H0C967",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GA8H76OK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],
			},
			{
				"hash":"1GA8H8PLH0",
				"type":BtnIcon("front",16,0,appCfg.sharedAssets+"/collapse.svg",null),"id":"BtnOpen","position":"relative","x":8,"y":"FH/2","anchorY":1,"margin":[0,0,0,0],
				"anchorX":1,"enable":$P(()=>(state.canOpen),state),"padding":2,
				/*#{1GA8H8PLH0Codes*/
				OnClick(){
					if(isOpen){
						line.close();
					}else{
						line.open();
					}
				}
				/*}#1GA8H8PLH0Codes*/
			},
			{
				"hash":"1GA8H8PMT0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.naviLineH-6,"h":cfgSize.naviLineH-6,"anchorY":1,"margin":[0,3,0,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontTool,"maskImage":icon,
			},
			{
				"hash":"1GA8H8PP40",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.naviLineH,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontTool,"text":$P(()=>(state.name),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"autoW":true,
			},
			{
				"hash":"1GD8JAMOJ0",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnAction","position":"relative","x":0,"y":"FH/2","image":appCfg.sharedAssets+"/run.svg",
				"anchorY":1,"attached":obj.objDef.action,"padding":1,
				/*#{1GD8JAMOJ0Codes*/
				OnClick:function(){
					self.BtnAction.enable=0;
					obj[obj.objDef.action](()=>{
						self.BtnAction.enable=1;
					});
				}
				/*}#1GD8JAMOJ0Codes*/
			},
			{
				"hash":"1GA8HF7HG0",
				"type":BtnIcon("front",cfgSize.naviLineH-4,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddAttr","position":"relative","x":0,"y":"FH/2","display":0,
				"anchorY":1,"margin":[0,0,0,3],"autoLayout":true,"padding":1,
				/*#{1GA8HF7HG0Codes*/
				OnClick:function(){
					box.addNewAttr(obj,line);
				}
				/*}#1GA8HF7HG0Codes*/
			}
		],
		/*#{1GA8H0C967ExtraCSS*/
		attrObj:obj,
		/*}#1GA8H0C967ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GA8H76OK0":{
					"display":0
				}
			},"over":{
				/*BoxBG*/"#1GA8H76OK0":{
					"display":1,"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GA8H76OK0":{
					"background":cfgColor.lineBodyLit,"display":1
				}
			},"focus":{
			},"blur":{
			},"open":{
				/*BtnOpen*/"#1GA8H8PLH0":{
					"rotate":90
				},
				/*BtnAddAttr*/"#1GA8HF7HG0":{
					"display":allowAddAttr
				},
				/*#{1GA8I97I20Code*/
				$(){
					isOpen=1;
					box.hideMetaMenu(self);
				}
				/*}#1GA8I97I20Code*/
			},"close":{
				/*BtnOpen*/"#1GA8H8PLH0":{
					"rotate":0
				},
				/*BtnAddAttr*/"#1GA8HF7HG0":{
					"display":0
				},
				/*#{1GA8I9C420Code*/
				$(){
					isOpen=0;
					box.showMetaMenu(self);
				}
				/*}#1GA8I9C420Code*/
			},"editOn":{
				/*#{1GBV0R5O50Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.margin=[0,0,vo.dlgH,0];
					}
				}
				/*}#1GBV0R5O50Code*/
			},"editOff":{
				/*#{1GBV0R9NQ0Code*/
				$(vo){
					self.margin=[0,0,0,0];
				}
				/*}#1GBV0R9NQ0Code*/
			},"showEdit":{
				/*#{1GDV4D9R20Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV4D9R20Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA8H0C967Create*/
			boxBG=self.BoxBG;
			line=self.parent;
			obj.traceOn(self.OnAttrChange);
			/*}#1GA8H0C967Create*/
		},
		/*#{1GA8H0C967EndCSS*/
		OnFree:function(){
			obj.traceOff(self.OnAttrChange);
		},
		/*}#1GA8H0C967EndCSS*/
	};
	/*#{1GA8H0C967PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		let name;
		name=obj.getName?obj.getName():(obj.showName||attrDef.showName||obj.name||attrDef.name);
		state.name=name;
		state.value=obj.val2ShowText(obj.val);
		state.hyper=obj.hyper;
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(){
		if(isOpen){
			line.close();
		}else{
			line.open();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn){
		if(box){
			if(!isOpen){
				if(isIn ){
					box.showMetaMenu(self);
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
	};
	/*}#1GA8H0C967PostCSSVO*/
	return cssVO;
};
/*#{1GA8H0C967ExCodes*/
/*}#1GA8H0C967ExCodes*/

EditAttrObjBtn.gearExport={
	framework: "vfact",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"obj": {
			"name": "obj", "showName": "obj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"objDef":{"action":"playAni"}}
		}, 
		"box": {
			"name": "box", "showName": "box", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display","face"],
	faces:["up","over","down","focus","blur","open","close","editOn","editOff","showEdit"],
	subContainers:{
	},
	/*#{1GA8H0C960ExGearInfo*/
	/*}#1GA8H0C960ExGearInfo*/
};
/*#{1GA8H0C960EndDoc*/
/*}#1GA8H0C960EndDoc*/

export default EditAttrObjBtn;
export{EditAttrObjBtn};
