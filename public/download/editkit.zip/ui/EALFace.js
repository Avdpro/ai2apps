//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GD2K22JP0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GD2K22JP0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALFace=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GD2K22JP7LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	/*}#1GD2K22JP7LocalVals*/
	
	/*#{1GD2K22JP7PreState*/
	/*}#1GD2K22JP7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val,"valText":attrObj.valText,
		"hyper":attrObj.hyper,"valShowText":attrObj.valText,
		/*#{1GD2K22JP5ExState*/
		/*}#1GD2K22JP5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GD2K22JP7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GD2K22JP7PostState*/
	cssVO={
		"hash":"1GD2K22JP7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GD2LI27H0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GD2LO9QU0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":3,"w":"FH-6","h":"FH-6","margin":[0,2,0,2],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.fontBody,"maskImage":appCfg.sharedAssets+"/faces.svg",
			},
			{
				"hash":"1GD2LIM130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GD2LRE5C0",
				"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":"FH/2","anchorY":1,"image":appCfg.sharedAssets+"/btncombo.svg",
				"padding":2,
				/*#{1GD2LRE5C0Codes*/
				OnClick(){
					self.showMenu();
				}
				/*}#1GD2LRE5C0Codes*/
			},
			{
				"hash":"1GD2LJ4ET0",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.valShowText}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"autoW":true,"flex":true,
			},
			{
				"hash":"1GD2LK1HG0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GD2K22JP7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GD2K22JP7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GD2LI27H0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GD2LI27H0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GD2LI27H0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GD2LI27H0":{
					"shadow":true
				},
				/*TxtVal*/"#1GD2LJ4ET0":{
					"display":0
				},
				/*#{1GD2K8KSA0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GD2K8KSA0Code*/
			},"editOff":{
				/*BoxBG*/"#1GD2LI27H0":{
					"shadow":false
				},
				/*TxtVal*/"#1GD2LJ4ET0":{
					"display":1
				},
				/*#{1GD2K8OO90Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GD2K8OO90Code*/
			},"showEdit":{
				/*#{1GDV4AO600Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV4AO600Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GD2K22JP7Create*/
			txtVal=self.txtVal;
			boxBG=self.BoxBG;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			/*}#1GD2K22JP7Create*/
		},
		/*#{1GD2K22JP7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.valShowText}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GD2K22JP7EndCSS*/
	};
	/*#{1GD2K22JP7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val;
		state.valShowText=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
		if(state.valText===""||state.value===""){
			self.resetFace();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		app.showDlg(DlgRawEditAttr,{
			line:self,box:box,
			attrObj:attrObj,
			filterValText(text){
				let val;
				if(text===""){
					return "";
				}
				if(text.startsWith("#")||text.startsWith("${")){
					//Hyper val
					return text;
				}
				if(text.startsWith("\"")||text.startsWith("'")||text.startsWith("`")||text.startsWith("[")){
					return text;
				}
				text="\""+text;
				if(text.endsWith("\"")){
					return text;
				}
				return text+"\"";
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=function(){
		let items,hudObj,objDef,faces,i,n;
		items=[{text:"No Init Face",value:'""',icon:appCfg.sharedAssets+"/faces.svg"}];
		hudObj=attrObj.owner.owner;
		if(hudObj.isHudFace){
			hudObj=hudObj.owner.owner;
		}
		objDef=hudObj.objDef;
		faces=objDef.faces;
		if(faces){
			n=faces.length;
			for(i=0;i<n;i++){
				items.push({text:faces[i],value:`"${faces[i]}"`,icon:appCfg.sharedAssets+"/faces.svg"});
			}
		}
		self.state=0;
		app.showDlg(DlgMenu,{
			hud:self,items:items,
			callback:(item,evt)=>{
				if(item){
					box.setAttrByText(attrObj,item.value);
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.resetFace=function(){
		let hudObj,hudFace;
		hudObj=attrObj.owner.owner;
		if(hudObj.isHudObj){
			return;
		}
		if(hudObj.isHudFace){
			//This is in face edit
			hudFace=hudObj;
			hudObj=hudFace.owner.owner;
			hudObj.rebuildLiveObj();
			hudObj.enterFaceEdit(hudFace.faceTag,true,false);
		}
	};
	/*}#1GD2K22JP7PostCSSVO*/
	return cssVO;
};
/*#{1GD2K22JP7ExCodes*/
EditAttrsBox.regAttrBox("face",EALFace);
/*}#1GD2K22JP7ExCodes*/


/*#{1GD2K22JP0EndDoc*/
/*}#1GD2K22JP0EndDoc*/

export default EALFace;
export{EALFace};
