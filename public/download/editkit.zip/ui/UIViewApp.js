import {VFACT} from "/@vfact";
import {UIView} from "./ui/UIView.js";
/*#{MoreImports*/
/*}#MoreImports*/
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	
	document.title="UI Preview";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	uiDef=UIView(app,appFrame);
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		appFrame:appFrame,
	});
	/*}#AppCode*/
}
startApp();

/*#{EndDoc*/
/*}#EndDoc*/
