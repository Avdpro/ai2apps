//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GACUOMUR0StartDoc*/
import {EditAttr} from "../EditAttr.js";
import {EALGroup} from "./EALGroup.js";
import {LineCard} from "./LineCard.js";
import {EditHudAni} from "../edithud/EditHudAni.js";
/*}#1GACUOMUR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgNewAttr=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GACUOMUR7LocalVals*/
	let dlgVO,mode,editObj;
	let curLine=null;
	let listBox=null;
	let edName=null;
	let txtInfo=null;
	let needName=true;
	/*}#1GACUOMUR7LocalVals*/
	
	/*#{1GACUOMUR7PreState*/
	/*}#1GACUOMUR7PreState*/
	/*#{1GACUOMUR7PostState*/
	/*}#1GACUOMUR7PostState*/
	cssVO={
		"hash":"1GACUOMUR7",nameHost:true,
		"type":"box","id":"DlgNewAttr","x":8,"y":11,"w":380,"h":620,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
		"border":2,"borderColor":cfgColor.lineBodySub,"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
		children:[
			{
				"hash":"1GACVK1L70",
				"type":"hud","id":"BoxDlg","position":"relative","x":0,"y":0,"w":"100%","h":"","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","traceSize":true,
				children:[
					{
						"hash":"1IA50PVHP0",
						"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"cursor":"move","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1IA50QND50",
								"type":"text","x":5,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
								"text":(($ln==="CN")?("添加新属性"):("New Attribute")),"fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1IA50U7BJ0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 28px)","y":"50%","anchorY":1,
								"OnClick":function(event){
									/*#{1IA513U2R0FunctionBody*/
									self.close();
									/*}#1IA513U2R0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1IA514OS90",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[0,0,1,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["gntLineBreak"],
					},
					{
						"hash":"1GAD069C80",
						"type":"hud","id":"TypeList","position":"relative","x":0,"y":0,"w":"100%","h":500,"overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
					},
					{
						"hash":"1GM5E8QNU0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[5,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,
					},
					{
						"hash":"1GAEULSEU0",
						"type":"hud","id":"BoxInfo","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAEUMU410",
								"type":"text","id":"TxtInfo","x":20,"y":0,"w":">calc(100% - 40px)","h":txtSize.smallMid,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor.fontBodySub,"text":(($ln==="CN")?("输入属性名称："):("Input attribute name:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"",
							}
						],
					},
					{
						"hash":"1GAD07HN50",
						"type":"hud","id":"BoxName","position":"relative","x":0,"y":0,"w":"100%","h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAD0AC520",
								"type":"edit","id":"EdName","x":"50%","y":"50%","w":">calc(100% - 50px)","h":25,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","placeHolder":(($ln==="CN")?("属性名称"):("Attribute name")),"color":cfgColor["fontBody"],"background":cfgColor.body,"fontSize":txtSize.smallMid,
								"outline":0,"border":1,"borderColor":cfgColor.lineBody,
								/*#{1GAD0AC520Codes*/
								OnUpdate(){
									self.doAddAttr(1);
								},
								OnInput(){
									self.updateBtn();
								}
								/*}#1GAD0AC520Codes*/
							}
						],
					},
					{
						"hash":"1GAD0E40M0",
						"type":"hud","id":"BoxBtns","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","subAlign":3,"itemsAlign":1,
						children:[
							{
								"hash":"1GAD0H8PM0",
								"type":BtnText("",100,24,"Button",false,""),"id":"BtnStay","position":"relative","x":0,"y":0,"text":(($ln==="CN")?("添加并停留"):("Add & Stay")),"corner":3,
								/*#{1GAD0H8PM0Codes*/
								OnClick(){
									self.doAddAttr(0);
								}
								/*}#1GAD0H8PM0Codes*/
							},
							{
								"hash":"1GAF0JP650",
								"type":BtnText("",100,24,"Button",false,""),"id":"BtnAdd","position":"relative","x":0,"y":0,"text":(($ln==="CN")?("添加并关闭"):("Add & Close")),"corner":3,
								/*#{1GAF0JP650Codes*/
								OnClick(){
									self.doAddAttr(1);
								}
								/*}#1GAF0JP650Codes*/
							},
							{
								"hash":"1GAD0JLUO0",
								"type":BtnText("",100,24,"Button",false,""),"id":"BtnClose","position":"relative","x":0,"y":0,"text":(($ln==="CN")?("关闭"):("Close")),"corner":3,
								/*#{1GAD0JLUO0Codes*/
								OnClick(){
									self.close();
								}
								/*}#1GAD0JLUO0Codes*/
							}
						],
					}
				],
			}
		],
		/*#{1GACUOMUR7ExtraCSS*/
		/*}#1GACUOMUR7ExtraCSS*/
		faces:{
			"nameOn":{
				/*BoxInfo*/"#1GAEULSEU0":{
					"display":1
				},
				/*BoxName*/"#1GAD07HN50":{
					"display":1
				}
			},"nameOff":{
				/*BoxInfo*/"#1GAEULSEU0":{
					"display":0
				},
				/*BoxName*/"#1GAD07HN50":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;
			/*#{1GACUOMUR7Create*/
			VFACT.applyMoveDrag(boxHeader,self);
			listBox=self.TypeList;
			edName=self.EdName;
			txtInfo=self.TxtInfo;
			/*}#1GACUOMUR7Create*/
		},
		/*#{1GACUOMUR7EndCSS*/
		/*}#1GACUOMUR7EndCSS*/
	};
	/*#{1GACUOMUR7PostCSSVO*/
	let typeAuto={
		name:"auto",showName:(($ln==="CN")?("自动类型"):/*EN*/("Auto")),info:(($ln==="CN")?("自动类型的属性或变量。"):/*EN*/("Auto typed property or variable.")),
		icon:"var_auto.svg",def:{type:"auto",extraAttr:1}
	};
	let typePptAuto={
		name:"auto",showName:(($ln==="CN")?("自动类型"):/*EN*/("Auto")),info:(($ln==="CN")?("自动类型的属性。"):/*EN*/("Auto typed property or variable.")),
		icon:"var_auto.svg",def:{type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":"auto"}}
	};
	let typeInt={
		name:"int",showName:(($ln==="CN")?("整数"):/*EN*/("Integer")),info:(($ln==="CN")?("整数属性或变量。"):/*EN*/("Integer property or variable.")),
		icon:"var_int.svg",def:{type:"int",extraAttr:1}
	};
	let typePptInt={
		name:"int",showName:(($ln==="CN")?("整数"):/*EN*/("Integer")),info:(($ln==="CN")?("整数属性或变量。"):/*EN*/("Integer property or variable.")),
		icon:"var_int.svg",def:{type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":"int"}}
	};
	let typeFontSize={
		name:"fontSize",showName:/*EN*/("Font Size"),info:(($ln==="CN")?("整数字体大小属性或变量。"):/*EN*/("Integer-font-size property or variable.")),
		icon:"var_int.svg",def:{type:"int",extraAttr:1,initVal:16,editType:"fontSize"}
	};
	let typeString={
		name:"string",showName:(($ln==="CN")?("字符串"):/*EN*/("String")),info:(($ln==="CN")?("字符串属性或变量。"):/*EN*/("String property or variable.")),
		icon:"var_str.svg",def:{type:"string",extraAttr:1}
	};
	let typePptString={
		name:"string",showName:(($ln==="CN")?("字符串"):/*EN*/("String")),info:(($ln==="CN")?("字符串属性。"):/*EN*/("String property or variable.")),
		icon:"var_int.svg",def:{type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":"string"}}
	};
	let typeLocString={
		name:"locString",showName:(($ln==="CN")?("本地化字符串"):/*EN*/("Localized String")),info:(($ln==="CN")?("支持多语言的字符串。"):/*EN*/("String supports multi-language.")),
		icon:"var_str.svg",def:{type:"string",extraAttr:1,localizable:true}
	};
	let typeNumber={
		name:"number",showName:(($ln==="CN")?("数字"):/*EN*/("Number")),info:(($ln==="CN")?("数值（浮点数或整数）属性或变量。"):/*EN*/("Number (float or integer) property or variable.")),
		icon:"var_num.svg",def:{type:"number",extraAttr:1}
	};
	let typePptNumber={
		name:"number",showName:(($ln==="CN")?("数字"):/*EN*/("Number")),info:(($ln==="CN")?("数值（浮点数或整数）属性。"):/*EN*/("Number (float or integer) property or variable.")),
		icon:"var_num.svg",def:{type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":"number"}}
	};
	let typeBool={
		name:"boolean",showName:(($ln==="CN")?("布尔型"):/*EN*/("Boolean")),info:(($ln==="CN")?("布尔属性或变量。"):/*EN*/("Boolean property or variable.")),
		icon:"var_bool.svg",def:{type:"bool",extraAttr:1}
	};
	let typePptBool={
		name:"boolean",showName:(($ln==="CN")?("布尔型"):/*EN*/("Boolean")),info:(($ln==="CN")?("布尔属性。"):/*EN*/("Boolean property or variable.")),
		icon:"var_bool.svg",def:{type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":"bool"}}
	};
	let typeRGB={
		name:"rgb",showName:(($ln==="CN")?("RGB 颜色"):/*EN*/("Color RGB")),info:(($ln==="CN")?("颜色属性或变量，没有透明度因素。"):/*EN*/("Color property or variable without alpha factor.")),
		icon:"var_rgb.svg",def:{type:"colorRGB",extraAttr:1}
	};
	let typeRGBA={
		name:"rgba",showName:(($ln==="CN")?("RGBA 颜色"):/*EN*/("Color RGBA")),info:(($ln==="CN")?("颜色属性或带有透明度因素的变量。"):/*EN*/("Color property or variable with alpha factor.")),
		icon:"var_rgba.svg",def:{type:"colorRGBA",extraAttr:1}
	};
	let typeFile={
		name:"file",showName:(($ln==="CN")?("文件路径"):/*EN*/("File Path")),info:(($ln==="CN")?("文件路径属性。"):/*EN*/("File path property.")),
		icon:"file.svg",def:{type:"file",extraAttr:1}
	};
	let typeURL={
		name:"url",showName:(($ln==="CN")?("URL路径"):/*EN*/("URL Path")),info:(($ln==="CN")?("URL路径属性."):/*EN*/("URL path property.")),
		icon:"link.svg",def:{type:"url",extraAttr:1}
	};
	let typeObj={
		name:"object",showName:(($ln==="CN")?("对象"):/*EN*/("Object")),info:(($ln==="CN")?("对象属性或变量。"):/*EN*/("Object property or variable.")),
		icon:"object.svg",def:{type:"object",def:"Object",extraAttr:1}
	};
	let typePptObj={
		name:"object",showName:(($ln==="CN")?("对象"):/*EN*/("Object")),info:(($ln==="CN")?("对象属性。"):/*EN*/("Object property.")),
		icon:"object.svg",def:{type:"object",def:"EditClassObjPpt",extraAttr:1}
	};
	let typeArray={
		name:"array",showName:(($ln==="CN")?("数组"):/*EN*/("Array")),info:(($ln==="CN")?("数组属性或变量。"):/*EN*/("Array property or variable.")),
		icon:"array.svg",def:{type:"array",def:"Array",extraAttr:1}
	};
	let typePptArray={
		name:"array",showName:(($ln==="CN")?("数组"):/*EN*/("Array")),info:(($ln==="CN")?("数组属性。"):/*EN*/("Array property.")),
		icon:"array.svg",def:{type:"object",def:"EditClassAryPpt",extraAttr:1}
	};
	let typeFlatObj={
		name:"flatObj",showName:(($ln==="CN")?("JSON对象"):/*EN*/("JSON-Object")),info:(($ln==="CN")?("该属性可以被JSON.stringify转换为字符串的对象。"):/*EN*/("Object that property can be JSON.stringify.")),
		icon:"array.svg",def:{type:"object",def:"FlatObj",extraAttr:1}
	};
	let typeFlatArray={
		name:"flatArray",showName:(($ln==="CN")?("JSON数组"):/*EN*/("JSON-Array")),info:(($ln==="CN")?("可以使用JSON.stringify转换为数组的属性。"):/*EN*/("Array property that can be JSON.stringify.")),
		icon:"object.svg",def:{type:"object",def:"FlatObj",extraAttr:1}
	};
	let baseType={
		group:1,showName:(($ln==="CN")?("基本类型"):/*EN*/("Basic Types")),
		types:[typeAuto,typeInt,typeString,typeLocString,typeNumber,typeBool,typeFontSize,typeRGB,typeRGBA,typeFile,typeURL,typeObj,typeArray]
	};
	let pptTypes={
		group:1,showName:(($ln==="CN")?("基本类型"):/*EN*/("Basic Types")),
		types:[typePptAuto,typePptInt,typePptString,typePptNumber,typePptBool,typePptObj,typePptArray]
	};
	let flatBaseType={
		group:1,showName:(($ln==="CN")?("JSON兼容类型"):/*EN*/("Basic JSON Types")),
		types:[typeAuto,typeInt,typeString,typeLocString,typeNumber,typeBool,typeFontSize,typeRGB,typeRGBA,typeFile,typeURL,typeFlatObj,typeArray]
	};
	let aniTypes=EditHudAni.getDefList();
	aniTypes=aniTypes.map(def=>{
		return {
			name:def.name,showName:def.showName||def.name,info:def.info||(($ln==="CN")?("组件动画"):/*EN*/("Component animate")),
			icon:def.icon||"ani.svg",def:{type:"hudani",def:def,extraAttr:1}
		};
	})
	let aniType={
		group:1,showName:(($ln==="CN")?("动画"):/*EN*/("Animates")),
		types:aniTypes
	};
	let mockups={
		group:1,showName:(($ln==="CN")?("数据模拟"):/*EN*/("Data Mockup")),
		types:[]
	};
	let mockupClass=function(){
		let list;
		list=EditAttr.getClassList();
		list=list.map(classObj=>{
			return {
				name:classObj.name,showName:classObj.showName||classObj.name,info:"Data Class",
				icon:"class.svg",def:{type:"mockup",className:classObj.codeName,extraAttr:1}
			};
		});
		mockups.types=list;
		return mockups;
	};
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let types,x;
		dlgVO=vo;
		types=[];
		editObj=vo.editObj;
		mode=vo.mode||"ExtraAttr";//"ExtraAttr", "GearArg", "ClassPpt", "LocalVar", "StatePpt"
		needName=true;
		switch(mode){
			default:
			case "ExtraAttr":{
				if(editObj.flatObj||editObj.objDef.flatObj||editObj.def.flatObj){
					types.push({...flatBaseType,open:1});
				}else{
					types.push({...baseType,open:1});
					types.push(mockupClass());
				}
				needName=true;
				break;
			}
			case "HudAni":{
				types.push({...aniType,open:1});
				needName=false;
				break;
			}
			case "ArrayElement":{
				if(editObj.flatObj||editObj.objDef.flatObj||editObj.def.flatObj){
					types.push({...flatBaseType,open:1});
				}else{
					types.push({...baseType,open:1});
				}
				needName=false;
				break;
			}
			case "FuncArg":
			case "GearArg":{
				types.push({...flatBaseType,open:1});
				types.push(mockupClass());
				needName=true;
				break;
			}
			case "ClassPpt":{
				types.push({...pptTypes,open:1});
				//types.push(mockupClass());
				needName=true;
				break;
			}
			case "LocalVar":{
				types.push({...baseType,open:1});
				types.push(mockupClass());
				needName=true;
				break;
			}
			case "StatePpt":{
				types.push({...baseType,open:1});
				types.push(mockupClass());
				needName=true;
				break;
			}
		}
		curLine=null;
		listBox.clearChildren();
		self.addTypes(types,self.TypeList);
		self.BtnAdd.enable=0;
		self.BtnStay.enable=0;
		if(vo.x>=0){
			let rect,hud;
			hud=vo.hud||vo.uiObj;
			if(hud){
				rect=hud.getBoundingClientRect();
				x=vo.x+rect.x;
				if(vo.align===2){
					x-=self.w;
				}
			}
			self.x=x;
		}
		txtInfo.text=(($ln==="CN")?("输入属性名称:"):/*EN*/("Input attribute name:"));
		if(needName===false){
			self.showFace("nameOff");
		}else{
			self.showFace("nameOn");
		}
		self.h=self.BoxDlg.h;
	};
	
	//------------------------------------------------------------------------
	cssVO.addTypes=function(types,ownerBox){
		let stub,css,line;
		function addTypeLine(stub,ownerBox){
			if(stub.group){
				css=EALGroup(app,stub,self,ownerBox);
				line=ownerBox.appendNewChild(css);
				self.addTypes(stub.types,line.boxLines);
				if(stub.open){
					line.open();
				}
			}else{
				css={
					type:LineCard(app,stub,self),stub:stub,
					OnClick(){
						self.focusLine(this);
					}
				};
				line=ownerBox.appendNewChild(css);
			}
		}
		for(stub of types){
			addTypeLine(stub,ownerBox);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focusLine=function(line){
		if(line===curLine){
			return;
		}
		if(curLine){
			curLine.showFace("blur");
		}
		curLine=line;
		if(curLine){
			curLine.showFace("focus");
		}
		self.updateBtn();
		edName.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateBtn=function(){
		let name;
		name=edName.text;
		if(needName){
			if(!name||!curLine){
				txtInfo.text=(($ln==="CN")?("输入属性名称:"):/*EN*/("Input attribute name:"));
				self.BtnAdd.enable=0;
				self.BtnStay.enable=0;
				return;
			}
			if(editObj.getAttr(name)){
				txtInfo.text=(($ln==="CN")?("此属性已存在。"):/*EN*/("This attribute is already existed."));
				self.BtnAdd.enable=0;
				self.BtnStay.enable=0;
			}else{
				txtInfo.text=(($ln==="CN")?("输入属性名称:"):/*EN*/("Input attribute name:"));
				self.BtnAdd.enable=1;
				self.BtnStay.enable=1;
			}
		}else{
			if(curLine){
				self.BtnAdd.enable=1;
				self.BtnStay.enable=1;
			}else{
				self.BtnAdd.enable=0;
				self.BtnStay.enable=0;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doAddAttr=function(close){
		let def,name,stub;
		if(!curLine){
			return;
		}
		if(needName){
			name=edName.text;
			if(!name){
				return;
			}
			if(editObj.getAttr(name)){
				return;
			}
		}
		if(close){
			self.close();
		}
		if(dlgVO.callback){
			stub=curLine.stub;
			if(needName){
				def={...stub.def,name:name};
			}else{
				def={...stub.def};
			}
			dlgVO.callback(def,close);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		app.closeDlg(self);
	};
	
	/*}#1GACUOMUR7PostCSSVO*/
	return cssVO;
};
/*#{1GACUOMUR7ExCodes*/
/*}#1GACUOMUR7ExCodes*/


/*#{1GACUOMUR0EndDoc*/
/*}#1GACUOMUR0EndDoc*/

export default DlgNewAttr;
export{DlgNewAttr};
