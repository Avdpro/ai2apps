//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {NaviTreeBox} from "./NaviTreeBox.js";
/*#{1GA5T3G490StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgNewGear} from "./DlgNewGear.js";
import {DlgFile} from "/@StdUI/ui/DlgFile.js";
/*}#1GA5T3G490StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXNaviPrj=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA5T3G497LocalVals*/
	let appPrj,dataDocs,editPrj;
	let treeBox=null;
	let isFocused=0;
	appPrj=app.prj;
	editPrj=appPrj.codyPrj;
	dataDocs=appPrj.docs;
	let naviView=app.naviView;
	let infoView=app.infoView;
	/*}#1GA5T3G497LocalVals*/
	
	/*#{1GA5T3G497PreState*/
	/*}#1GA5T3G497PreState*/
	/*#{1GA5T3G497PostState*/
	/*}#1GA5T3G497PostState*/
	cssVO={
		"hash":"1GA5T3G497",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GA5T5KBT0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1GA5T7T850",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddObj","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA5T7T850Codes*/
						tip:(($ln==="CN")?("添加新内容"):/*EN*/("Add new project item")),
						OnClick(){
							self.doAddObj(this);
						}
						/*}#1GA5T7T850Codes*/
					},
					{
						"hash":"1GDS97JGI0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GDS97JGI0Codes*/
						tip:(($ln==="CN")?("保存"):/*EN*/("Save")),
						OnClick(){
							app.mainUI.doSaveDoc()
						}
						/*}#1GDS97JGI0Codes*/
					},
					{
						"hash":"1GA5UDK1Q0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDelObj","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA5UDK1Q0Codes*/
						tip:(($ln==="CN")?("删除所选项目"):/*EN*/("Delete selected item(s)")),
						OnClick(){
							self.doDelObj(null);
						}
						/*}#1GA5UDK1Q0Codes*/
					},
					{
						"hash":"1GA5UEI7A0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/movefront.svg",null),"id":"BtnMoveUp","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA5UEI7A0Codes*/
						tip:(($ln==="CN")?("向上移动选定项目"):/*EN*/("Move up selected item(s)")),
						OnClick(){
							self.doMoveObjUp();
						}
						/*}#1GA5UEI7A0Codes*/
					},
					{
						"hash":"1GA5UFTMH0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/moveback.svg",null),"id":"BtnMoveDown","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GA5UFTMH0Codes*/
						tip:(($ln==="CN")?("向下移动选定的项目"):/*EN*/("Move down selected item(s)")),
						OnClick(){
							self.doMoveObjDown();
						}
						/*}#1GA5UFTMH0Codes*/
					},
					{
						"hash":"1GJ3I0K8A0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
						/*#{1GJ3I0K8A0Codes*/
						tip:(($ln==="CN")?("运行项目"):/*EN*/("Run project")),
						OnClick(){
							app.runPrj(this);
						}
						/*}#1GJ3I0K8A0Codes*/
					}
				],
			},
			{
				"hash":"1GA5UNIS50",
				"type":NaviTreeBox(app,"prj"),"id":"TreeBox","x":0,"y":0,
				/*#{1GA5UNIS50Codes*/
				OnLineClick(line,obj,node){
					self.OnLineClick(line,obj,node);
				}
				/*}#1GA5UNIS50Codes*/
			}
		],
		/*#{1GA5T3G497ExtraCSS*/
		traceSize:1,
		/*}#1GA5T3G497ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA5T3G497Create*/
			treeBox=self.TreeBox;
			//Tool bar			
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			
			//Init Root:
			treeBox.showRootObj(editPrj);
			
			//Trace dataDocs
			dataDocs.on("FocusDoc",self.OnFocusDoc);
			
			let prjCfg;
			prjCfg=appPrj.prjConfig;
			if(prjCfg){
				self.BtnRun.enable=!!prjCfg.run;
			}
			/*}#1GA5T3G497Create*/
		},
		/*#{1GA5T3G497EndCSS*/
		/*}#1GA5T3G497EndCSS*/
	};
	/*#{1GA5T3G497PostCSSVO*/
	//************************************************************************
	//:ToolBtn actions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doAddObj=function(hud){
			let hotNode,curObj;
			hotNode=treeBox.hotNode; 
			if(hotNode){
				curObj=hotNode.nodeObj;
			}
			if(curObj && curObj.dataDoc){
				curObj=curObj.owner;
			}
			if(!curObj || (curObj===editPrj)){
				self.addPrjItemByMenu(hud);
			}else if(curObj.def.docType && curObj.def.dir){
				self.addPrjItemByDocType(hud,curObj.def.docType,curObj.def.dir,curObj);
			}else if(curObj.isExternGearLibs){
				self.addPrjExternLib(hud);
			}else if(curObj.isCSSFiles){
				self.addPrjCSSFile(hud);
			}
		};
	}
	
	//************************************************************************
	//:Add new project items:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.addPrjItemByMenu=function(hud){
			let attrList,items,attr,attrDef;
			items=[];
			attrList=editPrj.attrList;
			//build menu items by editPrj
			for(attr of attrList){
				attrDef=attr.def;
				if(attrDef && attrDef.docType && attrDef.dir){
					items.push({text:attrDef.showName,docType:attrDef.docType,dir:attrDef.dir,owner:attr});
				}
			}
			//editPrj
			app.showDlg(DlgMenu,{
				hud:hud,
				items:items,
				callback(item){
					if(!item){
						return;
					}
					self.addPrjItemByDocType(hud,item.docType,item.dir,item.owner);
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.addPrjItemByDocType=function(hud,docType,dir,owner=null){
			let path,fname;
			app.showDlg(DlgMenu,{
				hud:hud,
				items:[
					{text:(($ln==="CN")?("创建新文件"):/*EN*/("Create new file")),code:"new"},
					{text:(($ln==="CN")?("选择本地文件"):/*EN*/("Choose a file")),code:"open"},
				],
				callback(item){
					if(!item){
						return;
					}
					if(item.code==="new"){
						if(docType==="hud"){
							self.addNewHudDoc(dir);
						}else if(docType==="view"){
							self.addNewViewDoc(dir);
						}else{
							self.addNewDataDoc(dir,"",owner);
						}
					}else{
						if(docType==="hud"){
							self.chooseAddHudDoc(dir);
						}else if(docType==="view"){
							self.chooseAddViewDoc(dir);
						}else{
							self.chooseAddDataDoc(dir,owner);
						}
					}
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewHudDoc=function(dir){
			app.showDlg(DlgNewGear,{
				hud:self,x:self.w,mode:"gear",dir:dir,
				callback:async function(fileName,path,def,oneHud){
					editPrj.addHudDocFile(editPrj.getAttr("docGears"),fileName,path,def,oneHud);
				}
			});			
		};
	
		//--------------------------------------------------------------------
		cssVO.addNewViewDoc=function(dir){
			app.showDlg(DlgNewGear,{
				hud:self,x:self.w,mode:"view",dir:dir,
				callback:async function(fileName,path,def){
					editPrj.addHudDocFile(editPrj.getAttr("docViews"),fileName,path,def,false);
				}
			});			
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewDataDoc=async function(dir,className,owner=null){
			let fname,done,path,entry,editDoc,ext;
			if(owner){
				ext=owner.def.fileExt||".js";
			}else{
				ext=".js";//By default
			}
			if(className){
				fname=className;
			}else{
				fname="newfile"+ext;
			}
			do{
				done=true;
				fname=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:"New data class file",text:fname});
				//fname=window.prompt("New data class file",fname);
				if(!fname){
					return;
				}
				if(!fname.endsWith(ext)){
					fname=fname+ext;
				}
				if(fname.indexOf("/")>=0){
					window.alert("File name should not inclde dir path.");
					done=false;
				}
				path=pathLib.join(appPrj.path,dir,fname);
				entry=await tabFS.getEntry(path);
				if(entry){
					window.alert("File name is already been used.");
					done=false;
				}
			}while(!done);
			editDoc=await editPrj.addDataDocFile(owner,fname,path);
			editPrj.setEditSubObj(editDoc);
			naviView.showView("NaviDoc");
			infoView.showView("EditObj");
		};
	
		//--------------------------------------------------------------------
		cssVO.addPrjExternLib=async function(hud){
			let path,mod,prj,ext;
			prj=editPrj
			path=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:`Input gear path, must start with "/@"`,text:"/@"});
			//path=window.prompt(`Input gear path, must start with "/@"`,"/@");
			if(path){
				ext=pathLib.extname(path);
				if(!ext){
					prj.addExternGearLib(path,true);
				}else{
					import(path).then(async(mod)=>{
						await prj.addExternGear(path);
					}).catch((err)=>{
					});
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addPrjCSSFile=async function(hud){
			let path,prj;
			prj=editPrj;
			app.showDlg(DlgFile,{
				mode:"open",
				path:prj.path,
				buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
				title:(($ln==="CN")?("选择文件"):/*EN*/("Choose File(s)")),
				options:{
					multiSelect:1,
					preview:1,
					filter:"*.css;*.js",
				},
				callback:async function(filePath){
					if(!filePath){
						return;
					}
					try{
						if(Array.isArray(filePath)){
							let i,n;
							n=filePath.length;
							for(i=0;i<n;i++){
								await editPrj.addPreloadFile(filePath[i]);
							}
						}else{
							await editPrj.addPreloadFile(filePath);
						}
						editPrj.savePrj();
					}catch(e){
						console.error("Import CSS file error:");
						console.error(e);
					}
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.chooseAddHudDoc=function(dir){
			let dirPath;
			if(!dir.startsWith(editPrj.path)){
				dirPath=editPrj.path+"/"+dir;
			}
			app.showDlg(DlgFile,{
				mode:"open",
				path:dirPath,
				buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
				options:{
					multiSelect:0,
					preview:1,
				},
				callback:async function(filePath){
					if(!filePath){
						return;
					}
					try{
						editPrj.addHudDocFile(editPrj.getAttr("docGears"),pathLib.basename(filePath),filePath,null,null);
					}catch(e){
						console.error("Import UI-Component file error:");
						console.error(e);
					}
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.chooseAddViewDoc=function(dir){
			let dirPath;
			if(!dir.startsWith(editPrj.path)){
				dirPath=editPrj.path+"/"+dir;
			}
			app.showDlg(DlgFile,{
				mode:"open",
				path:dirPath,
				buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
				options:{
					multiSelect:0,
					preview:1,
				},
				callback:async function(filePath){
					if(!filePath){
						return;
					}
					try{
						editPrj.addHudDocFile(editPrj.getAttr("docViews"),pathLib.basename(filePath),filePath,null,null);
					}catch(e){
						console.error("Import UI-View file error:");
						console.error(e);
					}
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.chooseAddDataDoc=function(dir,owner){
			let dirPath;
			if(!dir.startsWith(editPrj.path)){
				dirPath=editPrj.path+"/"+dir;
			}
			app.showDlg(DlgFile,{
				mode:"open",
				path:dirPath,
				buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
				options:{
					multiSelect:0,
					preview:1,
				},
				callback:async function(filePath){
					let editDoc;
					if(!filePath){
						return;
					}
					try{
						editDoc=editPrj.addDataDocFile(owner,pathLib.basename(filePath),filePath,true);
						editPrj.setEditSubObj(editDoc);
						naviView.showView("NaviDoc");
						infoView.showView("EditObj");
					}catch(e){
						console.error("Import DataClass file error:");
						console.error(e);
					}
				}
			});
		};
	}
	
	//************************************************************************
	//:Delete, move project item:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doDelObj=function(hud){
			let attr,owner,node;
			if(hud){
				attr=hud.attrObj;
				node=treeBox.showObjNode(attr,false,false,false);
			}else{
				let hotNode;
				hotNode=treeBox.hotNode;
				if(hotNode){
					attr=hotNode.nodeObj;
					node=hotNode;
				}
			}
			if(!attr || !node){
				return;
			}
			owner=attr.owner;
			if(!window.confirm((($ln==="CN")?(`确定要从项目中删除此项吗？`):/*EN*/(`Are you sure to remove this item from project?`)))){
				return;
			}
			owner.removeAttr(attr);
			editPrj.savePrj();
		};
		
		//--------------------------------------------------------------------
		cssVO.doMoveObjUp=function(){
			let attr,owner,node;
			let hotNode;
			hotNode=treeBox.hotNode;
			if(hotNode){
				attr=hotNode.nodeObj;
				node=hotNode;
			}
			if(!attr || !node){
				return;
			}
			owner=attr.owner;
			owner.moveUpAttr(attr);
			editPrj.savePrj();
		};
	
		//--------------------------------------------------------------------
		cssVO.doMoveObjDown=function(){
			let attr,owner,node;
			let hotNode;
			hotNode=treeBox.hotNode;
			if(hotNode){
				attr=hotNode.nodeObj;
				node=hotNode;
			}
			if(!attr || !node){
				return;
			}
			owner=attr.owner;
			owner.moveDownAttr(attr);
			editPrj.savePrj();
		};
	}
	
	//------------------------------------------------------------------------
	cssVO.OnLineClick=async function(line,obj,node){
		let dataDoc,path;
		dataDoc=obj.dataDoc;
		if(dataDoc){
			path=dataDoc.path;
			await dataDocs.openDoc(path);
			dataDocs.focusDoc(dataDoc);
			treeBox.setHotNode(node);
			editPrj.setEditSubObj(node.nodeObj);
		}else{
			treeBox.setHotNode(node);
			editPrj.setEditSubObj(node.nodeObj);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFocusDoc=function(doc){
		let editDoc,node;
		editDoc=doc.codyDoc;
		if(!editDoc){
			treeBox.setHotNode(null);
			return;
		}
		node=treeBox.showObjNode(editDoc);
		if(!node){
			treeBox.setHotNode(null);
		}
		//self.saveDocsState(0);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		isFocused=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.execChatCommand=async function(cmdVO){
		let cmd;
		cmd=cmdVO.command;
		switch(cmd){
			case "NewDataClass":{
				self.addNewDataDoc("data",cmdVO.name);
			}
			break;
			case "NewProperty":{
			}
			break;
		}
	};
	
	/*}#1GA5T3G497PostCSSVO*/
	cssVO.constructor=TBXNaviPrj;
	return cssVO;
};
/*#{1GA5T3G497ExCodes*/
TBXNaviPrj.tbxCodeName="NaviPrj";
TBXNaviPrj.tbxTip=(($ln==="CN")?("工程项目"):/*EN*/("Project Items"));
TBXNaviPrj.tbxIcon=appCfg.sharedAssets+"/prj.svg";
TBXNaviPrj.tbxIconPad=2;
/*}#1GA5T3G497ExCodes*/

//----------------------------------------------------------------------------
TBXNaviPrj.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GA5T3G497PreAISpot*/
	/*}#1GA5T3G497PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GA5T3G497PostAISpot*/
	/*}#1GA5T3G497PostAISpot*/
	return exposeVO;
};

/*#{1GA5T3G490EndDoc*/
/*}#1GA5T3G490EndDoc*/

export default TBXNaviPrj;
export{TBXNaviPrj};
