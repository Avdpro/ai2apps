//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GADMP5N90StartDoc*/
/*}#1GADMP5N90StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let LineCard=function(app,def,box){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=appCfg.sharedAssets+"/"+def.icon;
	
	/*#{1GADMP5N97LocalVals*/
	let isFocused;
	isFocused=0;
	/*}#1GADMP5N97LocalVals*/
	
	/*#{1GADMP5N97PreState*/
	/*}#1GADMP5N97PreState*/
	/*#{1GADMP5N97PostState*/
	/*}#1GADMP5N97PostState*/
	cssVO={
		"hash":"1GADMP5N97",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"FW","h":"","autoLayout":true,"margin":[0,0,2,0],"padding":[5,0,5,0],"minW":"","minH":cfgSize.cardLineH,
		"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","subAlign":1,
		children:[
			{
				"hash":"1GADMRKLA0",
				"type":"box","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GADMT6160",
				"type":"box","id":"BoxIcon","x":5,"y":"50%","w":cfgSize.cardLineH-4,"h":cfgSize.cardLineH-4,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.lineBodySub,"maskImage":icon,
			},
			{
				"hash":"1GADN2G2H0",
				"type":"text","id":"TxtName","position":"relative","x":50,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
				"text":def.showName||def.name,"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1GADN41NH0",
				"type":"text","id":"TxtInfo","position":"relative","x":55,"y":0,"w":">calc(100% - 60px)","h":"","overflow":1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodyLit,"text":def.info,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"wrap":true,
			}
		],
		/*#{1GADMP5N97ExtraCSS*/
		/*}#1GADMP5N97ExtraCSS*/
		faces:{
			"up":{
				/*#{1GADNB0B30PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1GADNB0B30PreCode*/
				"#1GADMRKLA0":{
					"background":cfgColor.body
				},
				/*TxtInfo*/"#1GADN41NH0":{
					"color":cfgColor.fontBodyLit
				}
			},"over":{
				/*#{1GADNB4I90PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1GADNB4I90PreCode*/
				"#1GADMRKLA0":{
					"background":cfgColor.lineBodyThin
				},
				/*TxtInfo*/"#1GADN41NH0":{
					"color":cfgColor.fontBodySub
				}
			},"down":{
				/*#{1GADNB8750PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1GADNB8750PreCode*/
				"#1GADMRKLA0":{
					"background":cfgColor.hot
				}
			},"focus":{
				"#1GADMRKLA0":{
					"background":cfgColor.hot
				},
				/*TxtInfo*/"#1GADN41NH0":{
					"color":cfgColor.fontBodySub
				},
				/*#{1GADNBFDU0Code*/
				$(){
					isFocused=1;
				}
				/*}#1GADNBFDU0Code*/
			},"blur":{
				"#1GADMRKLA0":{
					"background":cfgColor.body
				},
				/*TxtInfo*/"#1GADN41NH0":{
					"color":cfgColor.fontBodyLit
				},
				/*#{1GADNBINM0Code*/
				$(){
					isFocused=0;
				}
				/*}#1GADNBINM0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GADMP5N97Create*/
			/*}#1GADMP5N97Create*/
		},
		/*#{1GADMP5N97EndCSS*/
		get $$focus(){
			return isFocused;
		},
		set $$focus(f){
			if(!self){
				return 0;
			}
			if(f){
				self.showFace("focus");
			}else{
				self.showFace("blur");
			}
			return isFocused;
		}
		/*}#1GADMP5N97EndCSS*/
	};
	/*#{1GADMP5N97PostCSSVO*/
	/*}#1GADMP5N97PostCSSVO*/
	return cssVO;
};
/*#{1GADMP5N97ExCodes*/
/*}#1GADMP5N97ExCodes*/


/*#{1GADMP5N90EndDoc*/
/*}#1GADMP5N90EndDoc*/

export default LineCard;
export{LineCard};
