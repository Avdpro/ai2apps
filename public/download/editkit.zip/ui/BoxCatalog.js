//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HFLJI3MU0StartDoc*/
import {EditAISeg} from "../aiagent/EditAISeg.js";
import {BtnGear} from "./BtnGear.js";
/*}#1HFLJI3MU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxCatalog=function(catalog,genDef,autoUpdate){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxDefs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HFLJI3MU1LocalVals*/
	let app=VFACT.app;
	let isOpen=false;
	/*}#1HFLJI3MU1LocalVals*/
	
	/*#{1HFLJI3MU1PreState*/
	/*}#1HFLJI3MU1PreState*/
	/*#{1HFLJI3MU1PostState*/
	/*}#1HFLJI3MU1PostState*/
	cssVO={
		"hash":"1HFLJI3MU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HFLJM68K0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":25,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(180,180,180,0.1))",
				"border":[1,0,1,0],"borderColor":cfgColor["lineBody"],"contentLayout":"flex-x",
				children:[
					{
						"hash":"1HFLJOQIG0",
						"type":"box","position":"relative","x":8,"y":"50%","w":16,"h":16,"anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["fontBody"],"border":1,"maskImage":appCfg.sharedAssets+"/zhankai.svg",
					},
					{
						"hash":"1HFLJSK5O0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":catalog.showName||catalog.name,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,
					}
				],
				"OnClick":function(event){
					/*#{1HFLK7G6N0FunctionBody*/
					if(!isOpen){
						self.showFace("open");
					}else{
						self.showFace("close");
					}
					/*}#1HFLK7G6N0FunctionBody*/
				},
			},
			{
				"hash":"1HFLJVU820",
				"type":"hud","id":"BoxDefs","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[0,0,5,0],"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-y","itemsAlign":1,
			}
		],
		/*#{1HFLJI3MU1ExtraCSS*/
		/*}#1HFLJI3MU1ExtraCSS*/
		faces:{
			"open":{
				/*#{1HFLK1JR10PreCode*/
				$(){
					if(autoUpdate){
						self.initDefBtns();
					}
				},
				/*}#1HFLK1JR10PreCode*/
				"#1HFLJOQIG0":{
					"rotate":90
				},
				/*BoxDefs*/"#1HFLJVU820":{
					"display":1
				},
				/*#{1HFLK1JR10Code*/
				$$(){
					isOpen=true;
				}
				/*}#1HFLK1JR10Code*/
			},"close":{
				"#1HFLJOQIG0":{
					"rotate":0
				},
				/*BoxDefs*/"#1HFLJVU820":{
					"display":0
				},
				/*#{1HFLK21BD0Code*/
				$$(){
					isOpen=false;
				}
				/*}#1HFLK21BD0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxDefs=self.BoxDefs;
			/*#{1HFLJI3MU1Create*/
			if(!autoUpdate){
				self.initDefBtns();
			}
			/*}#1HFLJI3MU1Create*/
		},
		/*#{1HFLJI3MU1EndCSS*/
		/*}#1HFLJI3MU1EndCSS*/
	};
	/*#{1HFLJI3MU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initDefBtns=function(){
		let defs=catalog.defs;
		let def;
		boxDefs.clearChildren();
		for(def of defs){
			boxDefs.appendNewChild(genDef(def));
		}
	};
	/*}#1HFLJI3MU1PostCSSVO*/
	return cssVO;
};
/*#{1HFLJI3MU1ExCodes*/
/*}#1HFLJI3MU1ExCodes*/


/*#{1HFLJI3MU0EndDoc*/
/*}#1HFLJI3MU0EndDoc*/

export default BoxCatalog;
export{BoxCatalog};
