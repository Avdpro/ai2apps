//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GLCDPE690StartDoc*/
/*}#1GLCDPE690StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnGear=function(app,def){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=def.icon[0]==="/"?def.icon:appCfg.sharedAssets+"/"+def.icon;
	
	/*#{1GLCDPE691LocalVals*/
	/*}#1GLCDPE691LocalVals*/
	
	/*#{1GLCDPE691PreState*/
	/*}#1GLCDPE691PreState*/
	state={
		"icon":"size_w",
		/*#{1GLCDPE6A4ExState*/
		/*}#1GLCDPE6A4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GLCDPE691PostState*/
	/*}#1GLCDPE691PostState*/
	cssVO={
		"hash":"1GLCDPE691",nameHost:true,
		"type":"button","position":"relative","x":6,"y":"50%","w":80,"h":60,"anchorY":1,"autoLayout":true,"cursor":"pointer","margin":[0,3,0,3],"minW":"","minH":"",
		"maxW":"","maxH":"","styleClass":"",
		"def":def,
		children:[
			{
				"hash":"1GLCE900E0",
				"type":"box","id":"BoxBG","x":-5,"y":-5,"w":">calc(100% + 10px)","h":">calc(100% + 10px)","display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.hot,"corner":5,
			},
			{
				"hash":"1GLCETK8F0",
				"type":"box","id":"BoxIcon","x":"FW/2","y":25,"w":48,"h":48,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontBodySub,
				"border":1,"maskImage":icon,
			},
			{
				"hash":"1GLCFFE210",
				"type":"text","id":"TxtName","x":0,"y":48,"w":"FW","h":12,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":def.showName||def.name,
				"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
			}
		],
		/*#{1GLCDPE691ExtraCSS*/
		/*}#1GLCDPE691ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GLCE900E0":{
					"display":0,"background":cfgColor.hot
				},
				/*BoxIcon*/"#1GLCETK8F0":{
					"scale":1
				}
			},"over":{
				/*BoxBG*/"#1GLCE900E0":{
					"display":1,"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GLCE900E0":{
					"display":1,"background":cfgColor["hot"]
				},
				/*BoxIcon*/"#1GLCETK8F0":{
					"x":"FW/2","y":25,"w":48,"h":48,"scale":1.1
				}
			},"focus":{
				/*BoxIcon*/"#1GLCETK8F0":{
					"background":cfgColor.primary
				},
				/*TxtName*/"#1GLCFFE210":{
					"fontWeight":"bold"
				}
			},"blur":{
				/*BoxIcon*/"#1GLCETK8F0":{
					"background":cfgColor.fontBodySub
				},
				/*TxtName*/"#1GLCFFE210":{
					"fontWeight":"normal"
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GLCDPE691Create*/
			/*}#1GLCDPE691Create*/
		},
		/*#{1GLCDPE691EndCSS*/
		/*}#1GLCDPE691EndCSS*/
	};
	/*#{1GLCDPE691PostCSSVO*/
	/*}#1GLCDPE691PostCSSVO*/
	return cssVO;
};
/*#{1GLCDPE691ExCodes*/
/*}#1GLCDPE691ExCodes*/


/*#{1GLCDPE690EndDoc*/
/*}#1GLCDPE690EndDoc*/

export default BtnGear;
export{BtnGear};
