//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@homekit/ui/BtnIcon.js";
/*#{1H2VOVHFO0StartDoc*/
import {DlgMenu} from "/@homekit/ui/DlgMenu.js";
import {MenuLine} from "/@homekit/ui/MenuLine.js";
import packPreview from "../exporters/PackPreview.js";
/*}#1H2VOVHFO0StartDoc*/
const $ln=appCfg.lanCode||"EN";
//----------------------------------------------------------------------------
let UIView=function(uiDef){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let boxUI,boxDevice,boxHud,boxTouch,faceList,btnFace,btnDevice,edW,edH,btnZoomOut,txtZoom,btnZoomIn,btnShare;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let app=window.tabOSApp;
	let mobile=app.width<500;
	let isNaked=false;
	let assets="/@editkit/assets/preview";
	
	/*#{1H2VOVHFO1LocalVals*/
	let pvUIObj=null;
	let faces=[];
	let createArgs;
	let rootFace=null;
	let curFace=null;	
	let designW,designH;
	let clean=true;
	let timer=null;
	let appPath=VFACT.appFilePath;
	isNaked=packPreview.length<2;
	/*}#1H2VOVHFO1LocalVals*/
	
	/*#{1H2VOVHFO1PreState*/
	/*}#1H2VOVHFO1PreState*/
	state={
		"faceLog":"",
		/*#{1H2VOVHFP3ExState*/
		/*}#1H2VOVHFP3ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H2VOVHFO1PostState*/
	/*}#1H2VOVHFO1PostState*/
	cssVO={
		"hash":"1H2VOVHFO1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H2VP0R4V0",
				"type":"hud","id":"BoxUI","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":1,"styleClass":"",
				children:[
					{
						"hash":"1H390GGLS0",
						"type":"text","x":5,"y":5,"w":100,"h":20,"styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?($P(()=>("预设外观："+state.faceLog),state)):($P(()=>("Face: "+state.faceLog),state))),
						"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1H2VR7I5R0",
						"type":"box","id":"BoxDevice","x":200,"y":100,"w":375,"h":750,"scale":0.5,"styleClass":"","background":[255,255,255,1],"shadow":true,"shadowY":3,
						"shadowBlur":6,
						children:[
							{
								"hash":"1H2VRDAEI0",
								"type":"hud","id":"BoxHud","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
							}
						],
					},
					{
						"hash":"1H34AHRPL0",
						"type":"hud","id":"BoxTouch","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
					},
					{
						"hash":"1H39266GK0",
						"type":"box","id":"BoxPlay","x":"50%","y":">calc(100% - 45px)","w":120,"h":40,"anchorX":1,"styleClass":"","background":[255,255,255,1],"border":1,
						"borderColor":cfgColor.fontBodyLit,"corner":20,"shadow":true,"shadowX":0,"shadowY":3,"shadowBlur":6,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-x",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1H392B3KM0",
								"type":BtnIcon(app,32,32,assets+"/undo.svg",1),"id":"BtnNaviReset","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("重置界面"):("Reset UI")),
								"OnClick":function(event){
									/*#{1H3971K360FunctionBody*/
									self.resetUI();
									/*}#1H3971K360FunctionBody*/
								},
							},
							{
								"hash":"1H392EVVR0",
								"type":BtnIcon(app,32,32,assets+"/arrowleft.svg",1),"id":"BtnNaviBack","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("返回"):("Back")),
								"OnClick":function(event){
									/*#{1H39842S50FunctionBody*/
									self.naviBack();
									/*}#1H39842S50FunctionBody*/
								},
							},
							{
								"hash":"1H392H3330",
								"type":BtnIcon(app,32,32,assets+"/arrowright.svg",1),"id":"BtnNaviNext","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("下一个预设外观"):("Next")),
								"OnClick":function(event){
									/*#{1H398508O0FunctionBody*/
									self.naviNext();
									/*}#1H398508O0FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1H2VP2LRF0",
				"type":"hud","id":"BoxSide","x":0,"y":30,"w":280,"h":">calc(100% - 30px)","display":0,"styleClass":"",
				children:[
					{
						"hash":"1H2VP420F0",
						"type":"hud","id":"BoxFaces","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
						children:[
							{
								"hash":"1H2VP9GIU0",
								"type":"box","id":"Top","x":0,"y":0,"w":"100%","h":30,"padding":5,"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],"contentLayout":"flex-x",
								children:[
									{
										"hash":"1H2VPC2IR0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,10,0,0],"styleClass":"","color":[0,0,0],"text":(($ln==="CN")?("预设外观:"):("Faces:")),
										"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H2VRLUBO0",
										"type":BtnIcon(null,28,28,assets+"/close.svg",3),"id":"BtnCloseFace","x":">calc(100% - 5px)","y":"50%","anchorY":1,"anchorX":2,
										"OnClick":function(event){
											/*#{1H34ADPD40FunctionBody*/
											self.hideFaceList();
											/*}#1H34ADPD40FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H2VPLCK70",
								"type":"hud","id":"FaceList","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"hidden scroll","styleClass":"","contentLayout":"flex-y",
							}
						],
					},
					{
						"hash":"1H349Q9B00",
						"type":"box","id":"Line","x":"100%","y":0,"w":1,"h":"100%","styleClass":"","background":cfgColor.fontBodySub,
					}
				],
			},
			{
				"hash":"1H2VS1PMT0",
				"type":"box","id":"Header","x":0,"y":0,"w":"100%","h":30,"padding":5,"styleClass":"","background":cfgColor.tool,"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],
				"contentLayout":"flex-x",
				children:[
					{
						"hash":"1H349TUC20",
						"type":BtnIcon(app,28,28,assets+"/menu.svg",0),"id":"BtnFace","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,20,0,0],
						"tip":(($ln==="CN")?("预设外观"):("Show faces")),
						"OnClick":function(event){
							/*#{1H34A8N2R0FunctionBody*/
							self.showFaceList();
							/*}#1H34A8N2R0FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMU4",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":cfgColor.fontBodySub,"text":"Device:","fontSize":txtSize.smallMid,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1H2VS1PMT2",
						"type":BtnIcon(app,26,26,assets+"/btncombo.svg",1),"id":"BtnDevice","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":(($ln==="CN")?("选择设备"):("Choose Device")),
						"OnClick":function(event){
							/*#{1H358IN630FunctionBody*/
							self.chooseSize();
							/*}#1H358IN630FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMU9",
						"type":"edit","id":"EdW","position":"relative","x":0,"y":0,"w":40,"h":"100%","styleClass":"","text":"375","color":[0,0,0],"outline":0,"border":[0,0,1,0],
						"OnUpdate":function(){
							/*#{1H357M5CO0FunctionBody*/
							self.applySize();
							/*}#1H357M5CO0FunctionBody*/
						},
					},
					{
						"hash":"1H2VS1PMV0",
						"type":"text","position":"relative","x":2,"y":0,"w":"","h":"100%","margin":[0,5,0,3],"styleClass":"","color":[0,0,0],"text":"x","fontWeight":"normal",
						"fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					},
					{
						"hash":"1H2VS1PMV5",
						"type":"edit","id":"EdH","position":"relative","x":0,"y":0,"w":40,"h":"100%","margin":[0,20,0,0],"styleClass":"","text":"750","color":[0,0,0],"outline":0,
						"border":[0,0,1,0],
						"OnUpdate":function(){
							/*#{1H357MCAE0FunctionBody*/
							self.applySize();
							/*}#1H357MCAE0FunctionBody*/
						},
					},
					{
						"hash":"1H35A7MM30",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":cfgColor.fontBodySub,"text":"Zoom:","fontSize":txtSize.smallMid,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1H35A826R0",
						"type":BtnIcon(app,26,26,assets+"/dec.svg",1),"id":"BtnZoomOut","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":(($ln==="CN")?("缩小"):("Zoom out")),
						"OnClick":function(event){
							/*#{1H35A826R7FunctionBody*/
							self.stepZoom(-1);
							/*}#1H35A826R7FunctionBody*/
						},
					},
					{
						"hash":"1H35A87850",
						"type":"text","id":"TxtZoom","position":"relative","x":0,"y":0,"w":50,"h":"100%","cursor":"pointer","styleClass":"","color":[0,0,0],"text":"100%",
						"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"underline","alignH":1,"alignV":1,
						"OnClick":function(event){
							/*#{1H35ASSRE0FunctionBody*/
							self.chooseZoom();
							/*}#1H35ASSRE0FunctionBody*/
						},
					},
					{
						"hash":"1H35A9QIV0",
						"type":BtnIcon(app,26,26,assets+"/inc.svg",1),"id":"BtnZoomIn","position":"relative","x":0,"y":"50%","anchorY":1,
						"tip":(($ln==="CN")?("放大"):("Zoom in")),
						"OnClick":function(event){
							/*#{1H35A9QIV7FunctionBody*/
							self.stepZoom(1);
							/*}#1H35A9QIV7FunctionBody*/
						},
					},
					{
						"hash":"1H34AB4KC0",
						"type":BtnIcon(app,28,28,assets+"/send.svg",3),"id":"BtnShare","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,20],"attached":isNaked?false:true,
						"tip":(($ln==="CN")?("分享预览..."):("分享预览...")),
						"OnClick":function(event){
							/*#{1H3KT44I10FunctionBody*/
							self.sharePreview();
							/*}#1H3KT44I10FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H2VOVHFO1ExtraCSS*/
		/*}#1H2VOVHFO1ExtraCSS*/
		faces:{
			"hideSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"x":0,"w":"100%"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":0
				},
				/*#{1H33URP2G0Code*/
				/*}#1H33URP2G0Code*/
			},"showSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"x":280,"w":">calc(100% - 280px)"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":1
				},
				/*#{1H33USAD90Code*/
				/*}#1H33USAD90Code*/
			},"pause":{
				/*BtnNaviReset*/"#1H392B3KM0":{
					"enable":false
				},
				/*BtnNaviBack*/"#1H392EVVR0":{
					"enable":false
				},
				/*BtnNaviNext*/"#1H392H3330":{
					"enable":false
				}
			},"resume":{
				/*BtnNaviReset*/"#1H392B3KM0":{
					"enable":true
				},
				/*BtnNaviBack*/"#1H392EVVR0":{
					"enable":true
				},
				/*BtnNaviNext*/"#1H392H3330":{
					"enable":true
				}
			},"mobile":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"display":1,"x":0,"w":"100%"
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":0,"w":"100%"
				},
				/*BtnFace*/"#1H349TUC20":{
					"enable":true
				},
				"#1H2VS1PMU4":{
					"display":0
				},
				"#1H35A7MM30":{
					"display":0
				},
				/*TxtZoom*/"#1H35A87850":{
					"w":""
				},
				/*BtnShare*/"#1H34AB4KC0":{
					"display":0
				}
			},"mobileSide":{
				/*BoxUI*/"#1H2VP0R4V0":{
					"display":0
				},
				/*BoxSide*/"#1H2VP2LRF0":{
					"display":1
				},
				/*BtnFace*/"#1H349TUC20":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxUI=self.BoxUI;boxDevice=self.BoxDevice;boxHud=self.BoxHud;boxTouch=self.BoxTouch;faceList=self.FaceList;btnFace=self.BtnFace;btnDevice=self.BtnDevice;edW=self.EdW;edH=self.EdH;btnZoomOut=self.BtnZoomOut;txtZoom=self.TxtZoom;btnZoomIn=self.BtnZoomIn;btnShare=self.BtnShare;
			/*#{1H2VOVHFO1Create*/
			let gearExport=uiDef.gearExport;
			let defArgs=gearExport.args;
			let args,name,arg;
			let uiDefVO;
			let iconURL=assets+"/faces.svg";
			
			faces=gearExport.faces||[];
			faces=faces.map((item)=>{return {
				...item,text:item.name,icon:iconURL,
			}});
			if(mobile){
				self.showFace("mobile");
			}
			{
				let frameW,frameH,deviceW,deviceH;
				frameW=app.width;
				frameH=app.height-30;
				designW=deviceW=gearExport.deviceW;
				designH=deviceH=gearExport.deviceH;
				boxDevice.w=deviceW;
				boxDevice.h=deviceH;
				edW.text=""+deviceW;
				edH.text=""+deviceH;
				self.fitDevice(frameW,frameH,true,false);
			}			
			VFACT.applyMoveDrag(boxTouch,boxDevice);
			
			args=[];
			for(name in defArgs){
				arg=defArgs[name];
				args.push(arg.initVal);
			}
			createArgs=args;
			self.resetUI();
			//Find preview-entry:
			{
				let face;
				for(face of faces){
					if(face.entry===true){
						self.showPVFace(face);
						break;
					}
				}
			}
			/*}#1H2VOVHFO1Create*/
		},
		/*#{1H2VOVHFO1EndCSS*/
		/*}#1H2VOVHFO1EndCSS*/
	};
	/*#{1H2VOVHFO1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showPVFace=function(faceObj,justShow=false){
		if(typeof(faceObj)==="string"){
			faceObj=faces.find((face)=>{return face.name===faceObj});
			if(!faceObj){
				return;
			}
		}
		if(justShow){
			pvUIObj.showFace(faceObj.name);
			return;
		}
		if(!clean){
			if(faceObj.entry){
				self.resetUI();
			}else{
				state.faceLog+=">>";
			}
		}
		pvUIObj.showFace(faceObj.name);
		if(faceObj.entry){
			rootFace=faceObj;
		}
		clean=false;
		state.faceLog+=faceObj.name;
		curFace=faceObj;
		if(faceObj.time>0){
			self.showFace("pause");
			timer=setTimeout(()=>{
				self.showFace("resume");
			},faceObj.time+200);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.resetUI=function(){
		let uiDefVO=uiDef.apply(null,createArgs);
		boxHud.clearChildren();
		pvUIObj=boxHud.appendNewChild(uiDefVO);
		clean=true;
		rootFace=null;
		state.faceLog="";
	};
	
	//------------------------------------------------------------------------
	cssVO.naviBack=function(){
		if(rootFace){
			self.showPVFace(rootFace);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.naviNext=function(){
		let face;
		if(curFace && curFace.next){
			self.showPVFace(curFace.next);
			return;
		}else if(rootFace){
			let i,n;
			n=faces.length;
			i=faces.indexOf(rootFace);
			for(i=i+1;i<n;i++){
				face=faces[i];
				if(face.entry===true){
					self.showPVFace(face);
					return;
				}
			}
		}
		for(face of faces){
			if(face.entry===true){
				self.showPVFace(face);
				break;
			}
		}
		
	};
	
	//------------------------------------------------------------------------
	cssVO.showFaceList=function(){
		let i,n,stub,def;
		if(mobile){
			self.showFace("mobileSide");
		}else{
			self.showFace("showSide");
			self.fitDevice(0,0,true,false);
		}
		faceList.clearChildren();
		def={
			type:MenuLine({text:(($ln==="CN")?("重置界面"):/*EN*/("Reset")),icon:assets+"/undo.svg"}),faceStub:stub,position:"relative",margin:[3,0,3,0],
			OnClick(){
				self.resetUI();
				if(mobile){
					self.hideFaceList();
				}
			}
		};
		faceList.appendNewChild(def);
		n=faces.length;
		for(i=0;i<n;i++){
			stub=faces[i];
			def={
				type:MenuLine(stub),faceStub:stub,position:"relative",margin:[3,0,3,0],
				OnClick(){
					self.showPVFace(this.faceStub);
					if(mobile){
						self.hideFaceList();
					}
				}
			};
			faceList.appendNewChild(def);
		}
		btnFace.enable=false;
	};
	
	//------------------------------------------------------------------------
	cssVO.hideFaceList=function(){
		if(mobile){
			self.showFace("mobile");
		}else{
			self.showFace("hideSide");
			self.fitDevice(0,0,true,false);
		}
		btnFace.enable=true;
	};
	
	//------------------------------------------------------------------------
	cssVO.applySize=function(){
		let w,h;
		w=parseInt(edW.text);
		h=parseInt(edH.text);
		if(w>0){
			boxDevice.w=w;
		}
		if(h>0){
			boxDevice.h=h;
		}
		self.resetUI();
		self.fitDevice(0,0,true,false);
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseSize=function(){
		app.showDlg(DlgMenu,{
			hud:btnDevice,
			items:[
				{text:(($ln==="CN")?(`设计预置: ${designW}x${designH}`):/*EN*/(`Design: ${designW}x${designH}`)),w:designW,h:designH},
				{text:"iPhone 320x480",w:320,h:480},
				{text:"iPhone 375x500",w:375,h:500},
				{text:"iPhone 375x750",w:375,h:750},
				{text:"iPad 768x1024",w:768,h:1024},
				{text:"iPad 1024x768",w:1024,h:768},
				{text:(($ln==="CN")?("桌面 800x600"):/*EN*/("Desktop 800x600")),w:800,h:600},
				{text:(($ln==="CN")?("桌面 1200x900"):/*EN*/("Desktop 1200x900")),w:1200,h:900},
			],
			callback(item){
				if(!item)
					return;
				boxDevice.w=item.w;
				boxDevice.h=item.h;
				edW.text=""+item.w;
				edH.text=""+item.h;
				self.resetUI();
				self.fitDevice(0,0,true,false);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseZoom=function(){
		app.showDlg(DlgMenu,{
			hud:txtZoom,
			items:[
				{text:(($ln==="CN")?("适应设备"):/*EN*/("Fit Device")),scale:-1},
				{text:"10%",scale:10},
				{text:"30%",scale:30},
				{text:"50%",scale:50},
				{text:"75%",scale:75},
				{text:"100%",scale:100},
				{text:"150%",scale:150},
				{text:"200%",scale:200},
				{text:"300%",scale:300},
			],
			callback(item){
				let scale;
				if(!item)
					return;
				scale=item.scale;
				if(scale<0){
					self.fitDevice(0,0,false,true);
				}else{
					txtZoom.text=scale+"%";
					scale/=100;
					boxDevice.animate({type:"pose",scale:scale,time:50});
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.stepZoom=function(dir){
		let scale=boxDevice.scale;
		scale=Math.floor(scale*100);
		scale+=dir*5;
		scale=scale<5?5:scale;
		scale=scale>500?500:scale;
		txtZoom.text=scale+"%";
		scale/=100;
		boxDevice.animate({type:"pose",scale:scale,time:50});
	};
	
	//------------------------------------------------------------------------
	cssVO.fitDevice=function(frameW,frameH,move,ani){
		let deviceW,deviceH,dw,dh;
		let x,y,scale;
		frameW=frameW||boxUI.clientW;
		frameH=(frameH||boxUI.clientH)-20;
	
		deviceW=boxDevice.w;
		deviceH=boxDevice.h;
		dw=frameW-deviceW;
		dh=frameH-deviceH;
		if(dw>20 && dh>20){
			x=dw*0.5;
			y=dh*0.5;
			scale=1;
		}else{
			let sw,sh;
			sw=(frameW-20)/(deviceW);
			sh=(frameH-20)/(deviceH);
			scale=sw<sh?sw:sh;
			scale=Math.floor(scale*100)/100;
			x=(frameW-(deviceW*scale))*0.5;
			y=(frameH-(deviceH*scale))*0.5+20;
		}
		if(ani){
			let def;
			def={type:"pose",scale:scale,time:50};
			if(move){
				def.x=x;def.y=y;
			}
			boxDevice.animate(def);
		}else{
			if(move){
				boxDevice.x=x;
				boxDevice.y=y;
			}
			boxDevice.scale=scale;
		}
		txtZoom.text=scale*100+"%"
	};
	
	//------------------------------------------------------------------------
	cssVO.sharePreview=async function(){
		//let packPreview;
		//packPreview=(await import("../exporters/PackPreview.js")).default;
		await packPreview(app,btnShare,appPath);
	};
	/*}#1H2VOVHFO1PostCSSVO*/
	return cssVO;
};
/*#{1H2VOVHFO1ExCodes*/
/*}#1H2VOVHFO1ExCodes*/


export default UIView;
export{UIView};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H2VOVHFO0",
//	"editVersion": 73,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H2VOVHFO2",
//			"editVersion": 30,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H2VOVHFP0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8HTSND60",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2VOVHFP1",
//			"editVersion": 12,
//			"attrs": {
//				"uiDef": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H2VOVHFP2",
//			"editVersion": 28,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "#null#>window.tabOSApp"
//				},
//				"mobile": {
//					"type": "bool",
//					"valText": "#false#>app.width<500"
//				},
//				"isNaked": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"assets": {
//					"type": "string",
//					"valText": "/@editkit/assets/preview"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H2VOVHFP3",
//			"editVersion": 14,
//			"attrs": {
//				"faceLog": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H2VOVHFP4",
//			"editVersion": 12,
//			"attrs": {
//				"hideSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H33URP2G0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H33UU7880",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"showSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H33USAD90",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H33UU7881",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"pause": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BJR33C0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BJRLOL0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"resume": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BJRLOL1",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BJRLOL2",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3BV4FMP0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3BV9ARD0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobileSide": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H3CKGDSL0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H3CLKM9C0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H2VOVHFO1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP5",
//					"editVersion": 66,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2VP0R4V0",
//							"editVersion": 42,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ0",
//									"editVersion": 112,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H390GGLS0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H391HRNA0",
//													"editVersion": 162,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "5",
//														"y": "5",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": {
//															"type": "string",
//															"valText": "${\"Face: \"+state.faceLog},state",
//															"localize": {
//																"EN": "${\"Face: \"+state.faceLog},state",
//																"CN": "${\"预设外观：\"+state.faceLog},state"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H391HRNA1",
//													"editVersion": 54,
//													"attrs": {
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H391HRNA2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H391HRNA3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H2VR7I5R0",
//											"editVersion": 26,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R1",
//													"editVersion": 164,
//													"attrs": {
//														"type": "box",
//														"id": "BoxDevice",
//														"position": "Absolute",
//														"x": "200",
//														"y": "100",
//														"w": "375",
//														"h": "750",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.5",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "true",
//														"shadowX": "2",
//														"shadowY": "3",
//														"shadowBlur": "6",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H2VRDAEI0",
//															"editVersion": 28,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA0",
//																	"editVersion": 72,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxHud",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA1",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU7882",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU7883",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C7",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C8",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VRKAIA2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VRKAIA3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU7884",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU7885",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL7",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C9",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C11",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VR7I5R3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VR7I5R4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H34AHRPL0",
//											"editVersion": 32,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H34AHRPL1",
//													"editVersion": 74,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTouch",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H34AHRPL2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H34AHRPL3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H34AHRPL4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL9",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C13",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C15",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H34AHRPL5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H34AHRPL6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H39266GK0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H394HA3U0",
//													"editVersion": 194,
//													"attrs": {
//														"type": "box",
//														"id": "BoxPlay",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "100%-45",
//														"w": "120",
//														"h": "40",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor.fontBodyLit",
//														"corner": "20",
//														"shadow": "true",
//														"shadowX": "0",
//														"shadowY": "3",
//														"shadowBlur": "6",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.30]",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392B3KM0",
//															"editVersion": 36,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392EUF50",
//																	"editVersion": 40,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/undo.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392EUF51",
//																	"editVersion": 59,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/undo.svg\",1)",
//																		"id": "BtnNaviReset",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392EUF52",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL11",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL12",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR30",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR31",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C17",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C18",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C19",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C20",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392EUF53",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H3971K360",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H3972BEC0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392EUF54",
//																	"editVersion": 10,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Reset UI",
//																			"localize": {
//																				"EN": "Reset UI",
//																				"CN": "重置界面"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392EUF55",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392EVVR0",
//															"editVersion": 38,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392EVVR1",
//																	"editVersion": 46,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/arrowleft.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392EVVR2",
//																	"editVersion": 61,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/arrowleft.svg\",1)",
//																		"id": "BtnNaviBack",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS0",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL13",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL14",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR32",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR33",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C21",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C22",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C23",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C24",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS1",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H39842S50",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H39857DA0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392EVVS2",
//																	"editVersion": 10,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Back",
//																			"localize": {
//																				"EN": "Back",
//																				"CN": "返回"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392EVVS3",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@homekit/ui/BtnIcon.js",
//															"jaxId": "1H392H3330",
//															"editVersion": 38,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1H392H3331",
//																	"editVersion": 40,
//																	"attrs": {
//																		"app": "#app",
//																		"w": "32",
//																		"h": "32",
//																		"image": "#assets+\"/arrowright.svg\"",
//																		"pad": "1"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H392H3332",
//																	"editVersion": 61,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(app,32,32,assets+\"/arrowright.svg\",1)",
//																		"id": "BtnNaviNext",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Top"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H392H3333",
//																	"editVersion": 52,
//																	"attrs": {
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL15",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL16",
//																					"editVersion": 6,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H3BJRLOL1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJSMR34",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJSMR35",
//																					"editVersion": 4,
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJRLOL1",
//																			"faceTagName": "resume"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C25",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C26",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9C27",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9C28",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H392H3334",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H398508O0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1H39857DA1",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H392H3335",
//																	"editVersion": 10,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Next",
//																			"localize": {
//																				"EN": "Next",
//																				"CN": "下一个预设外观"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1H392H3336",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H394HA3U1",
//													"editVersion": 54,
//													"attrs": {
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL17",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL18",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C29",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C30",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9C31",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9C32",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H394HA3U2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H394HA3U3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ1",
//									"editVersion": 42,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU7886",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU7887",
//													"editVersion": 8,
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H340BHMQ4",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H340BHMQ5",
//													"editVersion": 16,
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "280"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%-280"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOL19",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOL20",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H3BV4FMP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9C33",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9C34",
//													"editVersion": 12,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BV4FMP0",
//											"faceTagName": "mobile"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9C35",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9C36",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VPIJLJ3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2VP2LRF0",
//							"editVersion": 33,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ4",
//									"editVersion": 108,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxSide",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "280",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H2VP420F0",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ5",
//													"editVersion": 114,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxFaces",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H2VP9GIU0",
//															"editVersion": 24,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ10",
//																	"editVersion": 124,
//																	"attrs": {
//																		"type": "box",
//																		"id": "Top",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H2VPC2IR0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ11",
//																					"editVersion": 156,
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "\"\"",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,10,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": {
//																							"type": "string",
//																							"valText": "Faces:",
//																							"localize": {
//																								"EN": "Faces:",
//																								"CN": "预设外观:"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ12",
//																					"editVersion": 64,
//																					"attrs": {
//																						"1H33URP2G0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H33UU78810",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H33UU78811",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33URP2G0",
//																							"faceTagName": "hideSide"
//																						},
//																						"1H3BJR33C0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3BJRLOL21",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3BJRLOL22",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3BJR33C0",
//																							"faceTagName": "pause"
//																						},
//																						"1H33USAD90": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E0",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E1",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33USAD90",
//																							"faceTagName": "showSide"
//																						},
//																						"1H3CKGDSL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E2",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E3",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3CKGDSL0",
//																							"faceTagName": "mobileSide"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1H2VPIJLJ13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1H2VPIJLJ14",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@homekit/ui/BtnIcon.js",
//																			"jaxId": "1H2VRLUBO0",
//																			"editVersion": 38,
//																			"attrs": {
//																				"createArgs": {
//																					"type": "object",
//																					"def": "gearCrateArgs",
//																					"jaxId": "1H2VRLUBO1",
//																					"editVersion": 60,
//																					"attrs": {
//																						"app": "null",
//																						"w": "28",
//																						"h": "28",
//																						"image": "#assets+\"/close.svg\"",
//																						"pad": "3"
//																					}
//																				},
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO2",
//																					"editVersion": 80,
//																					"attrs": {
//																						"type": "#null#>BtnIcon(null,28,28,assets+\"/close.svg\",3)",
//																						"id": "BtnCloseFace",
//																						"position": "Absolute",
//																						"x": "100%-5",
//																						"y": "50%",
//																						"display": "On",
//																						"face": "",
//																						"anchorV": "Center",
//																						"margin": "",
//																						"anchorH": "Right"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO3",
//																					"editVersion": 64,
//																					"attrs": {
//																						"1H33URP2G0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H33UU78816",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H33UU78817",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33URP2G0",
//																							"faceTagName": "hideSide"
//																						},
//																						"1H3BJR33C0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3BJRLOL23",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3BJRLOL24",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3BJR33C0",
//																							"faceTagName": "pause"
//																						},
//																						"1H33USAD90": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E4",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E5",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H33USAD90",
//																							"faceTagName": "showSide"
//																						},
//																						"1H3CKGDSL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H3CLKM9E6",
//																							"editVersion": 4,
//																							"attrs": {
//																								"properties": {
//																									"type": "object",
//																									"jaxId": "1H3CLKM9E7",
//																									"editVersion": 0,
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"type": "array",
//																									"def": "Array",
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H3CKGDSL0",
//																							"faceTagName": "mobileSide"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H34ADPD40",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1H34AE42M0",
//																									"editVersion": 2,
//																									"attrs": {
//																										"event": ""
//																									}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1H2VRLUBO5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"type": "object",
//																					"jaxId": "1H2VRLUBO6",
//																					"editVersion": 0,
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ15",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU78818",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU78819",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL25",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL26",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E8",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VPIJLJ16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VPIJLJ17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "true",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H2VPLCK70",
//															"editVersion": 29,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K0",
//																	"editVersion": 118,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "FaceList",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "30",
//																		"w": "100%",
//																		"h": "100%-30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K1",
//																	"editVersion": 64,
//																	"attrs": {
//																		"1H33URP2G0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H33UU78820",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H33UU78821",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33URP2G0",
//																			"faceTagName": "hideSide"
//																		},
//																		"1H3BJR33C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3BJRLOL27",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3BJRLOL28",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3BJR33C0",
//																			"faceTagName": "pause"
//																		},
//																		"1H33USAD90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H33USAD90",
//																			"faceTagName": "showSide"
//																		},
//																		"1H3CKGDSL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H3CLKM9E14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1H3CLKM9E15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H3CKGDSL0",
//																			"faceTagName": "mobileSide"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1H2VR570K2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1H2VR570K3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ18",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78822",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78823",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL29",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL30",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VPIJLJ19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VPIJLJ20",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H349Q9B00",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H349Q9B01",
//													"editVersion": 122,
//													"attrs": {
//														"type": "box",
//														"id": "Line",
//														"position": "Absolute",
//														"x": "100%",
//														"y": "0",
//														"w": "1",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor.fontBodySub",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H349Q9B02",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H349Q9B03",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H349Q9B04",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOL31",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOL32",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H349Q9B10",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H349Q9B11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ21",
//									"editVersion": 26,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78824",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78825",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78826",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78827",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOL33",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOL34",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H3BV4FMP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CJUFCH0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CJUFCH1",
//													"editVersion": 12,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BV4FMP0",
//											"faceTagName": "mobile"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9E24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9E25",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VPIJLJ22",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VPIJLJ23",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H2VS1PMT0",
//							"editVersion": 24,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2VS1PMT1",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "Header",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H349TUC20",
//											"editVersion": 58,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H349TUC21",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "28",
//														"h": "28",
//														"image": "#assets+\"/menu.svg\"",
//														"pad": "0"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H349TUC22",
//													"editVersion": 84,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,28,28,assets+\"/menu.svg\",0)",
//														"id": "BtnFace",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,20,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H349TUC23",
//													"editVersion": 54,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H349TUC30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H349TUC31",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E28",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E29",
//																	"editVersion": 6,
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E31",
//																	"editVersion": 4,
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H349TUC32",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H34A8N2R0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H34A8UKU0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H349TUC33",
//													"editVersion": 10,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Show faces",
//															"localize": {
//																"EN": "Show faces",
//																"CN": "预设外观"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H349TUC34",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H2VS1PMU4",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU5",
//													"editVersion": 164,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": "Device:",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU6",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78830",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78831",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARE34",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARE35",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E36",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E37",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E38",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E39",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU8",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H2VS1PMT2",
//											"editVersion": 50,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H2VS1PMT3",
//													"editVersion": 100,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/btncombo.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMT4",
//													"editVersion": 69,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/btncombo.svg\",1)",
//														"id": "BtnDevice",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,0,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU0",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78838",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78839",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU1",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H358IN630",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H358J0000",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU2",
//													"editVersion": 10,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Choose Device",
//															"localize": {
//																"EN": "Choose Device",
//																"CN": "选择设备"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU3",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1H2VS1PMU9",
//											"editVersion": 27,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU10",
//													"editVersion": 138,
//													"attrs": {
//														"type": "edit",
//														"id": "EdW",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "375",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU11",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78832",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78833",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMU12",
//													"editVersion": 2,
//													"attrs": {
//														"OnUpdate": {
//															"type": "fixedFunc",
//															"jaxId": "1H357M5CO0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H357MO4Q0",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMU13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H2VS1PMV0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV1",
//													"editVersion": 196,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "2",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "x",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV2",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78834",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78835",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMV4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1H2VS1PMV5",
//											"editVersion": 27,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV6",
//													"editVersion": 142,
//													"attrs": {
//														"type": "edit",
//														"id": "EdH",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,20,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "750",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV7",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H33UU78836",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H33UU78837",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H2VS1PMV8",
//													"editVersion": 2,
//													"attrs": {
//														"OnUpdate": {
//															"type": "fixedFunc",
//															"jaxId": "1H357MCAE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H357MO4Q1",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H2VS1PMV9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H35A7MM30",
//											"editVersion": 21,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A7MM31",
//													"editVersion": 182,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": "Zoom:",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A7MM40",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A7MM41",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A7MM42",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARF0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARF1",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A7MM43",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A7MM44",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H35A826R0",
//											"editVersion": 56,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H35A826R1",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/dec.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A826R2",
//													"editVersion": 78,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/dec.svg\",1)",
//														"id": "BtnZoomOut",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A826R3",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A826R4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A826R5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM18",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM19",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A826R6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35A826R7",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35A826R8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A826R9",
//													"editVersion": 10,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Zoom out",
//															"localize": {
//																"EN": "Zoom out",
//																"CN": "缩小"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H35A826R10",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H35A87850",
//											"editVersion": 32,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A87851",
//													"editVersion": 186,
//													"attrs": {
//														"type": "text",
//														"id": "TxtZoom",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "100%",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A87860",
//													"editVersion": 46,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A87861",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A87862",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM20",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM21",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CJUFCH2",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CJUFCH3",
//																	"editVersion": 14,
//																	"attrs": {
//																		"w": {
//																			"type": "length",
//																			"valText": "\"\""
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F24",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F25",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F27",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A87863",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35ASSRE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35ATVIT0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A87864",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H35A9QIV0",
//											"editVersion": 59,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H35A9QIV1",
//													"editVersion": 112,
//													"attrs": {
//														"app": "#app",
//														"w": "26",
//														"h": "26",
//														"image": "#assets+\"/inc.svg\"",
//														"pad": "1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H35A9QIV2",
//													"editVersion": 79,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,26,26,assets+\"/inc.svg\",1)",
//														"id": "BtnZoomIn",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H35A9QIV3",
//													"editVersion": 64,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H35A9QIV4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H35A9QIV5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM22",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM23",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F28",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F29",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9F30",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9F31",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H35A9QIV6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H35A9QIV7",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H35A9QIV8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H35A9QIV9",
//													"editVersion": 10,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Zoom in",
//															"localize": {
//																"EN": "Zoom in",
//																"CN": "放大"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H35A9QIV10",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@homekit/ui/BtnIcon.js",
//											"jaxId": "1H34AB4KC0",
//											"editVersion": 43,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H34AB4KC1",
//													"editVersion": 58,
//													"attrs": {
//														"app": "#app",
//														"w": "28",
//														"h": "28",
//														"image": "#assets+\"/send.svg\"",
//														"pad": "3"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H34AB4KC2",
//													"editVersion": 84,
//													"attrs": {
//														"type": "#null#>BtnIcon(app,28,28,assets+\"/send.svg\",3)",
//														"id": "BtnShare",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,20]",
//														"attach": "#isNaked?false:true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H34AB4KC3",
//													"editVersion": 30,
//													"attrs": {
//														"1H33URP2G0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H34AB4KC4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H34AB4KC5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33URP2G0",
//															"faceTagName": "hideSide"
//														},
//														"1H3BJR33C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BJRLOM4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BJRLOM5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BJR33C0",
//															"faceTagName": "pause"
//														},
//														"1H3BV4FMP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3BV9ARE32",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3BV9ARE33",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3BV4FMP0",
//															"faceTagName": "mobile"
//														},
//														"1H33USAD90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E32",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E33",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H33USAD90",
//															"faceTagName": "showSide"
//														},
//														"1H3CKGDSL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H3CLKM9E34",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H3CLKM9E35",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H3CKGDSL0",
//															"faceTagName": "mobileSide"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H34AB4KC6",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H3KT44I10",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H3KT4A850",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H34AB4KC7",
//													"editVersion": 10,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "分享预览...",
//															"localize": {
//																"EN": "分享预览...",
//																"CN": "分享预览..."
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H34AB4KC8",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2VS1PMV10",
//									"editVersion": 64,
//									"attrs": {
//										"1H33URP2G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H33UU78840",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H33UU78841",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33URP2G0",
//											"faceTagName": "hideSide"
//										},
//										"1H3BJR33C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3BJRLOM24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3BJRLOM25",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3BJR33C0",
//											"faceTagName": "pause"
//										},
//										"1H33USAD90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9F32",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9F33",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H33USAD90",
//											"faceTagName": "showSide"
//										},
//										"1H3CKGDSL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H3CLKM9F34",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H3CLKM9F35",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H3CKGDSL0",
//											"faceTagName": "mobileSide"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2VS1PMV11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2VS1PMV12",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP6",
//					"editVersion": 64,
//					"attrs": {
//						"1H33URP2G0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H33UU78842",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H33UU78843",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H33URP2G0",
//							"faceTagName": "hideSide"
//						},
//						"1H3BJR33C0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3BJRLON0",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3BJRLON1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H3BJR33C0",
//							"faceTagName": "pause"
//						},
//						"1H33USAD90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3CLKM9F36",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3CLKM9F37",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H33USAD90",
//							"faceTagName": "showSide"
//						},
//						"1H3CKGDSL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H3CLKM9F38",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H3CLKM9F39",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H3CKGDSL0",
//							"faceTagName": "mobileSide"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H2VOVHFP7",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H2VOVHFP8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H2VOVHFP9",
//			"editVersion": 62,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}