//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HBV0N7U60StartDoc*/
import {makeObjEventEmitter,makeNotify} from "/@events";
import {mergeCodeWithSeg} from "../exporters/codesegs.js";
/*}#1HBV0N7U60StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEditWithCanvas=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxEditCode,boxCanvas;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HBPMIQ541LocalVals*/
	let appPrj,editPrj,DefDocEditor,codeEditor,uiCanvas,editDoc;
	let UICanvas;
	appPrj=app.prj;
	editPrj=appPrj.codyPrj;
	DefDocEditor=appPrj.DefDocEditor;
	editDoc=dataDoc.codyDoc;
	UICanvas=UIEditWithCanvas.getCanvasReg(dataDoc);
	/*}#1HBPMIQ541LocalVals*/
	
	/*#{1HBPMIQ541PreState*/
	let editMode="";//"Code"/"Canvas"
	let editState=editDoc.editAttrState;
	let naviView=app.naviView;
	let infoView=app.infoView;
	/*}#1HBPMIQ541PreState*/
	/*#{1HBPMIQ541PostState*/
	let pandingCodeUpdate=false;
	/*}#1HBPMIQ541PostState*/
	cssVO={
		"hash":"1HBPMIQ541",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","traceSize":true,
		"app":app,
		children:[
			{
				"hash":"1HBPMKDGD0",
				"type":"hud","id":"BoxEditCode","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HBPMKDGD2",
						"type":"box","id":"BoxEditGearBtn","x":5,"y":5,"w":30,"h":30,"zIndex":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
						"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
						children:[
							{
								"hash":"1HBPMKDGD4",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/paint.svg",null),"id":"BtnEditGear","x":0,"y":0,"padding":2,
								"tip":"Switch to Design Mode",
								"OnClick":function(event){
									/*#{1HC1NFHHJ0FunctionBody*/
									self.setEditMode("Canvas");
									/*}#1HC1NFHHJ0FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HBPMLKQU0",
				"type":"hud","id":"BoxCanvas","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1HBPMIQ541ExtraCSS*/
		editPrj:editPrj,editDoc:editDoc,dataDoc:dataDoc,
		/*}#1HBPMIQ541ExtraCSS*/
		faces:{
			"code":{
				/*BoxEditCode*/"#1HBPMKDGD0":{
					"display":1
				},
				/*BoxCanvas*/"#1HBPMLKQU0":{
					"display":0
				}
			},"canvas":{
				/*BoxEditCode*/"#1HBPMKDGD0":{
					"display":0
				},
				/*BoxCanvas*/"#1HBPMLKQU0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxEditCode=self.BoxEditCode;boxCanvas=self.BoxCanvas;
			/*#{1HBPMIQ541Create*/
			makeNotify(self);
			makeObjEventEmitter(self);
			codeEditor=boxEditCode.insertNewBefore(DefDocEditor(app,mode,codeText,cfgVO,dataDoc),self.BoxEditGearBtn);
			//Rout all codeEditor events to this:
			codeEditor.emit=this.emit.bind(this);
			codeEditor.emitNotify=this.emitNotify.bind(this);
			codeEditor.on=this.on.bind(this);
			codeEditor.off=this.off.bind(this);
			codeEditor.onNotify=this.onNotify.bind(this);
			codeEditor.offNotify=this.offNotify.bind(this);
			//Trace codeEditor dialog show/off
			{
				let y=self.BoxEditGearBtn.y;
				codeEditor.on("DialogOn",(h)=>{
					self.BoxEditGearBtn.animate({type:"pose",y:y+h,time:80});
				});
				codeEditor.on("DialogOff",(h)=>{
					self.BoxEditGearBtn.animate({type:"pose",y:y,time:80});
				});
			}
			self.setEditMode(editState.editorMode||"Canvas");
			/*}#1HBPMIQ541Create*/
		},
		/*#{1HBPMIQ541EndCSS*/
		/*}#1HBPMIQ541EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HBPNBJ6V0FunctionBody*/
		if(uiCanvas && uiCanvas.getCurEditor()===self){
			UICanvas.bindToEditor(null);
		}
		/*}#1HBPNBJ6V0FunctionBody*/
	};
	/*#{1HBPMIQ541PostCSSVO*/
	//************************************************************************
	//:Edit mode manages:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.setEditMode=function(mode){
			if(editMode===mode){
				return;
			}
			editMode=mode||"Code";
			if(editMode==="Code"){
				editState.editorMode="Code";
				if(pandingCodeUpdate){
					editDoc.maybeUpdateDocText(false);
					pandingCodeUpdate=false;
				}
				self.showFace("code");
				codeEditor.focus();
			}else{
				editState.editorMode="Canvas";
				self.showFace("canvas");
				uiCanvas=UICanvas.bindToEditor(self);
				naviView.showView("NaviDoc");
				infoView.showView("EditObj");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.getEditMode=function(){
			return editMode;
		};
	}
	//************************************************************************
	//Code Editor related:
	//************************************************************************
	{
		//********************************************************************
		//Editor related:
		//********************************************************************
		{
			//----------------------------------------------------------------
			cssVO.init=async function(){
				return await codeEditor.init();
			};
	
			//----------------------------------------------------------------
			cssVO.applyCfg=function(opts){
				return codeEditor.applyCfg(opts);
			};
			
			//----------------------------------------------------------------
			cssVO.maybeUpdateCode=function(){
				if(editMode==="Code"){
					pandingCodeUpdate=false;
					return true;
				}
				pandingCodeUpdate=true;
				return false;
			};
	
			//----------------------------------------------------------------
			cssVO.setEditText=function(text,undo=true){
				codeEditor.setEditText(text,undo);
			};
			
			//----------------------------------------------------------------
			cssVO.mergeCodeIn=function(text,update=true){
				let docText;
				docText=self.getEditText();
				text=mergeCodeWithSeg(docText,text,editDoc.missingCodeSegs||{});
				if(update){
					self.setEditText(text);
				}
				return text;
			};
	
			//----------------------------------------------------------------
			cssVO.getEditText=function(){
				return codeEditor.getEditText();
			};
			
			//----------------------------------------------------------------
			cssVO.getSelection=function(){
				return codeEditor.getSelection();
			};
	
			//----------------------------------------------------------------
			cssVO.replaceSelection=function(text,select){
				codeEditor.replaceSelection(text,select);
			};
	
			//----------------------------------------------------------------
			cssVO.getSelectionRange=function(){
				return codeEditor.getSelectionRange();
			};
	
			//----------------------------------------------------------------
			cssVO.getCursorPos=function(){
				return codeEditor.getCursorPos();
			};
	
			//----------------------------------------------------------------
			cssVO.getCursorIndex=function(){
				return codeEditor.getCursorIndex();
			};
	
			//----------------------------------------------------------------
			cssVO.getEditVersion=function(){
				return codeEditor.getEditVersion();
			};
			
			//----------------------------------------------------------------
			cssVO.clearHistory=function(){
				return codeEditor.clearHistory();
			}
	
			//----------------------------------------------------------------
			cssVO.focus=function(){
				editDoc.OnDocFocus();
				if(editMode==="Code"){
					codeEditor.focus();
				}else{
					self.showFace("canvas");
					uiCanvas=UICanvas.bindToEditor(self);
				}
			};
	
			//----------------------------------------------------------------
			cssVO.blur=function(){
				if(editMode==="Code"){
					codeEditor.blur();
				}else{
					//TODO: Code this:
				}
			};
	
			//--------------------------------------------------------------------
			cssVO.gotoLine=function(line){
				if(editMode!=="Code"){
					self.setEditMode("Code");
				}
				if(typeof(line)==="string"){
					line="//:"+line;
				}
				return codeEditor.gotoLine(line);
			};
		}
		
		//********************************************************************
		//Work with cody
		//********************************************************************
		{
			//----------------------------------------------------------------
			cssVO.peekUndoAction=function(){
				return codeEditor.peekUndoAction();
			};
	
			//----------------------------------------------------------------
			cssVO.peekRedoAction=function(){
				return codeEditor.peekRedoAction();
			};
	
			//----------------------------------------------------------------
			cssVO.undo=function(){
				let action;
				action=codeEditor.peekUndoAction();
				if(!action){
					return;
				}
				if(editMode==="Code"){
					if(action.doc){
						self.setEditMode("Canvas");
					}
				}else{
					if(!action.doc){
						self.setEditMode("Code");
					}
				}
				codeEditor.undo();
			};
	
			//----------------------------------------------------------------
			cssVO.redo=function(){
				let action;
				action=codeEditor.peekRedoAction();
				if(!action){
					return;
				}
				if(editMode==="Code"){
					if(action.doc){
						self.setEditMode("Canvas");
					}
				}else{
					if(!action.doc){
						self.setEditMode("Code");
					}
				}
				codeEditor.redo();
			};
	
			//----------------------------------------------------------------
			cssVO.addCodyEditAction=function(action){
				codeEditor.addCodyEditAction(action);
			};
		}
	}
	
	//------------------------------------------------------------------------
	//Handle shortcut, only handle "Find"/Replace
	cssVO.handleShortcut=function(cmd){
		if(editMode==="Code"){
			if(cmd==="Find"){
				codeEditor.findNext();
				return 1;
			}else if(cmd==="FindNext"){
				codeEditor.findNext();
				return 1;
			}else if(cmd==="FindPre"){
				codeEditor.findPre();
				return 1;
			}else if(codeEditor.handleShortcut){
				return codeEditor.handleShortcut(cmd);
			}
			return 0;
		}else{
			if(uiCanvas){
				return uiCanvas.handleShortcut(cmd);
			}
		}
		return 0;
	};
	/*}#1HBPMIQ541PostCSSVO*/
	return cssVO;
};
/*#{1HBPMIQ541ExCodes*/
//----------------------------------------------------------------------------
let canvasRegs=[];
UIEditWithCanvas.regCanvas=function(canvasFunc){
	if(canvasRegs.indexOf(canvasFunc)<0){
		canvasRegs.push(canvasFunc);
	}
};

//----------------------------------------------------------------------------
UIEditWithCanvas.getCanvasReg=function(doc){
	let reg;
	for(reg of canvasRegs){
		if(reg.scoreDoc){
			if(reg.scoreDoc(doc)===100){
				return reg;
			}
		}
	}
	return null;
};

//----------------------------------------------------------------------------
UIEditWithCanvas.scoreDoc=function(doc){
	let reg,score,maxScore;
	maxScore=0;
	for(reg of canvasRegs){
		if(reg.scoreDoc){
			score=reg.scoreDoc(doc);
			if(score>maxScore){
				maxScore=score;
			}
		}
	}
	return maxScore;
};
/*}#1HBPMIQ541ExCodes*/


/*#{1HBV0N7U60EndDoc*/
/*}#1HBV0N7U60EndDoc*/

export default UIEditWithCanvas;
export{UIEditWithCanvas};
