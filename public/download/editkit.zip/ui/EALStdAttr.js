//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GA9NBELT0StartDoc*/
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1GA9NBELT0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALStdAttr=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GA9NBELT7LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	/*}#1GA9NBELT7LocalVals*/
	
	/*#{1GA9NBELT7PreState*/
	icon=attrObj.icon||attrDef.icon||(attrDef.def?attrDef.def.icon:null)||"";
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GA9NBELT7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val2ShowText(attrObj.val),
		"hyper":attrObj.hyper,"valText":attrObj.valText,"localized":!!attrObj.localize,
		/*#{1GA9NBELT5ExState*/
		/*}#1GA9NBELT5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GA9NBELT7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GA9NBELT7PostState*/
	cssVO={
		"hash":"1GA9NBELT7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"padding":[0,3,0,0],"minW":"",
		"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GA9ORHML0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GA9PH50S0",
				"type":"box","x":0,"y":"100%","w":">calc(100% - 5px)","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			},
			{
				"hash":"1GURDCSBF0",
				"type":"box","id":"BoxLoc","x":-12,"y":"50%","w":12,"h":12,"anchorY":1,"alpha":$P(()=>(state.localized?1:0.5),state),"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor.lineBody,"maskImage":appCfg.sharedAssets+"/web.svg","attached":attrObj.def.localizable,
			},
			{
				"hash":"1IGG5JO210",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IGG5LRHF0",
						"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"margin":[0,0,0,2],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
					},
					{
						"hash":"1IGG5MD4Q0",
						"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":cfgSize.attrLineH,"margin":[0,3,0,2],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignV":1,"autoW":true,
					},
					{
						"hash":"1IGG5MH840",
						"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.value}${state.hyper?` =${state.valText}`:""}`),state),
						"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
						/*#{1IGG5MH840Codes*/
						/*}#1IGG5MH840Codes*/
					}
				],
			}
		],
		/*#{1GA9NBELT7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerLine,
		/*}#1GA9NBELT7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GA9ORHML0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GA9ORHML0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GA9ORHML0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GA9ORHML0":{
					"shadow":true
				},
				/*TxtVal*/"#1IGG5MH840":{
					"display":0
				},
				/*#{1GA9P6RFR0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GA9P6RFR0Code*/
			},"editOff":{
				/*BoxBG*/"#1GA9ORHML0":{
					"shadow":false
				},
				/*TxtVal*/"#1IGG5MH840":{
					"display":1
				},
				/*#{1GA9P7KTD0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GA9P7KTD0Code*/
			},"showEdit":{
				/*#{1GDV1O2A60Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV1O2A60Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA9NBELT7Create*/
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			/*}#1GA9NBELT7Create*/
		},
		/*#{1GA9NBELT7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GA9NBELT7EndCSS*/
	};
	/*#{1GA9NBELT7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
		state.localized=!!attrObj.localize;
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(attrObj.startEdit){
			attrObj.startEdit(attrObj,self);
		}else{
			if(attrObj.localize){
				app.showLocalizerDlg({attrObj:attrObj,hud:self,box:box});
				//app.showDlg(DlgEditLocString,{attrObj:attrObj,hud:self,box:box});
			}else if(attrObj.isMockupState){
				app.showDlg(DlgMenu,{
					hud:self,
					items:[
						{text:(($ln==="CN")?("应用模拟样本"):/*EN*/("Apply Mokcup")),code:"Apply",icon:appCfg.sharedAssets+"/run.svg"},
						{text:(($ln==="CN")?("同步当前样本"):/*EN*/("Sync Mokcup")),code:"Sync",icon:appCfg.sharedAssets+"/refresh.svg"},
					],
					callback(item){
						if(!item){
							return;
						}
						if(item.code==="Apply"){
							attrObj.prj.editAttr_applyMockupState(attrObj);
						}else if(item.code==="Sync"){
							attrObj.prj.editAttr_syncMockupState(attrObj);
						}
					}
				});
			}else{
				app.showDlg(DlgRawEditAttr,{
					line:self,box:box,
					attrObj:attrObj
				});
			}
		}
	};
	/*}#1GA9NBELT7PostCSSVO*/
	cssVO.constructor=EALStdAttr;
	return cssVO;
};
/*#{1GA9NBELT7ExCodes*/
/*}#1GA9NBELT7ExCodes*/

//----------------------------------------------------------------------------
EALStdAttr.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GA9NBELT7PreAISpot*/
	/*}#1GA9NBELT7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GA9NBELT7PostAISpot*/
	/*}#1GA9NBELT7PostAISpot*/
	return exposeVO;
};

/*#{1GA9NBELT0EndDoc*/
/*}#1GA9NBELT0EndDoc*/

export default EALStdAttr;
export{EALStdAttr};
