//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GBT1HST30StartDoc*/
import {EditHudObj} from "../edithud/EditHudObj.js";
import {EALGroup} from "./EALGroup.js";
import {LineCard} from "./LineCard.js";
/*}#1GBT1HST30StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAddHud=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GBT1HST37LocalVals*/
	let listBox=null;
	let dlgVO=null;
	let curLine=null;
	/*}#1GBT1HST37LocalVals*/
	
	/*#{1GBT1HST37PreState*/
	/*}#1GBT1HST37PreState*/
	/*#{1GBT1HST37PostState*/
	/*}#1GBT1HST37PostState*/
	cssVO={
		"hash":"1GBT1HST37",nameHost:true,
		"type":"box","x":20,"y":30,"w":380,"h":"","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
		"borderColor":cfgColor.lineBodySub,"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1IA60JAPE0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"cursor":"move","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1IA60K16D0",
						"type":"text","x":10,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":"Create New Component","fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1IA60MK7M0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 28px)","y":3,
						"OnClick":function(event){
							/*#{1IA60O3ID0FunctionBody*/
							self.close();
							/*}#1IA60O3ID0FunctionBody*/
						},
					},
					{
						"hash":"1IA60QHDF0",
						"type":"box","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["gntLineBreak"],"borderColor":cfgColor["gntSelect"],
					}
				],
			},
			{
				"hash":"1GBTPTAEF0",
				"type":"text","id":"TxtInfo","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","margin":[5,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":"Choose new component type:","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","wrap":true,"autoH":true,
			},
			{
				"hash":"1GBT1Q5V30",
				"type":"hud","id":"TypeList","position":"relative","x":0,"y":0,"w":"100%","h":500,"overflow":"auto-y","margin":[0,0,5,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y",
			},
			{
				"hash":"1GBTQ04170",
				"type":"text","id":"TxtInfo","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","margin":[5,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":"You can also drag & drop from 'component type' tool-box to create a new component.","fontSize":txtSize.smallMid,
				"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"autoH":true,
			},
			{
				"hash":"1GBTPQ58N0",
				"type":"hud","id":"BoxBtns","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GBTPQ58O0",
						"type":BtnText("",100,24,"Button",false,""),"id":"BtnAdd","x":">calc(50% - 60px)","y":"50%","anchorX":1,"anchorY":1,"text":"Create","corner":3,
						/*#{1GBTPQ58O0Codes*/
						OnClick(){
							self.createItem();
						}
						/*}#1GBTPQ58O0Codes*/
					},
					{
						"hash":"1GBTPQ58O5",
						"type":BtnText("",100,24,"Button",false,""),"id":"BtnClose","x":">calc(50% + 60px)","y":"50%","anchorX":1,"anchorY":1,"text":"Close","corner":3,
						/*#{1GBTPQ58O5Codes*/
						OnClick(){
							self.close();
						}
						/*}#1GBTPQ58O5Codes*/
					}
				],
			}
		],
		/*#{1GBT1HST37ExtraCSS*/
		/*}#1GBT1HST37ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;
			/*#{1GBT1HST37Create*/
			VFACT.applyMoveDrag(boxHeader,self);
			listBox=self.TypeList;
			/*}#1GBT1HST37Create*/
		},
		/*#{1GBT1HST37EndCSS*/
		/*}#1GBT1HST37EndCSS*/
	};
	/*#{1GBT1HST37PostCSSVO*/
	function getHudCatalogGroup(catalogName){
		let defs;
		defs=EditHudObj.getCatalogDefs(catalogName);
		if(!defs || !defs.length){
			return {group:1,name:catalogName,defs:[]};
		}
		return {
			group:1,name:catalogName,defs:defs
		};
	};
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let types,x,catalogs,name;
		dlgVO=vo;
		types=[];
		curLine=null;
		listBox.clearChildren();
		catalogs=EditHudObj.getCatalogs();
		//Add all catalogs:
		for(name of catalogs){
			types.push(getHudCatalogGroup(name));
		}
		self.addTypes(types,self.TypeList);
		self.BtnAdd.enable=0;
		if(vo.x>=0){
			let rect,hud;
			hud=vo.hud||vo.uiObj;
			if(hud){
				rect=hud.getBoundingClientRect();
				x=rect.x+vo.x;
				if(vo.align===2){
					x-=self.w;
				}
			}
			self.x=x;
		}
	};
	//------------------------------------------------------------------------
	cssVO.addTypes=function(types,ownerBox){
		let stub,css,line;
		function addTypeLine(stub,ownerBox){
			if(stub.group){
				css=EALGroup(app,stub,self,ownerBox);
				line=ownerBox.appendNewChild(css);
				self.addTypes(stub.defs,line.boxLines);
				if(stub.open){
					line.open();
				}
			}else{
				css={
					type:LineCard(app,stub,self),stub:stub,
					OnClick(){
						self.focusLine(this);
					}
				};
				line=ownerBox.appendNewChild(css);
			}
		}
		for(stub of types){
			addTypeLine(stub,ownerBox);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focusLine=function(line){
		if(line===curLine){
			return;
		}
		if(curLine){
			curLine.showFace("blur");
		}
		curLine=line;
		if(curLine){
			curLine.showFace("focus");
		}
		self.updateBtn();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateBtn=function(){
		if(!curLine){
			self.BtnAdd.enable=0;
			return;
		}
		self.BtnAdd.enable=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.createItem=function(){
		let stub,def;
		if(!curLine){
			return;
		}
		stub=curLine.stub;
		app.closeDlg(self);
		if(dlgVO.callback){
			dlgVO.callback(stub);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		app.closeDlg(self);
	};
	/*}#1GBT1HST37PostCSSVO*/
	return cssVO;
};
/*#{1GBT1HST37ExCodes*/
/*}#1GBT1HST37ExCodes*/


/*#{1GBT1HST30EndDoc*/
/*}#1GBT1HST30EndDoc*/

export default DlgAddHud;
export{DlgAddHud};
