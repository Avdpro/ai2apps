//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GV3C1P8S0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1GV3C1P8S0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgLongText=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,boxHeader,txtTitle,txtMode,hudEdit,btnWrap;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let dlgY=375;
	let orgX=0;
	let orgY=0;
	
	/*#{1GV3C1P8S1LocalVals*/
	let dlgVO,docMode,cm;
	cm=null;
	/*}#1GV3C1P8S1LocalVals*/
	
	/*#{1GV3C1P8S1PreState*/
	/*}#1GV3C1P8S1PreState*/
	state={
		"txtMode":"Plain Text",
		/*#{1GV3C1P8S6ExState*/
		/*}#1GV3C1P8S6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GV3C1P8S1PostState*/
	/*}#1GV3C1P8S1PostState*/
	cssVO={
		"hash":"1GV3C1P8S1",nameHost:true,
		"type":"hud","x":550,"y":375,"w":500,"h":"","anchorX":2,"anchorY":1,"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1GV3C7ICA0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,
				"corner":4,"shadow":true,"shadowY":6,"shadowBlur":6,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1I3ER5NH80",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1I3ER6EHN0",
						"type":"text","id":"TxtTitle","position":"relative","x":5,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,10,0,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("编辑长文本"):("Edit Long Text")),"fontSize":txtSize.smallBig,"fontWeight":"bold",
						"fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
					},
					{
						"hash":"1I3ER7DRU0",
						"type":BtnIcon("front",32,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnShowBig","position":"relative","x":0,"y":0,"padding":1,
						"OnClick":function(event){
							self.showBig(this,event);
						},
					},
					{
						"hash":"1I3ER9GF50",
						"type":BtnIcon("front",32,0,appCfg.sharedAssets+"/dec.svg",null),"id":"BtnShowSmall","position":"relative","x":0,"y":0,"display":0,"padding":1,
						"OnClick":function(event){
							self.showSmall(this,event);
						},
					}
				],
			},
			{
				"hash":"1GV3CIHCC0",
				"type":"box","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":20,"margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.tool,"border":[1,1,0,1],
				children:[
					{
						"hash":"1GV3COIEG0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMode","x":5,"y":"50%","anchorY":1,"padding":1,
						"OnClick":function(event){
							/*#{1GV3GSSJC0FunctionBody*/
							self.chooseMode();
							/*}#1GV3GSSJC0FunctionBody*/
						},
					},
					{
						"hash":"1GV3CQD5G0",
						"type":"text","id":"TxtMode","x":25,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.txtMode),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1GV3CVS210",
				"type":"box","id":"BoxEdit","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":1,"contentLayout":"flex-y",
				children:[
					{
						"hash":"1GV3D0LGA0",
						"type":"hud","id":"HudEdit","position":"relative","x":0,"y":0,"w":"100%","h":200,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					}
				],
			},
			{
				"hash":"1GV3CN0IT0",
				"type":"box","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				"border":[0,1,1,1],
			},
			{
				"hash":"1GV3CM6D50",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":40,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","subAlign":2,
				children:[
					{
						"hash":"1GV3J84T10",
						"type":BtnSwitch(18,false),"id":"BtnWrap","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,3,0,0],
						/*#{1GV3J84T10Codes*/
						OnCheck(checked){
							self.setWrap(checked);
						}
						/*}#1GV3J84T10Codes*/
					},
					{
						"hash":"1GV3J92680",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,30,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("自动换行"):("Wrap lines")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1GV3D31PA0",
						"type":BtnText("",100,24,(($ln==="CN")?("应用"):("Apply")),false,""),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,20,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1GV3I9NS30FunctionBody*/
							self.close(true);
							/*}#1GV3I9NS30FunctionBody*/
						},
					},
					{
						"hash":"1GV3D57H70",
						"type":BtnText("warning",100,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,30,0,0],
						"corner":3,
						"OnClick":function(event){
							/*#{1GV3I9BDK0FunctionBody*/
							self.close(false);
							/*}#1GV3I9BDK0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1GV3C1P8S1ExtraCSS*/
		/*}#1GV3C1P8S1ExtraCSS*/
		faces:{
			"readOnly":{
				"#1GV3D31PA0":{
					"text":(($ln==="CN")?("关闭"):("Close"))
				},
				"#1GV3D57H70":{
					"display":0
				}
			},"!readOnly":{
				"#1GV3D31PA0":{
					"text":(($ln==="CN")?("应用"):("Apply"))
				},
				"#1GV3D57H70":{
					"display":1
				}
			},"small":{
				"#self":{
					"w":500,"anchorX":2,"x":$P(()=>(orgX)),"y":$P(()=>(orgY))
				},
				/*BtnShowBig*/"#1I3ER7DRU0":{
					"display":1
				},
				/*BtnShowSmall*/"#1I3ER9GF50":{
					"display":0
				},
				/*HudEdit*/"#1GV3D0LGA0":{
					"h":200
				},
				/*#{1I3ER4J0H0Code*/
				$(){
					self.y=dlgY;
					cm && cm.refresh();
				}
				/*}#1I3ER4J0H0Code*/
			},"big":{
				"#self":{
					"y":">calc(50% - 10px)","w":800,"anchorX":1,"x":"50%"
				},
				/*BtnShowBig*/"#1I3ER7DRU0":{
					"display":0
				},
				/*BtnShowSmall*/"#1I3ER9GF50":{
					"display":1
				},
				/*HudEdit*/"#1GV3D0LGA0":{
					"h":600
				},
				/*#{1I3ER4NBR0Code*/
				$(){
					cm && cm.refresh();
				}
				/*}#1I3ER4NBR0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;boxHeader=self.BoxHeader;txtTitle=self.TxtTitle;txtMode=self.TxtMode;hudEdit=self.HudEdit;btnWrap=self.BtnWrap;
			/*#{1GV3C1P8S1Create*/
			VFACT.applyMoveDrag(boxBG,self);
			VFACT.applyMoveDrag(boxHeader,self);
			/*}#1GV3C1P8S1Create*/
		},
		/*#{1GV3C1P8S1EndCSS*/
		/*}#1GV3C1P8S1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showBig=async function(sender,event){
		/*#{1I3ERH33S0Start*/
		/*}#1I3ERH33S0Start*/
		self.showFace("big");
	};
	//------------------------------------------------------------------------
	cssVO.showSmall=async function(sender,event){
		/*#{1I3ERIJEM0Start*/
		/*}#1I3ERIJEM0Start*/
		self.showFace("small");
	};
	/*#{1GV3C1P8S1PostCSSVO*/
	//------------------------------------------------------------------------
	let mods=[
		{text:"Plain Text"},
		{text:"Javascript",mode:"javascript"},
		{text:"HTML",mode:"html"},
		{text:"CSS",mode:"css"},
		{text:"C/CPP",mode:"cpp"},
		{text:"Java",mode:"java"},
	];
	
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let mode,hud,rect,x,y;
		self.showFace("small");
		dlgVO=vo;
		txtTitle.text=vo.title||(($ln==="CN")?("编辑长文本"):("Edit Long Text"));
		mode=vo.mode||"js";
		self.setText(vo.text||"",mode);
		hud=vo.hud;
		if(vo.readOnly){
			self.showFace("readOnly");
		}else{
			self.showFace("!readOnly");
		}
		if(hud){
			rect=hud.getBoundingClientRect();
			x=rect.x-10;
			y=rect.y+rect.height*0.5;
		}else{
			x=(app.width+500)/2;
			y=app.height/2;
		}
		if(y-self.h*0.5<10){
			y=self.h*0.5+10
		}
		self.x=x;self.y=y;
		dlgY=y;
		orgX=self.x;orgY=self.y;
		self.animate({type:"in",scale:0.9,alpha:0,time:100});
		if(cm){
			setTimeout(()=>{cm.focus()},20);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setText=async function(text,mode){
		let wrap=btnWrap.checked;
		if(cm){
			if(mode===docMode){
				cm.doc.setValue(text);
				return;
			}
			hudEdit.webObj.innerHTML="";
			cm=null;
		}
		if(!window.CodeMirror){
			//import CodeMirror
			await VFACT.appendScript("/@codemirror/lib/codemirror.js");
			await VFACT.appendCSS("/@codemirror/lib/codemirror.css");
			setTimeout(()=>{
				self.setText(text,mode);
				setTimeout(()=>{cm.focus()},20);
			},200);
			return;
		}
		docMode=mode||"text";
		switch(mode){
			case "javascript":
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				break;
			case "html":
				mode="text/html";
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
	
				await VFACT.appendScript("/@codemirror/mode/css.js");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/htmlmixed.js");
				break;
			case "markdown":
				wrap=true;
				mode="text/x-markdown";
				await VFACT.appendScript("/@codemirror/mode/markdown.js");
				break;
			case "json":
				mode={name: "javascript", json: true};
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				break;
			case "css":
			case ".css":
				mode={name: "css"};
				await VFACT.appendScript("/@codemirror/mode/css.js");
				break;
			case "jsx":
			case ".jsx":
				mode="text/jsx";
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/jsx.js");
				break;
			case ".cpp":
				mode="text/x-c++src";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			case ".java":
				mode="text/x-java";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			case "text":
			case ".txt":
				mode="text/plain";
				break;
		}
		cm=CodeMirror(hudEdit.webObj, {
			value:text,
			mode:mode,
			lineNumbers:true,
			undoDepth:20
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.getText=function(){
		if(cm){
			return cm.doc.getValue();
		}
		return "";
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(apply){
		let text,next;
		if(apply && cm){
			text=cm.doc.getValue();
		}else{
			text=null;
		}
		app.closeDlg(self,text);
		next=dlgVO.next||dlgVO.callback;
		if(next){
			next(!!apply,text);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseMode=function(){
		app.showDlg(DlgMenu,{
			hud:self.BtnMode,
			items:mods,
			callback(item){
				if(!item){
					return;
				}
				self.setText(self.getText(),item.mode);
				txtMode.text=item.text;
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.setWrap=function(wrap){
		if(cm){
			cm.setOption("lineWrapping",!!wrap);
		}
	};
	
	//------------------------------------------------------------------------
	/*}#1GV3C1P8S1PostCSSVO*/
	cssVO.constructor=DlgLongText;
	return cssVO;
};
/*#{1GV3C1P8S1ExCodes*/
/*}#1GV3C1P8S1ExCodes*/

//----------------------------------------------------------------------------
DlgLongText.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GV3C1P8S1PreAISpot*/
	/*}#1GV3C1P8S1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GV3C1P8S1PostAISpot*/
	/*}#1GV3C1P8S1PostAISpot*/
	return exposeVO;
};

/*#{1GV3C1P8S0EndDoc*/
/*}#1GV3C1P8S0EndDoc*/

export default DlgLongText;
export{DlgLongText};
