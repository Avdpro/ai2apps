//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HC1V0P1P0StartDoc*/
/*}#1HC1V0P1P0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIOutlet=function(outlet,segBox,canvas){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtID,boxLine,boxJointOrg,boxJointEnd,boxUnlink;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HC1V0P1P1LocalVals*/
	let svg=null;
	let svgPath=null;
	let focused=false;
	let boxSegs=canvas.BoxSegs;
	let traced=false;
	let dragMeta=null;
	let editPrj=outlet.prj;
	/*}#1HC1V0P1P1LocalVals*/
	
	/*#{1HC1V0P1P1PreState*/
	/*}#1HC1V0P1P1PreState*/
	state={
		"label":"result",
		/*#{1HC1V0P1P7ExState*/
		/*}#1HC1V0P1P7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HC1V0P1P1PostState*/
	state.label=outlet.idVal.val||"result";
	/*}#1HC1V0P1P1PostState*/
	cssVO={
		"hash":"1HC1V0P1P1",nameHost:true,
		"type":"button","x":66,"y":144,"w":"","h":24,"margin":[3,0,3,0],"padding":[5,15,5,12],"minW":10,"minH":16,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"subAlign":1,
		"outlet":outlet,
		children:[
			{
				"hash":"1HC1V5SF60",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				"border":2,"borderColor":cfgColor["fontBody"],"corner":[50,10,10,50],
			},
			{
				"hash":"1HC1VA5VT0",
				"type":"text","id":"TxtID","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"minH":12,"maxW":70,"maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
				"text":$P(()=>(state.label),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1HC1VEFK10",
				"type":"box","id":"BoxLine","x":"100%","y":"50%","w":10,"h":4,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
			},
			{
				"hash":"1HC1VGJ9T0",
				"type":"box","id":"BoxJointOrg","x":">calc(100% + 11px)","y":"50%","w":12,"h":12,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["body"],"border":3,"borderColor":cfgColor["fontBody"],"corner":20,
				children:[
					{
						"hash":"1HC57900U0",
						"type":"box","id":"BoxJointEnd","x":3,"y":3,"w":16,"h":16,"anchorX":1,"anchorY":1,"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBody"],"corner":20,
					}
				],
			},
			{
				"hash":"1HC7J92KU0",
				"type":"box","id":"BoxUnlink","x":"100%","y":"50%","w":20,"h":20,"anchorY":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":2,"borderColor":cfgColor["fontBody"],"corner":8,
				children:[
					{
						"hash":"1HC7JDJ2K0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnUnlink","x":"50%","y":"50%","anchorX":1,"anchorY":1,"padding":2,
						"OnClick":function(event){
							/*#{1HC7KINFG0FunctionBody*/
							self.linkToSeg(null);
							self.renderPath();
							self.showFace("focus");
							/*}#1HC7KINFG0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HC1V0P1P1ExtraCSS*/
		/*}#1HC1V0P1P1ExtraCSS*/
		faces:{
			"up":{
				/*#{1HC1V3JBS0PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC1V3JBS0PreCode*/
				/*BoxUnlink*/"#1HC7J92KU0":{
					"display":0
				}
			},"over":{
				/*#{1HC1V3JBS2PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC1V3JBS2PreCode*/
				/*BoxUnlink*/"#1HC7J92KU0":{
					"display":0
				}
			},"down":{
				/*#{1HC1V3JBS4PreCode*/
				$(){
					return !focused;
				},
				/*}#1HC1V3JBS4PreCode*/
				/*BoxUnlink*/"#1HC7J92KU0":{
					"display":0
				}
			},"focus":{
				/*BoxBG*/"#1HC1V5SF60":{
					"background":cfgColor["primary"]
				},
				/*BoxUnlink*/"#1HC7J92KU0":{
					"display":$P(()=>(!!outlet.linkedSeg))
				},
				/*#{1HC1V3JBS6Code*/
				$(){
					focused=true;
				},
				/*}#1HC1V3JBS6Code*/
			},"blur":{
				/*BoxBG*/"#1HC1V5SF60":{
					"background":cfgColor["secondary"]
				},
				/*BoxUnlink*/"#1HC7J92KU0":{
					"display":0
				},
				/*#{1HC1V3JBS8Code*/
				$(){
					focused=false;
				},
				/*}#1HC1V3JBS8Code*/
			},"mini":{
				"#self":{
					"h":16
				},
				/*TxtID*/"#1HC1VA5VT0":{
					"display":0
				}
			},"L2R":{
				/*BoxJointOrg*/"#1HC1VGJ9T0":{
					"rotate":0
				},
				/*#{1HCABC8PM0Code*/
				$(){
					outlet.pathDir=[1,0];
					svg.style.left="6px";
					svg.style.top="3px";
				},
				/*}#1HCABC8PM0Code*/
			},"R2L":{
				/*BoxJointOrg*/"#1HC1VGJ9T0":{
					"rotate":-180
				},
				/*#{1HCABCHI00Code*/
				$(){
					outlet.pathDir=[-1,0];
					svg.style.left="0px";
					svg.style.top="3px";
				},
				/*}#1HCABCHI00Code*/
			},"T2B":{
				/*BoxJointOrg*/"#1HC1VGJ9T0":{
					"rotate":-90
				},
				/*#{1HCABCQJU0Code*/
				$(){
					outlet.pathDir=[0,1];
					svg.style.left="3px";
					svg.style.top="6px";
				},
				/*}#1HCABCQJU0Code*/
			},"B2T":{
				/*BoxJointOrg*/"#1HC1VGJ9T0":{
					"rotate":90
				},
				/*#{1HCABD2780Code*/
				$(){
					outlet.pathDir=[0,-1];
					svg.style.left="3px";
					svg.style.top="0px";
				},
				/*}#1HCABD2780Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtID=self.TxtID;boxLine=self.BoxLine;boxJointOrg=self.BoxJointOrg;boxJointEnd=self.BoxJointEnd;boxUnlink=self.BoxUnlink;
			/*#{1HC1V0P1P1Create*/
			outlet.bindLiveObj(self);
			outlet.traceOn(self.syncOutlet);
			dragMeta=VFACT.applyMoveDrag(boxJointEnd,boxJointEnd);
			dragMeta.setCallbacks(self.startDragJT,null,self.endDragJT,self.dragJT);
			
			//:Test svg:
			svg= document.createElementNS("http://www.w3.org/2000/svg", "svg");
			svg.style.position="absolute";
			svg.style.left="6px";
			svg.style.top="3px";
			svg.style.width="1px";
			svg.style.height="1px";
			svg.style.overflow="unset";
			svgPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
			svgPath.setAttribute("fill", "none");
			traced=outlet.traced;
			if(traced){
				svgPath.setAttribute("stroke-width", "3");
				svgPath.setAttribute("stroke", "blue");
				svgPath.setAttribute("stroke-dasharray","");
			}else{
				svgPath.setAttribute("stroke-width", "2");
				svgPath.setAttribute("stroke", "black");
				svgPath.setAttribute("stroke-dasharray","3 3");
			}
			//poly.setAttribute("points", "-50,-50 100,100 150,50 200,100 250,50");
			svg.appendChild(svgPath);
			boxJointOrg.webObj.appendChild(svg);
			
			/*}#1HC1V0P1P1Create*/
		},
		/*#{1HC1V0P1P1EndCSS*/
		/*}#1HC1V0P1P1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HC3309290FunctionBody*/
		outlet.dropLiveObj(self);
		outlet.traceOff(self.syncOutlet);
		/*}#1HC3309290FunctionBody*/
	};
	/*#{1HC1V0P1P1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.syncOutlet=function(){
		state.label=outlet.idVal.val||"Result";
		if(traced!==outlet.traced){
			traced=outlet.traced;
			if(traced){
				svgPath.setAttribute("stroke-width", "3");
				svgPath.setAttribute("stroke", "blue");
				svgPath.setAttribute("stroke-dasharray","");
			}else{
				svgPath.setAttribute("stroke-width", "2");
				svgPath.setAttribute("stroke", "black");
				svgPath.setAttribute("stroke-dasharray","3 3");
			}
		}
	};
	
	//************************************************************************
	//:Path / Joint related:
	//************************************************************************
	{
		let boxSegsX,boxSegsY,orgX,orgY;
		//--------------------------------------------------------------------
		cssVO.renderPath=function(isDrag,pickedSeg=null){
			let kx1,ky1,kx2,ky2,rect,dir;
			let tgtSeg,x,y,points,dot;
			let factor=1.0/canvas.zoom;
			if(isDrag){
				svg.style.display="";
				if(pickedSeg){
					dir=pickedSeg.seg.pathDir;
					rect=pickedSeg.headerRect;
					x=rect.x+(dir[1]?rect.width*0.5:0)-orgX;
					y=rect.y+(dir[0]?rect.height*0.5:0)-orgY;
					x+=dir[0]===1?rect.width:0;
					y+=dir[1]===1?rect.height:0;
					dir=outlet.pathDir;
					dot=x*dir[0]+y*dir[1];
					if(0){//dot>0){
						kx1=x;ky1=0;
					}else{
						kx1=dir[0]*(50/factor);
						ky1=dir[1]*(50/factor);
					}
					dir=pickedSeg.seg.pathDir;
					dot=x*dir[0]+y*dir[1];
					if(0){//dot<0){
						kx2=0;ky2=y;
					}else{
						kx2=x+dir[0]*(50/factor);
						ky2=y+dir[1]*(50/factor);
					}
				}else{
					factor=1.0;
					x=boxJointEnd.x-6;
					y=boxJointEnd.y-3;
					dir=outlet.pathDir;
					dot=x*dir[0]+y*dir[1];
					if(dot>0){
						kx1=x;ky1=0;
					}else{
						kx1=dir[0]*50;ky1=dir[1]*50;
					}
					kx2=0;ky2=y;
				}
				points=`M 0,0 C ${kx1*factor},${ky1*factor} ${kx2*factor},${ky2*factor} ${x*factor},${y*factor}`;
				svgPath.setAttribute("d", points);
			}else{
				pickedSeg=outlet.linkedSeg;
				if(pickedSeg && (pickedSeg=pickedSeg.liveHudObj)){
					let isShort,dx,dy,len;
					rect=boxSegs.getBoundingClientRect();
					boxSegsX=rect.x;
					boxSegsY=rect.y;
					rect=boxJointOrg.getBoundingClientRect();
					orgX=rect.x+rect.width*0.5-boxSegsX;
					orgY=rect.y+rect.height*0.5-boxSegsY;
					svg.style.display="";
					rect=pickedSeg.headerRect;
					dir=pickedSeg.seg.pathDir;
					x=rect.x+(dir[1]?rect.width*0.5:0)-orgX;
					y=rect.y+(dir[0]?rect.height*0.5:0)-orgY;
					x+=dir[0]===1?rect.width:0;
					y+=dir[1]===1?rect.height:0;
					dir=outlet.pathDir;
					dot=x*dir[0]+y*dir[1];
					dx=(x<0?-x:x);
					dy=(y<0?-y:y);
					len=dx+dy;
					if(dir[1]==0){
						if(dy<50 && dx<50){
							isShort=true;
						}
					}else{
						if(dx<50 && dy<50){
							isShort=true;
						}
					}
					if(isShort){//dot>0){
						//kx1=x;ky1=0;
						kx1=dir[0]*(20/factor);
						ky1=dir[1]*(20/factor);
					}else{
						kx1=dir[0]*(50/factor);
						ky1=dir[1]*(50/factor);
					}
					
					dir=pickedSeg.seg.pathDir;
					dot=x*dir[0]+y*dir[1];
					if(isShort){//dot<0){
						//kx2=0;ky2=y;
						kx2=x+dir[0]*(20/factor);
						ky2=y+dir[1]*(20/factor);
					}else{
						kx2=x+dir[0]*(50/factor);
						ky2=y+dir[1]*(50/factor);
					}
					points=`M 0,0 C ${kx1*factor},${ky1*factor} ${kx2*factor},${ky2*factor} ${x*factor},${y*factor}`;
					svgPath.setAttribute("d", points);
					boxJointEnd.display=0;
				}else{
					svg.style.display="none";
					boxJointEnd.x=3;
					boxJointEnd.y=3;
					boxJointEnd.display=1;
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.startDragJT=function(evt){
			let rect;
			let scale=1.0/canvas.zoom;
			dragMeta.setScale(scale,scale);
			rect=boxSegs.getBoundingClientRect();
			boxSegsX=rect.x;
			boxSegsY=rect.y;
			rect=boxJointOrg.getBoundingClientRect();
			orgX=rect.x+rect.width*0.5-boxSegsX;orgY=rect.y+rect.height*0.5-boxSegsY;
		};
		
		//--------------------------------------------------------------------
		cssVO.dragJT=function(evt){
			let segHud;
			segHud=canvas.pickSegHud(evt.x-boxSegsX,evt.y-boxSegsY);
			canvas.setPickedSegHud(segHud);
			self.renderPath(true,segHud);
		};
		
		//--------------------------------------------------------------------
		cssVO.endDragJT=function(evt){
			let segHud;
			segHud=canvas.getPickedSegHud();
			if(segHud){
				self.linkToSeg(segHud.seg);
				canvas.setPickedSegHud(null);
			}else{
				boxJointEnd.x=3;
				boxJointEnd.y=3;
				self.linkToSeg(null);
				svg.style.display="none";
				canvas.creatSegByDragOutlet(self,boxJointEnd,evt.x,evt.y);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.linkToSeg=function(seg){
			if(outlet.linkedSeg===seg){
				return;
			}
			/*if(outlet.linkedSeg){
				outlet.linkedSeg.removeLinkedOutlet(outlet);
			}
			outlet.linkedSeg=seg;*/
			editPrj.editAttr_LinkSeg(outlet,seg,false);
			if(seg){
				svg.style.display="";
				//seg.linkOutlet(outlet);
				boxJointEnd.display=0;
				boxUnlink.display=true;
				sleep(500).then(()=>{
					boxUnlink.display=false;
				});
			}else{
				svg.style.display="none";
				boxJointEnd.x=3;
				boxJointEnd.y=3;
				boxJointEnd.display=1;
			}
		};
	}
	//************************************************************************
	//:Render snap to canvas:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.renderToCanvas=function(ctx,ox,oy){
			let orect,rect,list,i,n,hud,dir;
			let pickedSeg,size;
			//TODO: RenderBGBox:
			rect=boxBG.getBoundingClientRect();
			orect=rect;
			rect.x-=ox;rect.y-=oy;
			rect.x+=1;rect.y+=1;rect.width-=2;rect.height-=2;
			ctx.fillStyle="rgba(120,120,120,1)";
			ctx.strokeStyle="black";
			ctx.lineWidth = 2;
			ctx.beginPath();
			ctx.roundRect(rect.x,rect.y,rect.width,rect.height,[rect.height*0.5,0,0,rect.height*0.5]);
			ctx.fill();	
			ctx.stroke();	
	
			//Render outlets org-line:
			rect=boxLine.getBoundingClientRect();
			rect.x-=ox;rect.y-=oy;
			ctx.fillStyle="black";
			ctx.fillRect(rect.x-2,rect.y,rect.width+2,rect.height);
	
			//Render text:
			rect=txtID.getBoundingClientRect();
			rect.x-=ox;rect.y-=oy;
			ctx.fillStyle="white";
			ctx.textBaseline="top";
			ctx.font = "normal 12px arial";
			size=ctx.measureText(txtID.text);
			ctx.fillText(txtID.text,rect.x,orect.y+(orect.height-size.fontBoundingBoxDescent)*0.5+1,rect.width+10);
			
			//Render outlets org-box:
			rect=boxJointOrg.getBoundingClientRect();
			rect.x-=ox;rect.y-=oy;
			ctx.beginPath();
			ctx.ellipse(rect.x+rect.width*0.5, rect.y+rect.height*0.5, rect.width*0.5-1, rect.width*0.5-1, 0, 0, 2 * Math.PI);
			ctx.strokeStyle="black";
			ctx.fillStyle="white";
			ctx.lineWidth = 3;
			ctx.fill();
			ctx.stroke();
			
			//Render Path:
			pickedSeg=outlet.linkedSeg;
			if(pickedSeg && (pickedSeg=pickedSeg.liveHudObj)){
				let rect2,dir2,sx,sy,dx,dy,kx1,ky1,kx2,ky2,ax,ay,factor;

				sx=rect.x+rect.width*0.5;
				sy=rect.y+rect.height*0.5;
				dir=outlet.pathDir;
				sx+=dir[0]*6;
				sy+=dir[1]*6;

				rect2=pickedSeg.BoxHeader.getBoundingClientRect();
				dir2=pickedSeg.seg.pathDir;
				dx=rect2.x+rect2.height*0.5;
				dy=rect2.y+rect2.height*0.5;
				dx-=ox;dy-=oy;
				dx+=dir2[0]*18;
				dy+=dir2[1]*18;

				ax=dx-sx;ay=dy-sy;
				ax=ax<0?-ax:ax;
				ay=ay<0?-ay:ay;
				if(ax<50 && ay<50){
					factor=20;
				}else{
					factor=50;
				}
				
				kx1=sx+dir[0]*(factor);
				ky1=sy+dir[1]*(factor);
				
				kx2=dx+dir2[0]*factor;
				ky2=dy+dir2[1]*factor;
	
				ctx.beginPath();
				ctx.moveTo(sx, sy);
				ctx.bezierCurveTo(kx1, ky1, kx2, ky2, dx, dy);
				ctx.strokeStyle="black";
				ctx.lineWidth = 2;
				ctx.setLineDash([3,3]);
				ctx.stroke();
				ctx.setLineDash([]);
			}
		};
	}
	/*}#1HC1V0P1P1PostCSSVO*/
	return cssVO;
};
/*#{1HC1V0P1P1ExCodes*/
/*}#1HC1V0P1P1ExCodes*/

BoxAIOutlet.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:20,
	catalog:"",
	args: {
		"outlet": {
			"name": "outlet", "showName": "outlet", "type": "auto", "key": true, "fixed": true, 
			"initVal": {}
		}, 
		"segBox": {
			"name": "segBox", "showName": "segBox", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"canvas": {
			"name": "canvas", "showName": "canvas", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down","focus","blur","mini","L2R","R2L","T2B","B2T"],
	subContainers:{
	},
	/*#{1HC1V0P1P0ExGearInfo*/
	/*}#1HC1V0P1P0ExGearInfo*/
};
/*#{1HC1V0P1P0EndDoc*/
/*}#1HC1V0P1P0EndDoc*/

export default BoxAIOutlet;
export{BoxAIOutlet};
