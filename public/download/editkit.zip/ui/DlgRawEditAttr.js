//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BoxSteps} from "/@StdUI/ui/BoxSteps.js";
import {BoxRange} from "/@StdUI/ui/BoxRange.js";
/*#{1GAA1RLHQ0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgLongText} from "./DlgLongText.js";
/*}#1GAA1RLHQ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgRawEditAttr=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtRangeMin,txtRangeMax;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GAA1RLHQ7LocalVals*/
	let edText,attrListBox,txtLead,listBox;
	let attrLine,attrObj,mode;
	let attrChanged=0;
	let tipItems=[];
	let tipLead=null;
	let isShowTip,tipPos,curTipIdx;
	let orgAttrText;
	let syncVal=false;
	let valEds=[];
	let dlgVO=null;
	/*}#1GAA1RLHQ7LocalVals*/
	
	/*#{1GAA1RLHQ7PreState*/
	/*}#1GAA1RLHQ7PreState*/
	/*#{1GAA1RLHQ7PostState*/
	/*}#1GAA1RLHQ7PostState*/
	cssVO={
		"hash":"1GAA1RLHQ7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":300,"h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1GURGMI4C0",
				"type":"hud","id":"HudStdEdit","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1GURGQP9T0",
						"type":"text","id":"TxtLead","position":"relative","x":0,"y":0,"w":"","h":30,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":"=","fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1GAA27TBA0",
						"type":"edit","id":"EdText","position":"relative","x":0,"y":15,"w":"20%","h":20,"anchorY":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","placeHolder":(($ln==="CN")?("属性值"):("Attribute value")),"color":cfgColor["fontBody"],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
						"flex":true,
						/*#{1GAA27TBA0Codes*/
						OnUpdate:function(event){
							if(isShowTip && curTipIdx>=0){
								self.applyTip();
							}else{
								self.updateAttr();
								self.close(true);
							}
						},
						OnCancel:function(){
							/*#{1FUCJPEB92Code*/
							self.cancelEdit();
							/*}#1FUCJPEB92Code*/
						},
						OnNextEdit:function(){
							if(isShowTip && curTipIdx>=0){
								self.applyTip();
							}else{
								if(attrListBox.editNextAttr){
									self.updateAttr();
									self.close(true);
									callAfter(()=>{
										attrListBox.editNextAttr(attrObj,attrLine);
									});
								}
							}
							return true;
						},
						OnPreviousEdit:function(){
							if(isShowTip && curTipIdx>=0){
								self.applyTip();
							}else{
								if(attrListBox.editPreviousAttr){
									self.updateAttr();
									self.close(true);
									callAfter(()=>{
										attrListBox.editPreviousAttr(attrObj,attrLine);
									});
								}
							}
							return true;
						},
						OnInput:function(){
							self.OnInput();
						},
						OnPressKeyUp:function(){
							self.preTip();
							return true;
						},
						OnPressKeyDown:function(){
							self.nextTip();
							return true;
						},
						/*}#1GAA27TBA0Codes*/
					},
					{
						"hash":"1GCLFBL1M0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":5,"display":0,"image":appCfg.sharedAssets+"/btncombo.svg",
						"padding":0,
						/*#{1GCLFBL1M0Codes*/
						OnClick(){
							self.showMenu();
						}
						/*}#1GCLFBL1M0Codes*/
					},
					{
						"hash":"1GV3AL0UL0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/hudmemo.svg",null),"id":"BtnEditMemo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,0,0,2],
						"padding":0,
						"tip":(($ln==="CN")?("编辑长文本"):("Edit long text")),
						"OnClick":function(event){
							/*#{1GV3I1K640FunctionBody*/
							self.editMemo();
							/*}#1GV3I1K640FunctionBody*/
						},
					},
					{
						"hash":"1GV3B0BL20",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/check.svg",null),"id":"BtnEditDone","position":"relative","x":0,"y":"50%","anchorY":1,"padding":0,
						"OnClick":function(event){
							/*#{1GV3B1IIT0FunctionBody*/
							self.updateAttr();
							self.close(true);
							/*}#1GV3B1IIT0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1GBVO52HD0",
				"type":"hud","id":"BoxEdges","x":0,"y":30,"w":"FW","h":80,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GBVOAUBA0",
						"type":"edit","id":"EdVal1","x":"(FW-50)/2","y":5,"w":50,"h":20,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
						"fontSize":txtSize.smallMid,"outline":0,"border":1,
						/*#{1GBVOAUBA0Codes*/
						OnUpdate:function(){
							self.updateSubVals(0);
						},
						OnCancel:function(){
							self.cancelEdit();
						},
						OnNextEdit:function(){
							valEds[1].focus();
							return true;
						},
						OnPreviousEdit:function(){
							valEds[3].focus();
							return true;
						},
						OnInput:function(){
							self.OnSubInput();
						},
						/*}#1GBVOAUBA0Codes*/
					},
					{
						"hash":"1GBVODT9C0",
						"type":"edit","id":"EdVal2","x":"FW/2+20","y":"FH/2-10","w":50,"h":20,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontBody,"fontSize":txtSize.smallMid,"outline":0,"border":1,
						/*#{1GBVODT9C0Codes*/
						OnUpdate:function(){
							self.updateSubVals(1);
						},
						OnCancel:function(){
							self.cancelEdit();
						},
						OnNextEdit:function(){
							valEds[2].focus();
							return true;
						},
						OnPreviousEdit:function(){
							valEds[0].focus();
							return true;
						},
						OnInput:function(){
							self.OnSubInput();
						},
						/*}#1GBVODT9C0Codes*/
					},
					{
						"hash":"1GBVOFSK40",
						"type":"edit","id":"EdVal3","x":"(FW-50)/2","y":"FH-25","w":50,"h":20,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontBody,"fontSize":txtSize.smallMid,"outline":0,"border":1,
						/*#{1GBVOFSK40Codes*/
						OnUpdate:function(){
							self.updateSubVals(2);
						},
						OnCancel:function(){
							self.cancelEdit();
						},
						OnNextEdit:function(){
							valEds[3].focus();
							return true;
						},
						OnPreviousEdit:function(){
							valEds[2].focus();
							return true;
						},
						OnInput:function(){
							self.OnSubInput();
						},
						/*}#1GBVOFSK40Codes*/
					},
					{
						"hash":"1GBVOF3Q40",
						"type":"edit","id":"EdVal4","x":"FW/2-70","y":"FH/2-10","w":50,"h":20,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontBody,"fontSize":txtSize.smallMid,"outline":0,"border":1,
						/*#{1GBVOF3Q40Codes*/
						OnUpdate:function(){
							self.updateSubVals(3);
						},
						OnCancel:function(){
							self.cancelEdit();
							edText.focus();
						},
						OnNextEdit:function(){
							valEds[0].focus();
							return true;
						},
						OnPreviousEdit:function(){
							valEds[2].focus();
							return true;
						},
						OnInput:function(){
							self.OnSubInput();
						},
						/*}#1GBVOF3Q40Codes*/
					},
					{
						"hash":"1GBVOU4US0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/unlock.svg",null),"id":"BtnLock","x":"FW/2","y":"FH/2","anchorX":1,"anchorY":1,"autoLayout":true,
						"image":appCfg.sharedAssets+"/unlock.svg","padding":1,
						/*#{1GBVOU4US0Codes*/
						OnClick(){
							self.OnSyncClick();
						}
						/*}#1GBVOU4US0Codes*/
					},
					{
						"hash":"1GC0HMSCV0",
						"type":BoxSteps(20),"id":"BtnValStep1","x":"FW/2-45","y":5,"autoLayout":true,
						/*#{1GC0HMSCV0Codes*/
						OnStep(dir){
							self.stepSubVal(0,dir);
						}
						/*}#1GC0HMSCV0Codes*/
					},
					{
						"hash":"1GC0HP61S0",
						"type":BoxSteps(20),"id":"BtnValStep2","x":"FW/2+70","y":"FH/2-10","autoLayout":true,
						/*#{1GC0HP61S0Codes*/
						OnStep(dir){
							self.stepSubVal(1,dir);
						}
						/*}#1GC0HP61S0Codes*/
					},
					{
						"hash":"1GC0HQOMN0",
						"type":BoxSteps(20),"id":"BtnValStep3","x":"FW/2+25","y":"FH-25","autoLayout":true,
						/*#{1GC0HQOMN0Codes*/
						OnStep(dir){
							self.stepSubVal(2,dir);
						}
						/*}#1GC0HQOMN0Codes*/
					},
					{
						"hash":"1GC0HS4050",
						"type":BoxSteps(20),"id":"BtnValStep4","x":"FW/2-90","y":"FH/2-10","autoLayout":true,
						/*#{1GC0HS4050Codes*/
						OnStep(dir){
							self.stepSubVal(3,dir);
						}
						/*}#1GC0HS4050Codes*/
					}
				],
			},
			{
				"hash":"1GCL43E780",
				"type":"hud","id":"BoxRange","x":0,"y":30,"w":"FW","h":50,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GCL45JUJ0",
						"type":BoxRange(50,0,100),"id":"BoxRange","x":40,"y":20,"w":"FW-80","autoLayout":true,"h":20,"buttonSize":20,
						/*#{1GCL45JUJ0Codes*/
						OnChange(value,valText){
							self.OnRangeValueChange(value,valText);
						}
						/*}#1GCL45JUJ0Codes*/
					},
					{
						"hash":"1GCL49Q330",
						"type":"text","id":"TxtRangeMin","x":30,"y":0,"w":50,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
						"text":"0","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":2,
					},
					{
						"hash":"1GCL4DGHI0",
						"type":"text","id":"TxtRangeMax","x":"FW-30","y":0,"w":50,"h":20,"anchorX":2,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontBodySub,"text":"100","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":2,
					},
					{
						"hash":"1GCL4HKMQ0",
						"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/dec.svg",null),"x":10,"y":30,"anchorY":1,"image":appCfg.sharedAssets+"/dec.svg","padding":1,
						/*#{1GCL4HKMQ0Codes*/
						OnClick(){
							self.BoxRange.stepValue(-1);
						}
						/*}#1GCL4HKMQ0Codes*/
					},
					{
						"hash":"1GCL4L0TN0",
						"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/inc.svg",null),"x":"FW-35","y":30,"anchorY":1,"autoLayout":true,"image":appCfg.sharedAssets+"/inc.svg",
						"padding":1,
						/*#{1GCL4L0TN0Codes*/
						OnClick(){
							self.BoxRange.stepValue(1);
						}
						/*}#1GCL4L0TN0Codes*/
					}
				],
			},
			{
				"hash":"1GCLFA2S70",
				"type":"hud","id":"BoxColor","x":0,"y":30,"w":"FW","h":160,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GCLJ0IEQ0",
						"type":"image","x":80,"y":0,"w":50,"h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":appCfg.sharedAssets+"/checker.svg","fitSize":true,
						"repeat":false,
					},
					{
						"hash":"1GCLJ3R0A0",
						"type":"box","id":"BoxColorVal","x":80,"y":0,"w":50,"h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"border":1,
					},
					{
						"hash":"1GCLJAA9M0",
						"type":"text","x":0,"y":55,"w":50,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":"Red:","fontSize":txtSize.smallMid,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1GCLJ8EB20",
						"type":BoxRange(55,0,255),"id":"RngRed","x":55,"y":55,"w":80,"min":0,"value":50,"max":255,"step":1,"digit":0,"h":20,"buttonSize":18,"barSize":7,
						/*#{1GCLJ8EB20Codes*/
						OnChange(){
							self.OnColorRangeChange();
						}
						/*}#1GCLJ8EB20Codes*/
					},
					{
						"hash":"1GCLJDMLJ0",
						"type":"edit","id":"EdRed","x":140,"y":55,"w":45,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":"0~255","color":cfgColor.fontBody,
						"fontSize":txtSize.small,"outline":0,"border":1,
						/*#{1GCLJDMLJ0Codes*/
						OnUpdate:function(){
							self.OnColorEditUpdate();
						},
						OnBlur:function(){
							self.OnColorEditUpdate();
						},
						OnCancel:function(){
							self.cancelEdit();
							edText.focus();
						},
						OnNextEdit:function(){
							self.EdGreen.focus();
							return true;
						},
						OnPreviousEdit:function(){
							if(mode==="colorRGB"){
								self.EdBlue.focus();
							}else{
								self.EdAlpha.focus();
							}
							return true;
						},
						OnInput:function(){
						},
						/*}#1GCLJDMLJ0Codes*/
					},
					{
						"hash":"1GCLJNA5V0",
						"type":BoxSteps(20),"id":"BtnRed","x":185,"y":55,
						/*#{1GCLJNA5V0Codes*/
						OnStep(dir){
							self.RngRed.stepValue(dir);
						}
						/*}#1GCLJNA5V0Codes*/
					},
					{
						"hash":"1GCLJJILP0",
						"type":"text","x":0,"y":80,"w":50,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":"Green:","fontSize":txtSize.smallMid,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1GCLJK6B50",
						"type":BoxRange(55,0,255),"id":"RngGreen","x":55,"y":80,"w":80,"min":0,"max":255,"value":50,"step":1,"digit":0,"h":20,"buttonSize":18,"barSize":7,
						/*#{1GCLJK6B50Codes*/
						OnChange(){
							self.OnColorRangeChange();
						}
						/*}#1GCLJK6B50Codes*/
					},
					{
						"hash":"1GCLJLARR0",
						"type":"edit","id":"EdGreen","x":140,"y":80,"w":45,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":"0~255","color":cfgColor.fontBody,
						"fontSize":txtSize.small,"outline":0,"border":1,
						/*#{1GCLJLARR0Codes*/
						OnUpdate:function(){
							self.OnColorEditUpdate();
						},
						OnBlur:function(){
							self.OnColorEditUpdate();
						},
						OnCancel:function(){
							self.cancelEdit();
							edText.focus();
						},
						OnNextEdit:function(){
							self.EdBlue.focus();
							return true;
						},
						OnPreviousEdit:function(){
							self.EdRed.focus();
							return true;
						},
						OnInput:function(){
						},
						/*}#1GCLJLARR0Codes*/
					},
					{
						"hash":"1GCLJOM630",
						"type":BoxSteps(20),"id":"BtnGreen","x":185,"y":80,
						/*#{1GCLJOM630Codes*/
						OnStep(dir){
							self.RngGreen.stepValue(dir);
						}
						/*}#1GCLJOM630Codes*/
					},
					{
						"hash":"1GCLJPLNC0",
						"type":"text","x":0,"y":105,"w":50,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":"Blue:","fontSize":txtSize.smallMid,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1GCLJQCS10",
						"type":BoxRange(55,0,255),"id":"RngBlue","x":55,"y":105,"w":80,"min":0,"max":255,"value":50,"step":1,"digit":0,"h":20,"buttonSize":18,"barSize":7,
						/*#{1GCLJQCS10Codes*/
						OnChange(){
							self.OnColorRangeChange();
						}
						/*}#1GCLJQCS10Codes*/
					},
					{
						"hash":"1GCLJR9G30",
						"type":"edit","id":"EdBlue","x":140,"y":105,"w":45,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":"0~255","color":cfgColor.fontBody,
						"fontSize":txtSize.small,"outline":0,"border":1,
						/*#{1GCLJR9G30Codes*/
						OnUpdate:function(){
							self.OnColorEditUpdate();
						},
						OnBlur:function(){
							self.OnColorEditUpdate();
						},
						OnCancel:function(){
							self.cancelEdit();
							edText.focus();
						},
						OnNextEdit:function(){
							if(mode==="colorRGB"){
								self.EdRed.focus();
							}else{
								self.EdAlpha.focus();
							}
							return true;
						},
						OnPreviousEdit:function(){
							self.EdGreen.focus();
							return true;
						},
						OnInput:function(){
						},
						/*}#1GCLJR9G30Codes*/
					},
					{
						"hash":"1GCLJRQ0U0",
						"type":BoxSteps(20),"id":"BtnBlue","x":185,"y":105,
						/*#{1GCLJRQ0U0Codes*/
						OnStep(dir){
							self.RngBlue.stepValue(dir);
						}
						/*}#1GCLJRQ0U0Codes*/
					},
					{
						"hash":"1GCLJSLRJ0",
						"type":"text","x":0,"y":130,"w":50,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":"Alpha:","fontSize":txtSize.smallMid,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1GCLJT2350",
						"type":BoxRange(55,0,255),"id":"RngAlpha","x":55,"y":130,"w":80,"min":0,"max":1,"value":1,"step":0.05,"digit":2,"h":20,"buttonSize":18,"barSize":7,
						/*#{1GCLJT2350Codes*/
						OnChange(){
							self.OnColorRangeChange();
						}
						/*}#1GCLJT2350Codes*/
					},
					{
						"hash":"1GCLJTFEE0",
						"type":"edit","id":"EdAlpha","x":140,"y":130,"w":45,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":"0~1.0","color":cfgColor.fontBody,
						"fontSize":txtSize.small,"outline":0,"border":1,
						/*#{1GCLJTFEE0Codes*/
						OnUpdate:function(){
							self.OnColorEditUpdate();
						},
						OnBlur:function(){
							self.OnColorEditUpdate();
						},
						OnCancel:function(){
							self.cancelEdit();
							edText.focus();
						},
						OnNextEdit:function(){
							self.EdRed.focus();
							return true;
						},
						OnPreviousEdit:function(){
							self.EdBlue.focus();
							return true;
						},
						OnInput:function(){
						},
						/*}#1GCLJTFEE0Codes*/
					},
					{
						"hash":"1GCLJU5110",
						"type":BoxSteps(20),"id":"BtnAlpha","x":185,"y":130,
						/*#{1GCLJU5110Codes*/
						OnStep(dir){
							self.RngAlpha.stepValue(dir);
						}
						/*}#1GCLJU5110Codes*/
					}
				],
			},
			{
				"hash":"1GAA7NVSA0",
				"type":"box","id":"ListBox","x":20,"y":25,"w":100,"h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":1,"borderColor":cfgColor.lineBody,"shadow":true,"shadowX":1,"shadowY":3,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
			},
			{
				"hash":"1GURH1UII0",
				"type":"hud","id":"HudLocs","position":"relative","x":0,"y":0,"w":"100%","h":100,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1GAA1RLHQ7ExtraCSS*/
		/*}#1GAA1RLHQ7ExtraCSS*/
		faces:{
			"modeStd":{
				"#self":{
					"h":30
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":0
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":0
				}
			},"modeLocs":{
				"#self":{
					"h":""
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":0
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":0
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":0
				}
			},"modeEdges":{
				"#self":{
					"h":110
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":1
				},
				/*EdVal1*/"#1GBVOAUBA0":{
					"x":"(FW-50)/2","y":5
				},
				/*EdVal2*/"#1GBVODT9C0":{
					"x":"FW/2+20","y":"FH/2-10"
				},
				/*EdVal3*/"#1GBVOFSK40":{
					"x":"(FW-50)/2","y":"FH-25"
				},
				/*EdVal4*/"#1GBVOF3Q40":{
					"x":"FW/2-70","y":"FH/2-10"
				},
				/*BtnValStep1*/"#1GC0HMSCV0":{
					"x":"FW/2-45","y":5
				},
				/*BtnValStep2*/"#1GC0HP61S0":{
					"y":"FH/2-10","x":"FW/2+70"
				},
				/*BtnValStep3*/"#1GC0HQOMN0":{
					"x":"FW/2+25","y":"FH-25"
				},
				/*BtnValStep4*/"#1GC0HS4050":{
					"x":"FW/2-90","y":"FH/2-10"
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":0
				},
				/*#{1GBVO4N1K0Code*/
				$(){
					//TODO: set lock state:
				}
				/*}#1GBVO4N1K0Code*/
			},"modeCorners":{
				"#self":{
					"h":110
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":1
				},
				/*EdVal1*/"#1GBVOAUBA0":{
					"x":"FW/2-60"
				},
				/*EdVal2*/"#1GBVODT9C0":{
					"x":"FW/2+10","y":5
				},
				/*EdVal3*/"#1GBVOFSK40":{
					"y":"FH-25","x":"FW/2+10"
				},
				/*EdVal4*/"#1GBVOF3Q40":{
					"y":"FH-25","x":"FW/2-60"
				},
				/*BtnValStep1*/"#1GC0HMSCV0":{
					"x":"FW/2-80"
				},
				/*BtnValStep2*/"#1GC0HP61S0":{
					"y":5,"x":"FW/2+60"
				},
				/*BtnValStep3*/"#1GC0HQOMN0":{
					"x":"FW/2+60","y":"FH-25"
				},
				/*BtnValStep4*/"#1GC0HS4050":{
					"x":"FW/2-80","y":"FH-25"
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":0
				},
				/*#{1GBVO8CFB0Code*/
				/*}#1GBVO8CFB0Code*/
			},"modeRange":{
				"#self":{
					"h":80
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":0
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":1
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":0
				}
			},"modeColorRGB":{
				"#self":{
					"h":190
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":0
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":1
				},
				"#1GCLJSLRJ0":{
					"alpha":0.35
				},
				/*RngAlpha*/"#1GCLJT2350":{
					"alpha":0.35,"uiEvent":-1
				},
				/*EdAlpha*/"#1GCLJTFEE0":{
					"alpha":0.35,"uiEvent":-1
				},
				/*BtnAlpha*/"#1GCLJU5110":{
					"uiEvent":-1,"alpha":0.25
				}
			},"modeColorRGBA":{
				"#self":{
					"h":190
				},
				/*HudStdEdit*/"#1GURGMI4C0":{
					"display":1
				},
				/*BoxEdges*/"#1GBVO52HD0":{
					"display":0
				},
				/*BoxRange*/"#1GCL43E780":{
					"display":0
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"display":1
				},
				"#1GCLJSLRJ0":{
					"uiEvent":1,"alpha":1
				},
				/*RngAlpha*/"#1GCLJT2350":{
					"alpha":1,"uiEvent":1
				},
				/*EdAlpha*/"#1GCLJTFEE0":{
					"alpha":1,"uiEvent":1
				},
				/*BtnAlpha*/"#1GCLJU5110":{
					"alpha":1,"uiEvent":1
				}
			},"valueAttr":{
				/*BoxEdges*/"#1GBVO52HD0":{
					"uiEvent":1,"alpha":1
				},
				/*BoxRange*/"#1GCL43E780":{
					"alpha":1,"uiEvent":1
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"alpha":1,"uiEvent":1
				}
			},"hyperAttr":{
				/*BoxEdges*/"#1GBVO52HD0":{
					"uiEvent":-1,"alpha":0.35
				},
				/*BoxRange*/"#1GCL43E780":{
					"uiEvent":-1,"alpha":0.35
				},
				/*BoxColor*/"#1GCLFA2S70":{
					"alpha":0.35,"uiEvent":-1
				}
			},"syncOn":{
				/*BtnLock*/"#1GBVOU4US0":{
					"image":"/jaxweb/assets/lock.svg"
				}
			},"syncOff":{
				/*BtnLock*/"#1GBVOU4US0":{
					"image":"/jaxweb/assets/unlock.svg"
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtRangeMin=self.TxtRangeMin;txtRangeMax=self.TxtRangeMax;
			/*#{1GAA1RLHQ7Create*/
			edText=self.EdText;
			txtLead=self.TxtLead;
			listBox=self.ListBox;
			valEds[0]=self.EdVal1;
			valEds[1]=self.EdVal2;
			valEds[2]=self.EdVal3;
			valEds[3]=self.EdVal4;
			/*}#1GAA1RLHQ7Create*/
		},
		/*#{1GAA1RLHQ7EndCSS*/
		/*}#1GAA1RLHQ7EndCSS*/
	};
	/*#{1GAA1RLHQ7PostCSSVO*/
	//------------------------------------------------------------------------
	let itemCSS=function(item){
		return{
			type:"btn",x:0,y:0,w:"FW",h:20,autoLayout:1,position:"relative",item:item,
			children:[
				{type:"box",hash:"101",x:0,y:0,w:"FW",h:"FH",background:[255,255,255,1],uiEvent:-1,autoLayout:1,},
				{type:"text",hash:"102",x:5,y:0,w:"FW-10",h:"FH",text:item.text,color:[0,0,0],fontSize:appCfg.txtSize.smallMid,alignV:1,uiEvent:-1,autoLayout:1,}
			],
			faces:{
				"focus":{
					"#101":{
						background:cfgColor.hot
					}
				},
				"blur":{
					"#101":{
						background:cfgColor.body
					}
				}
			},
			OnButtonDown:function(){
				self.applyTip(item);
				return 1;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let rect,x,w,leadW;
		dlgVO=vo;
		attrListBox=vo.box||null;
		attrLine=vo.line;
		attrObj=attrLine.attrObj;
		mode=vo.mode||attrObj.def.editMode||"edit";
		
		//Place dialog:
		rect=attrLine.getBoundingClientRect();
		self.x=rect.x;
		self.y=rect.y+rect.height;
		self.w=rect.width;
		
		self.showFace("valueAttr");
		
		txtLead.fontSize=txtSize.smallMid;
		switch(mode){
			case "edit":
				txtLead.text="=";
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeStd");
				break;
			case "rename":
				txtLead.text="Rename: ";
				txtLead.fontSize=txtSize.small;
				edText.text=orgAttrText=attrObj.name;
				self.showFace("modeStd");
				break;
			case "edges":
				txtLead.text="=";
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeEdges");
				break;
			case "corners":
				txtLead.text="=";
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeCorners");
				break;
			case "range":
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeRange");
				break;
			case "colorRGB":
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeColorRGB");
				break;
			case "colorRGBA":
				edText.text=orgAttrText=attrObj.valText;
				self.showFace("modeColorRGBA");
				break;
		}
		self.updateEdit();
		
		//Adjust edText/listBox's pos and width:
		leadW=txtLead.textW;
		if(!vo.choice){
			self.BtnMenu.display=0;
		}else{
			self.BtnMenu.display=1;
		}
		listBox.x=edText.x;
		listBox.w=edText.w;
		listBox.display=0;
		
		attrLine.showFace("editOn",{dlgH:self.h});
	
		attrChanged=false;
		edText.blur();
		setTimeout(()=>{
			edText.focus();
		},0);
		self.showTips(null);
	};
	
	//------------------------------------------------------------------------
	cssVO.updateEdit=function(){
		switch(mode){
			case "edit":
				break;
			case "rename":
				break;
			case "edges":
				self.updateSubValEdits();
				break;
			case "corners":
				self.updateSubValEdits();
				break;
			case "range":
				self.updateRangeEdit();
				break;
			case "colorRGB":
			case "colorRGBA":
				self.updateColorEdit();
				break;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=function(){
		switch(mode){
			case "colorRGB":
			case "colorRGBA":{
				let items,prj,item,ownerObj,doc;
				ownerObj=attrObj.owner;
				doc=ownerObj.doc;
				prj=doc.prj;
				items=[];
				if(prj && doc!==prj.docConfig){
					let attr,colors;
					colors=prj.objConfig.getAttr("color");
					if(colors){
						colors=colors.attrList;
						for(attr of colors){
							item={text:attr.name,name:attr.name};
							items.push(item);
							if(attr.def.type==="colorRGB"||attr.def.type==="colorRGBA"||Array.isArray(attr.val)){
								item.icon="";
								item.iconColor=attr.val;
							}
						}
						app.showDlg(DlgMenu,{
							hud:edText,maxLines:10,items:items,
							callback(item){
								let valText;
								if(!item){
									return;
								}
								valText=`#cfgColor["${item.name}"]`;
								ownerObj.setAttrByText(attrObj,valText);
								edText.text=valText;
								attrChanged=1;
								self.updateColorEdit();
								self.close(true);
							}
						});
					}
				}
				break;
			}
		};
	};
	
	//************************************************************************
	//Major edit:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.updateAttr=function(vo){
			let obj,text,prj,orgText;
			obj=attrObj.owner;
			prj=obj.prj;
			text=orgText=edText.text;
			if(mode==="rename"){
				if(text===attrObj.name){
					return;
				}
				attrListBox.renameAttr(attrObj,text);
			}else{
				if(text===attrObj.valText){
					return;
				}
				if(dlgVO.filterValText){
					text=dlgVO.filterValText(text);
					if(text!==orgText){
						edText.text=text;
					}
				}
				obj.setAttrByText(attrObj,text);
			}
			attrChanged=true;
		};
	
		//--------------------------------------------------------------------
		cssVO.cancelEdit=function(){
			let obj,text,prj;
			if(isShowTip){
				self.showTips(null);
				return;
			}
			obj=attrObj.owner;
			prj=obj.prj;
			text=edText.text;
			if(text===orgAttrText){
				self.close(false);
				return;
			}
			text=edText.text=orgAttrText;
			if(attrChanged){
				if(mode==="rename"){
					attrListBox.renameAttr(attrObj,orgAttrText);
				}else{
					obj.setAttrByText(attrObj,text);
				}
				attrChanged=0;
			}
			edText.focus();
			edText.selectAll();
			if(mode==="edges" ||mode==="corners"){
				self.updateSubValEdits();
			}else if(mode==="range"){
				self.updateRangeEdit();
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnInput=function(){
			let obj,text,code,pos,tipList,pos2;
			text=edText.text;
			pos=edText.selectionStart;
			pos2=edText.selectionEnd;
			if(pos2>pos){
				self.showTips(null);
				return;
			}
			if(mode==="rename"){
				return;
			}
			text=text.substring(0,pos);
			tipPos=text.length;
			code=null;
			if(text[0]==="#"){
				pos=text.indexOf("#>");
				if(pos>0){
					code=text.substring(1,pos);
				}else{
					code=text.substring(1);
				}
			}else if(text.startsWith("${")){
				pos=text.lastIndexOf("}");
				if(pos>0){
					code=text.substring(1,pos);
				}else{
					code=text.substring(1);
				}
			}
			if(code===null){
				return;
			}
			obj=attrObj.owner;
			tipList=obj.getScopeValTip(code);
			self.showTips(tipList);
		};
	}
	
	//************************************************************************
	//Edge/Corner Sub-Val-Edit
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnSyncClick=function(){
			syncVal=!syncVal;
			if(syncVal){
				self.updateSubVals(0);
				self.BtnLock.image=appCfg.sharedAssets+"/lock.svg";
			}else{
				self.updateSubVals(0);
				self.BtnLock.image=appCfg.sharedAssets+"/unlock.svg";
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.updateSubValEdits=function(){
			let attrText,attrVal;
			attrText=edText.text;
			attrVal=attrObj.val;
			if(attrText.startsWith("#")||attrText.startsWith("${")){
				self.showFace("hyperAttr");
			}else{
				self.showFace("valueAttr");
			}
			if(!Array.isArray(attrVal)){
				syncVal=1;
				attrVal=attrVal||0;
				attrVal=[attrVal,attrVal,attrVal,attrVal];
				self.BtnLock.image=appCfg.sharedAssets+"/lock.svg";
			}else{
				syncVal=0;
				self.BtnLock.image=appCfg.sharedAssets+"/unlock.svg";
			}
			valEds[0].text=""+attrVal[0];
			valEds[1].text=""+attrVal[1];
			valEds[2].text=""+attrVal[2];
			valEds[3].text=""+attrVal[3];
		};
		
		//--------------------------------------------------------------------
		cssVO.updateSubVals=function(idx){
			let ownerObj,val;
			let vals=[];
			ownerObj=attrObj.owner;
			if(syncVal){
				val=parseInt(valEds[idx].text)||0;
				vals[0]=vals[1]=vals[2]=vals[3]=val;
				valEds[0].text=""+vals[0];
				valEds[1].text=""+vals[1];
				valEds[2].text=""+vals[2];
				valEds[3].text=""+vals[3];
				val=JSON.stringify(val);
				ownerObj.setAttrByText(attrObj,val);
				edText.text=val;
			}else{
				vals[0]=parseInt(valEds[0].text)||0;valEds[0].text=""+vals[0];
				vals[1]=parseInt(valEds[1].text)||0;valEds[1].text=""+vals[1];
				vals[2]=parseInt(valEds[2].text)||0;valEds[2].text=""+vals[2];
				vals[3]=parseInt(valEds[3].text)||0;valEds[3].text=""+vals[3];
				val=JSON.stringify(vals);
				ownerObj.setAttrByText(attrObj,val);
				edText.text=val;
			}
			if(val!==orgAttrText){
				attrChanged=true;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSubInput=function(){
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		cssVO.stepSubVal=function(idx,dir){
			let val,vals=[];
			val=parseInt(valEds[idx].text)||0;
			val+=dir;
			if(syncVal){
				vals[0]=vals[1]=vals[2]=vals[3]=val;
				valEds[0].text=""+val;
				valEds[1].text=""+val;
				valEds[2].text=""+val;
				valEds[3].text=""+val;
			}else{
				valEds[idx].text=""+val;
			}
			self.updateSubVals(idx);
		};
		
	}
	
	//************************************************************************
	//Range-Edit
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.updateRangeEdit=function(){
			let attrText,attrDef,boxRange;
			let minVal,maxVal;
			attrText=edText.text;
			if(attrText.startsWith("#")||attrText.startsWith("${")){
				self.showFace("hyperAttr");
			}else{
				self.showFace("valueAttr");
			}
			attrDef=attrObj.def;
			{
				let func;
				func=attrObj.getMinVal||attrDef.getMinVal;
				minVal=func?func.call(attrObj):(attrDef.minVal||0);
				txtRangeMin.text=""+minVal;
				func=attrObj.getMaxVal||attrDef.getMaxVal;
				maxVal=func?func.call(attrObj):(attrDef.maxVal||100);
				txtRangeMax.text=""+maxVal;
			}
			
			boxRange=self.BoxRange;
			boxRange.min=minVal;
			boxRange.max=maxVal;
			boxRange.step=attrDef.step;
			boxRange.digit=attrDef.valFixDigit;
			boxRange.value=attrObj.val;
		};
		
		//--------------------------------------------------------------------
		cssVO.OnRangeValueChange=function(value,valText){
			let ownerObj;
			ownerObj=attrObj.owner;
			edText.text=valText;
			ownerObj.setAttrByText(attrObj,valText);
			attrChanged=1;
		};
	}
	
	//************************************************************************
	//Color-Edit:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.updateColorEdit=function(){
			let attrText,attrDef,boxRange,color,value;
			attrText=edText.text;
			value=attrObj.val;
			if(attrObj.hyper||(!Array.isArray(value))){
				self.showFace("hyperAttr");
				self.EdRed.text="";
				self.EdGreen.text="";
				self.EdBlue.text="";
				self.EdAlpha.text="";
				self.RngRed.value=0;
				self.RngGreen.value=0;
				self.RngBlue.value=0;
				self.RngAlpha.value=0;
			}else{
				self.showFace("valueAttr");
				self.RngRed.value=value[0]||0;
				self.RngGreen.value=value[1]||0;
				self.RngBlue.value=value[2]||0;
				self.EdRed.text=""+(value[0]||0);
				self.EdGreen.text=""+(value[1]||0);
				self.EdBlue.text=""+(value[2]||0);
				if(mode==="colorRGB"){
					self.RngAlpha.value=1;
					self.EdAlpha.text="1";
				}else{
					self.RngAlpha.value=value[3]||0;
					self.EdAlpha.text=""+(value[3]||0);
				}
			}
			self.BoxColorVal.background=attrObj.val;
		};
		
		//--------------------------------------------------------------------
		cssVO.OnColorRangeChange=function(){
			self.EdRed.text=self.RngRed.getValText();
			self.EdGreen.text=self.RngGreen.getValText();
			self.EdBlue.text=self.RngBlue.getValText();
			if(mode==="colorRGB"){
				self.EdAlpha.text="";
			}else{
				self.EdAlpha.text=self.RngAlpha.getValText();
			}
			self.OnColorEditUpdate();
		};
		
		//--------------------------------------------------------------------
		cssVO.OnColorEditUpdate=function(){
			let ownerObj,r,g,b,a,valText;
			r=parseInt(self.EdRed.text)||0;
			g=parseInt(self.EdGreen.text)||0;
			b=parseInt(self.EdBlue.text)||0;
			a=parseFloat(self.EdAlpha.text)||0;
			if(mode==="colorRGB"){
				valText=`[${r},${g},${b}]`;
			}else{
				valText=`[${r},${g},${b},${a}]`;
			}
			self.RngRed.value=r;
			self.RngGreen.value=g;
			self.RngBlue.value=b;
			if(mode==="colorRGB"){
				self.RngAlpha.value=1;
			}else{
				self.RngAlpha.value=a;
			}
			ownerObj=attrObj.owner;
			edText.text=valText;
			ownerObj.setAttrByText(attrObj,valText);
			self.BoxColorVal.background=attrObj.val;
			attrChanged=1;
		};
	}
	
	//************************************************************************
	//Long-text-edit
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.editMemo=function(){
			let text;
			let attrDef=attrObj.def;
			let attrName=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name)
			text=attrObj.valText;
			app.showDlg(DlgLongText,{
				text:text,hud:self,
				title:(($ln==="CN")?(`编辑：${attrName}`):/*EN*/(`Edit: ${attrName}`)),
				next(apply,text){
					if(apply){
						attrChanged=true;
						edText.text=text;
						self.close(true,text);
					}
				}
			});
		};
	}
	
	//************************************************************************
	//Tips:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.showTips=function(tips){
			let i,n,item,css;
			if(!tips || !tips.length ||tips.length<2){
				curTipIdx=0;
				listBox.clearChildren();
				listBox.display=0;
				tipItems.splice(0);
				isShowTip=0;
				return;
			}
			isShowTip=1;
			listBox.clearChildren();
			tipItems.splice(0);
			listBox.display=1;
			tipLead=tips.pop();
			n=tips.length;
			for(i=0;i<n;i++){
				tipItems.push(listBox.appendNewChild(itemCSS({text:tips[i]})));
			}
			curTipIdx=-1;
		};
	
		//--------------------------------------------------------------------
		cssVO.applyTip=function(item){
			let exText,text,tipText,pos;
			if(!item){
				if(!(curTipIdx>=0)){
					return;
				}
				item=tipItems[curTipIdx].item;
			}
			tipText=item.text;
			text=edText.text;
			if(tipPos>=0){
				exText=text.substring(tipPos);
				text=text.substring(0,tipPos);
			}else{
				exText="";
			}
			if(tipLead){
				text=text.substring(0,text.length-tipLead.length);
			}
			text+=tipText;
			pos=text.length;
			text+=exText;
			edText.text=text;
			edText.setSelectionRange(pos);
			self.showTips(null);
		};
	
		//--------------------------------------------------------------------
		cssVO.nextTip=function(){
			let line;
			if(!isShowTip)
				return;
			line=tipItems[curTipIdx];
			if(line){
				line.showFace("blur");
			}
			curTipIdx++;
			line=tipItems[curTipIdx];
			if(!line){
				curTipIdx=0;
				line=tipItems[curTipIdx];
			}
			if(line){
				line.showFace("focus");
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.preTip=function(){
			let line;
			if(!isShowTip)
				return;
			line=tipItems[curTipIdx];
			if(line){
				line.showFace("blur");
			}
			curTipIdx--;
			line=tipItems[curTipIdx];
			if(!line){
				curTipIdx=tipItems.length-1;
				line=tipItems[curTipIdx];
			}
			if(line){
				line.showFace("focus");
			}
		};
	}
	
	//------------------------------------------------------------------------
	cssVO.OnBGClick=function(){
		self.updateAttr();
		self.close(true);
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(applyAttr,withText){
		let valText,owner;
		owner=attrObj.owner;
		if(mode!=="rename"){
			if(applyAttr && attrChanged){
				valText=withText||edText.text;
				if(valText!==orgAttrText){
					owner.setAttrByText(attrObj,orgAttrText);
					attrListBox.setAttrByText(attrObj,valText);
				}
			}else{
				owner.setAttrByText(attrObj,orgAttrText);
			}
		}
		attrLine.showFace("editOff");
		app.closeDlg(self);
	};
	/*}#1GAA1RLHQ7PostCSSVO*/
	cssVO.constructor=DlgRawEditAttr;
	return cssVO;
};
/*#{1GAA1RLHQ7ExCodes*/
/*}#1GAA1RLHQ7ExCodes*/

//----------------------------------------------------------------------------
DlgRawEditAttr.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GAA1RLHQ7PreAISpot*/
	/*}#1GAA1RLHQ7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GAA1RLHQ7PostAISpot*/
	/*}#1GAA1RLHQ7PostAISpot*/
	return exposeVO;
};

/*#{1GAA1RLHQ0EndDoc*/
/*}#1GAA1RLHQ0EndDoc*/

export default DlgRawEditAttr;
export{DlgRawEditAttr};
