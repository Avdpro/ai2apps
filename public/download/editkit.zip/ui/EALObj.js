//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {EditAttrObjBtn} from "./EditAttrObjBtn.js";
/*#{1GA8IFI6J0StartDoc*/
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EALEmptyAttr} from "./EALEmptyAttr.js";
import {EALGroup} from "./EALGroup.js";
/*}#1GA8IFI6J0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALObj=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA8IFI6J7LocalVals*/
	let inited=0;
	let boxAttrs=null;
	let btnObj=null;
	let isOpen=0;
	let attrEditState=attrObj.editAttrState;
	/*}#1GA8IFI6J7LocalVals*/
	
	/*#{1GA8IFI6J7PreState*/
	/*}#1GA8IFI6J7PreState*/
	/*#{1GA8IFI6J7PostState*/
	/*}#1GA8IFI6J7PostState*/
	cssVO={
		"hash":"1GA8IFI6J7",nameHost:true,
		"type":"box","position":"relative","x":2,"y":0,"w":">calc(100% - 2px)","h":"","autoLayout":true,"margin":[3,0,8,0],"minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBody,"corner":3,"shadow":true,"shadowX":0,"shadowBlur":2,"shadowColor":[0,0,0,0.3],
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1GA8JTFL60",
				"type":EditAttrObjBtn(app,attrObj,box),"id":"BtnObj","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1GA8LRR530",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			},
			{
				"hash":"1GA8LITMR0",
				"type":"hud","id":"BoxAttrs","position":"relative","x":20,"y":0,"w":">calc(100% - 20px)","h":"","autoLayout":true,"display":0,"padding":[0,0,5,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1GA8IFI6J7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerLine,
		/*}#1GA8IFI6J7ExtraCSS*/
		faces:{
			"open":{
				"#1GA8LRR530":{
					"display":1
				},
				/*BoxAttrs*/"#1GA8LITMR0":{
					"display":1
				},
				/*#{1GA8LNEDR0Code*/
				"BtnObj":{"face":"open"},
				$(){
					isOpen=1;
					attrEditState.open=1;
				}
				/*}#1GA8LNEDR0Code*/
			},"close":{
				"#1GA8LRR530":{
					"display":0
				},
				/*BoxAttrs*/"#1GA8LITMR0":{
					"display":0
				},
				/*#{1GA8LNHNF0Code*/
				"BtnObj":{"face":"close"},
				$(){
					isOpen=0;
					attrEditState.open=0;
				}
				/*}#1GA8LNHNF0Code*/
			},"editOn":{
				/*#{1GBV0BEDO0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.padding=[0,0,vo.dlgH,0];
					}
				}
				/*}#1GBV0BEDO0Code*/
			},"editOff":{
				/*#{1GBV0HHAF0Code*/
				$(){
					self.padding=[0,0,0,0];
				}
				/*}#1GBV0HHAF0Code*/
			},"showEdit":{
				/*#{1GDV4F7K70Code*/
				$(){
					btnObj.showFace("showEdit");
				}
				/*}#1GDV4F7K70Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA8IFI6J7Create*/
			let attrDef,objDef;
			attrDef=attrObj.def;
			objDef=attrObj.objDef;
			box.regAttrLine(attrObj,self);
			btnObj=self.BtnObj;
			boxAttrs=self.BoxAttrs;
			attrObj.on("AttrAdd",self.OnAttrAdd);
			attrObj.on("AttrRemove",self.OnAttrRemove);
			attrObj.on("AttrMoveUp",self.OnAttrMoveUp);
			attrObj.on("AttrMoveDown",self.OnAttrMoveDown);
			attrObj.on("AttrReplace",self.OnAttrReplace);
			if(attrDef.autoOpen||objDef.autoOpen||attrEditState.open){
				self.open();
			}
			if(objDef.OnAttrEdit){
				objDef.OnAttrEdit.call(attrObj,box,null);
			}
			/*}#1GA8IFI6J7Create*/
		},
		/*#{1GA8IFI6J7EndCSS*/
		OnFree(){
			box.unregAttrLine(attrObj,self);
			attrObj.off("AttrAdd",self.OnAttrAdd);
			attrObj.off("AttrRemove",self.OnAttrRemove);
			attrObj.off("AttrMoveUp",self.OnAttrMoveUp);
			attrObj.off("AttrMoveDown",self.OnAttrMoveDown);
			attrObj.off("AttrReplace",self.OnAttrReplace);
		},
		ownerLine:ownerLine,attrObj:attrObj,
		/*}#1GA8IFI6J7EndCSS*/
	};
	/*#{1GA8IFI6J7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.open=function(){
		let attrDef,objDef,list,item,itemType,cssFunc,attr;
		self.showFace("open");
		if(inited){
			return;
		}
		objDef=attrObj.objDef;
		list=attrObj.getEditSubPpts();
		for(item of list){
			if(item instanceof EditAttr){
				attr=item;
				attrDef=attr.def;
				cssFunc=null;
				if(attrDef.editType){
					cssFunc=box.getAttrTypeCSS(attrDef.editType);
					if(!cssFunc){
						console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
						cssFunc=box.getAttrTypeCSS(attrDef.type);
					}
				}else{
					cssFunc=box.getAttrTypeCSS(attrDef.type);
				}
				boxAttrs.appendNewChild(cssFunc(app,attr,box,self));
			}else{
				itemType=typeof(item);
				if(itemType==="string"){
					attr=attrObj.getAttr(item);
					if(attr){
						attrDef=attr.def;
						cssFunc=null;
						if(attrDef.editType){
							cssFunc=box.getAttrTypeCSS(attrDef.editType);
							if(!cssFunc){
								console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
								cssFunc=box.getAttrTypeCSS(attrDef.type);
							}
						}else{
							cssFunc=box.getAttrTypeCSS(attrDef.type);
						}
						boxAttrs.appendNewChild(cssFunc(app,attr,box,self));
					}else{
						attrDef=attrObj.getAttrDef(item);
						if(attrDef){
							boxAttrs.appendNewChild(EALEmptyAttr(app,attrObj,attrDef,box,self));
						}else{
							console.warn(`Sub-Edit-Attr "${item}" is missing.`);
						}
					}
				}else if(itemType==="object"){
					if(item.attrs){//This is a group:
						box.addEditGroup(boxAttrs,attrObj,item,item.open);
					}
				}
			}
		}
		inited=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		self.showFace("close");
	};
	
	//************************************************************************
	//EditObj changes trace functions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.findAttrLine=function(attr,listBox){
			let items,item,i,n;
			listBox=listBox||boxAttrs;
			items=listBox.children;
			n=items.length;
			for(i=0;i<n;i++){
				item=items[i];
				if(item.attrObj===attr){
					return item;
				}
				if(item.groupName){
					item=self.findAttrLine(attr,item.boxLines);
					if(item){
						return item;
					}
				}
			}
			return null;
		};
	
		//--------------------------------------------------------------------
		cssVO.findNullAttrLine=function(attrName,listBox){
			let items,item,i,n;
			listBox=listBox||boxAttrs;
			items=listBox.children;
			n=items.length;
			for(i=0;i<n;i++){
				item=items[i];
				if(item.nullAttrName===attrName){
					return item;
				}
				if(item.isGroup){
					item=self.findNullAttrLine(attrName,item.boxLines);
					if(item){
						return item;
					}
				}
			}
			return null;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnChanged=function(){
			//TODO: Code this:
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAttrAdd=function(attr){
			let replaceLine,cssFunc,line,attrDef,list;
			if(!inited){
				return;
			}
			attrDef=attr.def;
			replaceLine=self.findNullAttrLine(attr.name);
			if(replaceLine){
				if(attrDef.editType){
					cssFunc=box.getAttrTypeCSS(attrDef.editType);
					if(!cssFunc){
						console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
						cssFunc=box.getAttrTypeCSS(attrDef.type);
					}
				}else{
					cssFunc=box.getAttrTypeCSS(attrDef.type);
				}
				if(cssFunc){
					line=replaceLine.father.insertNewBefore(cssFunc(app,attr,box,self),replaceLine);
					if(line){
						replaceLine.father.removeChild(replaceLine);
					}
				}
			}else{
				list=attrObj.getEditSubPpts();
				if(!list ||(list.indexOf(attr)<0 && list.indexOf(attr.name)<0)){
					return;
				}
				if(attrDef.editType){
					cssFunc=box.getAttrTypeCSS(attrDef.editType);
					if(!cssFunc){
						console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
						cssFunc=box.getAttrTypeCSS(attrDef.type);
					}
				}else{
					cssFunc=box.getAttrTypeCSS(attr.def.type);
				}
				if(cssFunc){
					line=boxAttrs.appendNewChild(cssFunc(app,attr,box,self));
				}
			}
			if(line && (!app.getDlg()) && line.startEdit && (attr.editOnAdd!==false) && (attrDef.editOnAdd!==false)){
				line.startEdit();
				line.showFace("showEdit");
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAttrRemove=function(attr){
			let line,emptyLine;
			if(!inited){
				return;
			}
			line=self.findAttrLine(attr);
			if(line){
				if(attr.fixed || attr.def.fixed){
					let attrDef;
					attrDef=attrObj.getAttrDef(attr.name);
					if(attrDef){
						emptyLine=line.parent.insertNewBefore(EALEmptyAttr(app,attrObj,attrDef,box,self),line);
						emptyLine.showFace("showEdit");
					}
				}else{
					let list,attrDef;
					list=attrObj.getEditSubPpts();
					if(list && (list.indexOf(attr.name)>=0)){
						attrDef=attrObj.getAttrDef(attr.name);
						if(attrDef){
							emptyLine=line.parent.insertNewBefore(EALEmptyAttr(app,attrObj,attrDef,box,self),line);
							emptyLine.showFace("showEdit");
						}
					}
				}
				line.parent.removeChild(line);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAttrInsert=function(attr,idx){
			//TODO: Code this:
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAttrMoveUp=function(attr){
			let line,preLine;
			line=self.findAttrLine(attr);
			if(!line)
				return;
			preLine=line.previousSibling;
			boxAttrs.insertBefore(line,preLine);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAttrMoveDown=function(attr){
			let line,nxtLine;
			line=self.findAttrLine(attr);
			if(!line)
				return;
			nxtLine=line.nextSibling;
			boxAttrs.insertBefore(nxtLine,line);
		};
		
		//--------------------------------------------------------------------
		cssVO.OnAttrReplace=function(newAttr,oldAttr){
			let oldLine,nxtLine,cssFunc,line,attrDef;
			oldLine=self.findAttrLine(oldAttr);
			if(!oldLine)
				return;
			nxtLine=oldLine.nextSibling;
			attrDef=newAttr.def;
			if(attrDef.editType){
				cssFunc=box.getAttrTypeCSS(attrDef.editType);
				if(!cssFunc){
					console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
					cssFunc=box.getAttrTypeCSS(attrDef.type);
				}
			}else{
				cssFunc=box.getAttrTypeCSS(attrDef.type);
			}
			if(cssFunc){
				oldLine.parent.removeChild(oldLine);
				if(nxtLine){
					line=boxAttrs.insertNewBefore(cssFunc(app,newAttr,box,self),nxtLine);
				}else{
					line=boxAttrs.appendNewChild(cssFunc(app,newAttr,box,self));
				}
			}
			if(line && (!app.getDlg()) && line.startEdit){
				line.startEdit();
			}
		};
	}
	/*}#1GA8IFI6J7PostCSSVO*/
	return cssVO;
};
/*#{1GA8IFI6J7ExCodes*/
/*}#1GA8IFI6J7ExCodes*/


/*#{1GA8IFI6J0EndDoc*/
/*}#1GA8IFI6J0EndDoc*/

export default EALObj;
export{EALObj};
