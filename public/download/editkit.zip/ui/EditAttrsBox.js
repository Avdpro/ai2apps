//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GA9QOA2E0StartDoc*/
import {EditAttr} from "../EditAttr.js";
import {EditPrj} from "../EditPrj.js";
import {EALObj} from "./EALObj.js";
import {EALGroup} from "./EALGroup.js";
import {EALStdAttr} from "./EALStdAttr.js";
import {EALEmptyAttr} from "./EALEmptyAttr.js";
import {EALMetaMenu} from "./EALMetaMenu.js";
import {DlgNewAttr} from "./DlgNewAttr.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GA9QOA2E0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EditAttrsBox=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA9QOA2E7LocalVals*/
	let appPrj,dataDocs,editPrj,curEditObj,curDoc;
	let attrLines,ownerLines,lineList;
	let metaMenu=null;
	let editHideVsn=1;
	appPrj=app.prj;
	dataDocs=appPrj.docs;
	editPrj=appPrj.codyPrj;
	attrLines=new Map();
	lineList=[];
	curEditObj=null;
	curDoc=null;
	/*}#1GA9QOA2E7LocalVals*/
	
	/*#{1GA9QOA2E7PreState*/
	/*}#1GA9QOA2E7PreState*/
	/*#{1GA9QOA2E7PostState*/
	/*}#1GA9QOA2E7PostState*/
	cssVO={
		"hash":"1GA9QOA2E7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"overflow":"auto-y","padding":[0,2,200,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		/*#{1GA9QOA2E7ExtraCSS*/
		/*}#1GA9QOA2E7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA9QOA2E7Create*/
			metaMenu=this.appendNewChild(EALMetaMenu(app,self));
			metaMenu.hold();
			this.removeChild(metaMenu);
			self.metaMenu=metaMenu;
			editPrj.on("ShowEditAttr",(attr)=>{
				self.getAttrLine(attr,true,true,true);
			});
			/*}#1GA9QOA2E7Create*/
		},
		/*#{1GA9QOA2E7EndCSS*/
		/*}#1GA9QOA2E7EndCSS*/
	};
	/*#{1GA9QOA2E7PostCSSVO*/
	//************************************************************************
	//Attr contents:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.setEditObj=function(obj){
			let list,stub,attr,attrType,doc,objDef;
			if(obj===curEditObj){
				return;
			}
			self.clear();
			attrLines.clear();
			lineList.splice(0);
			curEditObj=obj;
			editHideVsn++;
			if(!obj){
				if(curDoc){
					curDoc.off("FaceOff",self.OnFaceOff);
				}
				curDoc=null;
				return;
			}
			doc=obj.doc;
			if(doc!==curDoc){
				if(curDoc){
					curDoc.off("FaceOff",self.OnFaceOff);
				}
				curDoc=doc;
				if(doc){
					curDoc.on("FaceOff",self.OnFaceOff);
				}
			}
			list=obj.getEditRootPpts();
			if(!list || !list.length){
				return;
			}
			for(stub of list){
				if(stub.obj){
					self.addRootEditObj(stub.obj,stub.open);
				}else if(stub.group){
					self.addEditGroup(self,obj,stub,stub.open);
				}else if(stub.attr){
					self.addRootEditAttr(stub.attr);
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.clear=function(){
			self.clearChildren();
		};
		
		//--------------------------------------------------------------------
		cssVO.OnFaceOff=function(){
			let obj;
			obj=curEditObj;
			self.setEditObj(null);
			self.setEditObj(obj);
		};
		
		//--------------------------------------------------------------------
		//Add a object line:
		cssVO.addRootEditObj=function(attrObj,open=true){
			let css,line;
			css=EALObj(app,attrObj,self,null);
			line=self.appendNewChild(css);
			if(open){
				line.open();
			}
		};
		
		//--------------------------------------------------------------------
		//Add a attr line:
		cssVO.addRootEditAttr=function(attr){
			let def=attr.def;
			let type=def.type;
			let cssFunc;
			let css,line;
			if(def.editType){
				cssFunc=EditAttrsBox.getAttrBox(def.editType);
				if(!cssFunc){
					console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
					cssFunc=EditAttrsBox.getAttrBox(type);
				}
			}else{
				cssFunc=EditAttrsBox.getAttrBox(type);
			}
			css=cssFunc(app,attr,self,null);
			line=self.appendNewChild(css);
			attr.canDelete=false;
		};
		
		//--------------------------------------------------------------------
		//Add a group line:
		cssVO.addEditGroup=function(ownerBox,attrObj,groupDef,open=true){
			let def,css,line,groupLine,groupAttrs,j,m,attr,attrHash,lineBox,attrDef;
			attrHash=attrObj.attrHash;
			css=EALGroup(app,groupDef,self,ownerBox);
			groupLine=ownerBox.appendNewChild(css);
			groupAttrs=groupDef.attrs;
			m=groupAttrs.length;
			lineBox=groupLine.boxLines;
			for(j=0;j<m;j++){
				attr=groupAttrs[j];
				if(typeof(attr)==="string"){
					attr=attrHash[attr];
				}
				if(attr){
					attrDef=attr.def;
					if(attrDef.editType){
						css=EditAttrsBox.getAttrBox(attrDef.editType);
						if(!css){
							console.warn(`Edit-Type's EAL-Def "${attrDef.editType}" is missing.`);
							css=EditAttrsBox.getAttrBox(attrDef.type);
						}
					}else{
						css=EditAttrsBox.getAttrBox(attrDef.type);
					}
					if(css){
						lineBox.appendNewChild(css(app,attr,self,groupLine));
					}
				}else{
					def=attrObj.getAttrDef(groupAttrs[j]);
					if(def){
						css=EALEmptyAttr(app,attrObj,def,self,groupLine);
						if(css){
							line=lineBox.appendNewChild(css);
						}
					}else{
						console.warn(`Attr "${groupAttrs[j]}" can't found.`);
					}
				}
			}
			groupLine.bindEditState(attrObj.editAttrState);
			//TODO: Check maybe open group?
			
		};
		
		cssVO.getAttrTypeCSS=function(attrType){
			return EditAttrsBox.getAttrBox(attrType);
		};
	}
	
	//************************************************************************
	//Edit dynamic behaviors:
	//************************************************************************
	{
		let curMetaMenuLine=null;
		//--------------------------------------------------------------------
		cssVO.showMetaMenu=function(lineBox){
			if(metaMenu.isBusy()){
				return;
			}
			if(self.allowMetaMenu===false){
				return;
			}
			if(curMetaMenuLine===lineBox){
				if(metaMenu.parent===lineBox){
					return;
				}
			}
			curMetaMenuLine=metaMenu.parent;
			if(curMetaMenuLine){
				curMetaMenuLine.removeChild(metaMenu);
				curMetaMenuLine=null;
			}
			lineBox.appendChild(metaMenu);
			metaMenu.dockInLine(lineBox);
			curMetaMenuLine=lineBox;
		};
	
		//--------------------------------------------------------------------
		cssVO.hideMetaMenu=function(lineBox){
			if(!lineBox){
				lineBox=metaMenu.parent;
				if(!lineBox){
					return;
				}
			}
			if(lineBox===curMetaMenuLine){
				if(metaMenu.father===curMetaMenuLine){
					lineBox.removeChild(metaMenu);
				}
				curMetaMenuLine=null;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.openObj=function(line){
			line.open();
		};
		
		//--------------------------------------------------------------------
		cssVO.closeObj=function(line){
			line.close();
		};
		
	}
	
	//************************************************************************
	//Edit attrs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.regAttrLine=function(attr,line){
			if(attrLines.get(attr)){
				let msg=`Attr ${attr.name} has already registered in EditBox`;
				console.error(msg);
				throw new Error(msg);
			}
			attrLines.set(attr,line);
			lineList.push(line);
			if(attr.editHideVsn===editHideVsn){
				line.display=false;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.editNextAttr=function(attr,line){
			while(line){
				line=line.nextSibling;
				if(line && line.startEdit){
					line.startEdit();
					return;
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.editPreviousAttr=function(attr,line){
			while(line){
				line=line.previousSibling;
				if(line && line.startEdit){
					line.startEdit();
					return;
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.unregAttrLine=function(attr,line){
			if(attrLines.get(attr)!==line){
				let msg=`Attr ${attr.name} has already registered in EditBox`;
				console.error(msg);
				throw new Error(msg);
			}
			attrLines.delete(attr);
		};
		
		//--------------------------------------------------------------------
		cssVO.getAttrLine=function(attr,open=false,show=false,showEdit=false){
			let line,ownerLine;
			if(!attr){
				return null;
			}
			line=attrLines.get(attr);
			if(open){
				if(!line){
					ownerLine=self.getAttrLine(attr.owner,true,false);
					if(!ownerLine){
						return null;
					}
					line=attrLines.get(attr);
				}
				if(line){
					if(open){
						ownerLine=line.ownerLine;
						while(ownerLine && ownerLine.open){
							ownerLine.open();
							ownerLine=ownerLine.ownerLine;
						}
					}
					if(show){
						VFACT.scrollToShow(line,self,{y:1,gap:20});
					}
					if(showEdit){
						line.showFace("showEdit");
					}
				}
			}
			return line||null;
		};
		
		//--------------------------------------------------------------------
		cssVO.showAttrLine=function(attr){
			let line,ownerLine;
			if(!attr){
				return;
			}
			line=attrLines.get(attr);
			if(line){
				line.display=true;
			}
			attr.editHideVsn=0;
		};
		
		//--------------------------------------------------------------------
		cssVO.hideAttrLine=function(attr){
			let line,ownerLine;
			if(!attr){
				return null;
			}
			line=attrLines.get(attr);
			if(line){
				line.display=false;
			}
			attr.editHideVsn=editHideVsn;
		};
		
		//--------------------------------------------------------------------
		cssVO.startEditAttr=function(attr){
			let line;
			line=self.getAttrLine(attr,true,true);
			if(line){
				line.startEdit();
			}
		};
		
		//--------------------------------------------------------------------
		//Rename a attr:
		cssVO.startEditAttrName=async function(attrObj,attrLine){
			app.showDlg(DlgRawEditAttr,{
				line:attrLine,box:self,mode:"rename",
				attrObj:attrObj
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.setAttrByText=function(attr,text){
			let obj,prj,naviBox,treeBox,list;
			obj=attr.owner;
			prj=obj.prj;
			if(prj && prj.editAttr_SetAttrByText){
				SetAttr:{
					naviBox=EditPrj.boxNaviDoc;
					if(naviBox){
						treeBox=naviBox.treeBox;
						list = treeBox.selected;
						if(list.size>0){
							//Multi-selected:
							let huds,hotNode,node,edHud,path;
							hotNode=treeBox.hotNode;
							edHud=hotNode.nodeObj;
							if(edHud){
								path=edHud.findAttrPath(attr);
								if(path){
									huds=Array.from(list).map((node)=>{return node.nodeObj});
									if(prj.editAttr_setHudsAttrByText(huds,path,text)){
										break SetAttr;
									}
								}
							}
						}
					}
					prj.editAttr_SetAttrByText(obj,attr,text);
				}
			}else{
				obj.setAttrByText(attr,text);
			}
			let objDef=obj.objDef;
			if(objDef.OnAttrEdit){
				objDef.OnAttrEdit.call(obj,self,attr,text);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.renameAttr=function(attr,text){
			let obj,prj;
			obj=attr.owner;
			prj=obj.prj;
			if(prj && prj.editAttr_RenameAttr){
				prj.editAttr_RenameAttr(obj,attr,text);
			}else{
				obj.renameAttr(attr,text);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.commentAttr=function(attr,text){
			let obj,prj;
			obj=attr.owner;
			prj=obj.prj;
			if(prj && prj.editAttr_CommentAttr){
				prj.editAttr_CommentAttr(obj,attr,text);
			}else{
				attr.comment=text;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.resetAttrType=function(attr,newType){
			let obj,prj;
			obj=attr.owner;
			prj=obj.prj;
			if(prj && prj.editAttr_RenameAttr){
				prj.editAttr_ResetAttrType(obj,attr,newType);
			}else{
				throw new Error("ResetAttrType is not supported by this EditAttrsBox: Missing EditPrj.");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.addNewAttr=function(editObj,line){
			let prj,attrDef,objDef,newAttrDef,mode,attrName,typeDef;
			prj=editObj.prj;
			attrDef=editObj.def;
			objDef=editObj.objDef;
			function addFixedAttr(){
				attrName=window.prompt("New attr name","");
				if(attrName){
					if(editObj.getAttr(attrName)){
						window.alert("Name already taken!");
						return;
					}
					newAttrDef.name=attrName;
					if(prj && prj.editAttr_AddAttr){
						prj.editAttr_AddAttr(editObj,newAttrDef);
					}else{
						editObj.addAttr(newAttrDef);
					}
				}
			}
			//Fixed type:
			newAttrDef={type:objDef.attrType,extraAttr:1};
			if(objDef.attrType){
				typeDef=EditAttr.getType(objDef.attrType);
				if(typeDef.getDef){
					if(objDef.attrTypeDef){
						newAttrDef.def=objDef.attrTypeDef;
						addFixedAttr();
						return;
					}else{
						//TODO: Show dialog to choose sub-def-type
					}
				}else{
					addFixedAttr();
					return;
				}
			}
			mode=objDef.newAttrMode||attrDef.newAttrMode;
			if(mode){
				mode=mode;
			}else if(attrDef.type==="array"){
				let elementType,elementDef;
				mode="ArrayElement";
				elementType=attrDef.elementType||objDef.elementType;
				elementDef=attrDef.elementDef||objDef.elementDef;
				if(elementType||elementDef){
					editObj.addAttr(null);
					return;
				}
			}else{
				let memberType,memberDef;
				memberType=attrDef.memberType||objDef.memberType;
				memberDef=attrDef.memberDef||objDef.memberDef;
				if(memberType){
					newAttrDef={type:memberType,extraAttr:1};
					if(memberDef){
						newAttrDef.def=memberDef;
					}
					addFixedAttr();
					return;
				}
				mode="ExtraAttr";
			}
			app.showDlg(DlgNewAttr,{
				mode:mode,hud:self,x:0,align:2,editObj:editObj,
				callback(attrDef,close){
					if(prj && prj.editAttr_AddAttr){
						prj.editAttr_AddAttr(editObj,attrDef);
					}else{
						editObj.addAttr(attrDef);
					}
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.addEmptyAttr=function(editObj,attrDef){
			let prj,objDef,err;
			prj=editObj.prj;
			if(editObj.checkAttrAdd){
				err=editObj.checkAttrAdd(attrDef);
				if(err){
					window.alert(""+err);
					return;
				}
			}
			if(prj && prj.editAttr_AddAttr){
				prj.editAttr_AddAttr(editObj,attrDef);
			}else{
				editObj.addAttr(attrDef);
			}
		};
		
		//--------------------------------------------------------------------
		//Remove a attr, ask user first:
		cssVO.removeAttr=async function(attr,attrLine){
			let obj,prj;
			obj=attr.owner;
			if(window.confirm((($ln==="CN")?(`您确定要删除属性“${attr.name}”吗？`):/*EN*/(`Are you sure to remove attr "${attr.name}"?`)))){
				if(obj.isHudFacePtts){
					attrLine.replaceLine=1;
				}
				prj=obj.prj;
				if(prj && prj.editAttr_RemoveAttr){
					prj.editAttr_RemoveAttr(obj,attr);
				}else{
					obj.removeAttr(attr);
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.moveUpAttr=function(attrObj){
			let editObj,prj;
			let attrDef,preAttr,preAttrDef,line,preLine;
			attrDef=attrObj.def;
			if(attrDef.fixed||attrDef.key){
				return;
			}
			line=attrLines.get(attrObj);
			if(!line){
				return;
			}
			preLine=line.previousSibling;
			if(!preLine){
				return;
			}
			if(preLine.isGroup){
				return;
			}
			preAttr=preLine.attrObj;
			if(!preAttr){
				return;
			}
			preAttrDef=preAttr.def;
			if(preAttrDef.fixed||preAttrDef.key){
				return;
			}
			editObj=attrObj.owner;
			prj=editObj.prj;
			if(prj && prj.editAttr_MoveUpAttr){
				prj.editAttr_MoveUpAttr(editObj,attrObj);
			}else{
				editObj.moveUpAttr(attrObj);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.moveDownAttr=function(attrObj){
			let editObj,prj;
			let attrDef,nxtAttr,nxtAttrDef,line,nxtLine;
			attrDef=attrObj.def;
			if(attrDef.fixed||attrDef.key){
				return;
			}
			line=attrLines.get(attrObj);
			if(!line){
				return;
			}
			nxtLine=line.nextSibling;
			if(!nxtLine){
				return;
			}
			if(nxtLine.isGroup){
				return;
			}
			nxtAttr=nxtLine.attrObj;
			if(!nxtAttr){
				return;
			}
			nxtAttrDef=nxtAttr.def;
			if(nxtAttrDef.fixed||nxtAttrDef.key){
				return;
			}
			editObj=attrObj.owner;
			prj=editObj.prj;
			if(prj && prj.editAttr_MoveDownAttr){
				prj.editAttr_MoveDownAttr(editObj,attrObj);
			}else{
				editObj.moveDownAttr(attrObj);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.localizeAttr=function(attrObj,attrLine){
			let editObj,prj;
			editObj=attrObj.owner;
			prj=editObj.prj;
			if(prj && prj.editAttr_LocalizeAttr){
				prj.editAttr_LocalizeAttr(editObj,attrObj);
			}else{
				editObj.localizeAttr(attrObj);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.setAttrLocalize=function(attrObj,locObj,attrLine){
			let editObj,prj;
			editObj=attrObj.owner;
			prj=editObj.prj;
			if(prj && prj.editAttr_SetAttrLocalize){
				prj.editAttr_SetAttrLocalize(editObj,attrObj,locObj);
			}else{
				editObj.localizeAttr(attrObj);
			}
		};
	}
	
	/*}#1GA9QOA2E7PostCSSVO*/
	cssVO.constructor=EditAttrsBox;
	return cssVO;
};
/*#{1GA9QOA2E7ExCodes*/
let attrBoxRegs={};
//----------------------------------------------------------------------------
//Register a attrBox
EditAttrsBox.regAttrBox=function(type,func){
	attrBoxRegs[type]=func;
};
//----------------------------------------------------------------------------
EditAttrsBox.getAttrBox=function(type){
	return attrBoxRegs[type]||EALStdAttr;
};

EditAttrsBox.regAttrBox("object",EALObj);
EditAttrsBox.regAttrBox("uistate",EALObj);
EditAttrsBox.regAttrBox("hudani",EALObj);
EditAttrsBox.regAttrBox("array",EALObj);
EditAttrsBox.regAttrBox("group",EALGroup);
EditAttrsBox.regAttrBox("font",EALObj);
/*}#1GA9QOA2E7ExCodes*/

//----------------------------------------------------------------------------
EditAttrsBox.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GA9QOA2E7PreAISpot*/
	/*}#1GA9QOA2E7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GA9QOA2E7PostAISpot*/
	/*}#1GA9QOA2E7PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
EditAttrsBox.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"view": {
			"name": "view", "showName": "view", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1GA9QOA2E0ExGearInfo*/
	/*}#1GA9QOA2E0ExGearInfo*/
};
/*#{1GA9QOA2E0EndDoc*/
/*}#1GA9QOA2E0EndDoc*/

export default EditAttrsBox;
export{EditAttrsBox};
