//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1GAHCAV6C0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GAHCAV6C0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALBoolAttr=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnVal;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GAHCAV6D0LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	icon=attrObj.icon||attrDef.icon||null;
	/*}#1GAHCAV6D0LocalVals*/
	
	/*#{1GAHCAV6D0PreState*/
	/*}#1GAHCAV6D0PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val,"hyper":attrObj.hyper,
		"valText":attrObj.valText,"showText":attrObj.val2ShowText?attrObj.val2ShowText(attrObj.val):attrObj.val,
		/*#{1GAHCAV6C5ExState*/
		/*}#1GAHCAV6C5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GAHCAV6D0PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GAHCAV6D0PostState*/
	cssVO={
		"hash":"1GAHCAV6D0",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GAHD36NL0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GAHD0SKS0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":cfgSize.attrLineH*0.5,"w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GAHD6G1K0",
				"type":BtnSwitch(16,!!state.value),"id":"BtnVal","position":"relative","x":0,"y":cfgSize.attrLineH*0.5,"anchorY":1,"checked":!!state.value,"margin":[0,3,0,3],
				/*#{1GAHD6G1K0Codes*/
				OnCheck(check){
					self.setVal(check);
				}
				/*}#1GAHD6G1K0Codes*/
			},
			{
				"hash":"1GAHD3DHV0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GAHD3JO90",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.showText}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
			},
			{
				"hash":"1GAHD3RA20",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GAHCAV6D0ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GAHCAV6D0ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GAHD36NL0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GAHD36NL0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GAHD36NL0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GAHD36NL0":{
					"shadow":true
				},
				/*BtnVal*/"#1GAHD6G1K0":{
					"display":0
				},
				/*TxtVal*/"#1GAHD3JO90":{
					"display":0
				},
				/*#{1GAHD21KK0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GAHD21KK0Code*/
			},"editOff":{
				/*BoxBG*/"#1GAHD36NL0":{
					"shadow":false
				},
				/*BtnVal*/"#1GAHD6G1K0":{
					"display":1
				},
				/*TxtVal*/"#1GAHD3JO90":{
					"display":1
				},
				/*#{1GAHD24OS0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GAHD24OS0Code*/
			},"showEdit":{
				/*#{1GDV3NFGI0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV3NFGI0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnVal=self.BtnVal;
			/*#{1GAHCAV6D0Create*/
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			if(attrDef.edit===false){
				self.BtnVal.enable=false;
			}
			/*}#1GAHCAV6D0Create*/
		},
		/*#{1GAHCAV6D0EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GAHCAV6D0EndCSS*/
	};
	/*#{1GAHCAV6D0PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val;
		state.hyper=attrObj.hyper;
		state.valText=attrObj.valText;
		state.showText=attrObj.val2ShowText(attrObj.val);
		self.BtnVal.checked=!!attrObj.val;
	};
	
	//------------------------------------------------------------------------
	cssVO.setVal=function(check){
		check=!!check;
		if(check!==attrObj.val){
			box.setAttrByText(attrObj,""+check);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			if(attrDef.rawEdit!==false && box.rawEdit!==false){
				self.startEdit(true);
			}else{
				btnVal.OnClick(evt);
			}
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(raw=false){
		if(raw){
			app.showDlg(DlgRawEditAttr,{
				line:self,box:box,
				attrObj:attrObj
			});
		}
	};
	/*}#1GAHCAV6D0PostCSSVO*/
	return cssVO;
};
/*#{1GAHCAV6D0ExCodes*/
EditAttrsBox.regAttrBox("bool",EALBoolAttr);
/*}#1GAHCAV6D0ExCodes*/


/*#{1GAHCAV6C0EndDoc*/
/*}#1GAHCAV6C0EndDoc*/

export default EALBoolAttr;
export{EALBoolAttr};
