//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
import {BoxNewGears} from "./BoxNewGears.js";
import {BoxSteps} from "/@StdUI/ui/BoxSteps.js";
/*#{1GANLA5IL0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {EditForge} from "../forge/EditForge.js";
let uiForge=null;
let curEditor=null;
/*}#1GANLA5IL0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIForge=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxGearPV,imgPvGear,txtPvName,txtPvInfo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GANLA5IL7LocalVals*/
	let appPrj,editPrj;
	let theForge=null;
	let curDoc=null;
	let cfgObj=null;
	appPrj=app.prj;
	editPrj=appPrj.codyPrj;
	
	let mouseInOut=function(isIn){
		if(isIn){
			if(this.tip){
				app.showTip(this,this.tip,this.w/2,this.h+5,1,0);
			}
			if(this.stateTip){
				app.showStateText(this.stateTip);
			}
		}else{
			if(this.tip){
				app.abortTip(this);
			}
		}
	}
	/*}#1GANLA5IL7LocalVals*/
	
	/*#{1GANLA5IL7PreState*/
	let btnUndo,btnRedo;
	btnUndo=null;
	btnRedo=null;
	/*}#1GANLA5IL7PreState*/
	/*#{1GANLA5IL7PostState*/
	/*}#1GANLA5IL7PostState*/
	cssVO={
		"hash":"1GANLA5IL7",nameHost:true,
		"type":"hud","id":"BoxForge","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GANLTTPS0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tool,
			},
			{
				"hash":"1GANLKIOV0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":40,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":[0,0,1,0],"borderColor":cfgColor.lineBodySub,"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HHKPBJF90",
						"type":"box","id":"BoxEditCodeBtn","position":"relative","x":0,"y":0,"w":30,"h":30,"zIndex":5,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
						children:[
							{
								"hash":"1HHKPBJF92",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/code.svg",null),"id":"BtnEditCode","x":0,"y":0,"padding":2,
								"tip":"Switch to Code Mode",
								/*#{1HHKPBJF92Codes*/
								OnClick(){
									if(curEditor){
										curEditor.setEditMode("Code");
									}
								}
								/*}#1HHKPBJF92Codes*/
							}
						],
					},
					{
						"hash":"1HHKPE3MF0",
						"type":"box","id":"BoxEditCodeBtn","position":"relative","x":0,"y":0,"w":30,"h":30,"zIndex":5,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
						children:[
							{
								"hash":"1HHKPE3MG0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/condition.svg",null),"id":"BtnEditSeg","x":0,"y":0,"padding":2,
								"tip":"Switch to Function Editor",
								"OnClick":function(event){
									/*#{1HHKQ4FSO0FunctionBody*/
									if(curEditor){
										curEditor.setSubEditMode("SEG");
									}
									/*}#1HHKQ4FSO0FunctionBody*/
								},
								/*#{1HHKPE3MG0Codes*/
								/*}#1HHKPE3MG0Codes*/
							}
						],
					},
					{
						"hash":"1GBRUO29S0",
						"type":"hud","id":"BoxFaceOnHeader","position":"relative","x":0,"y":0,"w":"","h":"FH","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GBRV03SO0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnFaceOff","x":0,"y":"FH/2","anchorY":1,"padding":1,
								/*#{1GBRV03SO0Codes*/
								tip:(($ln==="CN")?("退出编辑预设外观模式"):/*EN*/("Exit face edit mode")),
								OnClick(){
									self.endFaceEdit();
								}
								/*}#1GBRV03SO0Codes*/
							},
							{
								"hash":"1GBRV1ICD0",
								"type":"text","id":"TxtFaceName","x":30,"y":0,"w":100,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Face:",
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1GBRUPLUI0",
						"type":"hud","id":"BoxFaceOffHeader","position":"relative","x":0,"y":0,"w":"","h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1GNESK4A70",
								"type":"hud","id":"BlkUndo","position":"relative","x":0,"y":0,"w":75,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GNESK4A80",
										"type":"text","id":"TxtBlkUndo","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("撤销 / 重做:"):("Undo / Redo:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GNESK4A80Codes*/
										/*}#1GNESK4A80Codes*/
									},
									{
										"hash":"1GNESLUCE0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnUndo","x":3,"y":12,"padding":1,
										"tip":"Undo (Cmd+Z / Ctrl+Z)",
										/*#{1GNESLUCE0Codes*/
										OnClick(){
											self.doUndo();											
										}
										/*}#1GNESLUCE0Codes*/
									},
									{
										"hash":"1GNESM6I90",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnRedo","x":33,"y":12,"padding":1,
										"tip":"Redo (Cmd+Shift+Z / Ctrl+Shift+Z)",
										/*#{1GNESM6I90Codes*/
										OnClick(){
											self.doRedo();
										}
										/*}#1GNESM6I90Codes*/
									}
								],
								/*#{1GNESK4A70Codes*/
								/*}#1GNESK4A70Codes*/
							},
							{
								"hash":"1GT8GQ03D0",
								"type":"hud","id":"BlkAction","position":"relative","x":0,"y":0,"w":95,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GT8GQN0R0",
										"type":"text","id":"TxtBlkAct","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("光标操作"):("Cursor Action")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GT8GQN0R0Codes*/
										/*}#1GT8GQN0R0Codes*/
									},
									{
										"hash":"1GTAEOJK50",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/cursor_sel.svg",null),"id":"BtnActSelect","x":5,"y":12,"padding":1,
										/*#{1GTAEOJK50Codes*/
										face:"focus",tip:(($ln==="CN")?("选择并拖动"):/*EN*/("Select & drag")),
										actMode:0,
										OnClick(){
											self.setActMode(this.actMode);
										}
										/*}#1GTAEOJK50Codes*/
									},
									{
										"hash":"1GTAEPMNJ0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/cursor_add.svg",null),"id":"BtnActCreate","x":33,"y":12,"padding":1,
										/*#{1GTAEPMNJ0Codes*/
										tip:(($ln==="CN")?("创建"):/*EN*/("Create")),
										actMode:1,
										OnClick(){
											self.setActMode(this.actMode);
										}
										/*}#1GTAEPMNJ0Codes*/
									},
									{
										"hash":"1GTAKA0TS0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/cursor_draw.svg",null),"id":"BtnActDraw","x":58,"y":12,"enable":false,"padding":1,
										/*#{1GTAKA0TS0Codes*/
										tip:(($ln==="CN")?("即将推出：绘制草图"):/*EN*/("Comming soon: draw sketch")),
										actMode:2,
										OnClick(){
											self.setActMode(this.actMode);
										}
										/*}#1GTAKA0TS0Codes*/
									},
									{
										"hash":"1GTAJGG0L0",
										"type":"box","x":0,"y":3,"w":1,"h":"FH-6","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
									}
								],
							},
							{
								"hash":"1GMGL8IBT0",
								"type":"hud","id":"Blk0","position":"relative","x":0,"y":0,"w":80,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GMGL8IBU0",
										"type":"text","id":"TxtBlk0","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("锁定选择："):("Lock Selection:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GMGL8IBU0Codes*/
										/*}#1GMGL8IBU0Codes*/
									},
									{
										"hash":"1GMGLACM50",
										"type":BtnSwitch(18,false),"id":"BtnLockSel","x":8,"y":15,
										/*#{1GMGLACM50Codes*/
										OnCheck(check){
											theForge.lockSelect(check);
											self.TxtLockSel.text=check?"Yes":"No";
										}
										/*}#1GMGLACM50Codes*/
									},
									{
										"hash":"1GMGLCGPK0",
										"type":"text","id":"TxtLockSel","x":42,"y":15,"w":"","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"No",
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1GNESS4PT0",
										"type":"box","x":0,"y":3,"w":1,"h":">calc(100% - 6px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
									}
								],
								/*#{1GMGL8IBT0Codes*/
								tip:(($ln==="CN")?("锁定当前选择。快捷键：空格"):/*EN*/("Lock current selection. Shortcut: Space")),
								OnMouseInOut:mouseInOut
								/*}#1GMGL8IBT0Codes*/
							},
							{
								"hash":"1GBS1AK3V0",
								"type":"hud","id":"Blk1","position":"relative","x":0,"y":0,"w":80,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GBS1B69L0",
										"type":"text","id":"TxtBlk1","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("新建位置："):("New Item Place:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GBS1B69L0Codes*/
										/*}#1GBS1B69L0Codes*/
									},
									{
										"hash":"1GBS1BGEQ0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/auto.svg",null),"id":"BtnAddTop","x":5,"y":12,"padding":2,
										/*#{1GBS1BGEQ0Codes*/
										face:"focus",tip:(($ln==="CN")?("自动选择新控件容器"):/*EN*/("Auto pick new item slot")),
										addPlace:0,
										OnClick(){
											self.setAddPlace(this.addPlace);
										}
										/*}#1GBS1BGEQ0Codes*/
									},
									{
										"hash":"1GBS1C2LT0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/addchild.svg",null),"id":"BtnAddChild","x":33,"y":12,"padding":1,
										/*#{1GBS1C2LT0Codes*/
										tip:(($ln==="CN")?("将新控件置为选定控件的子项"):/*EN*/("Place new item as selected item's child")),
										addPlace:1,
										OnClick(){
											self.setAddPlace(this.addPlace);
										}
										/*}#1GBS1C2LT0Codes*/
									},
									{
										"hash":"1GNESSF480",
										"type":"box","x":0,"y":3,"w":1,"h":"FH-6","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
									}
								],
							},
							{
								"hash":"1GBS1GBVI0",
								"type":"hud","id":"Blk2","position":"relative","x":0,"y":0,"w":90,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GBS1GQ3P0",
										"type":"text","id":"Blk2","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("磁吸:"):("Magnet Snap:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GBS1GQ3P0Codes*/
										/*}#1GBS1GQ3P0Codes*/
									},
									{
										"hash":"1GBS1H41K0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/snap.svg",null),"id":"BtnSnapAuto","x":5,"y":12,"padding":1,
										/*#{1GBS1H41K0Codes*/
										face:"focus",tip:(($ln==="CN")?("自动捕捉"):/*EN*/("Snap: auto")),mode:1,
										OnClick(){
											self.setSnapMode(this.mode);
										},
										/*}#1GBS1H41K0Codes*/
									},
									{
										"hash":"1GBS1H4370",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/snapoff.svg",null),"id":"BtnSnapOff","x":30,"y":12,"padding":1,
										/*#{1GBS1H4370Codes*/
										tip:(($ln==="CN")?("捕捉: 禁用"):/*EN*/("Snap: disable")),mode:0,
										OnClick(){
											self.setSnapMode(this.mode);
										},
										/*}#1GBS1H4370Codes*/
									},
									{
										"hash":"1GBS1H3VO0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/snapobj.svg",null),"id":"BtnSnapObj","x":55,"y":12,"padding":1,
										/*#{1GBS1H3VO0Codes*/
										tip:(($ln==="CN")?("对齐到选定对象"):/*EN*/("Snap to selected objects")),mode:2,
										OnClick(){
											self.setSnapMode(this.mode);
										},
										/*}#1GBS1H3VO0Codes*/
									},
									{
										"hash":"1GNESSMB40",
										"type":"box","x":0,"y":3,"w":1,"h":"FH-6","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
									}
								],
							},
							{
								"hash":"1GMGQN9GA0",
								"type":"hud","id":"Blk3","position":"relative","x":0,"y":0,"w":90,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1GMGQN9GA2",
										"type":"text","id":"TxtBlk3","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("区域选择："):("Range Select:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1GMGQN9GA2Codes*/
										/*}#1GMGQN9GA2Codes*/
									},
									{
										"hash":"1GMGQN9GC0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/intersect.svg",null),"id":"BtnRange0","x":5,"y":12,"padding":1,
										/*#{1GMGQN9GC0Codes*/
										face:"focus",tip:(($ln==="CN")?("相交即选择"):/*EN*/("Select by intersect")),mode:0,
										OnClick(){
											self.setRangeMode(this.mode);
										},
										/*}#1GMGQN9GC0Codes*/
									},
									{
										"hash":"1GMGQN9GD0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/contain.svg",null),"id":"BtnRange1","x":33,"y":12,"padding":1,
										/*#{1GMGQN9GD0Codes*/
										tip:(($ln==="CN")?("按包含选择"):/*EN*/("Select by contain")),mode:1,
										OnClick(){
											self.setRangeMode(this.mode);
										},
										/*}#1GMGQN9GD0Codes*/
									},
									{
										"hash":"1GNEST23N0",
										"type":"box","x":0,"y":3,"w":1,"h":"FH-6","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
									}
								],
								/*#{1GMGQN9GA0Codes*/
								stateTip:(($ln==="CN")?("开始范围选择：按住Shift键然后拖动选择。"):/*EN*/("Start range select: Hold Shift-Key then drag to select.")),
								OnMouseInOut:mouseInOut
								/*}#1GMGQN9GA0Codes*/
							}
						],
					}
				],
			},
			{
				"hash":"1GANLDJQE0",
				"type":"box","id":"BoxEditCodeBtn","x":5,"y":5,"w":30,"h":30,"zIndex":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
				children:[
					{
						"hash":"1GANLDJQF0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/code.svg",null),"id":"BtnEditCode","x":0,"y":0,"padding":2,
						"tip":"Switch to Code Mode",
						/*#{1GANLDJQF0Codes*/
						OnClick(){
							if(curEditor){
								curEditor.setEditMode("Code");
							}
						}
						/*}#1GANLDJQF0Codes*/
					}
				],
			},
			{
				"hash":"1GANLVK3B0",
				"type":"box","id":"BoxGears","x":0,"y":39,"w":100,"h":">calc(100% - 39px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":[0,1,0,0],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1GANM9RFQ0",
						"type":"box","x":10,"y":0,"w":80,"h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
					},
					{
						"hash":"1GANMDFNH0",
						"type":"box","id":"BoxZoom","x":5,"y":">calc(100% - 25px)","w":90,"h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
						children:[
							{
								"hash":"1GANME4AK0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/dec.svg",null),"id":"BtnZoomSub","x":0,"y":2,"padding":0,
								/*#{1GANME4AK0Codes*/
								OnClick(){
									self.zoomSub();
								}
								/*}#1GANME4AK0Codes*/
							},
							{
								"hash":"1GANMFSGP0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnZoomAdd","x":"FW-20","y":2,"padding":0,
								/*#{1GANMFSGP0Codes*/
								OnClick(){
									self.zoomAdd();
								}
								/*}#1GANMFSGP0Codes*/
							},
							{
								"hash":"1GANMH9CS0",
								"type":"box","id":"BoxZoomText","x":20,"y":2,"w":"FW-40","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
								children:[
									{
										"hash":"1GANMJ88G0",
										"type":"text","id":"TxtZoom","x":0,"y":0,"w":"FW","h":"FH","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
										"text":"100%","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
									}
								],
								/*#{1GANMH9CS0Codes*/
								OnClick(){
									self.zoomMenu();
								}
								/*}#1GANMH9CS0Codes*/
							}
						],
					},
					{
						"hash":"1GANMM8BP0",
						"type":"hud","x":0,"y":1,"w":"100%","h":">calc(100% - 28px)","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GAP64JAM0",
								"type":BoxNewGears(app),"id":"BoxNewGears","x":0,"y":0,
							},
							{
								"hash":"1GTFG6S770",
								"type":"hud","id":"BoxActCreate","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1GTFO4E6P0",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[10,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x",
										children:[
											{
												"hash":"1GTFO62BR0",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":20,"margin":[0,3,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
												"text":"Snap: ","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1GTFO4RKT0",
												"type":BtnSwitch(14,false),"position":"relative","x":0,"y":"50%","anchorY":1,
												/*#{1GTFO4RKT0Codes*/
												OnCheck(check){
													self.setActDrawSnap(check);
												}
												/*}#1GTFO4RKT0Codes*/
											}
										],
									},
									{
										"hash":"1GTFGEKQR0",
										"type":"text","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":16,"margin":[5,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":"Grid size:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1GTFNO0HT0",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
										"subAlign":1,
										children:[
											{
												"hash":"1GTFNRECM0",
												"type":"edit","id":"EdActDrawSnap","position":"relative","x":0,"y":0,"w":30,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"text":"5","color":cfgColor["fontBody"],"outline":0,"border":[0,0,1,0],
												"OnUpdate":function(){
													/*#{1GTFQRP1E0FunctionBody*/
													self.setActDrawSnapSize(0);
													//TODO: Code this:
													/*}#1GTFQRP1E0FunctionBody*/
												},
											},
											{
												"hash":"1GTFO2QMH0",
												"type":BoxSteps(20),"position":"relative","x":0,"y":0,
												/*#{1GTFO2QMH0Codes*/
												OnStep(dir){
													self.setActDrawSnapSize(dir);
												}
												/*}#1GTFO2QMH0Codes*/
											}
										],
									}
								],
							},
							{
								"hash":"1GTFOF9540",
								"type":"hud","id":"BoxActDraw","x":0,"y":0,"w":"100%","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							}
						],
					}
				],
			},
			{
				"hash":"1GANNDS2L0",
				"type":"hud","id":"BoxScroll","x":100,"y":40,"w":">calc(100% - 100px)","h":">calc(100% - 40px)","overflow":1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"",
				children:[
					{
						"hash":"1GANNE27M0",
						"type":"hud","id":"BoxDevice","x":50,"y":50,"w":250,"h":400,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1GANNF8N30",
								"type":"box","id":"BoxDeviceBG","x":-2,"y":-2,"w":"FW+4","h":"FH+4","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":[255,255,255,1],"border":2,"borderStyle":2,
								children:[
									{
										"hash":"1GANNHMBV0",
										"type":"image","id":"ImgChecker","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"image":appCfg.sharedAssets+"/checker.png","repeat":false,
										/*#{1GANNHMBV0Codes*/
										/*}#1GANNHMBV0Codes*/
									}
								],
							},
							{
								"hash":"1GANNK4ET0",
								"type":"hud","id":"BoxGear","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1GANNLMPK0",
								"type":"hud","id":"BoxNotes","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1GANNM0LD0",
								"type":"hud","id":"BoxHelpers","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1GANNMEIS0",
								"type":"hud","id":"BoxLines","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							}
						],
					}
				],
			},
			{
				"hash":"1GAP3I8CL0",
				"type":"box","id":"BoxTip","x":100,"y":"FH-20","w":"FW-100","h":20,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[...cfgColor.secondary,-15],
				children:[
					{
						"hash":"1GAP3LEN30",
						"type":"text","id":"TxtMoveTip","x":10,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontPrimary,
						"text":"Move","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1GAQBDRPC0",
						"type":"text","id":"TxtSnapTip","x":10,"y":0,"w":"FW-20","h":20,"autoLayout":true,"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor.fontSecondary,"text":"Press 'Esc' key to ingore this snap position.","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignH":2,"alignV":1,
					}
				],
			},
			{
				"hash":"1GAPHDJIO0",
				"type":"box","id":"BoxNewHud","x":200,"y":200,"w":100,"h":100,"anchorX":1,"anchorY":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,0.5],"border":2,"borderStyle":3,
			},
			{
				"hash":"1GMD3MBBV0",
				"type":"box","id":"BoxNewHudOwner","x":200,"y":200,"w":100,"h":100,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[20,128,255,0.5],"border":3,"borderStyle":3,"borderColor":[255,0,255,1],
			},
			{
				"hash":"1GMGTS7G30",
				"type":"box","id":"BoxRangeSel","x":200,"y":200,"w":100,"h":100,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0.5],
				"border":2,"borderStyle":3,
			},
			{
				"hash":"1H26J7MCT0",
				"type":"box","id":"BoxGearPV","x":90,"y":">calc(100% - 20px)","w":250,"h":"","anchorY":2,"display":0,"padding":5,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":[255,255,255,1],"border":1,"corner":6,"shadow":true,"shadowX":3,"shadowY":5,"shadowBlur":6,"shadowSpread":3,"shadowColor":[0,0,0,0.3],
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1H26JBMRQ0",
						"type":"image","id":"ImgPvGear","position":"relative","x":"50%","y":0,"w":100,"h":50,"anchorX":1,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","fitSize":true,"repeat":false,
					},
					{
						"hash":"1H26JFAC90",
						"type":"text","id":"TxtPvName","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Gear Name","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1H26JGV0H0",
						"type":"text","id":"TxtPvInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
						"text":"Description","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			}
		],
		/*#{1GANLA5IL7ExtraCSS*/
		app:app,
		/*}#1GANLA5IL7ExtraCSS*/
		faces:{
			"faceOff":{
				/*BoxFaceOnHeader*/"#1GBRUO29S0":{
					"display":0
				},
				/*BoxFaceOffHeader*/"#1GBRUPLUI0":{
					"display":1
				}
			},"faceOn":{
				/*BoxFaceOnHeader*/"#1GBRUO29S0":{
					"display":1
				},
				/*BoxFaceOffHeader*/"#1GBRUPLUI0":{
					"display":0
				}
			},"actSelect":{
				/*BoxNewGears*/"#1GAP64JAM0":{
					"display":1
				},
				/*BoxActCreate*/"#1GTFG6S770":{
					"display":0
				},
				/*BoxActDraw*/"#1GTFOF9540":{
					"display":0
				}
			},"actCreate":{
				/*BoxNewGears*/"#1GAP64JAM0":{
					"display":0
				},
				/*BoxActCreate*/"#1GTFG6S770":{
					"display":1
				},
				/*BoxActDraw*/"#1GTFOF9540":{
					"display":0
				}
			},"actDraw":{
				/*BoxNewGears*/"#1GAP64JAM0":{
					"display":0
				},
				/*BoxActCreate*/"#1GTFG6S770":{
					"display":0
				},
				/*BoxActDraw*/"#1GTFOF9540":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxGearPV=self.BoxGearPV;imgPvGear=self.ImgPvGear;txtPvName=self.TxtPvName;txtPvInfo=self.TxtPvInfo;
			/*#{1GANLA5IL7Create*/
			theForge=new EditForge(self);
			app.uiForge=self;
			btnUndo=self.BtnUndo;
			btnRedo=self.BtnRedo;
			self.showFace("actSelect");
			/*}#1GANLA5IL7Create*/
		},
		/*#{1GANLA5IL7EndCSS*/
		/*}#1GANLA5IL7EndCSS*/
	};
	/*#{1GANLA5IL7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.bindToEditor=function(docEditor){
		let dataDoc,editDoc;
		if(docEditor){
			dataDoc=docEditor.dataDoc;
			editDoc=dataDoc.codyDoc;
		}else{
			dataDoc=null;
			editDoc=null;
		}
		if(!cfgObj){
			cfgObj=editPrj.objConfig;
			if(cfgObj){
				cfgObj.onNotify("Changed",()=>{
					UIForge.bindToEditor(null);
				});
			}
		}
		//Trace edit face:
		if(curDoc===editDoc){
			self.updateUndoRedo();
			self.showFace("faceOff");
			return;
		}
		if(curDoc){
			curDoc.off("FaceOn",self.OnFaceOn);
			curDoc.off("FaceOff",self.OnFaceOff);
			curDoc.offNotify("UpdateCode",self.updateUndoRedo);
		}
		curDoc=editDoc;
		if(curDoc){
			curDoc.on("FaceOn",self.OnFaceOn);
			curDoc.on("FaceOff",self.OnFaceOff);
			//Update forge for this gear-doc:
			theForge.startEdit(dataDoc);
			self.updateUndoRedo();
			curDoc.onNotify("UpdateCode",self.updateUndoRedo);
		}
		self.showFace("faceOff");
	};
	
	//------------------------------------------------------------------------
	cssVO.getCurEditor=function(){
		return curDoc?curDoc.dataDoc.editBox:null;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFaceOn=function(faceTag){
		self.TxtFaceName.text=`Face: ${faceTag.name}`;
		self.showFace("faceOn");
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFaceOff=function(){
		self.showFace("faceOff");
	};
	
	//------------------------------------------------------------------------
	cssVO.endFaceEdit=function(){
		let doc=curDoc;
		doc.exitFaceEdit(true);
	};
	
	//------------------------------------------------------------------------
	cssVO.setActMode=function(mode){
		if(theForge.actMode===mode){
			return;
		}
		theForge.actMode=mode;
		if(mode===0){
			self.BtnActSelect.face="focus";
			self.BtnActCreate.face="blur";
			self.BtnActDraw.face="blur";
			self.showFace("actSelect");
		}else if(mode===1){
			self.BtnActSelect.face="blur";
			self.BtnActCreate.face="focus";
			self.BtnActDraw.face="blur";
			self.showFace("actCreate");
		}else if(mode===2){
			self.BtnActSelect.face="blur";
			self.BtnActCreate.face="blur";
			self.BtnActDraw.face="focus";
			self.showFace("actDraw");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setActDrawSnap=function(check){
		theForge.drawSnap=!!check;
	};
	
	//------------------------------------------------------------------------
	cssVO.setActDrawSnapSize=function(dir=0){
		let size,edit;
		edit=self.EdActDrawSnap;
		size=parseInt(edit.text)||1;
		if(dir){
			size+=dir;
		}
		if(size<2){
			size=2;
		}
		if(size>50){
			size=50;
		}
		edit.text=""+size;
		theForge.drawSnapSize=size;
	};
	
	//------------------------------------------------------------------------
	cssVO.setAddPlace=function(addPlace){
		if(addPlace===theForge.addPlace){
			return;
		}
		theForge.addPlace=addPlace;
		if(addPlace===0){
			self.BtnAddTop.face="focus";
			self.BtnAddChild.face="blur";
		}else{
			self.BtnAddTop.face="blur";
			self.BtnAddChild.face="focus";
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setSnapMode=function(mode){
		if(mode===theForge.snapMode){
			return;
		}
		theForge.setSnapMode(mode);
		if(mode===1){//Auto
			self.BtnSnapAuto.face="focus";
			self.BtnSnapOff.face="blur";
			self.BtnSnapObj.face="blur";
		}else if(mode===0){//Off
			self.BtnSnapAuto.face="blur";
			self.BtnSnapOff.face="focus";
			self.BtnSnapObj.face="blur";
		}else if(mode===2){//Obj
			self.BtnSnapAuto.face="blur";
			self.BtnSnapOff.face="blur";
			self.BtnSnapObj.face="focus";
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setRangeMode=function(mode){
		theForge.setRangeSelMode(mode);
		if(mode===0){//Inter
			self.BtnRange0.face="focus";
			self.BtnRange1.face="blur";
		}else if(mode===1){//Off
			self.BtnRange0.face="blur";
			self.BtnRange1.face="focus";
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		self.bindToEditor(null);
		theForge.clear();
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		return theForge.handleShortcut(cmd);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnUpdateCode=function(){
		self.updateUndoRedo();
	};
	
	//------------------------------------------------------------------------
	cssVO.updateUndoRedo=function(){
		let editor,act;
		if(!curDoc){
			return;
		}
		editor=curDoc.dataDoc.editBox;
		if(!editor){
			btnUndo.enable=false;
			btnRedo.enable=false;
			return;
		}
		btnUndo.enable=!!editor.peekUndoAction();
		btnRedo.enable=!!editor.peekRedoAction();
	};
	
	//------------------------------------------------------------------------
	cssVO.doUndo=function(){
		let dataDoc,editor;
		if(!curDoc){
			return;
		}
		dataDoc=curDoc.dataDoc;
		editor=dataDoc.editBox;
		if(editor){
			editor.undo();
		}
		callAfter(self.updateUndoRedo);
	};
	
	//------------------------------------------------------------------------
	cssVO.doRedo=function(){
		let dataDoc,editor;
		if(!curDoc){
			return;
		}
		dataDoc=curDoc.dataDoc;
		editor=dataDoc.editBox;
		if(editor){
			editor.redo();
		}
		callAfter(self.updateUndoRedo);
	};
	
	
	//************************************************************************
	//Zoom:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.zoomAdd=function(){
			let curZoom;
			curZoom=parseInt(self.TxtZoom.text);
			if(curZoom<100){
				curZoom+=10
				if(curZoom>100){
					curZoom=100;
				}
			}else{
				curZoom+=50
			}
			curZoom=Math.trunc(curZoom);
			self.TxtZoom.text=`${curZoom}%`;
			curZoom/=100;
			theForge.setZoom(curZoom);
		};
		
		//--------------------------------------------------------------------
		cssVO.zoomSub=function(){
			let curZoom;
			curZoom=parseInt(self.TxtZoom.text);
			if(curZoom<=100){
				curZoom-=10
				if(curZoom<0){
					curZoom=0;
				}
			}else{
				curZoom-=50
				if(curZoom<100){
					curZoom=100;
				}
			}
			curZoom=Math.trunc(curZoom);
			self.TxtZoom.text=`${curZoom}%`;
			curZoom/=100;
			theForge.setZoom(curZoom);
		};
		
		//--------------------------------------------------------------------
		cssVO.zoomMenu=function(){
			let items;
			items=[
				{text:"Fit size", zoom:0},
				{text:"10%", zoom:10},
				{text:"25%", zoom:25},
				{text:"50%", zoom:50},
				{text:"75%", zoom:75},
				{text:"100%", zoom:100},
				{text:"150%", zoom:150},
				{text:"200%", zoom:200},
				{text:"250%", zoom:250},
				{text:"500%", zoom:500},
			];
			app.showDlg(DlgMenu,{
				items:items,hud:self.BoxZoom,
				callback(item){
					let zoom;
					if(!item){
						return;
					}
					zoom=item.zoom;
					if(zoom>0){
						self.TxtZoom.text=`${zoom}%`;
						zoom/=100;
						theForge.setZoom(zoom);
					}else{
						let boxDevice,boxScroll,w,h,fW,fH,zoomW,zoomH;
						boxDevice=self.BoxDevice;
						boxScroll=self.BoxScroll;
						w=boxDevice.w;
						h=boxDevice.h;
						fW=boxScroll.w;
						fH=boxScroll.h;
						if(fW>10 && fH>10){
							zoomW=w>0?((fW-10)/w):1;
							zoomH=h>0?((fH-10)/h):1;
							zoom=zoomW<zoomH?zoomW:zoomH;
							zoom*=100;
							zoom=Math.trunc(zoom);
							self.TxtZoom.text=`${zoom}%`;
							zoom/=100;
							theForge.setZoom(zoom);
							w=w*zoom;
							h=h*zoom;
							boxDevice.x=Math.trunc((fW-w)/2);
							boxDevice.y=Math.trunc((fH-h)/2);
						}
					}
				}
			});
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		cssVO.setLockSelect=function(lock){
			self.BtnLockSel.checked=lock;
			self.TxtLockSel.text=lock?"Yes":"No";
		};
		
		//--------------------------------------------------------------------
		let curGearPVDef=null;
		cssVO.showGearPV=function(def){
			let path;
			if(curGearPVDef===def)
				return;
			curGearPVDef=def;
			txtPvName.text=def.showName;
			txtPvInfo.text=def.info||def.desc;
			path=def.previewImg||def.image||def.icon;
			if(path){
				imgPvGear.OnLoad=function(){
					let imgW,imgH;
					if(curGearPVDef!==def)
						return;
					boxGearPV.display=true;
					imgW=this.imageW;
					imgH=this.imageH;
					if(imgW>240){
						imgH=imgH*240/imgW;
						imgW=240;
					}
					if(imgH>240){
						imgW=imgW*240/imgH;
						imgH=240;
					}
					imgPvGear.display=1;
					imgPvGear.w=imgW;
					imgPvGear.h=imgH;
					boxGearPV.display=1;
				};
				if(path[0]==="/"){
					if(path[1]==="@"){
						//OK
					}else if(path[1]!=="/" && path[1]!=="~"){
						path="/~"+path;
					}
				}else if(path[0]==="."){
					path="/~"+appPrj.path+"/assets"+path.substring(1);
				}else{
					path=appCfg.sharedAssets+"/"+path;
				}
				imgPvGear.image=path;
			}else{
				imgPvGear.image="";
				boxGearPV.display=true;
				imgPvGear.display=false;
			}
		};
		
		cssVO.hideGearPV=function(def){
			if(def===curGearPVDef){
				imgPvGear.image="";
				boxGearPV.display=false;
				curGearPVDef=null;
			}
		};
	}
	/*}#1GANLA5IL7PostCSSVO*/
	cssVO.constructor=UIForge;
	return cssVO;
};
/*#{1GANLA5IL7ExCodes*/
UIForge.bindToEditor=function(docEditor){
	if(!uiForge){
		let def;
		curEditor=docEditor;
		def=UIForge(docEditor.app);
		uiForge=curEditor.BoxEditGear.appendNewChild(def);
		uiForge.hold();
		uiForge.bindToEditor(curEditor);
		return uiForge;
	}
	if(curEditor){
		if(curEditor===docEditor){
			curEditor.editDoc.exitFaceEdit(true);
			uiForge.showFace("faceOff");
			return uiForge;
		}
		curEditor.BoxEditGear.removeChild(uiForge);
		uiForge.clear();
	}
	curEditor=docEditor;
	if(curEditor){
		curEditor.BoxEditGear.appendChild(uiForge);
		uiForge.bindToEditor(curEditor);
		return uiForge;
	}
	return null;
};
/*}#1GANLA5IL7ExCodes*/

//----------------------------------------------------------------------------
UIForge.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GANLA5IL7PreAISpot*/
	/*}#1GANLA5IL7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GANLA5IL7PostAISpot*/
	/*}#1GANLA5IL7PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
UIForge.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["faceOff","faceOn","actSelect","actCreate","actDraw"],
	subContainers:{
	},
	/*#{1GANLA5IL0ExGearInfo*/
	/*}#1GANLA5IL0ExGearInfo*/
};
/*#{1GANLA5IL0EndDoc*/
/*}#1GANLA5IL0EndDoc*/

export default UIForge;
export{UIForge};
