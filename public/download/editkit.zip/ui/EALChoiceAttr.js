//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GAHN8JGD0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {EditAttr} from "../EditAttr.js";
import {editFonts} from "../edithud/EditHudFont.js";
/*}#1GAHN8JGD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALChoiceAttr=function(app,attrObj,box,ownerBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnMenu;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GAHN8JGD7LocalVals*/
	let attrDef;
	let mode,menuItems;
	attrDef=attrObj.def;
	if(attrDef.editType==="fontChoice"){
		mode="Font";
	}else if(attrDef.editType==="fontSize"){
		mode="FontSize";
	}else if(attrDef.type==="mockup"){
		mode="Mockup";
	}else if(attrDef.editType==="language"){
		mode="Language";
	}else{
		mode="Choice";
	}
	menuItems=null;
	icon=attrObj.icon||attrDef.icon||null;
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GAHN8JGD7LocalVals*/
	
	/*#{1GAHN8JGD7PreState*/
	/*}#1GAHN8JGD7PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val2ShowText?(attrObj.val2ShowText(attrObj.val)):attrObj.val,
		"hyper":attrObj.hyper,"valText":attrObj.valText,
		/*#{1GAHN8JGD5ExState*/
		/*}#1GAHN8JGD5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GAHN8JGD7PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GAHN8JGD7PostState*/
	cssVO={
		"hash":"1GAHN8JGD7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GAHO6RVO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GAHO913P0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GAHOBANN0",
				"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":1,
				/*#{1GAHOBANN0Codes*/
				OnClick(){
					self.showMenu();
				}
				/*}#1GAHOBANN0Codes*/
			},
			{
				"hash":"1GAHO97S50",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":cfgSize.attrLineH,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,
			},
			{
				"hash":"1GAHOAOU70",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.value}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
			},
			{
				"hash":"1GAMJCOSD0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GAHN8JGD7ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerBox,
		/*}#1GAHN8JGD7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":true
				},
				/*TxtVal*/"#1GAHOAOU70":{
					"display":0
				},
				/*#{1GAHO48HT0Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GAHO48HT0Code*/
			},"editOff":{
				/*BoxBG*/"#1GAHO6RVO0":{
					"shadow":false
				},
				/*TxtVal*/"#1GAHOAOU70":{
					"display":1
				},
				/*#{1GAHO4CNK0Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GAHO4CNK0Code*/
			},"showEdit":{
				/*#{1GDV43B6P0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV43B6P0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnMenu=self.BtnMenu;
			/*#{1GAHN8JGD7Create*/
			box.regAttrLine(attrObj,self);
			boxBG=self.BoxBG;
			attrObj.traceOn(self.OnAttrChange);
			
			if(mode==="Font"){
				self.BtnMenu.hint=`Append a font candidate: hold "Ctrl" key while choosing font.`;
			}
			/*}#1GAHN8JGD7Create*/
		},
		/*#{1GAHN8JGD7EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GAHN8JGD7EndCSS*/
	};
	/*#{1GAHN8JGD7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(){
		let def=attrDef;
		if(def.showMenu){
			let result;
			result=await def.showMenu(attrObj,btnMenu,self,box);
			return;
		}else if(def.getMenuItems){
			menuItems=await def.getMenuItems.call(attrObj);
		}else if(mode==="Language"){
			let docApp,attrLoc,list,attr;
			menuItems=[];
			docApp=attrObj.owner.doc;
			attrLoc=docApp.attrLocalize;
			list=attrLoc.attrList;
			for(attr of list){
				menuItems.push({text:attr.val,valText:attr.val,checked:attr.val===attrObj.val});
			}
		}else if(!menuItems){
			let vals=def.vals;
			let i,n;
			menuItems=[];
			if(mode==="Font"){
				vals=editFonts;
				n=vals.length;
				for(i=0;i<n;i++){
					menuItems.push({text:vals[i],value:vals[i]});
				}
			}else if(mode==="FontSize"){
				let owner,prj,cfgObj,sizeObj,list,i,n;
				owner=attrObj.owner;
				prj=owner.prj;
				cfgObj=prj.objConfig;
				sizeObj=cfgObj.getAttr("txtSize");
				list=sizeObj.attrList;
				n=list.length;
				for(i=0;i<n;i++){
					menuItems.push({text:`${list[i].name}: ${list[i].val}`,valText:`#txtSize.${list[i].name}`});
				}
			}else if(mode==="Mockup"){
				let objClass,mockups,mockup;
				menuItems.push({text:"null",valText:"null"});
				if(attrObj.className){
					objClass=EditAttr.getClass(attrObj.className);
					if(objClass){
						mockups=objClass.mockupObjs.attrList;
						for(mockup of mockups){
							menuItems.push({text:mockup.name,valText:mockup.name});
						}
					}
				}
			}else{
				n=vals.length;
				for(i=0;i<n;i++){
					menuItems.push({text:(vals[i][2]?vals[i][2]:vals[i][1])+" = "+JSON.stringify(vals[i][0]),valText:vals[i][1],value:vals[i][0]});
				}
			}
		}
		if(!menuItems){
			return;
		}
		self.state=0;
		app.showDlg(DlgMenu,{
			hud:self.BtnMenu,items:menuItems,
			callback:(item,evt)=>{
				if(item){
					if(mode==="Font"){
						if(evt.metaKey||evt.ctrlKey){
							let text=attrObj.valText;
							text=text.trim();
							if(text){
								if(!text.endsWith(",")){
									text=text+", "+item.text;
								}else{
									text=text+" "+item.text;
								}
							}else{
								text=item.text;
							}
							box.setAttrByText(attrObj,text);
						}else{
							box.setAttrByText(attrObj,item.text);
						}
					}else{
						box.setAttrByText(attrObj,item.valText);
					}
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			if(attrDef.rawEdit!==false && box.rawEdit!==false){
				self.startEdit(true);
			}else{
				self.showMenu();
			}
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(raw=false){
		if(raw){
			app.showDlg(DlgRawEditAttr,{
				line:self,box:box,
				attrObj:attrObj
			});
		}else{
			self.showMenu();
		}
	};
	//------------------------------------------------------------------------
	/*}#1GAHN8JGD7PostCSSVO*/
	return cssVO;
};
/*#{1GAHN8JGD7ExCodes*/
EditAttrsBox.regAttrBox("language",EALChoiceAttr);
EditAttrsBox.regAttrBox("choice",EALChoiceAttr);
EditAttrsBox.regAttrBox("mockup",EALChoiceAttr);
EditAttrsBox.regAttrBox("fontChoice",EALChoiceAttr);
EditAttrsBox.regAttrBox("fontSize",EALChoiceAttr);
/*}#1GAHN8JGD7ExCodes*/


/*#{1GAHN8JGD0EndDoc*/
/*}#1GAHN8JGD0EndDoc*/

export default EALChoiceAttr;
export{EALChoiceAttr};
