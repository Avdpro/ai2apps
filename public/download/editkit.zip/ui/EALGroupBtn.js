//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GA8M7VKF0StartDoc*/
/*}#1GA8M7VKF0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALGroupBtn=function(app,group,box){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA8M7VKF7LocalVals*/
	let boxLine,isOpen;
	isOpen=0;
	boxLine=null;
	/*}#1GA8M7VKF7LocalVals*/
	
	/*#{1GA8M7VKF7PreState*/
	/*}#1GA8M7VKF7PreState*/
	/*#{1GA8M7VKF7PostState*/
	/*}#1GA8M7VKF7PostState*/
	cssVO={
		"hash":"1GA8M7VKF7",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GA8M95UC0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntSelect,
				"shadowX":0,"shadowBlur":2,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1GA8MG4VA0",
				"type":BtnIcon("front",16,0,appCfg.sharedAssets+"/collapse.svg",null),"id":"BtnOpen","position":"relative","x":8,"y":"50%","anchorY":1,"margin":[0,0,0,0],
				"anchorX":1,"autoLayout":true,"padding":2,
				/*#{1GA8MG4VA0Codes*/
				OnClick(){
					if(isOpen){
						boxLine.close();
					}else{
						boxLine.open();
					}
				}
				/*}#1GA8MG4VA0Codes*/
			},
			{
				"hash":"1GA8MG4S40",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.naviLineH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontTool,"text":group.showName||group.name,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"ellipsis":true,"autoW":true,"flex":true,
			}
		],
		/*#{1GA8M7VKF7ExtraCSS*/
		/*}#1GA8M7VKF7ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GA8M95UC0":{
					"background":cfgColor.gntSelect
				},
				/*BtnOpen*/"#1GA8MG4VA0":{
					"enable":true
				},
				/*TxtName*/"#1GA8MG4S40":{
					"color":cfgColor.fontTool
				}
			},"over":{
				/*BoxBG*/"#1GA8M95UC0":{
					"background":cfgColor.gntFocus
				}
			},"down":{
				/*BoxBG*/"#1GA8M95UC0":{
					"background":cfgColor.lineBodyThin
				}
			},"gray":{
				/*BtnOpen*/"#1GA8MG4VA0":{
					"enable":false
				},
				/*TxtName*/"#1GA8MG4S40":{
					"color":cfgColor.fontToolLit
				}
			},"open":{
				"#self":{
					"h":cfgSize.attrLineH-5
				},
				/*BtnOpen*/"#1GA8MG4VA0":{
					"rotate":90
				},
				/*TxtName*/"#1GA8MG4S40":{
					"h":cfgSize.attrLineH-5
				},
				/*#{1GA8MCL070Code*/
				$(){
					isOpen=1;
				}
				/*}#1GA8MCL070Code*/
			},"close":{
				"#self":{
					"h":cfgSize.attrLineH
				},
				/*BtnOpen*/"#1GA8MG4VA0":{
					"rotate":0
				},
				/*TxtName*/"#1GA8MG4S40":{
					"h":cfgSize.attrLineH
				},
				/*#{1GA8MCO3A0Code*/
				$(){
					isOpen=0;
				}
				/*}#1GA8MCO3A0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA8M7VKF7Create*/
			boxLine=self.parent;
			/*}#1GA8M7VKF7Create*/
		},
		/*#{1GA8M7VKF7EndCSS*/
		OnClick(){
			if(isOpen){
				boxLine.close();
			}else{
				boxLine.open();
			}
		}
		/*}#1GA8M7VKF7EndCSS*/
	};
	/*#{1GA8M7VKF7PostCSSVO*/
	/*}#1GA8M7VKF7PostCSSVO*/
	return cssVO;
};
/*#{1GA8M7VKF7ExCodes*/
/*}#1GA8M7VKF7ExCodes*/

EALGroupBtn.gearExport={
	framework: "vfact",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:500,initH:30,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"group": {
			"name": "group", "showName": "group", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"name":"Group"}
		}, 
		"box": {
			"name": "box", "showName": "box", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down","gray","open","close"],
	subContainers:{
	},
	/*#{1GA8M7VKF0ExGearInfo*/
	/*}#1GA8M7VKF0ExGearInfo*/
};
/*#{1GA8M7VKF0EndDoc*/
/*}#1GA8M7VKF0EndDoc*/

export default EALGroupBtn;
export{EALGroupBtn};
