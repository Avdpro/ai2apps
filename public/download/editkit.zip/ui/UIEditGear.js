//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GAMSM53B0StartDoc*/
import {makeObjEventEmitter,makeNotify} from "/@events";
import {UIForge} from "./UIForge.js";
import {mergeCodeWithSeg} from "../exporters/codesegs.js";
import {UIAICanvas} from "./UIAICanvas.js";
import {EditFlowSeg} from "../segflow/EditFlowSeg.js";
/*}#1GAMSM53B0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEditGear=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GAMSM53B7LocalVals*/
	let appPrj,editPrj,DefDocEditor,codeEditor,uiForge,uiSeg,editDoc;
	appPrj=app.prj;
	editPrj=appPrj.codyPrj;
	DefDocEditor=appPrj.DefDocEditor;
	editDoc=dataDoc.codyDoc;
	/*}#1GAMSM53B7LocalVals*/
	
	/*#{1GAMSM53B7PreState*/
	let boxEditCode, boxEditGear, boxDocEditor,editState,naviView,infoView;
	let editMode="";//"Code"/"Gear"
	let canvasMode="UI";//"UI"/"Seg"
	editState=editDoc.editAttrState;
	naviView=app.naviView;
	infoView=app.infoView;
	/*}#1GAMSM53B7PreState*/
	/*#{1GAMSM53B7PostState*/
	let pandingCodeUpdate=false;
	/*}#1GAMSM53B7PostState*/
	cssVO={
		"hash":"1GAMSM53B7",nameHost:true,
		"type":"view","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":"On","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GAMSOSSI0",
				"type":"hud","id":"BoxEditCode","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1GAN462E40",
						"type":"box","id":"BoxEditGearBtn","x":5,"y":5,"w":30,"h":30,"zIndex":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
						"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
						children:[
							{
								"hash":"1GAN462E42",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/paint.svg",null),"id":"BtnEditGear","x":0,"y":0,"padding":2,
								"tip":"Switch to Design Mode",
								/*#{1GAN462E42Codes*/
								OnClick(){
									self.setEditMode("Gear");
								}
								/*}#1GAN462E42Codes*/
							}
						],
					}
				],
			},
			{
				"hash":"1GAN46EKQ0",
				"type":"hud","id":"BoxEditGear","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1GAMSM53B7ExtraCSS*/
		app:app,editPrj:editPrj,editDoc:editDoc,dataDoc:dataDoc,
		/*}#1GAMSM53B7ExtraCSS*/
		faces:{
			"code":{
				/*BoxEditCode*/"#1GAMSOSSI0":{
					"display":1
				},
				/*BoxEditGear*/"#1GAN46EKQ0":{
					"display":0
				}
			},"gear":{
				/*BoxEditCode*/"#1GAMSOSSI0":{
					"display":0
				},
				/*BoxEditGear*/"#1GAN46EKQ0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GAMSM53B7Create*/
			self.BoxCanvas=self.BoxEditGear;
			makeNotify(self);
			makeObjEventEmitter(self);
			boxEditCode=self.BoxEditCode;
			boxEditGear=self.BoxEditGear;
			codeEditor=boxEditCode.insertNewBefore(DefDocEditor(app,mode,codeText,cfgVO,dataDoc),self.BoxEditGearBtn);
			//Rout all codeEditor events to this:
			codeEditor.emit=this.emit.bind(this);
			codeEditor.emitNotify=this.emitNotify.bind(this);
			codeEditor.on=this.on.bind(this);
			codeEditor.off=this.off.bind(this);
			codeEditor.onNotify=this.onNotify.bind(this);
			codeEditor.offNotify=this.offNotify.bind(this);
			//Trace codeEditor dialog show/off
			{
				let y=self.BoxEditGearBtn.y;
				codeEditor.on("DialogOn",(h)=>{
					self.BoxEditGearBtn.animate({type:"pose",y:y+h,time:80});
				});
				codeEditor.on("DialogOff",(h)=>{
					self.BoxEditGearBtn.animate({type:"pose",y:y,time:80});
				});
			}
			
			self.setEditMode(editState.editorMode||"Gear");
			/*}#1GAMSM53B7Create*/
		},
		/*#{1GAMSM53B7EndCSS*/
		OnFree:function(){
			if(uiForge && uiForge.getCurEditor()===self){
				UIForge.bindToEditor(null);
			}
			if(uiSeg && uiSeg.getCurEditor()===self){
				uiSeg.bindToEditor(null);
			}
		}
		/*}#1GAMSM53B7EndCSS*/
	};
	/*#{1GAMSM53B7PostCSSVO*/
	//************************************************************************
	//Edit mode manages:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.setEditMode=function(mode){
			if(editMode===mode){
				return;
			}
			editMode=mode||"Code";
			if(editMode==="Code"){
				editState.editorMode="Code";
				if(pandingCodeUpdate){
					editDoc.maybeUpdateDocText(false);
					pandingCodeUpdate=false;
				}
				self.showFace("code");
				codeEditor.focus();
			}else{
				editState.editorMode="Gear";
				self.showFace("gear");
				self.setSubEditMode(canvasMode);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.getEditMode=function(){
			return editMode;
		};
		
		//--------------------------------------------------------------------
		cssVO.setSubEditMode=function(mode){
			if(editMode==="Code"){
				canvasMode=mode||"UI";
				return;
			}
			canvasMode=mode||"UI";
			if(canvasMode==="UI"){
				editState.canvasMode="UI";
				if(uiSeg){
					UIAICanvas.bindCanvas(uiSeg,null);
				}
				uiForge=UIForge.bindToEditor(self);
				naviView.showView("NaviDoc");
				infoView.showView("EditObj");
			}else{
				editState.editorMode="SEG";
				if(uiForge){
					//TODO: Hide?
					UIForge.bindToEditor(null);
				}
				if(uiSeg){
					UIAICanvas.bindCanvas(uiSeg,self);
				}else{
					let def;
					//Create UISeg:
					def=UIAICanvas(app,EditFlowSeg,true);
					uiSeg=self.BoxCanvas.appendNewChild(def);
					uiSeg.hold();
					uiSeg.bindToEditor(self);
				}
				naviView.showView("NaviDoc");
				infoView.showView("EditObj");
			}
		};
		
		//-------------------------------------------------------------------
		cssVO.getSubEditor=function(subName){
			switch(subName){
				case "Code":
					return codeEditor;
				case "UI":
					return uiForge;
				case "SEG":
					return uiSeg;
			}
			return null;
		};
	}
	
	//************************************************************************
	//Code Editor related:
	//************************************************************************
	{
		//********************************************************************
		//Editor related:
		//********************************************************************
		{
			//----------------------------------------------------------------
			cssVO.init=async function(){
				return await codeEditor.init();
			};
	
			//----------------------------------------------------------------
			cssVO.applyCfg=function(opts){
				return codeEditor.applyCfg(opts);
			};
			
			//----------------------------------------------------------------
			cssVO.maybeUpdateCode=function(){
				if(editMode==="Code"){
					pandingCodeUpdate=false;
					return true;
				}
				pandingCodeUpdate=true;
				return false;
			};
	
			//----------------------------------------------------------------
			cssVO.setEditText=function(text,undo=true){
				codeEditor.setEditText(text,undo);
			};
			
			//----------------------------------------------------------------
			cssVO.mergeCodeIn=function(text,update=true){
				let docText;
				docText=self.getEditText();
				text=mergeCodeWithSeg(docText,text,editDoc.missingCodeSegs||{});
				if(update){
					self.setEditText(text);
				}
				return text;
			};
	
			//----------------------------------------------------------------
			cssVO.getEditText=function(){
				return codeEditor.getEditText();
			};
			
			//----------------------------------------------------------------
			cssVO.getSelection=function(){
				return codeEditor.getSelection();
			};
	
			//----------------------------------------------------------------
			cssVO.replaceSelection=function(text,select){
				codeEditor.replaceSelection(text,select);
			};
	
			//----------------------------------------------------------------
			cssVO.getSelectionRange=function(){
				return codeEditor.getSelectionRange();
			};
	
			//----------------------------------------------------------------
			cssVO.getCursorPos=function(){
				return codeEditor.getCursorPos();
			};
	
			//----------------------------------------------------------------
			cssVO.getCursorIndex=function(){
				return codeEditor.getCursorIndex();
			};
	
			//----------------------------------------------------------------
			cssVO.getEditVersion=function(){
				return codeEditor.getEditVersion();
			};
			
			//----------------------------------------------------------------
			cssVO.clearHistory=function(){
				return codeEditor.clearHistory();
			}
	
			//----------------------------------------------------------------
			cssVO.focus=function(){
				editDoc.OnDocFocus();
				if(editMode==="Code"){
					codeEditor.focus();
				}else{
					let cm;
					self.showFace("gear");
					cm=canvasMode;
					canvasMode="";
					self.setSubEditMode(cm);
				}
			};
	
			//----------------------------------------------------------------
			cssVO.blur=function(){
				if(editMode==="Code"){
					codeEditor.blur();
				}else{
					//TODO: Code this:
				}
			};
	
			//--------------------------------------------------------------------
			cssVO.gotoLine=function(line){
				if(editMode!=="Code"){
					self.setEditMode("Code");
				}
				return codeEditor.gotoLine(line);
			};
		}
		
		//********************************************************************
		//Work with cody
		//********************************************************************
		{
			//----------------------------------------------------------------
			cssVO.peekUndoAction=function(){
				return codeEditor.peekUndoAction();
			};
	
			//----------------------------------------------------------------
			cssVO.peekRedoAction=function(){
				return codeEditor.peekRedoAction();
			};
	
			//----------------------------------------------------------------
			cssVO.undo=function(){
				let action;
				action=codeEditor.peekUndoAction();
				if(!action){
					return;
				}
				if(editMode==="Code"){
					if(action.doc){
						self.setEditMode("Gear");
					}
				}else{
					if(!action.doc){
						self.setEditMode("Code");
					}
				}
				codeEditor.undo();
			};
	
			//----------------------------------------------------------------
			cssVO.redo=function(){
				let action;
				action=codeEditor.peekRedoAction();
				if(!action){
					return;
				}
				if(editMode==="Code"){
					if(action.doc){
						self.setEditMode("Gear");
					}
				}else{
					if(!action.doc){
						self.setEditMode("Code");
					}
				}
				codeEditor.redo();
			};
	
			//----------------------------------------------------------------
			cssVO.addCodyEditAction=function(action){
				codeEditor.addCodyEditAction(action);
			};
		}
	}
	
	//************************************************************************
	//Forge related:
	//************************************************************************
	{
	}
	
	//------------------------------------------------------------------------
	//Handle shortcut, only handle "Find"/Replace
	cssVO.handleShortcut=function(cmd){
		if(editMode==="Code"){
			if(cmd==="Find"){
				codeEditor.findNext();
				return 1;
			}else if(cmd==="FindNext"){
				codeEditor.findNext();
				return 1;
			}else if(cmd==="FindPre"){
				codeEditor.findPre();
				return 1;
			}else if(codeEditor.handleShortcut){
				return codeEditor.handleShortcut(cmd);
			}
			return 0;
		}else{
			if(canvasMode==="UI"){
				if(uiForge){
					return uiForge.handleShortcut(cmd);
				}
			}else{
				if(uiSeg){
					uiSeg.handleShortcut(cmd);
				}
			}
		}
		return 0;
	};
	/*}#1GAMSM53B7PostCSSVO*/
	return cssVO;
};
/*#{1GAMSM53B7ExCodes*/
//----------------------------------------------------------------------------
UIEditGear.scoreDoc=function(doc){
	let editDoc;
	editDoc=doc.codyDoc;
	if(editDoc && editDoc.hudObj){
		return 100;
	}
	return 0;
};
/*}#1GAMSM53B7ExCodes*/


/*#{1GAMSM53B0EndDoc*/
/*}#1GAMSM53B0EndDoc*/

export default UIEditGear;
export{UIEditGear};
