//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GA554IAH0StartDoc*/
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {DlgPlayFace} from "./DlgPlayFace.js";
/*}#1GA554IAH0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let NaviObjLine=function(app,obj,node,box,indent){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	let name="";
	
	/*#{1GA554IAH7LocalVals*/
	let focused=0;
	let isOpen=0;
	/*}#1GA554IAH7LocalVals*/
	
	/*#{1GA554IAH7PreState*/
	let objDef=obj.objDef;
	name=obj.getName?obj.getName(obj):(obj.showName||obj.def.showName||obj.name||obj.def.name);
	icon=obj.icon||obj.def.icon||objDef.icon||"object.svg";
	icon=(icon[0]==="/")?icon:(appCfg.sharedAssets+"/"+icon);
	/*}#1GA554IAH7PreState*/
	state={
		"name":name,"canOpen":true,
		/*#{1GA554IAH5ExState*/
		/*}#1GA554IAH5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GA554IAH7PostState*/
	let updateInfo=function(){
		let list,name;
		name=obj.getName?obj.getName(obj):(obj.showName||obj.def.showName||obj.name||obj.def.name);
		state.name=name;
		list=obj.getNaviSubList(box.mode);
		if(list){
			list=list.filter(item=>((item instanceof EditObj)||(item instanceof EditArray)));
		}
		state.canOpen=list && list.length>0;
	};
	obj.on("Changed",updateInfo);
	updateInfo();
	/*}#1GA554IAH7PostState*/
	cssVO={
		"hash":"1GA554IAH7",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":cfgSize.naviLineH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GA55DCG30",
				"type":"box","id":"BoxFocus","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],
			},
			{
				"hash":"1GA5QE0OM0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],
			},
			{
				"hash":"1GA55AKLB0",
				"type":BtnIcon("front",16,0,appCfg.sharedAssets+"/collapse.svg",null),"id":"BtnOpen","position":"relative","x":8,"y":"FH/2","anchorY":1,"margin":[0,0,0,indent],
				"anchorX":1,"enable":$P(()=>(state.canOpen),state),"image":appCfg.sharedAssets+"/collapse.svg","padding":2,
				/*#{1GA55AKLB0Codes*/
				OnClick(){
					if(isOpen){
						box.closeNode(node);
					}else{
						box.openNode(node);
					}
				}
				/*}#1GA55AKLB0Codes*/
			},
			{
				"hash":"1GA5PEE9I0",
				"type":"box","id":"BoxFace","position":"relative","x":0,"y":"50%","w":cfgSize.naviLineH-6,"h":cfgSize.naviLineH-6,"anchorY":1,"display":0,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontToolLit,"maskImage":appCfg.sharedAssets+"/faces.svg",
			},
			{
				"hash":"1GA55EL8T0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":cfgSize.naviLineH-6,"h":cfgSize.naviLineH-6,"anchorY":1,"margin":[0,2,0,0],"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontTool,"maskImage":icon,
			},
			{
				"hash":"1GA55MOTL0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.naviLineH,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontTool,"text":$P(()=>(state.name),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"autoW":true,
			},
			{
				"hash":"1GA55RNP80",
				"type":BtnIcon("front",cfgSize.naviLineH-4,0,appCfg.sharedAssets+"/ani.svg",null),"id":"BtnPlay","x":">calc(100% - 5px)","y":"50%","anchorY":1,"anchorX":2,
				"attached":false,"autoLayout":true,"image":appCfg.sharedAssets+"/ani.svg","padding":1,
				/*#{1GA55RNP80Codes*/
				OnClick(){
				}
				/*}#1GA55RNP80Codes*/
			},
			{
				"hash":"1GKET6SBS0",
				"type":BtnIcon("front",cfgSize.naviLineH-4,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnReload","x":">calc(100% - 5px)","y":"50%","anchorY":1,
				"anchorX":2,"attached":obj.isImportFile?true:false,"autoLayout":true,"image":appCfg.sharedAssets+"/redo.svg","padding":1,
				/*#{1GKET6SBS0Codes*/
				OnClick(){
					self.reloadFile();
				}
				/*}#1GKET6SBS0Codes*/
			}
		],
		/*#{1GA554IAH7ExtraCSS*/
		/*}#1GA554IAH7ExtraCSS*/
		faces:{
			"up":{
				/*#{1GA5PT45L0PreCode*/
				/*}#1GA5PT45L0PreCode*/
				/*BoxBG*/"#1GA5QE0OM0":{
					"display":0
				}
			},"over":{
				/*#{1GA5PT7FI0PreCode*/
				/*}#1GA5PT7FI0PreCode*/
				/*BoxBG*/"#1GA5QE0OM0":{
					"display":1,"background":cfgColor.hot
				}
			},"down":{
				/*#{1GA5PTAT80PreCode*/
				/*}#1GA5PTAT80PreCode*/
				/*BoxBG*/"#1GA5QE0OM0":{
					"background":cfgColor.primary,"display":1
				}
			},"focus":{
				/*BoxFocus*/"#1GA55DCG30":{
					"display":1,"background":cfgColor.gntFocus
				},
				/*#{1GA5PTH6I0Code*/
				$(){
					focused=1
				}
				/*}#1GA5PTH6I0Code*/
			},"blur":{
				/*BoxFocus*/"#1GA55DCG30":{
					"background":[255,255,255,0],"display":0
				},
				/*#{1GA5PTKVL0Code*/
				$(){
					focused=0
				}
				/*}#1GA5PTKVL0Code*/
			},"select":{
				/*BoxFocus*/"#1GA55DCG30":{
					"display":1,"background":cfgColor.gntSelected
				},
				/*#{1GA5PTOL50Code*/
				$(){
					focused=0
				}
				/*}#1GA5PTOL50Code*/
			},"open":{
				/*BtnOpen*/"#1GA55AKLB0":{
					"rotate":90
				},
				/*#{1GA79TL840Code*/
				$(){
					isOpen=1;
				}
				/*}#1GA79TL840Code*/
			},"close":{
				/*BtnOpen*/"#1GA55AKLB0":{
					"rotate":0
				},
				/*#{1GA79TS0P0Code*/
				$(){
					isOpen=0;
				}
				/*}#1GA79TS0P0Code*/
			},"faceOn":{
				/*BoxFace*/"#1GA5PEE9I0":{
					"display":1
				}
			},"faceOff":{
				/*BoxFace*/"#1GA5PEE9I0":{
					"display":0
				}
			},"targetOn":{
				/*BoxFocus*/"#1GA55DCG30":{
					"display":1,"background":cfgColor.gntTarget
				}
			},"targetOff":{
				/*BoxFocus*/"#1GA55DCG30":{
					"display":0
				},
				/*#{1GMFI2BL10Code*/
				$(){
					if(focused){
						self.showFace("focus");
					}
				},
				/*}#1GMFI2BL10Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA554IAH7Create*/
			obj.on("AttrAdd",self.OnAttrAdd);
			obj.on("AttrRemove",self.OnAttrRemove);
			obj.on("AttrInsert",self.OnAttrInsert);
			obj.on("AttrMoveUp",self.OnAttrMoveUp);
			obj.on("AttrMoveDown",self.OnAttrMoveDown);
			//obj.on("AttrReplace",self.OnAttrReplace);
			/*}#1GA554IAH7Create*/
		},
		/*#{1GA554IAH7EndCSS*/
		OnFree:function(){
			obj.off("AttrAdd",self.OnAttrAdd);
			obj.off("AttrRemove",self.OnAttrRemove);
			obj.off("AttrInsert",self.OnAttrInsert);
			obj.off("AttrMoveUp",self.OnAttrMoveUp);
			obj.off("AttrMoveDown",self.OnAttrMoveDown);
			//obj.off("AttrReplace",self.OnAttrReplace);
		}
		/*}#1GA554IAH7EndCSS*/
	};
	/*#{1GA554IAH7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrAdd=function(attr){
		if(!isOpen){
			box.openNode(node);
		}else{
			if(attr instanceof EditObj){
				let list,newNode;
				list=obj.getNaviSubList(box.mode);
				if(list && list.indexOf(attr)>=0){
					newNode=box.addNode(attr,node);
					box.OnAddNaviObject && box.OnAddNaviObject(attr,newNode);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAttrInsert=function(attr,idx){
		if(!isOpen){
			box.openNode(node);
		}else{
			if(attr instanceof EditObj){
				let list;
				list=obj.getNaviSubList(box.mode);
				if(list && list.indexOf(attr)>=0){
					//box.addNode(attr,node);
					box.insertNode(idx,attr,node);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAttrRemove=function(attr){
		if(!isOpen){
			return;
		}else{
			let attrNode=box.showObjNode(attr,false,false,false);
			if(attrNode){
				box.removeNode(attrNode);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAttrMoveUp=function(attr){
		if(!isOpen){
			return;
		}else{
			let attrNode=box.showObjNode(attr,false,false,false);
			if(attrNode){
				box.moveNodeUp(attrNode);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAttrMoveDown=function(attr){
		if(!isOpen){
			return;
		}else{
			let attrNode=box.showObjNode(attr,false,false,false);
			if(attrNode){
				box.moveNodeDown(attrNode);
			}
		}
	};
	
	//------------------------------------------------------------------------
	let lastClickTime=0;
	cssVO.OnClick=function(evt){
		if(focused && state.canOpen){
			let time;
			time=Date.now();
			if(time-lastClickTime<500){
				if(isOpen){
					box.closeNode(node);
				}else{
					box.openNode(node);
				}
				lastClickTime=0;
			}else{
				box.OnLineClick(self,obj,node,evt);
				lastClickTime=time;
			}
		}else{
			box.OnLineClick(self,obj,node,evt);
			lastClickTime=Date.now();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.reloadFile=function(){
		obj.prj.reloadCSSFile(obj).then(()=>{
			app.showStateText(`${obj.attrPath} reloaded.`);
		});
	};
	/*}#1GA554IAH7PostCSSVO*/
	return cssVO;
};
/*#{1GA554IAH7ExCodes*/
/*}#1GA554IAH7ExCodes*/


/*#{1GA554IAH0EndDoc*/
/*}#1GA554IAH0EndDoc*/

export default NaviObjLine;
export{NaviObjLine};
