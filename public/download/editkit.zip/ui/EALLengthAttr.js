//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GLF7K6U00StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
/*}#1GLF7K6U00StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALLengthAttr=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GLF7K6U01LocalVals*/
	let attrDef;
	attrDef=attrObj.def;
	/*}#1GLF7K6U01LocalVals*/
	
	/*#{1GLF7K6U01PreState*/
	icon=attrObj.icon||attrDef.icon||(attrDef.def?attrDef.def.icon:null)||"";
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GLF7K6U01PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"value":attrObj.val2ShowText(attrObj.val),
		"hyper":attrObj.hyper,"valText":attrObj.valText,
		/*#{1GLF7K6U14ExState*/
		/*}#1GLF7K6U14ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GLF7K6U01PostState*/
	let txtVal=null;
	let boxBG=null;
	let btnMenu=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	state.hyper=attrObj.hyper||(typeof(attrObj.val)==="string");
	/*}#1GLF7K6U01PostState*/
	cssVO={
		"hash":"1GLF7K6U01",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GLF7V1UR0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GLF7V87U0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GLF7VGD20",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,2],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"autoW":true,
			},
			{
				"hash":"1GLF822Q20",
				"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":"FH/2","display":0,"anchorY":1,
				"enable":$P(()=>(!attrObj.hyper),state),"padding":1,
				/*#{1GLF822Q20Codes*/
				OnClick(){
					self.showMenu();
				}
				/*}#1GLF822Q20Codes*/
			},
			{
				"hash":"1GLF804IG0",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${attrObj.val2ShowText()}`),state),"fontSize":txtSize.smallMid,
				"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
				/*#{1GLF804IG0Codes*/
				flex:"1 0 auto"
				/*}#1GLF804IG0Codes*/
			},
			{
				"hash":"1GLF80ART0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GLF7K6U01ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerLine,
		/*}#1GLF7K6U01ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GLF7V1UR0":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GLF7V1UR0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GLF7V1UR0":{
					"background":cfgColor.lineBodyLit
				}
			},"editOn":{
				/*BoxBG*/"#1GLF7V1UR0":{
					"shadow":true
				},
				/*TxtVal*/"#1GLF804IG0":{
					"display":0
				},
				/*#{1GLF7V1US5Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GLF7V1US5Code*/
			},"editOff":{
				/*BoxBG*/"#1GLF7V1UR0":{
					"shadow":false
				},
				/*TxtVal*/"#1GLF804IG0":{
					"display":1
				},
				/*#{1GLF7V1US6Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GLF7V1US6Code*/
			},"showEdit":{
				/*#{1GLF7V1US7Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GLF7V1US7Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GLF7K6U01Create*/
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			btnMenu=self.BtnMenu;
			/*}#1GLF7K6U01Create*/
		},
		/*#{1GLF7K6U01EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
					btnMenu.display=1;
				}else{
					box.hideMetaMenu(self);
					btnMenu.display=0;
				}
			}
		}
		/*}#1GLF7K6U01EndCSS*/
	};
	/*#{1GLF7K6U01PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper||(typeof(attrObj.val)==="string");
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(attrObj.startEdit){
			attrObj.startEdit(attrObj,self);
		}else{
			app.showDlg(DlgRawEditAttr,{
				line:self,box:box,
				attrObj:attrObj
			});
		}
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=function(){
		let curLen,curEditHudObj,curLiveObj,ownerLen,ownerEditHudObj,ownerLiveObj,ownerLenCode;
		let items=[];
		let delta,rate;
	
		ownerLenCode=attrDef.FVal;
	
		curEditHudObj=attrObj.owner.owner;
		ownerEditHudObj=curEditHudObj.owner.owner;
		curLiveObj=curEditHudObj.liveEdObj;
		ownerLiveObj=ownerEditHudObj.liveEdObj;
		curLen=curLiveObj[attrObj.name];
		switch(ownerLenCode){
			case "FW":
			default:
				ownerLen=ownerLiveObj.clientW;
				break;
			case "FH":
				ownerLen=ownerLiveObj.clientH;
				break;
		}
	
		//Static Number:
		items.push({text:`= ${Math.round(curLen)}`,valText:`${Math.round(curLen)}`});
	
		//Delta to FL:
		if(curLen>0 && ownerLen>curLen){
			delta=ownerLen-curLen;
			items.push({text:`= 100%-${delta}`,valText:`100%-${delta}`});
		}
		
		//Rate to FL:
		if(ownerLen>0){
			rate=(curLen/ownerLen);
			if(rate===0){
			}else if(rate===1){
				items.push({text:`= 100%`,valText:`100%`});
			}else{
				rate=rate*100;
				rate=rate.toFixed(1);
				items.push({text:`= ${rate}%`,valText:`${rate}%`});
			}
		}
		
		//Delta to FL*0.5:
		if(curLen>0 && ownerLen>0){
			delta=curLen-ownerLen*0.5;
			if(delta>0){
				items.push({text:`= 50%+${delta}`,valText:`50%+${delta}`});
			}else if(delta<0){
				items.push({text:`= 50%${delta}`,valText:`50%${delta}`});
			}else{
				items.push({text:`= 50%`,valText:`50%`});
			}
		}
		app.showDlg(DlgMenu,{
			hud:self.BtnMenu,items:items,
			callback:(item,evt)=>{
				if(item){
					box.setAttrByText(attrObj,item.valText);
				}
			}
		});
	};
	/*}#1GLF7K6U01PostCSSVO*/
	return cssVO;
};
/*#{1GLF7K6U01ExCodes*/
EditAttrsBox.regAttrBox("length",EALLengthAttr);
/*}#1GLF7K6U01ExCodes*/


/*#{1GLF7K6U00EndDoc*/
/*}#1GLF7K6U00EndDoc*/

export default EALLengthAttr;
export{EALLengthAttr};
