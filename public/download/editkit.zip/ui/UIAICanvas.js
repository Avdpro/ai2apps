//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1HBPMFQBQ0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {EditPrj} from "../EditPrj.js";
import {EditAttr} from "../EditAttr.js";
import {EditAISeg} from "../aiagent/EditAISeg.js";
import {BtnGear} from "./BtnGear.js";
import {BoxCatalog} from "./BoxCatalog.js";
import {BoxAISeg} from "./BoxAISeg.js";
import {layoutSegs} from "../aiagent/LayoutSeg.js";
let uiCanvas=null;
let curEditor=null;
let copyiedSegVO=null;
/*}#1HBPMFQBQ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIAICanvas=function(app,segDefs,withUI){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxCanvas,boxScroll,boxJoints,boxSegs,boxNewSegMark,boxSelectMark,lineAlignX,lineAlignY,edEditSegName,btnUndo,btnRedo,btnDebug,txtZoom,boxSegDefs,btnImport;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HBPMFQBQ1LocalVals*/
	let appPrj=app.prj;
	let editPrj=appPrj.codyPrj;
	segDefs=segDefs||EditAISeg;
	let curEditor=null;
	let curDoc=null;
	let cfgObj=null;
	let snapGap=5;
	let hotItemHud=null;
	let naviView=app.naviView;
	let infoView=app.infoView;
	let lockAddSeg=false;
	let editState=null;
	let zoom=1;
	let snap=true;
	let curSelSegHuds=[];
	let linkSvg,linkPath;
	let linkSeg1,linkSeg2;
	/*}#1HBPMFQBQ1LocalVals*/
	
	/*#{1HBPMFQBQ1PreState*/
	/*}#1HBPMFQBQ1PreState*/
	/*#{1HBPMFQBQ1PostState*/
	/*}#1HBPMFQBQ1PostState*/
	cssVO={
		"hash":"1HBPMFQBQ1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HBPRFJ7D0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
			},
			{
				"hash":"1HBPVF2SD0",
				"type":"hud","id":"BoxCanvas","x":100,"y":40,"w":">calc(100% - 100px)","h":">calc(100% - 40px)","overflow":1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"",
				children:[
					{
						"hash":"1HC1Q886R0",
						"type":"hud","id":"BoxScroll","x":0,"y":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HC1Q96JT0",
								"type":"hud","id":"BoxJoints","x":0,"y":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1HC1Q998H0",
								"type":"hud","id":"BoxSegs","x":0,"y":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1HC1QGJ7N0",
								"type":"box","id":"BoxNewSegMark","x":106,"y":64,"w":120,"h":50,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0.5],
								"border":2,"borderStyle":2,"corner":[100,20,20,100],
							},
							{
								"hash":"1HC1QGJ7N0",
								"type":"box","id":"BoxSelectMark","x":65,"y":20,"w":120,"h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0.5],
								"border":2,"borderStyle":2,
							},
							{
								"hash":"1I0I0DFV20",
								"type":"box","id":"LineAlignX","x":228,"y":351,"w":100,"h":1,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":[255,0,255,1],
							},
							{
								"hash":"1I0I0F0NH0",
								"type":"box","id":"LineAlignY","x":228,"y":351,"w":1,"h":100,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":[255,0,255,1],
							}
						],
					},
					{
						"hash":"1I0I36L250",
						"type":"edit","id":"EdEditSegName","position":"relative","x":0,"y":0,"w":100,"h":20,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":[0,0,0],"fontSize":txtSize.small,"outline":0,"border":[0,0,1,0],
						"OnBlur":function(event){
							/*#{1I0I3CF540FunctionBody*/
							self.cancelEditSegName();
							/*}#1I0I3CF540FunctionBody*/
						},
						"OnUpdate":function(){
							/*#{1I0I3ET2F0FunctionBody*/
							self.confirmEditSegName();
							/*}#1I0I3ET2F0FunctionBody*/
						},
						"OnCancel":function(){
							/*#{1I0I52HCJ0FunctionBody*/
							self.cancelEditSegName();
							/*}#1I0I52HCJ0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HBPRULAS0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":40,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":[0,0,1,0],"borderColor":cfgColor.lineBodySub,"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HHKON84B0",
						"type":"box","id":"BoxEditCodeBtn","position":"relative","x":0,"y":0,"w":30,"h":30,"zIndex":5,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,"shadowY":1,
						children:[
							{
								"hash":"1HHKON84B2",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/code.svg",null),"id":"BtnEditCode","x":0,"y":0,"padding":2,
								"tip":"Switch to Code Mode",
								"OnClick":function(event){
									/*#{1HHKON84B7FunctionBody*/
									if(curEditor){
										curEditor.setEditMode("Code");
									}
									/*}#1HHKON84B7FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HHKOS5FP0",
						"type":"box","id":"BoxEditUIBtn","position":"relative","x":0,"y":0,"w":30,"h":30,"display":withUI,"zIndex":5,"margin":[0,5,0,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":1,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":0,
						"shadowY":1,
						children:[
							{
								"hash":"1HHKOS5FQ0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/huddock.svg",null),"id":"BtnEditCode","x":0,"y":0,"padding":2,
								"tip":"Switch to UI Editor",
								"OnClick":function(event){
									/*#{1HHKOS5FQ5FunctionBody*/
									if(curEditor){
										curEditor.setSubEditMode("UI");
									}
									/*}#1HHKOS5FQ5FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HBPRULAU17",
						"type":"hud","id":"BoxSettings","position":"relative","x":0,"y":0,"w":"","h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1HGNMP3OC0",
								"type":BtnIcon("front",32,0,appCfg.sharedAssets+"/huddock.svg",null),"id":"BtnEditUI","position":"relative","x":0,"y":0,"display":0,"padding":1,
							},
							{
								"hash":"1HBPRULAU19",
								"type":"hud","id":"BlkUndo","position":"relative","x":0,"y":0,"w":70,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HBPRULAU21",
										"type":"text","id":"TxtBlkUndo","x":3,"y":0,"w":100,"h":txtSize.small,"scale":0.75,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":(($ln==="CN")?("撤销 / 重做:"):("Undo / Redo:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										/*#{1HBPRULAU21Codes*/
										/*}#1HBPRULAU21Codes*/
									},
									{
										"hash":"1HBPRULB00",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnUndo","x":3,"y":12,"padding":1,
										"tip":"Undo (Cmd+Z / Ctrl+Z)",
										/*#{1HBPRULB00Codes*/
										/*}#1HBPRULB00Codes*/
									},
									{
										"hash":"1HBPRULB10",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnRedo","x":33,"y":12,"padding":1,
										"tip":"Redo (Cmd+Shift+Z / Ctrl+Shift+Z)",
										/*#{1HBPRULB10Codes*/
										/*}#1HBPRULB10Codes*/
									}
								],
								/*#{1HBPRULAU19Codes*/
								/*}#1HBPRULAU19Codes*/
							},
							{
								"hash":"1HCPI07FI0",
								"type":BtnText("secondary",100,20,(($ln==="CN")?("重置画布"):("Reset Canvas")),false,""),"position":"relative","x":0,"y":0,"corner":3,
								"OnClick":function(event){
									/*#{1HCPI39QT0FunctionBody*/
									self.resetCanvas();
									/*}#1HCPI39QT0FunctionBody*/
								},
							},
							{
								"hash":"1HBPSB56N0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":20,"margin":[0,3,0,15],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("对齐"):("Snap:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1HBPSBGJ70",
								"type":BtnSwitch(18,true),"id":"BtnSnap","position":"relative","x":0,"y":0,"checked":true,
								/*#{1HBPSBGJ70Codes*/
								OnCheck(check){
									snap=check;
								}
								/*}#1HBPSBGJ70Codes*/
							},
							{
								"hash":"1HRU3MJ6I0",
								"type":BtnText("secondary",100,20,(($ln==="CN")?("调试Agent"):("Debug Agent")),false,""),"id":"BtnDebug","position":"relative","x":0,"y":0,"display":!withUI,
								"margin":[0,0,0,30],"corner":3,
								"OnClick":function(event){
									/*#{1HRU3MJ6J2FunctionBody*/
									self.setupDebug();
									/*}#1HRU3MJ6J2FunctionBody*/
								},
							},
							{
								"hash":"1HTESPMV70",
								"type":BtnIcon("front",28,0,"/~/-tabos/shared/assets/inc.svg",null),"id":"BtnDebugCfg","position":"relative","x":0,"y":0,"display":!withUI,"padding":0,
								"tip":(($ln==="CN")?("在新窗口里调试"):("Debug in new window")),
								"OnClick":function(event){
									/*#{1HTESPMV83FunctionBody*/
									self.setupDebug(true);
									/*}#1HTESPMV83FunctionBody*/
								},
							},
							{
								"hash":"1HE5V3UUQ0",
								"type":BtnText("secondary",100,20,(($ln==="CN")?("重置追踪信息"):("Reset Traces")),false,""),"position":"relative","x":0,"y":0,"display":!withUI,"margin":[0,0,0,20],
								"corner":3,
								"OnClick":function(event){
									/*#{1HE5V3UUQ5FunctionBody*/
									self.resetTraces();
									/*}#1HE5V3UUQ5FunctionBody*/
								},
							},
							{
								"hash":"1HGLKPCU10",
								"type":BtnText("secondary",100,20,(($ln==="CN")?("保存画布"):("Snap Image")),false,""),"position":"relative","x":0,"y":0,"margin":[0,0,0,20],"corner":3,
								"OnClick":function(event){
									/*#{1HGLKPCU15FunctionBody*/
									self.snapImage();
									/*}#1HGLKPCU15FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HBPS5Q4M0",
				"type":"box","id":"BoxCreate","x":0,"y":39,"w":100,"h":">calc(100% - 39px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
				"border":[0,1,0,0],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1HBPS5Q4M2",
						"type":"box","x":10,"y":0,"w":80,"h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
					},
					{
						"hash":"1HBPS5Q4N4",
						"type":"box","id":"BoxZoom","x":5,"y":">calc(100% - 25px)","w":90,"h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
						children:[
							{
								"hash":"1HBPS5Q4N6",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/dec.svg",null),"id":"BtnZoomSub","x":0,"y":2,"padding":0,
								"OnClick":function(event){
									/*#{1HCP5A58R0FunctionBody*/
									self.zoomSub();
									/*}#1HCP5A58R0FunctionBody*/
								},
							},
							{
								"hash":"1HBPS5Q4N17",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnZoomAdd","x":"FW-20","y":2,"padding":0,
								"OnClick":function(event){
									/*#{1HCP5B6TV0FunctionBody*/
									self.zoomAdd();
									/*}#1HCP5B6TV0FunctionBody*/
								},
							},
							{
								"hash":"1HBPS5Q4O7",
								"type":"box","id":"BoxZoomText","x":20,"y":2,"w":"FW-40","h":20,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
								children:[
									{
										"hash":"1HBPS5Q4O9",
										"type":"text","id":"TxtZoom","x":0,"y":0,"w":"FW","h":"FH","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
										"text":"100%","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
									}
								],
								"OnClick":function(event){
									/*#{1HCP5GHRB0FunctionBody*/
									self.zoomMenu();
									/*}#1HCP5GHRB0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HBPS5Q4P0",
						"type":"hud","x":0,"y":1,"w":"100%","h":">calc(100% - 28px)","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HBPS5Q4P15",
								"type":"hud","id":"BoxSegDefs","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[10,0,50,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","contentLayout":"flex-y","itemsAlign":1,
								children:[
									{
										"hash":"1I05OR9660",
										"type":BtnIcon("front",36,0,appCfg.sharedAssets+"/additem.svg",null),"id":"BtnImport","position":"relative","x":0,"y":0,"margin":[5,0,0,0],"padding":0,
										"tip":(($ln==="CN")?("导入更多组件"):("Import more components")),
										"OnClick":function(event){
											/*#{1I06ME1R10FunctionBody*/
											self.showAddOnMenu();
											/*}#1I06ME1R10FunctionBody*/
										},
									}
								],
							}
						],
					}
				],
			}
		],
		/*#{1HBPMFQBQ1ExtraCSS*/
		/*}#1HBPMFQBQ1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxCanvas=self.BoxCanvas;boxScroll=self.BoxScroll;boxJoints=self.BoxJoints;boxSegs=self.BoxSegs;boxNewSegMark=self.BoxNewSegMark;boxSelectMark=self.BoxSelectMark;lineAlignX=self.LineAlignX;lineAlignY=self.LineAlignY;edEditSegName=self.EdEditSegName;btnUndo=self.BtnUndo;btnRedo=self.BtnRedo;btnDebug=self.BtnDebug;txtZoom=self.TxtZoom;boxSegDefs=self.BoxSegDefs;btnImport=self.BtnImport;
			/*#{1HBPMFQBQ1Create*/
			let dragMeta;
			boxNewSegMark.display=false;
			boxSelectMark.display=false;
			editPrj.on("EditSubObj",self.maybeSyncSelects);
			editPrj.on("SelectSubObj",self.maybeSyncSelects);
			editPrj.on("SelectSubObjList",self.maybeSyncSelects);
			dragMeta=VFACT.applyMoveDrag(boxCanvas,null);
			dragMeta.setCallbacks(self.OnCanvasDragStart,self.OnCanvasDrag,self.OnCanvasDragEnd);
			self.initDefBtns();
			edEditSegName.hold();
			boxCanvas.removeChild(edEditSegName);
			this.zoom=1;
			
			linkSvg= document.createElementNS("http://www.w3.org/2000/svg", "svg");
			linkSvg.style.position="absolute";
			linkSvg.style.left="6px";
			linkSvg.style.top="3px";
			linkSvg.style.width="1px";
			linkSvg.style.height="1px";
			linkSvg.style.overflow="unset";
			linkSvg.style.display="none";
			
			linkPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
			linkPath.setAttribute("fill", "none");
			linkPath.setAttribute("stroke-width", "5");
			linkPath.setAttribute("stroke", "rgba(128,0,255,1)");
			linkPath.setAttribute("stroke-dasharray","15 15");
			linkSvg.appendChild(linkPath);
			boxScroll.webObj.appendChild(linkSvg);
			/*}#1HBPMFQBQ1Create*/
		},
		/*#{1HBPMFQBQ1EndCSS*/
		/*}#1HBPMFQBQ1EndCSS*/
	};
	/*#{1HBPMFQBQ1PostCSSVO*/
	//--------------------------------------------------------------------
	let syncSegPose=cssVO.syncSegPose=function(){
		let list,i,n,segHud;
		list=boxSegs.children;
		n=list.length;
		for(i=0;i<n;i++){
			list[i].syncHeaderPose(true);
		}
	};
	
	//--------------------------------------------------------------------
	let getSegByName=function (segsVal,name){
		let list,seg;
		list=segsVal.attrList;
		for(seg of list){
			if(seg.attrHash.id.val===name){
				return seg;
			}
		}
		return null;
	}
	
	//------------------------------------------------------------------------
	function findSegsVal(item){
		let owner;
		do{
			if(item.segsList){
				return item.segsVal;
			}
			item=item.owner;
		}while(item);
		return null;
	}
	
	//************************************************************************
	//Canvas basics:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		cssVO.genDefBtn=function(def){
			return {
				type:BtnGear(app,def),position:"relative",x:0,y:0,drag:2,anchorY:0,margin:[5,0,5,0],
				def:def,
				OnDragStart:function(e){
					this.uiEvent=-1;
					self.OnDefDragStart(this,e);
				},
				OnDrag:function(e,dx,dy){
					self.OnDefDrag(e);
				},
				OnDragEnd:function(e,cancel,dx,dy){
					self.OnDefDragEnd(e,cancel);
					this.uiEvent=1;
				},
			};
		};
	
		//--------------------------------------------------------------------
		cssVO.initDefBtns=function(){
			let catalogs,def,css;
			catalogs=segDefs.getCatalogs();
			btnImport.hold();
			boxSegDefs.removeChild(btnImport);
			for(def of catalogs){
				css=BoxCatalog(def,self.genDefBtn,false);
				boxSegDefs.appendNewChild(css);
			}
			boxSegDefs.firstChild.showFace("open");
			boxSegDefs.appendChild(btnImport);
		};
	
		//--------------------------------------------------------------------
		cssVO.getCurEditor=function(){
			return curEditor;
		};
	
		//--------------------------------------------------------------------
		cssVO.bindToEditor=function(docEditor){
			let dataDoc,editDoc,segsVal;
			function addSeg(seg){
				let subSegs;
				boxSegs.appendNewChild({
					type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
					OnClick:self.OnSegClick,
					OnOutletClick:self.OnOutletClick
				});
				subSegs=seg.segsList;
				if(subSegs){
					let i,n,subSeg;
					n=subSegs.length;
					for(i=0;i<n;i++){
						subSeg=subSegs[i];
						addSeg(subSeg);
					}
				}
			}
	
			//This is major for debug:
			VFACT.AISegCanvas=self;
	
			if(docEditor){
				dataDoc=docEditor.dataDoc;
				editDoc=dataDoc.codyDoc;
			}else{
				dataDoc=null;
				editDoc=null;
			}
			//Trace edit face:
			if(curDoc===editDoc){
				self.updateUndoRedo();
				return;
			}
			curEditor=docEditor;
			if(curDoc){
				curDoc.dropSegLiveObjs();
				curDoc.offNotify("UpdateCode",self.updateUndoRedo);
	
				//Off seg events:
				segsVal=curDoc.segsVal;
				segsVal.off("AttrAdd",self.OnSegAdd);
				segsVal.off("AttrInsert",self.OnSegInsert);
				segsVal.off("AttrRemove",self.OnSegRemove);
				segsVal.off("AttrMoveUp",self.OnSegMoveUp);
				segsVal.off("AttrMoveDown",self.OnSegMoveDown);
				segsVal.off("AttrReplace",self.OnSegReplace);
	
				curDoc.off("SegAttrAdd",self.OnSegAdd);
				curDoc.off("SegAttrInsert",self.OnSegInsert);
				curDoc.off("SegAttrRemove",self.OnSegRemove);
				curDoc.off("SegAttrMoveUp",self.OnSegMoveUp);
				curDoc.off("SegAttrMoveDown",self.OnSegMoveDown);
				curDoc.off("SegAttrReplace",self.OnSegReplace);
			}
			curSelSegHuds.splice(0);
			boxSegs.clearChildren();
			curDoc=editDoc;
			if(curDoc){
				let list,seg;
				editState=editDoc.editState.aiCanvas;
	
				if(editState){
					this.setZoom(editState.zoom);
					boxScroll.x=editState.x;
					boxScroll.y=editState.y;
				}
	
				//Add segs:
				list=editDoc.segsList;
				for(seg of list){
					addSeg(seg);
				}
				{
					let i,n;
					list=boxSegs.children;
					n=list.length;
					for(i=0;i<n;i++){
						list[i].syncHeaderPose();
					}
				}
	
				self.updateUndoRedo();
				curDoc.onNotify("UpdateCode",self.updateUndoRedo);
	
				//Trace seg events:
				segsVal=curDoc.segsVal;
				segsVal.on("AttrAdd",self.OnSegAdd);
				segsVal.on("AttrInsert",self.OnSegInsert);
				segsVal.on("AttrRemove",self.OnSegRemove);
				segsVal.on("AttrMoveUp",self.OnSegMoveUp);
				segsVal.on("AttrMoveDown",self.OnSegMoveDown);
				segsVal.on("AttrReplace",self.OnSegReplace);
	
				curDoc.on("SegAttrAdd",self.OnSegAdd);
				curDoc.on("SegAttrInsert",self.OnSegInsert);
				curDoc.on("SegAttrRemove",self.OnSegRemove);
				curDoc.on("SegAttrMoveUp",self.OnSegMoveUp);
				curDoc.on("SegAttrMoveDown",self.OnSegMoveDown);
				curDoc.on("SegAttrReplace",self.OnSegReplace);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.rebindToEditor=function(){
			if(!curDoc){
				return;
			}
			curDoc.renderPath();
		};
	
		//--------------------------------------------------------------------
		cssVO.saveDocState=function(){
			let state;
			state=curDoc.editState.aiCanvas;
			if(!state){
				curDoc.editState.aiCanvas=state={};
			}
			state.zoom=zoom;
			state.x=boxScroll.x;
			state.y=boxScroll.y;
		};
	
		//--------------------------------------------------------------------
		cssVO.updateUndoRedo=function(){
			let editor,act;
			if(!curDoc){
				return;
			}
			editor=curDoc.dataDoc.editBox;
			if(!editor){
				btnUndo.enable=false;
				btnRedo.enable=false;
				return;
			}
			btnUndo.enable=!!editor.peekUndoAction();
			btnRedo.enable=!!editor.peekRedoAction();
		};
	
	}
	
	//************************************************************************
	//Edit actions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.resetTraces=function(){
			if(!curDoc){
				return;
			}
			curDoc.resetDebugTrace();
		};
		
		//--------------------------------------------------------------------
		cssVO.showAddOnMenu=async function(){
			let items,item;
			items=[
				{text:"Import this File",icon:appCfg.sharedAssets+"/fileadd.svg",code:"This"},
				{text:"Import from File",icon:appCfg.sharedAssets+"/folder.svg",code:"File"},
				{text:"Agent Hub (comming soon)",icon:appCfg.sharedAssets+"/cloud.svg",code:"Cloud",enable:false},
			];
			item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
				hud:btnImport,items:items
			});
			if(!item){
				return;
			}
			if(item.code==="This"){
				self.importAddOnThisDoc();
			}else if(item.code==="File"){
				self.importAddOnByFile();
			}else{
				self.importAddOnByCloud();
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.importAddOnThisDoc=async function(){
			let path,prjCfg;
			prjCfg=appPrj.prjConfig;
			path=curDoc.path;
			if(prjCfg.addOns.indexOf(path)>=0){
				window.alert("Current doc is already imported by this project.");
				return;
			}
			prjCfg.addOns.push(path);
			path=`${appPrj.path}/tabstudio.project.json`;
			await tabFS.writeFile(path,JSON.stringify(prjCfg,null,"\t"),"utf8");
			if(window.confirm((($ln==="CN")?("项目配置已更改，重新加载吗?"):/*EN*/("Project config changed, reload it?")))){
				document.location.reload();
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.importAddOnByFile=async function(){
			let path,prjCfg;
			path=editPrj.path;
			prjCfg=appPrj.prjConfig;
			path=await VFACT.app.modalDlg("/@homekit/ui/DlgFile.js",{
				mode:"open",
				path:path,
				options:{filter:"*.js"}
			});
			if(path){
				prjCfg.addOns.push(path);
				path=`${appPrj.path}/tabstudio.project.json`;
				await tabFS.writeFile(path,JSON.stringify(prjCfg,null,"\t"),"utf8");
				if(window.confirm((($ln==="CN")?("项目配置已更改，重新加载吗?"):/*EN*/("Project config changed, reload it?")))){
					document.location.reload();
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.importAddOnByCloud=async function(){
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		cssVO.editSegName=function(segHud){
			if(!segHud.TxtID.display){
				return;
			}
			edEditSegName.w=segHud.TxtID.w>40?segHud.TxtID.w:40;
			segHud.TxtID.display=false;
			segHud.BoxNames.appendChild(edEditSegName);
			edEditSegName.display=true;
			edEditSegName.text=segHud.seg.getAttrVal("id");
			edEditSegName.focus();
			edEditSegName.segHud=segHud;
		};
		
		//--------------------------------------------------------------------
		cssVO.confirmEditSegName=function(){
			let segHud=edEditSegName.segHud;
			let seg=segHud.seg;
			segHud.TxtID.display=true;
			editPrj.editAttr_SetAttrByText(seg,seg.getAttr("id"),edEditSegName.text);
			edEditSegName.display=false;
			//segHud.BoxNames.removeChild(edEditSegName);
		};
	
		//--------------------------------------------------------------------
		cssVO.cancelEditSegName=function(){
			let segHud=edEditSegName.segHud;
			segHud.TxtID.display=true;
			edEditSegName.display=false;
			//segHud.BoxNames.removeChild(edEditSegName);
		};
	}
	
	//************************************************************************
	//DragCanvas
	//************************************************************************
	{
		let isRangeSelect=false;
		let ox,oy;
		//--------------------------------------------------------------------
		cssVO.OnCanvasDragStart=function(evt){
			let scale=1.0/zoom;
			isRangeSelect=(!!evt.shiftKey)||(!!evt.ctrlKey)||(!!evt.metaKey);
			if(isRangeSelect){
				let x,y,rect;
				rect=boxScroll.getBoundingClientRect();
				x=evt.x-rect.x;
				y=evt.y-rect.y;
				boxSelectMark.display=true;
				boxSelectMark.x=x*scale;
				boxSelectMark.y=y*scale;
				boxSelectMark.w=0;
				boxSelectMark.h=0;
				ox=x*scale;oy=y*scale;
			}else{
				ox=boxScroll.x;oy=boxScroll.y;
				boxSelectMark.display=false;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCanvasDrag=function(evt,tgt,dx,dy){
			let scale=1.0/zoom;
			if(isRangeSelect){
				if(dx<0){
					boxSelectMark.x=ox+dx*scale;
					boxSelectMark.w=-dx*scale;
				}else{
					boxSelectMark.x=ox;
					boxSelectMark.w=dx*scale;
				}
				if(dy<0){
					boxSelectMark.y=oy+dy*scale;
					boxSelectMark.h=-dy*scale;
				}else{
					boxSelectMark.y=oy;
					boxSelectMark.h=dy*scale;
				}
			}else{
				boxScroll.x=ox+dx;
				boxScroll.y=oy+dy;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCanvasDragEnd=function(evt){
			if(isRangeSelect){
				let x1,x2,y1,y2,tmp,rect,huds,hud,hudItem,oldHotHud,scle;
				rect=boxSelectMark.getBoundingClientRect();
				x1=rect.x;
				x2=rect.x+rect.width;
				y1=rect.y;
				y2=rect.y+rect.height;
				huds=self.rangSegHuds(x1,y1,x2,y2);
				oldHotHud=hotItemHud;
				for(hud of huds){
					if(!hotItemHud){
						editPrj.setEditSubObj(hud.seg,false);
						hotItemHud=hud;
					}else{
						editPrj.setEditSubObj(hud.seg,true);
					}
				}
				boxSelectMark.display=false;
				hotItemHud=oldHotHud;
			}
		};
	}
	
	//************************************************************************
	//:Seg/outlet manage:
	//************************************************************************
	{
		let isAboutSync=false;
		//--------------------------------------------------------------------
		cssVO.maybeSyncSelects=function(){
			if(isAboutSync){
				return;
			}
			isAboutSync=true;
			callAfter(self.syncSelects);
		};
		
		//--------------------------------------------------------------------
		cssVO.syncSelects=function(){
			let naviBox,treeBox,hotItem,hud,list,seg,node;
			isAboutSync=false;
			naviBox=EditPrj.boxNaviDoc;
			if(!naviBox){
				return;
			}
			treeBox=naviBox.treeBox;
			hotItem=treeBox.hotNode&&treeBox.hotNode.nodeObj;
			hud=(hotItem?hotItem.liveHudObj:null)||null;
			if(hotItemHud!==hud){
				if(hotItemHud){
					hotItemHud.showFace("blur");
				}
				hotItemHud=hud;
				if(hud){
					hud.showFace("focus");
				}
			}
			self.clearLink();
			
			for(hud of curSelSegHuds){
				hud.showFace("!selected");
			}
			curSelSegHuds.splice(0);
			
			list = treeBox.selected;
			for(node of list){
				seg=node.nodeObj;
				hud=seg.liveHudObj;
				if(hud && hud.seg && hotItemHud!==hud){
					hud.showFace("selected");
					curSelSegHuds.push(hud);
				}
			}
			if(hotItem){
				self.showHotItem(hotItem);
				if(hotItem.isJumper){
					let tgtName,tgtSeg;
					let list,i,n,seg;
					tgtName=hotItem.getAttrVal("seg");
					if(tgtName){
						list=boxSegs.children;
						n=list.length;
						for(i=0;i<n;i++){
							seg=list[i].seg;
							if(seg){
								if(seg.idVal.val===tgtName){
									tgtSeg=seg;
									break;
								}
								if(seg.jaxId===tgtName){
									tgtSeg=seg;
									break;
								}
							}
						}
						if(tgtSeg && tgtSeg.liveHudObj){
							self.drawLinkedSeg(hotItem,tgtSeg);
						}
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		let lastSegClickTime=0;
		cssVO.OnSegClick=async function(evt){//"this" object is the clicked button
			let hud=this;
			let singleSelect=false;
			if(hotItemHud===hud){
				if(hud.seg && (evt.metaKey || evt.ctrlKey)){
					editPrj.deselectEditSubObj(hud.seg,true);
					singleSelect=false;
				}else{
					singleSelect=true;
				}
				if(Date.now()-lastSegClickTime<500){
					self.editSegName(hud);
				}
			}else{
				if(evt && (evt.metaKey || evt.ctrlKey)&& hud.seg){
					if(!hotItemHud){
						editPrj.setEditSubObj(hud.seg);
					}else if(hotItemHud.seg){
						if(curSelSegHuds.indexOf(hud)>=0){
							editPrj.deselectEditSubObj(hud.seg,true);
						}else{
							editPrj.setEditSubObj(hud.seg,true);
						}
					}else{
						editPrj.setEditSubObj(hud.seg);
					}
					singleSelect=false;
				}else{
					editPrj.setEditSubObj(hud.seg||hud.outlet);
					singleSelect=true;
				}
				naviView.showView("NaviDoc");
				infoView.showView("EditObj");
				self.maybeSyncSelects();
			}
	
			if(singleSelect){
				if(evt){
					if(evt.button===2){
						let items,item;
						items=[
							{icon:appCfg.sharedAssets+"/dummy.svg",text:(($ln==="CN")?("选择右侧相关组件"):/*EN*/("Select related components on the right")),code:"SelectRight"},
							{icon:appCfg.sharedAssets+"/trash.svg",text:(($ln==="CN")?("删除组件"):/*EN*/("Delete component")),code:"Delete"},
							{icon:appCfg.sharedAssets+"/flag.svg",text:(($ln==="CN")?("设置组件标记"):/*EN*/("Choose component mark")),code:"Mark"},
						]
						item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud: hud,items:items});
						if(!item)
							return;
						if(item.code==="Delete"){
							self.doRemoveObj();
						}else if(item.code==="Mark"){
							hud.setMark();
						}else if(item.code==="SelectRight"){
							self.selectRight(hud.seg);
						}
						lastSegClickTime=0;
					}else{
						lastSegClickTime=Date.now();
					}
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnOutletClick=function(hud){
			if(hotItemHud===hud){
				return;
			}
			editPrj.setEditSubObj(hud.seg||hud.outlet);
			naviView.showView("NaviDoc");
			infoView.showView("EditObj");
			self.maybeSyncSelects();
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegAdd=function(seg){
			let box;
			if(lockAddSeg){
				return;
			}
			box=boxSegs.appendNewChild({
				type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
				OnClick:self.OnSegClick,
				OnOutletClick:self.OnOutletClick
			});
			box.syncHeaderPose();
			box.scale=0.8;
			box.animate({type:"pose",scale:1,time:50});
			{
				let list,outlet,hud;
				list=seg.linkedOutlets;
				for(outlet of list){
					hud=outlet.liveHudObj;
					if(hud){
						hud.linkToSeg(seg);
					}
				}
			}
			box.OnClick();
		};
	
		//--------------------------------------------------------------------
		cssVO.OnSegRemove=function(seg){
			let box,list,outlet,hud;
			box=seg.liveHudObj;
			if(box){
				boxSegs.removeChild(box);
			}
			list=seg.linkedOutlets;
			for(outlet of list){
				hud=outlet.liveHudObj;
				if(hud){
					hud.linkToSeg(null);
				}
			}
			list=seg.segsList;
			if(list){
				let subSeg;
				for(subSeg of list){
					self.OnSegRemove(subSeg);
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnSegInsert=function(seg,idx){
			let pre;
			if(withUI){
				let owner,preSeg;
				owner=seg.owner;
				preSeg=owner.attrList[idx+1];
				pre=preSeg?preSeg.liveHudObj:null;
				boxSegs.insertNewBefore({
					type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
					OnClick:self.OnSegClick,
					OnOutletClick:self.OnOutletClick
				},pre).syncHeaderPose();
			}else{
				pre=boxSegs.children[idx];
				if(pre){
					boxSegs.insertNewBefore({
						type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
						OnClick:self.OnSegClick,
						OnOutletClick:self.OnOutletClick
					},pre).syncHeaderPose();
				}else{
					boxSegs.appendNewChild({
						type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
						OnClick:self.OnSegClick,
						OnOutletClick:self.OnOutletClick
					},pre).syncHeaderPose();
				}
			}
			//Rebuild links:
			{
				let list,outlet,hud;
				list=seg.linkedOutlets;
				for(outlet of list){
					hud=outlet.liveHudObj;
					if(hud){
						hud.linkToSeg(seg);
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegMoveUp=function(seg){
			let box,pre;
			box=seg.liveHudObj;
			if(box){
				if(withUI){
					let owner,list,idx,preSeg;
					owner=seg.owner;
					list=owner.attrList;
					idx=list.indexOf(seg);
					if(idx>=0){
						preSeg=owner.attrList[idx+1];
					}
					if(preSeg){
						pre=preSeg.liveHudObj;
					}
				}else{
					pre=box.previousSibling;
				}
				if(pre){
					box.hold();
					boxSegs.removeChild(box);
					boxSegs.insertBefore(box,pre);
					box.release();
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegMoveDown=function(seg){
			let next,box;
			box=seg.liveHudObj;
			if(box){
				if(withUI){
					let owner,list,idx,nxtSeg;
					owner=seg.owner;
					list=owner.attrList;
					idx=list.indexOf(seg);
					if(idx>=0){
						nxtSeg=owner.attrList[idx-1];
					}
					if(nxtSeg){
						next=nxtSeg.liveHudObj;
					}
				}else{
					next=box.nextSibling;
				}
				if(next){
					self.OnSegMoveUp(next);
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegReplace=function(seg,oldSeg){
			let box;
			box=oldSeg.liveHudObj;
			if(box){
				boxSegs.insertNewBefore({
					type:BoxAISeg(seg,self),x:seg.getAttr("x").val,y:seg.getAttr("y").val,
					OnClick:self.OnSegClick,
					OnOutletClick:self.OnOutletClick
				},box).syncHeaderPose();
				boxSegs.removeChild(box);
				//Rebuild links:
				{
					let list,outlet,hud;
					list=seg.linkedOutlets;
					for(outlet of list){
						hud=outlet.liveHudObj;
						if(hud){
							hud.linkToSeg(seg);
						}
					}
				}
			}
		};
	}
	
	//************************************************************************
	//:Drag to create
	//************************************************************************
	{
		let ox,oy,boxX,boxY,segDef;
		//--------------------------------------------------------------------
		cssVO.OnDefDragStart=function(btn,evt){
			let rect;
			console.log("Start drag create.");
			ox=evt.x;oy=evt.y;
			rect=boxScroll.getBoundingClientRect();
			boxX=rect.x;boxY=rect.y;
			boxNewSegMark.display=1;
			boxNewSegMark.x=(ox-boxX-60)/zoom;
			boxNewSegMark.y=(oy-boxY)/zoom;
			segDef=btn.def;
			self.clearLink();
		};
		
		//--------------------------------------------------------------------
		cssVO.OnDefDrag=function(evt){
			let x,y;
			x=(evt.x-boxX-60)/zoom;
			y=(evt.y-boxY)/zoom;
			if(snap){
				x=Math.round(x/snapGap)*snapGap;
				y=Math.round(y/snapGap)*snapGap;
			}
			boxNewSegMark.x=x;
			boxNewSegMark.y=y;
		};
		
		//--------------------------------------------------------------------
		cssVO.OnDefDragEnd=function(evt,cancel){
			let dx,dy,x,y,newSeg,css,hud;
			boxNewSegMark.display=0;
			dx=evt.x-ox;dy=evt.y-oy;
			dx=dx<0?-dx:dx;dy=dy<0?-dy:dy;
			if(dx+dy<50){
				//TODO: Create seg at center of the view
				x=200;y=100;
			}else{
				//Create seg at mouse poistion
				x=evt.x-boxX-60;
				y=evt.y-boxY;
				x/=zoom;
				y/=zoom;
			}
			if(snap){
				x=Math.round(x/snapGap)*snapGap;
				y=Math.round(y/snapGap)*snapGap;
			}
			lockAddSeg=true;
			if(withUI){
				let segsVal,item;
				if(segDef.rootOnly){
					segsVal=curDoc.segsVal;
				}else{
					if(hotItemHud){
						item=hotItemHud.seg||hotItemHud.outlet;
						segsVal=findSegsVal(item);
					}
					if(!segsVal){
						segsVal=curDoc.segsVal;
					}
				}
				newSeg=editPrj.editAttr_AddFlowSeg(segsVal,segDef,x,y);
			}else{
				newSeg=editPrj.editAttr_AddFlowSeg(curDoc.segsVal,segDef,x,y);
			}
			css={
				type:BoxAISeg(newSeg,self),x:x,y:y,
				OnClick:self.OnSegClick,
				OnOutletClick:self.OnOutletClick
			};
			hud=boxSegs.appendNewChild(css);
			hud.syncHeaderPose();
			hud.scale=0.8;
			hud.animate({type:"pose",scale:1,time:50});
			hud.OnClick();
			lockAddSeg=false;
			self.editSegName(hud);
			/*
			callAfter(()=>{
				const attr=newSeg.getAttr("id");
				const attrBox=EditPrj.boxEditObj;
				if(attrBox){
					if(attrBox.isFocused){
						attrBox.startEditAttr(attr);
					}else{
						infoView.showView("EditObj").then(view=>{
							view.startEditAttr(attr);
						});
					}
				}else{
					infoView.showView("EditObj").then(view=>{
						view.startEditAttr(attr);
					});
				}
			},10);*/
		};
	}
	
	//************************************************************************
	//:Drag to move seg / points:
	//************************************************************************
	{
		let multiDrag=false;
		let multiDragOX,multiDragOY;
		let savedLinkSeg1,savedLinkSeg2;
		//--------------------------------------------------------------------
		cssVO.OnSegDragStart=function(evt,segHud){
			let hud;
			multiDrag=false;
			if(segHud===hotItemHud){
				if(curSelSegHuds.length>0){
					multiDrag=true;
				}
			}else if(curSelSegHuds.indexOf(segHud)>=0){
				multiDrag=true;
			}
			if(multiDrag){
				multiDragOX=segHud.x;
				multiDragOY=segHud.y;
				for(hud of curSelSegHuds){
					hud.multiDragOX=hud.x;
					hud.multiDragOY=hud.y;
				}
				hud=hotItemHud;
				if(hud){
					hud.multiDragOX=hud.x;
					hud.multiDragOY=hud.y;
				}
			}
			segHud.dragHudX=segHud.x;
			segHud.dragHudY=segHud.y;
			savedLinkSeg1=linkSeg1;
			savedLinkSeg2=linkSeg2;
			self.clearLink();
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegDrag=function(evt,segHud){
			let x,y,seg;
			function dragOneHud(hud,dx,dy){
				if(hud===segHud)
					return;
				hud.x=hud.multiDragOX+dx;
				hud.y=hud.multiDragOY+dy;
				hud.syncHeaderPose();
			}
			x=segHud.x;
			y=segHud.y;
			if(snap){
				segHud.x=Math.round(x/snapGap)*snapGap;
				segHud.y=Math.round(y/snapGap)*snapGap;
				if(segHud.x!==segHud.dragHudX || segHud.y!==segHud.dragHudY){
					segHud.dragHudX=segHud.x;
					segHud.dragHudY=segHud.y;
					self.checkAlignSeg(segHud);
				}
			}
			segHud.syncHeaderPose();
			if(multiDrag){
				let dx,dy,hud;
				dx=segHud.x-multiDragOX;
				dy=segHud.y-multiDragOY;
				hud=hotItemHud;
				if(hud){
					dragOneHud(hud,dx,dy);
				}
				for(hud of curSelSegHuds){
					dragOneHud(hud,dx,dy);
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnSegDragEnd=function(evt,segHud){
			let x,y,seg;
			lineAlignX.display=false;
			lineAlignY.display=false;
			if(multiDrag){
				let hud;
				hud=hotItemHud;
				seg=hud.seg;
				curDoc.startEditAction();
				editPrj.editAttr_MoveFlowSeg(seg,hud.x,hud.y,true);
				hud.showFace("up");
				hud.showFace("focus");
				for(hud of curSelSegHuds){
					seg=hud.seg;
					editPrj.editAttr_MoveFlowSeg(seg,hud.x,hud.y,true);
				}
				curDoc.endEditAction();
			}else{
				x=segHud.x;
				y=segHud.y;
				seg=segHud.seg;
				editPrj.editAttr_MoveFlowSeg(seg,x,y,false);
				if(segHud!==hotItemHud){
					//TODO: Select this one?
				}else{
					segHud.showFace("up");
					segHud.showFace("focus");
				}
			}
			if(savedLinkSeg1){
				self.drawLinkedSeg(savedLinkSeg1,savedLinkSeg2);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.checkAlignSeg=async function(dragHud){
			callAfter(()=>{
				let list,seg,segHud;
				let alignX,alignY,segX,segY;
				let minAlignX,maxAlignX,minAlignY,maxAlignY;
				alignX=dragHud.x;
				alignY=dragHud.y;
				minAlignX=maxAlignX=alignX;
				minAlignY=maxAlignY=alignY;
				list=curDoc.segsList;
				for(seg of list){
					segHud=seg.liveHudObj;
					if(segHud!==dragHud){
						segX=segHud.x;
						segY=segHud.y;
						if(segY===alignY){
							minAlignX=segX<minAlignX?segX:minAlignX;
							maxAlignX=segX>maxAlignX?segX:maxAlignX;
						}
						if(segX===alignX){
							minAlignY=segY<minAlignY?segY:minAlignY;
							maxAlignY=segY>maxAlignY?segY:maxAlignY;
						}
					}
				}
				if(maxAlignX>minAlignX){
					lineAlignX.display=true;
					lineAlignX.x=minAlignX-50;
					lineAlignX.w=maxAlignX-minAlignX+100+dragHud.w;
					lineAlignX.y=alignY;
				}else{
					lineAlignX.display=false;
				}
				if(maxAlignY>minAlignY){
					lineAlignY.display=true;
					lineAlignY.y=minAlignY-50;
					lineAlignY.h=maxAlignY-minAlignY+100;
					lineAlignY.x=alignX;
				}else{
					lineAlignY.display=false;
				}
			},10);
		};
	}
	
	//************************************************************************
	//:Segs / points management:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.createSeg=function(segDef,x,y){
			let newSeg,css,hud;
			let lastSeg,segsList,i,n,seg;
			x=x||100;
			
			segsList=curDoc.segsList;
			if(typeof(segDef)==="string"){
				segDef=segDefs.getDef(segDef);
				if(!segDef){
					return null;
				}
			}
			
			if(!y){
				let sdef;
				n=segsList.length;
				for(i=0;i<n;i++){
					seg=segsList[i];
					sdef=seg.objDef;
					if(sdef.name==="Entry"){
						lastSeg=seg;
					}
				}
				if(lastSeg){
					y=lastSeg.getAttrVal("y")+100;
				}else{
					y=50;
				}
			}
			
			//Avdpro
			lockAddSeg=true;
			newSeg=editPrj.editAttr_AddFlowSeg(curDoc.segsVal,segDef,x,y);
			css={
				type:BoxAISeg(newSeg,self),x:x,y:y,
				OnClick:self.OnSegClick,
				OnOutletClick:self.OnOutletClick
			};
			hud=boxSegs.appendNewChild(css);
			hud.syncHeaderPose();
			hud.scale=0.8;
			hud.animate({type:"pose",scale:1,time:50});
			hud.OnClick();
			lockAddSeg=false;
			return newSeg;
		};
		
		//--------------------------------------------------------------------
		cssVO.removeSeg=function(seg){
		};
	}
	
	//************************************************************************
	//:Pick segs:
	//************************************************************************
	{
		let pickedSegHud=null;
		//--------------------------------------------------------------------
		cssVO.pickSegHud=function(x,y){
			let list,i,n,segHud,rect;
			list=boxSegs.children;
			n=list.length;
			for(i=0;i<n;i++){
				segHud=list[i];
				rect=segHud.headerRect;
				if(x>=rect.x&&y>=rect.y&&x<rect.x+rect.width&&y<rect.y+rect.height){
					return segHud;
				}
			}
			return null;
		};
		
		//--------------------------------------------------------------------
		cssVO.rangSegHuds=function(x1,y1,x2,y2){
			let list,i,n,segHud,rect,segs,rx1,rx2,ry1,ry2,mx1,mx2,my1,my2;
			segs=[];
			list=boxSegs.children;
			n=list.length;
			for(i=0;i<n;i++){
				segHud=list[i];
				if(segHud.seg){
					rect=segHud.getBoundingClientRect();
					rx1=rect.x;rx2=rect.x+rect.width;
					ry1=rect.y;ry2=rect.y+rect.height;
					mx1=x1>rx1?x1:rx1;
					my1=y1>ry1?y1:ry1;
					mx2=x2<rx2?x2:rx2;
					my2=y2<ry2?y2:ry2;
					if(mx2>mx1 && my2>my1){
						segs.push(segHud);
					}
				}
			}
			return segs;
		};
	
		//--------------------------------------------------------------------
		cssVO.setPickedSegHud=function(segHud){
			if(segHud===pickedSegHud){
				return;
			}
			if(pickedSegHud){
				pickedSegHud.showFace("!picked");
			}
			pickedSegHud=segHud;
			if(segHud){
				segHud.showFace("picked");
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.getPickedSegHud=function(){
			return pickedSegHud;
		};
		
		//--------------------------------------------------------------------
		cssVO.creatSegByDragOutlet=async function(outletBox,ptHud,x,y){
			let segDef,rect,boxX,boxY,newSeg,css,outlet,hud;
			outlet=outletBox.outlet;
			rect=boxScroll.getBoundingClientRect();
			boxX=rect.x;boxY=rect.y;
			segDef=await app.modalDlg("/@editkit/DlgChooseSeg.js",{segDefs:segDefs,x:x});
			if(segDef){
				x=x-boxX;
				y=y-boxY;
				x/=zoom;
				y/=zoom;
				if(snap){
					x=Math.round(x/snapGap)*snapGap;
					y=Math.round(y/snapGap)*snapGap;
				}
				lockAddSeg=true;
				if(withUI){
					let segsVal,item;
					if(segDef.rootOnly){
						segsVal=curDoc.segsVal;
					}else{
						item=outlet;
						segsVal=findSegsVal(item);
						if(!segsVal){
							segsVal=curDoc.segsVal;
						}
					}
					newSeg=editPrj.editAttr_AddFlowSeg(segsVal,segDef,x,y);
				}else{
					newSeg=editPrj.editAttr_AddFlowSeg(curDoc.segsVal,segDef,x,y);
				}
				css={
					type:BoxAISeg(newSeg,self),x:x,y:y,
					OnClick:self.OnSegClick,
					OnOutletClick:self.OnOutletClick
				};
				hud=boxSegs.appendNewChild(css);
				hud.syncHeaderPose();
				hud.scale=0.8;
				hud.animate({type:"pose",scale:1,time:50});
				hud.OnClick();
				lockAddSeg=false;
				outletBox.linkToSeg(newSeg);
				self.editSegName(hud);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.selectRight=function(seg){
			let orgHud,orgX,checkedSet;
			
			function checkAttr(attr){
				if(attr.isAIOutlet){
					let seg;
					seg=attr.linkedSeg;
					if(seg){
						checkSeg(seg);
					}
				}else{
					let list,subAttr;
					list=attr.attrList;
					if(list){
						for(subAttr of list){
							checkAttr(subAttr);
						}
					}
				}
			}
			
			function checkSeg(seg){
				let hud;
				if(checkedSet.has(seg)){
					return;
				}
				hud=seg.liveHudObj;
				if(hud && hud.headerRect){
					if(hud.headerRect.x>=orgX){
						checkedSet.add(seg);
						checkAttr(seg);
					}
				}
			}
			
			orgHud=seg.liveHudObj;
			if(!orgHud || !orgHud.headerRect){
				return;
			}
			orgX=orgHud.headerRect.x;
			checkedSet=new Set();
			checkSeg(seg);
			
			if(checkedSet.size>0){
				let allSegs,subSeg;
				allSegs=checkedSet.values();
				for(subSeg of allSegs){
					if(subSeg!==seg){
						editPrj.setEditSubObj(subSeg,true);
					}
				}
				editPrj.setEditSubObj(seg,true);
			}
		};
	}
	
	//************************************************************************
	//:Edit Actions
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doRemoveObj=function(){
			let naviBox;
			naviBox=EditPrj.boxNaviDoc;
			if(!naviBox){
				return;
			}
			if(naviBox){
				naviBox.doDelObj();
			}
			callAfter(self.updateUndoRedo);
			self.maybeSyncSelects();
		};
		
		//--------------------------------------------------------------------
		cssVO.doCopyObj=function(){
			let naviBox,treeBox,hotItem,hud,seg,saveVO;
			naviBox=EditPrj.boxNaviDoc;
			if(!naviBox){
				return;
			}
			treeBox=naviBox.treeBox;
			hotItem=treeBox.hotNode&&treeBox.hotNode.nodeObj;
			hud=(hotItem?hotItem.liveHudObj:null)||null;
			if(!hud)
				return;
			seg=hud.seg;
			if(!seg){
				return;
			}
			saveVO=seg.genSaveVO();
			copyiedSegVO=saveVO;
			callAfter(self.updateUndoRedo);
		};
		
		//-------------------------------------------------------------------
		cssVO.doCutObj=function(){
			//TODO: Code this:
			callAfter(self.updateUndoRedo);
		};
		
		//-------------------------------------------------------------------
		cssVO.doPasteObj=function(){
			let naviBox,treeBox,hotItem,hud,seg,saveVO;
			let x,y,idName,newName,segsVal,newSeg,css,idx;
			if(!copyiedSegVO){
				return;
			}
			idName=copyiedSegVO.attrs.id;
			naviBox=EditPrj.boxNaviDoc;
			if(!naviBox){
				return;
			}
			treeBox=naviBox.treeBox;
			hotItem=treeBox.hotNode&&treeBox.hotNode.nodeObj;
			while(hotItem && !hotItem.isAISeg){
				hotItem=hotItem.owner;
			}
			hud=(hotItem?hotItem.liveHudObj:null)||null;
			if(hud){
				x=hud.x+(hud.w>0?hud.w:0)+20;
				y=hud.y+20;
			}else{
				x=200;y=100;
			}
			lockAddSeg=true;
			//Find segsVal to add to:
			if(withUI){
				let item;
				let segDef,idName;
				segDef=EditAttr.getObjDef(copyiedSegVO.type,copyiedSegVO.def);
				if(segDef && segDef.rootOnly){
					segsVal=curDoc.segsVal;
				}else{
					if(hotItemHud){
						item=hotItemHud.seg||hotItemHud.outlet;
						segsVal=findSegsVal(item);
					}
					if(!segsVal){
						segsVal=curDoc.segsVal;
					}
				}
			}else{
				segsVal=curDoc.segsVal;
			}
			newName=idName;
			idx=0;
			while(getSegByName(segsVal,newName)){
				idx++;
				newName=idName+"_"+idx;
			}
			copyiedSegVO.attrs.id=newName;
			newSeg=editPrj.editAttr_PasteFlowSeg(segsVal,copyiedSegVO,x,y);
			copyiedSegVO.attrs.id=idName;
			css={
				type:BoxAISeg(newSeg,self),x:x,y:y,
				OnClick:self.OnSegClick,
				OnOutletClick:self.OnOutletClick
			};
			hud=boxSegs.appendNewChild(css);
			hud.syncHeaderPose();
			hud.scale=0.8;
			hud.animate({type:"pose",scale:1,time:50});
			hud.OnClick();
			lockAddSeg=false;
			callAfter(self.updateUndoRedo);
		};
		
		//-------------------------------------------------------------------
		cssVO.doUndo=function(){
			let editor,dataDoc;
			if(!curDoc){
				return;
			}
			dataDoc=curDoc.dataDoc;
			editor=dataDoc.editBox;
			if(editor){
				editor.undo();
			}
			callAfter(self.updateUndoRedo);
			self.maybeSyncSelects();
		};
	
		//-------------------------------------------------------------------
		cssVO.doRedo=function(){
			let editor,dataDoc;
			if(!curDoc){
				return;
			}
			dataDoc=curDoc.dataDoc;
			editor=dataDoc.editBox;
			if(editor){
				editor.redo();
			}
			callAfter(self.updateUndoRedo);
			self.maybeSyncSelects();
		};
	}
	
	//************************************************************************
	//:Parse, execute commands
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.getSegById=function(idName){
			let segList,seg;
			segList=curDoc.segsList;
			for(seg of segList){
				if(seg.getAttrVal("id")===idName){
					return seg;
				}
			}
			return null;
		};
		
		//--------------------------------------------------------------------
		cssVO.runEditCommands=async function(cmds){
			let cmd,newSegs,newPaths;
			newSegs=[];
			newPaths=[];
			let act=curDoc.startEditAction();
			for(cmd of cmds){
				switch(cmd.command){
					case "AddPath":{
						let fromSeg,outlet,toSeg;
						fromSeg=self.getSegById(cmd.from);
						toSeg=self.getSegById(cmd.to);
						if(!fromSeg){
							console.error("runEditCommands Error: AddPath can't find from seg: "+cmd.from);
							break;
						}
						outlet=fromSeg.getOutletById(cmd.outlet);
						if(!outlet){
							console.error("runEditCommands Error: AddPath can't find from seg: "+cmd.outlet);
							break;
						}
						editPrj.editAttr_LinkSeg(outlet,toSeg,true);
						newPaths.push(outlet);
						break;
					}
					case "DeletePath":{
						let fromSeg,outlet,toSeg;
						fromSeg=self.getSegById(cmd.from);
						if(!fromSeg){
							console.error("runEditCommands Error: DeletePath can't find from seg: "+cmd.from);
							break;
						}
						outlet=fromSeg.getOutletById(cmd.outlet);
						if(!outlet){
							console.error("runEditCommands Error: DeletePath can't find outlet: "+cmd.outlet);
							break;
						}
						editPrj.editAttr_LinkSeg(outlet,null,true);
						break;
					}
					case "AddSeg":{
						let segVO,segId,segDef,seg,attrs,attrName,attrValue,attr,attrDef;
						let outlets,otid,outlet;
						segVO=cmd.segVO;
						segId=segVO.id;
						segDef=EditAISeg.getDef(segVO.type);
						if(!segDef){
							console.error("runEditCommands Error: AddSeg can't find segType: "+segVO.type);
							break;
						}
						seg=self.getSegById(segVO.id);
						if(seg){
							console.error("runEditCommands Error: AddSeg sed-ID is used: "+segVO.id);
							break;
						}
						seg=editPrj.editAttr_AddFlowSeg(curDoc.segsVal,segDef,0,0);
						//Set init vals:
						attrs=segVO.attributes;
						attrs.id=segVO.id;
						attrs.desc=segVO.desc;
						for(attrName in attrs){
							attrValue=attrs[attrName];
							if(typeof(attrValue)!=="string"){
								attrValue=JSON.stringify(attrValue);
							}
							attr=seg.getAttr(attrName);
							if(!attr){
								attrDef=seg.getAttrDef(attrName);
								if(attrDef){
									attr=editPrj.editAttr_AddAttr(seg,attrDef);
								}else{
									console.warn("runEditCommands Error: AddSeg attr-def not found: "+attrName+" for "+JSON.stringify(segVO));
								}
							}
							if(attr){
								editPrj.editAttr_SetAttrByText(seg,attr,attrValue);
							}
						}
	
						//Init outlets:
						let outletsVal=seg.outletsVal;
						if(outletsVal){
							let list,outletsDef,def,outletVO,attrName,attrVal,attr;
							//First, clear current outlets:
							outletsVal.clearArray();
							outletsDef=outletsVal.def.def;
							outlets=segVO.outlets;
							for(otid in outlets){
								if(otid==="outlet"){
									continue;
								}
								outlet=outlets[otid];
								
								if(!Array.isArray(outlet)){
									outlet=[outlet];
								}
								list=outlet;
								for(outletVO of list){
									//Add this outlet...
									def={type:"aioutlet",def:outletsDef.elementDef,extraAttr:1,navi:"doc"};
									outlet=editPrj.editAttr_AddAttr(seg.outletsVal,def);
									for(attrName in outletVO){
										attrVal=outletVO[attrName];
										if(attrName!=="seg"){
											if(outlet.getAttrDef(attrName)){
												outlet.setAttrByText(attrName,""+attrVal);
											}
										}
									}
								}
							}
						}
						//Mark to layout:
						newSegs.push(seg);
						break;
					}
					case "UpdateSeg":{
						let segVO,segId,segDef,seg,attrs,attrName,attrVal;
						segVO=cmd.segVO;
						segId=segVO.id;
						seg=self.getSegById(segVO.id);
						if(!seg){
							console.error("runEditCommands Error: UpdateSeg can't find seg: "+segVO.id);
							break;
						}
						//Set vals:
						attrs=segVO.attributes;
						for(attrName in attrs){
							attrVal=attrs[attrName];
							if(typeof(attrVal)!=="string"){
								attrVal=JSON.stringify(attrVal);
							}
							editPrj.editAttr_SetAttrByText(seg,attrName,attrVal);
						}
						//TODO: Update outlets?
						
						break;
					}
					case "DeleteSeg":{
						let seg,ownerObj;
						seg=self.getSegById(cmd.id);
						if(!seg){
							console.error("runEditCommands Error: DeleteSeg can't find seg: "+cmd.id);
							break;
						}
						ownerObj=seg.owner;
						editPrj.editAttr_RemoveAttr(ownerObj,seg);
						break;
					}
					case "DelAttr":{
						let obj;
						obj=curDoc.getAttr(cmd.obj);
						if(obj){
							editPrj.editAttr_RemoveAttr(obj,cmd.attr);
						}else{
							console.error("runEditCommands Error: DelAttr can't find obj: "+cmd.obj);
						}
						break;
					}
					case "AddAttr":{
						let obj,attrName,attrDef,attrObj,subAttrs,subAttrText,subAttr;
						obj=curDoc.getAttr(cmd.obj);
						if(obj){
							attrObj=obj.getAttr(cmd.attrName);
							if(!attrObj){
								attrDef={name:cmd.attrName,type:"object",def:"AgentCallArgument"};
								attrObj=editPrj.editAttr_AddAttr(obj,attrDef);
							}
							if(attrObj){
								subAttrs=cmd.attrs;
								for(attrName in subAttrs){
									subAttrText=JSON.stringify(subAttrs[attrName]);
									attrName=attrName==="initValue"?"mockup":attrName;
									attrObj.setAttrByText(attrName,subAttrText,true);
								}
							}
						}else{
							console.error("runEditCommands Error: AddAttr can't find obj: "+cmd.obj);
						}
						break;
					}
					case "SetAttr":{
						let obj,attrName,attrDef,attrObj,subAttrs,subAttrText,subAttr;
						obj=curDoc.getAttr(cmd.obj);
						if(obj){
							attrObj=obj.getAttr(cmd.attrName);
							if(attrObj){
								subAttrs=cmd.attrs;
								for(attrName in subAttrs){
									subAttrText=JSON.stringify(subAttrs[attrName]);
									attrName=attrName==="initValue"?"mockup":attrName;
									editPrj.editAttr_SetAttrByText(attrObj,attrName,subAttrText);
								}
							}else{
								console.error("runEditCommands Error: SetAttr can't find attr: "+cmd.attrName);
							}
						}else{
							console.error("runEditCommands Error: SetAttr can't find obj: "+cmd.obj);
						}
						break;
					}
				}
			}
			self.autoLayoutNewSegs(newSegs);
			curDoc.endEditAction(act);
			await sleep(200);
			curDoc.renderPath();
		};
		
		//--------------------------------------------------------------------
		cssVO.autoLayoutNewSegs=async function(newSegs){
			let allSegs;
			allSegs=curDoc.segsList;
			layoutSegs(newSegs,allSegs);
			//TODO: Code this:
		};
	}
	
	//************************************************************************
	//:Debug agent
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.setupDebug=async function(newApp){
			let args,template,arg,ppts,debugArgs,pptLayout;
			let argName,argType,argVal,orgObj,argObj,voidArgs;

			//Check sync changes before	debug:
			let changed=await app.checkSyncPrj();
			if(false){
				if(!window.confirm((($ln==="CN")?("项目内容发生了改变，是否继续？"):/*EN*/("Project content has changed, do you want to continue?")))){
					return;
				}
			}
			
			orgObj=curDoc.editDebugArgs||null;
			ppts={};
			args=curDoc.arguments.attrList;
			for(arg of args){
				argName=arg.name;
				argType=arg.getAttrVal("type");
				argVal=arg.getAttrVal("mockup");
				ppts[argName]={
					type:argType,label:argName+":",defaultValue:argVal
				};
			}
			voidArgs=!args.length;
			pptLayout=Object.keys(ppts);
			//Add plain text args input:
			ppts["$TextArg"]={
				type:"string",label:"Plain text as arguments:",defaultValue:curDoc.editDebugTextArgs||""
			};
			//Add start options like slowMo/ stepRun options:
			ppts["$DebugSlowMo"]={
				type:"bool",label:"Start in slow-mo:",defaultValue:false
			};
			ppts["$DebugStepRun"]={
				type:"bool",label:"Start in step-run:",defaultValue:false
			};
			pptLayout.push({type:"space",space:20});
			pptLayout.push({type:"line"});
			pptLayout.push("$TextArg");
			pptLayout.push({type:"hint",text:"Debug options:"});
			pptLayout.push("$DebugSlowMo");
			pptLayout.push("$DebugStepRun");
			template={
				title:"Debug agent:",label:"",
				properties:ppts,
				newObject(){return VFACT.newUITemplateObj(this);},
				desc:"Arguments to execute agent:",
				layout:pptLayout
			};
			argObj=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
				hud:btnDebug,width:360,x:(btnDebug.w-360)/2,y:-20,alignX:0,alignY:0,
				template:template,object:orgObj
			});
			if(argObj){
				let opts={};
				if(argObj.$DebugSlowMo){
					opts.slowMo=true;
				}
				if(argObj.$DebugStepRun){
					opts.stepRun=true;
				}
				if(argObj.$TextArg){
					argObj=argObj.$TextArg;
					curDoc.editDebugTextArgs=argObj;
					self.startDebug(argObj,newApp,opts);
			}else{
					delete argObj.$DebugSlowMo;
					delete argObj.$DebugStepRun;
					delete argObj.$TextArg;
					curDoc.editDebugArgs=argObj;
					curDoc.editDebugTextArgs="";
					self.startDebug(voidArgs?null:argObj,newApp,opts);
				}
			}
		};
	
		//--------------------------------------------------------------------
		let runMeta=null;
		cssVO.startDebug=async function(argObj,newApp,opts={}){
			let frames,frame,params;
			if(!runMeta){
				runMeta={
					type:"app",
					name:"Debug Agent",
					caption:"Debug Agent",
					//main:"/@aichat/debug.html",
					main:"/@AgentBuilder/app.html",
					package:"dev",
					catalog:["System"],
					icon:appCfg.sharedAssets+"/agent.svg",
					iconApp:null,
					appFrame:{
						//main:"/@aichat/debug.html",
						main:"/@AgentBuilder/app.html",
						//group:"/@aichat/debug.html",
						group:"/@AgentBuilder/app.html",
						title:"Debug Agent",
						caption:"Debug Agent",
						icon:appCfg.sharedAssets+"/agent.svg",
						multiFrame:true,
						width:1200,height:800,
						maxable:false,
					}
				};
			}
			params={
				title:"Debug Agent",
				file:curDoc.path,isServer:!curDoc.getAttrVal("inBrowser"),prjPath:appPrj.path,prjName:pathLib.basename(appPrj.path),argument:argObj,
				slowMo:!!opts.slowMo,stepRun:!!opts.stepRun
			};
			frames=app.getAppFramesByGroup(runMeta.appFrame.group);
			if(frames && !newApp){
				for(frame of frames){
					app.focusAppFrame(frame);
					frame.reloadPage("/@AgentBuilder/app.html",params);
					return;
				}
			}
			app.newFrameApp(runMeta,params,{});
		};
	}
	
	//************************************************************************
	//:Draw linked segs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.clearLink=function(){
			linkSvg.style.display="none";
			linkSeg1=null;
			linkSeg2=null;
		};
		
		//--------------------------------------------------------------------
		cssVO.drawLinkedSeg=function(fromSeg,toSeg){
			let rect,boxSegsX,boxSegsY,fromSegX,fromSegY,toSegX,toSegY;
			let isShort,dx,dy,len;
			let dir,x,y,kx1,ky1,kx2,ky2,points,adx,ady,hsize;
			let factor=1.0/self.zoom;
			linkSeg1=fromSeg;
			linkSeg2=toSeg;
			rect=boxScroll.getBoundingClientRect();
			boxSegsX=rect.x;
			boxSegsY=rect.y;

			rect=fromSeg.liveHudObj.getBoundingClientRect();
			fromSegX=rect.x-boxSegsX;
			fromSegY=rect.y+rect.height*0.5-boxSegsY;

			rect=toSeg.liveHudObj.getBoundingClientRect();
			toSegX=rect.x-boxSegsX;
			toSegY=rect.y+rect.height*0.5-boxSegsY;
			
			dx=toSegX-fromSegX;
			dy=toSegY-fromSegY;
			adx=dx<0?-dx:dx;
			ady=dy<0?-dy:dy;
			
			if(fromSegY<toSegY){
				fromSegY+=13/factor;
				toSegY-=20/factor;
				dir=[0,1];
			}else{
				fromSegY-=20/factor;
				toSegY+=13/factor;
				dir=[0,-1];
			}
			x=fromSegX;
			y=fromSegY;
			
			if(adx>100){
				hsize=adx*0.25;
			}else if(ady>150||adx>30){
				hsize=60;
			}else{
				hsize=20;
			}

			kx1=x;
			ky1=y+dir[1]*(hsize/factor);

			x=toSegX;
			y=toSegY;
			kx2=x;
			ky2=y-dir[1]*(hsize/factor);
			
			points=`M ${fromSegX*factor},${fromSegY*factor} C ${kx1*factor},${ky1*factor} ${kx2*factor},${ky2*factor} ${toSegX*factor},${toSegY*factor}`;
			linkPath.setAttribute("d", points);
			linkSvg.style.display="";
		};
	}
	
	//-----------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		switch(cmd){
			case "Escape":{
				break;
			}
			case "Delete":{
				if(!edEditSegName.display){
					self.doRemoveObj();
				}
				break;
			}
			case "Copy":
				self.doCopyObj();
				return 1;
			case "Cut":
				self.doCutObj();
				return 1;
			case "Paste":
				self.doPasteObj();
				return 1;
			case "Undo":
				self.doUndo();
				return 1;
			case "Redo":
				self.doRedo();
				return 1;
			case "AICode":{
				let botURL;
				botURL=UIAICanvas.AIHelperURL;
				if(botURL){
					app.showDlg("/@aichat/ui/DlgAIChat.js",{url:botURL,prompt:{canvasUI:self,doc:curDoc},autoClose:true,clearChat:true},"AgentHelper");
				}
				return 1;
			}
		}
	};
	
	//************************************************************************
	//Zoom, show item:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.resetCanvas=function(){
			self.setZoom(1);
			boxScroll.x=0;
			boxScroll.y=0;
		};
		
		//--------------------------------------------------------------------
		cssVO.setZoom=function(newZoom,ani=false){
			let text;
			if(newZoom===zoom)
				return;
			txtZoom.text=""+Math.round(newZoom*100)+"%";
			zoom=this.zoom=newZoom;
			if(ani){
				boxScroll.animate({
					type:"pose",scale:zoom,time:80,
					OnFinish:()=>{
						syncSegPose();
					}
				});
				return;
			}
			//Refresh seg rects...
			boxScroll.scale=zoom;
			syncSegPose();
			return;
		};
		
		//--------------------------------------------------------------------
		cssVO.zoomAdd=function(){
			let curZoom;
			curZoom=parseInt(txtZoom.text);
			if(curZoom<100){
				curZoom+=10
				if(curZoom>100){
					curZoom=100;
				}
			}else{
				curZoom+=50
			}
			curZoom=Math.trunc(curZoom);
			curZoom/=100;
			self.setZoom(curZoom,true);
		};
		
		//--------------------------------------------------------------------
		cssVO.zoomSub=function(){
			let curZoom;
			curZoom=parseInt(txtZoom.text);
			if(curZoom<=100){
				curZoom-=10
				if(curZoom<0){
					curZoom=0;
				}
			}else{
				curZoom-=50
				if(curZoom<100){
					curZoom=100;
				}
			}
			curZoom=Math.trunc(curZoom);
			curZoom/=100;
			self.setZoom(curZoom,true);
		};
		
		//--------------------------------------------------------------------
		cssVO.zoomMenu=function(){
			let items;
			items=[
				{text:"10%", zoom:10},
				{text:"25%", zoom:25},
				{text:"50%", zoom:50},
				{text:"75%", zoom:75},
				{text:"100%", zoom:100},
				{text:"150%", zoom:150},
				{text:"200%", zoom:200},
				{text:"250%", zoom:250},
				{text:"500%", zoom:500},
			];
			app.showDlg("/@StdUI/ui/DlgMenu.js",{
				items:items,hud:self.BoxZoom,
				callback(item){
					let zoom;
					if(!item){
						return;
					}
					zoom=item.zoom;
					if(zoom>0){
						zoom/=100;
						self.setZoom(zoom,true);
					}
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.showHotItem=function(seg){
			let cvsRect,segRect,hud,move,x,y;
			hud=seg.liveHudObj;
			if(!hud){
				return;
			}
			cvsRect=boxCanvas.getBoundingClientRect();
			segRect=hud.getBoundingClientRect();
			segRect.x-=cvsRect.x;
			segRect.y-=cvsRect.y;
			x=boxScroll.x;y=boxScroll.y;
			move=false;
			if(segRect.x<0){
				x+=-segRect.x+50;
				move=true;
			}
			if(segRect.x+segRect.width>cvsRect.width){
				x-=(segRect.x+segRect.width-cvsRect.width)+50;
				move=true;
			}
			if(segRect.y<0){
				y+=-segRect.y+50;
				move=true;
			}
			if(segRect.y+segRect.height>cvsRect.height){
				y-=(segRect.y+segRect.height-cvsRect.height)+50;
				move=true;
			}
			if(move){
				boxScroll.animate({type:"pose",x:x,y:y,time:80});
			}
		};
	}
	
	//************************************************************************
	//Draw canvas
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.snapImage=function(){
			let dataURL,link,name,pos;
			dataURL=self.drawCanvas();
			link = document.createElement("a");
			link.href = dataURL;
			name=curDoc.name;
			pos=name.lastIndexOf(".");
			if(pos>0){
				name=name.substring(0,pos)
			}
			name+=".png";
			link.download = name;
			link.click();
		};
		
		//--------------------------------------------------------------------
		cssVO.drawCanvas=function(){
			let list,segHud,i,n,rect;
			let x1,y1,x2,y2,mx1,mx2,my1,my2,cvsW,cvsH,seg;
			EditAISeg.clearJumpCode();
			list=boxSegs.children;
			n=list.length;
			for(i=0;i<n;i++){
				list[i].jumpSlotCode=null;
			}
			//First, get size:
			mx1=1000000;mx2=0;my1=1000000;my2=0;
			for(i=0;i<n;i++){
				segHud=list[i];
				rect=segHud.getBoundingClientRect();
				x1=rect.x;x2=rect.x+rect.width;
				y1=rect.y;y2=rect.y+rect.height;
				mx1=x1<mx1?x1:mx1;
				mx2=x2>mx2?x2:mx2;
				my1=y1<my1?y1:my1;
				my2=y2>my2?y2:my2;

				seg=segHud.seg;
				if(seg.isJumper){
					let tgtName;
					tgtName=seg.getAttrVal("seg");
					if(tgtName){
						let segs,tgtSeg;
						segs=seg.doc.segsList;
						FindSeg:{
							let seg,i,n;
							n=segs.length;
							for(i=0;i<n;i++){
								seg=segs[i];
								if(seg.jaxId===tgtName){
									tgtSeg=seg;
									break FindSeg;
								}
								if(seg.idVal.val===tgtName){
									tgtSeg=seg;
									break FindSeg;
								}
							}
							tgtSeg=null;
						}
						if(tgtSeg){
							let code=EditAISeg.getJumpCode(tgtSeg);;
							segHud.jumpCode=code;
							if(tgtSeg.liveHudObj){
								tgtSeg.liveHudObj.jumpSlotCode=code;
							}
						}else{
							segHud.jumpCode=null;
						}
					}
				}
			}
			cvsW=mx2-mx1+100;
			cvsH=my2-my1+100;
			//Create canvas and context;
			let cvs = document.createElement("canvas");
			let ctx = cvs.getContext("2d");
			cvs.width = cvsW;
			cvs.height = cvsH;
			ctx.fillStyle="white";
			ctx.strokeStyle="black";
			ctx.fillRect(0,0,cvsW,cvsH);
			ctx.textAlign="left";
			//Render segs:
			for(i=0;i<n;i++){
				segHud=list[i];
				segHud.renderToCanvas(ctx,mx1-50,my1-35);
			}
			
			//Draw caption:
			ctx.fillStyle="rgba(80,80,80,1)";
			ctx.textAlign="center";
			ctx.textBaseline="top";
			ctx.font = "normal 16px arial";
			ctx.fillText(curDoc.name,cvsW*0.5,cvsH-30);
			
			//Generate dataURL:
			return cvs.toDataURL("image/png");
		};
	}
	/*}#1HBPMFQBQ1PostCSSVO*/
	cssVO.constructor=UIAICanvas;
	return cssVO;
};
/*#{1HBPMFQBQ1ExCodes*/
VFACT.classRegs.UIAICanvas=UIAICanvas;
//----------------------------------------------------------------------------
UIAICanvas.scoreDoc=function(doc){
	let editDoc;
	editDoc=doc.codyDoc;
	if(editDoc && editDoc.isAIAgentDoc){
		return 100;
	}
	return 0;
};

//----------------------------------------------------------------------------
UIAICanvas.bindCanvas=function(canvas,docEditor){
	let curEditor;
	curEditor=canvas.getCurEditor();
	if(curEditor){
		if(curEditor===docEditor){
			curEditor.BoxCanvas.appendChild(canvas);
			canvas.rebindToEditor && canvas.rebindToEditor();
			return;
		}
		canvas.saveDocState();
		if(canvas.parent===curEditor.BoxCanvas){
			curEditor.BoxCanvas.removeChild(canvas);
		}
	}
	curEditor=docEditor;
	if(curEditor){
		curEditor.BoxCanvas.appendChild(canvas);
		canvas.bindToEditor(curEditor);
	}
};

//----------------------------------------------------------------------------
UIAICanvas.bindToEditor=function(docEditor){
	if(!uiCanvas){
		let def;
		curEditor=docEditor;
		def=UIAICanvas(docEditor.app);
		uiCanvas=curEditor.BoxCanvas.appendNewChild(def);
		uiCanvas.hold();
		uiCanvas.bindToEditor(curEditor);
		return uiCanvas;
	}
	if(curEditor){
		if(curEditor===docEditor){
			uiCanvas.rebindToEditor && uiCanvas.rebindToEditor();
			return uiCanvas;
		}
		uiCanvas.saveDocState();
		curEditor.BoxCanvas.removeChild(uiCanvas);
	}
	curEditor=docEditor;
	if(curEditor){
		curEditor.BoxCanvas.appendChild(uiCanvas);
		uiCanvas.bindToEditor(curEditor);
		return uiCanvas;
	}
	return null;
};
/*}#1HBPMFQBQ1ExCodes*/

//----------------------------------------------------------------------------
UIAICanvas.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HBPMFQBQ1PreAISpot*/
	/*}#1HBPMFQBQ1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HBPMFQBQ1PostAISpot*/
	/*}#1HBPMFQBQ1PostAISpot*/
	return exposeVO;
};

/*#{1HBPMFQBQ0EndDoc*/
/*}#1HBPMFQBQ0EndDoc*/

export default UIAICanvas;
export{UIAICanvas};
