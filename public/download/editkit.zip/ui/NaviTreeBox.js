//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GA54HEQE0StartDoc*/
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {NaviObjLine} from "./NaviObjLine.js";
/*}#1GA54HEQE0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let NaviTreeBox=function(app,mode){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA54HEQE7LocalVals*/
	let rootObj=null;
	/*}#1GA54HEQE7LocalVals*/
	
	/*#{1GA54HEQE7PreState*/
	/*}#1GA54HEQE7PreState*/
	/*#{1GA54HEQE7PostState*/
	/*}#1GA54HEQE7PostState*/
	cssVO={
		"hash":"1GA54HEQE7",nameHost:true,
		"type":"tree","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"contentLayout":"flex-y","overflow":"hidden scroll","minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"",
		/*#{1GA54HEQE7ExtraCSS*/
		mode:mode,multiSelect:true,
		/*}#1GA54HEQE7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA54HEQE7Create*/
			/*}#1GA54HEQE7Create*/
		},
		/*#{1GA54HEQE7EndCSS*/
		nodeDef(obj,node){
			return NaviObjLine(app,obj,node,self,node.indent*20);
		},
		getSubObjs(obj,node){
			let list;
			list=obj.getNaviSubList(mode);
			if(list){
				return list.filter(item=>((item instanceof EditObj)||item instanceof EditArray));
			}
			return null;
		}
		/*}#1GA54HEQE7EndCSS*/
	};
	/*#{1GA54HEQE7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showRootObj=function(obj){
		let node,subObj;
		rootObj=obj;
		if(Array.isArray(obj)){
			for(subObj of obj){
				node=self.addNode(subObj,null);
				self.openNode(node);
			}
		}else{
			node=self.addNode(obj,null);
			self.openNode(node);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showObjNode=function(obj,openUp=1,focus=1,addSelect=0){
		let node;
		if(!obj)
			return null;
		node=self.getNodeOfObj(obj);
		if(node){
			if(focus){
				self.setHotNode(node,addSelect);
			}else if(addSelect){
				self.selectNode(node);
			}
			return node;
		}
		if(!openUp){
			return null;
		}
		if(obj.owner){
			node=self.showObjNode(obj.owner,1,0);
			if(node){
				self.openNode(node);
			}
			node=self.getNodeOfObj(obj);
			if(node){
				if(focus){
					self.setHotNode(node,addSelect);
				}else if(addSelect){
					self.selectNode(node);
				}
			}
			return node;
		}
		return null;
	};
	/*}#1GA54HEQE7PostCSSVO*/
	return cssVO;
};
/*#{1GA54HEQE7ExCodes*/
/*}#1GA54HEQE7ExCodes*/

NaviTreeBox.gearExport={
	framework: "vfact",
	hudType: "tree",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"mode": {
			"name": "mode", "showName": "mode", "type": "string", "key": true, "fixed": true, "initVal": "\"prj\""
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1GA54HEQE0ExGearInfo*/
	/*}#1GA54HEQE0ExGearInfo*/
};
export default NaviTreeBox;
export{NaviTreeBox};
