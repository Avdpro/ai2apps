//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxSteps} from "/@StdUI/ui/BoxSteps.js";
/*#{1GK8J7OHQ0StartDoc*/
import {EditAttrsBox} from "./EditAttrsBox.js";
/*}#1GK8J7OHQ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALFontPreview=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GK8J7OHQ1LocalVals*/
	let fontObj,urlAttr;
	fontObj=attrObj.owner;
	urlAttr=fontObj.getAttr("url");
	/*}#1GK8J7OHQ1LocalVals*/
	
	/*#{1GK8J7OHQ1PreState*/
	/*}#1GK8J7OHQ1PreState*/
	state={
		"size":16,
		/*#{1GK8J7OHR4ExState*/
		/*}#1GK8J7OHR4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GK8J7OHQ1PostState*/
	state.size=attrObj.val;
	/*}#1GK8J7OHQ1PostState*/
	cssVO={
		"hash":"1GK8J7OHQ1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":60,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GK8JABBV0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			},
			{
				"hash":"1GK8JAKRP0",
				"type":"text","x":20,"y":5,"w":"","h":18,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":$P(()=>(`Preview: ${state.size}px`),state),
				"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GK8JECHH0",
				"type":BoxSteps(18),"x":2,"y":5,
				/*#{1GK8JECHH0Codes*/
				OnStep(d){
					state.size+=d;
					state.size=state.size<8?8:state.size;
				}
				/*}#1GK8JECHH0Codes*/
			},
			{
				"hash":"1GK8JKDMB0",
				"type":"text","id":"TxtPreview","x":5,"y":25,"w":"FW-10","h":35,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
				"text":"ABCDabcd123456","fontSize":$P(()=>(state.size),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1GK8J7OHQ1ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerLine,
		/*}#1GK8J7OHQ1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GK8J7OHQ1Create*/
			box.regAttrLine(attrObj,self);
			urlAttr.traceOn(self.OnFontChange);
			//attrObj.traceOn(self.OnAttrChange);
			/*}#1GK8J7OHQ1Create*/
		},
		/*#{1GK8J7OHQ1EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			urlAttr.traceOff(self.OnFontChange);
			//attrObj.traceOff(self.OnAttrChange);
		},
		/*}#1GK8J7OHQ1EndCSS*/
	};
	/*#{1GK8J7OHQ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnFontChange=function(){
		//TODO: Need delay?
		self.TxtPreview.font="";//Make sure the attr is changed?
		self.TxtPreview.font=fontObj.name;
	};
	cssVO.OnAttrChange=function(){
		state.size=attrObj.val>0?attrObj.val:8;
	};
	/*}#1GK8J7OHQ1PostCSSVO*/
	return cssVO;
};
/*#{1GK8J7OHQ1ExCodes*/
EditAttrsBox.regAttrBox("fontView",EALFontPreview);
/*}#1GK8J7OHQ1ExCodes*/


/*#{1GK8J7OHQ0EndDoc*/
/*}#1GK8J7OHQ0EndDoc*/

export default EALFontPreview;
export{EALFontPreview};
