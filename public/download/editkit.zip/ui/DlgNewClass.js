//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1H1T7ISV50StartDoc*/
import {TMPNewClass} from "../data/AppData.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*}#1H1T7ISV50StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgNewClass=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,boxButtons,btnAI,btnCreate,btnCancel;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO,dvData,createVO;
	app=VFACT.app;
	dlgVO=null;
	createVO=TMPNewClass.newObject();
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	let dvOptions={
		"titleHeight":30,
		"titleSize":18,
		"titleColor":cfgColor["fontBody"],
		"titleBold":true,
		"lineHeight":30,"lineGap":10,
		"labelSize":12,"labelColor":cfgColor["fontBodySub"],"labelLine":true,"labelBold":true,
		"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,
		"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],
		"trace":false,"edit":true,
		"noteSize":12
	};
	/*}#1H1T7ISV51PreState*/
	state={
		"title":"New Data Class",
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":50,"w":420,"h":"","anchorX":1,"padding":[10,10,15,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
				children:[
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1HRKAL3MG0",
						"type":BtnText("success",100,26,"AI Helper",false,""),"id":"BtnAI","position":"relative","x":0,"y":0,"margin":[0,25,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1HRKC4NDQ0FunctionBody*/
							self.doAI();
							/*}#1HRKC4NDQ0FunctionBody*/
						},
					},
					{
						"hash":"1HRK7E12T0",
						"type":BtnText("",100,26,"Create",false,""),"id":"BtnCreate","position":"relative","x":0,"y":0,"margin":[0,10,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1HRKC4I0U0FunctionBody*/
							self.doCreate();
							/*}#1HRKC4I0U0FunctionBody*/
						},
					},
					{
						"hash":"1HRK7KRFE0",
						"type":BtnText("warning",100,26,"Cancel",false,""),"id":"BtnCancel","position":"relative","x":0,"y":0,"corner":3,
						"OnClick":function(event){
							/*#{1HRKC17KG0FunctionBody*/
							app.closeDlg(self);
							/*}#1HRKC17KG0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HRK7IDM20",
				"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 30px)","y":5,"padding":1,
				"OnClick":function(event){
					/*#{1HRK8R8R50FunctionBody*/
					app.closeDlg(self);
					/*}#1HRK8R8R50FunctionBody*/
				},
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnAI=self.BtnAI;btnCreate=self.BtnCreate;btnCancel=self.BtnCancel;
			/*#{1H1T7ISV51Create*/
			//Create DataView:
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		if(!dvData){
			dvData=boxContent.appendNewChild({
				type:DataView(null,"TMPNewClass",createVO,null,dvOptions,null),position:"relative",
				OnEdit(){
					let vo,hasError;
					vo=this.getEditedVO();
					dvData.clearErrorTips();
					hasError=false;
					if(!vo.name){
						hasError=true;
					}
					if(vo.useMockup==="Object"){
						this.showPptLine("mockup");
						btnAI.enable=true;
						try{
							JSON.parse(vo.mockup);
						}catch(err){
							this.showErrorTip("mockup","Error in JSON text.");
							hasError=true;
						}
					}else if(vo.useMockup==="Template"){
						this.showPptLine("mockup");
						btnAI.enable=true;
						try{
							JSON.parse(vo.mockup);
						}catch(err){
							this.showErrorTip("mockup","Error in JSON text.");
							hasError=true;
						}
					}else{
						this.hidePptLine("mockup");
						btnAI.enable=false;
					}
					btnCreate.enable=!hasError;
				}
			});
		}else{
			createVO=TMPNewClass.newObject();
			dvData.setObject("TMPNewClass",createVO,null);
		}
		self.animate({
			type:"in",alpha:0,scale:0.9,time:100,
			OnFinish(){
				dvData.focus();
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doAI=async function(){
		let result,line;
		result=await app.modalDlg("/@aichat/ui/DlgAIChat.js",{
			url:"/@editkit/ai/TemplateHelper.js",
			prompt:"Object",
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		},"TemplateHelper");
		console.log(result);
		if(result.target && result.result){
			line=dvData.getPptLine("mockup");
			line.setText(JSON.stringify(result.result,null,"\t"));
			line=dvData.getPptLine("useMockup");
			line.value=result.target;
			dvData.OnEdit();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCreate=function(){
		let vo,hasError,name;
		vo=dvData.getEditedVO();
		name=vo.name;
		if(dlgVO.curObj.getAttr(name)){
			window.alert(`"Error: name ${name}" is already taken.`);
			return;
		}
		if(dlgVO && dlgVO.callback){
			dlgVO.callback(vo);
		}
		app.closeDlg(self);
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/


/*#{1H1T7ISV50EndDoc*/
/*}#1H1T7ISV50EndDoc*/

export default DlgNewClass;
export{DlgNewClass};
