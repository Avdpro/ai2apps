//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GK6LRS290StartDoc*/
import pathLib from "/@path";
import {DlgRawEditAttr} from "./DlgRawEditAttr.js";
import {DlgFile} from "/@StdUI/ui/DlgFile.js";
import {EditAttrsBox} from "./EditAttrsBox.js";
/*}#1GK6LRS290StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALFileAttr=function(app,attrObj,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnOpen;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon="";
	
	/*#{1GK6LRS291LocalVals*/
	let attrDef,prj,dataPrj;
	attrDef=attrObj.def;
	dataPrj=app.prj;
	prj=dataPrj.codyPrj;
	/*}#1GK6LRS291LocalVals*/
	
	/*#{1GK6LRS291PreState*/
	icon=attrObj.icon||attrDef.icon||(attrDef.def?attrDef.def.icon:null)||"";
	if(icon){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1GK6LRS291PreState*/
	state={
		"name":attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name),"hyper":!!attrObj.hyper,"value":attrObj.val2ShowText(attrObj.val),
		"valText":attrObj.valText,
		/*#{1GK6LRS2A4ExState*/
		/*}#1GK6LRS2A4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GK6LRS291PostState*/
	let txtVal=null;
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GK6LRS291PostState*/
	cssVO={
		"hash":"1GK6LRS291",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GK6MQ82D0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GK6MQHAU0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBody,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GK76KIUP0",
				"type":BtnIcon("front",cfgSize.attrLineH-6,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","position":"relative","x":0,"y":"FH/2","anchorY":1,
				"padding":0,
				/*#{1GK76KIUP0Codes*/
				OnClick(evt){
					self.openPath();
				}
				/*}#1GK76KIUP0Codes*/
			},
			{
				"hash":"1GK6MQML40",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,3,0,2],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.name+":"),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1GK6MQT0C0",
				"type":"text","id":"TxtVal","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":$P(()=>(state.hyper?cfgColor.primary:cfgColor.fontBody),state),"text":$P(()=>(`${state.value}${state.hyper?` =${state.valText}`:""}`),state),
				"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,"flex":true,
				"tip":"aa",
				/*#{1GK6MQT0C0Codes*/
				/*}#1GK6MQT0C0Codes*/
			},
			{
				"hash":"1GK6MR3HE0",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GK6LRS291ExtraCSS*/
		attrObj:attrObj,ownerLine:ownerLine,
		/*}#1GK6LRS291ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GK6MQ82D0":{
					"background":cfgColor.body
				}
			},"down":{
				/*BoxBG*/"#1GK6MQ82D0":{
					"background":cfgColor.lineBodyLit
				}
			},"over":{
				/*BoxBG*/"#1GK6MQ82D0":{
					"background":cfgColor.hot
				}
			},"editOn":{
				/*BoxBG*/"#1GK6MQ82D0":{
					"shadow":true
				},
				/*TxtVal*/"#1GK6MQT0C0":{
					"display":0
				},
				/*#{1GK6MQ82F6Code*/
				$(vo){
					if(vo && vo.dlgH>0){
						self.h=cfgSize.attrLineH+vo.dlgH;
					}
				}
				/*}#1GK6MQ82F6Code*/
			},"editOff":{
				/*BoxBG*/"#1GK6MQ82D0":{
					"shadow":false
				},
				/*TxtVal*/"#1GK6MQT0C0":{
					"display":1
				},
				/*#{1GK6MQ82F7Code*/
				$(vo){
					self.h=cfgSize.attrLineH;
				}
				/*}#1GK6MQ82F7Code*/
			},"showEdit":{
				/*#{1GK6MQ82F8Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GK6MQ82F8Code*/
			}
		},
		OnCreate:function(){
			self=this;
			btnOpen=self.BtnOpen;
			/*#{1GK6LRS291Create*/
			boxBG=self.BoxBG;
			txtVal=self.txtVal;
			box.regAttrLine(attrObj,self);
			attrObj.traceOn(self.OnAttrChange);
			/*}#1GK6LRS291Create*/
		},
		/*#{1GK6LRS291EndCSS*/
		OnFree:function(){
			box.unregAttrLine(attrObj,self);
			attrObj.traceOff(self.OnAttrChange);
		},
		OnMouseInOut:function(isIn){
			if(box){
				if(isIn){
					box.showMetaMenu(self);
					if(state.hyper){
						app.showStateText(`${state.name}: ${state.value}${state.hyper?` = ${state.valText}`:""}`);
					}else if(attrDef.info){
						app.showStateText(`${state.name}: ${attrDef.info}`);
					}
				}else{
					box.hideMetaMenu(self);
				}
			}
		}
		/*}#1GK6LRS291EndCSS*/
	};
	/*#{1GK6LRS291PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnAttrChange=function(){
		state.name=attrObj.getName?attrObj.getName():(attrObj.showName||attrDef.showName||attrObj.name||attrDef.name);
		state.value=attrObj.val2ShowText(attrObj.val);
		state.valText=attrObj.valText;
		state.hyper=attrObj.hyper;
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(evt){
		if(evt.button===0){
			self.startEdit();
		}else{
			box.metaMenu.showMenu(self);
		}
	};
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(attrObj.startEdit){
			attrObj.startEdit(attrObj,self);
		}else{
			app.showDlg(DlgRawEditAttr,{
				line:self,box:box,
				attrObj:attrObj
			});
		}
	};
	//------------------------------------------------------------------------
	cssVO.openPath=async function(){
		let path;
		let def=attrDef;
		if(def.showMenu){
			let result;
			result=await def.showMenu(attrObj,btnOpen,self,box);
			if(result){
				return;
			}
		}
		path=attrObj.val;
		if(path){
			path=pathLib.dirname(path);
		}else{
			path=prj.path;
		}
		app.showDlg(DlgFile,{
			mode:"open",
			path:path,
			buttonText:(($ln==="CN")?("选择"):/*EN*/("Select")),
			options:{
				multiSelect:0,
				preview:1,
			},
			callback:async function(filePath){
				let doc;
				if(!filePath){
					return;
				}
				try{
					if(filePath.startsWith(prj.path)){
						filePath=filePath.substring(prj.path.length+1);
					}
					box.setAttrByText(attrObj,filePath);
				}catch(e){
				}
			}
		});
	};
	/*}#1GK6LRS291PostCSSVO*/
	cssVO.constructor=EALFileAttr;
	return cssVO;
};
/*#{1GK6LRS291ExCodes*/
EditAttrsBox.regAttrBox("file",EALFileAttr);
EditAttrsBox.regAttrBox("url",EALFileAttr);
/*}#1GK6LRS291ExCodes*/

//----------------------------------------------------------------------------
EALFileAttr.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GK6LRS291PreAISpot*/
	/*}#1GK6LRS291PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GK6LRS291PostAISpot*/
	/*}#1GK6LRS291PostAISpot*/
	return exposeVO;
};

/*#{1GK6LRS290EndDoc*/
/*}#1GK6LRS290EndDoc*/

export default EALFileAttr;
export{EALFileAttr};
