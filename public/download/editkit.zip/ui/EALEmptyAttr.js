//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1GA9PN5S10StartDoc*/
/*}#1GA9PN5S10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALEmptyAttr=function(app,editObj,attrDef,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=attrDef.icon?(appCfg.sharedAssets+"/"+attrDef.icon):"";
	let name=attrDef.showName||attrDef.name;
	
	/*#{1GA9PN5S17LocalVals*/
	/*}#1GA9PN5S17LocalVals*/
	
	/*#{1GA9PN5S17PreState*/
	/*}#1GA9PN5S17PreState*/
	state={
		"name":attrDef.showName||attrDef.name,
		/*#{1GA9PN5S15ExState*/
		/*}#1GA9PN5S15ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GA9PN5S17PostState*/
	let boxBG=null;
	let showEditAni=[{borderWidth:"0px 10px 0px 0px",borderColor:"#00A000"},{borderWidth:"0px",borderColor:"rgba(0,128,0,0)"}];
	/*}#1GA9PN5S17PostState*/
	cssVO={
		"hash":"1GA9PN5S17",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":cfgSize.attrLineH,"autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"",
		"maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GA9PVJG50",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
			},
			{
				"hash":"1GA9Q8A540",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":cfgSize.attrLineH,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":name,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"autoW":true,
			},
			{
				"hash":"1GA9QCJF90",
				"type":"box","id":"BoxAddIcon","position":"relative","x":0,"y":"FH/2","w":22,"h":22,"anchorY":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.lineBody,"maskImage":appCfg.sharedAssets+"/inc.svg",
			},
			{
				"hash":"1GA9Q7SKU0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"FH/2","w":cfgSize.attrLineH-6,"h":cfgSize.attrLineH-6,"anchorY":1,"margin":[0,0,0,2],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodySub,"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1GA9QGFB10",
				"type":"box","x":0,"y":"100%","w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			}
		],
		/*#{1GA9PN5S17ExtraCSS*/
		ownerLine:ownerLine,
		/*}#1GA9PN5S17ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1GA9PVJG50":{
					"background":cfgColor.body
				}
			},"over":{
				/*BoxBG*/"#1GA9PVJG50":{
					"background":cfgColor.hot
				}
			},"down":{
				/*BoxBG*/"#1GA9PVJG50":{
					"background":cfgColor.lineBodyLit
				}
			},"showEdit":{
				/*#{1GDV403HQ0Code*/
				$(){
					boxBG.webObj.animate(showEditAni,5000);
				}
				/*}#1GDV403HQ0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA9PN5S17Create*/
			boxBG=self.BoxBG;
			/*}#1GA9PN5S17Create*/
		},
		/*#{1GA9PN5S17EndCSS*/
		nullAttrName:attrDef.name
		/*}#1GA9PN5S17EndCSS*/
	};
	/*#{1GA9PN5S17PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnClick=function(){
		box.addEmptyAttr(editObj,attrDef);
	};
	/*}#1GA9PN5S17PostCSSVO*/
	return cssVO;
};
/*#{1GA9PN5S17ExCodes*/
/*}#1GA9PN5S17ExCodes*/


/*#{1GA9PN5S10EndDoc*/
/*}#1GA9PN5S10EndDoc*/

export default EALEmptyAttr;
export{EALEmptyAttr};
