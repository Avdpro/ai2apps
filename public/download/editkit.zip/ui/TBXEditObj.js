//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {EditAttrsBox} from "./EditAttrsBox.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GAB0NN7A0StartDoc*/
import {EditPrj} from "../EditPrj.js";
/*}#1GAB0NN7A0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXEditObj=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GAB0NN7A7LocalVals*/
	let appPrj,editPrj,dataDocs;
	let isFocused;
	let boxAttrs;
	appPrj=app.prj;
	dataDocs=appPrj.docs;
	editPrj=appPrj.codyPrj;
	isFocused=0;
	/*}#1GAB0NN7A7LocalVals*/
	
	/*#{1GAB0NN7A7PreState*/
	/*}#1GAB0NN7A7PreState*/
	/*#{1GAB0NN7A7PostState*/
	/*}#1GAB0NN7A7PostState*/
	cssVO={
		"hash":"1GAB0NN7A7",nameHost:true,
		"type":"hud","id":"TBXEditObj","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GAB0QJBV0",
				"type":EditAttrsBox(app,view),"id":"BoxAttrs","x":0,"y":0,
			},
			{
				"hash":"1GAB0OPPP0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"100%","h":30,"autoLayout":true,"padding":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1GAB0OPPP2",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnReload","position":"relative","x":0,"y":"FH/2","display":0,"anchorY":1,
						"padding":1,
						/*#{1GAB0OPPP2Codes*/
						/*}#1GAB0OPPP2Codes*/
					},
					{
						"hash":"1IA66SDDA0",
						"type":"box","position":"relative","x":0,"y":0,"w":26,"h":26,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"maskImage":appCfg.sharedAssets+"/ghost.svg",
					},
					{
						"hash":"1GAB16BJ60",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("对象属性"):("Object Attributes")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,
					}
				],
			}
		],
		/*#{1GAB0NN7A7ExtraCSS*/
		/*}#1GAB0NN7A7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GAB0NN7A7Create*/
			boxAttrs=self.BoxAttrs;
			EditPrj.boxEditObj=self;
			//Tool bar			
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			
			//Trace EditPrj:
			editPrj.on("EditSubObj",()=>{self.showEditObj()});
			self.showEditObj();
			/*}#1GAB0NN7A7Create*/
		},
		/*#{1GAB0NN7A7EndCSS*/
		get $$isFocused(){
			return isFocused;
		}
		/*}#1GAB0NN7A7EndCSS*/
	};
	/*#{1GAB0NN7A7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showEditObj=function(){
		let edObj;
		edObj=editPrj.curEditSubObj;
		boxAttrs.setEditObj(edObj);
	};
	
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		boxAttrs.setEditObj(null);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		isFocused=1;
		self.showEditObj();
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		isFocused=0;
		self.clear();
	};
	
	//------------------------------------------------------------------------
	cssVO.startEditAttr=function(attr){
		boxAttrs.startEditAttr(attr);
	};
	/*}#1GAB0NN7A7PostCSSVO*/
	cssVO.constructor=TBXEditObj;
	return cssVO;
};
/*#{1GAB0NN7A7ExCodes*/
TBXEditObj.tbxCodeName="EditObj";
TBXEditObj.tbxTip=(($ln==="CN")?("编辑对象属性"):/*EN*/("Object Attributes"));
TBXEditObj.tbxIcon=appCfg.sharedAssets+"/config.svg";
TBXEditObj.tbxIconPad=2;
/*}#1GAB0NN7A7ExCodes*/

//----------------------------------------------------------------------------
TBXEditObj.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GAB0NN7A7PreAISpot*/
	/*}#1GAB0NN7A7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GAB0NN7A7PostAISpot*/
	/*}#1GAB0NN7A7PostAISpot*/
	return exposeVO;
};

/*#{1GAB0NN7A0EndDoc*/
/*}#1GAB0NN7A0EndDoc*/

export default TBXEditObj;
export{TBXEditObj};
