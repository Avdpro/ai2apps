//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {EALGroupBtn} from "./EALGroupBtn.js";
/*#{1GA8M784R0StartDoc*/
/*}#1GA8M784R0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EALGroup=function(app,group,box,ownerLine){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GA8M784R7LocalVals*/
	let isOpen;
	let groupName=group.name;
	let editAttrState=null;
	/*}#1GA8M784R7LocalVals*/
	
	/*#{1GA8M784R7PreState*/
	/*}#1GA8M784R7PreState*/
	/*#{1GA8M784R7PostState*/
	/*}#1GA8M784R7PostState*/
	cssVO={
		"hash":"1GA8M784R7",nameHost:true,
		"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"","autoLayout":true,"margin":[0,0,2,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"background":[255,255,255,1],"shadow":true,"shadowX":0,"shadowBlur":2,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
		children:[
			{
				"hash":"1GA8MTDQV0",
				"type":EALGroupBtn(app,group,box),"id":"BtnGroup","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1GA8N10PK0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.gntLine,
			},
			{
				"hash":"1GA8N15M60",
				"type":"hud","id":"BoxLines","position":"relative","x":20,"y":0,"w":">calc(100% - 20px)","h":"","autoLayout":true,"display":0,"padding":[0,0,5,0],
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1GA8M784R7ExtraCSS*/
		ownerLine:ownerLine,groupName:groupName,
		/*}#1GA8M784R7ExtraCSS*/
		faces:{
			"open":{
				"#1GA8N10PK0":{
					"display":1
				},
				/*BoxLines*/"#1GA8N15M60":{
					"display":1
				},
				/*#{1GA8N0J1V0Code*/
				"BtnGroup":{face:"open"},
				$(){
					isOpen=1;
					if(editAttrState){
						editAttrState.openGroup[groupName]=1;
					}
				}
				/*}#1GA8N0J1V0Code*/
			},"close":{
				/*BoxLines*/"#1GA8N15M60":{
					"display":0
				},
				/*#{1GA8N0MIR0Code*/
				"BtnGroup":{face:"close"},
				$(){
					isOpen=0;
					if(editAttrState){
						editAttrState.openGroup[groupName]=0;
					}
				}
				/*}#1GA8N0MIR0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GA8M784R7Create*/
			self.boxLines=self.BoxLines;
			if(group.open){
				self.open();
			}
			/*}#1GA8M784R7Create*/
		},
		/*#{1GA8M784R7EndCSS*/
		ownerLine:ownerLine,isGroup:1,
		/*}#1GA8M784R7EndCSS*/
	};
	/*#{1GA8M784R7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.open=function(){
		self.showFace("open");
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		self.showFace("close");
	};
	
	//------------------------------------------------------------------------
	cssVO.bindEditState=function(state){
		editAttrState=state;
		if(editAttrState.openGroup[groupName]){
			self.open();
		}
	};
	/*}#1GA8M784R7PostCSSVO*/
	return cssVO;
};
/*#{1GA8M784R7ExCodes*/
/*}#1GA8M784R7ExCodes*/


/*#{1GA8M784R0EndDoc*/
/*}#1GA8M784R0EndDoc*/

export default EALGroup;
export{EALGroup};
