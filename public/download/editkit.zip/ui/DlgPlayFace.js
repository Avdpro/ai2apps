//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GDCV8N0P0StartDoc*/
/*}#1GDCV8N0P0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgPlayFace=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GDCV8N0P7LocalVals*/
	let txtInfo;
	let dlgVO,doc,faceTag,faceName,curFaceTag;
	/*}#1GDCV8N0P7LocalVals*/
	
	/*#{1GDCV8N0P7PreState*/
	/*}#1GDCV8N0P7PreState*/
	/*#{1GDCV8N0P7PostState*/
	/*}#1GDCV8N0P7PostState*/
	cssVO={
		"hash":"1GDCV8N0P7",nameHost:true,
		"type":"box","x":0,"y":0,"w":"FW","h":cfgSize.headerH,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.secondary,
		children:[
			{
				"hash":"1GDCVQ7D80",
				"type":"text","id":"TxtInfo","x":10,"y":0,"w":100,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontPrimary,"text":"Playing face: Focus",
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1GDCVTQ2D0",
				"type":BtnText("warning",80,24,"Cancel",false,""),"x":"FW-90","y":"FH/2","text":"Cancel","anchorY":1,"corner":3,
				/*#{1GDCVTQ2D0Codes*/
				OnClick(){
					self.cancelPlay();
				}
				/*}#1GDCVTQ2D0Codes*/
			}
		],
		/*#{1GDCV8N0P7ExtraCSS*/
		/*}#1GDCV8N0P7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GDCV8N0P7Create*/
			txtInfo=self.TxtInfo;
			/*}#1GDCV8N0P7Create*/
		},
		/*#{1GDCV8N0P7EndCSS*/
		/*}#1GDCV8N0P7EndCSS*/
	};
	/*#{1GDCV8N0P7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		doc=vo.doc;
		faceTag=vo.faceTag;
		curFaceTag=faceTag;
		faceName=faceTag.getName();
		txtInfo.text=`Playing face: ${faceName}`;
		doc.on("PlayFace",self.OnPlayFace);
		doc.on("PlayFaceFin",self.OnPlayFaceFin);
		doc.on("PlayFaceCancel",self.OnPlayFaceCancel);
		doc.playFaceTag(faceTag);
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(canceled){
		doc.off("PlayFaceFin",self.OnPlayFaceFin);
		doc.off("PlayFaceAtFace",self.OnPlayFaceAtFace);
		app.closeDlg(self);
		if(dlgVO.callback){
			if(canceled){
				dlgVO.callback(null);
			}else{
				dlgVO.callback(curFaceTag);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelPlay=function(){
		doc.cancelFacePlay();
	};
	
	//------------------------------------------------------------------------
	cssVO.OnPlayFaceFin=function(){
		self.close(false);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnPlayFaceCancel=function(){
		self.close(true);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnPlayFace=function(face){
		if(face!==curFaceTag){
			curFaceTag=face;
			faceName=face.getName();
			txtInfo.text=`Playing face: ${faceName}`;
		}
	};
	/*}#1GDCV8N0P7PostCSSVO*/
	return cssVO;
};
/*#{1GDCV8N0P7ExCodes*/
/*}#1GDCV8N0P7ExCodes*/


/*#{1GDCV8N0P0EndDoc*/
/*}#1GDCV8N0P0EndDoc*/

export default DlgPlayFace;
export{DlgPlayFace};
