//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HJNUUQMD0StartDoc*/
import {BtnGear} from "./BtnGear.js";
import {BoxCatalog} from "./BoxCatalog.js";
/*}#1HJNUUQMD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgChooseSeg=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxList;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HJNUUQMD1LocalVals*/
	const app=VFACT.app;
	let inited=false;
	let segDefs=null;
	/*}#1HJNUUQMD1LocalVals*/
	
	/*#{1HJNUUQMD1PreState*/
	/*}#1HJNUUQMD1PreState*/
	/*#{1HJNUUQMD1PostState*/
	/*}#1HJNUUQMD1PostState*/
	cssVO={
		"hash":"1HJNUUQMD1",nameHost:true,
		"type":"view","x":0,"y":50,"w":120,"h":">calc(100% - 100px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HJNV0K2R0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":2,
				"corner":6,"shadow":true,"shadowX":5,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HJNV43L50",
				"type":"hud","id":"BoxList","x":5,"y":25,"w":">calc(100% - 10px)","h":">calc(100% - 50px)","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-y",
			},
			{
				"hash":"1HJNV8FGQ0",
				"type":"box","x":">calc(100% - 30px)","y":0,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],"corner":15,
				children:[
					{
						"hash":"1HJNVBS2O0",
						"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":"50%","y":"50%","anchorX":1,"anchorY":1,"padding":1,
						"OnClick":function(event){
							self.btnCloseOnClick(this,event);
						},
					}
				],
			}
		],
		/*#{1HJNUUQMD1ExtraCSS*/
		/*}#1HJNUUQMD1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxList=self.BoxList;
			/*#{1HJNUUQMD1Create*/
			/*}#1HJNUUQMD1Create*/
		},
		/*#{1HJNUUQMD1EndCSS*/
		/*}#1HJNUUQMD1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.btnCloseOnClick=async function(sender,event){
		/*#{1HJO02VPL0Start*/
		app.closeDlg(self,null);
		/*}#1HJO02VPL0Start*/
	};
	/*#{1HJNUUQMD1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.genDefBtn=function(def){
		return {
			type:BtnGear(app,def),position:"relative",x:0,y:0,anchorY:0,margin:[5,0,5,0],
			def:def,
			OnClick(){
				app.closeDlg(self,def);
			}
		};
	};
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		if(inited){
			if(segDefs===vo.segDefs){
				self.x=(vo.x)||300;
				self.animate({type:"pose",x:vo.x-50,alpha:1,time:50});
				return;
			}
			boxList.clearChildren();
		}
		self.x=(vo.x)||300;
		segDefs=vo.segDefs;
		if(segDefs){
			let catalogs,def,css;
			catalogs=segDefs.getCatalogs();
			for(def of catalogs){
				css=BoxCatalog(def,self.genDefBtn,false);
				boxList.appendNewChild(css);
			}
			boxList.firstChild.showFace("open");
		}
		self.alpha=0;
		self.animate({type:"pose",x:vo.x-50,alpha:1,time:50});
		inited=true;
	};
	
	//-----------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		switch(cmd){
			case "Escape":{
				app.closeDlg(self,null);
				return 1;
			}
		}
	};
	
	//-----------------------------------------------------------------------
	cssVO.OnBGClick=function(){
		app.closeDlg(self,null);
	};
	/*}#1HJNUUQMD1PostCSSVO*/
	return cssVO;
};
/*#{1HJNUUQMD1ExCodes*/
/*}#1HJNUUQMD1ExCodes*/


/*#{1HJNUUQMD0EndDoc*/
/*}#1HJNUUQMD0EndDoc*/

export default DlgChooseSeg;
export{DlgChooseSeg};
