//Auto genterated by Cody
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
import{} from "/@homekit/cfg/appCfg.js";
/*#{MoreImports*/
/*}#MoreImports*/
VFACT.appCfg=appCfg;
//Prefix extern-lib's appCfgs:
{
	let cfgs,name;
	cfgs=window.codyAppCfgs;
	for(name in cfgs){
		cfgs[name].applyCfg();
	}
}
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	/*}#AppCode*/
}
startApp();
/*#{EndDoc*/
/*}#EndDoc*/

