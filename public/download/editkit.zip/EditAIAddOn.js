import {VFACT} from "/@vfact";
import {} from "./aiagent/DirTabOS.js";
import {} from "./aiagent/EditAI.js";
import {UIEditWithCanvas} from "./ui/UIEditWithCanvas.js";
import {} from "/@aichat/ai/RemoteChat.js";

export default {
	"DocEditor":{
		"CanvasEditor":UIEditWithCanvas
	}
};