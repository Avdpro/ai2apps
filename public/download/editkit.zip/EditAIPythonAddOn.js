import {VFACT} from "/@vfact";
import {} from "./aiagent/EditAIPython.js";
import {RemoteChat} from "/@aichat/ai/RemoteChat.js";

async function loadPythonSeg(url){
	let code,pos,pos2,mk1,mk2,func;
	code=await (await fetch(url)).text();
	mk1=`""">>>CodyExport`;
	mk2=`>>>CodyExport"""`;
	pos=code.indexOf(mk1);
	if(pos>0){
		pos2=code.indexOf(mk2);
		if(pos2>pos){
			code=code.substring(pos+mk1.length,pos2);
		}else{
			console.warn(`LoadPythonSeg error in ${url}: can't find close mark.`);
			return;
		}
		try{
			func=new Function("VFACT",code);
			code=func(VFACT);
		}catch(err){
			console.warn(`Import addon ${url} failed:`);								
			console.error(err);
		}
	}else{
		console.warn(`LoadPythonSeg error in ${url}: can't find seg-start mark.`);
		return;
	}
}

try{
	RemoteChat.pythonAddOn();
	await loadPythonSeg("/@aichat/ai/FixArg.py");
}catch(err){
	console.warn(`Can't load python seg: ${err}`);
}

