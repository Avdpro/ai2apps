import {} from "./backend/EditBackEnd.js";
import {UIEditWithCanvas} from "./ui/UIEditWithCanvas.js";

export default {
	"DocEditor":{
		"CanvasEditor":UIEditWithCanvas
	}
};