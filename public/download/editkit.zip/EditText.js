import {EditAttr} from "./EditAttr.js";
import inherits from "/@inherits";
//----------------------------------------------------------------------------
function EditLocText(owner,def,init){
	EditAttr.call(owner,def,init);
	let locTexts;
	this.locTexts=locTexts={};
	Object.defineProperty(this,"val",{
		get: function () {
			let prj,lan;
			prj=owner.prj;
			lan=prj.language;
			if(lan in locTexts){
				return locTexts[lan];
			}
			locTexts[lan]="_"+this.name+"_";
			return locTexts[lan];
		},
		set: function (v) {
			let prj,lan;
			prj=owner.prj;
			lan=prj.language;
			locTexts[lan]=v;
		},
		enumerable: true
	});
};
inherits(EditLocText,EditAttr);
EditAttr.regAttrType("locText",EditLocText);
let editLocText=EditLocText.prototype;

//----------------------------------------------------------------------------
editLocText.setText=function(loc,text){
	//TODO: check if text is a function
	this.locTexts[loc]=text;
};

//****************************************************************************
//I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	editLocText.genSaveVO=function(){
		let vo,locs,loc,text;
		vo={};
		locs=this.locTexts;
		for(loc in locs){
			text=locs[loc];
			if(text instanceof Function){
				vo[loc]={source:""+text};
			}else{
				vo[loc]=""+text;
			}
		}
		return vo;
	};

	//------------------------------------------------------------------------
	editLocText.loadFromVO=function(vo){
		let locs,loc,text;
		locs=this.locTexts;
		for(loc of vo){
			text=vo[loc];
			if(typeof(text)==="string"){
				locs[loc]=text;
			}else if(text.source){
				//TODO: make this safer?
				locs[loc]=eval(text.source);
			}
		}
	};
};
