import {EditPrj} from "./EditPrj.js";
import {} from "./exporters/DocReactAppExporter.js";//Exporter for app.js
import {} from "./exporters/DocCfgExporter.js";//Exporter for appCfg.js
import {} from "./exporters/DocClassExporter.js";//Exporter for data class source files
import {} from "./exporters/DocGearExporter.js";//Exporter for JSLib
import {} from "./exporters/ReactExporter.js";//Exporter for UI component/view source files
import {} from "./exporters/HTML_ReactExporter.js";//Exporter for HTML
import {TBXNaviPrj} from "./ui/TBXNaviPrj.js";
import {TBXNaviDoc} from "./ui/TBXNaviDoc.js";
import {TBXEditObj} from "./ui/TBXEditObj.js";
//AIChat:
import AIChatCommands from "./ai/AIAddOn.js";
//Attribute edit line:
import {} from "./ui/EALStdAttr.js";
import {} from "./ui/EALBoolAttr.js";
import {} from "./ui/EALColor.js";
import {} from "./ui/EALFace.js";
import {} from "./ui/EALChoiceAttr.js";
import {} from "./ui/EALFileAttr.js";
import {} from "./ui/EALFontPreview.js";
import {} from "./ui/EALLengthAttr.js";
import {UIEditGear} from "./ui/UIEditGear.js";
import {} from "./edithud/ReactHudTypes.js";

async function EditAddOn(dataPrj){
	let prj;
	prj=new EditPrj(dataPrj);
	await prj.loadPrj(dataPrj.path);
};

export default {
	"Project":{
		"EditAddOn":EditAddOn
	},
	"NaviTool":{
		"NaviPrj":TBXNaviPrj,
		"NaviDoc":TBXNaviDoc
	},
	"InfoTool":{
		"EditObj":TBXEditObj
	},
	"DocEditor":{
		"GearEditor":UIEditGear
	},
	"AICommand":AIChatCommands
};
