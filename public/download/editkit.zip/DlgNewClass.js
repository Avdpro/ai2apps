import {DlgNewClass} from "./ui/DlgNewClass.js";

export default DlgNewClass;
export {DlgNewClass};