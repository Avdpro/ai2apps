import {VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {esprima} from "/@tabos/utils/esprima.mjs";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
import {EditAISegOutlet,EditAISeg} from "../aiagent/EditAISeg.js";
//Hud:

const $ln=VFACT.lanCode;
let EditFlowSeg,editFlowSeg;
//****************************************************************************
//:EditFlowSeg
//****************************************************************************
EditFlowSeg=function(owner,def,init){
	let self;
	self=this;
	EditAISeg.call(this,owner,def,true);
	this.isFlowSeg=true;
};
EditAttr.regAttrType("flowseg",EditFlowSeg);
inherits(EditFlowSeg,EditAISeg);
editFlowSeg=EditFlowSeg.prototype;

//****************************************************************************
//:EditFlowSeg def registers
//****************************************************************************
{
	let segDefRegs={};
	EditFlowSeg.regDef=function(def){
		let name=def.name;
		let catalogs=def.catalog;
		if(def){
			segDefRegs[name]=def;
		}
		if(catalogs){
			let catalog;
			for(name of catalogs){
				catalog=EditFlowSeg.getCatalog(name);
				if(catalog){
					catalog.defs.push(def);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	EditFlowSeg.getDef=function(name){
		return segDefRegs[name];
	};

	//------------------------------------------------------------------------
	EditFlowSeg.getDefs=function(){
		return Array.from(Object.values(segDefRegs));
	};
	let defCatalogs={};
	//------------------------------------------------------------------------
	EditFlowSeg.regCatalog=function(def){
		let name,catalog;
		name=def.name;
		catalog=defCatalogs[name];
		if(!catalog){
			defCatalogs[name]={...def,defs:[]};
		}
	};
	
	//------------------------------------------------------------------------
	EditFlowSeg.getCatalog=function(name){
		return defCatalogs[name];
	};

	//------------------------------------------------------------------------
	EditFlowSeg.getCatalogs=function(){
		return Object.values(defCatalogs);
	};
}

//****************************************************************************
//:Scope:
//****************************************************************************
{
	editFlowSeg.initScope=function(){
		let self,doc,appCfg,argObj,stateObj,localVars,willUpdate;
		self=this;
		willUpdate=false;
		this.scopeObj={};
		appCfg=this.prj.objConfig;
		doc=this.doc;
		argObj=doc.getAttr("createArgs");
		stateObj=doc.getAttr("state");
		localVars=doc.getAttr("localVars");
		this.setScopeObj("$ln",appCfg.getAttr("lanCode"),false);
		this.setScopeObj("args",argObj,true);
		this.setScopeObj("state",stateObj,false);
		this.setScopeObj("localVars",localVars,true);
		function update(){
			if(willUpdate)
				return;
			willUpdate=true;
			callAfter(()=>{
				self.buildScopeEnv();
				self.updateHyperAttrs();
				willUpdate=false;
			});
		}
		stateObj.on("Changed",update);
		argObj.on("Changed",update);
		localVars.on("Changed",update);
	};
}


export {EditFlowSeg};
