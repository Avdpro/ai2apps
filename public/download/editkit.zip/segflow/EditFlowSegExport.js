const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
let expRegs={};
let exportVsn=0;

//----------------------------------------------------------------------------
function exportOutletFlow(editDoc,outlet,exporter){
	let nextSeg,segType,expFunc;
	nextSeg=outlet.getLinkedSeg();
	while(nextSeg){
		segType=nextSeg.objDef.name;
		expFunc=expRegs[segType];
		if(expFunc){
			expFunc(editDoc,nextSeg,exporter);
		}
		outlet=nextSeg.outlet;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}else{
			nextSeg=null;
		}
	}
}

//----------------------------------------------------------------------------
function exportFunction(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	coder=exporter.coder;
	let name=seg.getAttr("id").val;
	let isAsync=seg.getAttrVal("async");
	let args=seg.getAttr("args").attrList;
	let comment=seg.getAttrVal("desc");
	if((!name) || (!varNameRegex.test(name))){
		name="SEG"+seg.jaxId;
	}
	coder.maybeNewLine();
	coder.packBreakLine();
	if(comment){
		let lines,i,n,line;
		//Export JSDoc comment
		lines=comment.split("\n");
		n=lines.length;
		coder.packText("/**");coder.newLine();
		coder.packText(" * "+lines[0]);coder.newLine();
		for(i=1;i<n;i++){
			coder.packText(" * "+lines[i]);coder.newLine();
		}
		if(args.length>0){
			coder.packText(" * ");coder.newLine();
		}
		//Export args comment:
		for(let arg of args){
			let i,n;
			comment=arg.comment||"";
			lines=comment.split("\n");
			n=lines.length;
			coder.packText(` * @param {${arg.def.type==="auto"?"*":arg.def.type}} ${arg.name} - ${lines[0]||""}`);coder.newLine();
			for(i=1;i<n;i++){
				coder.packText(" *    "+lines[i]);coder.newLine();
			}
		}
		//Export return comment:
		let rtArg=seg.getAttr("returnType");
		if(rtArg){
			let i,n;
			comment=rtArg.comment||"";
			lines=comment.split("\n");
			n=lines.length;
			coder.packText(` * @returns {${rtArg.val}} ${lines[0]||""}`);coder.newLine();
			for(i=1;i<n;i++){
				coder.packText(" *    "+lines[i]);coder.newLine();
			}
		}
		coder.packText(" */");coder.newLine();
	}
	coder.packText(`cssVO.${name}=${isAsync?"async ":""}function(`);//TODO: add mark?
	{
		let arg;
		for(arg of args){
			coder.packText(arg.name+",");
		}
		coder.eatPreComa();
	}
	coder.packText("){");
	coder.indentMore();
	coder.newLine();
	{
		let nextSeg,segType,expFunc,outlet;
		//localVals
		{
			let localVars,attr;
			localVars=seg.getAttr("localVars").attrList;
			for(attr of localVars){
				exporter.genLocalVar(attr,[]);
			}
		}
		coder.beginDocObjTagBlcok(seg,"Start");
		coder.endDocObjTagBlcok(seg,"Start",0);
		exportOutletFlow(editDoc,seg.outlet,exporter);
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("};");
	coder.newLine();
}
expRegs["Entry"]=exportFunction;

//----------------------------------------------------------------------------
expRegs["SetFace"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	let target=seg.getAttrVal("component");
	coder=exporter.coder;
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"Pre");
		coder.endDocObjTagBlcok(seg,"Pre",0);
	}
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	coder.packText(`${target}.showFace(`);exporter.genAttrStatement(seg.getAttr("face"));coder.packText(");");
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"Post");
		coder.endDocObjTagBlcok(seg,"Post",0);
	}
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["Return"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	let hasResult=seg.getAttrValText("result");
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"");
		coder.endDocObjTagBlcok(seg,"",0);
	}
	if(hasResult){
		coder.packText(`return `);exporter.genAttrStatement(seg.getAttr("result"));coder.packText(";");
	}else{
		coder.packText(`return;`);
	}
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["Code"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	coder=exporter.coder;
	{
		let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	coder.beginDocObjTagBlcok(seg,"");
	coder.endDocObjTagBlcok(seg,"",0);
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["CodeBlock"]=
function(editDoc,seg,exporter){
	let coder,prefix,postfix;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	let target=seg.getAttrVal("component");
	coder=exporter.coder;
	{
		let comment=seg.getAttrVal("desc")||seg.getAttrVal("id");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	prefix=seg.getAttrVal("prefix")||"";
	postfix=seg.getAttrVal("postfix")||"";
	coder.packText(`${prefix}{`);
	coder.indentMore();
	coder.newLine();
	{
		let outlet,bodySeg;
		outlet=seg.getAttr("catchlet");
		bodySeg=outlet.getLinkedSeg();
		if(bodySeg){
			if(seg.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(seg,"");
				coder.endDocObjTagBlcok(seg,"",0);
			}
			exportOutletFlow(editDoc,outlet,exporter);
			if(seg.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
		}else{
			coder.beginDocObjTagBlcok(outlet,"");
			coder.endDocObjTagBlcok(outlet,"",0);
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`}${postfix}`);
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["Condition"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	let i,n,cdnList,cdn;

	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	cdnList=seg.outletsList;
	n=cdnList.length;
	for(i=0;i<n;i++){
		cdn=cdnList[i];
		if(i===0){
			coder.packText(`if(`);
		}else{
			coder.packText(`}else if(`);
		}
		coder.packText(cdn.getAttrVal("condition"));
		coder.packText(`){`);
		coder.indentMore();
		coder.newLine();
		{
			let nextSeg;
			nextSeg=cdn.getLinkedSeg();
			if(nextSeg){
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"");
					coder.endDocObjTagBlcok(cdn,"",0);
				}
				exportOutletFlow(editDoc,cdn,exporter);
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"Post");
					coder.endDocObjTagBlcok(cdn,"Post",0);
				}
			}else{
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"");
					coder.endDocObjTagBlcok(cdn,"",0);
				}
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
	}
	cdn=seg.catchlet;
	if(cdn.getAttrVal("codes")||cdn.getLinkedSeg()){
		coder.packText(`}else{`);
		coder.indentMore();
		coder.newLine();
		{
			let nextSeg;
			nextSeg=cdn.getLinkedSeg();
			if(nextSeg){
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"");
					coder.endDocObjTagBlcok(cdn,"",0);
				}
				exportOutletFlow(editDoc,cdn,exporter);
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"Post");
					coder.endDocObjTagBlcok(cdn,"Post",0);
				}
			}else{
				if(cdn.getAttrVal("codes")){
					coder.beginDocObjTagBlcok(cdn,"");
					coder.endDocObjTagBlcok(cdn,"",0);
				}
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText(`}`);
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["Switch"]=
function(editDoc,seg,exporter){
	let i,n,csList,csObj,csText,cdn,cmt;
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;

	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	coder.packText(`switch(${seg.getAttrVal("expression")}){`);
	coder.indentMore();
	coder.newLine();
	{
		csList=seg.outletsList;
		n=csList.length;
		for(i=0;i<n;i++){
			csObj=csList[i];
			cmt=csObj.getAttrVal("desc");
			if(cmt){
				coder.packComment(cmt);
			}
			cdn=csObj.getAttrVal("condition");
			if(!cdn||cdn==="default"){
				if(csObj.getAttrVal("merge")){
					coder.packText(`default:`);
					coder.newLine();
					continue;
				}
				coder.packText(`default:{`);
			}else{
				if(csObj.getAttrVal("merge")){
					coder.packText(`case ${cdn}:`);
					coder.newLine();
					continue;
				}
				coder.packText(`case ${cdn}:{`);
			}
			coder.indentMore();
			coder.newLine();
			{
				let nextSeg;
				nextSeg=csObj.getLinkedSeg();
				if(nextSeg){
					if(csObj.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(csObj,"");
						coder.endDocObjTagBlcok(csObj,"",0);
					}
					exportOutletFlow(editDoc,csObj,exporter);
					if(csObj.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(csObj,"Post");
						coder.endDocObjTagBlcok(csObj,"Post",0);
					}
				}else{
					if(csObj.getAttrVal("codes")){
						coder.beginDocObjTagBlcok(csObj,"");
						coder.endDocObjTagBlcok(csObj,"",0);
					}
				}
			}
			if(csObj.getAttrVal("break")){
				coder.packText(`break;`);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`}`);
			coder.newLine();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`}`);
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["Wait"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	let time=seg.getAttrVal("time");
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"Pre");
		coder.endDocObjTagBlcok(seg,"Pre",0);
	}
	coder.packText(`await sleep(${time});`)
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"Post");
		coder.endDocObjTagBlcok(seg,"Post",0);
	}
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["LoopObj"]
=function(editDoc,seg,exporter){
	let coder,arrayName,labelName,valName,loopMode,letVal;
	if(seg.exportVsn===exportVsn){
		return;
	}
	arrayName=seg.getAttrVal("loopObj");
	labelName=seg.getAttrVal("label");
	valName=seg.getAttrVal("loopVal");
	loopMode=seg.getAttrVal("loopMode");
	letVal=seg.getAttrVal("letVal");
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	if(labelName){
		coder.packText(`${labelName}:{`);
		coder.indentMore();
		coder.newLine();
	}
	coder.packText(`for(${letVal?"let ":""}${valName} ${loopMode} ${arrayName}){`);
	coder.indentMore();
	coder.newLine();
	{
		let outlet,loopSeg;
		outlet=seg.getAttr("catchlet");
		loopSeg=outlet.getLinkedSeg();
		if(loopSeg){
			if(seg.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(seg,"");
				coder.endDocObjTagBlcok(seg,"",0);
			}
			exportOutletFlow(editDoc,outlet,exporter);
			if(seg.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(seg,"Post");
				coder.endDocObjTagBlcok(seg,"Post",0);
			}
		}else{
			coder.beginDocObjTagBlcok(outlet,"");
			coder.endDocObjTagBlcok(outlet,"",0);
		}
	}
	coder.maybeNewLine();
	coder.indentLess();
	coder.packText(`}`);

	if(labelName){
		coder.maybeNewLine();
		coder.indentLess();
		coder.packText(`}`);
	}
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["TryCatch"]
=function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	coder.packText(`try{`);
	coder.indentMore();
	coder.newLine();
	{
		let outlet,nextSeg;
		outlet=seg.getAttr("outlets").getAttr("try");
		nextSeg=outlet.getLinkedSeg();
		if(nextSeg){
			if(outlet.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
			exportOutletFlow(editDoc,outlet,exporter);
			if(outlet.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(outlet,"Post");
				coder.endDocObjTagBlcok(outlet,"Post",0);
			}
		}else{
			coder.beginDocObjTagBlcok(outlet,"");
			coder.endDocObjTagBlcok(outlet,"",0);
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`}catch(error){`);
	coder.indentMore();
	coder.newLine();
	{
		let outlet,nextSeg;
		outlet=seg.getAttr("outlets").getAttr("catch");
		nextSeg=outlet.getLinkedSeg();
		if(nextSeg){
			if(outlet.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(outlet,"");
				coder.endDocObjTagBlcok(outlet,"",0);
			}
			exportOutletFlow(editDoc,outlet,exporter);
			if(outlet.getAttrVal("codes")){
				coder.beginDocObjTagBlcok(outlet,"Post");
				coder.endDocObjTagBlcok(outlet,"Post",0);
			}
		}else{
			coder.beginDocObjTagBlcok(outlet,"");
			coder.endDocObjTagBlcok(outlet,"",0);
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`}`);
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["Menu"]
=function(editDoc,seg,exporter){
	let launcher;
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	launcher=seg.getAttrVal("launcher");
	coder.packText(`{`);
	coder.indentMore();
	coder.newLine();
	{
		coder.packText(`let $items,$item;`);coder.newLine();
		coder.packText(`$items=[`);
		coder.indentMore();coder.newLine();
		{
			let outlets,i,n,outlet;
			outlets=seg.outletsList;
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				coder.packText("{");
				coder.packText(`id:`);exporter.genAttrStatement(outlet.getAttr("id"));coder.packText(",");
				coder.packText(`text:`);exporter.genAttrStatement(outlet.getAttr("text"));coder.packText(",");
				if(outlet.getAttr("icon")){
					coder.packText(`icon:`);exporter.genAttrStatement(outlet.getAttr("icon"));coder.packText(",");
				}
				if(outlet.getAttr("enable")){
					coder.packText(`enable:`);exporter.genAttrStatement(outlet.getAttr("enable"));coder.packText(",");
				}
				if(outlet.getAttr("check")){
					coder.packText(`check:`);exporter.genAttrStatement(outlet.getAttr("check"));coder.packText(",");
				}
				coder.eatPreComa();
				coder.packText("},");
				coder.newLine();
			}
			coder.eatPreComa();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText("];");
		coder.newLine();
		if(seg.getAttrVal("codes")){
			coder.beginDocObjTagBlcok(seg,"Items");
			coder.endDocObjTagBlcok(seg,"Items",0);
		}
		coder.packText(`$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:${launcher},items:$items});`);
		coder.newLine();
		
		coder.packText(`if($item){`);
		coder.indentMore();coder.newLine();
		{
			let outlets,i,n,outlet;
			outlets=seg.outletsList;
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				if(i===0){
					coder.packText(`if($item.id===`);exporter.genAttrStatement(outlet.getAttr("id"));coder.packText("){");
				}else{
					coder.packText(`}else if($item.id===`);exporter.genAttrStatement(outlet.getAttr("id"));coder.packText("){");
				}
				coder.indentMore();coder.newLine();
				{
					let nextSeg;
					nextSeg=outlet.getLinkedSeg();
					if(nextSeg){
						if(outlet.getAttrVal("codes")){
							coder.beginDocObjTagBlcok(outlet,"");
							coder.endDocObjTagBlcok(outlet,"",0);
						}
						exportOutletFlow(editDoc,outlet,exporter);
						if(outlet.getAttrVal("codes")){
							coder.beginDocObjTagBlcok(outlet,"Post");
							coder.endDocObjTagBlcok(outlet,"Post",0);
						}
					}else{
						coder.beginDocObjTagBlcok(outlet,"");
						coder.endDocObjTagBlcok(outlet,"",0);
					}
				}
				coder.indentLess();coder.maybeNewLine();
			}			
			coder.packText("}");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText("}");
	}
	if(seg.getAttrVal("codes")){
		coder.beginDocObjTagBlcok(seg,"Post");
		coder.endDocObjTagBlcok(seg,"Post",0);
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`}`);
	coder.newLine();
};

//----------------------------------------------------------------------------
expRegs["Dialog"]=
function(editDoc,seg,exporter){
	let coder,modal,popApp,assign,pathAttr,hasCode;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	modal=seg.getAttrVal("modal");
	popApp=seg.getAttrValText("app");
	assign=seg.getAttrValText("assign");
	hasCode=seg.getAttrVal("codes");
	coder=exporter.coder;
	pathAttr=seg.getAttr("dialog");
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	if(modal){
		if(assign){
			coder.packText(`${assign}=`);
		}
		coder.packText(`await ${popApp||"VFACT.app"}.modalDlg(`);
	}else{
		coder.packText(`${popApp||"VFACT.app"}.showDlg(`);
	}
	exporter.genAttrStatement(pathAttr);
	coder.packText(`,`);
	coder.newLine();
	exporter.genObjSeg(seg.getAttr("args"),false,hasCode?"Args":false);
	coder.eatPreComa();
	coder.packText(");");
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["RenderData"]=
function(editDoc,seg,exporter){
	let coder,view,data,clear,uiDef,assign,hasCode;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	view=seg.getAttrValText("view");
	data=seg.getAttrValText("data");
	uiDef=seg.getAttrValText("uiDef");
	clear=seg.getAttrVal("clear");
	hasCode=seg.getAttrVal("codes");
	assign=seg.getAttrValText("assign");
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	if(hasCode){
		coder.beginDocObjTagBlcok(seg,"");
		coder.endDocObjTagBlcok(seg,"",0);
	}
	if(assign){
		coder.packText(`${assign}=`);
	}
	coder.packText(`VFACT.syncDataList2View(${view},${data},${uiDef},${clear});`);
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
expRegs["WebFetch"]=
function(editDoc,seg,exporter){
	let coder;
	if(seg.exportVsn===exportVsn){
		return;
	}
	seg.exportVsn=exportVsn;
	coder=exporter.coder;
	coder.maybeNewLine();
	{
		let comment=seg.getAttrVal("desc");
		if(comment){
			coder.maybeGapLine();
			coder.packComment(comment);
		}
	}
	{
		let segName=seg.idVal.val;
		let urlAttr=seg.getAttr("url");
		let methodAttr=seg.getAttr("method");
		let headerAttr=seg.getAttr("headers");
		let textAttr=seg.getAttr("text");
		let imageAttr=seg.getAttr("image");
		let argMode=seg.getAttrVal("argMode");
		let timeout=seg.getAttrVal("timeout");
		let hasCode=seg.getAttrVal("codes");
		let assign=seg.getAttrValText("assign");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`{`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let callVO=null;`);coder.newLine();
			coder.packText(`let url=`);exporter.genAttrStatement(urlAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let method=`);exporter.genAttrStatement(methodAttr);coder.packText(`;`);coder.newLine();
			if(headerAttr.attrList.length>0){
				coder.packText(`let headers=`);exporter.genAttrStatement(headerAttr);coder.eatPreComa();coder.packText(`;`);coder.newLine();
			}else{
				coder.packText(`let headers={};`);coder.newLine();
			}
			if(hasCode){
				coder.beginDocObjTagBlcok(seg,"PreCodes");
				coder.endDocObjTagBlcok(seg,"PreCodes",0);
			}
			switch(argMode){
				case "URL":{
					let list,i,n,attr,key,value;
					coder.packText(`if(url.indexOf("&")<0&&url.indexOf("?")<0){url+="?";}else{url+="&"}`);coder.newLine();
					coder.packText(`url+=`);
					list=seg.getAttr("args").attrList;
					n=list.length;
					for(i=0;i<n;i++){
						attr=list[i];
						key=attr.name;
						if(i!==0){
							coder.packText(`+"&"+`);
						}
						coder.packText(`encodeURIComponent("${key}")+"="+encodeURIComponent(`);exporter.genAttrStatement(attr);coder.packText(`)`);
					}
					coder.packText(`;`);coder.newLine();
					coder.packText(`let text=`);exporter.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
					coder.packText(`callVO={method:method,headers:headers,body:text};`);coder.newLine();
					break;
				}
				case "JSON":{
					let attr=seg.getAttr("args");
					if(attr.attrList.length>0){
						coder.packText(`let json=`);exporter.genAttrStatement(attr);coder.eatPreComa();coder.packText(`;`);coder.newLine();
					}else{
						coder.packText(`let json={};`);coder.newLine();
					}
					coder.packText(`headers["Content-Type"]="application/json";`);coder.newLine();
					coder.packText(`callVO={method:method,argMode:"JSON",headers:headers,body:json};`);coder.newLine();
					break;
				}
				case "TEXT":{
					coder.packText(`let text=`);exporter.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
					coder.packText(`callVO={method:method,headers:headers,body:text};`);coder.newLine();
					break;
				}
			}
			if(hasCode){
				coder.beginDocObjTagBlcok(seg,"AboutCall");
				coder.endDocObjTagBlcok(seg,"AboutCall",0);
			}
			coder.packText(`${assign?assign+" = ":""}await (await import("/@tabos/utils/webAPI.js")).webFetch(url,callVO);`);
			coder.newLine();
			if(hasCode){
				coder.beginDocObjTagBlcok(seg,"PostCall");
				coder.endDocObjTagBlcok(seg,"PostCall",0);
			}
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`}`);
	}
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
function exportFlowSegs(editDoc,exporter){
	let coder,segsList,seg,segDef;
	exportVsn+=1;
	segsList=editDoc.segsList;
	coder=exporter.coder;
	for(seg of segsList){
		segDef=seg.objDef;
		if(segDef.name==="Entry"){
			exportFunction(editDoc,seg,exporter);
		}
	}
};

//----------------------------------------------------------------------------
function exportSegAIExpose(seg){
	let funcVO,ppts;
	let name=seg.getAttr("id").val;
	let isAsync=seg.getAttrVal("async");
	let args=seg.getAttr("args").attrList;
	let comment=seg.getAttrVal("descAI")||seg.getAttrVal("desc");
	if((!name) || (!varNameRegex.test(name))){
		name="SEG"+seg.jaxId;
	}
	ppts={};
	for(let arg of args){
		let i,n,comment;
		comment=arg.comment||"";
		ppts[arg.name]={
			type:arg.def.type==="auto"?"any":arg.def.type,
			description:arg.comment||"",
		};
	}
	funcVO={
		name:name,
		description:comment,
		parameters:{
			type:"object",
			properties:ppts
		}
	}
	return funcVO;
};

//----------------------------------------------------------------------------
function docHasFlowSegsAIExpose(editDoc){
	let segsList,seg,segDef,segVO;
	segsList=editDoc.segsList;
	for(seg of segsList){
		segDef=seg.objDef;
		if(segDef.name==="Entry" && seg.getAttrVal("exposeToAI")){
			return true;
		}
	}
	return false;
};

//----------------------------------------------------------------------------
function genDocFlowSegsAIExpose(editDoc,exporter){
	let coder,segsList,seg,segDef,segVO;
	coder=exporter.coder;
	segsList=editDoc.segsList;
	coder=exporter.coder;
	coder.packText("[");
	coder.indentMore();coder.newLine();
	{
		for(seg of segsList){
			segDef=seg.objDef;
			if(segDef.name==="Entry" && seg.getAttrVal("exposeToAI")){
				segVO=exportSegAIExpose(seg);
				coder.packText(JSON.stringify(segVO));
			}
		}
		coder.eatPreComa();
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText("]");
};

export {exportFlowSegs,docHasFlowSegsAIExpose,genDocFlowSegsAIExpose};