import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditAISegOutlet} from "../aiagent/EditAISeg.js";
import {EditFlowSeg} from "./EditFlowSeg.js";
const $ln=VFACT.lanCode;

const TraceLogArrayDef={icon:"files.svg",elementType:"object",elementDef:"AISegTraceLog",allowExtraAttr:false};

const SegObjShellAttr={
	"id":{
		name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,
	},
	"label":{
		name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"New AI Seg",localizable:true,export:false,edit:false
	},
	"x":{
		name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
	},
	"y":{
		name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
	},
	"desc":{
		name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?(""):/*EN*/("")),
	},
	"codes":{
		name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
	},
};

const ConditionOutletDef={
	name:"ConditionOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Condition",
		},
		"condition":{
			name:"condition",showName:(($ln==="CN")?("判断条件"):/*EN*/("Condition")),type:"string",key:1,fixed:1,initVal:"",export:false,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("条件输出节点。"):/*EN*/("Condition outlet.")),
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(ConditionOutletDef);
const CoditionOutletArrayDef={
	elementType:"aioutlet",elementDef:ConditionOutletDef,allowExtraAttr:1,
	attrs:[
		{type:"aioutlet",def:ConditionOutletDef,key:1,fixed:1}
	]
};

const SwitchOutletDef={
	name:"SwitchOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Condition",
		},
		"condition":{
			name:"condition",showName:(($ln==="CN")?("判断条件"):/*EN*/("Condition")),type:"string",key:1,fixed:1,initVal:"",export:false,
		},
		"merge":{
			name:"merge",showName:(($ln==="CN")?("向下合并"):/*EN*/("Merge down")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"break":{
			name:"break",showName:(($ln==="CN")?("break结尾"):/*EN*/("Ends with break")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",key:1,fixed:1,initVal:"",
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(SwitchOutletDef);
const SwitchOutletArrayDef={
	elementType:"aioutlet",elementDef:SwitchOutletDef,allowExtraAttr:1,
	attrs:[
		{type:"aioutlet",def:SwitchOutletDef,key:1,fixed:1}
	]
};

const MenuItemDef={
	name:"MenuItem",allowExtraAttr:true,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item",
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",localizable:true,key:1,fixed:1,initVal:"item",export:false,
		},
		"icon":{
			name:"icon",showName:(($ln==="CN")?("图标"):/*EN*/("Icon")),type:"url",initVal:undefined,key:0,fixed:1
		},
		"enable":{
			name:"enable",showName:(($ln==="CN")?("启用"):/*EN*/("Enable")),type:"bool",initVal:true,key:0,fixed:1
		},
		"check":{
			name:"check",showName:(($ln==="CN")?("选中"):/*EN*/("check")),type:"bool",initVal:false,key:0,fixed:1
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",key:1,fixed:1,initVal:"",
		}
	},
	listHint:["id","text","icon","enable","check","desc"],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(MenuItemDef);
const MenuItemArrayDef={
	elementType:"aioutlet",elementDef:MenuItemDef,allowExtraAttr:1,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:0,
			def:{
				...MenuItemDef,
				attrs:{
					...MenuItemDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item1"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",localizable:true,key:1,fixed:1,initVal:"Item 1",},
				}
			},
		},
		{
			type:"aioutlet",key:1,fixed:0,
			def:{
				...MenuItemDef,
				attrs:{
					...MenuItemDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item2"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",localizable:true,key:1,fixed:1,initVal:"Item 2",},
				}
			},
		},
		{
			type:"aioutlet",key:1,fixed:0,
			def:{
				...MenuItemDef,
				attrs:{
					...MenuItemDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item3"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",localizable:true,key:1,fixed:1,initVal:"Item 3",},
				}
			},
		},
	]
};

//************************************************************************
//:Define catalogs:
//************************************************************************
EditFlowSeg.regCatalog({
	name:"Common",showName:(($ln==="CN")?("常用"):/*EN*/("Common"))
});

EditFlowSeg.regCatalog({
	name:"UIModify",showName:(($ln==="CN")?("UI 调整"):/*EN*/("Modify UI"))
});

EditFlowSeg.regCatalog({
	name:"Flow",showName:(($ln==="CN")?("流程控制"):/*EN*/("Flow Control"))
});

EditFlowSeg.regCatalog({
	name:"Code",showName:(($ln==="CN")?("代码"):/*EN*/("Code"))
});

const FlowArgDef={
	name:"FlowCallArgument",allowExtraAttr:false,
	attrs:{
		"type":{
			name:"type",showName:(($ln==="CN")?("类型"):/*EN*/("type")),type:"choice",key:1,fixed:1,initVal:"auto",
			vals:[
				["auto","Auto",(($ln==="CN")?("自动类型"):/*EN*/("Auto Type"))],
				["string","String",(($ln==="CN")?("字符串"):/*EN*/("String"))],
				["integer","Integer",(($ln==="CN")?("整数"):/*EN*/("Integer"))],
				["number","Integer",(($ln==="CN")?("数字"):/*EN*/("Number"))],
				["bool","Boolean",(($ln==="CN")?("布尔型"):/*EN*/("Boolean"))],
			],
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:"",
		},
		"enum":{
			name:"enum",showName:(($ln==="CN")?("可取的值"):/*EN*/("Enum")),type:"array",elementType:"auto",key:0,fixed:1,initVal:"",
		},
	},
	listHint:["type","desc","enum"],
};
EditObj.regDef("FlowCallArgument",FlowArgDef);

const FlowSegArrayDef={elementType:"flowseg",allowExtraAttr:1};
//************************************************************************
//:Define segs:
//************************************************************************
//:Code seg that start an function:
EditFlowSeg.regDef({
	name:"Entry",showName:(($ln==="CN")?("函数入口"):/*EN*/("Entry")),icon:"func.svg",catalog:["Common","Code"],rootOnly:true,
	attrs:{
		...SegObjShellAttr,
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Arguments")),type:"object",def:"Object",icon:"args.svg",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"GearArg",watchTree:true,autoOpen:1
		},
		"async":{
			name:"async",showName:(($ln==="CN")?("异步函数"):/*EN*/("Async")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false
		},
		"returnType":{
			name:"returnType",showName:(($ln==="CN")?("函数返回"):/*EN*/("Returns")),type:"string",key:1,fixed:1,initVal:"void",editType:"choice",
			vals:[
				["void","Void","Void"],
				["any","Any","Any"],
				["int","Integer","Integer"],
				["number","Number","Number"],
				["string","String","String"],
				["boolean","Boolean","Boolean"],
				["Object","Object","Object"],
				["Array","Array","Array"],
			],
			comment:true,
		},
		"aiToolCall":{
			name:"aiToolCall",showName:(($ln==="CN")?("可被AI调用"):/*EN*/("AI tool")),type:"bool",key:0,fixed:1,initVal:false,rawEdit:false
		},
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",icon:"var_auto.svg",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"HudLocalVal",watchTree:true,autoOpen:1
		},
		"segs":{
			name:"segs",showName:(($ln==="CN")?("子片段"):/*EN*/("Sub Segs")),type:"array",icon:"array.svg",def:FlowSegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				}
			}
		},
		"exposeToAI":{
			name:"exposeToAI",showName:(($ln==="CN")?("向AI输出"):/*EN*/("Expose to AI")),type:"bool",initVal:false,key:1,fixed:1,rawEdit:false,
		},
		"descAI":{
			name:"descAI",showName:(($ln==="CN")?("面向AI的描述说明"):/*EN*/("Description for AI")),type:"string",initVal:"",key:0,fixed:1,localizable:true
		}
	},
	listHint:[
		"id","args","async","localVars","returnType","codes","aiToolCall","desc","exposeToAI","descAI"
	],
	objAttrs:{
		addCallArg:function(name,def){
			let args=this.getAttr("args");
			let attrDef={...def,name:name,key:0,fixed:0};
			return args.addAttr(attrDef);
		}
	}
});

//------------------------------------------------------------------------
//:CodeSeg that just code:
EditFlowSeg.regDef({
	name:"Code",showName:(($ln==="CN")?("代码片段"):/*EN*/("Code Seg")),icon:"tab_css.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",showName:"next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
			}
		}
	},
	listHint:[
		"id","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Raw-Block-Code, can be if/while/do-while/event function...
EditFlowSeg.regDef({
	name:"CodeBlock",showName:(($ln==="CN")?("代码块"):/*EN*/("Code Block")),icon:"code.svg",catalog:["Common","Code"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"prefix":{
			name:"prefix",showName:(($ln==="CN")?("前缀"):/*EN*/("Prefix")),type:"string",key:1,fixed:1,initVal:"",
		},
		"postfix":{
			name:"postfix",showName:(($ln==="CN")?("后缀"):/*EN*/("Postfix")),type:"string",key:1,fixed:1,initVal:"",
		},
		"catchlet":{
			name:"catchlet",showName:"Body",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Body",
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		}
	},
	listHint:[
		"id","prefix","postfix","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Code set that set face of current UI:
EditFlowSeg.regDef({
	name:"SetFace",showName:(($ln==="CN")?("设置外观"):/*EN*/("Set Face")),icon:"faces.svg",catalog:["Common","UIModify"],
	attrs:{
		...SegObjShellAttr,
		"component":{
			name:"component",showName:(($ln==="CN")?("控件"):/*EN*/("Component")),type:"string",key:1,fixed:1,initVal:"self",
		},
		"face":{
			name:"face",showName:(($ln==="CN")?("外观"):/*EN*/("Face")),type:"string",key:1,fixed:1,initVal:"",localizable:false,editType:"choice",
			getMenuItems:function(){
				let list,i,n,tag;
				let items=[];
				try{
					list=this.owner.doc.faceTags.attrList;
					n=list.length;
					for(i=0;i<n;i++){
						tag=list[i];
						items.push({text:tag.name,valText:tag.name});
					}
				}catch(err){
				}
				if(!items.length){
					items.push({text:(($ln==="CN")?("界面没有预置外观"):/*EN*/("UI has no faces")),valText:"",enable:false});
				}
				return items;
			}
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
			}
		},
	},
	listHint:[
		"id","component","face","codes","desc",
	],
});

//------------------------------------------------------------------------
//:Code seg that end the function and return value:
EditFlowSeg.regDef({
	name:"Return",showName:(($ln==="CN")?("退出函数"):/*EN*/("Exit")),icon:"flag.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"result":{
			name:"result",showName:(($ln==="CN")?("返回值"):/*EN*/("Result Value")),type:"auto",key:1,fixed:1,initVal:undefined,
		},
	},
	listHint:[
		"id","result","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Code set that wait a while to continue:
EditFlowSeg.regDef({
	name:"Wait",showName:(($ln==="CN")?("等待"):/*EN*/("Wait")),icon:"wait.svg",catalog:["Common","UIModify"],
	attrs:{
		...SegObjShellAttr,
		"time":{
			name:"time",showName:(($ln==="CN")?("等待时间 (ms)"):/*EN*/("Wait seconds (ms)")),type:"int",key:1,fixed:1,initVal:1000,
			editType:"step",step:100,minVal:0,maxVal:10000,valFixDigit:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",},
			}
		},
	},
	listHint:[
		"id","time","codes","desc",
	],
});

//------------------------------------------------------------------------
//:Code seg path connect:
const connectorDef={
	name:"connector",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowleft.svg",segIcon:"arrowright.svg",catalog:["Common","Flow"],
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"New AI Seg",export:false,edit:false,
		},
		"x":{
			name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"y":{
			name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"outlet":{
			name:"outlet",showName:"Outlet",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Outlet",
				},
			},
		},
		"dir":{
			name:"dir",showName:(($ln==="CN")?("方向"):("Direction")),type:"choice",
			vals:(($ln==="CN")?([["L2R","L2R","左至右"],["R2L","R2L","右至左"],["T2B","T2B","上至下"],["B2T","B2T","下至上"]]):/*EN*/([["L2R","L2R","Left to right"],["R2L","R2L","Right to left"],["T2B","T2B","Top to bottom"],["B2T","B2T","Bottom to top"]])),
			initVal:"R2L",hideVal:1,key:1,fixed:1
		},
	},
	listHint:[
		"dir"
	],
	objAttrs:{
		isConnector:true,
		getName(){
			return (($ln==="CN")?("连接器"):/*EN*/("Connector"));
		}
	},
};
EditFlowSeg.regDef(connectorDef);
EditFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorL",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowright.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"L2R"}
}));
EditFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorT",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowdown.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"T2B"}
}));
EditFlowSeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorB",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowup.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"B2T"}
}));

//------------------------------------------------------------------------
//:Condition brunches:
EditFlowSeg.regDef({
	name:"Condition",showName:(($ln==="CN")?("条件分支"):/*EN*/("Condition")),icon:"condition.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlets":{
			name:"outlets",showName:"Conditions",type:"array",def:CoditionOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"catchlet":{
			name:"catchlet",showName:"Else",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"else",
				},
				"codes":{
					name:"codes",showName:(($ln==="CN")?("代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","desc","codes",
	]
});

//------------------------------------------------------------------------
//:Swtich brunches:
EditFlowSeg.regDef({
	name:"Switch",showName:(($ln==="CN")?("Switch块"):/*EN*/("Switch Block")),icon:"condition.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"expression":{
			name:"expression",showName:"Expression",type:"string",fixed:1,key:1,edit:false,initVal:"expression",
		},
		"outlets":{
			name:"outlets",showName:"Conditions",type:"array",def:SwitchOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","expression","codes","desc",
	]
});

//------------------------------------------------------------------------
//:CodeSeg that make loop on an array:
EditFlowSeg.regDef({
	name:"LoopObj",showName:(($ln==="CN")?("遍历数组/对象"):/*EN*/("Items Loop")),icon:"loop_array.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"loopObj":{
			name:"loopObj",showName:(($ln==="CN")?("循环目标"):/*EN*/("Loop Target")),type:"string",key:1,fixed:1,rawEdit:false,initVal:"list",//TODO: Choose array attr?
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"",
		},
		"loopVal":{
			name:"loopVal",showName:(($ln==="CN")?("循环变量"):/*EN*/("Loop Val")),type:"string",key:1,fixed:1,initVal:"item",
		},
		"letVal":{
			name:"letVal",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local Val")),type:"bool",key:1,fixed:1,rawEdit:false,initVal:true,
		},
		"loopMode":{
			name:"loopMode",showName:(($ln==="CN")?("循环模式"):/*EN*/("Loop Mode")),type:"choice",key:1,fixed:1,initVal:"of",rawEdit:false,
			vals:[
				["of","of","of"],
				["in","in","in"],
			],
		},
		"catchlet":{
			name:"catchlet",showName:"Looper",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Looper",
				},
			},
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		},
	},
	listHint:[
		"id","loopObj","loopVal","letVal","label","loopMode","desc","codes",
	]
});

//------------------------------------------------------------------------
//:CodeSeg that catch error in sub-flow:
EditFlowSeg.regDef({
	name:"TryCatch",showName:(($ln==="CN")?("捕获异常"):/*EN*/("Catch Error")),icon:"trycatch.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlets":{
			name:"outlets",showName:"TryCatch",type:"object",key:1,fixed:1,edit:false,navi:"doc",
			def:{
				allowExtraAttr:false,
				attrs:{
					"try":{
						name:"try",showName:"Try",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
						attrs:{
							"id":{
								name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Try",
							},
							"codes":{
								name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,
							},
						},
					},
					"catch":{
						name:"catch",showName:"catch",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
						attrs:{
							"id":{
								name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Catch",
							},
							"codes":{
								name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("Codes")),type:"bool",key:1,fixed:1,initVal:true,
							},
						},
					}
				}
			}
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		}
	},
	listHint:[
		"id","desc","codes",
	]
});

//------------------------------------------------------------------------
//:UI Menu brunches:
EditFlowSeg.regDef({
	name:"Menu",showName:(($ln==="CN")?("菜单"):/*EN*/("Menu")),icon:"menu.svg",catalog:["UIModify"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"launcher":{
			name:"launcher",showName:(($ln==="CN")?("触发控件"):/*EN*/("Launcher")),type:"string",key:1,fixed:1,initVal:"self"
		},
		"outlets":{
			name:"outlets",showName:"Conditions",type:"array",def:MenuItemArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","launcher","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Show Dialog
EditFlowSeg.regDef({
	name:"Dialog",showName:(($ln==="CN")?("弹出对话框"):/*EN*/("Pop-Dialog")),icon:"idcard.svg",catalog:["UIModify"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"app":{
			name:"app",showName:(($ln==="CN")?("发起的App"):/*EN*/("Pop app")),type:"string",key:1,fixed:1,initVal:"",
		},
		"dialog":{
			name:"dialog",showName:(($ln==="CN")?("对话框URL"):/*EN*/("Dialog URL")),type:"url",key:1,fixed:1,initVal:"/@homekit/ui/DlgLogin.js",editType:"choice",
			vals:[
				["/@homekit/ui/DlgLogin.js","/@homekit/ui/DlgLogin.js","Dialog Login"],
				["/@homekit/ui/DlgCloud.js","/@homekit/ui/DlgCloud.js","Dialog Cloud"],
				["/@aichat/ui/DlgAIChat.js","/@aichat/ui/DlgAIChat.js","Dialog AI Chat"],
				["/@homekit/ui/DlgAIWork.js","/@homekit/ui/DlgAIWork.js","Dialog AI Work"],
			],
		},
		"modal":{
			name:"modal",showName:(($ln==="CN")?("模式对话框"):/*EN*/("Modal")),type:"bool",key:1,fixed:1,initVal:true,
		},
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Arguments")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"GearArg"
		},
		"assign":{
			name:"assign",showName:(($ln==="CN")?("赋值结果"):/*EN*/("Assign Result")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","app","dialog","modal","args","assign","codes","desc",
	]
});

//------------------------------------------------------------------------
//:Data to UI items
EditFlowSeg.regDef({
	name:"RenderData",showName:(($ln==="CN")?("数据映射UI"):/*EN*/("Data2UI")),icon:"hudlbx.svg",catalog:["UIModify"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"view":{
			name:"view",showName:(($ln==="CN")?("目标UI"):/*EN*/("View")),type:"string",key:1,fixed:1,initVal:"",
		},
		"data":{
			name:"data",showName:(($ln==="CN")?("数据数组"):/*EN*/("DataArray")),type:"string",key:1,fixed:1,initVal:"[]",
		},
		"uiDef":{
			name:"uiDef",showName:(($ln==="CN")?("控件函数"):/*EN*/("UI function")),type:"string",key:1,fixed:1,initVal:"",
		},
		"clear":{
			name:"clear",showName:(($ln==="CN")?("映射前清空"):/*EN*/("Clear first")),type:"bool",key:1,fixed:1,initVal:true,
			newAttrMode:"GearArg"
		},
		"assign":{
			name:"assign",showName:(($ln==="CN")?("赋值结果"):/*EN*/("Assign Result")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","view","data","uiDef","clear","assign","codes","desc",
	]
});

//------------------------------------------------------------------------
//:WebCall
EditFlowSeg.regDef({
	name:"WebFetch",showName:(($ln==="CN")?("调用网络API"):/*EN*/("Call WEB API")),icon:"web.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("调用URL"):/*EN*/("Call URL")),type:"string",key:1,fixed:1,initVal:"https://api.google.com",
		},
		"method":{
			name:"method",showName:(($ln==="CN")?("请求方法"):/*EN*/("Request Method")),type:"choice",key:1,fixed:1,initVal:"POST",
			vals:[
				["GET","GET","GET"],
				["POST","POST","POST"],
				["PUT","PUT","PUT"],
				["DELETE","DELETE","DELETE"],
			],
		},
		"argMode":{
			name:"argMode",showName:(($ln==="CN")?("参数传递方法"):/*EN*/("Arguments embeding")),type:"choice",key:1,fixed:1,initVal:"JSON",rawEdit:false,
			vals:[
				["URL","URL","URL"],
				["JSON","JOSN","JSON in body"],
				["TEXT","Text","String"],
			],
		},
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call arguments")),type:"object",def:"Object",key:1,fixed:1
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("调用文本"):/*EN*/("Call text")),type:"string",key:1,fixed:1,initVal:"",
		},
		"headers":{
			name:"headers",showName:(($ln==="CN")?("HTTP 头参数"):/*EN*/("HTTP Header")),type:"object",def:"Object",key:1,fixed:1
		},
		"assign":{
			name:"assign",showName:(($ln==="CN")?("赋值结果"):/*EN*/("Assign Result")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",showName:"Next",type:"aioutlet",def:"AISegOutlet",key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next"},
			}
		},
	},
	listHint:[
		"id","url","method","headers","argMode","args","text","assign","codes","desc",
	]
});

