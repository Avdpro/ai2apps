import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditAtom} from "../editdoc/EditAtom.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
import {getMemberProperties} from "./CodeFilter.js";
var DocClassExporter,docClassExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocClassExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("DataClass",DocClassExporter);
inherits(DocClassExporter,EditDocExporter);
docClassExporter=DocClassExporter.prototype;

//----------------------------------------------------------------------------
docClassExporter.export=function(editDoc,opts){
	let list,i,n,objExp,coder,exportObjs,orgCodes;
	
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	orgCodes=editDoc.dataDoc.getDocText();
	
	//Imports:
	{
		let imports,path,stub,items;
		let orgDir=pathLib.dirname(editDoc.path);
		let prjPath=editDoc.prj.path;
		coder.packText(`import VFACT from "/@vfact";`,0);coder.newLine();
		coder.packText(`import inherits from "/@inherits";`,0);coder.newLine();
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(path.startsWith(prjPath)){//In same prj, use relative path
				path=pathLib.relative(orgDir,path);
				if(!path.startsWith(".") && !path.startsWith("/")){
					path="./"+path;
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);

	//Export more objs:
	{
		let exObj,funcArgs,superClass,codeType;
		list=editDoc.getAttr("editObjs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			exObj=list[i];
			if(exObj instanceof EditObj){
				codeType=exObj.getAttrVal("exportType");
				switch(codeType){
					default:
					case "":
					case "DataClass":
						this.genClassCode(exObj,exportObjs,orgCodes);
						break;
					case "UIDataTemplate":
						this.genUITemplate(exObj,exportObjs,orgCodes);
						break;
				}
			}
		}
	}

	//------------------------------------------------------------------------
	//Extra code before end doc:
	coder.newLine();
	coder.beginDocObjTagBlcok(editDoc,"EndDoc");
	coder.endDocObjTagBlcok(editDoc,"EndDoc",0);
	//------------------------------------------------------------------------
	//export
	coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
DocClassExporter.exportClass=function(coder,exObj,exportObjs,orgCodes){
	let exporter,codeType;
	exporter=new DocClassExporter(exObj.prj);
	exporter.coder=coder;
	codeType=exObj.getAttrVal("exportType");
	switch(codeType){
		default:
		case "":
		case "DataClass":
			exporter.genClassCode(exObj,exportObjs,orgCodes);
			break;
		case "UIDataTemplate":
			//TODO: Code this:
			break;
	}
};

//----------------------------------------------------------------------------
docClassExporter.mergeClassPpts=function(classPptsObj,codePptsObj){
	let prj,doc,orgList,tgtList,orgHash,tgtHash;
	let orgAttr,attrName,tgtAttr,attrDef,tgtAttrText,orgAttrText;
	let atom,needOrder,objs2Merge;
	doc=classPptsObj.doc;
	doc.startEditAction();
	orgList=codePptsObj.attrList;
	tgtList=classPptsObj.attrList;
	orgHash=codePptsObj.attrHash;
	tgtHash=classPptsObj.attrHash;
	objs2Merge=[];
	//First, add new attrs:
	for(orgAttr of orgList){
		attrName=orgAttr.name;
		tgtAttr=tgtHash[attrName];
		if(tgtAttr){
			tgtAttrText=tgtAttr.valText;
			orgAttrText=tgtAttr.valText;
			//TODO: check value,
			if(orgAttr.type==="auto"){
				if(orgAttrText!==tgtAttrText){
					//align val:
					if(tgtAttr.val!==orgAttr.val){
						if(tgtAttrText.startsWith("#")||tgtAttrText.startsWith("${")){
							//Keep tgtAttr
						}else{
							//Try to set tgtAttr by text:
							if((tgtAttr instanceof EditArray)||(tgtAttr instanceof EditObj)){
							}else{
								doc.execEditAtom(EditAtom.setAttrByText(classPptsObj,tgtAttr,orgAttrText));
							}
						}
					}
				}
			}else if(orgAttr.type==="object"){
				if(tgtAttr.type==="object"){
					objs2Merge.push({org:orgAttr,tgt:tgtAttr});
				}else{
					//TODO: Code this:
				}
			}else if(orgAttr.type==="array"){
				if(tgtAttr.type!=="array"){
					//TODO: Code this:
				}
			}
		}else{
			//add value,
			atom=EditAtom.addAttr(classPptsObj,orgAttr.def);
			doc.execEditAtom(atom);
		}
	}
	//2nd, remove missing attrs:
	for(tgtAttr of tgtList){
		attrName=tgtAttr.name;
		orgAttr=orgHash[attrName];
		if(!orgAttr){
			//remove attr
			doc.execEditAtom(EditAtom.removeAttr(classPptsObj,tgtAttr));
		}
	}
	CheckOrder:{
		let i,n;
		n=orgList.length;
		for(i=0;i<n;i++){
			orgAttr=orgList[i];
			tgtAttr=tgtList[i];
			if(orgAttr.name!==tgtAttr.name){
				needOrder=true;
				break CheckOrder;
			}
		}
		needOrder=false;
	}
	if(needOrder){
		//TODO: Add order-atom:
	}
	
	doc.endEditAction();
};

//----------------------------------------------------------------------------
docClassExporter.genClassCode=function(exObj,exportObjs,orgCodes){
	let funcArgs,superClass,coder;
	let mockupOnly;

	if(orgCodes){
		let mark,argSeg,pptSeg,ppts;
		//Maybe we update class content:
		//TODO: Parse arguments
		mark=exObj.jaxId+"Properties+";
		pptSeg=CdyCoder.getSegCode(orgCodes,mark);
		if(pptSeg){
			//Parse pptSeg, find ppts
			ppts=getMemberProperties(pptSeg);
			//console.log("Parsed properties:");
			//console.log(ppts);
			if(ppts){
				//TODO: Merge ppts
			}
		}
	}
	
	coder=this.coder;
	mockupOnly=exObj.getAttr("mockupOnly").val;
	if(!mockupOnly){
		superClass=exObj.getAttr("superClass");
		coder.packText("//----------------------------------------------------------------------------");
		coder.newLine();
		//:Constructor:
		coder.beginDocObjTagBlcok(exObj,"Constructor+");
		coder.packText(`let ${exObj.name}=function(`);
		funcArgs=exObj.getAttr("constructArgs");
		if(funcArgs){
			funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
			coder.packText(""+funcArgs);
		}
		coder.packText(`){`);
		coder.endDocObjTagBlcok(exObj,"Constructor+");
		{
			coder.indentMore();
			coder.beginDocObjTagBlcok(exObj,"PreConstruct");
			coder.endDocObjTagBlcok(exObj,"PreConstruct",0);
			coder.beginDocObjTagBlcok(exObj,"Properties+");
			this.genConstructSeg(exObj.getAttr("properties"),false,"ExAttrs");	
			coder.endDocObjTagBlcok(exObj,"Properties+",0);
			coder.beginDocObjTagBlcok(exObj,"PostConstruct");
			coder.endDocObjTagBlcok(exObj,"PostConstruct",0);
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("};");
		if(exportObjs){
			exportObjs.push(exObj.name);
		}
		coder.maybeNewLine();

		//:Inherits:
		if(superClass && superClass.val){
			coder.packText(`inherits(${exObj.name},${superClass.val});`);
		}else{
			coder.packText(`${exObj.name}.prototype={};`);	
		}
		coder.newLine();
		coder.packText(`let _${exObj.name}=${exObj.name}.prototype;`);
		coder.newLine();

		//:Functions
		let funcs=exObj.getAttr("functions");
		if(funcs){
			funcs=funcs.attrList;
			for(let func of funcs){
				this.genFunctionSeg(exObj.name,func);
			}
		}
		coder.beginDocObjTagBlcok(exObj,"ExCodes");
		coder.endDocObjTagBlcok(exObj,"ExCodes",0);
		coder.newLine();
	}
};

//----------------------------------------------------------------------------
//Export properties in constructor:
docClassExporter.genConstructSeg=function(pptObj){
	let coder,list,attr;
	coder=this.coder;
	list=pptObj.attrList;
	for(attr of list){
		this.genAttr(attr);
	}
};

//----------------------------------------------------------------------------
//Export a function:
docClassExporter.genFunctionSeg=function(clsName,funcObj){
	let funcArgs;
	let coder=this.coder;
	coder.newLine();
	coder.packText("//----------------------------------------------------------------------------");
	coder.newLine();
	coder.packText(`_${clsName}.${funcObj.name}=function(`,0);
	funcArgs=funcObj.getAttr("callArgs");
	if(funcArgs){
		funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
		coder.packText(""+funcArgs);
	}
	coder.packText(`){`,0);
	{
		coder.indentMore();
		coder.newLine();
		coder.beginDocObjTagBlcok(funcObj,"FunctionBody");
		coder.endDocObjTagBlcok(funcObj,"FunctionBody",0);
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText(`};`,0);
	coder.newLine();
};

//----------------------------------------------------------------------------
docClassExporter.genAttr=function(attr){
	let valText,val;
	let coder=this.coder;
	valText=attr.valText;
	coder.maybeNewLine();
	coder.packText(`this.${attr.name}=`);
	if(valText.startsWith("#>")){
		let pos=valText.indexOf(">",2);
		if(pos>0){
			coder.packText(valText.substring(pos+1),0);
		}else{
			console.warn(`>#valtext incomplete: ${valText}`);
			coder.packText("null",0);
		}
	}else if(valText.startsWith("#")){
		let pos;
		pos=valText.indexOf("#>",1);
		if(pos>1){
			coder.packText(valText.substring(pos+2),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
	}else if(valText.startsWith("${")){
		let text;
		let pos=valText.lastIndexOf("}");
		text=`$V(()=>${valText.substring(2,pos)}`;
		if(valText[pos+1]==="("){
			let pos2=valText.lastIndexOf(")");//Track items:
			if(pos2>0){
				text+=","+valText.substring(pos+2,pos2);
			}else{
				console.warn(`\${valtext incomplete: ${valText}`);
			}
		}
		text+=")";
		coder.packText(text,0);
	}else{
		let attrType;
		attrType=attr.def.type;
		if(attrType==="classobj"){
			let initCode;
			initCode=attr.getAttr("initCode").val;
			if(initCode){
				coder.packText(initCode,0);
			}else{
				coder.packText("null",0);
			}
		}else if(attr instanceof EditObj){
			if(attr.isClassProperty){
				let defaultVal=attr.getAttr("defaultValue");
				if(defaultVal){
					this.genAttrStatement(defaultVal);
				}else{
					coder.packText("undefined",0);
				}
				//this.genObjPpt(attr,false,false);
			}else{
				this.genObjSeg(attr,false,false);
				coder.packText(`,`,0);
			}
			coder.eatPreComa();
		}else{
			if(attr.exportCode){
				coder.packText(attr.exportCode("class"),0);
			}else{
				coder.packText(JSON.stringify(attr.val),0);
			}
		}
	}
	coder.packText(`;`,0);
	coder.newLine();
};

//----------------------------------------------------------------------------
docClassExporter.genObjPpt=function(editObj,withName,exSeg){
	let pptType;
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	if(editObj.jaxId){
		coder.packText(`//"jaxId":"${editObj.jaxId}"`);
	}
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
//Export one template property:
docClassExporter.genTemplateAttr=function(attrObj){
	let coder,list,attrType,attrName,attrVal,attrText;
	
	const packAttr=(name,exportName)=>{
		let attr;
		attr=attrObj.getAttr(name);
		if(attr){
			coder.packText(`${exportName||name}:`);this.genAttrStatement(attr,false,true);coder.packText(`,`);coder.newLine();
		}
		return attr;
	}
	
	if(!(attrObj instanceof EditObj)){
		return;
	}
	coder=this.coder;
	attrName=attrObj.name;
	coder.packText(`${attrName}:{`);
	coder.indentMore();
	coder.newLine();
	{
		attrType=attrObj.getAttrVal("type");
		coder.packText(`name:"${attrName}",`);
		coder.packText(`type:"${attrType}",`);
		coder.maybeNewLine();
		switch(attrType){
			case "object":{
				packAttr("label");
				packAttr("icon");
				packAttr("class");
				packAttr("desc");
				break;
			}
			case "array":{
				let attr;
				packAttr("label");
				packAttr("icon");
				packAttr("uiMode");
				packAttr("readOnly");
				packAttr("required");
				packAttr("initLength");
				attr=packAttr("element");
				packAttr("desc");
				break;
			}
			default:{
				let attr;
				packAttr("label");
				packAttr("icon");
				packAttr("defaultValue");
				packAttr("readOnly");
				packAttr("required");
				packAttr("placeHolder");
				packAttr("inputType");
				packAttr("inputPattern");
				packAttr("shortEdit");
				packAttr("uiMode");
				packAttr("choices");
				attr=packAttr("ranged");
				if(attr && attr.val){
					packAttr("rangeMin");
					packAttr("rangeMax");
				}
				attr=packAttr("desc");
				break;
			}
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`},`);
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
//Export properties in ui-data-template's properties:
docClassExporter.genTemplateAttrs=function(pptObj){
	let coder,list,attr;
	coder=this.coder;
	list=pptObj.attrList;
	for(attr of list){
		this.genTemplateAttr(attr);
	}
};

//----------------------------------------------------------------------------
//Export ui-data-template
docClassExporter.genUITemplate=function(exObj,exportObjs,orgCodes){
	let coder,mockupOnly;
	coder=this.coder;
	mockupOnly=exObj.getAttr("mockupOnly").val;
	if(mockupOnly){
		return;
	}
	if(exportObjs){
		exportObjs.push(exObj.name);
	}
	coder.packText(`let ${exObj.name}={`);
	coder.indentMore();
	coder.newLine();
	{
		let layoutAttr;
		coder.packText(`name:"${exObj.name}",//${exObj.jaxId}`);coder.newLine();
		coder.packText(`type:"object",`);coder.newLine();
		coder.packText(`label:`);this.genAttrStatement(exObj.getAttr("label"),false,true);coder.packText(`,`);coder.newLine();
		coder.packText(`properties:{`);
		coder.indentMore();
		coder.newLine();
		{
			this.genTemplateAttrs(exObj.getAttr("properties"));
		}
		coder.beginDocObjTagBlcok(exObj,"MoreProperties");
		coder.endDocObjTagBlcok(exObj,"MoreProperties",0);
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`},`);
		coder.maybeNewLine();
		layoutAttr=exObj.getAttr("layout");
		if(layoutAttr){
			coder.packText(`layout:`);this.genAttrStatement(layoutAttr,false,true);coder.packText(`,`);coder.newLine();
			//coder.packText(`layout:${JSON.stringify(layoutAttr.getJSObj())},`);
			//coder.maybeNewLine();
		}
		coder.packText(`desc:`);this.genAttrStatement(exObj.getAttr("desc"),false,true);coder.packText(`,`);coder.newLine();
		coder.packText(`newObject(){return VFACT.newUITemplateObj(this)},`);
		coder.maybeNewLine();
		coder.beginDocObjTagBlcok(exObj,"MoreFunctions");
		coder.endDocObjTagBlcok(exObj,"MoreFunctions",0);
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText(`};`);
	coder.maybeNewLine();
	coder.packText(`VFACT.regUITemplate("${exObj.jaxId}",${exObj.name});`);coder.newLine();
	coder.packText(`VFACT.regUITemplate("${exObj.name}",${exObj.name});`);coder.newLine();
	coder.beginDocObjTagBlcok(exObj,"MoreCodes");
	coder.endDocObjTagBlcok(exObj,"MoreCodes",0);
};

export {DocClassExporter};

