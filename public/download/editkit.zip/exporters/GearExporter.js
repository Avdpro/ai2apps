import {EditObj} from "../EditObj.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {DocGearExporter} from "./DocGearExporter.js";
EditDocExporter.regExporter("Gear",DocGearExporter);
