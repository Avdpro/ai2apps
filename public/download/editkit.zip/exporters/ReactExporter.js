import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {EditHudGear} from "../edithud/EditHudGear.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
import {DocClassExporter} from "./DocClassExporter.js";
import {ACTParser} from "./ACTParser.js";
import {getHyperAttrText} from "/@vfact";
import {vfactCSSPptMap,vfactElmtPptMap} from "../edithud/HTMLPptDef.js";

var ReactExporter,reactExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
ReactExporter=function(prj){
	EditDocExporter.call(this,prj);
	this.objStubMap=null;
};
EditDocExporter.regExporter("Gear",ReactExporter);
inherits(ReactExporter,EditDocExporter);
reactExporter=ReactExporter.prototype;
//----------------------------------------------------------------------------
reactExporter.export=function(editDoc,opts){
	let coder,path,baseName,exportName,exportObjs,subStates;
	let actParser,cssMapValues,rootHudObj;
	let objStubMap,utilFuncSet,exposeNameSet,funcStubMap;
	let isGearDoc=!!editDoc.exposeGear.val;
	let config;

	config=editDoc.prj.config;
	subStates=[];
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	rootHudObj=this.rootHudObj=editDoc.hudObj;
	actParser=new ACTParser(editDoc.prj,{
		allowDynamic:true,
		hyperValToken:["{","}"],
		hashNamePrefix:"",subNamePrefix:"#",
		cssPptMap:vfactCSSPptMap,
		elmtPptMap:vfactElmtPptMap,
	});
	actParser.parseACT(rootHudObj);
	objStubMap=this.objStubMap=actParser.objStubMap;
	utilFuncSet=actParser.utilFuncSet;
	exposeNameSet=actParser.exposeNameSet;
	funcStubMap=this.funcStubMap=actParser.funcStubMap;

	path=editDoc.getAttr("path").val;
	baseName=pathLib.basename(path);
	{
		let pos=baseName.indexOf(".");
		exportName=(pos>0)?(baseName.substring(0,pos)):baseName;
		exportObjs.push(exportName);
	}
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	//Imports:
	{
		let imports,stub,items;
		let orgDir=pathLib.dirname(editDoc.selfProxy.path);
		let prjPath=editDoc.prj.path;
		if(isGearDoc){
			coder.packText("import React, {useState, useEffect, useRef, useMemo, useCallback, memo} from '/@react';");
		}else{
			coder.packText("import React, {useState, useEffect, useRef, useMemo, useCallback} from '/@react';");
		}
		coder.newLine();
		{
			let i,n;
			coder.packText("import {");
			items=utilFuncSet.values();
			for(let name of items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "/@vfact/vfact_react.js";`,0);
			coder.newLine();
		}
		
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(!stub.isUsed()){
				continue;
			}
			if(path.startsWith(prjPath)){//In same prj, use relative path
				if(opts.orgDir && path.startsWith(opts.orgDir)){
					path="./"+pathLib.basename(path);
				}else if(path.startsWith(orgDir)){
					path="./"+pathLib.basename(path);
				}else if(!path.startsWith("/@")){
					path=pathLib.relative(orgDir,path);
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			/*if(docType==="vfact"){
				path=path.replaceAll("ui/lib","ui");
			}*/
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);

	//Export class objs:
	if(config.allowDataClassInUI){
		let exObj,list,i,n;
		list=editDoc.getAttr("editObjs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			exObj=list[i];
			if(exObj instanceof EditObj){
				DocClassExporter.exportClass(coder,exObj,null);
			}
		}
	}

	//Export Major hud-gear:
	{
		let exObj,funcArgs,arg,ppts,attr,localVars;
		
		exObj=editDoc.hudObj;
		//:Export static Styles:
		coder.packText(`const staticStyles={`);
		{
			let list,i,n,sub;
			coder.indentMore();
			coder.newLine();
			cssMapValues=Array.from(objStubMap.values());
			for(let stub of cssMapValues){
				if(!stub.hyper && !stub.faces){
					this.exportStaticStyleStub(stub,coder);
					list=stub.subElmts;
					if(list){
						n=list.length;
						for(i=0;i<n;i++){
							sub=list[i];
							if(!sub.hyper && !sub.faces){
								this.exportStaticStyleStub(sub,coder);
							}
						}
					}
				}
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText(`};`);
		
		coder.packText("//----------------------------------------------------------------------------");
		coder.newLine();
		//:Constructor:
		funcArgs=editDoc.getAttr("createArgs");
		if(funcArgs){
			funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
			funcArgs.push("$style");
			funcArgs.push("$fwdRef");
		}
		coder.packText(`function ${exportName}({`);
		if(funcArgs){
			coder.packText(""+funcArgs);
		}
		coder.eatPreComa();
		coder.packText(`}){`);
		{
			coder.indentMore();
			coder.newLine();
			coder.packText("let styleRegs;");
			coder.newLine();
			coder.packText("let [face,setFace]=useState(\"\");");
			coder.newLine();
			coder.packText("let rendered = useRef(false);");
			coder.newLine();
			coder.newLine();
			coder.packText("let cfgColor,cfgSize,txtSize,state,setState;");
			coder.newLine();
			coder.packText("let cssVO,self=useRef(),showFace;");
			coder.newLine();
			coder.newLine();
			{
				coder.packText("$style=$style||{};");coder.newLine();
				coder.packText("cfgColor=appCfg.color;");coder.newLine();
				coder.packText("cfgSize=appCfg.size;");coder.newLine();
				coder.packText("txtSize=appCfg.txtSize;");coder.newLine();
				coder.newLine();
			}
			{
				let list,name;
				list=exposeNameSet.values();
				coder.packText("let elmts={",0);
				for(name of list){
					coder.packText(`"${name}":useRef(),`,0);
				}
				coder.eatPreComa();
				coder.packText("};",0);
				coder.newLine();
			}
			//Add localVars;
			localVars=editDoc.getAttr("localVars").attrList;
			for(attr of localVars){
				this.genLocalVar(attr,subStates);
			}
			coder.newLine();
			coder.beginDocObjTagBlcok(exObj,"LocalVals");
			coder.endDocObjTagBlcok(exObj,"LocalVals",0);
			coder.newLine();
			coder.beginDocObjTagBlcok(exObj,"PreState");
			coder.endDocObjTagBlcok(exObj,"PreState",0);
			
			//State properties:
			{
				let stateObj=editDoc.getAttr("state");
				if(stateObj.attrList.length>0){
					coder.packText("state=");
					this.genObjSeg(editDoc.getAttr("state"),false,"ExState");
					coder.eatPreComa();
					coder.packText(";");
					coder.newLine();
					coder.packText(`[state,setState]=useState(state);`);
					coder.newLine();
				}
			}
			coder.beginDocObjTagBlcok(exObj,"PostState");
			coder.endDocObjTagBlcok(exObj,"PostState",0);
			
			coder.packText("useEffect(() => {");
			{
				coder.indentMore();
				coder.newLine();
				coder.packText("rendered.current = true;");
				coder.beginDocObjTagBlcok(exObj,"OnFirstMount");
				coder.endDocObjTagBlcok(exObj,"OnFirstMount",0);
				coder.indentLess();
			}
			coder.newLine();
			coder.packText("},[]);");
			
			coder.newLine();
			coder.packText("useEffect(() => {");
			{
				coder.indentMore();
				coder.newLine();
				coder.packText("self.current.showFace=showFace;");
				coder.newLine();
				coder.packText("self.current.subElmts=elmts;");
				coder.newLine();
				coder.packText("if($fwdRef){$fwdRef.current=self.current;};");
				coder.beginDocObjTagBlcok(exObj,"OnEachMount");
				coder.endDocObjTagBlcok(exObj,"OnEachMount",0);
				coder.indentLess();
			}
			coder.newLine();
			coder.packText("});");

			coder.newLine();
			coder.packText("let useRefCounter=useRef(0);");
			coder.newLine();
			coder.packText("function _useRef(vo){");
			{
				coder.indentMore();
				coder.newLine();
				coder.packText("useRefCounter.current+=1;");
				coder.newLine();
				coder.packText("return useRef(vo);");
				coder.indentLess();
				coder.newLine();
			}
			coder.packText("}");//End function _useRef
			coder.newLine();
			coder.packText("function cheatUseRef(){");
			{
				coder.indentMore();
				coder.newLine();
				coder.packText("let n=useRefCounter.current;");
				coder.newLine();
				coder.packText("for(let i=0;i<n;i++){useRef(null);}");
				coder.indentLess();
				coder.newLine();
			}
			coder.packText("}");
			coder.newLine();

			//The base-dynamic-styles:
			coder.packText("styleRegs=useRef();");
			coder.newLine();
			coder.packText("if(!rendered.current){");
			{
				coder.indentMore();
				coder.newLine();
				coder.packText("styleRegs.current={");
				{
					let list,i,n,sub;
					coder.indentMore();
					coder.newLine();
					for(let stub of cssMapValues){
						if(stub.hyper || stub.faces){
							this.exportDynamicStyleStub(stub,coder);
							list=stub.subElmts;
							if(list){
								n=list.length;
								for(i=0;i<n;i++){
									sub=list[i];
									this.exportDynamicStyleStub(sub,coder);
								}
							}
						}else{
							list=stub.subElmts;
							if(list){
								n=list.length;
								for(i=0;i<n;i++){
									sub=list[i];
									if(sub.hyper || stub.faces){
										this.exportDynamicStyleStub(sub,coder);
									}
								}
							}
						}
					}
					coder.eatPreComa();
					coder.indentLess();
					coder.newLine();
				}
				coder.packText("};");
				coder.indentLess();
				coder.newLine();
			}
			coder.packText("}else{");
			{
				let stub=objStubMap.get(rootHudObj);
				coder.indentMore();
				coder.newLine();
				coder.packText("cheatUseRef();");
				coder.newLine();
				coder.packText("let current=styleRegs.current");
				coder.newLine();
				coder.packText(`let styleObj=current["${stub.indexName}"];`);
				coder.newLine();
				coder.packText(`styleObj.current={...styleObj.current,...$style};`);
				{
					let list,i,n,sub;
					coder.newLine();
					for(let stub of cssMapValues){
						if(stub.hyper || stub.faces){
							this.exportStateStyleStub(stub,coder);
							list=stub.subElmts;
							if(list){
								n=list.length;
								for(i=0;i<n;i++){
									sub=list[i];
									this.exportStateStyleStub(sub,coder);
								}
							}
						}else{
							list=stub.subElmts;
							if(list){
								n=list.length;
								for(i=0;i<n;i++){
									sub=list[i];
									if(sub.hyper || stub.faces){
										this.exportStateStyleStub(sub,coder);
									}
								}
							}
						}
					}
				}
				coder.indentLess();
				coder.newLine();
			}
			coder.packText("}");
			coder.newLine();
			coder.packText("let styleObjs=styleRegs.current;");
			coder.newLine();
			coder.newLine();

			//Generate faces:
			if(config.allowFace){
				{
					let faceTags,i,n,faceTag;
					faceTags=editDoc.faceTags.attrList;
					n=faceTags.length;
					if(n>=0){
						coder.maybeNewLine();
						coder.packText("let faces=useMemo(()=>{");
						{
							coder.indentMore();
							coder.newLine();
							coder.packText("return {");
							{
								coder.indentMore();
								coder.newLine();
								for(i=0;i<n;i++){
									coder.maybeNewLine();
									faceTag=faceTags[i];
									if(!faceTag.mockup.val){
										this.genFaceTag(editDoc,faceTag,actParser,false);
									}
								}
								coder.eatPreComa();
								coder.indentLess();
							}
							coder.maybeNewLine();
							coder.packText("};");
							coder.indentLess();
						}
						coder.maybeNewLine();
						coder.packText("},[]);");
					}
				}
				coder.newLine();
				coder.packText("showFace=useCallback((faceName)=>{let faceFunc=faces[faceName];if(faceFunc){faceFunc(styleRegs.current);setFace(faceName);}},[]);");
				coder.newLine();
			}
			coder.beginDocObjTagBlcok(exObj,"PreJSX");
			coder.endDocObjTagBlcok(exObj,"PreJSX",0);
			
			//Generate events, functions:
			{
				let funcStubs,funcStub,funcAttr,args,argAttr;
				funcStubs=funcStubMap.values();
				for(funcStub of funcStubs){
					funcAttr=funcStub.attr;
					coder.packText(`let ${funcStub.name}=function(`);
					//Pack args:
					args=funcAttr.callArgs.attrList;
					for(argAttr of args){
						coder.packText(`${argAttr.name},`);
					}
					coder.eatPreComa();
					coder.packText("){");
					coder.indentMore();
					coder.newLine();
					coder.beginDocObjTagBlcok(funcAttr,`Code`);
					coder.endDocObjTagBlcok(funcAttr,`Code`,0);
					coder.indentLess();
					coder.newLine();
					coder.packText("};");
					coder.newLine();
				}
			}

			//****************************************************************
			//Export the JSX-HTML:
			this.genHudHTMLSeg(exObj,actParser);	

			//Post codes and return:
			coder.beginDocObjTagBlcok(exObj,"PostJSX");
			coder.endDocObjTagBlcok(exObj,"PostJSX",0);
			coder.packText("return cssVO;");
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("};");
		coder.maybeNewLine();
		coder.beginDocObjTagBlcok(exObj,"ExCodes");
		coder.endDocObjTagBlcok(exObj,"ExCodes",0);
		coder.newLine();
	}
	
	//------------------------------------------------------------------------
	//:Export seg:
	{
		let i,n;
		coder.newLine();
		if(isGearDoc){
			coder.packText(`export default memo(${exportObjs[0]});`);coder.newLine();
			coder.packText(`let $memo_${exportObjs[0]}=${exportObjs[0]};`);coder.newLine();
			coder.packText("export{");
			coder.packText(`$memo_${exportObjs[0]} as ${exportObjs[0]},`);
			n=exportObjs.length;
			for(i=1;i<n;i++){
				coder.packText(exportObjs[i]);
				coder.packText(",");
			}
			coder.eatPreComa();
			coder.packText("};");
			coder.newLine();
		}else{
			coder.packText(`export default ${exportObjs[0]};`);coder.newLine();
			coder.packText("export{");
			n=exportObjs.length;
			for(i=0;i<n;i++){
				coder.packText(exportObjs[i]);
				coder.packText(",");
			}
			coder.eatPreComa();
			coder.packText("};");
			coder.newLine();
		}
	}

	return coder.genDocText();
};

//----------------------------------------------------------------------------
reactExporter.exportStaticStyleStub=function(stub,coder){
	let styleObj,keyName;
	styleObj=stub.styleObj;
	coder.maybeNewLine();
	coder.packText(`"${stub.indexName}":{`,1);
	{
		coder.indentMore();
		coder.newLine();
		for(keyName in styleObj){
			coder.packText(keyName,1);
			coder.packText(`:${styleObj[keyName]},`,0);
		}
		if(stub.editHudObj===this.rootHudObj){
			coder.packText(`...$style`);
		}else{
			coder.eatPreComa();
		}
		coder.indentLess();
	}
	coder.maybeNewLine();
	coder.packText("},",1);
	if(stub.elmtContent){
		coder.maybeNewLine();
		coder.packText(`"${stub.indexName+"#t"}":${stub.elmtContent},`,1);
	}
};

//----------------------------------------------------------------------------
reactExporter.exportDynamicStyleStub=function(stub,coder){
	let styleObj,keyName,val;
	styleObj=stub.styleObj;
	coder.maybeNewLine();
	coder.packText(`"${stub.indexName}":_useRef({`,1);
	{
		coder.indentMore();
		coder.newLine();
		for(keyName in styleObj){
			val=styleObj[keyName];
			coder.packText(keyName,1);
			if(typeof(val)==="object"){
				coder.packText(`:${val.code},`,0);
			}else{
				coder.packText(`:${val},`,0);
			}
		}
		if(stub.editHudObj===this.rootHudObj){
			coder.packText(`...$style`);
		}else{
			coder.eatPreComa();
		}
		coder.indentLess();
	}
	coder.maybeNewLine();
	coder.packText("}),",1);
	if(stub.elmtContent){
		val=stub.elmtContent;
		coder.maybeNewLine();
		if(typeof(val)==="object"){
			coder.packText(`"${stub.indexName+"#t"}":_useRef(${val.code}),`,1);
		}else{
			coder.packText(`"${stub.indexName+"#t"}":_useRef(${stub.elmtContent}),`,1);
		}
	}
};

//----------------------------------------------------------------------------
reactExporter.exportStateStyleStub=function(stub,coder){
	let styleObj,keyName,indexName,val,isCoded;
	styleObj=stub.styleObj;
	indexName=stub.indexName;
	isCoded=false;
	coder.maybeNewLine();
	{
		for(keyName in styleObj){
			val=styleObj[keyName];
			if(typeof(val)==="object"){
				if(val.trace){
					if(!isCoded){
						isCoded=1;
						coder.packText(`styleObj=current["${indexName}"];`,0);
						coder.newLine();
					}
					coder.packText(`styleObj["${keyName}"].current=${val.code};`,0);
					coder.newLine();
				}
			}
		}
	}
	if(stub.elmtContent){
		val=stub.elmtContent;
		coder.maybeNewLine();
		if(typeof(val)==="object" && val.trace){
			coder.packText(`current["${indexName}#t"].current=${val.code};`,1);
		}
	}
	coder.maybeNewLine();
};

//----------------------------------------------------------------------------
reactExporter.genHudHTMLSeg=function(gearObj){
	let doc;
	let coder=this.coder;
	doc=gearObj.doc;
	coder.packText(`cssVO=(`);
	{
		coder.indentMore();
		coder.newLine();
		this.exportEditHudObj(gearObj,coder,true);
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText(");");
};

//----------------------------------------------------------------------------
reactExporter.exportEditHudObj=function(editHudObj,coder,isRoot=false){
	let objDef,stub,hyper,funcStubMap;
	stub=this.objStubMap.get(editHudObj);
	funcStubMap=this.funcStubMap;
	objDef=editHudObj.objDef;
	if(editHudObj instanceof EditHudGear){
		coder.maybeNewLine();
		coder.packText(`<${objDef.importName||"div"} `,0);
		if(stub.idName){
			coder.packText(`$fwdRef={elmts["${stub.idName}"]} `,0);
		}
		{
			let attrs=stub.elmtAttrs;
			let keyName;
			for(keyName in attrs){
				coder.packText(`${keyName}=${attrs[keyName]} `);
			}
		}
		//Export call args:
		{
			let args,attr,attrText;
			args=editHudObj.createArgs.attrList;
			for(attr of args){
				coder.packText(`${attr.name}={`,1);
				if(attr.hyper){
					attrText=getHyperAttrText(attr.valText);
					coder.packText(`${attrText}} `,0);
				}else{
					coder.packText(`${JSON.stringify(attr.val)}} `,0);
				}
			}
		}
		//Use extraAttrs add functions and custom HTML attributes:
		{
			let attr,attrName;
			let attrs=editHudObj.extraPpts.attrList;
			for(attr of attrs){
				attrName=attr.name;
				coder.packText(`${attrName}=${attr.val} `);
			}
		}
		hyper=stub.hyper || stub.faces;
		if(hyper){
			coder.packText(`$style={styleObjs["${stub.indexName}"].current} `,0);
		}else{
			coder.packText(`$style={staticStyles["${stub.indexName}"]} `,0);
		}
		//Export all events:
		{
			let events,funcAttr,stub;
			events=editHudObj.getAttr("events");
			if(events){
				events=events.attrList;
				for(funcAttr of events){
					stub=funcStubMap.get(funcAttr);
					if(stub){
						coder.packText(`${funcAttr.name}={${stub.name}} `);
					}
				}
			}
		}
		coder.eatPreSpace();
		coder.packText(`>`,0);
		coder.maybeNewLine();
		coder.packText(`</${objDef.importName||"div"}>`,0);
		return;
	}
	coder.maybeNewLine();
	coder.packText(`<${objDef.HTMLElemntType||"div"} `,0);
	if(editHudObj===this.rootHudObj){
		coder.packText(`ref={self} `,0);
	}else{
		if(stub.idName){
			coder.packText(`ref={elmts["${stub.idName}"]} `,0);
		}
	}
	{
		let attrs=stub.elmtAttrs;
		let keyName;
		for(keyName in attrs){
			coder.packText(`${keyName}=${attrs[keyName]} `);
		}
	}
	//Use extraAttrs add functions and custom HTML attributes:
	{
		let attr,attrName;
		let attrs=editHudObj.extraPpts.attrList;
		for(attr of attrs){
			attrName=attr.name;
			coder.packText(`${attrName}=${attr.val} `);
		}
	}
	hyper=stub.hyper || stub.faces;
	if(hyper){
		coder.packText(`style={styleObjs["${stub.indexName}"].current} `,0);
	}else{
		coder.packText(`style={staticStyles["${stub.indexName}"]} `,0);
	}
	//Export all events:
	{
		let events,funcAttr,stub;
		events=editHudObj.getAttr("events");
		if(events){
			events=events.attrList;
			for(funcAttr of events){
				stub=funcStubMap.get(funcAttr);
				if(stub){
					coder.packText(`${funcAttr.name}={${stub.name}} `);
				}
			}
		}
	}
	coder.eatPreSpace();
	coder.packText(`>`,0);
	coder.indentMore();	
	coder.maybeNewLine();
	if(stub.subElmts){
		let list,sub,i,n;
		list=stub.subElmts;
		n=list.length;
		for(i=0;i<n;i++){
			sub=list[i];
			coder.maybeNewLine();
			coder.packText(`<${sub.elmtType||"div"} `,0);
			{
				let attrs=sub.elmtAttrs;
				let keyName;
				for(keyName in attrs){
					coder.packText(`${keyName}=${attrs[keyName]} `);
				}
			}
			hyper=hyper || sub.hyper || sub.faces;
			if(hyper){
				coder.packText(`style={styleObjs["${sub.indexName}"].current}`,0);
			}else{
				coder.packText(`style={staticStyles["${sub.indexName}"]}`,0);
			}
			coder.packText(`>`,0);
			//add tag content
			if(sub.elmtContent){
				coder.indentMore();	
				coder.maybeNewLine();
				if(hyper){
					coder.packText(`{styleObjs["${sub.indexName+"#t"}"].current}`);
				}else{
					coder.packText(`{staticStyles["${sub.indexName+"#t"}"]}`);
				}
				coder.indentLess();	
			}
			coder.maybeNewLine();
			coder.packText(`</${sub.HTMLElemntType||"div"}>`,0);
		}
	}
	if(editHudObj.subHuds){
		let list,sub;
		list=editHudObj.subHuds.attrList;
		if(list&&list.length){
			for(sub of list){
				this.exportEditHudObj(sub,coder);
			}
		}
	}
	coder.indentLess();	
	coder.maybeNewLine();
	coder.packText(`</${objDef.HTMLElemntType||"div"}>`,0);
};

//----------------------------------------------------------------------------
reactExporter.genFaceTag=function(doc,faceTag,actParser,isFaceTime=false){
	let coder,name,hudObj,hudId,faceFunc,faceTimes;
	let objStubMap,keys;
	objStubMap=this.objStubMap;
	coder=this.coder;
	if(isFaceTime){
		name="@"+faceTag.time.val;
	}else{
		name=faceTag.name;
	}
	coder.packText(`"${name}":(styleRegs)=>{`);
	{
		let faceState;
		coder.indentMore();
		coder.newLine();
		coder.packText("let styleObj;");
		coder.newLine();
		
		faceState=faceTag.getAttr("state");
		if(faceState){
			let list,i,n,attr,attrText,pos;
			coder.packText(`let newState={...state};`);
			list=faceState.attrList;
			n=list.length;
			for(i=0;i<n;i++){
				attr=list[i];
				coder.newLine();
				attrText=attr.valText;
				if(attrText[0]==="#"){
					attrText=attrText.substring(1);
				}else if(attrText.startsWith("${")){
					pos=attrText.lastIndexOf("}");
					if(pos>0){
						attrText=attrText.substring(2,pos);
					}else{
						attrText=attrText.substring(2);
					}
				}else{
					attrText=JSON.stringify(attrText);
				}
				coder.packText(`newState["${attr.name}"]=${attrText};`);
			}
			coder.newLine();
			coder.packText(`setState(newState);`);
		}

		faceFunc=faceTag.getAttr("preFunc").val;
		if(faceFunc){
			coder.beginDocObjTagBlcok(faceTag,"PreCode");
			coder.endDocObjTagBlcok(faceTag,"PreCode",0);
		}
		hudObj=doc.hudObj;
		hudObj.runOnAllHuds((hud)=>{
			let faces,face,stub,styleObj,keyName;
			let objDef,pptMap,faceStub;
			objDef=hud.objDef;
			stub=objStubMap.get(hud);
			faces=hud.faces.attrList;
			FindFace:{
				for(face of faces){
					if(face.faceTag===faceTag){
						break FindFace;
					}
				}
				return;
			}
			if(face.properties.attrList.length>0){
				faceStub={};
				pptMap=actParser.getCSSPptMap(hud);
				styleObj=actParser.genPptsVO(face,pptMap,faceStub);
				if(Object.keys(styleObj).length>0){
					coder.maybeNewLine();
					coder.packText(`styleObj=styleRegs["${stub.indexName}"];`);
					coder.newLine();
					coder.packText("styleObj.current={...styleObj.current,");
					for(keyName in styleObj){
						coder.packText(`${keyName}:${styleObj[keyName]},`);
					}
					coder.eatPreComa();
					coder.packText("};");
				}
				//SubElements:
				if(stub.subElmts){
					let list,sub,subDef,i,n,hyper;
					list=stub.subElmts;
					n=list.length;
					for(i=0;i<n;i++){
						sub=list[i];
						subDef=sub.def;
						faceStub={};
						pptMap=sub.cssPptMapp;
						styleObj=actParser.genPptsVO(face,pptMap,faceStub);
						if(Object.keys(styleObj).length>0){
							coder.maybeNewLine();
							coder.packText(`styleObj=styleRegs["${sub.indexName}"];`);
							coder.newLine();
							coder.packText("styleObj.current={...styleObj.current,");
							for(keyName in styleObj){
								coder.packText(`${keyName}:${styleObj[keyName]},`);
							}
							coder.eatPreComa();
							coder.packText("};");
						}
						if(subDef.elmtContent){
							if(subDef.elmtContent(face,faceStub,this)){
								coder.maybeNewLine();
								coder.packText(`styleObj=styleRegs["${sub.indexName}#t"];`);
								coder.newLine();
								coder.packText(`styleObj.current=${faceStub.elmtContent};`);
								coder.newLine();
							}
						}
					}
				}
			}
		});
		//TODO: Export face times:{
		/*
		faceTimes=faceTag.faceTimes;
		if(faceTimes){
			let faceTime;
			faceTimes=faceTimes.attrList;
			for(faceTime of faceTimes){
				this.genFaceTag(doc,faceTime,1);
			}
		}*/
		faceFunc=faceTag.getAttr("faceFunc").val;
		if(faceFunc){
			coder.beginDocObjTagBlcok(faceTag,"Code");
			coder.endDocObjTagBlcok(faceTag,"Code",0);
		}
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText("},");
};

//----------------------------------------------------------------------------
reactExporter.genLocalVar=function(attr,subStates){
	let coder=this.coder;
	let valText,pos,docType,attrDef,exportName;
	
	docType=this.docType;
	attrDef=attr.def;
	valText=attr.valText;

	if(attrDef.exportValText){
		valText=attrDef.exportValText(attr,docType);
	}else{
		valText=attr.valText;
	}
	exportName=attrDef.exportName||attr.name;
	if(exportName instanceof Function){
		exportName=exportName(attr,docType);
		if(!exportName){
			return;
		}
	}

	coder.maybeNewLine();
	coder.packText(`let ${exportName}=`);
	if(attr instanceof EditObj){
		if(attr.def.type==="uistate"){
			subStates.push(attr);
			//if(docType==="vfact")
			{
				coder.packText("VFACT.flexState(",0);
			}/*else{
				coder.packText("jaxHudState(jaxEnv,",0);
			}*/
			this.genObjSeg(attr,0,0);
			coder.eatPreComa();
			coder.packText(");",0);
		}else{
			this.genObjSeg(attr,0,0);
			coder.eatPreComa();
			coder.packText(";");
		}
	}else if(valText.startsWith("#")){
		pos=valText.lastIndexOf("#>");
		if(pos>0){
			coder.packText(`${valText.substring(pos+2)};`);
		}else{
			coder.packText(`${valText.substring(1)};`);
		}
	}else if(valText.startsWith("${")){
		pos=valText.lastIndexOf("}");
		//if(docType==="vfact")
		{
			if(pos>0){
				let traceText;
				coder.packText(`$P(()=>(${valText.substring(2,pos)})`,0);
				traceText=valText.substring(pos);
				coder.packText(`${traceText.startsWith(",")?traceText:""});`,0);
			}else{
				coder.packText(`$P(()=>(${valText.substring(2)}));`);
			}
		}/*else{
			if(pos>0){
				let traceText;
				coder.packText(`$V(()=>(${valText.substring(2,pos)})`,0);
				traceText=valText.substring(pos);
				coder.packText(`${traceText.startsWith(",")?traceText:""});`,0);
			}else{
				coder.packText(`$V(()=>(${valText.substring(2)}));`);
			}
		}*/
	}else{
		coder.packText(`${JSON.stringify(attr.val)};`);
	}
	coder.newLine();
};

//----------------------------------------------------------------------------
reactExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
reactExporter.genInObjSegAttr=function(attr,noHide){
	let valText,val,attrDef,docType,exportName;
	let coder=this.coder;
	docType=this.docType;
	attrDef=attr.def;
	val=attr.val;
	if(attrDef.exportValText){
		valText=attrDef.exportValText(attr,docType);
	}else{
		valText=attr.valText;
	}
	exportName=attrDef.exportName||attr.name;
	if(exportName instanceof Function){
		exportName=exportName(attr,docType);
		if(!exportName){
			return;
		}
	}
	if(valText.startsWith("#")){
		let pos;
		pos=valText.indexOf("#>",1);
		coder.packText(`"${exportName}":`,1);
		if(pos>0){
			coder.packText(valText.substring(pos+2),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
		coder.packText(",",0);
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		//if(docType==="vfact")
		{
			coder.packText(`"${exportName}":`,1);
			coder.packText("$P(()=>(",0);
			coder.packText(valText.substring(2,pos),0);
			coder.packText(")",0);
		}/*else{
			coder.packText(`"${exportName}":`,1);
			coder.packText("$V(()=>(",0);
			coder.packText(valText.substring(2,pos),0);
			coder.packText(")",0);
		}*/
		if(valText[pos+1]===","){
			coder.packText(valText.substring(pos+1),0);
		}
		coder.packText(`),`,0);
	}else{
		if(!noHide && attr.isHideExport()){
			return;
		}
		if(attr instanceof EditObj){
			coder.maybeNewLine();
			coder.packText(`"${exportName}":`,1);
			this.genObjSeg(attr,false,false);
			coder.newLine();
		}else{
			coder.packText(`"${exportName}":`,1);
			if(attr.exportCode){
				coder.packText(attr.exportCode(docType),0);
			}else{
				coder.packText(JSON.stringify(attr.val),0);
			}
			coder.packText(`,`,0);
		}
	}
};


