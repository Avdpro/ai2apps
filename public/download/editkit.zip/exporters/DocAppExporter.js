import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
var DocAppExporter,docAppExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocAppExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("DocApp",DocAppExporter);
inherits(DocAppExporter,EditDocExporter);
docAppExporter=DocAppExporter.prototype;

//----------------------------------------------------------------------------
docAppExporter.export=function(editDoc,opts){
	let list,i,n,objExp,coder,exportObjs,externLibCnt,docType,prj;
	let useTabOS;
	prj=editDoc.prj;
	exportObjs=[];
	useTabOS=editDoc.getAttr("useTabOS").val;
	docType=this.docType=editDoc.getAttr("exportTarget").val;
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	if(useTabOS){
		coder.packText(`import {tabOS,tabFS,tabTask} from "/@tabos";`,0);coder.newLine();
	}
	coder.packText(`import {VFACT} from "/@vfact";`,0);coder.newLine();
	coder.packText(`import {} from "/@vfact/vfact_app.js";`,0);coder.newLine();
	coder.packText(`import{appCfg} from "./cfg/appCfg.js";`,0);coder.newLine();
	externLibCnt=0;
	//Extern lib imports:
	{
		let prj;
		let imports,val,path,stub,items;
		let orgDir=pathLib.dirname(editDoc.selfProxy.path);
		let prjPath=editDoc.prj.path;
		prj=editDoc.prj;
		imports=prj.externGearLibs.attrList;
		for(val of imports){
			path=val.getAttrVal("path");
			path=pathLib.join(path,"cfg/appCfg.js");
			coder.packText(`import{} from "${path}";`,0);coder.newLine();
			externLibCnt++;
		}
	}
	coder.beginDocObjTagBlcok(null,"MoreImports");
	coder.endDocObjTagBlcok(null,"MoreImports",0);

	coder.packText(`VFACT.appCfg=appCfg;`,0);coder.newLine();
	if(externLibCnt>0){
		coder.packText(`//Prefix extern-lib's appCfgs:`,0);coder.newLine();
		coder.packText(`{`,0);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let cfgs,name;`,0);coder.newLine();
			coder.packText(`cfgs=window.codyAppCfgs;`,0);coder.newLine();
			coder.packText(`for(name in cfgs){`,0);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`cfgs[name].applyCfg();`,0);coder.newLine();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`}`,0);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`,0);coder.newLine();
	}

	//TODO: Load fonts:
	//TODO:Load images?

	coder.beginDocObjTagBlcok(null,"StartApp");
	coder.endDocObjTagBlcok(null,"StartApp",0);

	//if(docType==="vfact")
	{
		coder.packText(`//----------------------------------------------------------------------------`,0);coder.newLine();
		coder.packText(`//Start the app:`,0);coder.newLine();
		coder.packText(`async function startApp() {`,0);
		coder.indentMore();coder.newLine();
		//Load fonts here:
		{
			let attr,urlAttr,urlText,name,pos;
			let fonts=editDoc.getAttr("fonts").attrList;
			for(let attr of fonts){
				urlAttr=attr.getAttr("url");
				if(urlAttr.hyper){
					urlText=urlAttr.valText;
					if(urlText.startsWith("#")){
						urlText=urlText.substring(1);
					}else if(urlText.startsWith("${")){
						pos=urlText.lastIndexOf("}");
						if(pos>0){
							urlText=urlText.substring(2,pos);
						}else{
							urlText=urlText.substring(2);
						}
					}
				}else{
					urlText=urlAttr.val;
					if(urlText.startsWith(prj.path)){
						urlText=urlText.substring(prj.path.length+1);
					}
				}
				coder.packText(`await VFACT.loadFont(${JSON.stringify(attr.name)},"url(${urlText})",{});`,0);
				coder.newLine();
			}
		}
		coder.beginDocObjTagBlcok(null,"AppCode");
		coder.endDocObjTagBlcok(null,"AppCode",0);
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`,0);coder.newLine();
		if(useTabOS){
			coder.packText(`tabOS.setup().then(()=>{startApp();});`,0);coder.newLine();
		}else{
			coder.packText(`startApp();`,0);coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(null,"EndDoc");
	coder.endDocObjTagBlcok(null,"EndDoc",0);
	coder.newLine();
	return coder.genDocText();
};

//----------------------------------------------------------------------------
docAppExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	if(editObj.def.navi){
		coder.packText(`//"jaxId":"${editObj.jaxId}"`);
	}
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docAppExporter.genAttr=function(attr){
	let valText,val;
	let coder=this.coder;
	valText=attr.valText;
	if(valText.startsWith("#")){
		let pos;
		coder.packText(`"${attr.name}":`,1);
		pos=valText.indexOf("#>");
		if(pos>1){
			coder.packText(valText.substring(1,pos),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		coder.packText(`"${attr.name}":`,1);
		coder.packText("$V(()=>{",0);
		coder.packText(valText.substring(2,pos),0);
		coder.packText("}",0);
		if(valText[pos+1]==="("){
			let pos2=valText.lastIndexOf(")");//Track items:
			coder.packText(","+valText.substring(pos+2,pos2),0);
		}
		coder.packText(`,`,0);
	}else{
		if(attr instanceof EditObj){
			coder.maybeNewLine();
			coder.packText(`"${attr.name}":`,1);
			this.genObjSeg(attr,false,false);
			coder.newLine();
		}else{
			coder.packText(`"${attr.name}":`,1);
			coder.packText(JSON.stringify(attr.val),0);
			coder.packText(`,`,0);
		}
	}
};

export {DocAppExporter};


