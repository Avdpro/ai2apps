import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
var DocCfgExporter,docCfgExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocCfgExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("DocCfg",DocCfgExporter);
inherits(DocCfgExporter,EditDocExporter);
docCfgExporter=DocCfgExporter.prototype;

//----------------------------------------------------------------------------
docCfgExporter.export=function(editDoc,opts){
	let prj,list,i,n,objExp,coder,exportObjs;
	prj=editDoc.prj;
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	coder.packText(`import {VFACT} from "/@vfact";`);
	coder.newLine();
	coder.beginDocObjTagBlcok(null,"Imports");
	coder.endDocObjTagBlcok(null,"Imports",0);
	coder.maybeNewLine();
	coder.packText(`var cfgURL=import.meta.url+"${editDoc.jaxId};"`);
	coder.newLine();
	//Imports:
	{
		let imports,path,stub,items;
		let orgDir=pathLib.dirname(editDoc.selfProxy.path);
		let prjPath=prj.path;
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(path.startsWith(prjPath)){//In same prj, use relative path
				path=pathLib.relative(path,orgDir);
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(null,"StartDoc");
	coder.endDocObjTagBlcok(null,"StartDoc",0);
	
	//Add localVars;
	let localVars,attr;
	localVars=editDoc.getAttr("localVars").attrList;
	if(localVars){
		for(attr of localVars){
			this.genLocalVar(attr);
		}
	}
	coder.packText("darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;");coder.newLine();
	coder.packText("VFACT.darkMode=darkMode;");coder.newLine();
	coder.packText("if(!window.codyAppCfgs){");coder.newLine();
	coder.packText("\twindow.codyAppCfgs={};");coder.newLine();
	coder.packText("}");coder.newLine();

	coder.beginDocObjTagBlcok(null,"StartObj");
	coder.endDocObjTagBlcok(null,"StartObj",0);

	//Export more objs:
	{
		let exObj;
		list=editDoc.getAttr("editObjs").attrList;
		n=list.length;
		exObj=list[0];
		if(exObj instanceof EditObj){
			coder.packText("//----------------------------------------------------------------------------");
			coder.newLine();
			coder.packText(`let ${exObj.name}=window.codyAppCfgs[cfgURL]||`);
			this.genObjSeg(exObj,false,"ExAttrs");	
			coder.eatPreComa();
			coder.packText(";");
			exportObjs.push(exObj.name);
			coder.maybeNewLine();
			coder.packText(`window.codyAppCfgs[cfgURL]=${exObj.name};`);coder.newLine();

			coder.packText(`appCfg.lanCode=VFACT.lanCode===null?"${prj.docApp.getAttrVal("language")||"EN"}":(VFACT.lanCode||"EN");`);coder.newLine();
			coder.packText("VFACT.lanCode=appCfg.lanCode;");coder.newLine();
			coder.packText("if(!VFACT.appCfg){");coder.newLine();
			coder.packText("\tVFACT.appCfg=appCfg;");coder.newLine();
			coder.packText("\twindow.jaxAppCfg=appCfg;");coder.newLine();
			coder.packText("}");coder.newLine();
			

			coder.packText(`${exObj.name}.applyCfg=function(){`);coder.newLine();
			coder.packText(`\tlet majorCfg,attrName,cAttr,mAttr;`);coder.newLine();
			coder.packText(`\tmajorCfg=VFACT.appCfg||window.jaxAppCfg;`);coder.newLine();
			coder.packText(`\tif(majorCfg && majorCfg!==${exObj.name}){`);coder.newLine();
			coder.packText(`\t\tfor(attrName in appCfg){`);coder.newLine();
			coder.packText(`\t\t\tif(attrName in majorCfg){`);coder.newLine();
			coder.packText(`\t\t\t\tcAttr=appCfg[attrName];`);coder.newLine();
			coder.packText(`\t\t\t\tmAttr=majorCfg[attrName];`);coder.newLine();
			coder.packText(`\t\t\t\tif(typeof(cAttr)==="object"){`);coder.newLine();
			coder.packText(`\t\t\t\t\tif(typeof(mAttr)==="object"){`);coder.newLine();
			coder.packText(`\t\t\t\t\t\tObject.assign(cAttr,mAttr);`);coder.newLine();
			coder.packText(`\t\t\t\t\t}`);coder.newLine();
			coder.packText(`\t\t\t\t}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){`);coder.newLine();
			coder.packText(`\t\t\t\t\tappCfg[attrName]=mAttr;`);coder.newLine();
			coder.packText(`\t\t\t\t}`);coder.newLine();
			coder.packText(`\t\t\t}`);coder.newLine();
			coder.packText(`\t\t}`);coder.newLine();
			coder.packText(`\t}`);coder.newLine();
			coder.packText(`};`);coder.newLine();
			//Upgrade
			coder.packText(`${exObj.name}.proxyCfg=function(proxy){`);coder.newLine();
			coder.packText(`\tif(window.codyAppCfgs[cfgURL]===${exObj.name}){`);coder.newLine();
			coder.packText(`\t\twindow.codyAppCfgs[cfgURL]=proxy;`);coder.newLine();
			coder.packText(`\t}`);coder.newLine();
			coder.packText(`\t${exObj.name}=proxy;`);coder.newLine();
			coder.packText(`};`);coder.newLine();
		}
	}

	coder.newLine();
	coder.beginDocObjTagBlcok(null,"EndDoc");
	coder.endDocObjTagBlcok(null,"EndDoc",0);
	//export
	coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docCfgExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	if(editObj.def.navi){
		coder.packText(`//"jaxId":"${editObj.jaxId}"`);
	}
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttr(attr,1);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(null,exSeg);
			coder.endDocObjTagBlcok(null,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docCfgExporter.genArraySeg=function(editObj,withName){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("[");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttr(attr,0);
			}
		}
	}
	coder.eatPreComa();
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("],");
};

//----------------------------------------------------------------------------
docCfgExporter.genAttr=function(attr,withName=1){
	let valText,val;
	let coder=this.coder;
	valText=attr.valText;
	if(valText.startsWith("#")){
		let pos;
		if(withName){
			coder.packText(`"${attr.name}":`,1);
		}
		pos=valText.indexOf("#>");
		if(pos>1){
			coder.packText(valText.substring(1,pos),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
		coder.packText(`,`,0);
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		if(withName){
			coder.packText(`"${attr.name}":`,1);
		}
		coder.packText("$V(()=>{",0);
		coder.packText(valText.substring(2,pos),0);
		coder.packText("}",0);
		if(valText[pos+1]==="("){
			let pos2=valText.lastIndexOf(")");//Track items:
			coder.packText(","+valText.substring(pos+2,pos2),0);
		}
		coder.packText(`,`,0);
	}else{
		if(attr instanceof EditObj){
			coder.maybeNewLine();
			if(withName){
				coder.packText(`"${attr.name}":`,1);
			}
			this.genObjSeg(attr,false,false);
			coder.newLine();
		}else if(attr instanceof EditArray){
			coder.maybeNewLine();
			if(withName){
				coder.packText(`"${attr.name}":`,1);
			}
			this.genArraySeg(attr,false,false);
			coder.newLine();
		}else{
			if(withName){
				coder.packText(`"${attr.name}":`,1);
			}
			coder.packText(JSON.stringify(attr.val),0);
			coder.packText(`,`,0);
		}
	}
};

//----------------------------------------------------------------------------
docCfgExporter.genLocalVar=function(attr){
	let coder=this.coder;
	let valText,pos;
	valText=attr.valText;
	coder.maybeNewLine();
	coder.packText(`let ${attr.name}=`);
	if(attr instanceof EditObj){
		this.genObjSeg(attr,0,0);
		coder.eatPreComa();
		coder.packText(";");
	}else if(valText.startsWith("#")){
		pos=valText.lastIndexOf("#>");
		if(pos>0){
			coder.packText(`${valText.substring(pos+2)};`);
		}else{
			coder.packText(`${valText.substring(1)};`);
		}
	}else if(valText.startsWith("${")){
		pos=valText.lastIndexOf("}");
		if(pos>0){
			let traceText;
			coder.packText(`$V(()=>(${valText.substring(2,pos)})`,0);
			traceText=valText.substring(pos);
			coder.packText(`${traceText.startsWith(",")?traceText:""});`,0);
		}else{
			coder.packText(`$V(()=>(${valText.substring(2)}));`);
		}
	}else{
		coder.packText(`${JSON.stringify(attr.val)};`);
	}
	coder.newLine();
};


export {DocCfgExporter};


