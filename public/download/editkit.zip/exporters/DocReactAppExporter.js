import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
var DocReactAppExporter,docReactAppExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocReactAppExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("DocApp",DocReactAppExporter);
inherits(DocReactAppExporter,EditDocExporter);
docReactAppExporter=DocReactAppExporter.prototype;

//----------------------------------------------------------------------------
docReactAppExporter.export=function(editDoc,opts){
	let list,i,n,objExp,coder,exportObjs,externLibCnt,docType;
	exportObjs=[];
	docType=this.docType=editDoc.getAttr("exportTarget").val;
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	//if(docType==="vfact")
	{
		coder.packText(`import React from "/@react";`,0);coder.newLine();
		coder.packText(`import ReactDOM from '/@react-dom';`,0);coder.newLine();
		coder.packText(`import {loadFont} from "/@vfact/vfact_react.js";`,0);coder.newLine();
		coder.packText(`import {appCfg} from "./cfg/appCfg.js";`,0);coder.newLine();
	}
	externLibCnt=0;
	//Extern lib imports:
	{
		let prj;
		let imports,val,path,stub,items;
		let orgDir=pathLib.dirname(editDoc.selfProxy.path);
		let prjPath=editDoc.prj.path;
		prj=editDoc.prj;
		imports=prj.externGearLibs.attrList;
		for(val of imports){
			path=val.getAttrVal("path");
			path=pathLib.join(path,"cfg/appCfg.js");
			coder.packText(`import{} from "${path}";`,0);coder.newLine();
			externLibCnt++;
		}
	}
	coder.beginDocObjTagBlcok(null,"MoreImports");
	coder.endDocObjTagBlcok(null,"MoreImports",0);

	if(externLibCnt>0){
		coder.packText(`//Prefix extern-lib's appCfgs:`,0);coder.newLine();
		coder.packText(`{`,0);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let cfgs,name;`,0);coder.newLine();
			coder.packText(`cfgs=window.codyAppCfgs;`,0);coder.newLine();
			coder.packText(`for(name in cfgs){`,0);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`cfgs[name].applyCfg();`,0);coder.newLine();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`}`,0);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`,0);coder.newLine();
	}

	//TODO:Load images?

	coder.beginDocObjTagBlcok(null,"StartApp");
	coder.endDocObjTagBlcok(null,"StartApp",0);

	//if(docType==="vfact")
	{
		coder.packText(`//----------------------------------------------------------------------------`,0);coder.newLine();
		coder.packText(`//Start the app:`,0);coder.newLine();
		coder.packText(`async function startApp() {`,0);
		coder.indentMore();coder.newLine();
		//Load fonts:
		{
			let prj,attr,urlAttr,urlText,name,pos;
			let fonts=editDoc.getAttr("fonts").attrList;
			prj=editDoc.prj;
			for(let attr of fonts){
				urlAttr=attr.getAttr("url");
				if(urlAttr.hyper){
					urlText=urlAttr.valText;
					if(urlText.startsWith("#")){
						urlText=urlText.substring(1);
					}else if(urlText.startsWith("${")){
						pos=urlText.lastIndexOf("}");
						if(pos>0){
							urlText=urlText.substring(2,pos);
						}else{
							urlText=urlText.substring(2);
						}
					}
				}else{
					urlText=urlAttr.val;
					if(urlText.startsWith(prj.path)){
						urlText=urlText.substring(prj.path.length+1);
					}
				}
				coder.packText(`await loadFont(${JSON.stringify(attr.name)},"url(${urlText}",{}));`,0);
				coder.newLine();
			}
		}
		coder.beginDocObjTagBlcok(null,"AppCode");
		coder.endDocObjTagBlcok(null,"AppCode",0);
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`,0);coder.newLine();
		coder.packText(`startApp();`,0);coder.newLine();
		coder.newLine();
	}
	coder.beginDocObjTagBlcok(null,"EndDoc");
	coder.endDocObjTagBlcok(null,"EndDoc",0);
	coder.newLine();
	return coder.genDocText();
};

export {docReactAppExporter};


