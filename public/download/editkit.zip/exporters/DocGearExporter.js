import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditDocExporter,genAttrValText,genLocalizeValText} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
import {DocClassExporter} from "./DocClassExporter.js";
import {exportFlowSegs,docHasFlowSegsAIExpose,genDocFlowSegsAIExpose} from "../segflow/EditFlowSegExport.js";

var DocGearExporter,docGearExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocGearExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("LibJS",DocGearExporter);
inherits(DocGearExporter,EditDocExporter);
docGearExporter=DocGearExporter.prototype;
let exportMockup=false;
//----------------------------------------------------------------------------
docGearExporter.export=function(editDoc,opts){
	let list,i,n,objExp,coder,exportObjs,subStates;
	let path,baseName,exportName,docType;
	opts=opts||{};
	subStates=[];
	exportObjs=[];
	docType=this.docType=editDoc.getAttr("exportTarget").val;
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	path=editDoc.getAttr("path").val;
	baseName=pathLib.basename(path);
	{
		let pos=baseName.indexOf(".");
		exportName=(pos>0)?(baseName.substring(0,pos)):baseName;
		exportObjs.push(exportName);
	}
	exportMockup=opts.mockup||false;

	//Imports:
	{
		let imports,path,stub,items;
		let orgPath=opts.path||editDoc.selfProxy.path;
		let orgDir=opts.orgDir||pathLib.dirname(orgPath);
		let prjPath=editDoc.prj.path;
		{
			coder.packText(`import {$P,VFACT,callAfter,sleep} from "/@vfact";`,0);
			coder.newLine();
			coder.packText(`import inherits from "/@inherits";`,0);
			coder.newLine();
		}
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(!stub.isUsed()){
				continue;
			}
			if(path.startsWith(prjPath)){//In same prj, use relative path
				if(path.startsWith(orgDir)){
					path="./"+pathLib.basename(path);
				}else if(!path.startsWith("/@")){
					path=pathLib.relative(orgDir,path);
				}
			}
			if(opts.fixExt){
				let ext;
				ext=pathLib.extname(path);
				if(ext!==".js"){
					path=path.substring(0,path.length-ext.length)+".js";
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			/*if(docType==="vfact"){
				path=path.replaceAll("ui/lib","ui");
			}*/
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);
	coder.packText(`const $ln=appCfg.lanCode||VFACT.lanCode||"EN";`,0);
	coder.newLine();

	//Export class objs:
	{
		let exObj,funcArgs,superClass;
		list=editDoc.getAttr("editObjs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			exObj=list[i];
			if(exObj instanceof EditObj){
				DocClassExporter.exportClass(coder,exObj,null);
			}
		}
	}
	//Export Major hud-gear:
	{
		let exObj,funcArgs,arg,ppts,attr,localVars,hudNames;
		exObj=editDoc.hudObj;
		coder.packText("//----------------------------------------------------------------------------");
		coder.newLine();
		//:Constructor:
		funcArgs=editDoc.getAttr("createArgs");
		if(funcArgs){
			funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
		}
		coder.packText(`let ${exportName}=function(`);
		if(funcArgs){
			coder.packText(""+funcArgs);
		}
		coder.eatPreComa();
		coder.packText(`){`);
		{
			coder.indentMore();
			coder.newLine();
			coder.packText("let cfgColor,cfgSize,txtSize,state;");coder.newLine();
			coder.packText("let cssVO,self;");coder.newLine();
			coder.packText(`const $ln=appCfg.lanCode||VFACT.lanCode||"EN";`);
			//named huds
			{
				let i,n
				hudNames=[];
				exObj.runOnAllHuds((hud)=>{
					if(hud!==exObj && hud.exposeNameVal.val){
						let name=hud.properties.getAttr("id").val;
						if(name){
							hudNames.push(name);
						}
					}
				},false);
				n=hudNames.length;
				if(n){
					let name,names;
					names={};
					coder.maybeNewLine();
					coder.packText(`let `);
					for(i=0;i<n;i++){
						name=hudNames[i];
						name=name[0].toLowerCase()+name.substring(1);
						if(!names[name]){
							if(i>0){
								coder.packText(`,`);
							}
							coder.packText(name);
							names[name]=1;
						}
					}
					coder.packText(`;`);
					coder.newLine();
				}
			}
			coder.newLine();
			{
				coder.packText("cfgColor=appCfg.color;");coder.newLine();
				coder.packText("cfgSize=appCfg.size;");coder.newLine();
				coder.packText("txtSize=appCfg.txtSize;");coder.newLine();
				coder.newLine();
			}
			//Add localVars;
			localVars=editDoc.getAttr("localVars").attrList;
			for(attr of localVars){
				this.genLocalVar(attr,subStates);
			}
			coder.newLine();
			coder.beginDocObjTagBlcok(exObj,"LocalVals");
			coder.endDocObjTagBlcok(exObj,"LocalVals",0);
			coder.newLine();
			coder.beginDocObjTagBlcok(exObj,"PreState");
			coder.endDocObjTagBlcok(exObj,"PreState",0);
			//States:
			{
				let stateObj=editDoc.getAttr("state");
				if(stateObj.attrList.length>0){
					coder.packText("state=");
					this.genObjSeg(editDoc.getAttr("state"),false,"ExState");
					coder.eatPreComa();
					coder.packText(";");
					coder.newLine();
					if(!subStates.length){
						coder.packText("state=VFACT.flexState(state);");coder.newLine();
					}else{
						subStates=subStates.map(item=>item.name);
						coder.packText(`state=VFACT.flexState(state,${""+subStates});`);coder.newLine();
					}
				}
			}
			coder.beginDocObjTagBlcok(exObj,"PostState");
			coder.endDocObjTagBlcok(exObj,"PostState",0);

			this.genHudGearCSSSeg(exObj,hudNames);	

			//:Functions
			let funcs=exObj.getAttr("functions");
			if(funcs){
				funcs=funcs.attrList;
				for(let func of funcs){
					this.genFunctionSeg(exObj.name,func);
				}
			}
			//:Logic flow:
			exportFlowSegs(editDoc,this);
			coder.beginDocObjTagBlcok(exObj,"PostCSSVO");
			coder.endDocObjTagBlcok(exObj,"PostCSSVO",0);
			
			coder.packText(`cssVO.constructor=${exportName};`);coder.newLine();
			coder.packText("return cssVO;");
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("};");
		coder.maybeNewLine();

		coder.beginDocObjTagBlcok(exObj,"ExCodes");
		coder.endDocObjTagBlcok(exObj,"ExCodes",0);
		
		//:AI Spot:
		if(editDoc.getAttrVal("exposeToAI")){
			coder.newLine();
			coder.packText("//----------------------------------------------------------------------------");coder.newLine();
			coder.packText(exportName+".exposeAI=");
			this.genGearAISpot(editDoc,exObj);	
		}

		if(opts.exposeGear||editDoc.exposeGear.val){
			coder.newLine();
			coder.packText("//----------------------------------------------------------------------------");coder.newLine();
			coder.packText(`${exportName}.gearExport={`);
			{
				let desc;
				coder.indentMore();
				coder.newLine();
				coder.packText(`framework: "${docType||"jax"}",`);
				coder.newLine();
				coder.packText(`hudType: "${exObj.properties.getAttr('type').val}",`);
				coder.newLine();
				if(editDoc.oneHud.val){
					coder.packText(`oneHud: true,`);
					coder.newLine();
				}
				{
					this.genInObjSegAttr(editDoc.gearName);
					//coder.packText(`showName:"${editDoc.gearName.val||""}",`);
				}
				{
					let path=editDoc.gearIcon.val;
					//path=path?pathLib.join("/~/-editkit",path):"gears.svg";
					coder.packText(`icon:"${path}",`);
				}
				{
					let path=editDoc.getAttr("previewImg").val;
					if(path){
						coder.packText(`previewImg:"${path}",`);
					}else{
						coder.packText(`previewImg:false,`);
					}
				}
				coder.newLine();
				coder.packText(`fixPose:${editDoc.getAttr("fixPose").val||false},`);
				coder.packText(`initW:${editDoc.gearW.val||100},`);
				coder.packText(`initH:${editDoc.gearH.val||100},`);
				coder.maybeNewLine();
				desc=editDoc.getAttr("description");
				if(desc && desc.val){
					this.genInObjSegAttr(desc);
					//coder.packText(`desc:${JSON.stringify(desc)},`);
					coder.maybeNewLine();
				}
				coder.packText(`catalog:"${editDoc.gearCatalog.val||""}",`);
				coder.newLine();
				coder.packText(`args: `);
				coder.packObj(editDoc.getAttr("createArgs").genEditObjAttrsDef());
				coder.maybeNewLine();
				if(editDoc.oneHud.val){
					let attrList,attrDef,attr,vo,valText,val;
					vo={};
					attrList=exObj.properties.attrList;
					for(attr of attrList){
						valText=attr.valText;
						val=attr.val;
						attrDef=attr.def;
						if(valText.startsWith("#")){
							vo[attr.name]={initVal:val,initValText:valText};
						}else if(valText.startsWith("${")){
							vo[attr.name]={initVal:val,initValText:valText};
						}else {
							if(!attr.isHideExport()){
								if(val!==attrDef.initVal){
									vo[attr.name]={initVal:val};
								}
							}
						}
					}
					delete vo.x; delete vo.y;//We don't need x,y:
					coder.packText(`properties:${JSON.stringify(vo)}`);
					coder.newLine();
				}else{
					coder.packText(`state:{`);
					{
						let statePpts,ppt,exposedPpts;
						coder.indentMore();
						coder.newLine();
						exposedPpts=editDoc.exposeStateAttrs.attrList;
						statePpts=editDoc.getAttr("state").attrHash;
						n=exposedPpts.length;
						for(i=0;i<n;i++){
							ppt=exposedPpts[i].val;
							ppt=statePpts[ppt];
							if(ppt){
								coder.maybeNewLine();
								coder.packText(`${ppt.name}:{name:"${ppt.name}",type:"${ppt.def.type}",initVal:${JSON.stringify(ppt.val)}${ppt.def.localizable?",localizable:true":""}${ppt.def.editType?`,editType:"${ppt.def.editType}"`:""}${ppt.def.editMode?`,editMode:"${ppt.def.editMode}"`:""}},`);
							}
						}
						coder.eatPreComa();
						coder.indentLess();
						coder.maybeNewLine();
					}
					coder.packText(`},`);
					coder.newLine();
					coder.packText(`properties:[`);
					//Add exposed ppt:
					ppts=editDoc.getAttr("exposeAttrs").attrList;
					for(attr of ppts){
						if(attr.val){
							coder.packText(`"${attr.name}",`);
						}
					}
					coder.eatPreComa();
					coder.packText(`],`);
					//Export faceTags:
					{
						let faceTags,i,n,faceTag;
						faceTags=editDoc.faceTags.attrList;
						n=faceTags.length;
						if(n>=0){
							coder.maybeNewLine();
							coder.packText(`faces:[`);
							if(opts.profile){
								coder.indentMore();
								for(i=0;i<n;i++){
									faceTag=faceTags[i];
									this.genFaceTagStub(editDoc,faceTag);
								}
								coder.indentLess();
								coder.newLine();
							}else{
								for(i=0;i<n;i++){
									faceTag=faceTags[i];
									if(exportMockup || (!faceTag.mockup.val)){
										coder.packText(`"${faceTags[i].name}",`);
									}
								}
							}
							coder.eatPreComa();
							coder.packText(`],`);
						}
					}
					//Export GearSlots:
					{
						coder.maybeNewLine();
						coder.packText(`subContainers:{`);
						coder.indentMore();
						coder.newLine();
						{
							exObj.runOnAllHuds((editHud)=>{
								let exposeAttr,contentLayout=0;
								exposeAttr=editHud.getAttr("exposeContainer");
								if(editHud.properties){
									contentLayout=editHud.properties.getAttr("contentLayout");
									if(contentLayout){
										contentLayout=contentLayout.val;
									}
								}
								if(exposeAttr && exposeAttr.val){
									let name;
									if(editHud===exObj){
										name="Contents";
									}else{
										name=editHud.properties.getAttr("id").val||"[Slot]";
									}
									coder.maybeNewLine();
									coder.packText('"'+editHud.jaxId+'":');
									coder.packText(JSON.stringify({showName:name,contentLayout:contentLayout})+",",0);
								}
							});
						}
						coder.eatPreComa();
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`},`);
					}
				}
				if(opts.profile){
					let profile,i,n,faceTags;
					profile=editDoc.getAttr("editEnv");
					coder.maybeNewLine();
					coder.packText(`deviceW:${profile.getAttr("screenW").val},`);
					coder.maybeNewLine();
					coder.packText(`deviceH:${profile.getAttr("screenH").val},`);
				}
				coder.beginDocObjTagBlcok(editDoc,"ExGearInfo");
				coder.endDocObjTagBlcok(editDoc,"ExGearInfo",0);
				coder.indentLess();
				coder.maybeNewLine();
			}
			coder.packText(`};`);
		}
	}

	//------------------------------------------------------------------------
	//export
	coder.newLine();
	coder.beginDocObjTagBlcok(editDoc,"EndDoc");
	coder.endDocObjTagBlcok(editDoc,"EndDoc",0);
	coder.newLine();
	coder.packText(`export default ${exportObjs[0]};`);coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docGearExporter.genHudGearCSSSeg=function(gearObj,hudNames){
	let doc;
	let attrList,attr;
	let faceTags,faceTag,i,n;
	let subList,sub;
	let docType=this.docType;
	let coder=this.coder;
	doc=gearObj.doc;
	coder.packText(`cssVO={`);
	{
		coder.indentMore();
		coder.newLine();
		coder.packText(`"hash":"${gearObj.jaxId}",nameHost:true,`);
		coder.newLine();
		//Inbuilt propoerties:
		attrList=gearObj.properties.attrList;
		for(attr of attrList){
			if(attr.def.export!==false) {
				this.genAttr(attr);
			}
		}
		coder.newLine();
		//Extra properties:
		attrList=gearObj.extraPpts.attrList;
		if(attrList.length>0){
			for(attr of attrList){
				if(attr.def.export!==false) {
					this.genAttr(attr);
				}
			}
			coder.newLine();
		}
		//Export items:
		if(gearObj.subHuds){
			subList=gearObj.subHuds.attrList;
			if(subList&&subList.length){
				coder.maybeNewLine();
				//if(docType==="vfact")
				{
					coder.packText("children:[");
				}
				/*else{
					coder.packText("items:[");
				}*/
				{
					coder.indentMore();
					coder.newLine();
					for(sub of subList){
						this.genHudSubCSSSeg(sub);
					}
					coder.indentLess();
					coder.maybeNewLine();
				}
				coder.eatPreComa();
				coder.packText("],");
			}
		}
		//Export exposed state args:
		{
			let nameList=doc.exposeStateAttrs.attrList;
			let i,n,name;
			n=nameList.length;
			for(i=0;i<n;i++){
				name=nameList[i].val;
				coder.maybeNewLine();
				coder.packText(`get $$${name}(){return state["${name}"]},`);
				coder.maybeNewLine();
				coder.packText(`set $$${name}(v){`);
				{
					coder.indentMore();
					coder.newLine();
					coder.packText(`state["${name}"]=v;`);
					coder.newLine();
					coder.beginDocObjTagBlcok(gearObj,`Set${name}`);
					coder.endDocObjTagBlcok(gearObj,`Set${name}`,0);
					coder.indentLess();
					coder.maybeNewLine();
				}
				coder.packText("},");
				coder.newLine();
			}
		}
		coder.beginDocObjTagBlcok(gearObj,"ExtraCSS");
		coder.endDocObjTagBlcok(gearObj,"ExtraCSS",0);

		//Add faces here:
		faceTags=doc.faceTags.attrList;
		n=faceTags.length;
		if(n>=0){
			coder.maybeNewLine();
			coder.packText("faces:{");
				{
					coder.indentMore();
					coder.newLine();
					for(i=0;i<n;i++){
						faceTag=faceTags[i];
						if(exportMockup ||(!faceTag.mockup.val)){
							this.genFaceTag(doc,faceTag);
						}
					}
					coder.eatPreComa();
					coder.indentLess();
					coder.maybeNewLine();
				}
			coder.packText("},");
		}
		
		coder.maybeNewLine();
		coder.packText(`OnCreate:function(){`);
		{
			let i,n,name,orgName;
			coder.indentMore();
			coder.newLine();
			coder.packText(`self=this;`);
			coder.newLine();
			n=hudNames.length;
			if(n>0){
				for(i=0;i<n;i++){
					orgName=hudNames[i];
					name=orgName[0].toLowerCase()+orgName.substring(1);
					coder.packText(`${name}=self.${orgName};`);
				}
			}
			coder.newLine();
			coder.beginDocObjTagBlcok(gearObj,"Create");
			coder.endDocObjTagBlcok(gearObj,"Create",0);
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("},");
		coder.beginDocObjTagBlcok(gearObj,"EndCSS");
		coder.endDocObjTagBlcok(gearObj,"EndCSS",0);
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText("};");
};

//----------------------------------------------------------------------------
docGearExporter.genHudSubCSSSeg=function(gearObj){
	let docType;
	let attrList,attr;
	let subList,sub;
	let coder=this.coder;
	docType=this.docType;
	if((!exportMockup) && gearObj.mockup.val){
		return;
	}
	coder.maybeNewLine();
	coder.packText(`{`);
	{
		coder.indentMore();
		coder.newLine();
		coder.packText(`"hash":"${gearObj.jaxId}",`);
		coder.newLine();
		attrList=gearObj.properties.attrList;
		for(attr of attrList){
			if(attr.def.export!==false) {
				this.genAttr(attr);
			}
		}
		//Extra properties:
		attrList=gearObj.extraPpts.attrList;
		if(attrList.length>0){
			coder.maybeNewLine();
			for(attr of attrList){
				if(attr.def.export!==false) {
					this.genAttr(attr);
				}
			}
		}
		//Children components:
		coder.maybeNewLine();
		if(gearObj.subHuds){
			subList=gearObj.subHuds.attrList;
			if(subList&&subList.length>0){
				coder.maybeNewLine();
				coder.packText("children:[");
				{
					coder.indentMore();
					coder.newLine();
					for(sub of subList){
						this.genHudSubCSSSeg(sub);
					}
					coder.indentLess();
					coder.maybeNewLine();
				}
				coder.eatPreComa();
				coder.packText("],");
			}
		}
		//gearContainer slots:
		if(gearObj.containerSlots){
			let subList=gearObj.containerSlots.attrList;
			let slotSubs,hasSub=false;
			if(subList && subList.length>0){
				for(sub of subList){
					slotSubs=sub.subHuds.attrList;
					if(slotSubs&&slotSubs.length>0){
						hasSub=true;
					}
				}
				if(hasSub){
					coder.maybeNewLine();
					coder.packText("subContainers:{");
					{
						coder.indentMore();
						coder.newLine();
						for(sub of subList){
							slotSubs=sub.subHuds.attrList;
							if(slotSubs&&slotSubs.length>0){
								coder.packText(`"${sub.editJaxId}":[`);
								coder.indentMore();
								coder.newLine();
								{
									let sub;
									for(sub of slotSubs){
										this.genHudSubCSSSeg(sub);
									}
								}
								coder.indentLess();
								coder.maybeNewLine();
								coder.eatPreComa();
								coder.packText("],");
							}
						}
						coder.indentLess();
						coder.maybeNewLine();
					}
					coder.eatPreComa();
					coder.packText("},");
				}
			}
		}
		//Functions:
		let funcs=gearObj.getAttr("functions");
		if(funcs){
			funcs=funcs.attrList;
			for(let func of funcs){
				this.genSubItemFunctionSeg(func);
			}
		}
		if(gearObj.hasCodes.val){
			coder.beginDocObjTagBlcok(gearObj,"Codes");
			coder.endDocObjTagBlcok(gearObj,"Codes",0);
		}
		coder.maybeNewLine();
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText("},");
};

//----------------------------------------------------------------------------
//Export a function:
docGearExporter.genFunctionSeg=function(clsName,funcObj){
	let funcArgs;
	let coder=this.coder;
	coder.newLine();
	coder.packText("//------------------------------------------------------------------------");
	coder.newLine();
	//TODO: Comments:
	coder.packText(`cssVO.${funcObj.name}=function(`,0);
	funcArgs=funcObj.getAttr("callArgs");
	if(funcArgs){
		funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
		coder.packText(""+funcArgs);
	}
	coder.packText(`){`,0);
	{
		coder.indentMore();
		coder.newLine();
		coder.beginDocObjTagBlcok(funcObj,"FunctionBody");
		coder.endDocObjTagBlcok(funcObj,"FunctionBody",0);
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText(`};`,0);
	coder.newLine();
};

//----------------------------------------------------------------------------
//Export a function in sub items:
docGearExporter.genSubItemFunctionSeg=function(funcObj){
	let funcArgs,segName;
	let coder=this.coder;
	if(funcObj.entrySeg && funcObj.entrySeg.inGearDoc){
		segName=funcObj.entrySeg.getAttrVal("id");
	}else{
		segName=null;
	}
	//TODO: Comments:
	coder.maybeNewLine();
	coder.packText(`"${funcObj.name}":function(`,0);
	funcArgs=funcObj.getAttr("callArgs");
	if(funcArgs){
		funcArgs=funcArgs.attrList.map(item=>item.name);//Object.keys(funcArgs.attrHash);
		coder.packText(""+funcArgs);
	}
	coder.packText(`){`,0);
	{
		coder.indentMore();
		coder.newLine();
		if(segName){
			coder.packText(`self.${segName}(this,`);
			if(funcArgs){
				coder.packText(""+funcArgs);
			}
			coder.eatPreComa();
			coder.packText(`);`);
			coder.newLine();
		}else{
			coder.beginDocObjTagBlcok(funcObj,"FunctionBody");
			coder.endDocObjTagBlcok(funcObj,"FunctionBody",0);
		}
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText(`},`,0);
	coder.newLine();
};

//----------------------------------------------------------------------------
docGearExporter.genLocalVar=function(attr,subStates){
	let coder=this.coder;
	let valText,pos,docType,attrDef,exportName;
	
	docType=this.docType;
	attrDef=attr.def;
	valText=attr.valText;

	if(attrDef.exportValText){
		valText=attrDef.exportValText(attr,docType);
	}else{
		valText=attr.valText;
	}
	exportName=attrDef.exportName||attr.name;
	if(exportName instanceof Function){
		exportName=exportName(attr,docType);
		if(!exportName){
			return;
		}
	}

	coder.maybeNewLine();
	coder.packText(`let ${exportName}=`);
	if(attr instanceof EditObj){
		if(attr.def.type==="uistate"){
			subStates.push(attr);
			coder.packText("VFACT.flexState(",0);
			this.genObjSeg(attr,0,0);
			coder.eatPreComa();
			coder.packText(");",0);
		}else{
			this.genObjSeg(attr,0,0);
			coder.eatPreComa();
			coder.packText(";");
		}
	}else{
		if(attr.localize){
			coder.packText(genLocalizeValText(attr)+";",0);
		}else{
			coder.packText(genAttrValText(attr,valText)+";",0);
		}
	}
	coder.newLine();
};

//----------------------------------------------------------------------------
docGearExporter.genAttr=function(attr){
	this.genInObjSegAttr(attr);
};

//----------------------------------------------------------------------------
docGearExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docGearExporter.genFaceObjSeg=function(hudFace){
	let coder=this.coder;
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=hudFace.properties.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genInObjSegAttr(attr,true);
			}
		}
		coder.maybeNewLine();
		list=hudFace.anis.attrList;
		n=list.length;
		if(n>0){
			coder.packText("ani:[")
			coder.indentMore();
			coder.newLine();
			{
				for(i=0;i<n;i++){
					this.genAniObjSeg(list[i],0,null);
				}
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("]");
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docGearExporter.genAniObjSeg=function(hudAni){
	let coder=this.coder;
	coder.maybeNewLine();
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr,hasCode;
		list=hudAni.properties.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttr(attr);
			}
		}
		let funcs=hudAni.getAttr("functions");
		if(funcs){
			funcs=funcs.attrList;
			for(let func of funcs){
				this.genSubItemFunctionSeg(func);
			}
		}
		hasCode=hudAni.getAttrVal("codes");
		if(hasCode){
			coder.beginDocObjTagBlcok(hudAni,"Codes");
			coder.endDocObjTagBlcok(hudAni,"Codes");
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docGearExporter.genInObjSegAttr=function(attr,noHide){
	let valText,val,attrDef,docType,exportName;
	let coder=this.coder;
	docType=this.docType;
	attrDef=attr.def;
	val=attr.val;
	if(attrDef.exportValText){
		valText=attrDef.exportValText(attr,docType);
	}else{
		valText=attr.valText;
	}
	exportName=attrDef.exportName||attr.name;
	if(exportName instanceof Function){
		exportName=exportName(attr,docType);
		if(!exportName){
			return;
		}
	}
	if(attr.localize){
		coder.packText(`"${exportName}":`,1);
		coder.packText(genLocalizeValText(attr)+",",0);
	}else if(valText.startsWith("#")){
		let pos;
		pos=valText.indexOf("#>",1);
		coder.packText(`"${exportName}":`,1);
		if(pos>0){
			coder.packText(valText.substring(pos+2),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
		coder.packText(",",0);
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		{
			coder.packText(`"${exportName}":`,1);
			coder.packText("$P(()=>(",0);
			coder.packText(valText.substring(2,pos),0);
			coder.packText(")",0);
		}
		if(valText[pos+1]===","){
			coder.packText(valText.substring(pos+1),0);
		}
		coder.packText(`),`,0);
	}else{
		if(!noHide && attr.isHideExport()){
			return;
		}
		if(attr instanceof EditObj){
			coder.maybeNewLine();
			coder.packText(`"${exportName}":`,1);
			this.genObjSeg(attr,false,false);
			coder.newLine();
		}else{
			coder.packText(`"${exportName}":`,1);
			if(attr.exportCode){
				coder.packText(attr.exportCode(docType),0);
			}else{
				coder.packText(JSON.stringify(attr.val),0);
			}
			coder.packText(`,`,0);
		}
	}
};

//----------------------------------------------------------------------------
docGearExporter.genFaceTagStub=function(doc,faceTag){
	let coder,name,time,faceTimes;
	coder=this.coder;
	name=faceTag.name;
	time=faceTag.getAttrVal("delay")||0;
	if(time===0){
		faceTimes=faceTag.faceTimes;
		if(faceTimes){
			let faceTime;
			faceTimes=faceTimes.attrList;
			for(faceTime of faceTimes){
				time+=faceTime.time.val;
			}
		}
	}
	coder.maybeNewLine();
	coder.packText(`{name:"${name}",entry:${!!faceTag.getAttr("previewEntry").val},next:"${faceTag.getAttr("mockupNext").val}",desc:${JSON.stringify(faceTag.getAttr("description").val)},time:${time}},`);//TODO: Add key, mockup, etc...
};

//----------------------------------------------------------------------------
docGearExporter.genFaceTag=function(doc,faceTag,isFaceTime=false){
	let coder,name,hudObj,hudId,faceFunc,faceTimes,faceState;
	coder=this.coder;
	if(isFaceTime){
		name="@"+faceTag.time.val;
	}else{
		name=faceTag.name;
	}
	coder.packText(`"${name}":{`);
	{
		coder.indentMore();
		coder.newLine();
		faceState=faceTag.getAttr("state");
		if(faceState){
			coder.packText(`"/":function(){`);
			{
				let list,i,n,attr,attrText,pos;
				coder.indentMore();
				list=faceState.attrList;
				n=list.length;
				for(i=0;i<n;i++){
					attr=list[i];
					coder.newLine();
					attrText=attr.valText;
					if(attrText[0]==="#"){
						attrText=attrText.substring(1);
					}else if(attrText.startsWith("${")){
						pos=attrText.lastIndexOf("}");
						if(pos>0){
							attrText=attrText.substring(2,pos);
						}else{
							attrText=attrText.substring(2);
						}
					}else{
						attrText=JSON.stringify(attrText);
					}
					coder.packText(`state["${attr.name}"]=${attrText};`);
				}
				coder.indentLess();
				coder.newLine();
			}
			coder.packText(`},`);
		}

		faceFunc=faceTag.getAttr("preFunc").val;
		if(faceFunc){
			coder.beginDocObjTagBlcok(faceTag,"PreCode");
			coder.endDocObjTagBlcok(faceTag,"PreCode",0);
		}
		hudObj=doc.hudObj;
		hudObj.runOnAllHuds((hud)=>{
			let faces,face;
			faces=hud.faces.attrList;
			FindFace:{
				for(face of faces){
					if(face.faceTag===faceTag){
						break FindFace;
					}
				}
				return;
			}
			if(!face.faceAttrList.length && !face.anis.attrList.length){
				return;
			}
			coder.maybeNewLine();
			hudId=hud.properties.getAttr("id");
			hudId=hudId?hudId.val:null;
			if(hud===hudObj){
				coder.packText(`"#self":`);
			}else{
				if(hudId){
					coder.packText(`/*${hudId}*/`);
				}
				coder.packText(`"#${hud.jaxId}":`);
			}
			this.genFaceObjSeg(face);
		},false);
		//Export face times:
		faceTimes=faceTag.faceTimes;
		if(faceTimes){
			let faceTime;
			faceTimes=faceTimes.attrList;
			for(faceTime of faceTimes){
				this.genFaceTag(doc,faceTime,1);
			}
		}
		faceFunc=faceTag.getAttr("faceFunc").val;
		if(faceFunc){
			coder.beginDocObjTagBlcok(faceTag,"Code");
			coder.endDocObjTagBlcok(faceTag,"Code",0);
		}else{
			coder.eatPreComa();
		}
		coder.indentLess();
		coder.maybeNewLine();
	}
	coder.packText("},");
};

//----------------------------------------------------------------------------
docGearExporter.genGearAISpot=function(editDoc,gearObj){
	let funcArgs;
	let coder=this.coder;
	coder.packText(`async function(hud,appAIVO,opts){`,0);
	coder.indentMore();coder.newLine();
	{
		let descAttr;
		coder.packText("let exposeVO;");coder.newLine();
		coder.beginDocObjTagBlcok(gearObj,"PreAISpot");
		coder.endDocObjTagBlcok(gearObj,"PreAISpot",0);
		
		coder.packText("exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);");coder.newLine();

		descAttr=gearObj.getAttr("descAI");
		coder.packText(`exposeVO.type=`);this.genAttrStatement(editDoc.getAttr("gearName"));coder.packText(";");coder.newLine();
		coder.packText(`exposeVO.typeDescription=`);this.genAttrStatement(editDoc.getAttr("descAI"));coder.packText(";");coder.newLine();

		//Expose functions:
		if(docHasFlowSegsAIExpose(editDoc)){
			coder.packText("exposeVO.functions=");
			genDocFlowSegsAIExpose(editDoc,this);
			coder.packText(";");coder.newLine();
		}
		
		//Expose Sub-UI-Tree:
		if(editDoc.getAttrVal("exposeTree2AI")){
			coder.packText("if(!opts.recursive){");
			coder.indentMore();coder.newLine();
			{
				coder.packText("let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);");coder.newLine();
				coder.packText("if(subList && subList.length){exposeVO.children=subList;}");coder.newLine();
				
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText("}");coder.newLine();
		}
		
		coder.beginDocObjTagBlcok(gearObj,"PostAISpot");
		coder.endDocObjTagBlcok(gearObj,"PostAISpot",0);
		coder.packText("return exposeVO;");coder.newLine();
		coder.indentLess();coder.maybeNewLine();
	}
	coder.packText(`};`,0);
	coder.newLine();
};

export {DocGearExporter};


