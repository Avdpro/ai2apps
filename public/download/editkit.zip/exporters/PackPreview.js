import {VFACT} from "/@vfact";
import {tabOS,tabFS,tabNT} from "/@tabos";
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {rollupConfigObj} from "/@rollup";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgCloud} from "/@homekit/ui/DlgCloud.js";
import terser from "/@terser/rollup-plugin.js";
import {path2Zip} from "/@zippath";
const $ln=VFACT.lanCode;
let rootPath;
let fixTabOS={
	resolveId (importee,importer) {
		let basePath,path;
		console.log(">>>>>resolveId: "+importee+" from "+importer);
		if(importee.startsWith("/")){
			return importee;
		}
		if(importer){
			if(importer.startsWith("/@")){
				let ext=pathLib.extname(importer);
				if(!ext){
					//This is a in-package-file: like /@fs imports "./const.js".
					return pathLib.join(importer,importee);
				}
				basePath=pathLib.dirname(importer);
			}else{
				basePath=pathLib.dirname(importer);
			}
		}else{
			basePath=rootPath;
		}
		path=pathLib.join(basePath,importee);
		//console.log(">>>>>import: "+importee+" from "+importer+" => "+path);
		return path;
	},
	load:async function(fileName){
		//console.log(">>>>>loadFile: "+fileName);
		if(fileName==="/@tabos" || fileName==="/-tabos/tabos.js"){
			let code;
			try{
				let res=await fetch(fileName);
				if(res.ok){
					code=await res.text();
					code=`import staticFS from "./tabos_fs.js";\n${code}`;
					code=code.replace('(await import("./tabos_fs.js")).default',"staticFS");
					return await code;
				}
			}catch(err){
			}
		}
		if(fileName.endsWith("PackPreview.js")){
			return "export default function(){};";
		}
		if(fileName.endsWith("DlgCloud.js")){
			return "function DlgCloud(){};\nexport default DlgCloud;\nexport {DlgCloud};";
		}
		return null;
	},
	renderChunk: async function(code, chunk, outputOptions) {
		let pos,cnt,ptn;
		pos=0;
		cnt=0;
		ptn="var cfgURL=import.meta.url;";
		while(pos>=0){
			pos=code.indexOf(ptn);
			if(pos>0){
				cnt+=1;
				code=code.substring(0,pos)+`var cfgURL=import.meta.url+"${cnt}";`+code.substring(pos+ptn.length);
			}
		}
		ptn="/@editkit/assets/preview";
		pos=code.indexOf(ptn);
		if(pos>0){
			code=code.substring(0,pos)+`pvassets`+code.substring(pos+ptn.length);
		}
		//console.log(">>>>>renderFile:");
		//console.log(chunk);
		return code;
	}
};

function downloadFile(data,fileName){
	let blob, url;
	let e;
	blob = new Blob([data], {type: "application/octet-stream"});
	url = URL.createObjectURL(blob);
	VFACT.webFileDownload.download = fileName;
	VFACT.webFileDownload.href = url;

	//Generate a mouse click:
	e = document.createEvent('MouseEvents');
	e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
	VFACT.webFileDownload.dispatchEvent(e);

	//Release the URLData:
	window.setTimeout(() => {
		URL.revokeObjectURL(url);
	}, 10000);
}

async function genPreviewData(app,prjPath,tty){
	let rollupVO;
	let htmlCode,ptn,jsCode,zipObj,zipData,htmlData;
	//Setup Env:
	rootPath=prjPath;
	rollupVO={
		input:"./preview.js",
		output:{
			file:"./temp/_preview.js",
			format:"es",
		},
		external:["./experters/PackPreview.js","experters/PackPreview.js"],
		plugins:[fixTabOS,/*terser()*/]
	};
	await tabOS.setup();
	tabFS.chdir(prjPath);

	//Generate data:
	tty.textOut("Rollup sources...\n");
	await rollupConfigObj(tty,rollupVO);
	//Merge html...
	tty.textOut("Generate html file...\n");
	htmlCode=await tabFS.readFile(`${prjPath}/preview.html`,"utf8");
	ptn=`<script type="text/javascript">`;
	jsCode=await tabFS.readFile(`${prjPath}/_preview.js`,"utf8");
	jsCode=`<script type="module">\n${jsCode}\n</script>`;
	{
		let ptn,pos;
		ptn=`<script type="module" src="preview.js"></script>`;
		pos=htmlCode.indexOf(ptn);
		//htmlCode=htmlCode.replace(`<script type="module" src="preview.js"></script>`,jsCode);//Error: $$ will be replace to $ due to String.replace behavior
		htmlCode=htmlCode.substring(0,pos)+jsCode+htmlCode.substring(pos+ptn.length);
	}
	//Generate zip obj:
	zipObj=await path2Zip(`${prjPath}`,[await tabFS.getEntry(`${prjPath}/assets`)],tty,{zipObj:true});
	//zipObj=await path2Zip(`${prjPath}`,[await tabFS.getEntry(`${prjPath}/_preview.html`),await tabFS.getEntry(`${prjPath}/assets`)],tty,{zipObj:true});
	//Add html:
	{
		await zipObj.file("preview.html", htmlCode);
	}
	//Add shared images:
	{
		let items,stub,name,data;
		items=await tabFS.getEntries("/-editkit/assets/preview");
		for(stub of items){
			if(!stub.dir){
				name=stub.name;
				data=await tabFS.readFile("/-editkit/assets/preview/"+name);
				if(data) {
					data=new Uint8Array(data);//Makesure type
					await zipObj.file("pvassets/"+name, data);
				}				
			}
		}
	}
	console.log(zipObj);
	//generate zip file data:
	zipData=zipObj.generateAsync({
		type : "uint8array",
		compression: "DEFLATE",
		compressionOptions: {level: 6}				
	});			
	return zipData;
}

async function share2Cloud(app,slot,zipData,tty){
	let resVO;
	tty.textOut("Sending preview package to cloud...\n");
	try{
		let data64;
		data64=Base64.encode(zipData);
		resVO=await tabNT.makeCall("sharePreview",{"slot":slot,"data":data64});
		if(resVO.code!==200){
			tty.textOut(`Share preview to cloud failed ${resVO.code}: ${resVO.info}\n`);
			throw "Share preview failed, please check logs for details.";
		}
	}catch(err){
		throw(err);
	}
	tty.textOut("Preview shared.\n");
	return resVO.url;
}

async function genPreview(app,prjPath,mode){
	let pms,funcDone,funcError;
	pms=new Promise((resolve,reject)=>{
		funcDone=resolve;
		funcError=reject;
	});
	app.showDlg(DlgCloud,{
		mode:"Work",
		workingText:"Rollup preview codes...",
		work:async function(tty){
			let zipData;
			if(mode==="cloud"){
				if(!await tabNT.checkLogin()){
					tty.textOut("Error: can't read user info.\n");
					throw "Please login before sharing to cloud.";
				}
			}
			zipData=await genPreviewData(app,prjPath,tty);
			switch(mode){
				case "zip":
					downloadFile(zipData,pathLib.basename(prjPath)+"_preview.zip");
					return true;
				case "cloud":{
					let url;
					url=await share2Cloud(app,0,zipData,tty);
					console.log("URL: "+url);
					window.open(url,"Preview");
					return url;
				}
					
			}
			return;
		},
		callback(result){
			funcDone(result);
		}
	});
	return pms;
};

async function packPreview(app,btn,prjPath){
	let data,item;
	item=await app.modalDlg(DlgMenu,{
		hud:btn,
		items:[
			{text:(($ln==="CN")?("以ZIP格式共享"):/*EN*/("Share as ZIP")),mode:"zip"},
			{text:(($ln==="CN")?("通过Tab-OS云共享"):/*EN*/("Share via cloud")),mode:"cloud"},
		]
	});
	if(!item)
		return;
	await genPreview(app,prjPath,item.mode);
};

export default packPreview;
export {packPreview};