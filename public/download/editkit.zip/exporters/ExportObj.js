import {EditObjExporter} from "./EditObjExporter.js";
import inherits from "/@inherits";
import {$P} from "/@vfact";

var ExportObj,exportObj;

//----------------------------------------------------------------------------
//This exporter exports an edit-attr as a plain javasript val/object
ExportObj=function(prj){
	EditObjExporter.call(this,prj);
};
inherits(ExportObj,EditObjExporter);
exportObj=ExportObj.prototype;

//----------------------------------------------------------------------------
ExportObj.export=exportObj.export=function(orgObj,hyper){
	let objVO,attrList,attrDef,valText,pos,pos2,attrName,traceVal;
	let objType=orgObj.def.type;
	if(objType==="array"){
		let i,n,attr;
		objVO=[];
		attrList=orgObj.attrList;
		n=attrList.length;
		for(i=0;i<n;i++){
			objVO[i]=this.export(attrList[i]);
		}
		return objVO;
	}else if(orgObj.attrHash){
		objVO={};
		attrList=orgObj.attrList;
		for(let attr of attrList){
			attrDef=attr.def;
			if(attrDef.notLiveVal){
				continue;
			}
			attrName=attrDef.liveValName||attrDef.exportName||attrDef.name;
			if("liveVal" in attrDef){
				let val=attrDef.liveVal;
				if(val instanceof Function){
					val=val(attr);
					objVO[attrName]=val;
				}else{
					objVO[attrName]=val;
				}
			}else{
				if(attr.type==="object"){
					objVO[attrName]=this.export(attr);
				}else if(attr.type==="array"){
					objVO[attrName]=this.export(attr);
				}else{
					valText=attr.valText;
					if(hyper && valText && valText.startsWith("${")){
						pos=valText.lastIndexOf("}");
						if(pos<0){
							//Wrong
							objVO[attrName]=[...attr.val];
						}
						pos2=valText.indexOf(",",pos);
						traceVal=null;
						if(pos2>0){
							traceVal=valText.substring(pos2+1);
							if(traceVal){
								traceVal=orgObj.getScopeVal(traceVal)||null;
							}
						}
						valText=valText.substring(2,pos);
						
						objVO[attrName]=$P(orgObj.genHyperAttrFunc(valText),traceVal);
					}else{
						if(!attr.isHideExport()){
							//objVO[attrName]=attr.val;
							if(attr.arrayVal){
								objVO[attrName]=[...attr.val];
							}else{
								objVO[attrName]=attr.val;
							}
						}
					}
				}
			}
		}
		return objVO;
	}else{
		return orgObj.val;
	}
};
export default ExportObj;
export {ExportObj};