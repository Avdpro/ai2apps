import {tabFS} from "/@tabos";
import pathLib from "/@path";
import {EditObj} from "../EditObj.js";
import {esprima} from "/@tabos/utils/esprima.mjs";

async function exportTemplate(path,newPath,inertnal=false){
	let docText,basePath,newName;

	//Get Gear/View name:
	{
		let pos;
		newName=pathLib.basename(newPath);
		pos=newName.lastIndexOf(".");
		newName=newName.substring(0,pos);
	}
	
	if(path.startsWith("/@")){
		//path is ok
	}else if(path.startsWith("/~/")){
		//path is ok
	}else if(path.startsWith("//")){
		path="/~/"+path.substring(2);//make it safer
	}else if(path.startsWith("/")){
		path="/~/"+path.substring(1);//file path, convert to http path:
	}
	basePath=pathLib.dirname(path);
	docText=await (await fetch(path)).text();
	//Change Doc JAXID:
	{
		let pos,pos2,codeText,codyMark,codyText,editText,codyVO;
		let orgJaxId,newJaxId;
		codyMark="\n\/\*\Cody Project Doc*/";
		pos=docText.indexOf(codyMark);
		if(pos<0){
			console.warn(`Doc ${path} has no Cody mark`);
			return false;
		}
		editText=docText.substring(0,pos);
		pos+=codyMark.length;
		codyText=docText.substring(pos);
		codyText=codyText.replaceAll("\n//","\n");
		let segMark1="\/\*\#{Doc*/";
		let segMark2="/*Doc\}\#\*\/";
		pos=codyText.indexOf(segMark1);
		if(pos>0){
			pos2=codyText.lastIndexOf(segMark2);
			if(pos2>0){
				codyText=codyText.substring(pos+segMark1.length,pos2);
			}else{
				console.error(`Doc ${path}'s cody mark "/*Doc}#*/" missing`);
				throw new Error(`Doc ${path}'s cody mark "/*Doc}#*/" missing`);
			}
		}
		try{
			codyVO=JSON.parse(codyText);
		}catch(err){
			console.error(err);
			codyVO=null;
		}
		orgJaxId=codyVO.jaxId;
		newJaxId=EditObj.genObjId();
		codyVO.jaxId=newJaxId;
		docText=docText.replaceAll(orgJaxId,newJaxId);
	}
	//Fix import path:
	if(!inertnal){
		let ast,body,node,importPath,posDelta;
		posDelta=0;
		ast=esprima.parseModule(docText,{range:true});
		body=ast.body;
		for(node of body){
			if(node.type==="ImportDeclaration"){
				importPath=node.source.value;
				if(importPath.startsWith(".")){
					let fixedPath;
					//Fix path:
					fixedPath=pathLib.join(basePath,importPath);
					docText=docText.substring(0,node.source.range[0]+1+posDelta)+fixedPath+docText.substring(node.source.range[1]-1+posDelta);
					posDelta+=fixedPath.length-importPath.length;
				}
			}
		}
	}
	await tabFS.writeFile(newPath,docText,"utf8");
};

export {exportTemplate};