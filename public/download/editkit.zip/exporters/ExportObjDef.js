import inherits from "/@inherits";
import {EditObjExporter} from "./EditObjExporter.js";
import {EditAttr} from "../EditAttr.js";

var ExportObjDef,exportObjDef;

//----------------------------------------------------------------------------
//This exporter exports an edit-object as a edit-object-def
ExportObjDef=function(prj){
	EditObjExporter.call(this,prj);
};
inherits(ExportObjDef,EditObjExporter);
exportObjDef=ExportObjDef.prototype;

ExportObjDef.export=exportObjDef.export=function(orgObj,opts){
	let defVO,attrList,defAttrs,defAttr,defHints;
	opts=opts||{};
	defVO=opts.defVO;
	if(!defVO){
		defVO={};
		defVO.name=opts.name||"ExportObjDef";
		defVO.icon=opts.icon||"object.svg";
		defVO.allowExtraAttr=("allowExtraAttr" in opts)?opts.allowExtraAttr:1;
		defVO.attrs={};
		defVO.listHint=[];
		defHints=defVO.listHint;
	}else{
		defHints=[];
		defVO.listHint.push({name:orgObj.name,showName:orgObj.name,attrs:defHints,open:0});
	}
	defAttrs=defVO.attrs;
	attrList=orgObj.attrList;
	for(let attr of attrList){
		if(defAttrs[attr.name]){
			continue;
		}
		//Add this attr as key attr
		defAttr=defAttrs[attr.name]={
			name:attr.name,
			showName:attr.showName,
			type:attr.def.type,
			key:1
		};
		defHints.push(attr.name);
		switch(defAttr.type){
			case "object":{
				defAttr.def=this.export(attr,{name:attr.name,allowExtraAttr:attr.objDef.allowExtraAttr,icon:attr.objDef.icon||"object.svg"});
				break;
			}
			case "array":{
				defAttr.def=attr.def.def;
				//TODO: Clone the array?
				break;
			}
			case "classobj":{
				let mockup=attr.getAttr("mockup").val;
				defAttr.type="mockup";
				defAttr.className="ObjClass"+attr.objClass.jaxId//TODO: Code this:
				if(mockup){
					defAttr.initVal=mockup;
				}
				break;
			}
			default:{
				defAttr.initVal=attr.val;
				break;
			}
		}
		if(attr.isPath){
			//TODO: convert path?
		}
	}
	//superClass:
	let superClass=orgObj.getAttr("superClass");
	superClass=superClass?superClass.val:null;
	if(superClass){
		superClass=EditAttr.getClassType(superClass);
		if(superClass){
			this.export(superClass,{defVO:defVO});
		}
	}
	return defVO;
};
export default ExportObjDef;
export {ExportObjDef};