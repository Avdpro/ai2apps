var mergeCodeWithSeg;

function getIndent(text,pos){
	let spos,i,indent,c;
	spos=text.lastIndexOf("\n",pos);
	if(spos<0){
		spos=0;
	}
	indent="";
	for(i=pos-1;i>=spos;i--){
		c=text[i];
		if(c==="\t"||c===" "){
			indent=c+indent;
		}else{
			break;
		}
	}
	return indent;
}

function getLeadIndent(text){
	let cnt,i,n;
	cnt=0;
	n=text.length;
	for(i=0;i<n;i++){
		if(text[i]==='\t'){
			cnt++;
		}else{
			return cnt;
		}
	}
	return cnt;
}

function makeIndent(segCode,indent){
	let lines,i,n,line;
	lines=segCode.split("\n");
	n=lines.length;
	for(i=0;i<n;i++){
		line=lines[i];
		line=line.trimLeft();
		line=indent+line;
		lines[i]=line;
	}
	segCode=lines.join("\n");
	return segCode;
}

function countLeadingSpaces(str) {
  let match = str.match(/^ */);
  return match ? match[0].length : 0;
}

function checkIndentNum(lines){
	let i,n,line,lastSpaces,spaces,ds,minDs,minS;
	minDs=minS=10000;
	lastSpaces=-1;
	n=lines.length;
	for(i=0;i<n;i++){
		line=lines[i];
		if(!line || !line.trim()){
			continue;
		}
		if(line[0]==="\t"){
			return 0;//Using tab
		}else if(line[0]===" "){
			spaces=countLeadingSpaces(line);
			if(lastSpaces>=0 && spaces>lastSpaces){
				ds=spaces-lastSpaces;
				if(ds<minDs){
					minDs=ds;
				}
			}
			if(spaces<minS){
				minS=spaces;
			}
			lastSpaces=spaces;
		}else{
			lastSpaces=0;
		}
	}
	return minDs>0?minDs:(minS>0?minS:0);
}

function getBaseSpaces(lines){
	let i,n,line,s,minS;
	n=lines.length;
	minS=-1;
	for(i=0;i<n;i++){
		line=lines[i];
		if(!line || !line.trim()){
			continue;
		}
		s=countLeadingSpaces(line);
		if(s<minS){
			minS=s;
		}
	}
	return minS>=0?minS:0;
}

function getSegCode(code,mark,indent,isPython=false){
	let smark,emark,spos,epos,segCode,indentLen;
	let lines,i,n,line,baseIndent,orgIndent,dIndent,pfx,d;
	let indentSpaces;
	indentLen=indent.length;
	if(isPython){
		smark=`##{${mark}#`;
		emark=`##}${mark}#`;
	}else{
		smark=`/*#{${mark}*/`;
		emark=`/*}#${mark}*/`;
	}
	spos=code.indexOf(smark);
	epos=code.indexOf(emark);
	if(spos<0 || epos<=spos){
		return null;
	}
	segCode=code.substring(spos+smark.length,epos);
	lines=segCode.split("\n");
	lines.shift();//Skip the first line:
	n=lines.length;
	if(n>0){
		indentSpaces=checkIndentNum(lines);
		if(indentSpaces>0){
			baseIndent=getBaseSpaces(lines);
			for(i=0;i<n;i++){
				line=lines[i];
				orgIndent=countLeadingSpaces(lines[i]);
				dIndent=Math.floor((orgIndent-baseIndent)/indentSpaces);
				dIndent=dIndent<0?0:dIndent;
				pfx=indent;
				for(d=0;d<dIndent;d++){
					pfx+="\t";
				}
				line=line.trimLeft();
				line=pfx+line;
				lines[i]=line;
			}
		}else{
			baseIndent=getLeadIndent(lines[0]);
			for(i=0;i<n;i++){
				line=lines[i];
				orgIndent=getLeadIndent(lines[i]);
				dIndent=orgIndent-baseIndent;
				dIndent=dIndent<0?0:dIndent;
				pfx=indent;
				for(d=0;d<dIndent;d++){
					pfx+="\t";
				}
				line=line.trimLeft();
				line=pfx+line;
				lines[i]=line;
			}
		}
	}
	segCode=lines.join("\n");
	return segCode;
}

//----------------------------------------------------------------------------
mergeCodeWithSeg=function(orgCode,tgtCode,msSegs,isPython=false){
	let lead,pos,mark,smark,emark,pos2,pos3,indent,segCode;
	let mergedSeg=new Set();
	if(isPython){
		lead="##{";
	}else{
		lead="/*#{";
	}
	msSegs=msSegs||{};
	pos=0;
	do{
		pos=orgCode.indexOf(lead,pos);
		indent=getIndent(orgCode,pos);
		if(pos<0){
			break;
		}
		if(isPython){
			pos2=orgCode.indexOf("#\n",pos);
			if(pos2<0){
				throw new Error(`Code seg mark end error, seg start: ${orgCode.substring(pos,pos+10)}`);
			}
			mark=orgCode.substring(pos+(lead.length),pos2);
			smark=`##{${mark}#\n`;
			emark=`##}${mark}#\n`;
		}else{
			pos2=orgCode.indexOf("*/",pos);
			if(pos2<0){
				throw new Error(`Code seg mark end error, seg start: ${orgCode.substring(pos,pos+10)}`);
			}
			mark=orgCode.substring(pos+(lead.length),pos2);
			smark=`/*#{${mark}*/\n`;
			emark=`/*}#${mark}*/\n`;
		}
		pos3=orgCode.indexOf(emark,pos2);
		if(pos3<0){
			throw new Error(`Code seg close error, seg mark: `+mark);
		}
		if(!mark.endsWith("+")){
			segCode=getSegCode(tgtCode,mark,indent,isPython);
			if(segCode===null){
				segCode=msSegs[mark];
				if(segCode){
					//adjust indents:
					segCode=makeIndent(segCode,indent);
					delete msSegs[mark];
				}else{
					segCode=null;
				}
			}
			mergedSeg.add(mark);
			pos+=smark.length;
			if(segCode){
				orgCode=orgCode.substring(0,pos)+segCode+orgCode.substring(pos3);
			}
		}
		pos=pos3+emark.length;
	}while(pos>=0);

	//Find and keep missing code segs:
	do{
		pos=tgtCode.indexOf(lead,pos);
		indent=getIndent(tgtCode,pos);
		if(pos<0){
			break;
		}
		if(isPython){
			pos2=tgtCode.indexOf("#\n",pos);
			if(pos2<0){
				throw new Error(`Target code seg mark end error, seg start: ${tgtCode.substring(pos,pos+10)}`);
			}
			mark=tgtCode.substring(pos+(lead.length),pos2);
			smark=`##{${mark}#\n`;
			emark=`##}${mark}#\n`;
		}else{
			pos2=tgtCode.indexOf("*/",pos);
			if(pos2<0){
				throw new Error(`Target code seg mark end error, seg start: ${tgtCode.substring(pos,pos+10)}`);
			}
			mark=tgtCode.substring(pos+(lead.length),pos2);
			smark=`/*#{${mark}*/\n`;
			emark=`/*}#${mark}*/\n`;
		}
		pos3=tgtCode.indexOf(emark,pos2);
		if(pos3<0){
			throw new Error(`Code seg close error, seg mark: `+mark);
		}
		if(!mergedSeg.has(mark)){
			pos+=smark.length;
			segCode=tgtCode.substring(pos,pos3);
			msSegs[mark]=segCode;
		}
		pos=pos3+emark.length;
	}while(pos>=0);
	
	return orgCode;
};
export default mergeCodeWithSeg;
export {mergeCodeWithSeg,getSegCode};