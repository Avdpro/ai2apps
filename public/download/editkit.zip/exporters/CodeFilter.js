import {esprima} from "/@tabos/utils/esprima.mjs";
import {EditObj} from "../EditObj.js";

//----------------------------------------------------------------------------
//Get class member properties:
function getMemberProperties(code){
	let ast,ppts,blocks,block;
	
	function parseObject(objAttr,objNode){
		let pptList,pptNode,valueNode,pptName,pptAttr;
		pptList=objNode.properties;
		for(pptNode of pptList){
			if(pptNode.key && pptNode.key.type==="Identifier" && pptNode.method===false){
				pptName=pptNode.key.name;
				valueNode=pptNode.value;
				if(valueNode.type==="Literal"){
					objAttr.setAttrByText(pptName,valueNode.raw,true);
				}else if(valueNode.type==="ObjectExpression"){
					pptAttr=objAttr.addAttr({name:pptName,type:"object",def:"Object",extraAttr:true});
					parseObject(pptAttr,valueNode);
				}
			}
		}
		
	}
	
	function parseBlock(block){
		let left,right;
		let pptName,pptAttr;
		if(block.type!=="ExpressionStatement"){
			return;
		}
		block=block.expression;
		if(block.type!=="AssignmentExpression"){
			return;
		}
		if(block.operator!=="="){
			return;
		}
		left=block.left;
		right=block.right;
		if(left.type!=="MemberExpression"){
			return;
		}
		if(left.object.type!=="ThisExpression"){
			return;
		}
		if(left.property.type!=="Identifier"){
			return;
		}
		pptName=left.property.name;
		if(!pptName){
			return;
		}
		if(right.type==="Literal"){
			ppts.setAttrByText(pptName,right.raw,true);
		}else if(right.type==="ObjectExpression"){
			pptAttr=ppts.addAttr({name:pptName,type:"object",def:"Object",extraAttr:true});
			parseObject(pptAttr,right);
		}
	}
	
	try{
		let blockNode;
		ast=esprima.parseScript(code,{range:true});
		//console.log("Code AST: ");
		//console.log(ast);
		//parse ast, get properties:
		blocks=ast.body;
		ppts=new EditObj(null,{name:"ppts",type:"object",def:"Object"},true);
		for(blockNode of blocks){
			parseBlock(blockNode);
		}
		return ppts;
	}catch(err){
		console.log(err);
	}
	return null;
};

//----------------------------------------------------------------------------
//Trim code minify tokens:
function trimCodes(code){
	let ast;
};

export {getMemberProperties,trimCodes};