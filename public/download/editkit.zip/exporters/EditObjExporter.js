import {EditObj} from "../EditObj.js";

var EditObjExporter,editObjExporter;
//****************************************************************************
//This is be base-class of object-exporter.
//Object-exporter export a EditObj to an VO-object.
EditObjExporter=function(prj){
	this.prj=prj;
};
editObjExporter=EditObjExporter.prototype={};
var objExporterRegs={};

//----------------------------------------------------------------------------
EditObjExporter.regExporter=function(name,exporter){
	objExporterRegs[name]=exporter;
};

//----------------------------------------------------------------------------
EditObjExporter.getExporter=function(name){
	return objExporterRegs[name];
};

//----------------------------------------------------------------------------
editObjExporter.export=function(editObj,opts){
	let exportPath=opts.path;
	return null;
};

export {EditObjExporter};