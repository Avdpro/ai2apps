import pathLib from "/@path";
import {CdyCoder} from "./coder.js";
import {camelCSSName} from "/@vfact/vfact_core.js";
import {vfactCSSPptMap,vfactElmtPptMap} from "../edithud/HTMLPptDef.js";

let HTMLExporter,htmlExporter;
//****************************************************************************
//Export HUDObj to HTML text, this is not export a whole doc, it just export a EditHudObj to a HTML code Seg.
HTMLExporter=function(prj){
	this.prj=prj;
	this.coder=null;
	this.editHudObj=null;
	this.hyperValToken=["{","}"];//Open/Close mark for dynamic val:
	this.defaultCSSPptMap=vfactCSSPptMap;
	this.defaultElmtPptMap=vfactElmtPptMap;
	this.allowDynamic=true;
};
htmlExporter=HTMLExporter.prototype={};

//----------------------------------------------------------------------------
htmlExporter.export=function(editDoc,opts){
	//TODO: Code this:
};

//----------------------------------------------------------------------------
htmlExporter.getElmtPptMap=function(editHudObj){
	let objDef;
	objDef=editHudObj.objDef;
	if(objDef.HTMLElmtPptMap){
		return objDef.HTMLElmtPptMap;
	}
	return this.defaultElmtPptMap;
};

//----------------------------------------------------------------------------
htmlExporter.getCSSPptMap=function(editHudObj){
	let objDef;
	objDef=editHudObj.objDef;
	if(objDef.HTMLCSSPptMap){
		return objDef.HTMLCSSPptMap;
	}
	return this.defaultCSSPptMap;
};

//----------------------------------------------------------------------------
htmlExporter.exportEditHudObj=function(editHudObj,coder){
	let objDef;
	objDef=editHudObj.objDef;
	this.coder=coder||this.coder;
	coder=this.coder;//Make sure coder
	coder.maybeNewLine();
	coder.packText(`<${objDef.HTMLElemntType||"div"} `,0);
	this.exportEditHudObjElementPpts(editHudObj);
	coder.packText(`style="`,0);
	this.exportEditHudObjCSS(editHudObj);
	coder.packText(`">`,0);
	coder.indentMore();	
	coder.maybeNewLine();
	this.exportSubHudObjs(editHudObj);
	coder.indentLess();	
	coder.maybeNewLine();
	coder.packText(`</${objDef.HTMLElemntType||"div"}>`,0);
};

//----------------------------------------------------------------------------
htmlExporter.genEditHudObjStubVO=function(editHudObj,exporter){
	let vo,idAttr,objDef;
	let list,sub;
	vo={
		editHudObj:editHudObj,
		idName:"",
		hash:editHudObj.jaxId,
		hyper:false,
		elmtAttrs:null,
		styleObj:null,
		faces:null,
		subElmts:null,
	};
	objDef=editHudObj.objDef;
	idAttr=editHudObj.properties.getAttr("id");
	if(idAttr){
		vo.idName=idAttr.val;
	}
	vo.elmtAttrs=this.genPptsVO(editHudObj,this.getElmtPptMap(editHudObj),vo,exporter);
	vo.styleObj=this.genPptsVO(editHudObj,this.getCSSPptMap(editHudObj),vo,exporter);
	vo.faces=this.checkHudObjFaces(editHudObj,vo);
	//Check-in inbuilt sub-elements:
	list=objDef.HTMLSubElements;
	if(list){
		let subVO,i,n;
		vo.subElmts=[];
		//Export editHubObj's inbuilt sub element(s):
		n=list.length;
		for(i=0;i<n;i++){
			sub=list[i];
			subVO={
				idName:"",
				def:sub,
				elmtType:sub.elmtType,
				hash:editHudObj.jaxId+"_"+(i+1),
				hyper:vo.hyper,
				elmtAttrs:null,
				styleObj:null,
				faces:null,
				elmtPptMapp:sub.elmtPptMap,
				cssPptMapp:sub.cssPptMap,
			}
			subVO.elmtAttrs=this.genPptsVO(editHudObj,sub.elmtPptMap,subVO,exporter);
			subVO.styleObj=this.genPptsVO(editHudObj,sub.cssPptMap,subVO,exporter);
			if(sub.elmtContent){
				sub.elmtContent(editHudObj,subVO,exporter);
			}
			vo.subElmts.push(subVO);
		}
	}
	return vo;
};

//----------------------------------------------------------------------------
htmlExporter.genPptsVO=function(editHudObj,pptMap,tgtVO,exporter){
	let pptNames,pptName,jsName,def,attr2ValFunc,attr2ValFuncName;
	let hudPpts,pos;
	let vo={};
	hudPpts=editHudObj.properties;
	pptNames=Object.keys(pptMap);
	for(pptName of pptNames){
		def=pptMap[pptName];
		jsName=camelCSSName(pptName);
		if(def.export){
			def.export(editHudObj,vo,exporter||this);
		}else{
			let attr,valText;
			attr=hudPpts.getAttr(def.attrName);
			if(attr){
				valText=attr.valText;
				attr2ValFunc=def.attrVal2CSSVal;
				attr2ValFuncName=def.attrVal2CSSValFuncName||(attr2ValFunc?attr2ValFunc.name:null);
				if(this.allowDynamic && def.allowDynamic && attr.hyper){
					tgtVO.hyper=true;
					if(valText.startsWith("${")){
						pos=valText.lastIndexOf("}");
						if(pos>0 &&valText[pos+1]===","){
							vo[jsName]={code:this.genHyperAttrText(pptName,valText,attr2ValFuncName),trace:true};
						}else{
							vo[jsName]=this.genHyperAttrText(pptName,valText,attr2ValFuncName);
						}
					}else{
						vo[jsName]=this.genHyperAttrText(pptName,valText,attr2ValFuncName);
					}
				}else{
					valText=attr2ValFunc?attr2ValFunc(attr.val,editHudObj,this):(""+attr.val);
					if(valText!==def.hideValText){
						vo[jsName]=this.genStaticAttrText(valText);
					}
				}
				if(attr2ValFuncName && exporter && exporter.regUtilFunc){
					exporter.regUtilFunc(attr2ValFuncName);
				}
			}
		}
	}	
	return vo;
};

//----------------------------------------------------------------------------
htmlExporter.exportSubHudObjs=function(editHudObj){
	let coder,objDef,list,sub;
	coder=this.coder;
	objDef=editHudObj.objDef;
	list=objDef.HTMLSubElements;
	if(list){
		//Export editHubObj's inbuilt sub element(s):
		for(sub of list){
			coder.maybeNewLine();
			coder.packText(`<${sub.elementType||"div"} `,0);
			this.exportEditHudObjElementPpts(editHudObj,sub.elmtPptMap);
			coder.packText(`style="`,0);
			this.exportEditHudObjCSS(editHudObj,sub.cssPptMap);
			coder.packText(`">`,0);
		}
	}
	if(editHudObj.subHuds){
		list=editHudObj.subHuds.attrList;
		if(list&&list.length){
			for(sub of list){
				this.exportEditHudObj(sub);
			}
		}
	}
};

//----------------------------------------------------------------------------
htmlExporter.checkHudObjFaces=function(editHudObj,vo){
	let faces,face,stub,styleObj,keyName;
	let pptMap,faceStub;
	faces=editHudObj.faces.attrList;
	for(face of faces){
		if(face.properties.attrList.length>0){
			return true;
		}
	}
	return false;
};

//----------------------------------------------------------------------------
htmlExporter.exportEditHudObjElementPpts=function(editHudObj,pptMap){
	let coder,pptNames,pptName,def,attr2ValFunc;
	let hudPpts;
	coder=this.coder;
	hudPpts=editHudObj.properties;
	pptMap=pptMap||this.getElmtPptMap(editHudObj);
	pptNames=Object.keys(pptMap);
	for(pptName of pptNames){
		def=pptMap[pptName];
		if(def.export){
			def.export(editHudObj,coder,this);
		}else{
			let attr,valText;
			attr=hudPpts.getAttr(def.attrName);
			if(attr){
				valText=attr.valText;
				if(this.allowDynamic && def.allowDynamic && attr.hyper && valText.startsWith("${")){
					this.packHyperElmtAttr(pptName,valText,def.attrVal2CSSValFuncName);
				}else{
					attr2ValFunc=def.attrVal2CSSVal;
					valText=attr2ValFunc?attr2ValFunc(attr.val,editHudObj,this):(""+attr.val);
					if(valText!==def.hideValText){
						this.packStaticElmtAttr(pptName,valText);
					}
				}
			}
		}
	}
};

//----------------------------------------------------------------------------
htmlExporter.exportEditHudObjCSS=function(editHudObj,pptMap){
	let coder,pptNames,pptName,def,attr2ValFunc;
	let hudPpts;
	coder=this.coder;
	hudPpts=editHudObj.properties;
	pptMap=pptMap||this.getCSSPptMap(editHudObj);
	pptNames=Object.keys(pptMap);
	for(pptName of pptNames){
		def=pptMap[pptName];
		if(def.export){
			def.export(editHudObj,coder,this);
		}else{
			let attr,valText;
			attr=hudPpts.getAttr(def.attrName);
			if(attr){
				valText=attr.valText;
				if(this.allowDynamic && def.allowDynamic && attr.hyper && valText.startsWith("${")){
					this.packHyperCSSAttr(pptName,valText,def.attrVal2CSSValFuncName);
				}else{
					attr2ValFunc=def.attrVal2CSSVal;
					valText=attr2ValFunc?attr2ValFunc(attr.val,editHudObj,this):(""+attr.val);
					if(valText!==def.hideValText && valText!==""){
						this.packStaticCSSAttr(pptName,valText);
					}
				}
			}
		}
	}
};

//----------------------------------------------------------------------------
htmlExporter.fixHyperCode=function(valText){
	return valText;
};

//----------------------------------------------------------------------------
htmlExporter.genStaticAttrText=function(valText){
	if(typeof(valText)==="string"){
		return `${JSON.stringify(valText)}`;
	}else if(valText){
		return `${JSON.stringify(valText)}`;
	}
};

//----------------------------------------------------------------------------
htmlExporter.genHyperAttrText=function(pptName,valText,attrFunc){
	let pos;
	if(valText.startsWith("${")){
		pos=valText.lastIndexOf("}");
		if(pos>0){
			valText=valText.substring(2,pos);
		}else{
			valText=valText.substring(2);
		}
	}else if(valText.startsWith("#")){
		valText=valText.substring(1);
	}
	valText=this.fixHyperCode(valText);
	if(attrFunc){
		return "`${"+attrFunc+"("+valText+")}`";
	}
	return "`${"+valText+"}`";
};

//----------------------------------------------------------------------------
htmlExporter.packHyperElmtAttr=function(keyword,valText,attrFunc){
	let coder,pos;
	coder=this.coder;
	pos=valText.lastIndexOf("}");
	if(pos>0){
		valText=valText.substring(2,pos);
	}else{
		valText=valText.substring(2);
	}
	valText=this.fixHyperCode(valText);
	coder.packText(`${keyword}="`,1);
	coder.packText(`${this.hyperValToken[0]}`,0);
	coder.packText(`${attrFunc?attrFunc+"(":""}${valText}${attrFunc?")":""})`,0);
	coder.packText(`${this.hyperValToken[1]}" `,0);
	coder.packText(";",0);
};

//----------------------------------------------------------------------------
htmlExporter.packStaticElmtAttr=function(keyword,valText){
	let coder;
	coder=this.coder;
	if(typeof(valText)==="string"){
		coder.packText(`${keyword}=`,1);
		coder.packText(`${JSON.stringify(valText)} `,0);
	}else if(valText){
		valText=""+valText;
		coder.packText(`${keyword}=`,1);
		coder.packText(`${JSON.stringify(valText)} `,0);
	}
};

//----------------------------------------------------------------------------
htmlExporter.packHyperCSSAttr=function(keyword,valText,attrFunc){
	let coder,pos;
	coder=this.coder;
	pos=valText.lastIndexOf("}");
	if(pos>0){
		valText=valText.substring(2,pos);
	}else{
		valText=valText.substring(2);
	}
	valText=this.fixHyperCode(valText);
	coder.packText(`${keyword}:`,1);
	coder.packText(`${this.hyperValToken[0]}`,0);
	coder.packText(`${attrFunc?attrFunc+"(":""}${valText}${attrFunc?")":""}`,0);
	coder.packText(`${this.hyperValToken[1]};`,0);
};

//----------------------------------------------------------------------------
htmlExporter.packStaticCSSAttr=function(keyword,valText){
	let coder;
	coder=this.coder;
	coder.packText(`${keyword}:`,1);
	coder.packText(`${valText};`,0);
};

export default HTMLExporter;
export {HTMLExporter};
