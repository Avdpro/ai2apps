import pathLib from "/@path";
import inherits from "/@inherits";
import {EditObj} from "../EditObj.js";
import {EditDocExporter} from "./EditDocExporter.js";
import {CdyCoder} from "./coder.js";
var DocVOExporter,docVOExporter;
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocVOExporter=function(prj){
	EditDocExporter.call(this,prj);
};
EditDocExporter.regExporter("DocVO",DocVOExporter);
inherits(DocVOExporter,EditDocExporter);
docVOExporter=DocVOExporter.prototype;

//----------------------------------------------------------------------------
docVOExporter.export=function(editDoc,opts){
	let list,i,n,objExp,coder,exportObjs;
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();

	//Imports:
	{
		let imports,path,stub,items;
		let orgDir=pathLib.dirname(editDoc.selfProxy.path);
		let prjPath=editDoc.prj.path;
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(path.startsWith(prjPath)){//In same prj, use relative path
				path=pathLib.relative(orgDir,path);
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);

	//Export more objs:
	{
		let exObj;
		list=editDoc.getAttr("editObjs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			exObj=list[i];
			if(exObj instanceof EditObj){
				coder.packText("//----------------------------------------------------------------------------");
				coder.newLine();
				coder.packText(`let ${exObj.name}=`);
				this.genObjSeg(exObj,false,"ExAttrs");	
				coder.eatPreComa();
				coder.packText(";");
				exportObjs.push(exObj.name);
				coder.maybeNewLine();
				coder.beginDocObjTagBlcok(exObj,"ExCodes");
				coder.endDocObjTagBlcok(exObj,"ExCodes",0);
				coder.newLine();
			}
		}
	}

	coder.newLine();
	coder.beginDocObjTagBlcok(editDoc,"EndDoc");
	coder.endDocObjTagBlcok(editDoc,"EndDoc",0);
	//export
	coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docVOExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	if(editObj.def.navi){
		coder.packText(`//"jaxId":"${editObj.jaxId}"`);
	}
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("},");
};

//----------------------------------------------------------------------------
docVOExporter.genAttr=function(attr){
	let valText,val;
	let coder=this.coder;
	valText=attr.valText;
	if(valText.startsWith("#")){
		let pos;
		coder.packText(`"${attr.name}":`,1);
		pos=valText.indexOf("#>");
		if(pos>1){
			coder.packText(valText.substring(1,pos),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		coder.packText(`"${attr.name}":`,1);
		coder.packText("$V(()=>{",0);
		coder.packText(valText.substring(2,pos),0);
		coder.packText("}",0);
		if(valText[pos+1]==="("){
			let pos2=valText.lastIndexOf(")");//Track items:
			coder.packText(","+valText.substring(pos+2,pos2),0);
		}
		coder.packText(`,`,0);
	}else{
		if(attr instanceof EditObj){
			coder.maybeNewLine();
			coder.packText(`"${attr.name}":`,1);
			this.genObjSeg(attr,false,false);
			coder.newLine();
		}else{
			coder.packText(`"${attr.name}":`,1);
			coder.packText(JSON.stringify(attr.val),0);
			coder.packText(`,`,0);
		}
	}
};

export {DocVOExporter};


