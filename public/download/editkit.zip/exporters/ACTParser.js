import pathLib from "/@path";
import {camelCSSName} from "/@vfact/vfact_core.js";

let ACTParser,actParser;
//****************************************************************************
//Parse EditKit runtime ACT to a VO that exporter can use
ACTParser=function(prj,opts){
	this.prj=prj;
	this.editHudObj=null;
	
	this.allowDynamic=opts.allowDynamic===false?false:true;
	this.hyperValToken=opts.hyperValToken||["{","}"];//Open/Close mark for dynamic val:
	this.hashNamePrefix=opts.hashNamePrefix||"";
	this.subNamePrefix=opts.subNamePrefix||"#";
	this.defaultCSSPptMap=opts.cssPptMap;
	this.defaultElmtPptMap=opts.elmtPptMap;

	this.rootHudObj=null;
	this.objStubMap=null;
	this.objNameSet=null;
	this.exposeNameSet=null;
	this.utilFuncSet=null;
	this.funcStubMap=null;
	this.funcNameSet=null;
};
actParser=ACTParser.prototype={};

//----------------------------------------------------------------------------
actParser.getElmtPptMap=function(editHudObj){
	let objDef;
	objDef=editHudObj.objDef;
	if(objDef.HTMLElmtPptMap){
		return objDef.HTMLElmtPptMap;
	}
	return this.defaultElmtPptMap;
};

//----------------------------------------------------------------------------
actParser.getCSSPptMap=function(editHudObj){
	let objDef;
	objDef=editHudObj.objDef;
	if(objDef.HTMLCSSPptMap){
		return objDef.HTMLCSSPptMap;
	}
	return this.defaultCSSPptMap;
};

//----------------------------------------------------------------------------
actParser.parseACT=function(editHudObj){
	this.rootHudObj=editHudObj;
	this.objStubMap=new Map();
	this.objNameSet=new Set();
	this.utilFuncSet=new Set();
	this.exposeNameSet=new Set();
	this.funcStubMap=new Map();
	this.funcNameSet=new Set();

	this.parseEditHudObj(editHudObj);
};

//---------------------------------------------------------------------------
actParser.parseEditHudObj=function(gearObj){
	let objStubMap,objNameSet,funcStubMap,funcNameSet;
	let objStub,setName;
	let objDef,list,sub,i,n;
	let hashNamePrefix,subNamePrefix;
	hashNamePrefix=this.hashNamePrefix;
	subNamePrefix=this.subNamePrefix;
	objDef=gearObj.objDef;
	objStubMap=this.objStubMap;
	objNameSet=this.objNameSet;
	funcStubMap=this.funcStubMap;
	funcNameSet=this.funcNameSet;
	objStub=this.genEditHudObjStubVO(gearObj,this);
	if(gearObj===this.rootHudObj){
		objStub.hyper=true;
	}
	objStubMap.set(gearObj,objStub);
	IndexName:{
		let indexName;
		if(objStub.idName){
			if(gearObj!==this.rootHudObj){
				this.exposeNameSet.add(objStub.idName);
			}
			if(!objNameSet.has(objStub.idName)){
				objNameSet.add(objStub.idName);
				objStub.indexName=objStub.idName;
				break IndexName;
			}
		}
		indexName=hashNamePrefix+objStub.hash;
		if(!objNameSet.has(indexName)){
			objNameSet.add(indexName);
			objStub.indexName=indexName;
			break IndexName;
		}
		let idx=1;
		indexName=hashNamePrefix+objStub.hash+idx;
		while(objNameSet.has(indexName)){
			idx++;
			indexName=hashNamePrefix+objStub.hash+idx;
		}
		objNameSet.add(indexName);
		objStub.indexName=indexName;
	}
	list=objStub.subElmts;
	if(list){
		n=list.length;
		for(i=0;i<n;i++){
			list[i].indexName=objStub.indexName+subNamePrefix+(i+1);
		}
	}

	//Export Events/Functions:
	{
		let funcs,i,n,funcAttr,funcName,stub,nameIdx;
		funcs=gearObj.getAttr("events");
		if(funcs){
			funcs=funcs.attrList;
			n=funcs.length;
			for(i=0;i<n;i++){
				funcAttr=funcs[i];
				funcName=objStub.indexName+"_"+funcAttr.name;
				if(funcNameSet.has(funcName)){
					nameIdx=1;
					do{
						funcName=objStub.indexName+"_"+funcAttr.name+nameIdx;
						nameIdx++;
					}while(funcNameSet.has(funcName));
				}
				stub={
					name:funcName,
					attr:funcAttr
				};
				funcStubMap.set(funcAttr,stub);
				funcNameSet.add(funcName);
			}
		}

		funcs=gearObj.getAttr("functions");
		if(funcs){
			funcs=funcs.attrList;
			n=funcs.length;
			for(i=0;i<n;i++){
				funcAttr=funcs[i];
				funcName=objStub.indexName+"_"+funcAttr.name;
				if(funcNameSet.has(funcName)){
					nameIdx=1;
					do{
						funcName=objStub.indexName+"_"+funcAttr.name+nameIdx;
						nameIdx++;
					}while(funcNameSet.has(funcName));
				}
				stub={
					name:funcName,
					attr:funcAttr
				};
				funcStubMap.set(funcAttr,stub);
				funcNameSet.add(funcName);
			}
		}
	}
	
	//Export children objs:
	if(gearObj.subHuds){
		list=gearObj.subHuds.attrList;
		if(list&&list.length){
			for(sub of list){
				this.parseEditHudObj(sub);
			}
		}
	}
};

//----------------------------------------------------------------------------
actParser.genEditHudObjStubVO=function(editHudObj){
	let vo,idAttr,objDef;
	let list,sub;
	vo={
		editHudObj:editHudObj,
		idName:"",
		hash:editHudObj.jaxId,
		hyper:false,
		elmtAttrs:null,
		styleObj:null,
		faces:null,
		subElmts:null,
	};
	objDef=editHudObj.objDef;
	idAttr=editHudObj.properties.getAttr("id");
	if(idAttr){
		vo.idName=idAttr.val;
	}
	vo.elmtAttrs=this.genPptsVO(editHudObj,this.getElmtPptMap(editHudObj),vo,this);
	vo.styleObj=this.genPptsVO(editHudObj,this.getCSSPptMap(editHudObj),vo,this);
	vo.faces=this.checkHudObjFaces(editHudObj,vo);
	//Check-in inbuilt sub-elements:
	list=objDef.HTMLSubElements;
	if(list){
		let subVO,i,n;
		vo.subElmts=[];
		//Export editHubObj's inbuilt sub element(s):
		n=list.length;
		for(i=0;i<n;i++){
			sub=list[i];
			subVO={
				idName:"",
				def:sub,
				elmtType:sub.elmtType,
				hash:editHudObj.jaxId+"_"+(i+1),
				hyper:vo.hyper,
				elmtAttrs:null,
				styleObj:null,
				faces:null,
				elmtPptMapp:sub.elmtPptMap,
				cssPptMapp:sub.cssPptMap,
			}
			subVO.elmtAttrs=this.genPptsVO(editHudObj,sub.elmtPptMap,subVO,this);
			subVO.styleObj=this.genPptsVO(editHudObj,sub.cssPptMap,subVO,this);
			if(sub.elmtContent){
				sub.elmtContent(editHudObj,subVO,this);
			}
			vo.subElmts.push(subVO);
		}
	}
	return vo;
};

//----------------------------------------------------------------------------
actParser.genPptsVO=function(editHudObj,pptMap,tgtVO){
	let pptNames,pptName,jsName,def,attr2ValFunc,attr2ValFuncName;
	let hudPpts,pos;
	let vo={};
	hudPpts=editHudObj.properties;
	pptNames=Object.keys(pptMap);
	for(pptName of pptNames){
		def=pptMap[pptName];
		jsName=camelCSSName(pptName);
		if(def.export){
			def.export(editHudObj,vo,this);
		}else{
			let attr,valText;
			attr=hudPpts.getAttr(def.attrName);
			if(attr){
				valText=attr.valText;
				attr2ValFunc=def.attrVal2CSSVal;
				attr2ValFuncName=def.attrVal2CSSValFuncName||(attr2ValFunc?attr2ValFunc.name:null);
				if(this.allowDynamic && def.allowDynamic && attr.hyper){
					tgtVO.hyper=true;
					if(valText.startsWith("${")){
						pos=valText.lastIndexOf("}");
						if(pos>0 &&valText[pos+1]===","){
							vo[jsName]={code:this.genHyperAttrText(pptName,valText,attr2ValFuncName),trace:true};
						}else{
							vo[jsName]=this.genHyperAttrText(pptName,valText,attr2ValFuncName);
						}
					}else{
						vo[jsName]=this.genHyperAttrText(pptName,valText,attr2ValFuncName);
					}
				}else{
					valText=attr2ValFunc?attr2ValFunc(attr.val,editHudObj,this):(""+attr.val);
					if(valText!==def.hideValText){
						vo[jsName]=this.genStaticAttrText(valText);
					}
				}
				if(attr2ValFuncName){
					this.regUtilFunc(attr2ValFuncName);
				}
			}
		}
	}	
	return vo;
};

//----------------------------------------------------------------------------
actParser.checkHudObjFaces=function(editHudObj,vo){
	let faces,face,stub,styleObj,keyName;
	let pptMap,faceStub;
	faces=editHudObj.faces.attrList;
	for(face of faces){
		if(face.properties.attrList.length>0){
			return true;
		}
	}
	return false;
};


//----------------------------------------------------------------------------
actParser.regUtilFunc=function(funcName){
	this.utilFuncSet.add(funcName);
};

//----------------------------------------------------------------------------
actParser.fixHyperCode=function(valText){
	return valText;
};

//----------------------------------------------------------------------------
actParser.genStaticAttrText=function(valText){
	if(typeof(valText)==="string"){
		return `${JSON.stringify(valText)}`;
	}else if(valText){
		return `${JSON.stringify(valText)}`;
	}
};

//----------------------------------------------------------------------------
actParser.genHyperAttrText=function(pptName,valText,attrFunc){
	let pos;
	if(valText.startsWith("${")){
		pos=valText.lastIndexOf("}");
		if(pos>0){
			valText=valText.substring(2,pos);
		}else{
			valText=valText.substring(2);
		}
	}else if(valText.startsWith("#")){
		valText=valText.substring(1);
	}
	valText=this.fixHyperCode(valText);
	if(attrFunc){
		return "`${"+attrFunc+"("+valText+")}`";
	}
	return "`${"+valText+"}`";
};

export default ACTParser;
export {ACTParser};
