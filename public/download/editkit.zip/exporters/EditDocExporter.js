import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";

var EditDocExporter,editDocExporter;
//****************************************************************************
//This is be base-class of doc-exporter.
//Doc-exporter export a EditDoc to a code-text.
EditDocExporter=function(prj){
	this.prj=prj;
};
editDocExporter=EditDocExporter.prototype={};
var objExporterRegs={};

//----------------------------------------------------------------------------
EditDocExporter.regExporter=function(name,exporter){
	objExporterRegs[name]=exporter;
};
//----------------------------------------------------------------------------
EditDocExporter.getExporter=function(name){
	return objExporterRegs[name];
};

//----------------------------------------------------------------------------
editDocExporter.export=function(editDoc,opts){
	return "";
};

//--------------------------------------------------------------------
function genAttrValText(attr,valText){
	let pos;
	if(valText===undefined){
		return "";
	}
	valText=""+valText;
	if(valText.startsWith("#")){
		pos=valText.lastIndexOf("#>");
		if(pos>0){
			return(`${valText.substring(pos+2)}`);
		}else{
			return(`${valText.substring(1)}`);
		}
	}else if(valText.startsWith("${")){
		pos=valText.lastIndexOf("}");
		if(pos>0){
			let traceText,code;
			code=`$P(()=>(${valText.substring(2,pos)})`;
			traceText=valText.substring(pos+1);
			code+=`${traceText.startsWith(",")?traceText:""})`;
			return code;
		}else{
			return `$P(()=>(${valText.substring(2)}))`;
		}
	}else{
		try{
			if(attr.exportCode){
				return attr.exportCode("gearTypeAttr");
			}
			return `${JSON.stringify(attr.text2Val(valText))}`;
		}catch(err){
			return JSON.stringify(attr.val);
		}
	}
};

//--------------------------------------------------------------------
function genLocalizeValText(attr){
	let code,locs,lans,text,isPy;
	function packLans(lans){
		let lan,code;
		if(lans.length>1){
			lan=lans.pop();
			text=locs[lan];
			if(text===undefined){
				text=locs["EN"];
			}
			code=`(($ln==="${lan}")?(${genAttrValText(attr,text)}):${packLans(lans)})`
		}else{
			lan=lans.pop();
			code=`(${genAttrValText(attr,locs[lan])})`
		}
		return code;
	}
	locs=attr.localize;
	lans=Object.keys(locs);
	return packLans(lans);
};

//--------------------------------------------------------------------
function genLocalizeValTextPy(attr){
	let code,locs,lans,text,isPy;
	function packLans(lans){
		let lan,code;
		if(lans.length>1){
			lan=lans.pop();
			text=locs[lan];
			if(text===undefined){
				text=locs["EN"];
			}
			code=`((${genAttrValText(attr,text)}) if(__Ln=="${lan}") else ${packLans(lans)})`
		}else{
			lan=lans.pop();
			code=`(${genAttrValText(attr,locs[lan])})`
		}
		return code;
	}
	locs=attr.localize;
	lans=Object.keys(locs);
	return packLans(lans);
};

//----------------------------------------------------------------------------
editDocExporter.genObjSeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("}");
};

//----------------------------------------------------------------------------
editDocExporter.genArraySeg=function(editObj,withName,exSeg){
	let coder=this.coder;
	if(withName){
		coder.packText(`"${editObj.name}":`,1);
	}
	coder.packText("[");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.def.export!==false) {
				this.genAttrStatement(attr);
				coder.packText(",");
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("]");
};

//----------------------------------------------------------------------------
editDocExporter.genInObjSegAttr=function(attr,withName=true){
	let valText,val,attrDef,docType,exportName;
	let coder=this.coder;
	docType=this.docType;
	attrDef=attr.def;
	val=attr.val;
	if(attrDef.exportValText){
		valText=attrDef.exportValText(attr,docType);
	}else{
		valText=attr.valText;
	}
	exportName=attrDef.exportName||attr.name;
	if(exportName instanceof Function){
		exportName=exportName(attr,docType);
		if(!exportName){
			return;
		}
	}
	if(withName){
		coder.packText(`"${exportName}":`,1);
	}
	this.genAttrStatement(attr);
	coder.packText(`,`,0);
};

//----------------------------------------------------------------------------
editDocExporter.genAttrStatement=function(attr){
	let valText,val,attrDef,docType,exportFunc;
	let coder=this.coder;
	if(!attr){
		coder.packText("undefined");
		return;
	}
	docType=this.docType;
	attrDef=attr.def;
	val=attr.val;
	exportFunc=attrDef.exportValText||attr.exportValText;
	if(exportFunc){
		valText=exportFunc.call(attr,attr,docType);
	}else{
		valText=attr.valText;
	}
	if(valText===undefined){
		valText="";
	}else{
		valText=""+valText;
	}
	if(attr.localize){
		if(this.isPython){
			coder.packText(genLocalizeValTextPy(attr),0);
		}else{
			coder.packText(genLocalizeValText(attr),0);
		}
	}else if(valText.startsWith("#")){
		let pos;
		pos=valText.indexOf("#>",1);
		if(pos>0){
			coder.packText(valText.substring(pos+2),0);
		}else{
			coder.packText(valText.substring(1),0);
		}
	}else if(valText.startsWith("${")){
		let pos=valText.lastIndexOf("}");
		{
			coder.packText("$P(()=>(",0);
			coder.packText(valText.substring(2,pos),0);
			coder.packText(")",0);
		}
		if(valText[pos+1]===","){
			coder.packText(valText.substring(pos+1),0);
		}
		coder.packText(`)`,0);
	}else{
		if(attr instanceof EditObj){
			this.genObjSeg(attr,false,false);
		}else if(attr instanceof EditArray){
			this.genArraySeg(attr,false,false);
		}else{
			if(attr.exportCode){
				coder.packText(attr.exportCode(docType),0);
			}else{
				coder.packText(""+JSON.stringify(attr.val),0);
			}
		}
	}
};

//----------------------------------------------------------------------------
editDocExporter.genJSONArraySeg=function(jsonAry,exSeg){
	let i,n,pptVal;
	let coder=this.coder;
	n=jsonAry.length;
	coder.packText("[");coder.indentMore();coder.newLine();
	{
		for(i=0;i<n;i++){
			pptVal=jsonAry[i];
			if(Array.isArray(pptVal)){
				this.genJSONArraySeg(pptVal,exSeg);
			}else if(pptVal===null || pptVal===undefined){
				coder.packText(`null,`)
			}else if(pptVal instanceof Object){
				this.genJSONObjectSeg(pptVal,exSeg);
			}else{
				coder.packText(`${JSON.stringify(pptVal)},`)
			}
		}
	}
	coder.eatPreComa();
	coder.indentLess();coder.maybeNewLine();coder.packText("],")
	coder.newLine();
};

//----------------------------------------------------------------------------
editDocExporter.genJSONObjectSeg=function(jsonObj,exSeg,exSegObj){
	let pptKey,pptVal;
	let coder=this.coder;
	coder.packText("{");coder.indentMore();coder.newLine();
	{
		for(pptKey in jsonObj){
			coder.maybeNewLine();
			pptVal=jsonObj[pptKey];
			if(Array.isArray(pptVal)){
				coder.packText(`"${pptKey}":`);
				this.genJSONArraySeg(pptVal,false,null);
			}else if(pptVal===null || pptVal===undefined){
				coder.packText(`"${pptKey}":null,`)
			}else if(pptVal instanceof Object){
				coder.packText(`"${pptKey}":`);
				this.genJSONObjectSeg(pptVal,exSeg);
			}else{
				coder.packText(`"${pptKey}":${JSON.stringify(pptVal)},`)
			}
		}
	}
	if(exSeg && exSegObj){
		coder.beginDocObjTagBlcok(exSegObj,"Extra");
		coder.endDocObjTagBlcok(exSegObj,"Extra");
	}else{
		coder.eatPreComa();
	}
	coder.indentLess();coder.maybeNewLine();coder.packText("},")
	coder.newLine();
};

export {EditDocExporter,genAttrValText,genLocalizeValText,genLocalizeValTextPy};