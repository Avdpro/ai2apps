var CdyCoder,__Proto;

//---------------------------------------------------------------------------
//用来输出代码的对象，负责美化:
CdyCoder=function(){
	this.maxLineChars=150;
	this.lines=[];
	this.generatedCode="";
	this.curLine="";
	this.curIndent=0;
};

__Proto=CdyCoder.prototype={};

//---------------------------------------------------------------------------
//开始编写工程文件存盘信息:
__Proto.startPrjDoc=function(indent=0){
	this.lines=[];
	this.maxLineChars=65536;
	this.generatedCode="";
	this.curLine="";
	this.curIndent=indent;
	this.isNewLine=1;
};

//---------------------------------------------------------------------------
//生成文本:
__Proto.genDocText=function(preFix)
{
	if(!this.newLine){
		this.lines.push(this.curLine);
	}
	this.generatedCode=this.lines.join(preFix?("\n"+preFix):"\n");
	return preFix?(preFix+this.generatedCode):this.generatedCode;
};

//***************************************************************************
//代码合并操作
//***************************************************************************
{
	//-----------------------------------------------------------------------
	CdyCoder.getSegCode=function(code,mark){
		let mark1,mark2,pos1,pos2;
		mark1="##{"+mark+"#\n";
		mark2="##}"+mark+"#\n";
		pos1=code.indexOf(mark1);
		if(pos1>=0){
			pos2=code.indexOf(mark2,pos1);
			if(pos2>0){
				return code.substring(pos1+mark1.length,pos2);
			}
		}
		return "";
	};
	
	//-----------------------------------------------------------------------
	//找到旧代码里的标记对，合并到新代码里去:
	CdyCoder.mergeCode=function(oldCode,newCode,missList){
		var findPos,pos,pos2,pos3,mark,inMark,outMark;
		var codeSeg,indentPos,oldIndent,newIndent;
		findPos=0;
		do{
			pos=oldCode.indexOf("##{",findPos);
			if(pos>=0){
				findPos=pos+1;
				pos2=oldCode.indexOf("#\n",pos);
				if(pos2<0){
					throw "Can't find mark end.";
				}
				mark=oldCode.substring(pos+3,pos2);
				inMark="##{"+mark+"#\n";
				outMark="##}"+mark+"#\n";
				pos3=oldCode.indexOf(outMark,pos2);
				if(pos3<3){
					throw "Can't find seg end: "+mark+" in old code.";
				}
				codeSeg=oldCode.substring(pos+inMark.length,pos3);
				//找到起始缩进
				oldIndent=0;
				indentPos=pos-1;
				while(oldCode.charAt(indentPos)==='\t'){
					oldIndent++;
					indentPos--;
				}
				//找到新代码段里的对应代码段:
				pos=newCode.indexOf(inMark);
				if(pos>=0){
					pos2=newCode.indexOf(outMark,pos);
					if(pos2<0){
						throw "Can't find seg end: "+mark+" in new code.";
					}
					//找到起始缩进
					newIndent=0;
					indentPos=pos-1;
					while(newCode.charAt(indentPos)==='\t'){
						newIndent++;
						indentPos--;
					}
					if(oldIndent!==newIndent){
						let lines,delta,i,n,j;

						lines=codeSeg.split("\n");
						n=lines.length;

						//更新代码块的缩进
						delta=newIndent-oldIndent;
						if(delta>0){
							let txt="";
							for(i=0;i<delta;i++){
								txt+="\t";
							}
							for(i=0;i<n;i++){
								lines[i]=(txt)+lines[i];
							}
						}else{
							let txt="";
							delta=-delta;
							for(i=0;i<n;i++){
								txt=lines[i];
								for(j=0;j<delta;j++){
									if(txt.charAt(0)==='\t'){
										txt=txt.substring(1);
									}
								}
								lines[i]=txt;
							}
						}
						codeSeg=lines.join("\n");
					}
					newCode=newCode.substring(0,pos+inMark.length)+codeSeg+newCode.substring(pos2);
				}else{
					//TODO: Add missing seg to missList
				}
			}else{
				findPos=-1;
			}
		}while(findPos>=0);
		return newCode;
	};
}

//***************************************************************************
//基础操作
//***************************************************************************
{
	//-----------------------------------------------------------------------
	//添加文本:
	__Proto.packText=function(text,allowNewLine=0){
		if(allowNewLine && this.curLine.length>=this.maxLineChars){
			this.newLine();
		}
		this.curLine+=text;
		if(this.isNewLine && text.length){
			this.isNewLine=0;
		}
	};

	//---------------------------------------------------------------------------
	//新建一行
	__Proto.newLine = function () {
		let i,n;
		this.lines.push(this.curLine);
		this.curLine="";
		n=this.curIndent;
		for(i=0;i<n;i++){
			this.curLine+='\t';
		}
		this.isNewLine=1;
	};

	//---------------------------------------------------------------------------
	//如果当前不是新的一行，新建一行
	__Proto.maybeNewLine = function () {
		let i,n;
		if(this.isNewLine){
			return;
		}
		this.lines.push(this.curLine);
		this.curLine="";
		n=this.curIndent;
		for(i=0;i<n;i++){
			this.curLine+='\t';
		}
		this.isNewLine=1;
	};

	//---------------------------------------------------------------------------
	//如果当前不是新的缩进的一行，新建一行
	__Proto.maybeGapLine = function () {
		let i,n;
		if(this.isNewLine){
			let lastLine=this.lines[this.lines.length-1];
			for(i=0;lastLine[i]==="\t";i++){
			}
			if(this.curIndent>i){
				return;
			}
		}
		this.lines.push(this.curLine);
		this.curLine="";
		n=this.curIndent;
		for(i=0;i<n;i++){
			this.curLine+='\t';
		}
		this.isNewLine=1;
	};

	//---------------------------------------------------------------------------
	//缩进+
	__Proto.indentMore = function () {
		this.curIndent++;
		if(this.isNewLine){
			this.curLine=(this.curLine||"")+"\t";
		}
	};

	//---------------------------------------------------------------------------
	//缩进-
	__Proto.indentLess = function () {
		this.curIndent--;
		this.curIndent = this.curIndent < 0 ? 0 : this.curIndent;
		if(this.isNewLine){
			if(this.curLine.length){
				this.curLine=this.curLine.substring(0,this.curLine.length-1);
			}
		}
	};

	//-----------------------------------------------------------------------
	//向前消除一个逗号:
	__Proto.eatPreComa=function(){
		let line;
		if(this.isNewLine){
			line=this.lines.pop();
			line=line.trimRight();
			if(line.endsWith(",")){
				line = line.substring(0, line.length - 1);
			}
			this.lines.push(line);
		}else {
			this.curLine=this.curLine.trimRight();
			if (this.curLine.endsWith(",")) {
				this.curLine = this.curLine.substring(0, this.curLine.length - 1);
			}
		}
	};
	//-----------------------------------------------------------------------
	//向前消除一个Space:
	__Proto.eatPreSpace=function(){
		let line;
		if(this.isNewLine){
		}else {
			this.curLine=this.curLine.trimRight();
		}
	};
	
	//------------------------------------------------------------------------
	__Proto.packBreakLine=function(ch="-"){
		let indent=this.curIndent;
		let i,len=78-indent*4-2;
		let text="";
		this.maybeNewLine();
		for(i=0;i<len;i++){
			text+=ch;
		}
		this.packText("##"+text);
		this.newLine();
	};

	//------------------------------------------------------------------------
	__Proto.packComment=function(text){
		let lines,i,n;
		this.maybeNewLine();
		lines=text.split("\n");
		n=lines.length;
		for(i=0;i<n;i++){
			this.packText("#"+lines[i].trimRight());
			this.newLine();
		}
	};
}

//***************************************************************************
//DocObj相关操作
//***************************************************************************
{
	//---------------------------------------------------------------------------
	//开始DocObj的扩展块:
	__Proto.beginDocObjTagBlcok=function(obj,tag){
		var mark;
		if (!this.isNewLine) {
			this.newLine();
		}
		mark = "##{" + (obj?obj.jaxId:"") + tag+"#";
		this.packText(mark);
		this.newLine();
	};

	//---------------------------------------------------------------------------
	//结束DocObj的扩展块:
	__Proto.endDocObjTagBlcok=function(obj,tag,indentLess){
		var mark;
		this.maybeNewLine();
		mark = "##}" + (obj?obj.jaxId:"") + tag + "#";
		this.packText(mark);
		if(indentLess){
			this.indentLess();
		}
		this.newLine();
	};

}
//***************************************************************************
//输出Obj代码相关操作
//***************************************************************************
{
	//-----------------------------------------------------------------------
	//TODO: 输出一个对象
	__Proto.packObj=function(val){
		var bigObj;
		bigObj=this.checkBigObj(val);
		if(bigObj===1){
			this.packText("{");
			this.indentMore();
			this.newLine();
			{
				this.packObjAttrs(val);
			}
			this.eatPreComa();
			this.maybeNewLine();
			this.indentLess();
			this.packText("},");
			this.newLine();
		}else{
			this.packText(bigObj+",");
		}
	};

	//-----------------------------------------------------------------------
	//TODO: 查看一个对象是不是大型/复杂对象:
	__Proto.checkBigObj=function(obj){
		var len,jsonText;
		jsonText=JSON.stringify(obj);
		len=this.curLine.length+jsonText.length;
		if(len>this.maxLineChars*0.5){
			return 1;
		}
		return jsonText;
	};

	//-----------------------------------------------------------------------
	//TODO: 输出一个对象的全部属性
	__Proto.packObjAttrs=function(obj){
		var k,key,val,bigObj;
		for(k in obj){
			key=k;
			val=obj[key];
			//console.log("Will pack attr: "+key);
			if(Array.isArray(val)){
				bigObj=this.checkBigObj(val);
				if(bigObj===1){
					if(!this.isNewLine) {
						this.newLine();
						bigObj=this.checkBigObj(val);
					}
					if(bigObj===1) {
						this.packObjAttrName(key);
						this.packText("[");
						this.indentMore();
						this.newLine();
						{
							this.packArrayItems(val);
						}
						this.eatPreComa();
						this.maybeNewLine();
						this.indentLess();
						this.packText("], ");

						this.newLine();
					}else{
						this.packObjAttrName(key);
						this.packText(bigObj+", ");
					}
				}else{
					this.packObjAttrName(key);
					this.packText(bigObj+", ");
				}
			}else if(typeof(val)==="object"){
				bigObj=this.checkBigObj(val);
				if(bigObj===1){
					//console.log("Found big obj: "+key);
					if(!this.isNewLine) {
						this.newLine();
						bigObj=this.checkBigObj(val);
					}
					if(bigObj===1) {
						//console.log("Still big: "+key);
						this.packObjAttrName(key);
						this.packText("{");
						this.indentMore();
						this.newLine();
						{
							this.packObjAttrs(val);
						}
						this.eatPreComa();
						this.indentLess();
						if(!this.isNewLine) {
							this.newLine();
						}
						this.packText("}, ");

						this.newLine();
					}else{
						//console.log("Not big: "+key);
						this.packObjAttrName(key);
						this.packText(bigObj+", ");
					}
				}else{
					this.packObjAttrName(key);
					this.packText(bigObj+", ");
				}
			}else {
				this.packObjAttrName(key);
				this.packObjAttrValue(val);
			}
		}
		this.eatPreComa();
	};

	//-----------------------------------------------------------------------
	//TODO: 输出一个数组的全部元素
	__Proto.packArrayItems=function(obj){
		var i,n,key,val,bigObj;
		n=obj.length;
		for(i=0;i<n;i++){
			key=i;
			val=obj[key];
			if(Array.isArray(val)){
				bigObj=this.checkBigObj(val);
				if(bigObj===1){
					this.maybeNewLine();
					this.packText("[");
					this.indentMore();
					this.newLine();
					{
						this.packArrayItems(val);
					}
					this.eatPreComa();
					this.newLine();
					this.indentLess();
					this.packText("],");

					this.newLine();
				}else{
					this.packText(bigObj+",");
				}
			}else if(typeof(val)==="object"){
				bigObj=this.checkBigObj(val);
				if(bigObj===1){
					this.maybeNewLine();
					this.packText("{");
					this.indentMore();
					this.newLine();
					{
						this.packObjAttrs(val);
					}
					this.eatPreComa();
					this.newLine();
					this.indentLess();
					this.packText("},");

					this.newLine();
				}else{
					this.packText(bigObj+",");
				}
			}else {
				//this.packObjAttrName(key);
				this.packObjAttrValue(val);
			}
		}
		this.eatPreComa();
	};
}
export default CdyCoder;
export {CdyCoder};
