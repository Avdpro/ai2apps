import {DlgChooseSeg} from "./ui/DlgChooseSeg.js";

export default DlgChooseSeg;
export {DlgChooseSeg};