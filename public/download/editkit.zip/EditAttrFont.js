import inherits from "/@inherits";
import {EditAttr} from "./EditAttr.js";
import {EditObj} from "./EditObj.js";
var EditAttrFont,editAttrFont;
var fontDef={
	name:"Font",icon:"font.svg",
	attrs:{
		url:{name:"url",showName:"Font URL",type:"file",initVal:"",key:1,fixed:1},
		previewSize:{name:"previewSize",showName:"Preview size",type:"int",initVal:16,key:1,fixed:1,editType:"fontView"},
	}
};
var sysFonts=["Arial","Arial Black","Courier New","Georgia","Impact","Microsoft Sans Serif","Times New Roman","Verdana"];
var codyFonts=[];
var willBuildFonts=0;
//****************************************************************************
//Font attr:
//****************************************************************************
EditAttrFont=function(owner,def,init){
	let self=this;
	EditObj.call(this,owner,def,true);
	this.fontURL=this.getAttr("url");
	this.previewSize=this.getAttr("previewSize");
	this.webFontFace=null;
	let applyFont=()=>{
		let name,url,fonts;
		if(self.webFontFace){
			document.fonts.delete(self.webFontFace);
			self.webFontFace=null;
		}
		name=self.name;
		url=self.fontURL.val;
		if(url.startsWith("//")){
			url=document.location.origin+url;
		}
		if(name && url){
			self.webFontFace=new FontFace(name,`url(${url})`);
			self.webFontFace.load().then(loadedFont=>{
				document.fonts.add(loadedFont);
				self.previewSize.emitAttrChange();
			});
		}
		if(!willBuildFonts){
			willBuildFonts=1;
			window.setTimeout(()=>{
				let name;
				self.doc.emitObjChange();
				codyFonts.splice(0);
				fonts=self.owner.attrHash;
				for(name in fonts){
					codyFonts.push(name);
				}
				codyFonts.push(...sysFonts);
				willBuildFonts=0;
			},0);
		}
	};
	//TODO: Add notify:
	this.onChange(applyFont);
	this.fontURL.onChange(applyFont);
};
inherits(EditAttrFont,EditObj);
EditAttr.regAttrType("font",EditAttrFont);
var fontDefs={};
EditAttrFont.regDef=function(name,def){
	fontDefs[name]=def;
};
EditAttrFont.getDef=function(name){
	return fontDefs[name];
};
EditAttrFont.getDefList=function(){
	return Object.values(fontDefs);
};

editAttrFont=EditAttrFont.prototype;

EditObj.regObjectDef("Fonts",{
	name:"Fonts",icon:"fonts.svg",attrs:{},attrType:"font",attrTypeDef:"Font",allowExtraAttr:1
});
EditAttrFont.regDef("Font",fontDef);

export {EditAttrFont,codyFonts,sysFonts};

