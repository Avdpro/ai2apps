import {VFACT} from "/@vfact";
import inherits from "/@inherits";
import {EditAttr} from "./EditAttr.js";
import {EditObj,EditAttrList,EditObjProxy} from "./EditObj.js";
import {} from "./EditFunction.js";//Make sure the EditFunction is loaded.
import {ExportObjDef} from "./exporters/ExportObjDef.js";
const $ln=VFACT.lanCode;

let EditClassObj;
//----------------------------------------------------------------------------
//Template for class obj-def:
var DefClassObj={
	name:"ClassObj",//Replace this in class
	objClass:null,//Replace this in class
	allowExtraAttr:0,
	icon:"object.svg",navi:"doc",
	attrs:{
		"initCode":{name:"initCode",showName:"Init Code",type:"string",initVal:"null",key:1,fixed:1},
		"mockup":{
			name:"mockup",showName:"Mockup",type:"mockup",key:1,fixed:1
		}
	}
};

//****************************************************************************
//:EditClassProperty
//****************************************************************************
let EditClassPpt,editClassPpt;
let EditClassStdPptDef,EditClassObjPptDef,EditClassAryPptDef,EditClassAryElmtDef;
{
	//------------------------------------------------------------------------
	const EditClassShellAttr={
		"label":{
			name:"label",showName:(($ln==="CN")?("展示名称"):/*EN*/("Label")),type:"string",key:0,fixed:1,initValText:"New Property",localizable:true,
		},
		"icon":{
			name:"icon",showName:(($ln==="CN")?("图标URL"):/*EN*/("Icon URL")),type:"file",key:0,fixed:1,initValText:"",isURL:true,
		},
		"readOnly":{
			name:"readOnly",showName:(($ln==="CN")?("只读"):/*EN*/("Read Only")),type:"bool",key:0,fixed:1,initVal:false,
		},
		"required":{
			name:"required",showName:(($ln==="CN")?("不能为空"):/*EN*/("Reauired")),type:"bool",key:0,fixed:1,initVal:true,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:0,fixed:1,initVal:(($ln==="CN")?("这是一个AISeg。"):/*EN*/("This is an AISeg.")),localizable:true,
		}
	};
	
	//------------------------------------------------------------------------
	EditClassStdPptDef={
		name:"EditClassStdPpt",showName:(($ln==="CN")?("基础属性"):/*EN*/("Basic Property")),icon:"var_auto.svg",
		attrs:{
			...EditClassShellAttr,
			"type":{
				name:"type",showName:(($ln==="CN")?("类型"):/*EN*/("Type")),type:"choice",key:0,fixed:1,initVal:"auto",
				vals:[
					["auto","Auto","Auto"],
					["int","Integer","Integer"],
					["number","Number","Number"],
					["string","String","String"],
					["bool","Boolean","Boolean"],
				],
			},
			"defaultValue":{
				name:"defaultValue",showName:(($ln==="CN")?("默认值"):/*EN*/("Default Value")),type:"auto",key:0,fixed:1,
			},
			"uiMode":{
				name:"uiMode",showName:(($ln==="CN")?("展示模式"):/*EN*/("UI Mode")),type:"string",key:0,fixed:1,initVal:"",
			},
			"choices":{
				name:"choices",showName:(($ln==="CN")?("值选项"):/*EN*/("Value Choices")),type:"array",key:0,fixed:1,
			},
			"inputType":{
				name:"inputType",showName:(($ln==="CN")?("输入模式"):/*EN*/("Input Type")),type:"choice",key:0,fixed:1,
				vals:[
					["","Normal","Normal"],
					["password","Password","Password"],
					["date","Date","Date"],
					["time","Time","Time"],
					["month","Month","Month with year"],
				],
			},
			"inputPattern":{
				name:"inputPattern",showName:(($ln==="CN")?("输入格式"):/*EN*/("Input Pattern")),type:"string",key:0,fixed:1,initVal:"",
			},
			"shortEdit":{
				name:"shortEdit",showName:(($ln==="CN")?("短输入"):/*EN*/("Short Edit")),type:"bool",key:0,fixed:1,initVal:false,
			},
			"ranged":{
				name:"ranged",showName:(($ln==="CN")?("取值区间"):/*EN*/("Value Range")),type:"bool",key:0,fixed:1,initVal:false,
			},
			"rangeMin":{
				name:"rangeMin",showName:(($ln==="CN")?("最小值"):/*EN*/("Min. Value")),type:"auto",key:0,fixed:1,initVal:undefined,
			},
			"rangeMax":{
				name:"rangeMax",showName:(($ln==="CN")?("最大值"):/*EN*/("Min. Value")),type:"auto",key:0,fixed:1,initVal:undefined,
			},
			"placeHolder":{
				name:"placeHolder",showName:(($ln==="CN")?("占位提示"):/*EN*/("Place Holder")),type:"string",key:0,fixed:1,initVal:"",
			},
		},
		listHint:[
			"type","label","icon","defaultValue",
			{
				name:"advanced",showName:(($ln==="CN")?("高级"):("Advanced")),
				attrs:["readOnly","required","placeHolder","inputType","inputPattern","shortEdit","uiMode","choices","ranged","rangeMin","rangeMax",]
			},
			"desc",
		],
		objAttrs:{
			isClassProperty:true,
			genAttrDef:function(name,showName,key=true,fixed=false){
				let vo,uiMode;
				vo={
					name:name||this.name,
					showName:name||this.name,
					type:this.getAttrVal("type"),
					key:key,fixed:fixed,
					initVal:this.getAttrVal("defaultValue")
				};
				uiMode=this.getAttrVal("uiMode");
				if(uiMode){
					vo.editType=uiMode;
				}
				return vo;
			},
		},
	};
	EditObj.regDef("EditClassStdPpt",EditClassStdPptDef);
	
	//------------------------------------------------------------------------
	EditClassObjPptDef={
		name:"EditClassObjPpt",showName:(($ln==="CN")?("对象属性"):/*EN*/("Object Property")),icon:"object.svg",
		attrs:{
			...EditClassShellAttr,
			"type":{name:"type",type:"string",key:1,fixex:1,initVal:"object",edit:false},
			"class":{
				name:"class",showName:(($ln==="CN")?("类型"):/*EN*/("Class")),type:"choice",key:1,fixed:1,initVal:"",rawEdit:false,
				vals:[[null,"null","null"]],
				val2ShowText(val){
					let tmp;
					if(val===null){
						return null;
					}
					tmp=VFACT.getEditUITemplate(val);
					if(tmp){
						return tmp.label||tmp.name;
					}
					return val;
				},
				getMenuItems:function(attrObj){
					let items=[{text:"null",valText:"null"}];
					let tmps=VFACT.getEditUITemplates();
					for(let tmpName in tmps){
						let tmp=tmps[tmpName];
						if(tmp instanceof Function){
							tmp=tmp();
						}
						if(tmp){
							items.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
						}
					}
					return items;
				}
			},
			"required":{
				name:"required",showName:(($ln==="CN")?("不能为空"):/*EN*/("Reauired")),type:"bool",key:0,fixed:1,initVal:true,
			},
		},
		listHint:[
			"class","required","label","icon","desc",
		],
		objAttrs:{
			defEditObj:null,
			isClassProperty:true,
			val2ShowText:function(val){
				let def;
				def=VFACT.getUITemplate(val);
				if(def){
					return def.name;
				}
				return "Undefined";
			},
			genAttrDef:function(name,showName,key=true,fixed=true){
				let vo,defName,attrs,ppts;
				vo={
					name:name||this.name,
					showName:name||this.name,
					type:"mockup",className:"ObjClass"+this.getAttrVal("class"),
					key:key,fixed:fixed,
				};
				defName=this.getAttrVal("def");
				if(defName){
					vo.def=defName;
				}else{
					//ppts=this.get
				}
				return vo;
			},
		},
	};
	EditObj.regDef("EditClassObjPpt",EditClassObjPptDef);

	//------------------------------------------------------------------------
	EditClassAryElmtDef={
		name:"EditClassAryElmt",showName:(($ln==="CN")?("元素模版"):/*EN*/("Element Template")),icon:"ghost.svg",
		attrs:{
			"type":{
				name:"type",showName:(($ln==="CN")?("类型"):/*EN*/("Type")),type:"choice",key:1,fixed:1,initVal:"auto",
				vals:[
					["auto","Auto","Auto"],
					["int","Integer","Integer"],
					["number","Number","Number"],
					["string","String","String"],
					["bool","Boolean","Boolean"],
					["object","Object","Object"],
				]
			},
			"label":{
				name:"label",showName:(($ln==="CN")?("标签模版"):/*EN*/("Label Patten")),type:"string",key:1,fixed:1,initVal:"#'###:'",localizable:true,
			},
			"defaultValue":{
				name:"defaultValue",showName:(($ln==="CN")?("默认值"):/*EN*/("Default Value")),type:"auto",key:0,fixed:1,
			},
			"uiMode":{name:"uiMode",showName:(($ln==="CN")?("展示模式"):/*EN*/("UI Mode")),type:"string",key:0,fixex:1,initVal:undefined},
			"class":{
				name:"class",showName:(($ln==="CN")?("元素对象类型"):/*EN*/("Element Class")),type:"choice",key:0,fixed:1,initVal:null,
				vals:[[null,"null","null"]],
				val2ShowText(val){
					let tmp;
					if(val===null){
						return null;
					}
					tmp=VFACT.getEditUITemplate(val);
					if(tmp){
						return tmp.label||tmp.name;
					}
					return val;
				},
				getMenuItems:function(attrObj){
					let items=[{text:"null",valText:"null"}];
					let tmps=VFACT.getEditUITemplates();
					for(let tmpName in tmps){
						let tmp=tmps[tmpName];
						if(tmp instanceof Function){
							tmp=tmp();
						}
						if(tmp){
							items.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
						}
					}
					return items;
				}
			},
			"choices":{
				name:"choices",showName:(($ln==="CN")?("值选项"):/*EN*/("Choices")),type:"array",key:0,fixed:1,
			},
		},
		listHint:[
			"type","label","defaultValue","uiMode","class","choices"
		],
		objAttrs:{
			defEditObj:null,isClassProperty:true,
		},
	};
	EditObj.regDef("EditClassAryElmt",EditClassAryElmtDef);
	
	//------------------------------------------------------------------------
	EditClassAryPptDef={
		name:"EditClassAryPpt",showName:(($ln==="CN")?("数组属性"):/*EN*/("Array Property")),icon:"array.svg",
		attrs:{
			...EditClassShellAttr,
			"type":{name:"type",type:"string",key:1,fixex:1,initVal:"array",edit:false},
			"element":{
				name:"element",showName:(($ln==="CN")?("元素模版"):/*EN*/("Element Template")),type:"object",key:1,fixed:1,
				def:"EditClassAryElmt",
			},
			"initLength":{
				name:"initLength",showName:(($ln==="CN")?("初始长度"):/*EN*/("Init Length")),type:"int",key:1,fixed:1,initVal:0
			},
			"required":{
				name:"required",showName:(($ln==="CN")?("不能为空"):/*EN*/("Reauired")),type:"bool",key:0,fixed:1,initVal:true,
			},
			"uiMode":{name:"uiMode",showName:(($ln==="CN")?("展示模式"):/*EN*/("UI Mode")),type:"string",key:0,fixex:1,initVal:""},
			"orderFixed":{name:"orderFixed",showName:(($ln==="CN")?("固定顺序"):/*EN*/("Fixed order")),type:"bool",key:0,fixex:1,initVal:false},
		},
		listHint:[
			"label","element","required","initLength","icon","uiMode","orderFixed","desc",
		],
		objAttrs:{
			isClassProperty:true,
			//This is for mockup
			genAttrDef:function(name,showName,key=true,fixed=true){
				let vo,defName,attrs,ppts,elmtAttr,elmtType,uiMode;
				vo={
					name:name||this.name,
					showName:name||this.name,
					type:"array",
					key:key,fixed:fixed,
					def:"Array"
				};
				uiMode=this.getAttrVal("uiMode");
				elmtAttr=this.getAttr("element");
				elmtType=elmtAttr.getAttrVal("type");
				//Add elementType:
				if(elmtType==="object"){
					let className;
					className=elmtAttr.getAttrVal("class");
					vo.elementDef={type:"mockup",extraAttr:1,className:"ObjClass"+className};
				}else{
					vo.elementDef={type:elmtType,initVal:elmtAttr.getAttrVal("defaultValue"),extraAttr:1};
				}
				return vo;
			},
		},
	};
	EditObj.regDef("EditClassAryPpt",EditClassAryPptDef);
}

//****************************************************************************
//:EditClass
//****************************************************************************
let EditClass,editClass;
{
	let defArgs={icon:"args.svg",allowExtraAttr:1,attrs:{}};
	let DefObjClass={
		name:"ObjClass",
		allowExtraAttr:0,
		naviAllowAdd:true,
		icon:"class.svg",
		navi:"doc",
		attrs:{
			"exportType":{
				name:"exportType",showName:(($ln==="CN")?("代码"):/*EN*/("Code")),type:"choice",key:1,fixed:1,initVal:"UIDataTemplate",rawEdit:false,
				vals:[
					["DataClass","Data Class","Data Class"],
					["UIDataTemplate","UI Data Template","UI Data Template"],
					["JSClass","Javascript Class","Javascript Class"],
				],
			},
			"label":{
				name:"label",showName:(($ln==="CN")?("展示名称"):/*EN*/("Label")),type:"string",key:0,fixed:1,localizable:true,
			},
			"desc":{
				name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:0,fixed:1,initVal:"This is a meta-data",localizable:true,
			},
			"constructArgs":{
				name:"constructArgs",showName:"Arguments",type:"object",icon:"args.svg",key:1,fixed:1,
				def:defArgs
			},
			"superClass":{name:"superClass",showName:"SuperClass",type:"string",initVal:"",key:1,fixed:1},
			"superArgs":{
				name:"superArgs",showName:"Super Arguments",type:"object",def:defArgs,key:0,fixed:1
			},
			"properties":{
				name:"properties",showName:"Properties",type:"object",def:"Object",key:1,fixed:1,watchTree:true,newAttrMode:"ClassPpt"
			},
			"layout":{
				name:"layout",showName:"Layout",type:"array",def:"AutoArray",key:0,fixed:1,watchTree:true
			},
			"functions":{name:"functions",showName:"Functions",type:"object",def:"Functions",key:1,fixed:1},
			"mockups":{
				name:"mockups",type:"object",def:"Object",key:1,fixed:1,save:false,export:false,navi:"doc",edit:false,
				objAttrs:{
					getEditRootPpts:function(){
						return [{obj:this,open:1}];
					}
				}
			},
			"exportMode":{name:"mockupOnly",showName:"Mockups Only",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
			"mockupOnly":{name:"mockupOnly",showName:"Mockups Only",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
			"nullMockup":{name:"nullMockup",showName:"Allow Null Mockup",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
			"exportClass":{name:"exportClass",showName:"Export Class",type:"bool",initVal:false,key:1,fixed:1,rawEdit:false},
		},
		listHint:[
			"exportType","label",
			{name:"Construct",showName:"Construct",attrs:["constructArgs","superClass","superArgs"],open:0},
			"properties",
			"functions",
			"layout",
			"mockupOnly",
			"desc",
			"exportClass"
		]
	};

	//------------------------------------------------------------------------
	EditClass=function(owner,def,init){
		let self,objDef,baseDef,objFunDefs,defFunctions;
		
		EditObj.call(this,owner,def,false);
		self=this;
		this.codeName=null;
		this.isEditClass=true;
		objDef=this.objDef;
		objFunDefs=objDef.functions?{...objDef.functions}:{};
		{
			baseDef=objDef.baseDef;
			if(baseDef){
				baseDef=EditObj.getObjectDef(baseDef);
				if(!baseDef){
					console.error(`Object base-def: ${baseDef.baseDef} not found.`);
					throw new Error(`Object base-def: ${baseDef.baseDef} not found.`);
				}
				if(baseDef.functions){
					objFunDefs={...baseDef.functions,...objFunDefs};
				}
			}
		}
		defFunctions=def.functions;
		if(defFunctions){
			Object.assign(objFunDefs,defFunctions);
		}
		this.funcs=new EditAttrList(this,objFunDefs,"Func");
		if(init){
			this.attrs.ensureKeys();
			this.funcs.ensureKeys();
		}
		let selfProxy;
		Object.defineProperty(this,'selfProxy',{
			get:function(){
				if(!selfProxy){
					selfProxy=new Proxy(new EditObjProxy(this),{
						get:function(tgt,key){
							var attr;
							if(key==="%EditObj"){
								return self;
							}
							if(key===Symbol.toPrimitive){
								return ()=>"{EditObjAttr}";
							}
							attr=self.attrs.getAttr(key);
							if(attr){
								if(attr.selfProxy) {
									return attr.selfProxy;
								}else if(attr instanceof EditAttr){
									return attr.val;
								}
							}
							attr=self.funcs.getAttr(key);
							if(attr){
								if(attr.funcProxy) {
									return attr.funcProxy;
								}else if(attr instanceof EditAttr){
									return attr.val;
								}
							}
							if(attr===undefined){
								console.log("Can't find attr: ",key);
							}
							return undefined;
						},
						set:function(tgt,key,val){
							throw new Error(`Can not set attrib "${key}" on EditObjProxy.`);
						}
					});
				}
				return selfProxy;
			},
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(this,'funcList',{
			get:function(){
				return this.funcs.attrList;
			},
			enumerable: true
		});
		Object.defineProperty(this,'funcHash',{
			get:function(){
				return this.funcs.attrHash;
			},
			enumerable: true
		});
		
		this.classObjDef=null;
		this.mockupObjs=null
		if(init){
			this.objReady();
		}else{
			this.mockupObjs=null
		}
		self.onNotify("Change",()=>{this.regThisClass();});
		self.on("LeaveUIEdit",()=>{self.updateMockups();});
		if(self.doc){
			self.doc.on("AboutSaveDoc",()=>{self.updateMockups();});
		}
	};
	inherits(EditClass,EditObj);
	EditAttr.regAttrType("objclass",EditClass);
	editClass=EditClass.prototype;
	let classDefRegs={};

	//------------------------------------------------------------------------
	EditClass.regDef=EditClass.regClassDef=function(name,def){
		classDefRegs[name]=def;
	};

	//------------------------------------------------------------------------
	EditClass.getDef=EditObj.getClassDef=function(name){
		return classDefRegs[name];
	};
	
	EditClass.regDef("ObjClass",DefObjClass);//The only def?
	
	//------------------------------------------------------------------------
	editClass.objReady=function(step){
		let self=this;
		if(this.isReady)
			return;
		this.properties=this.getAttr("properties");
		this.initScope();
		this.genClassDefs();
		if(this.getAttrVal("exportClass")===true){
		}
		this.regThisClass();
		//Trace property changes:
		this.properties.on("Changed",()=>{
			//TODO: Update mockup-obj-def
			self.updateMockups();
		});
		
		this.mockupObjs=this.getAttr("mockups");
		
		//Replace mockupObjs' def:
		this.mockupObjs.objDef={...this.mockupObjs.objDef};
		//Make sure mockupObjs' element type:
		this.mockupObjs.objDef.attrType="object";
		this.mockupObjs.objDef.attrTypeDef=this.mockupDef.def;
		
		if(this.objDef.OnCreate){
			this.objDef.OnCreate.call(this);
		}
		this.isReady=true;
	};

	//************************************************************************
	//Mockup obj access:
	//************************************************************************
	{
		//------------------------------------------------------------------------
		editClass.regThisClass=function(){
			this.codeName="ObjClass"+this.jaxId;
			EditAttr.regClass(this.codeName,this);
			EditClassObj.regDef(this.objClassDef.name,this.objClassDef);
			VFACT.regEditUITemplate(this.jaxId,()=>{
				let vo,ppts,list,attr,count,layout;
				count=0;
				function packAttrObj(pptAttrObj){
					let objVO,attrList,attr,attrName;
					objVO={
						name:pptAttrObj.name,
					};
					if(pptAttrObj.getAttrVal("type")==="array"){
						let elmtAttr,elmtT,uiMode,reqAttr;
						elmtAttr=pptAttrObj.getAttr("element");
						objVO.type="array";
						reqAttr=pptAttrObj.getAttr("required");
						if(reqAttr){
							objVO.required=pptAttrObj.getAttrVal("required");
						}
						objVO.element=elmtT=packAttrObj(elmtAttr);
						objVO.desc=pptAttrObj.getAttrVal("desc");
						uiMode=pptAttrObj.getAttrVal("uiMode");
						if(uiMode){
							objVO.uiMode=uiMode;
						}
						delete elmtT.name;
					}else{
						attrList=pptAttrObj.attrList;
						for(attr of attrList){
							attrName=attr.name;
							objVO[attrName]=attr.getJSObj?attr.getJSObj():attr.val;
						}
					}
					return objVO;
				}
				ppts={};
				vo={
					name:this.jaxId,
					label:this.name,
					type:"object",
					desc:this.getAttrVal("desc")||"",
					properties:ppts
				};
				list=this.properties.attrList;
				for(attr of list){
					if(attr.def.type==="object" && attr.objDef){
						ppts[attr.name]=packAttrObj(attr);
						count++;
					}
				}
				layout=this.getAttr("layout");
				if(layout){
					vo.layout=layout.getJSObj();
				}
				if(count>0){
					return vo;
				}
				return null;
			});
		};

		//------------------------------------------------------------------------
		editClass.genClassDefs=function(){
			let def,pptAttr;
			//Mockup def:
			pptAttr=this.properties;
			def=this.mockupDef=pptAttr.genAttrDef("mockup","mockup","ghost.svg");
			def.classAttr=this;

			//Class obj def:
			def={...DefClassObj};
			def.attrs={...DefClassObj.attrs};
			def.objClass=this;
			def.attrs.mockup={...def.attrs.mockup,className:"ObjClass"+this.jaxId};
			def.name="ClassObj"+this.jaxId;
			def.doc=this.doc;
			def.showName=(attr)=>{
				return this.name;
			}
			this.objClassDef=def;
		};

		//------------------------------------------------------------------------
		//Update all mockup obj
		editClass.updateMockups=function(){
			this.properties.updateGenedAttrDef(this.mockupDef);
			//Update all mockups:
			{
				let mkList,mkObj;
				mkList=this.getAttr("mockups").attrList;
				for(mkObj of mkList){
					mkObj.syncWithDef(true,true,true);
				}
			}
		};
	}

	//************************************************************************
	//I/O related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editClass.initScope=function(){
			let callArgs,ppts;
			this.scopeObj={};
			this.setScopeObj("appCfg",this.prj.objConfig,false);
			callArgs=this.getAttr("constructArgs");
			this.setScopeObj("callArgs",callArgs,true);
			ppts=this.getAttr("properties");
			callArgs.on("ObjChanged",()=>{
				this.scopeObjVsn++;
				ppts.updateHyperAttrs();
			});
		};

		//--------------------------------------------------------------------
		editClass.loadFromVO=function(vo){
			let voAttrs,objMockups,voMockups,mkDef;
			this.muteNotify();
			this.applyJaxId(vo.jaxId||null);
			this.editVersion=vo.editVersion||0;
			voAttrs=vo.attrs;
			this.attrs.loadFromVO(voAttrs);
			this.objReady();
			objMockups=this.mockupObjs;
			voMockups=vo.mockups;
			if(voMockups){
				mkDef={type:"object",def:this.mockupDef.def};
				for(let name in voMockups){
					let mkVO=voMockups[name];
					let attr=objMockups.addAttr({...mkDef,name:name,showName:name,extraAttr:1});
					attr.loadFromVO(mkVO);
				}
			}
			this.unmuteNotify();
		};

		//--------------------------------------------------------------------
		editClass.genSaveVO=function(){
			let attrList,mkList,mkObj,voMockups;
			let vo={};

			{
				let exportType,orgDef;
				exportType=true;
				if(!this.def.extraAttr && this.owner){
					orgDef=this.owner.getAttrDef(this.name);
					if(orgDef && orgDef.key && this.def.type===orgDef.type){
						exportType=false;
					}
				}
				if(exportType){
					vo.type=this.def.type||"object";
					vo.def=this.objDef.name;
				}
			}
			//vo.type=this.def.type;
			//vo.def=this.objDef.name;
			vo.jaxId=this.jaxId;
			//vo.editVersion=this.editVersion;
			attrList=this.attrs;
			vo.attrs=attrList.genSaveVO();
			voMockups=vo.mockups={};
			//Save mockup objs:
			mkList=this.mockupObjs.attrList;
			for(mkObj of mkList){
				voMockups[mkObj.name]=mkObj.genSaveVO();
			}
			return vo;
		};
		
		//--------------------------------------------------------------------
		editClass.genBriefSaveVO=function(){
			let saveVO,attrList,attrs,voMockups,mkList,mkObj;
			attrList=this.attrs;
			saveVO={};
			saveVO.type=this.def.type;
			saveVO.def=this.objDef.name;
			saveVO.jaxId=this.jaxId;
			saveVO.attrs=attrs={};//attrList.genSaveVO();
			attrs.properties=this.properties.genSaveVO();
			delete attrs.properties["editVersion"];
			attrs.mockupOnly="true";
			//Save mockup objs:
			voMockups=saveVO.mockups={};
			mkList=this.mockupObjs.attrList;
			for(mkObj of mkList){
				voMockups[mkObj.name]=mkObj.genSaveVO();
			}
			return saveVO;
		};
	}
	
	//************************************************************************
	//Apply mockup:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editClass.applyMockTemplate=function(tmptObj){
			let ppts,pptName,pptTmpt,pptType,pptDef,pptAttr;
			ppts=tmptObj.properties;
			if(!ppts){
				return;
			}
			for(pptName in ppts){
				pptTmpt=ppts[pptName];
				//Check if ppt is alreay inited?
				if(this.properties.getAttr(pptName)){
					continue;//Skip this property.
				}
				pptType=pptTmpt.type;
				switch(pptType){
					case "auto":
					case "int":
					case "number":
					case "string":
					case "bool":
						pptDef={name:pptName,type:"object",def:"EditClassStdPpt",extraAttr:1,initAttrs:{"type":pptType}};
						pptAttr=this.properties.addAttr(pptDef);
						if(pptAttr){
							let choices,chDef;
							if(pptTmpt.required){
								pptAttr.setAttrByText("required","true",true);
							}
							if(pptTmpt.label){
								pptAttr.setAttrByText("label",pptTmpt.label,true);
							}
							if(pptTmpt.desc){
								pptAttr.setAttrByText("desc",pptTmpt.desc,true);
							}
							if(pptTmpt.inputType){
								pptAttr.setAttrByText("inputType",pptTmpt.inputType,true);
							}
							choices=pptTmpt.choices;
							if(Array.isArray(choices) && choices.length){
								chDef=pptAttr.getAttrDef("choices");
								if(chDef){
									let chAryObj=pptAttr.addAttr(chDef);
									let chAttr;
									for(let text of choices){
										chAttr=chAryObj.addAttr();
										chAttr.setValByText(text);
									}
								}
							}
						}
						break;
					case "object":
						pptDef={name:pptName,type:"object",def:"EditClassObjPpt",extraAttr:1};
						pptAttr=this.properties.addAttr(pptDef);
						if(pptAttr){
							if(pptTmpt.required){
								pptAttr.setAttrByText("required","true",true);
							}
							if(pptTmpt.label){
								pptAttr.setAttrByText("label",pptTmpt.label,true);
							}
							if(pptTmpt.desc){
								pptAttr.setAttrByText("desc",pptTmpt.desc,true);
							}
						}
						break;
					case "array":
						pptDef={name:pptName,type:"object",def:"EditClassAryPpt",extraAttr:1};
						pptAttr=this.properties.addAttr(pptDef);
						if(pptAttr){
							if(pptTmpt.required){
								pptAttr.setAttrByText("required","true",true);
							}
							if(pptTmpt.label){
								pptAttr.setAttrByText("label",pptTmpt.label,true);
							}
							if(pptTmpt.desc){
								pptAttr.setAttrByText("desc",pptTmpt.desc,true);
							}
						}
						break;
				}
			}
		};
	}
}

//****************************************************************************
//:EditClassObj
//****************************************************************************
let editClassObj;
{
	//------------------------------------------------------------------------
	EditClassObj=function(owner,def,init){
		let objClass;
		EditObj.call(this,owner,def,false);
		objClass=this.objDef.objClass;
		this.objClass=objClass;
		if(objClass){
			if(objClass.doc!==this.doc){
				//TODO: name maybe change:
				this.doc.addImportObj(objClass.name,objClass.doc.path);
			}
		}
		this.updateHyperAttrs();
		this.attrs.ensureKeys();
		this.initCode=this.getAttr("initCode");
		this.mockup=this.getAttr("mockup");
		this.on("ObjChanged",()=>{
			this.owner.emitObjChange();
		});
	};
	inherits(EditClassObj,EditObj);
	EditAttr.regAttrType("classobj",EditClassObj);
	editClassObj=EditClassObj.prototype;
	let classObjDefRegs={};
	
	//------------------------------------------------------------------------
	EditClassObj.regDef=function(name,def){
		classObjDefRegs[name]=def;
	};
	//------------------------------------------------------------------------
	EditClassObj.getDef=function(name){
		let def=classObjDefRegs[name];
		if(!def){
			def={...DefClassObj,name:name};
		}
		return def;
	};

	//------------------------------------------------------------------------
	editClassObj.getName=function(vo){
		return this.name+": "+this.objClass.name;
	};
	
	//------------------------------------------------------------------------
	editClassObj.loadFromVO=function(vo){
		let voAttrs;
		this.muteNotify();
		this.objClass=EditClass.getClass("ObjClass"+vo.objClass);
		if(!this.objClass){
			//The objClass maybe not been loaded, wait...
			this.objClass="ObjClass"+vo.objClass;
		}
		this.applyJaxId(vo.jaxId||null);
		this.editVersion=vo.editVersion||0;
		voAttrs=vo.attrs;
		this.attrs.loadFromVO(voAttrs);
		this.unmuteNotify();
	};
	
	//------------------------------------------------------------------------
	editClassObj.genSaveVO=function(){
		let attrList;
		let vo={};

		{
			let exportType,orgDef;
			exportType=true;
			if(!this.def.extraAttr && this.owner){
				orgDef=this.owner.getAttrDef(this.name);
				if(orgDef && orgDef.key && this.def.type===orgDef.type){
					exportType=false;
				}
			}
			if(exportType){
				vo.type=this.def.type||"object";
				vo.def=this.objDef.name;
			}
		}
		//vo.objClass=this.objClass.jaxId;
		//vo.type=this.def.type;
		vo.def=this.objDef.name;
		vo.jaxId=this.jaxId;
		//vo.editVersion=this.editVersion;
		attrList=this.attrs;
		vo.attrs=attrList.genSaveVO();
		return vo;
	};

	//------------------------------------------------------------------------
	editClassObj.postLoad=function(){
		let attrList,attr;
		if(typeof(this.objClass)==="string"){
			this.objClass=EditAttr.getClass(this.objClass);
		}
		attrList=this.attrList;
		for(attr of attrList){
			attr.postLoad && attr.postLoad();
		}
	};
}

//****************************************************************************
//:MockupObj: mockup object attr under objClass
//****************************************************************************
let EditMockup, editMockup;
{
	EditMockup=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		let self=this;
		this.className=def.className;
		this.valText="null";
		this.val=null;
		this.icon="ghost.svg";
		
		let selfProxy;
		let mockupClass=null;
		Object.defineProperty(this,'selfProxy',{
			get:function(){
				if(self.valText==="null"){
					return null;
				}
				if(!selfProxy){
					selfProxy=new Proxy(new EditObjProxy(self),{
						get:function(tgt,key){
							let attr,mockupObj;
							if(!mockupClass){
								mockupClass=EditAttr.getClass(self.className);
							}
							if(!mockupClass ||! mockupClass.mockupObjs){
								return undefined;
							}
							if(key==="%EditObj"){
								return mockupClass.properties;
							}
							if(key===Symbol.toPrimitive){
								return ()=>"{EditObjAttr}";
							}
							mockupObj=mockupClass.mockupObjs.getAttr(self.valText);
							if(mockupObj){
								return mockupObj.selfProxy[key];
							}else{
								return mockupClass.properties.selfProxy[key];
							}
							return undefined;
						},
						set:function(tgt,key,val){
							throw new Error(`Can not set attrib "${key}" on EditMockup obj.`);
						}
					});
				}
				return selfProxy;
			},
			enumerable: true,
			configurable: true
		});
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				this.val=this.text2Val(this.valText);
			}
		}
	};
	inherits(EditMockup,EditAttr);
	editMockup=EditMockup.prototype;
	EditAttr.regAttrType("mockup",EditMockup);

	//------------------------------------------------------------------------
	editMockup.text2Val=function(text){
		let val,pts,className,mockName,classAttr,mockObj;
		if(text===""){
			return null;
		}
		if(text==="null"){
			return null;
		}
		if(this.className){
			className=this.className;
			mockName=text;
		}else{
			pts=text.split(".");
			if(pts.length!==2){
				return null;
			}
			className=pts[0];mockName=pts[1];
		}
		classAttr=EditAttr.getClass(className);
		if(!classAttr){
			return null;
		}
		mockObj=classAttr.mockupObjs.getAttr(mockName);
		if(!mockObj){
			return null;
		}
		return mockObj;
	};

	//------------------------------------------------------------------------
	editMockup.val2Text=function(val){
		if(!val){
			return "null";
		}
		if(this.className){
			if(val.name){
				return val.name;
			}
			return "null";
		}else{
			if(val.def && val.def.classAttr && val.name){
				return val.def.classAttr.name+"."+val.name;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	editMockup._genSaveVO=function(){
		let vo;
		vo={};
		vo.type="mockup";
		vo.className=this.className;
		vo.valText=this.valText;
		return vo;
	};
	
	//------------------------------------------------------------------------
	editMockup.loadFromVO=function(vo){
		if(typeof(vo)==="string"){
			this.valText=vo;
			this.val=this.text2Val(this.valText);
		}else{
			this.className=vo.className||this.def.className;
			this.valText=vo.valText;
			this.val=this.text2Val(this.valText);
		}
	};
	
	//------------------------------------------------------------------------
	editMockup.postLoad=function(){
		this.val=this.text2Val(this.valText);
	};
	
	//------------------------------------------------------------------------
	editMockup.val2ShowText=function(){
		if(this.className){
			let classObj,className;
			classObj=EditAttr.getClass(this.className);
			if(classObj){
				className=classObj.showName||classObj.name;
				if(this.val){
					return `${this.val.name}[${className}]`;
				}else{
					return `null[${className}]`;
				}
			}else{
				return `null[Missing class: ${this.className}]`;
			}
		}else{
			return "null"
		}
	};
	
	//------------------------------------------------------------------------
	editMockup.genAttrDef=function(name,showName,key=true,fixed=true){
		return {
			name:name||this.name,
			showName:showName||this.showName||this.name,
			type:"mockup",
			className:this.className,
			key:key,fixed:fixed,
			initValText:this.valText
		}
	};
	
	//------------------------------------------------------------------------
	editMockup.updateGenedAttrDef=function(attrDef){
		attrDef.initValText=this.valText;
	};
	
	//------------------------------------------------------------------------
	editMockup.getJSObj=function(deep=0,maxDeep=5,applyHyper=false){
		let mockupClass,mockupObj,mocked;
		function makeObj(edObj,deep){
			let objVO,attrList,attr;
		}
		mockupClass=EditAttr.getClass(this.className);
		if(mockupClass){
			mockupObj=mockupClass.mockupObjs.getAttr(this.valText);
			if(!mockupObj){
				return null;
			}
			return mockupObj.getJSObj(deep,maxDeep,applyHyper);
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	editMockup.exportCode=function(){
		return "null";
	};
}

export {EditClass,EditClassObj,EditMockup};


