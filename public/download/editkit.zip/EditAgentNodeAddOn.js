import {VFACT} from "/@vfact";
import {} from "./aiagent/DirAgentNode.js";
import {} from "./aiagent/EditAI.js";
import {UIEditWithCanvas} from "./ui/UIEditWithCanvas.js";
import {} from "/@aichat/ai/RemoteChat.js";

export default {
	"DocEditor":{
		"CanvasEditor":UIEditWithCanvas
	}
};