import pathLib from "/@path";
import inherits from "/@inherits";
import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditDocExporter,genAttrValText,genLocalizeValText,genLocalizeValTextPy} from "../exporters/EditDocExporter.js";
import {CdyCoder} from "../exporters/coder.js";
import {DocClassExporter} from "../exporters/DocClassExporter.js";

var DocAIAgentExporter,docAIAgentExporter;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
let segTypeExporters={};
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocAIAgentExporter=function(prj){
	EditDocExporter.call(this,prj);
};
DocAIAgentExporter.segTypeExporters=segTypeExporters;
EditDocExporter.regExporter("AIAgent",DocAIAgentExporter);
inherits(DocAIAgentExporter,EditDocExporter);
docAIAgentExporter=DocAIAgentExporter.prototype;
if(VFACT.classRegs){
	VFACT.classRegs.DocAIAgentExporter=DocAIAgentExporter;
}

//----------------------------------------------------------------------------
let exportDebug=false;
docAIAgentExporter.isExportDebug=function(){
	return exportDebug;
};

function genArgShowName(argVal,isPython){
	let attrLabel;
	attrLabel=argVal.getAttr("label");
	if(!attrLabel || !attrLabel.valText){
		return "undefined";
	}
	if(attrLabel.localize){
		if(isPython){
			return genLocalizeValTextPy(attrLabel);
		}else{
			return genLocalizeValText(attrLabel);
		}
	}
	return `"${attrLabel.val}"`;
}

docAIAgentExporter.export=function(editDoc,opts){
	let list,i,n,coder,exportObjs,subStates;
	let path,baseName,exportName;
	let inBrowser;
	opts=opts||{};
	subStates=[];
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("//Auto genterated by Cody");
	coder.newLine();
	exportDebug=editDoc.getAttr("debug").val;
	path=editDoc.getAttr("path").val;
	baseName=pathLib.basename(path);
	{
		let pos=baseName.indexOf(".");
		exportName=(pos>0)?(baseName.substring(0,pos)):baseName;
		exportObjs.push(exportName);
	}
	this.agentInBrowser=inBrowser=editDoc.getAttrVal("inBrowser");

	//Imports:
	if(inBrowser){
		let imports,path,stub,items;
		let orgPath=opts.path||editDoc.selfProxy.path;
		let orgDir=opts.orgDir||pathLib.dirname(orgPath);
		let prjPath=editDoc.prj.path;
		{
			coder.packText(`import {$P,VFACT,callAfter,sleep} from "/@vfact";`,0);
			coder.newLine();
			coder.packText(`import pathLib from "/@path";`,0);
			coder.newLine();
			coder.packText(`import inherits from "/@inherits";`,0);
			coder.newLine();
			coder.packText(`import Base64 from "/@tabos/utils/base64.js";`,0);
			coder.newLine();
			coder.packText(`import {trimJSON} from "/@aichat/utils.js";`,0);
			coder.newLine();
		}
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(!stub.isUsed()){
				continue;
			}
			if(path.startsWith(prjPath)){//In same prj, use relative path
				if(path.startsWith(orgDir)){
					path="./"+pathLib.basename(path);
				}else if(!path.startsWith("/@")){
					path=pathLib.relative(orgDir,path);
				}
			}
			if(opts.fixExt){
				let ext;
				ext=pathLib.extname(path);
				if(ext!==".js"){
					path=path.substring(0,path.length-ext.length)+".js";
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}
		coder.beginDocObjTagBlcok(editDoc,"MoreImports");
		coder.endDocObjTagBlcok(editDoc,"MoreImports",0);
		coder.packText(`const agentURL=(new URL(import.meta.url)).pathname;`,0);
		coder.newLine();
		coder.packText(`const baseURL=pathLib.dirname(agentURL);`,0);
		coder.newLine();
		coder.packText(`const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;`,0);
		coder.newLine();
		coder.packText(`const $ln=VFACT.lanCode||"EN";`,0);
		coder.newLine();

	}else{
		let imports,path,stub,items;
		let orgPath=opts.path||editDoc.selfProxy.path;
		let orgDir=opts.orgDir||pathLib.dirname(orgPath);
		let prjPath=editDoc.prj.path;
		let homePath="../..";
		coder.packText(`import pathLib from "path";`,0);
		coder.newLine();
		coder.packText(`import Base64 from "${homePath}/agenthub/base64.mjs";`,0);
		coder.newLine();
		coder.packText(`import {trimJSON} from "${homePath}/agenthub/ChatSession.mjs";`,0);
		coder.newLine();
		coder.packText(`import {URL} from "url";`,0);
		coder.newLine();
		imports=editDoc.imports;
		for(path in imports){
			stub=imports[path];
			if(!stub.isUsed()){
				continue;
			}
			if(path.startsWith(prjPath)){//In same prj, use relative path
				if(path.startsWith(orgDir)){
					path="./"+pathLib.basename(path);
				}else if(!path.startsWith("/@")){
					path=pathLib.relative(orgDir,path);
				}
			}
			if(opts.fixExt){
				let ext;
				ext=pathLib.extname(path);
				if(ext!==".js"){
					path=path.substring(0,path.length-ext.length)+".js";
				}
			}
			coder.packText("import {",0);
			items=stub.items;
			for(let name in items){
				coder.packText(`${name},`,0);
			}
			coder.eatPreComa();
			coder.packText(`} from "${path}";`,0);
			coder.newLine();
		}

		coder.beginDocObjTagBlcok(editDoc,"MoreImports");
		coder.endDocObjTagBlcok(editDoc,"MoreImports",0);
		coder.packText(`const agentURL=decodeURIComponent((new URL(import.meta.url)).pathname);`,0);
		coder.newLine();
		coder.packText(`const baseURL=pathLib.dirname(agentURL);`,0);
		coder.newLine();
		coder.packText(`const basePath=baseURL.startsWith("file://")?pathLib.fileURLToPath(baseURL):baseURL;`,0);
		coder.newLine();
		coder.packText(`const VFACT=null;`,0);
		coder.newLine();
	}
	//Arguments template:
	{
		let args,arg,attr;
		args=editDoc.getAttr("apiArgs").attrList;
		if(args.length>0){
			coder.packText("const argsTemplate={");
			coder.indentMore();coder.newLine();
			{
				coder.packText("properties:{");coder.indentMore();coder.newLine();
				{
					for(arg of args){
						coder.packText(`"${arg.name}":{`);coder.indentMore();coder.newLine();
						{
							coder.packText(`"name":"${arg.name}","type":"${arg.getAttrVal("type")}",`);coder.newLine();
							attr=arg.getAttr("label");
							if(attr && attr.valText){
								coder.packText(`"label":"${arg.getAttrVal("label")}",`);coder.newLine();
							}
							attr=arg.getAttr("required");
							if(attr && attr.valText){
								coder.packText(`"required":${!!arg.getAttrVal("required")},`);coder.newLine();
							}
							coder.packText(`"defaultValue":${JSON.stringify(arg.getAttrVal("mockup"))},`);coder.newLine();
							coder.packText(`"desc":"${arg.getAttrVal("desc")}",`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();coder.packText("},");coder.newLine();
					}
					coder.eatPreComa();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText("},");coder.newLine();
				coder.beginDocObjTagBlcok(editDoc,"ArgsView");
				coder.endDocObjTagBlcok(editDoc,"ArgsView",0);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText("};");coder.newLine();
			coder.newLine();
		}
	}
	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);

	//Export Major hud-gear:
	{
		let exportObj,attr,localVars,seg0,segNames;
		exportObj=editDoc;
		coder.packText("//----------------------------------------------------------------------------");
		coder.newLine();
		coder.packText(`let ${exportName}=async function(session){`);
		{
			coder.indentMore();coder.newLine();
			//Add exec-arguments:
			{
				let args=editDoc.getAttr("apiArgs").attrList;
				if(args.length>0){
					let arg;
					coder.packText("let ");
					for(arg of args){
						coder.packText(`${arg.name},`);
					}
					coder.eatPreComa();
					coder.packText(";");
					coder.newLine();
				}else{
					coder.packText("let execInput;");coder.newLine();
				}
			}
			coder.packText(`const $ln=session.language||"EN";`,0);coder.newLine();
			coder.packText("let context,globalContext=session.globalContext;");coder.newLine();
			coder.packText("let self;");coder.newLine();
			seg0=exportObj.segsList[0];
			//named segs
			{
				let i,n;
				segNames=[];
				exportObj.runOnAllSegs((seg)=>{
					let name=seg.getAttr("id").val;
					if(name && varNameRegex.test(name)){
						segNames.push(name);
					}else if(!seg.isConnector){
						segNames.push("SEG"+seg.jaxId);
					}
				},false);
				n=segNames.length;
				if(n){
					let name,names;
					names={};
					coder.maybeNewLine();
					coder.packText(`let `);
					for(i=0;i<n;i++){
						name=segNames[i];
						//name=name[0].toLowerCase()+name.substring(1);
						if(!names[name]){
							if(i>0){
								coder.packText(`,`);
							}
							coder.packText(name);
							names[name]=1;
						}
					}
					coder.packText(`;`);
					coder.newLine();
				}else{
					coder.newLine();
				}
			}
			//Add localVars;
			localVars=editDoc.getAttr("localVars").attrList;
			if(localVars.length>0){
				for(attr of localVars){
					this.genLocalVar(attr,subStates);
				}
				coder.newLine();
			}
			coder.beginDocObjTagBlcok(exportObj,"LocalVals");
			coder.endDocObjTagBlcok(exportObj,"LocalVals",0);
			coder.newLine();
			{
				let args=editDoc.getAttr("apiArgs").attrList;
				coder.packText("function parseAgentArgs(input){");coder.indentMore();	coder.newLine();
				{
					if(args.length>0){
						let arg;
						coder.packText("if(typeof(input)=='object'){");
						coder.indentMore();	coder.newLine();
						{
							for(arg of args){
								coder.packText(`${arg.name}=input.${arg.name};`);coder.newLine();
							}
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText("}else{");
						coder.indentMore();coder.newLine();
						{
							for(arg of args){
								coder.packText(`${arg.name}=undefined;`);coder.newLine();
							}
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText("}");
					}else{
						coder.packText("execInput=input;");coder.newLine();
					}
					coder.beginDocObjTagBlcok(editDoc,"ParseArgs");
					coder.endDocObjTagBlcok(editDoc,"ParseArgs",0);
				}
				coder.indentLess();coder.maybeNewLine();coder.packText("}");coder.maybeNewLine();
				coder.newLine();
			}
			coder.beginDocObjTagBlcok(exportObj,"PreContext");
			coder.endDocObjTagBlcok(exportObj,"PreContext",0);
			coder.maybeNewLine();
			//Context:
			{
				let stateObj=editDoc.getAttr("context");
				if(stateObj.attrList.length>0){
					coder.packText("context=");
					this.genContextObjSeg(editDoc.getAttr("context"),"ExCtxAttrs");
					coder.eatPreComa();
					coder.packText(";");
					coder.newLine();
					if(inBrowser){
						if(!subStates.length){
							coder.packText("context=VFACT.flexState(context);");coder.newLine();
						}else{
							subStates=subStates.map(item=>item.name);
							coder.packText(`context=VFACT.flexState(state,${""+subStates});`);coder.newLine();
						}
					}
				}else{
					coder.packText("context={};");
					coder.newLine();
					if(inBrowser){
						coder.packText("context=VFACT.flexState(context);");coder.newLine();
					}
				}
			}
			coder.beginDocObjTagBlcok(exportObj,"PostContext");
			coder.endDocObjTagBlcok(exportObj,"PostContext",0);
			coder.packText("let $agent,agent,segs={};");coder.newLine();
			
			//Export segs:
			{
				let segsList,seg;
				segsList=exportObj.segsList;
				for(seg of segsList){
					this.exportSeg(seg);
				}
			}
			
			//Export agent 
			let segName;
			if(seg0){
				let entrySeg=null;
				{
					let segName=exportObj.getAttrVal("entry");
					let list=exportObj.segsVal.attrList;
					if(segName){
						for(let seg of list){
							if(seg.idVal.val===segName){
								entrySeg=seg;
								break;
							}
						}
					}
				}
				entrySeg=entrySeg||seg0;
				segName=entrySeg.getAttr("id").val;
				segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+entrySeg.jaxId);
			}else{
				segName=null;
			}
			coder.packText("agent=$agent={");
			coder.indentMore();				
			coder.newLine();
			{
				let args=editDoc.getAttr("apiArgs").attrList;
				let showNameAttr=editDoc.getAttr("showName");
				let showNameValText=showNameAttr.valText;
				coder.packText(`isAIAgent:true,`);
				coder.newLine();
				coder.packText(`session:session,`);
				coder.newLine();
				coder.packText(`name:"${exportName}",`);
				coder.newLine();
				if(showNameValText){
					coder.packText(`showName:`);this.genAttrStatement(showNameAttr);coder.packText(`,`);
					coder.newLine();
				}
				coder.packText(`url:agentURL,`);
				coder.newLine();
				coder.packText(`autoStart:${exportObj.getAttrVal("autoStart")},`);
				coder.newLine();
				if(exportDebug){
					coder.packText(`jaxId:"${editDoc.jaxId}",`);
					coder.newLine();
				}
				coder.packText("context:context,");
				coder.newLine();
				coder.packText("livingSeg:null,");
				coder.newLine();
				if(args.length>0){
					let arg;
					coder.packText("execChat:async function(input/*{");
					for(arg of args){
						coder.packText(`${arg.name},`);
					}
					coder.eatPreComa();
					coder.packText("}*/){");
				}else{
					coder.packText("execChat:async function(input){");
				}
				coder.indentMore();				
				coder.newLine();
				{
					coder.packText(`let result;`);coder.newLine();
					coder.packText(`parseAgentArgs(input);`);coder.newLine();
					coder.beginDocObjTagBlcok(exportObj,"PreEntry");
					coder.endDocObjTagBlcok(exportObj,"PreEntry",0);
					if(segName){
						coder.packText(`result={seg:${segName},"input":input};`);coder.newLine();
					}
					//coder.packText(`result=await session.execAISeg(agent,${segName},input);`);coder.newLine();
					coder.beginDocObjTagBlcok(exportObj,"PostEntry");
					coder.endDocObjTagBlcok(exportObj,"PostEntry",0);
					coder.packText(`return result;`);
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText("},");
				coder.beginDocObjTagBlcok(exportObj,"MoreAgentAttrs");
				coder.endDocObjTagBlcok(exportObj,"MoreAgentAttrs",0);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText("};");
			coder.newLine();
			

			//:Functions
			let funcs=exportObj.getAttr("functions");
			if(funcs){
				funcs=funcs.attrList;
				for(let func of funcs){
					this.genFunctionSeg(exportObj.name,func);
				}
			}
			coder.beginDocObjTagBlcok(exportObj,"PostAgent");
			coder.endDocObjTagBlcok(exportObj,"PostAgent",0);
			coder.packText("return agent;");
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.packText("};");
		coder.maybeNewLine();

		coder.beginDocObjTagBlcok(exportObj,"ExCodes");
		coder.endDocObjTagBlcok(exportObj,"ExCodes",0);
		coder.newLine();
	}
	coder.packText("//#CodyExport>>>");coder.newLine();
	//------------------------------------------------------------------------
	//API list:
	if(editDoc.getAttrVal("exportAPI")){
		let addOnOpts,segName,showName,segIcon,catalog,agentPath;
		addOnOpts=editDoc.getAttrVal("addOnOpts")||{};
		if(inBrowser){
			coder.packText(`export const ChatAPI=[{`);
		}else{
			coder.packText(`let ChatAPI=[{`);
		}
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`def:{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`name: "${exportName}",`);coder.newLine();
				coder.packText(`description: ${JSON.stringify(editDoc.getAttrVal("desc"))},`),coder.newLine();
				coder.packText(`parameters:{`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`type: "object",`);coder.newLine();
					coder.packText(`properties:{`);
					coder.indentMore();
					coder.newLine();
					{
						let list,i,n,attr,enumAttr;
						list=editDoc.getAttr("apiArgs").attrList;
						n=list.length;
						for(i=0;i<n;i++){
							attr=list[i];
							coder.packText(`${attr.name}:{type:"${attr.getAttrVal("type")}",description:${JSON.stringify(attr.getAttrVal("desc"))},`);
							enumAttr=attr.getAttr("enum");
							if(enumAttr && enumAttr.attrList.length>0){
								coder.packText(`enum:[`);
								for(attr of enumAttr.attrList){
									coder.packText(JSON.stringify(attr.val));
									coder.packText(",");
								}
								coder.eatPreComa();
								coder.packText(`]`);
							}
							coder.eatPreComa();
							coder.packText(`},`);
							coder.newLine();
						}
					}
					coder.eatPreComa();
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);
					coder.newLine();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`},`);
			coder.newLine();
			if(addOnOpts.path){
				coder.packText(`path: ${JSON.stringify(addOnOpts.path)},`);coder.newLine();
			}
			if(addOnOpts.pathInHub){
				let nodeName,agentName;
				let hubPath=addOnOpts.pathInHub;
				let pts=hubPath.split("@");
				if(pts>1){
					nodeName=pts[0];
					agentName=pts[1];
				}else{
					nodeName=hubPath;
					agentName=pathLib.basename(editDoc.path);
				}
				if(nodeName && agentName){
					coder.packText(`agentNode: ${JSON.stringify(nodeName)},`);coder.newLine();
					coder.packText(`agentName: ${JSON.stringify(agentName)},`);coder.newLine();
				}
			}
			if(addOnOpts.label){
				coder.packText(`label: ${JSON.stringify(addOnOpts.label)},`);coder.newLine();
			}
			if(addOnOpts.isRPA){
				coder.packText(`isRPA: true,`);coder.newLine();
				//coder.packText(`rpaHost: ${JSON.stringify(addOnOpts.rpaHost)},`);coder.newLine();
			}
			if(addOnOpts.isChatApi===false){
				coder.packText(`isChatApi: false,`);coder.newLine();
			}else{
				coder.packText(`isChatApi: true,`);coder.newLine();
			}
			if(addOnOpts.chatEntry){
				coder.packText(`chatEntry: ${JSON.stringify(addOnOpts.chatEntry)},`);coder.newLine();
			}
			if(addOnOpts.capabilities){
				coder.packText(`capabilities: ${JSON.stringify(addOnOpts.capabilities)},`);coder.newLine();
			}
			if(addOnOpts.meta){
				coder.packText(`meta: ${JSON.stringify(addOnOpts.meta)},`);coder.newLine();
			}
			if(addOnOpts.segIcon){
				coder.packText(`icon: ${JSON.stringify(addOnOpts.segIcon)},`);coder.newLine();
			}
			if(this.agentInBrowser){
				coder.packText(`agent: ${exportName},`);
			}
		}
		coder.eatPreComa();
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}];`);
		coder.newLine();
	}
	
	//------------------------------------------------------------------------
	//Agent Add-On:
	if(editDoc.getAttrVal("exportAddOn")){
		coder.newLine();
		coder.packText(`//:Export Edit-AddOn:`);coder.newLine();
		coder.packText(`const DocAIAgentExporter=VFACT?VFACT.classRegs.DocAIAgentExporter:null;`);coder.newLine();
		coder.packText(`if(DocAIAgentExporter){`);coder.indentMore();coder.newLine();
		{
			let addOnOpts,segName,showName,segIcon,catalog,agentPath,hubPath;
			addOnOpts=editDoc.getAttrVal("addOnOpts")||{};
			segName=addOnOpts.name||exportName;
			showName=addOnOpts.label||segName;
			segIcon=addOnOpts.segIcon||"agent.svg";
			catalog=addOnOpts.catalog||"AI Call";
			agentPath=addOnOpts.path||("/~"+editDoc.dataDoc.path);
			coder.packText(`const EditAttr=VFACT.classRegs.EditAttr;`);coder.newLine();
			coder.packText(`const EditAISeg=VFACT.classRegs.EditAISeg;`);coder.newLine();
			coder.packText(`const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;`);coder.newLine();
			coder.packText(`const SegObjShellAttr=EditAISeg.SegObjShellAttr;`);coder.newLine();
			coder.packText(`const SegOutletDef=EditAISegOutlet.SegOutletDef;`);coder.newLine();
			coder.packText(`const docAIAgentExporter=DocAIAgentExporter.prototype;`);coder.newLine();
			coder.packText(`const packExtraCodes=docAIAgentExporter.packExtraCodes;`);coder.newLine();
			coder.packText(`const packResult=docAIAgentExporter.packResult;`);coder.newLine();
			coder.packText(`const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;`);coder.newLine();
			coder.newLine();
			//Seg def:
			coder.packText(`EditAISeg.regDef({`);coder.indentMore();coder.newLine();
			{
				let list,attr,i,n;
				coder.packText(`name:"${segName}",showName:${JSON.stringify(showName)},icon:"${segIcon}",catalog:["${catalog}"],`);coder.newLine();
				coder.packText(`attrs:{`);coder.indentMore();coder.newLine();
				{
					coder.packText(`...SegObjShellAttr,`);coder.newLine();
					//Pack arguments:
					list=editDoc.getAttr("apiArgs").attrList;
					n=list.length;
					for(i=0;i<n;i++){
						attr=list[i];
						coder.packText(`"${attr.name}":{name:"${attr.name}",showName:${genArgShowName(attr)},type:"${attr.getAttrVal("type")}",key:1,fixed:1,initVal:${JSON.stringify(attr.getAttrVal("mockup"))}},`);
						coder.newLine();
					}
					coder.packText(`"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`},`);coder.newLine();
				coder.packText(`listHint:["id",`);
				for(i=0;i<n;i++){
					attr=list[i];
					coder.packText(`"${attr.name}",`);
				}
				coder.packText(`"codes","desc"],`);coder.newLine();
				coder.packText(`desc:${JSON.stringify(editDoc.getAttrVal("desc"))}`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`});`);coder.newLine();
			coder.newLine();
			
			//Export seg function:
			this.exportAgentSeg(editDoc,segName,agentPath);
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}`);
		coder.newLine();
	}
	coder.packText("//#CodyExport<<<");coder.newLine();

	coder.beginDocObjTagBlcok(editDoc,"PostDoc");
	coder.endDocObjTagBlcok(editDoc,"PostDoc",0);
	coder.newLine();
	//------------------------------------------------------------------------
	//export
	coder.newLine();
	coder.packText(`export default ${exportObjs[0]};`);coder.newLine();
	coder.packText("export{");
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(exportObjs[i]);
		coder.packText(",");
	}
	if(editDoc.getAttrVal("exportAPI") && !inBrowser){
		coder.packText("ChatAPI");
	}
	coder.eatPreComa();
	coder.packText("};");
	coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docAIAgentExporter.genLocalVar=function(attr,subStates=null){
	let coder=this.coder;
	coder.packText(`let ${attr.name}=`);
	this.genAttrStatement(attr);
	coder.packText(`;`);
	coder.newLine();
};

//----------------------------------------------------------------------------
docAIAgentExporter.exportSeg=function(seg){
	let typeName,funcName,func;
	typeName=seg.objDef.name;
	funcName="export_"+typeName;
	func=this[funcName]||segTypeExporters[typeName];
	if(func){
		func.call(this,seg);
	}
};
//----------------------------------------------------------------------------
docAIAgentExporter.genContextObjSeg=function(editObj,exSeg){
	let coder=this.coder;
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.objDef && attr.objDef.name==="AgentCallArgument"){
				coder.packText(attr.name+": ");
				this.genInObjSegAttr(attr.getAttr("mockup"),false);
				coder.maybeNewLine();
			}else if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
				coder.maybeNewLine();
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("}");
};

//----------------------------------------------------------------------------
docAIAgentExporter.genJSONFormat=function(attrObj){
	let formatDef,schemaDef,refDefs;
	refDefs={};
	schemaDef=this.genJSONSchema(attrObj,refDefs,attrObj);
	if(Object.keys(refDefs).length>0){
		schemaDef["$defs"]=refDefs;
	}
	formatDef={
		name:attrObj.label||attrObj.name,
		schema:schemaDef,
		strict: true,
	};
	return {
		"type": "json_schema",
		"json_schema":formatDef
	};
};

//----------------------------------------------------------------------------
docAIAgentExporter.genJSONSchema=function(attrObj,refDefs,orgAttrObj){
	let jsonDef,attrList,attr,ppts,ppt,reqs;
	let attrName,attrType,attrDesc,choicesAttr;
	
	function cvtType(attrType){
		switch(attrType){
			default:
			case "string":
				return "string";
			case "int":
				return "integer";
			case "number":
			case "float":
			case "real":
				return "number";
			case "bool":
				return "boolean";
				break;
			case "object":
				return "object";
			case "array":
				return "array";
			case "auto":
				return "any"
		}
	}
	
	ppts={};
	reqs=[]
	jsonDef={
		type:"object",
		description:attrObj.desc,
		properties:ppts,
		required: reqs,
		additionalProperties: false
	};
	attrList=Object.values(attrObj.properties);
	for(attr of attrList){
		attrName=attr.name;
		attrType=attr.type;
		attrType=cvtType(attrType);
		if(attr.required===false){
			attrType=[attrType,"null"];
		}
		reqs.push(attrName);
		ppt={
			type:attrType
		};
		attrDesc=attr.desc;//TODO: support localization?
		if(attrDesc){
			ppt.description=attrDesc;
		}
		choicesAttr=attr.choices;
		if(choicesAttr){
			let chList,i,n,ch,enums;
			enums=[];
			chList=choicesAttr;
			n=chList.length;
			for(i=0;i<n;i++){
				ch=chList[i];
				if(ch){
					enums.push(ch);
				}
			}
			if(enums.length){
				ppt.enum=enums;
			}
		}
		if(attrType==="array" ||attrType[0]==="array"){
			let elmtAttr,elmtType;
			elmtAttr=attr.element;
			elmtType=elmtAttr.type;
			elmtType=cvtType(elmtType);
			if(elmtType==="object"){
				let classId,className,classTemplate;
				classId=elmtAttr.class;
				classTemplate=VFACT.getEditUITemplate(classId);
				if(classTemplate){
					className=classTemplate.label||classTemplate.name;
					if(classTemplate.name===orgAttrObj.name){
						ppt.items={"$ref":`#`};
					}else if(!refDefs[className]){
						refDefs[className]={};//Hold the place:
						refDefs[className]=this.genJSONSchema(classTemplate,refDefs,orgAttrObj);
						ppt.items={"$ref":`#/$defs/${className}`};
					}else{
						ppt.items={"$ref":`#/$defs/${className}`};
					}
				}
			}else if(elmtType==="array"){
				//Not supported yet...
			}else{
				ppt.items={type:elmtType};
			}
		}else if(attrType==="object"){
			let classId,className,classTemplate;
			classId=attr.class;
			classTemplate=VFACT.getEditUITemplate(classId);
			if(classTemplate){
				className=classTemplate.label||classTemplate.name;
				if(classTemplate.name===orgAttrObj.name){
					ppt={"$ref":`#`};
				}else if(!refDefs[className]){
					if(classTemplate.name===orgAttrObj.name){
						ppt={"$ref":`#`};
					}else{
						refDefs[className]={};//Hold the place:
						refDefs[className]=this.genJSONSchema(classTemplate,refDefs,orgAttrObj);
						ppt={"$ref":`#/$defs/${className}`};
					}
				}
			}
		}
		ppts[attrName]=ppt;
	}
	return jsonDef;
};

//----------------------------------------------------------------------------
docAIAgentExporter.exportAgentSeg=function(editDoc,name,path){
	let coder;
	coder=this.coder;
	coder.packText(`DocAIAgentExporter.segTypeExporters["${name}"]=`);coder.newLine();
	coder.packText(`function(seg){`);coder.indentMore();coder.newLine();
	{
		coder.packText('let coder=this.coder;');coder.newLine();
		coder.packText('let segName=seg.idVal.val;');coder.newLine();
		coder.packText('let exportDebug=this.isExportDebug();');coder.newLine();
		coder.packText('segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);');coder.newLine();
		coder.packText('coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);');coder.newLine();
		coder.packText('coder.indentMore();coder.newLine();');coder.newLine();
		coder.packText("{");coder.indentMore();coder.newLine();
		let list,attr,i,n;
		coder.packText("coder.packText(`let result,args={};`);coder.newLine();");coder.newLine();
		//Pack arguments:
		list=editDoc.getAttr("apiArgs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			coder.packText(`coder.packText("args['${attr.name}']=");this.genAttrStatement(seg.getAttr("${attr.name}"));coder.packText(";");coder.newLine();`);coder.newLine();
		}
		coder.packText('this.packExtraCodes(coder,seg,"PreCodes");');coder.newLine();
		//Call agent:
		coder.packText(`coder.packText(\`result= await session.pipeChat(${JSON.stringify(path)},args,false);\`);coder.newLine();`);coder.newLine();
		coder.packText('this.packExtraCodes(coder,seg,"PostCodes");');coder.newLine();
		//Update context:
		coder.packText('this.packUpdateContext(coder,seg);');coder.newLine();
		coder.packText('this.packUpdateGlobal(coder,seg);');coder.newLine();
		//Result:
		coder.packText('this.packResult(coder,seg,seg.outlet);');coder.newLine();
		coder.indentLess();coder.maybeNewLine();coder.packText("}");
		coder.newLine();
		coder.packText('coder.indentLess();coder.maybeNewLine();');coder.newLine();
		coder.packText('coder.packText(`};`);coder.newLine();');coder.newLine();
		coder.packText('if(exportDebug){');coder.newLine();
		coder.packText('\tcoder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();');coder.newLine();
		coder.packText('}');coder.newLine();
		coder.packText('coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();');coder.newLine();
		coder.packText('coder.newLine();');coder.newLine();
	}
	coder.indentLess();coder.maybeNewLine();coder.packText(`};`);coder.newLine();
};

//****************************************************************************
//:Export typed segs
//****************************************************************************
{
	//------------------------------------------------------------------------
	function packResult(coder,seg,outlet,valName="result",applyCatch=true){
		let nextSeg,segName,outletId,catchlet;
		catchlet=applyCatch?seg.catchlet:null;
		outletId="";
		if(outlet){
			outletId=outlet.jaxId;
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(catchlet){
				let catchletId,catchSeg,catchName;
				catchletId=catchlet.jaxId;
				catchSeg=catchlet.getLinkedSeg();
				if(catchSeg){
					catchName=catchSeg.idVal.val||(("SEG")+catchSeg.jaxId);
					catchName=(catchName &&varNameRegex.test(catchName))?catchName:("SEG"+catchName.jaxId);
				}else{
					catchName="null";
				}
				if(exportDebug){
					coder.packText(`return {seg:${segName},result:(${valName}),preSeg:"${seg.jaxId}",outlet:"${outletId}",catchSeg:${catchName},catchlet:"${catchletId}"};`);
				}else{
					coder.packText(`return {seg:${segName},result:(${valName},catchSeg:${catchName})};`);
				}
			}else{
				if(exportDebug){
					coder.packText(`return {seg:${segName},result:(${valName}),preSeg:"${seg.jaxId}",outlet:"${outletId}"};`);
				}else{
					coder.packText(`return {seg:${segName},result:(${valName})};`);
				}
			}
		}else{
			coder.packText(`return {result:${valName}};`);
		}
	}
	docAIAgentExporter.packResult=packResult;
	
	//------------------------------------------------------------------------
	function packSegCall(coder,outlet,valName="input",isAsync=false){
		let nextSeg,segName;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(isAsync){
				coder.packText(`session.execAISeg(agent,${segName},(${valName}))`);
			}else{
				coder.packText(`await session.execAISeg(agent,${segName},(${valName}))`);
			}
		}else{
			coder.packText(`${valName}`);
		}
	}
	docAIAgentExporter.packSegCall=packSegCall;
	
	//------------------------------------------------------------------------
	function packSegCallWithAttr(coder,outlet,attr,isAsync=false){
		let nextSeg,segName;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(isAsync){
				coder.packText(`session.execAISeg(agent,${segName},(`);this.genAttrStatement(attr);coder.packText(`))`);
			}else{
				coder.packText(`await session.execAISeg(agent,${segName},(`);this.genAttrStatement(attr);coder.packText(`))`);
			}
		}else{
			this.genAttrStatement(attr);
		}
	}
	docAIAgentExporter.packSegCallWithAttr=packSegCallWithAttr;

	//------------------------------------------------------------------------
	function packSegRun(coder,preSeg,outlet,valName="input",isAsync=false){
		let nextSeg,segName;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(exportDebug){
				if(isAsync){
					coder.packText(`session.runAISeg(agent,${segName},${valName},"${preSeg?preSeg.jaxId:null}","${outlet.jaxId}")`);
				}else{
					coder.packText(`await session.runAISeg(agent,${segName},${valName},"${preSeg?preSeg.jaxId:null}","${outlet.jaxId}")`);
				}
			}else{
				if(isAsync){
					coder.packText(`session.runAISeg(agent,${segName},(${valName}))`);
				}else{
					coder.packText(`await session.runAISeg(agent,${segName},(${valName}))`);
				}
			}
		}else{
			coder.packText(`${valName}`);
		}
	}
	docAIAgentExporter.packSegRun=packSegRun;

	//------------------------------------------------------------------------
	function packSegRunWithAttr(coder,preSeg,outlet,attr,isAsync=false){
		let nextSeg,segName;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(exportDebug){
				if(isAsync){
					coder.packText(`session.runAISeg(agent,${segName},`);this.genAttrStatement(attr);coder.packText(`,"${preSeg?preSeg.jaxId:null}","${outlet.jaxId}")`);
				}else{
					coder.packText(`await session.runAISeg(agent,${segName},`);this.genAttrStatement(attr);coder.packText(`),"${preSeg?preSeg.jaxId:null}","${outlet.jaxId}"`);
				}
			}else{
				if(isAsync){
					coder.packText(`session.runAISeg(agent,${segName},(`);this.genAttrStatement(attr);coder.packText(`))`);
				}else{
					coder.packText(`await session.runAISeg(agent,${segName},(`);this.genAttrStatement(attr);coder.packText(`))`);
				}
			}
		}else{
			this.genAttrStatement(attr);
		}
	}
	docAIAgentExporter.packSegRunWithAttr=packSegRunWithAttr;

	//------------------------------------------------------------------------
	function packExtraCodes(coder,seg,mark="Codes",force=false){
		let codes=seg.getAttr("codes");
		if(codes){
			codes=!!codes.val;
		}
		if(codes||force){
			coder.beginDocObjTagBlcok(seg,mark);
			coder.endDocObjTagBlcok(seg,mark,0);
		}
	}
	docAIAgentExporter.packExtraCodes=packExtraCodes;

	//------------------------------------------------------------------------
	function genProcessSeg(prcAttr){
		let coder;
		if(!prcAttr){
			return;
		}
		coder=this.coder;
		coder.packText(`{`);coder.indentMore();coder.newLine();
		{
			coder.packText(`const $text=`);this.genAttrStatement(prcAttr.getAttr("text"));coder.packText(`;`);coder.newLine();
			coder.packText(`const $role=(`);this.genAttrStatement(prcAttr.getAttr("$role"));coder.packText(`)||"assistant";`);coder.newLine();
			coder.packText(`const $roleText=(`);this.genAttrStatement(prcAttr.getAttr("role"));coder.packText(`)||undefined;`);coder.newLine();
			packExtraCodes(coder,prcAttr,"Codes");
			coder.packText(`await session.addChatText($role,$text,{"channel":"Process","txtHeader":$roleText});`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
	};
	docAIAgentExporter.genProcessSeg=genProcessSeg;

	
	//------------------------------------------------------------------------
	function packUpdateContext(coder,seg){
		let ctxAttr=seg.getAttr("context");
		let castAttr,castObj,key,value,list;
		if(!ctxAttr||!ctxAttr.getAttr){
			return;
		}
		castAttr=ctxAttr.getAttr("cast");
		if(castAttr){
			let keys;
			castObj=castAttr.valText;
			try{
				castObj=JSON.parse(castObj);
			}catch(err){
				castObj=null;
			}
			if(castObj){
				keys=Object.keys(castObj);
				if(keys.length>0){
					for(key of keys){
						value=""+castObj[key];
						if(value){
							if(value.startsWith("#")){
								value=value.substring(1);
							}
							coder.packText(`context["${key}"]=${value};`);coder.newLine();
						}
					}
					return;
				}
			}
		}
		list=ctxAttr.attrList;
		if(list.length>0){
			let attr;
			for(attr of list){
				if(attr.name!=="cast"){
					coder.packText(`context["${attr.name}"]=`);this.genAttrStatement(attr);coder.packText(";");coder.newLine();
				}
			}
		}
	}
	docAIAgentExporter.packUpdateContext=packUpdateContext;
	
	//------------------------------------------------------------------------
	function packUpdateGlobal(coder,seg){
		let ctxAttr=seg.getAttr("global");
		let castAttr,castObj,key,value,list;
		if(!ctxAttr||!ctxAttr.getAttr){
			return;
		}
		castAttr=ctxAttr.getAttr("cast");
		if(castAttr){
			let keys;
			castObj=castAttr.valText;
			try{
				castObj=JSON.parse(castObj);
			}catch(err){
				castObj=null;
			}
			if(castObj){
				keys=Object.keys(castObj);
				if(keys.length>0){
					for(key of keys){
						value=""+castObj[key];
						if(value){
							if(value.startsWith("#")){
								value=value.substring(1);
							}
							coder.packText(`globalContext["${key}"]=${value};`);coder.newLine();
						}
					}
					return;
				}
			}
		}
		list=ctxAttr.attrList;
		if(list.length>0){
			let attr;
			for(attr of list){
				if(attr.name!=="cast"){
					coder.packText(`globalContext["${attr.name}"]=`);this.genAttrStatement(attr);coder.packText(";");coder.newLine();
				}
			}
		}
	}
	docAIAgentExporter.packUpdateGlobal=packUpdateGlobal;
	
	//----------------------------------------------------------------------------
	DocAIAgentExporter.exportImportCall=function(seg, sourcePath,funcName,args){
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);
			coder.maybeNewLine();
			coder.packText(`let md=await import("${sourcePath}");`);coder.newLine();
			coder.packText(`let func=md["${funcName}"];`);coder.newLine();
			coder.packText(`let args=[];`);coder.newLine();
			if(args){
				let argName;
				for(argName of args){
					coder.packText(`args.push(`);this.genAttrStatement(seg.getAttr(argName));coder.packText(");");coder.newLine();
				}
			}
			coder.packText(`result= await func.call(agent,input,...args);`);coder.newLine();
			packExtraCodes(coder,seg);
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_tryCatch=
	docAIAgentExporter.export_code=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let resultVal=seg.getAttr("result");
		let orgCodes=seg.getAttrVal("codes")||seg.getAttrValText("codes");
		if(orgCodes && orgCodes[0]==="#"){
			let pos=orgCodes.indexOf("#>");
			orgCodes=orgCodes.substring(pos>0?pos:1);
		}
		let outlets=seg.outletsList;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result=`);
			if(resultVal){
				this.genAttrStatement(resultVal);
			}else{
				coder.packText("input;");
			}
			coder.newLine();
			if(outlets && outlets.length>0){
				let i,n,outlet,nextSeg,nextSegName;
				coder.packText(`let outlets={`);coder.indentMore();coder.newLine();
				{
					n=outlets.length;
					for(i=0;i<n;i++){
						outlet=outlets[i];
						let nextSeg=outlet.getLinkedSeg();
						if(nextSeg){
							nextSegName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
							nextSegName=(nextSegName &&varNameRegex.test(nextSegName))?nextSegName:("SEG"+nextSeg.jaxId);
							coder.packText(`${outlet.getAttrVal("id")}: ${nextSegName},`);
						}
					}
				}
				coder.eatPreComa();coder.indentLess();coder.maybeNewLine();coder.packText(`};`);
			}
			coder.maybeNewLine();
			genProcessSeg.call(this,seg.getAttr("process"));
			coder.beginDocObjTagBlcok(seg,"Code");
			if(orgCodes){
				coder.packCode(""+orgCodes);
			}
			coder.endDocObjTagBlcok(seg,"Code",0);
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_function=function(seg){
		let resultVal=seg.getAttr("result");
		let sourcePath=seg.getAttr("source").val;
		let funcName=seg.getAttr("function").val;
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);
			coder.maybeNewLine();
			coder.packText(`let md=await import("${sourcePath}");`);coder.newLine();
			coder.packText(`let func=md["${funcName}"];`);coder.newLine();
			coder.packText(`result= await func.call(agent,input);`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg);
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_callLLM=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlet=seg.outlet;
		let secret=seg.getAttrVal("secret");
		let keepNum=seg.getAttrVal("keepChat");
		let docPath=pathLib.dirname(seg.doc.path);
		let apiList,apiFiles;
		let prefixTxt=seg.getAttrValText("inputPrefix");
		let postfixTxt=seg.getAttrValText("inputPostfix");
		let clearNum=seg.getAttrVal("clearChat");
		let allowCheat=seg.getAttrVal("allowCheat");
		let hasCode=seg.getAttrVal("codes");
		let shareChatName=seg.getAttrVal("shareChatName");
		let parallelFunction=seg.getAttrVal("parallelFunction");
		let responseFormat=seg.getAttrVal("responseFormat");
		let formatDefAttr=seg.getAttr("formatDef");
		let useStream=seg.getAttrVal("stream");
		
		apiFiles=seg.getAttr("apiFiles").attrList;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let prompt;`);coder.newLine();
			if(hasCode){
				coder.packText(`let result=null;`);coder.newLine();
			}else{
				coder.packText(`let result;`);coder.newLine();
			}
			genProcessSeg.call(this,seg.getAttr("process"));
			packExtraCodes(coder,seg,"Input");coder.newLine();
			//Call options:
			coder.packText(`let opts={`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`platform:`);this.genAttrStatement(seg.getAttr("platform"));coder.packText(`,`);coder.newLine();
				coder.packText(`mode:`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`,`);coder.newLine();
				coder.packText(`maxToken:`);this.genAttrStatement(seg.getAttr("maxToken"));coder.packText(`,`);coder.newLine();
				coder.packText(`temperature:`);this.genAttrStatement(seg.getAttr("temperature"));coder.packText(`,`);coder.newLine();
				coder.packText(`topP:${seg.getAttrVal("topP")},`);coder.newLine();
				coder.packText(`fqcP:${seg.getAttrVal("fqcP")},`);coder.newLine();
				coder.packText(`prcP:${seg.getAttrVal("prcP")},`);coder.newLine();
				coder.packText(`secret:`);this.genAttrStatement(seg.getAttr("secret"));coder.packText(`,`);coder.newLine();
				if(formatDefAttr){
					let schemaDef;
					formatDefAttr=VFACT.getEditUITemplate(formatDefAttr.val);
					if(formatDefAttr){
						schemaDef=this.genJSONFormat(formatDefAttr);
						if(schemaDef){
							coder.packText(`responseFormat:`);this.genJSONObjectSeg(schemaDef);coder.maybeNewLine();
						}
					}else{
						coder.packText(`responseFormat:`);this.genAttrStatement(seg.getAttr("responseFormat"));coder.packText(`,`);coder.newLine();
					}
					
				}else{
					coder.packText(`responseFormat:`);this.genAttrStatement(seg.getAttr("responseFormat"));coder.packText(`,`);coder.newLine();
				}
				if(apiFiles.length>0){
					coder.packText(`apis:${segName}.apis,`);coder.newLine();
					if(parallelFunction){
						coder.packText(`parallelFunction:true,`);coder.newLine();
					}
				}
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`};`);
			coder.newLine();
			
			if(shareChatName){
				coder.packText(`let chatMem=context["${shareChatName}"]||[];`);coder.newLine();
			}else{
				coder.packText(`let chatMem=${segName}.messages`);coder.newLine();
			}
			
			coder.packText(`let seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(seed!==undefined){opts.seed=seed;}`);coder.newLine();

			coder.packText(`let messages=[`);
			coder.indentMore();
			coder.newLine();
			{
				let list,i,n,attr;
				//System message:
				coder.packText(`{role:"system",content:`);this.genAttrStatement(seg.getAttr("system"));coder.packText(`},`);coder.newLine();
				list=seg.getAttr("messages").attrList;
				n=list.length;
				for(i=0;i<n;i++){
					attr=list[i];
					coder.packText(`{role:"${attr.getAttrVal("role")}",content:`);this.genAttrStatement(attr.getAttr("content"));coder.packText(`},`);coder.newLine();
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`];`);
			coder.maybeNewLine();
			if(seg.getAttrVal("keepChat")){
				coder.packText(`messages.push(...chatMem);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PrePrompt");
			coder.packText(`prompt=`);
			if(prefixTxt){
				this.genAttrStatement(seg.getAttr("inputPrefix"));
				coder.packText(`+"\\n"+`);
			}
			this.genAttrStatement(seg.getAttr("prompt"));
			if(postfixTxt){
				coder.packText(`+"\\n"`);
				this.genAttrStatement(seg.getAttr("inputPostfix"));
			}
			coder.packText(`;`);coder.newLine();
			coder.packText(`if(prompt!==null){`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if(typeof(prompt)!=="string"){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`prompt=JSON.stringify(prompt,null,"\t");`);
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
				coder.packText(`let msg={role:"user",content:prompt};`);
				packExtraCodes(coder,seg,"FilterMessage");
				coder.packText(`messages.push(msg);`);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PreCall");
			if(allowCheat){
				coder.packText(`result=${segName}.cheats[prompt]||${segName}.cheats[input]||${segName}.cheats[""+chatMem.length]||${segName}.cheats[""];`);
				coder.newLine();
				coder.packText(`if(!result){`);
				coder.indentMore();
				coder.newLine();
				{
					if(useStream){
						if(hasCode){
							coder.packText(`result=(result===undefined)?(await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)):result;`);coder.newLine();
						}else{
							coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true);`);coder.newLine();
						}
					}else{
						if(hasCode){
							coder.packText(`result=(result===undefined)?(await session.makeAICall("${segName}@"+agentURL,opts,messages,true)):result;`);coder.newLine();
						}else{
							coder.packText(`result=await session.makeAICall("${segName}@"+agentURL,opts,messages,true);`);coder.newLine();
						}
					}
				}
				coder.indentLess();
				coder.newLine();
				coder.packText(`}`);
				coder.newLine();
			}else{
				if(useStream){
					if(hasCode){
						coder.packText(`result=(result===null)?(await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)):result;`);coder.newLine();
					}else{
						coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true);`);coder.newLine();
					}
				}else{
					if(hasCode){
						coder.packText(`result=(result===null)?(await session.makeAICall("${segName}@"+agentURL,opts,messages,true)):result;`);coder.newLine();
					}else{
						coder.packText(`result=await session.makeAICall("${segName}@"+agentURL,opts,messages,true);`);coder.newLine();
					}
				}
			}
			if(keepNum>0){
				packExtraCodes(coder,seg,"PostLLM");
				coder.packText(`chatMem.push({role:"user",content:prompt});`);coder.newLine();
				coder.packText(`chatMem.push({role:"assistant",content:result});`);coder.newLine();
				if(keepNum<200){
					coder.packText(`if(chatMem.length>${keepNum}){`);
					coder.indentMore();
					coder.newLine();
					{
						coder.packText(`let removedMsgs=chatMem.splice(0,${clearNum});`);
						packExtraCodes(coder,seg,"PostClear");
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
			}
			if(responseFormat==="json_object"){
				coder.maybeNewLine();
				coder.packText(`result=trimJSON(result);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCall");
			//Result:
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		if(keepNum>0){
			if(shareChatName){
				coder.packText(`context["${shareChatName}"]=context["${shareChatName}"]||[];`);coder.newLine();
			}else{
				coder.packText(`${segName}.messages=[];`);coder.newLine();
			}
		}
		if(apiFiles.length>0){//TODO: Choose in funcation-call or toolCalls:
			let i,n,path,basePath;
			n=apiFiles.length;
			coder.packText(`${segName}.apis=await session.loadAISegAPIs([`);
			for(i=0;i<n;i++){
				path=apiFiles[i].val;
				if(path){
					if(!path.startsWith("/@")){
						path=pathLib.relative(docPath,path);
						if(path[0]!=="."&&path[0]!=="/"){
							path="./"+path;
						}
					}
					coder.packText(`"${path}",`);
				}
			}
			coder.eatPreComa();
			coder.packText(`]);`);
			coder.newLine();
		}
		if(allowCheat){
			coder.packText(`${segName}.cheats={`);
			coder.indentMore();
			coder.newLine();
			{
				let cheat;
				let list=seg.getAttr("GPTCheats").attrList;
				for(cheat of list){
					coder.maybeNewLine();
					coder.packText(`${JSON.stringify(cheat.getAttrVal("prompt"))}:${JSON.stringify(cheat.getAttrVal("reply"))},`);
				}
				coder.eatPreComa();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`};`);
			coder.newLine();
		}
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_aiVision=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlet=seg.outlet;
		let secret=seg.getAttrVal("secret");
		let hasCode=seg.getAttrVal("codes");
		let imageAttr=seg.getAttr("image");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let prompt;`);coder.newLine();
			if(hasCode){
				coder.packText(`let result=null;`);coder.newLine();
			}else{
				coder.packText(`let result;`);coder.newLine();
			}
			packExtraCodes(coder,seg,"Input");coder.newLine();
			coder.packText(`let imageURL=`);this.genAttrStatement(imageAttr);coder.newLine();
			//Call options:
			coder.packText(`let opts={`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`mode:`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`,`);coder.newLine();
				coder.packText(`maxToken:`);this.genAttrStatement(seg.getAttr("maxToken"));coder.packText(`,`);coder.newLine();
				coder.packText(`temperature:`);this.genAttrStatement(seg.getAttr("temperature"));coder.packText(`,`);coder.newLine();
				coder.packText(`topP:${seg.getAttrVal("topP")},`);coder.newLine();
				coder.packText(`fqcP:${seg.getAttrVal("fqcP")},`);coder.newLine();
				coder.packText(`prcP:${seg.getAttrVal("prcP")},`);coder.newLine();
				coder.packText(`secret:`);this.genAttrStatement(seg.getAttr("secret"));coder.packText(`,`);coder.newLine();
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`};`);
			coder.newLine();

			coder.packText(`let seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(seed!==undefined){opts.seed=seed;}`);coder.newLine();

			coder.packText(`let messages=[];`);
			coder.maybeNewLine();
			packExtraCodes(coder,seg,"PrePrompt");
			coder.packText(`prompt=`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(prompt!==null){`);
			coder.indentMore();
			coder.newLine();
			if(imageAttr && imageAttr.valText){
				coder.packText(`if(!imageURL.startsWith("data:")){`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`let ext=pathLib.extname(imageURL)`);coder.newLine();
					coder.packText(`let buf=await (await fetch(imageURL)).arrayBuffer();`);coder.newLine();
					coder.packText(`buf=Base64.encode(buf)`);coder.newLine();
					coder.packText(`switch(ext){`);
					coder.indentMore();
					coder.newLine();
					{
						coder.packText(`case ".jpg":`);
						coder.indentMore();
						coder.newLine();
							coder.packText(`imageURL="data:image/jpeg;base64,"+buf;`);coder.newLine();
							coder.packText(`break;`);
						coder.indentLess();
						coder.newLine();
						coder.packText(`case ".png":`);
						coder.indentMore();
						coder.newLine();
							coder.packText(`imageURL="data:image/png;base64,"+buf;`);coder.newLine();
							coder.packText(`break;`);
						coder.indentLess();
						coder.newLine();
						coder.packText(`default:`);
						coder.indentMore();
						coder.newLine();
							coder.packText(`throw Error("Wrong imageURL extname: "+ext);`);coder.newLine();
							coder.packText(`break;`);
						coder.indentLess();
						coder.newLine();
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);
					coder.maybeNewLine();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
				coder.packText(`messages.push({role:"user",content:[{type:"text",text:prompt},{type:"image_url","image_url":{"url":imageURL}}]});`);coder.newLine();
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}`);
			coder.newLine();
			packExtraCodes(coder,seg,"PreCall");
			if(hasCode){
				coder.packText(`result=(result===null)?(await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)):result;`);coder.newLine();
			}else{
				coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCall");
			//Result:
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_aiBot=function(seg){
		let resultVal=seg.getAttr("result");
		let sourcePathTxt=seg.getAttr("source").valText;
		let isCodeSource=sourcePathTxt[0]==="#";
		let sourcePath=seg.getAttrVal("source")||"";
		let agentNodeValTxt=seg.getAttrValText("agentNode");
		let agentNodeVal=seg.getAttrVal("agentNode");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let secret=seg.getAttrVal("secret");
		let outlets=seg.outletsList;
		let asklet=outlets[0];
		let askSegName="null";
		if(asklet){
			let nextSeg=asklet.getLinkedSeg();
			if(nextSeg){
				askSegName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
				askSegName=(askSegName &&varNameRegex.test(askSegName))?askSegName:("SEG"+nextSeg.jaxId);
			}
		}
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);coder.newLine();
			coder.packText(`let arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.packText(`;`);coder.newLine();
			coder.packText(`let agentNode=(`);this.genAttrStatement(seg.getAttr("agentNode"));coder.packText(`)||null;`);coder.newLine();
			if(agentNodeValTxt&&(agentNodeValTxt[0]==="#" || agentNodeVal)){
				coder.packText(`let sourcePath=`);this.genAttrStatement(seg.getAttr("source"));coder.packText(`;`);coder.newLine();
			}else if(this.agentInBrowser){
				if(isCodeSource){
					coder.packText(`let sourcePath=(`);this.genAttrStatement(seg.getAttr("source"));coder.packText(`)||"";`);coder.newLine();
					coder.packText(`sourcePath=sourcePath[0]==="/"?sourcePath:pathLib.joinTabOSURL(basePath,"../"+sourcePath);`);coder.newLine();
				}else{
					coder.packText(sourcePath[0]==="/"?`let sourcePath="${sourcePath}"`:`let sourcePath=pathLib.joinTabOSURL(basePath,"${sourcePath}");`);coder.newLine();
				}
			}else{
				if(isCodeSource){
					coder.packText(`let sourcePath=(`);this.genAttrStatement(seg.getAttr("source"));coder.packText(`)||"";`);coder.newLine();
					coder.packText(`sourcePath=sourcePath[0]==="/"?sourcePath:pathLib.join(basePath,"../"+sourcePath);`);
				}else{
					coder.packText(sourcePath[0]==="/"?`let sourcePath="${sourcePath}"`:`let sourcePath=pathLib.join(basePath,"${sourcePath}");`);coder.newLine();
				}
			}
			coder.packText(`let opts={secrect:${secret},fromAgent:$agent,askUpwardSeg:${askSegName}};`);coder.newLine();
			genProcessSeg.call(this,seg.getAttr("process"));
			packExtraCodes(coder,seg,"Input");
			coder.packText(`result= await session.callAgent(agentNode,sourcePath,arg,opts);`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret});`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg,"Output");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_MCP=function(seg){
		let resultVal=seg.getAttr("result");
		let toolTxt=seg.getAttr("tool").valText;
		let isCodeSource=toolTxt[0]==="#";
		let toolPath=seg.getAttrVal("tool")||"";
		let serverValTxt=seg.getAttrValText("server");
		let serverAttr=seg.getAttr("server");
		let serverVal=seg.getAttrVal("server");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let askSegName="null";
		let params = {tool_name:toolPath, tool_args:seg.getAttr("argument")};
		if(!serverVal.endsWith("/")) serverVal = serverVal + "/";
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);coder.newLine();
			coder.packText(`let arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.packText(`;`);coder.newLine();
			coder.packText(`let server=(`);this.genAttrStatement(serverAttr);coder.packText(`)||null;`);coder.newLine();
			coder.packText(`let tool=`);this.genAttrStatement(seg.getAttr("tool"));coder.packText(`;`);coder.newLine();
			coder.packText(`let webFetch=(await import("/@tabos/utils/webAPI.js")).webFetch;`);coder.newLine();

			packExtraCodes(coder,seg,"Input");
			coder.packText(`result= await webFetch("${serverVal + "execute"}",{method: 'POST',headers: {'Content-Type': 'application/json'},body:{tool_name:"${toolPath.slice(1)}", tool_args:arg}})`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret});`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg,"Output");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_AutoAPI=function(seg){
		let resultVal=seg.getAttr("result");
		let toolTxt=seg.getAttr("tool").valText;
		let isCodeSource=toolTxt[0]==="#";
		let toolPath=seg.getAttrVal("tool")||"";
		let serverValTxt=seg.getAttrValText("server");
		let serverAttr=seg.getAttr("server");
		let serverVal=seg.getAttrVal("server");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let askSegName="null";
		if(!serverVal.endsWith("/")) serverVal = serverVal + "/";
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);coder.newLine();
			coder.packText(`let arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.packText(`;`);coder.newLine();
			coder.packText(`let server=(`);this.genAttrStatement(serverAttr);coder.packText(`)||null;`);coder.newLine();
			coder.packText(`let tool=`);this.genAttrStatement(seg.getAttr("tool"));coder.packText(`;`);coder.newLine();
			coder.packText(`let webFetch=(await import("/@tabos/utils/webAPI.js")).webFetch;`);coder.newLine();

			packExtraCodes(coder,seg,"Input");
			coder.packText(`result= await webFetch(\`${serverVal + "dynamic"}`);coder.packText("${tool}`");coder.packText(`,{method: 'POST',headers: {'Content-Type': 'application/json'},body: arg});`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret});`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg,"Output");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_brunch=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlets=seg.outletsList;
		let outlet,condition;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result=input;`);coder.newLine();
			packExtraCodes(coder,seg,"Start");
			for(outlet of outlets){
				condition=outlet.getAttr("condition");
				if(condition){
					condition=condition.valText;
				}
				if(condition){
					if(condition[0]==="#"){
						let pos;
						pos=condition.lastIndexOf("#>");
						if(pos>0){
							condition=condition.substring(pos+2);
						}else{
							condition=condition.substring(1);
						}
					}
					coder.packText(`if(${condition}){`);
				}else{
					coder.packText(`if(input==="${outlet.idVal.val}"){`);
				}
				coder.indentMore();
				coder.newLine();
				{
					if(outlet.getAttrValText("output")){
						coder.packText(`let output=`);this.genAttrStatement(outlet.getAttr("output")||outlet.getAttr("output"));coder.packText(`;`);coder.newLine();
						packExtraCodes(coder,outlet);
						packResult(coder,seg,outlet,"output");
						this.packUpdateContext(coder,outlet);
						this.packUpdateGlobal(coder,outlet);
					}else{
						packExtraCodes(coder,outlet);
						packResult(coder,seg,outlet,"input");
						this.packUpdateContext(coder,outlet);
						this.packUpdateGlobal(coder,outlet);
					}
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			outlet=seg.outlet;
			if(outlet.getAttrValText("output")){
				coder.packText(`result=`);this.genAttrStatement(outlet.getAttr("output"));coder.packText(`;`);coder.newLine();
			}
			packExtraCodes(coder,seg,"Post");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_sleep=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlet;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let time=`);this.genAttrStatement(seg.getAttr("time"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`await sleep(time);`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_summary=function(seg){
		let format=seg.getAttr("format").val;
		let coder=this.coder;
		let segName=seg.idVal.val;
		let asyncMode=seg.getAttrVal("async");
		let keyAttr=seg.getAttrValText("key");
		let outlets=seg.outletsList;
		let outlet,isSurvey,hasCode,nextSeg;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let sumVO={}`);coder.newLine();
			if(asyncMode){
				coder.packText(`let pmsList=[]`);coder.newLine();
			}
			coder.packText(`let result;`);coder.newLine();
			coder.packText(`let key;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			for(outlet of outlets){
				isSurvey=!!outlet.getAttr("survey").val;
				hasCode=outlet.getAttrVal("codes");
				nextSeg=outlet.getLinkedSeg();
				if(nextSeg){
					if(asyncMode){
						coder.packText(`pmsList.push(`);
						this.packSegRunWithAttr(coder,seg,outlet,outlet.getAttr("input"),true);
						coder.packText(`.then((r)=>{`);
						coder.indentMore();
						coder.newLine();
						{
							if(isSurvey){
								coder.packText(`key=`);this.genAttrStatement(outlet.getAttr("key"));coder.packText(`||${JSON.stringify(outlet.idVal.val)};`);coder.newLine();
								coder.packText(`sumVO[key]=r;`);
								//coder.packText(`sumVO["${outlet.idVal.val}"]=r;`);
							}
							if(hasCode){
								packExtraCodes(coder,outlet,"PostCodes");
							}
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}));`);
						coder.newLine();
					}else{
						if(isSurvey){
							coder.packText(`key=`);this.genAttrStatement(outlet.getAttr("key"));coder.packText(`||${JSON.stringify(outlet.idVal.val)};`);coder.newLine();
							coder.packText(`sumVO[key]=`);
						}
						this.packSegRunWithAttr(coder,seg,outlet,outlet.getAttr("input"));
						coder.packText(`;`);coder.newLine();
						if(hasCode){
							packExtraCodes(coder,outlet,"PostCodes");
						}
					}
				}
			}
		}
		if(asyncMode){
			coder.packText(`await Promise.all(pmsList);`);coder.newLine();
		}
		packExtraCodes(coder,seg,"PostCodes");
		if(format==="Text"){
			coder.packText(`result="";`);coder.newLine();
			coder.packText(`for(let name in sumVO){result+=name+":"+sumVO[name]+"\\n"}`);coder.newLine();
		}else if(format==="Object"){
			coder.packText(`result=sumVO;`);coder.newLine();
		}else{
			coder.packText(`result=JSON.stringify(sumVO,null,"\\t");`);coder.newLine();
		}
		packExtraCodes(coder,seg);
		this.packUpdateContext(coder,seg);
		this.packUpdateGlobal(coder,seg);
		packResult(coder,seg,seg.outlet,"result");
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_loopArray=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let method=seg.getAttrVal("method");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			switch(method){
				default:{
					coder.packText(`let result=input;`);coder.newLine();
					break;
				}
				case "asyncForEach":{
					coder.packText(`let result;`);coder.newLine();
					coder.packText(`let tasks=[];`);coder.newLine();
					break;
				}
				case "findIndex":
				case "find":{
					coder.packText(`let result;`);coder.newLine();
					break;
				}
				case "allOf":{
					coder.packText(`let result=true;`);coder.newLine();
					break;
				}
				case "anyOf":{
					coder.packText(`let result=false;`);coder.newLine();
					break;
				}
				case "anyOf":{
					coder.packText(`let result=false;`);coder.newLine();
					break;
				}
				case "map":
				case "filter":{
					coder.packText(`let result=[];`);coder.newLine();
					break;
				}
			}
			coder.packText(`let list=`);this.genAttrStatement(seg.getAttr("loopArray"));coder.packText(`;`);coder.newLine();
			coder.packText(`let i,n,item,loopR;`);coder.newLine();
			packExtraCodes(coder,seg,"PreLoop");
			coder.packText(`n=list.length;`);coder.newLine();
			coder.packText(`for(i=0;i<n;i++){`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`item=list[i];`);coder.newLine();
				packExtraCodes(coder,seg,"InLoopPre");
				switch(method){
					case "forEach":{
						coder.packText(`loopR=`);
						packSegRun(coder,seg,seg.outlet,"item");coder.newLine();
						coder.packText(`if(loopR==="break"){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`break;`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();coder.packText(`}`);
						break;
					}
					case "asyncForEach":{
						coder.packText("tasks.push(");packSegRun(coder,seg,seg.outlet,"item",true);coder.packText(");");coder.newLine();
						break;
					}
					case "find":{
						coder.packText(`if(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`){`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=item;`);coder.newLine();
							coder.packText(`break;`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					}
					case "findIndex":{
						coder.packText(`if(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`){`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=i;`);coder.newLine();
							coder.packText(`break;`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					}
					case "allOf":{
						coder.packText(`if(!(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`)){`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=false;`);coder.newLine();
							coder.packText(`break;`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					}
					case "anyOf":{
						coder.packText(`if(!(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`)){`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=true;`);coder.newLine();
							coder.packText(`break;`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					}
					case "map":{
						coder.packText(`result.push(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`);`);coder.newLine();
						break;
					}
					case "filter":{
						coder.packText(`if(`);
						packSegRun(coder,seg,seg.outlet,"item");
						coder.packText(`){`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result.push(item);`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					}
				}
				packExtraCodes(coder,seg,"InLoopPost");
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);
			coder.newLine();
			switch(method){
				case "asyncForEach":{
					coder.packText(`result=await Promise.all(tasks);`);coder.newLine();
					break;
				}
			}
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.catchlet,"result",false);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_output=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let roleAttr=seg.getAttr("role");
		let contentAttr=seg.getAttr("text");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let channel=`);this.genAttrStatement(seg.getAttr("channel"));coder.packText(`;`);coder.newLine();
			coder.packText(`let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};`);coder.newLine();
			coder.packText(`let role=`);this.genAttrStatement(roleAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let content=`);this.genAttrStatement(contentAttr);coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`session.addChatText(role,content,opts);`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_image=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let roleAttr=seg.getAttr("role");
		let textAttr=seg.getAttr("text");
		let imageAttr=seg.getAttr("image");
		let limitAttr=seg.getAttr("sizeLimit");
		let formatTag=seg.getAttrVal("format");
		let codeDraw=seg.getAttrVal("codeDraw");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let role=`);this.genAttrStatement(roleAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let content=`);this.genAttrStatement(textAttr);coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(!limitAttr.valText || limitAttr.valText==="0"){
				coder.packText(`let vo={image:`);this.genAttrStatement(imageAttr);coder.packText(`};`);coder.newLine();
				packExtraCodes(coder,seg,"Options");
				coder.packText(`session.addChatText(role,content,vo);`);coder.newLine();
			}
			if(limitAttr.valText && limitAttr.valText!=="0"){
				coder.packText(`//Limit size:`);coder.newLine();
				coder.packText(`let callback =null;`);coder.newLine();
				coder.packText(`let pms=new Promise((resolve)=>{callback=resolve;});`);coder.newLine();
				coder.packText(`{`);coder.newLine();
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`let maxSize =`);this.genAttrStatement(limitAttr);coder.packText(`;`);coder.newLine();
					coder.packText(`let img = new Image();`);coder.newLine();
	        	    coder.packText(`img.crossOrigin = "Anonymous";`);coder.newLine();
    		        coder.packText(`img.src = `);this.genAttrStatement(imageAttr);coder.packText(`;`);coder.newLine();
		            coder.packText(`img.onload = function () {`);
					coder.indentMore();
					coder.newLine();
					{					
						coder.packText(`let imgW = img.width;`);coder.newLine();
						coder.packText(`let imgH = img.height;`);coder.newLine();
						coder.packText(`let scale = maxSize/(imgW>imgH?imgW:imgH);`);coder.newLine();
						if(codeDraw){
							coder.packText(`{`);
						}else{
							coder.packText(`if(scale<1){`);
						}
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`let canvas = document.createElement("canvas");`);coder.newLine();
							coder.packText(`let context = canvas.getContext("2d");`);coder.newLine();
							coder.packText(`canvas.width = Math.floor(img.width*scale);`);coder.newLine();
							coder.packText(`canvas.height = Math.floor(img.height*scale);`);coder.newLine();
							coder.packText(`context.drawImage(img, 0, 0,canvas.width,canvas.height);`);coder.newLine();
							if(codeDraw){
								packExtraCodes(coder,seg,"Draw",true);
							}
							coder.packText(`result = canvas.toDataURL("${formatTag}");`);coder.newLine();

						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`}`);
						coder.maybeNewLine();
						coder.packText(`callback();`);coder.newLine();
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`};`);
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
				coder.packText(`await pms;`);coder.newLine();
				coder.packText(`let vo={image:result};`);coder.newLine();
				packExtraCodes(coder,seg,"Options");
				coder.packText(`session.addChatText(role,content,vo);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askChat=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let tip=(`);this.genAttrStatement(seg.getAttr("tip"));coder.packText(`);`);coder.newLine();
			coder.packText(`let tipRole=(`);this.genAttrStatement(seg.getAttr("tipRole"));coder.packText(`);`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`);`);coder.newLine();
			coder.packText(`let allowFile=(`);this.genAttrStatement(seg.getAttr("file"));coder.packText(`)||false;`);coder.newLine();
			coder.packText(`let askUpward=(`);this.genAttrStatement(seg.getAttr("askUpward"));coder.packText(`);`);coder.newLine();
			coder.packText(`let text=(`);this.genAttrStatement(seg.getAttr("text"));;coder.packText(`);`);coder.newLine();
			coder.packText(`let result="";`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`if(askUpward && tip){`);coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await session.askUpward($agent,tip);`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}else{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if(tip){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`session.addChatText(tipRole,tip);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
				coder.packText(`result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile});`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			
			//coder.packText(`result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile});`);coder.newLine();
			if(seg.getAttrVal("showText")){
				coder.packText(`if(typeof(result)==="string"){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`session.addChatText("user",result);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}else if(result.assets && result.prompt){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`session.addChatText("user",\`\${result.prompt}\\n- - -\\n\${result.assets.join("\\n- - -\\n")}\`,{render:true});`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}else{`);coder.indentMore();coder.newLine();
				{
					coder.packText(`session.addChatText("user",result.text||result.prompt||result);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askText=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let inputType=(`);this.genAttrStatement(seg.getAttr("inputType"));coder.packText(`)||"text";`);coder.newLine();
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`);`);coder.newLine();
			coder.packText(`let text=(`);this.genAttrStatement(seg.getAttr("text"));;coder.packText(`);`);coder.newLine();
			coder.packText(`let resultText="";`);coder.newLine();
			coder.packText(`let result="";`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`[resultText,result]=await session.askUserRaw({type:"input",inputType:inputType,prompt:prompt,placeholder:placeholder,text:text});`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askConfirm=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlets=seg.outletsList;
		let outlet,resultVal;
		let withChat=seg.getAttrVal("withChat");
		let silentOutlet=seg.getAttrVal("silentOutlet");
		FindOutlet:{
			let i,n;
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				if(outlet && outlet.getAttrVal("id")==silentOutlet){
					silentOutlet=outlet;
					break FindOutlet;
				}
			}
			silentOutlet=outlets[0];
		}
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			if(silentOutlet){
				coder.packText(`let silent=`);this.genAttrStatement(seg.getAttr("silent"));coder.packText(`;`);coder.newLine();
			}
			coder.packText(`let countdown=`);this.genAttrStatement(seg.getAttr("countdown"));coder.packText(`;`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`)||null;`);coder.newLine();
			outlet=outlets[0];
			if(outlet){
				coder.packText(`let button1=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`)||"OK";`);coder.newLine();
			}else{
				coder.packText(`let button1="OK";`);coder.newLine();
			}
			outlet=outlets[1];
			if(outlet){
				coder.packText(`let button2=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`)||"Cancel";`);coder.newLine();
			}else{
				coder.packText(`let button2="";`);coder.newLine();
			}
			outlet=outlets[2];
			if(outlet){
				coder.packText(`let button3=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`)||"";`);coder.newLine();
			}else{
				coder.packText(`let button3="";`);coder.newLine();
			}
			coder.packText(`let result="";`);coder.newLine();
			coder.packText(`let value=0;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(silentOutlet){
				outlet=silentOutlet;
				coder.packText(`if(silent){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`result=`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`;`);coder.newLine();
					packExtraCodes(coder,outlet,"Silent");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			
			coder.packText(`[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:${withChat},placeholder:placeholder});`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			outlet=outlets[0];
			if(outlet){
				coder.packText(`if(value===1){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`)||result;`);coder.newLine();
					packExtraCodes(coder,outlet,"Btn1");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			
			outlet=outlets[2];
			if(outlet){
				coder.packText(`if(value===2){`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`)||result;`);coder.newLine();
					packExtraCodes(coder,outlet,"Btn3");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
			}
			
			outlet=outlets[1];
			if(outlet){
				coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`)||result;`);coder.newLine();
				packExtraCodes(coder,outlet,"Btn2");
				this.packUpdateContext(coder,outlet);
				this.packUpdateGlobal(coder,outlet);
				packResult(coder,seg,outlet,"result");
				coder.newLine();
			}
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askMenu=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlets=seg.outletsList;
		let isMulti=seg.getAttrVal("multi");
		let outlet,i,n,nextSeg,defaultOutlet;
		let silentOutlet=seg.getAttrVal("silentOutlet");
		FindOutlet:{
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				if(outlet && outlet.getAttrVal("id")==silentOutlet){
					silentOutlet=outlet;
					break FindOutlet;
				}
			}
			silentOutlet=outlets[0];
		}
		defaultOutlet=null;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			coder.packText(`let countdown=`);this.genAttrStatement(seg.getAttr("countdown"));coder.packText(`;`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`)||null;`);coder.newLine();
			coder.packText(`let withChat=`);this.genAttrStatement(seg.getAttr("withChat"));coder.packText(`;`);coder.newLine();
			if(silentOutlet){
				coder.packText(`let silent=`);this.genAttrStatement(seg.getAttr("silent"));coder.packText(`;`);coder.newLine();
			}
			coder.packText(`let items=[`);coder.newLine();coder.indentMore();
			{
				let iconAttr,emojiAttr;
				n=outlets.length;
				for(i=0;i<n;i++){
					outlet=outlets[i];
					coder.maybeNewLine();
					emojiAttr=outlet.getAttr("emoji");
					iconAttr=outlet.getAttr("icon");
					if(!outlet.getAttrValText("text")){
						defaultOutlet=outlet;
					}else{
						if(emojiAttr && emojiAttr.val){
							coder.packText(`{emoji:`);this.genAttrStatement(emojiAttr);coder.packText(`,text:`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,code:${i}},`);
						}else if(iconAttr){
							coder.packText(`{icon:`);this.genAttrStatement(iconAttr);coder.packText(`||"/~/-tabos/shared/assets/dot.svg",text:`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,code:${i}},`);
						}else{
							coder.packText(`{icon:"/~/-tabos/shared/assets/dot.svg",text:`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,code:${i}},`);
						}
					}
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`];`);
			coder.newLine();

			coder.packText(`let result="";`);coder.newLine();
			coder.packText(`let item=null;`);coder.newLine();
			//coder.packText(`let multi=`);this.genAttrStatement(multiAttr);coder.packText(`;`);coder.newLine();
			coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(silentOutlet){
				outlet=silentOutlet;
				coder.packText(`if(silent){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`result=`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`;`);coder.newLine();
					packExtraCodes(coder,outlet,"Silent");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			coder.packText(`[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:${!!isMulti},items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			if(isMulti){
				if(defaultOutlet){
					coder.maybeNewLine();
					packExtraCodes(coder,seg,"FinCodes");
					this.packUpdateContext(coder,defaultOutlet);
					this.packUpdateGlobal(coder,defaultOutlet);
					packResult(coder,seg,defaultOutlet,"result");
				}else{
					for(i=0;i<n;i++){
						outlet=outlets[i];
						nextSeg=outlet.getLinkedSeg();
						if(nextSeg){
							coder.maybeNewLine();
							packExtraCodes(coder,seg,"FinCodes");
							this.packUpdateContext(coder,outlet);
							this.packUpdateGlobal(coder,outlet);
							packResult(coder,seg,outlet,"result");
							break;
						}
					}
				}
			}else{
				coder.maybeNewLine();
				coder.packText("if(typeof(item)==='string'){");coder.newLine();coder.indentMore();
				{
					outlet=seg.getAttr("outlet");
					coder.packText(`result=item;`);coder.newLine();
					packExtraCodes(coder,outlet,"ChatInput");
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();//coder.packText(`}`);coder.newLine();
				for(i=0;i<n;i++){
					outlet=outlets[i];
					if(outlet===defaultOutlet){
						continue;
					}
					coder.maybeNewLine();
					coder.packText(`}else if(item.code===${i}){`);coder.indentMore();coder.newLine();
					{
						if(outlet.getAttrValText("result")){
							coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`);`);coder.newLine();
						}
						packExtraCodes(coder,outlet,"");
						this.packUpdateContext(coder,outlet);
						this.packUpdateGlobal(coder,outlet);
						packResult(coder,seg,outlets[i],"result");
					}
					coder.indentLess();coder.maybeNewLine();
				}
				coder.packText(`}`);coder.newLine();
				packExtraCodes(coder,seg,"FinCodes");
				if(defaultOutlet){
					this.packUpdateContext(coder,defaultOutlet);
					this.packUpdateGlobal(coder,defaultOutlet);
					packResult(coder,seg,defaultOutlet,"result");
				}else{
					outlet=seg.getAttr("outlet");
					packExtraCodes(coder,outlet,"DefaultOutlet");
					packResult(coder,seg,outlet,"result");
				}
			}
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_askAudio=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`)||null;`);coder.newLine();
			coder.packText(`let result="";`);coder.newLine();
			coder.packText(`let audioData=null;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`[result,audioData]=await session.askUserRaw({type:"audio",prompt:prompt});`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"audioData");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askUIBlock=function(seg){
		let resultVal=seg.getAttr("result");
		let roleAttr=seg.getAttr("role");
		let sourcePath=seg.getAttr("source").val;
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result,resultText;`);
			coder.maybeNewLine();
			coder.packText(`let role=`);this.genAttrStatement(roleAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let md=await import("${sourcePath}");`);coder.newLine();
			coder.packText(`let func=md.default;`);coder.newLine();
			coder.packText(`let text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
			
			coder.packText(`[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(self,input),input:input,role:role});`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg);
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askUIDlg=function(seg){
		let resultVal=seg.getAttr("result");
		let sourcePath=seg.getAttr("source").val;
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);
			coder.maybeNewLine();
			coder.packText(`let role=`);this.genAttrStatement(seg.getAttr("role"));coder.packText(`;`);coder.newLine();
			coder.packText(`let tip=`);this.genAttrStatement(seg.getAttr("tip"));coder.packText(`;`);coder.newLine();
			coder.packText(`let showResult=`);this.genAttrStatement(seg.getAttr("showResult"));coder.packText(`;`);coder.newLine();
			coder.packText(`let dlgVO=`);this.genAttrStatement(seg.getAttr("callArg"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"Pre");
			coder.packText(`result= await session.askUserDlg({"dlgPath":"${sourcePath}","arg":dlgVO,"role":role,tip:tip,showResult:showResult});`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg);
			this.packUpdateContext(coder,seg,"Post");
			this.packUpdateGlobal(coder,seg,"Post");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askUIView=function(seg){
		let resultVal=seg.getAttr("result");
		let sourcePath=seg.getAttr("source").val;
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
			if(sourcePath[0]==="."){
				sourcePath=`(pathLib.join(basePath,"${sourcePath}"))`;
			}else{
				sourcePath=`"${sourcePath}"`;
			}
		}
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result;`);
			coder.maybeNewLine();
			coder.packText(`let pkg=`);this.genAttrStatement(seg.getAttr("package"));coder.packText(`;`);coder.newLine();
			coder.packText(`let withChat=`);this.genAttrStatement(seg.getAttr("withChat"));coder.packText(`;`);coder.newLine();
			coder.packText(`let showChats=`);this.genAttrStatement(seg.getAttr("showChats"));coder.packText(`;`);coder.newLine();
			coder.packText(`let showArg=`);this.genAttrStatement(seg.getAttr("callArg"));coder.packText(`;`);coder.newLine();
			coder.packText(`let allowFile=`);this.genAttrStatement(seg.getAttr("file"));coder.packText(`;`);coder.newLine();
			coder.packText(`let tip=`);this.genAttrStatement(seg.getAttr("tip"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"Pre");
			coder.packText(`result= await session.askUserView({"ui":${sourcePath},"args":showArg,"options":{"package":pkg,"withChat":withChat,"showChats":showChats,"tip":tip,chatOpts:{"allowFile":allowFile}}});`);coder.newLine();
			{
				let outlet,outlets,condition;
				outlets=seg.outletsList;
				packExtraCodes(coder,seg,"Command");
				coder.packText(`if(result && result.command){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`let $command=result.command;`);coder.newLine();
					for(outlet of outlets){
						condition=outlet.getAttr("condition");
						if(condition){
							condition=condition.valText;
						}
						if(condition){
							if(condition[0]==="#"){
								let pos;
								pos=condition.lastIndexOf("#>");
								if(pos>0){
									condition=condition.substring(pos+2);
								}else{
									condition=condition.substring(1);
								}
							}
							coder.packText(`if($command==="${condition}"){`);
						}else{
							coder.packText(`if($command==="${outlet.idVal.val}"){`);
						}
						coder.indentMore();coder.newLine();
						{
							if(outlet.getAttrValText("output")){
								coder.packText(`let output=`);this.genAttrStatement(outlet.getAttr("output")||outlet.getAttr("output"));coder.packText(`;`);coder.newLine();
								packExtraCodes(coder,outlet);
								packResult(coder,seg,outlet,"output");
								this.packUpdateContext(coder,outlet);
								this.packUpdateGlobal(coder,outlet);
							}else{
								packExtraCodes(coder,outlet);
								packResult(coder,seg,outlet,"result");
								this.packUpdateContext(coder,outlet);
								this.packUpdateGlobal(coder,outlet);
							}
						}
						coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
					}
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			}
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			packExtraCodes(coder,seg);
			this.packUpdateContext(coder,seg,"Post");
			this.packUpdateGlobal(coder,seg,"Post");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_aiDraw=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let modeAttr=seg.getAttr("mode");
		let promptAttr=seg.getAttr("prompt");
		let sizeAttr=seg.getAttr("size");
		let labelAttr=seg.getAttr("imgLabel");
		let method=seg.getAttrVal("method");
		let imageAttr=seg.getAttr("image");
		let maskAttr=seg.getAttr("mask");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let callVO=null;`);coder.newLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let revisedPrompt="";`);coder.newLine();
			coder.packText(`let rsp=null;`);coder.newLine();
			coder.packText(`let dataURL=null;`);coder.newLine();
			coder.packText(`let $mode=`);this.genAttrStatement(modeAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let $prompt=`);this.genAttrStatement(promptAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let $size=`);this.genAttrStatement(sizeAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let label=`);this.genAttrStatement(labelAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let $seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $image=`);this.genAttrStatement(imageAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let $mask=`);this.genAttrStatement(maskAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let $background=`);this.genAttrStatement(seg.getAttr("background"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $output_format=`);this.genAttrStatement(seg.getAttr("output_format"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $output_compression=`);this.genAttrStatement(seg.getAttr("output_compression"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $quality=`);this.genAttrStatement(seg.getAttr("quality"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $moderation=`);this.genAttrStatement(seg.getAttr("moderation"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(method==="Variation"){
				coder.packText(`callVO={model:mode,image:imageURL,size:size};`);coder.newLine();
				coder.packText(`if(seed!==undefined){callVO.seed=seed;}`);coder.newLine();
				coder.packText(`rsp=await session.sysCall("AIDrawVariation",callVO,true,100000);`);coder.newLine();
			}else{
				coder.packText(`callVO={model:$mode,image:$image,mask:$mask,prompt:$prompt,seed:$seed,size:$size,background:$background,output_format:$output_format,output_compression:$output_compression,quality:$quality,moderation:$moderation};`);coder.newLine();
				coder.packText(`rsp=await session.sysCall("AIDraw",callVO,true,100000);`);coder.newLine();
			}
			
			//coder.packText(`console.log(rsp)`);coder.newLine();
			coder.packText(`if(rsp.code===200){`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result=rsp.img;`);coder.newLine();
				coder.packText(`revisedPrompt=rsp.revised_prompt;`);coder.newLine();
				coder.packText(`dataURL=\`data:image/\${$output_format||"png"};base64,\${result}\``);coder.newLine();
				if(seg.getAttrVal("showImage")){
					coder.packText(`session.addChatText("assistant",label,{image:dataURL});`);coder.newLine();
				}
				coder.packText(`result=dataURL;`);coder.newLine();
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}else{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`throw Error("Error "+rsp.code+": "+rsp.info||"")`);
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}`);
			coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askFile=
	docAIAgentExporter.export_askText=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let pathAttr=seg.getAttr("path");
		let filterAttr=seg.getAttr("filter");
		let inputTypeAttr=seg.getAttr("inputType");
		let placeholderAttr=seg.getAttr("placeholder");
		let textAttr=seg.getAttr("textAttr");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			if(inputTypeAttr){
				coder.packText(`let inputType=(`);this.genAttrStatement(inputTypeAttr);coder.packText(`)||"text";`);coder.newLine();
			}
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			if(placeholderAttr){
				coder.packText(`let placeholder=(`);this.genAttrStatement(placeholderAttr);coder.packText(`);`);coder.newLine();
			}
			if(textAttr){
				coder.packText(`let text=(`);this.genAttrStatement(textAttr);coder.packText(`);`);coder.newLine();
			}
			coder.packText(`let resultText="";`);coder.newLine();
			coder.packText(`let fileData=null;`);coder.newLine();
			coder.packText(`let enc=null;`);coder.newLine();
			coder.packText(`let ext=null;`);coder.newLine();
			coder.packText(`let fileSys="${seg.getAttr("fileSys").val}";`);coder.newLine();
			coder.packText(`let result="";`);coder.newLine();
			if(pathAttr){
				coder.packText(`let path=(`);this.genAttrStatement(pathAttr);coder.packText(`);`);coder.newLine();
				coder.packText(`let filter=(`);this.genAttrStatement(filterAttr);coder.packText(`);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PreCodes");
			if(pathAttr){
				let readAttrVal=seg.getAttrVal("read");
				coder.packText(`[resultText,result]=await session.askUserRaw({type:"input",prompt:prompt,text:"",path:path,file:fileSys,filter:filter,});`);coder.newLine();
				switch(readAttrVal){
					default:
						coder.packText(`if(!result && resultText){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`result=resultText;`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else if(resultText && result){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`result=session.arrayBufferToDataURL(resultText,result);`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);
						coder.newLine();
						break;
					case "Text":
						coder.packText(`fileData=result||(await (await fetch(resultText)).arrayBuffer());`);coder.newLine();
						coder.packText(`result=(new TextDecoder()).decode(fileData)`);coder.newLine();
						break;
					case "Data":
						coder.packText(`fileData=result||(await (await fetch(resultText)).arrayBuffer());`);coder.newLine();
						coder.packText(`result=fileData;`);coder.newLine();
						break;
					case "JSON":
						coder.packText(`fileData=result||(await (await fetch(resultText)).arrayBuffer());`);coder.newLine();
						coder.packText(`result=(new TextDecoder()).decode(fileData)`);coder.newLine();
						coder.packText(`result=JSON.parse(result);`);coder.newLine();
						break;
					case "Base64":
						coder.packText(`fileData=result||(await (await fetch(resultText)).arrayBuffer());`);coder.newLine();
						coder.packText(`result=Base64.encode(fileData);`);coder.newLine();
						break;
					case "DataURL":
						coder.packText(`fileData=result||(await (await fetch(resultText)).arrayBuffer());`);coder.newLine();
						coder.packText(`result=session.arrayBufferToDataURL(resultText,fileData);`);coder.newLine();
						break;
				}
			}else{
				coder.packText(`[resultText,result]=await session.askUserRaw({type:"input",inputType:inputType,prompt:prompt,placeholder:placeholder,text:text});`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_askEditObj=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result,resultText;`);
			coder.maybeNewLine();
			coder.packText(`let role=`);this.genAttrStatement(seg.getAttr("role"));coder.packText(`;`);coder.newLine();
			coder.packText(`let text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
			coder.packText(`let template=`);this.genAttrStatement(seg.getAttr("template"));coder.packText(`;`);coder.newLine();
			coder.packText(`let data=`);this.genAttrStatement(seg.getAttr("data"));coder.packText(`;`);coder.newLine();
			coder.packText(`let edit=`);this.genAttrStatement(seg.getAttr("editData"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(typeof(template)==="string"){`);coder.indentMore();coder.newLine();
			{
				coder.packText(`template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			coder.packText(`let inputVO={template:template,data:data,options:{edit:edit}};`);coder.newLine();
			packExtraCodes(coder,seg,"Pre");
			coder.packText(`[resultText,result]=await session.askUserRaw({type:"object",text:text,data:data,template:template,role:role,edit:edit});`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
		
	//------------------------------------------------------------------------
	docAIAgentExporter.export_aiTTS=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let modeAttr=seg.getAttr("mode");
		let inputAttr=seg.getAttr("text");
		let voiceAttr=seg.getAttr("voice");
		let labelAttr=seg.getAttr("ttsLabel");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let callVO=null;`);coder.newLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let rsp=null;`);coder.newLine();
			coder.packText(`let mode=`);this.genAttrStatement(modeAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let text2Read=`);this.genAttrStatement(inputAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let voice=`);this.genAttrStatement(voiceAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let label=`);this.genAttrStatement(labelAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let showBlock=`);this.genAttrStatement(seg.getAttr("showBlock"));coder.packText(`;`);coder.newLine();
			coder.packText(`let autoPlay=`);this.genAttrStatement(seg.getAttr("autoPlay"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`callVO={model:mode,input:text2Read,voice:voice};`);coder.newLine();
			coder.packText(`rsp=await session.sysCall("AITTS",callVO,true,100000);`);coder.newLine();
			//coder.packText(`console.log(rsp)`);coder.newLine();
			coder.packText(`if(rsp.code===200){`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result=rsp.mp3;`);coder.newLine();
				coder.packText(`if(autoPlay)`);
				coder.packText(`session.addChatText("assistant",label,{audio:result,autoPlay:autoPlay});`);coder.newLine();
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}else{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`throw Error("Error "+rsp.code+": "+rsp.info||"")`);
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}`);
			coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_webCall=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let urlAttr=seg.getAttr("url");
		let methodAttr=seg.getAttr("method");
		let headerAttr=seg.getAttr("headers");
		let textAttr=seg.getAttr("text");
		let imageAttr=seg.getAttr("image");
		let argMode=seg.getAttrVal("argMode");
		let timeout=seg.getAttrVal("timeout");
		let format=seg.getAttrVal("format");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let callVO=null;`);coder.newLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let rsp=null;`);coder.newLine();
			coder.packText(`let url=`);this.genAttrStatement(urlAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let method=`);this.genAttrStatement(methodAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let headers=`);this.genAttrStatement(headerAttr);coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			switch(argMode){
				case "URL":{
					let list,i,n,attr,key,value;
					coder.packText(`if(url.indexOf("&")<0&&url.indexOf("?")<0){url+="?";}else{url+="&"}`);coder.newLine();
					coder.packText(`url+=`);
					list=seg.getAttr("args").attrList;
					n=list.length;
					for(i=0;i<n;i++){
						attr=list[i];
						key=attr.name;
						if(i!==0){
							coder.packText(`+"&"+`);
						}
						coder.packText(`encodeURIComponent("${key}")+"="+encodeURIComponent(`);this.genAttrStatement(attr);coder.packText(`)`);
					}
					coder.packText(`;`);coder.newLine();
					coder.packText(`callVO={url:url,method:method,headers:headers};`);coder.newLine();
					break;
				}
				case "JSON":{
					coder.packText(`let json=`);this.genAttrStatement(seg.getAttr("args"));coder.packText(`;`);coder.newLine();
					coder.packText(`callVO={url:url,method:method,argMode:"JSON",headers:headers,json:json};`);coder.newLine();
					break;
				}
				case "TEXT":{
					coder.packText(`let text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
					coder.packText(`callVO={url:url,method:method,argMode:"TEXT",headers:headers,text:text};`);coder.newLine();
					break;
				}
			}
			packExtraCodes(coder,seg,"AboutCall");
			coder.packText(`rsp=await session.webCall(callVO,true,${timeout});`);coder.newLine();
			coder.packText(`if(rsp.code===200){`);
			coder.indentMore();
			coder.newLine();
			{
				if(format==="JSON"){
					coder.packText(`result=JSON.parse(rsp.data);`);
				}else{
					coder.packText(`result=rsp.data;`);
				}
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}else{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`throw Error("Error "+rsp.code+": "+rsp.info||"")`);
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`}`);
			coder.newLine();
			packExtraCodes(coder,seg,"AfterCall");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_save=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let loc=seg.getAttrVal("location");
		let ctxAttr=seg.getAttr("saveContext");
		let fileAttr=seg.getAttr("fileName");
		let target=seg.getAttrVal("target");
		let attrList=ctxAttr.attrList;
		let i,n,attr,attrName;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		if(target==="Context"){
			coder.packText(`let saveVO={context:{}};`);coder.newLine();
			coder.packText(`let ctxVO=saveVO.context;`);coder.newLine();
			coder.packText(`let result=saveVO;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				attrName=attr.val;
				coder.packText(`ctxVO["${attrName}"]=context["${attrName}"];`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			if(fileAttr.valText){
				coder.packText(`{`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`let fileName=`);this.genAttrStatement(fileAttr);coder.packText(`;`);coder.newLine();
					coder.packText(`let content=JSON.stringify(saveVO,null,"\t");`);coder.newLine();
					coder.packText(`let result=content;`);coder.newLine();
					packExtraCodes(coder,seg,"SaveData");
					if(loc==="Hub"){
						coder.packText(`fileName=pathLib.basename(fileName);`);coder.newLine();
						coder.packText(`result=await session.saveHubFile(fileName,content);`);coder.newLine();
					}else{
						coder.packText(`fileName=fileName[0]==="/"?fileName:basePath+"/"+fileName;`);coder.newLine();
						coder.packText(`fileName=fileName.startsWith("/~/")?fileName.substring(2):fileName;`);coder.newLine();
						coder.packText(`fileName=fileName.startsWith("//")?fileName.substring(1):fileName;`);coder.newLine();
						coder.packText(`let tabFS=(await import("/@tabos")).tabFS;`);coder.newLine();
						coder.packText(`await tabFS.writeFile(fileName,content,"utf8");`);coder.newLine();
					}
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}				
			packExtraCodes(coder,seg,"FinCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}else{
			let saveFormat=seg.getAttrVal("format");
			coder.packText(`let fileName=`);this.genAttrStatement(fileAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`let content=input;`);coder.newLine();
			coder.packText(`let result=content;`);coder.newLine();
			if(loc==="Hub"){
				coder.packText(`fileName=pathLib.basename(fileName);`);coder.newLine();
				coder.packText(`result=await session.saveHubFile(fileName,content);`);coder.newLine();
			}else{
				coder.packText(`let tabFS=(await import("/@tabos")).tabFS;`);coder.newLine();
				coder.packText(`fileName=fileName[0]==="/"?fileName:basePath+"/"+fileName;`);coder.newLine();
				coder.packText(`fileName=fileName.startsWith("/~/")?fileName.substring(2):fileName;`);coder.newLine();
				coder.packText(`fileName=fileName.startsWith("//")?fileName.substring(1):fileName;`);coder.newLine();
				packExtraCodes(coder,seg,"PreCodes");
				switch(saveFormat){
					default:
					case "Data":
						break;
					case "JSON":
						coder.packText(`content=JSON.stringify(content,null,"\\t");`);coder.newLine();
						break;
					case "CJSON":
						coder.packText(`content=JSON.stringify(content);`);coder.newLine();
						break;
					case "Text":
						coder.packText(`content=""+content;`);coder.newLine();
						break;
					case "Base642Data":
						coder.packText(`content=Base64.decode(content);`);coder.newLine();
						break;
					case "DataURL2Data":
						coder.packText(`content=content.split(",")[1];`);coder.newLine();
						coder.packText(`content=Base64.decode(content);`);coder.newLine();
						break;
				}
				packExtraCodes(coder,seg,"SaveData");
				coder.packText(`await tabFS.writeFile(fileName,content);`);coder.newLine();
			}
			packExtraCodes(coder,seg,"FinCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_load=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let fileAttr=seg.getAttr("fileName");
		let readTarget=seg.getAttrVal("read");
		let i,n,attr,attrName;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let content=null;`);coder.newLine();
			coder.packText(`let result=null;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(fileAttr.valText){
				coder.packText(`{`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`let tabFS=(await import("/@tabos")).tabFS;`);coder.newLine();
					coder.packText(`let fileName=`);this.genAttrStatement(fileAttr);coder.packText(`;`);coder.newLine();
					coder.packText(`fileName=fileName[0]==="/"?fileName:basePath+"/"+fileName;`);coder.newLine();
					coder.packText(`fileName=fileName.startsWith("/~/")?fileName.substring(2):fileName;`);coder.newLine();
					coder.packText(`fileName=fileName.startsWith("//")?fileName.substring(1):fileName;`);coder.newLine();
					coder.packText(`try{`);
					coder.indentMore();
					coder.newLine();
					{
						switch(readTarget){
							case "Context":
							case "JSON":
								coder.packText(`content=await tabFS.readFile(fileName,"utf8");`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content=JSON.parse(content);`);coder.newLine();
								break;
							case "Text":
								coder.packText(`content=await tabFS.readFile(fileName,"utf8");`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								break;
							case "Data":
								coder.packText(`content=await tabFS.readFile(fileName);`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								break;
							case "Base64":
								coder.packText(`content=await tabFS.readFile(fileName);`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content=Base64.encode(content);`);coder.newLine();
								break;
							case "DataURL":
								coder.packText(`content=await tabFS.readFile(fileName);`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content=Base64.encode(content);`);coder.newLine();
								coder.packText(`let ext=pathLib.extname(fileName);`);coder.newLine();
								coder.packText(`switch(ext){`);
								coder.indentMore();
								coder.newLine();
								{
									coder.packText(`case ".jpg":`);
									coder.indentMore();
									coder.newLine();
									coder.packText(`content="data:image/jpeg;base64,"+content;`);coder.newLine();
									coder.packText(`break;`);
									coder.indentLess();
									coder.newLine();
									coder.packText(`case ".png":`);
									coder.indentMore();
									coder.newLine();
									coder.packText(`content="data:image/png;base64,"+content;`);coder.newLine();
									coder.packText(`break;`);
									coder.indentLess();
									coder.newLine();
									coder.packText(`case ".txt":`);
									coder.indentMore();
									coder.newLine();
									coder.packText(`content="data:text/plain;base64,"+content;`);coder.newLine();
									coder.packText(`break;`);
									coder.indentLess();
									coder.newLine();
									coder.packText(`default:`);
									coder.indentMore();
									coder.newLine();
									coder.packText(`content="data:application/octet-stream;base64,"+content;`);coder.newLine();
									coder.packText(`break;`);
									coder.indentLess();
									coder.newLine();
								}
								coder.indentLess();
								coder.maybeNewLine();
								coder.packText(`}`);
								coder.maybeNewLine();
								break;
						}
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}catch(err){`);
					coder.indentMore();
					coder.newLine();
					{
						coder.packText(`content=null;`);coder.newLine();
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}				
			packExtraCodes(coder,seg,"PreMerge");
			if(readTarget==="Context"){
				coder.packText(`if(content && content.context){Object.assign(context,content.context);}`);coder.newLine();
				packExtraCodes(coder,seg,"PostCodes");
				coder.packText(`result=content;`);coder.newLine();
			}else{
				coder.packText(`result=content;`);coder.newLine();
			}
			packExtraCodes(coder,seg,"FinCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docAIAgentExporter.export_fixArgs=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let editDoc=seg.doc;
		let resultVal=seg.getAttr("result");
		let docArgs=editDoc.getAttr("apiArgs").attrList;
		let argAttr,argName;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let missing=false;`);coder.newLine();
			coder.packText(`let smartAsk=`);this.genAttrStatement(seg.getAttr("smartAsk"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			for(argAttr of docArgs){
				argName=argAttr.name;
				if(argAttr.getAttrVal("required")!==false){
					coder.packText(`if(${argName}===undefined || ${argName}==="") missing=true;`);coder.newLine();
				}
			}
			coder.packText(`if(missing){`);coder.indentMore();coder.newLine();
			{
				if(this.agentInBrowser){
					coder.packText(`result=await session.pipeChat("/@aichat/ai/CompleteArgs.js",{"argsTemplate":argsTemplate,"command":input,smartAsk:smartAsk},false);`);coder.newLine();
				}else{
					coder.packText(`result=await session.pipeChat("/@tabos/HubFixArgs.mjs",{"argsTemplate":argsTemplate,"command":input,smartAsk:smartAsk},false);`);coder.newLine();
				}
				coder.packText(`parseAgentArgs(result);`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			coder.maybeNewLine();
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docAIAgentExporter.export_jumper=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let editDoc=seg.doc;
		let resultVal=seg.getAttr("result");
		let docArgs=editDoc.getAttr("apiArgs").attrList;
		let jumpTarget=seg.getAttrVal("seg");
		let argAttr,argName;
		let outlet=seg.outlet;
		let nextSeg,outletId;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`let result=input;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			
			if(outlet){
				outletId=outlet.jaxId;
				nextSeg=outlet.getLinkedSeg();
			}
			coder.maybeNewLine();
			if(nextSeg){
				coder.packText(`result=(await ${jumpTarget}(input)).result;`);
				coder.maybeNewLine();
				packExtraCodes(coder,seg,"PostCodes");
				coder.maybeNewLine();
				segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
				segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
				if(exportDebug){
					coder.packText(`return {seg:${segName},result:result,preSeg:"${seg.jaxId}",outlet:"${outletId}"};`);
				}else{
					coder.packText(`return {seg:${segName},result:result};`);
				}
			}else{
				if(jumpTarget){
					let list,i,n;
					list=editDoc.segsList;
					n=list.length;
					FindSeg:{
						for(i=0;i<n;i++){
							seg=list[i];
							if(seg.idVal.val===jumpTarget){
								break FindSeg;
							}
							if(seg.jaxId===jumpTarget){
								jumpTarget=seg.idVal.val;
								break FindSeg;
							}
						}
						jumpTarget=null;
					}
				}
				if(exportDebug){
					coder.packText(`return {seg:${jumpTarget||null},result:result,preSeg:"${seg.jaxId}",outlet:"${outletId}"};`);
				}else{
					coder.packText(`return {seg:${jumpTarget||null},result:result};`);
				}
			}
			coder.maybeNewLine();
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
