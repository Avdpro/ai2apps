import {EditPrj,EditPrjObjDef} from "../EditPrj.js";
import {} from "./EditPyAgentDocExporter.js";
//----------------------------------------------------------------------------
//Change the AI agents extname to ".py":
{
	let attrs=EditPrjObjDef.attrs;
	for(let name in attrs){
		if(name==="docAIAgents"){
			let attrDef=attrs[name];
			attrDef.fileExt=".py";
		}
	};
}
