import {EditPrj,EditPrjObjDef} from "../EditPrj.js";
EditPrj.AIAgentDir="ai";