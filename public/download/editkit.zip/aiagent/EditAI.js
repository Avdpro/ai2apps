import {VFACT} from "/@vfact";
import {EditAISeg} from "./EditAISeg.js";
import {DocAIAgent} from "./EditAIAgentDoc.js";
import {} from "./EditAISegDefs.js";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditPrj,EditPrjObjDef} from "../EditPrj.js";
import {EditAtom} from "../editdoc/EditAtom.js";
import {} from "./EditAIAgentDocExporter.js";

import {UIEditWithCanvas} from "../ui/UIEditWithCanvas.js";
import {UIAICanvas} from "../ui/UIAICanvas.js";

let $ln=VFACT.lanCode||"EN";

//----------------------------------------------------------------------------
//Inject/insert AIAgent docs into editPrj:
let oldAttrs=EditPrjObjDef.attrs;
let newAttrs={};
for(let name in oldAttrs){
	if(name==="docGears"){
		newAttrs.docAIAgents={
			name:"docAIAgents",showName:(($ln==="CN")?("AI智能体"):/*EN*/("AI Agents")),icon:"folder.svg",type:"object",def:"DocsObj",docType:"DocAIAgent",dir:EditPrj.AIAgentDir===undefined?"ai":EditPrj.AIAgentDir,key:1,fixed:1,edit:false,navi:"prj"
		};
	}
	newAttrs[name]=oldAttrs[name];
};
EditPrjObjDef.attrs=newAttrs;

//****************************************************************************
//Inject seg functions into editPrj
//****************************************************************************
{
	let editPrj=EditPrj.prototype;
	//------------------------------------------------------------------------
	editPrj.editAttr_AddAISeg=function(segs,def,x,y){
		let attr;
		let doc;
		doc=segs.doc;
		doc.startEditAction();
		{
			let atom;
			//Adjust child's position and x,y based on owner's content-layout:
			atom=EditAtom.addAttr(segs,{type:"aiseg",def:def,navi:"doc"});
			doc.execEditAtom(atom);
			attr=atom.attr;
			if(Number.isFinite(x) && Number.isFinite(y)){
				attr.setAttrByText("x",""+x);
				attr.setAttrByText("y",""+y);
			}
		}
		doc.endEditAction();
		return attr;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_AddAIOutlet=function(outlets,def){
		let attr;
		let doc;
		doc=outlets.doc;
		doc.startEditAction();
		{
			let atom;
			//Adjust child's position and x,y based on owner's content-layout:
			atom=EditAtom.addAttr(outlets,{type:"aioutlet",def:def,navi:"doc"});
			doc.execEditAtom(atom);
		}
		doc.endEditAction();
		return attr;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_MoveAISeg=function(seg,x,y,multiDrag=false){
		let doc;
		doc=seg.doc;
		if(!multiDrag){
			doc.startEditAction();
		}
		{
			let attrDef,execSetTextAtom;
			attrDef=seg.def;
			execSetTextAtom=seg.execSetTextAtom||attrDef.execSetTextAtom;
			if(execSetTextAtom){
				execSetTextAtom(EditAtom,doc,seg,"x",""+x);
				execSetTextAtom(EditAtom,doc,seg,"y",""+y);
			}else{
				doc.execEditAtom(EditAtom.setAttrByText(seg,"x",""+x));
				doc.execEditAtom(EditAtom.setAttrByText(seg,"y",""+y));
			}
		}
		if(!multiDrag){
			doc.endEditAction();
		}
		return seg;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_PasteAISeg=function(segs,vo,x,y){
		let doc,savedList,atom,newSeg;
		doc=segs.doc;
		doc.startEditAction();
		{
			//This is copied item:
			EditObj.forceNewJaxId(1);
			newSeg=EditAttr.loadFromVO(segs,vo);
			newSeg.postLoadLink(true);
			newSeg.def.navi="doc";
			newSeg.setAttrByText("x",""+x);
			newSeg.setAttrByText("y",""+y);
			EditObj.forceNewJaxId(0);
			atom=EditAtom.addAttr(segs,newSeg);
			doc.execEditAtom(atom);
		}
		doc.endEditAction();
		return newSeg;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_PasteAIOutlet=function(curObj,vo){
		//TODO: Code this:
	};
}


//Reigster AI-Edit-Canvas:
UIEditWithCanvas.regCanvas(UIAICanvas);

export{EditAISeg,DocAIAgent};
