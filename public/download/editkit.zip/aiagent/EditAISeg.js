import {VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {esprima} from "/@tabos/utils/esprima.mjs";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
//Hud:

const $ln=VFACT.lanCode;
let EditAISeg,editAISeg,EditAISegOutlet,editAISegOutlet;
//****************************************************************************
//:EditAISegOutlet
//****************************************************************************
{
	EditAISegOutlet=function(owner,def,init){
		let self;
		self=this;
		EditObj.call(this,owner,def,true);
		this.isAISegOutlet=true;
		this.linkedSeg=null;
		this.idVal=this.getAttr("id");
		this.liveHudObj=null;
		this.pathDir=[1,0];
	};
	inherits(EditAISegOutlet,EditObj);
	EditAttr.regAttrType("aioutlet",EditAISegOutlet);
	editAISegOutlet=EditAISegOutlet.prototype;
	if(VFACT.classRegs){
		VFACT.classRegs.EditAISegOutlet=EditAISegOutlet;
	}
	
	//************************************************************************
	//:EditAISegOutlet def registers
	//************************************************************************
	{
		let defRegs={};
		//--------------------------------------------------------------------
		EditAISegOutlet.regDef=function(def){
			let name=def.name;
			if(def){
				defRegs[name]=def;
			}else{
				delete defRegs[name];
			}
		};

		//--------------------------------------------------------------------
		EditAISegOutlet.getDef=function(name){
			return defRegs[name];
		};

		//--------------------------------------------------------------------
		EditAISegOutlet.getDefs=function(){
			return Object.values(defRegs);
		};
		
	}
	
	//************************************************************************
	//:EditAISegOutlet export related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAISegOutlet.getLinkedSeg=function(){
			let seg,outlet;
			seg=this.linkedSeg;
			while(seg && seg.isConnector){
				outlet=seg.outlet;
				if(outlet){
					seg=outlet.linkedSeg;
				}else{
					seg=null;
				}
			}
			return seg;
		};
	}
	
	//************************************************************************
	//:EditAISegOutlet I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAISegOutlet.genSaveVO=function(){
			let vo=EditObj.prototype.genSaveVO.call(this);
			if(this.linkedSeg){
				vo.linkedSeg=this.linkedSeg.jaxId;
			}
			return vo;
		};

		//--------------------------------------------------------------------
		editAISegOutlet.loadFromVO=function(vo){
			EditObj.prototype.loadFromVO.call(this,vo);
			this.linkedSeg=vo.linkedSeg||null;
		};

		//--------------------------------------------------------------------
		editAISegOutlet.postLoadLink=function(clearLink=false){
			let segId,doc,list,i,n,seg;
			if(clearLink){
				this.linkedSeg=null;
				return;
			}
			segId=this.linkedSeg;
			if(typeof(segId)==="string" && segId){
				doc=this.doc;
				seg=doc.findSeg(segId);
				this.linkedSeg=seg||null;
				if(seg){
					seg.linkOutlet(this);
				}
			}
		};
	
	}
	
	//************************************************************************
	//:EditAISegOutlet LiveHudObj / render path
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAISegOutlet.renderPath=function(){
			if(this.liveHudObj){
				this.liveHudObj.renderPath();
			}
		};

		//--------------------------------------------------------------------
		editAISegOutlet.bindLiveObj=function(liveObj){
			if(this.liveHudObj && this.liveHudObj!==liveObj){
				this.dropLiveObj();
			}
			this.liveHudObj=liveObj;
		};

		//--------------------------------------------------------------------
		editAISegOutlet.dropLiveObj=function(liveObj){
			if(liveObj && liveObj!==this.liveHudObj){
				return;
			}
			this.liveHudObj=null;
		};
	}
	
	//************************************************************************
	//:UIEditor related:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		editAISegOutlet.getName=function(){
			return this.idVal.val||"outlet";
		};

		//--------------------------------------------------------------------
		editAISegOutlet.getEditRootPpts=function(){
			return [{obj:this,open:true}];
		};
	}
}

//****************************************************************************
//:EditAISeg
//****************************************************************************
EditAISeg=function(owner,def,init){
	let self;
	self=this;
	EditObj.call(this,owner,def,true);
	this.isAISeg=true;
	
	//Inbuilt outlet:
	this.outlet=this.getAttr("outlet");
	//Catch outlet:
	this.catchlet=this.getAttr("catchlet");
	
	//Extra outlets:
	this.outletsVal=this.getAttr("outlets");
	if(this.outletsVal){
		this.outletsList=this.outletsVal.attrList;
	}

	this.idVal=this.getAttr("id");
	this.nameVal=this.getAttr("viewName")||this.idVal;
	this.labelVal=this.getAttr("label");
	this.liveHudObj=null;
	this.linkedOutlets=[];
	this.pathDir=[-1,0];
	this.traced=false;
	this.traceLogs=this.getAttr("traceLogs");
	this.initScope();
	this.mkpInputVal=this.getAttr("mkpInput");
	if(this.mkpInputVal){
		this.mkpInputVal.traceOn(()=>{
			this.updateHyperAttrs();
		});
	}
};
inherits(EditAISeg,EditObj);
EditAttr.regAttrType("aiseg",EditAISeg);
editAISeg=EditAISeg.prototype;
if(VFACT.classRegs){
	VFACT.classRegs.EditAISeg=EditAISeg;
}
//****************************************************************************
//:EditAISeg def registers
//****************************************************************************
{
	let segDefRegs={};
	EditAISeg.regDef=function(def){
		let name=def.name;
		let catalogs=def.catalog;
		let oldDef;
		oldDef=segDefRegs[name];
		if(def){
			segDefRegs[name]=def;
		}
		if(oldDef){
			let name,catalog,catalogs,idx;
			catalogs=oldDef.catalog;
			for(name of catalogs){
				catalog=EditAISeg.getCatalog(name);
				idx=catalog.defs.indexOf(oldDef);
				if(idx>=0){
					catalog.defs.splice(idx,1);
				}
			}
		}
		if(catalogs){
			let catalog;
			for(name of catalogs){
				catalog=EditAISeg.getCatalog(name);
				if(catalog){
					catalog.defs.push(def);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	EditAISeg.getDef=function(name){
		return segDefRegs[name];
	};

	//------------------------------------------------------------------------
	EditAISeg.getDefs=function(){
		return Array.from(Object.values(segDefRegs));
	};
	let defCatalogs={};
	//------------------------------------------------------------------------
	EditAISeg.regCatalog=function(def){
		let name,catalog;
		name=def.name;
		catalog=defCatalogs[name];
		if(!catalog){
			defCatalogs[name]={...def,defs:[]};
		}
	};
	
	//------------------------------------------------------------------------
	EditAISeg.getCatalog=function(name){
		return defCatalogs[name];
	};

	//------------------------------------------------------------------------
	EditAISeg.getCatalogs=function(){
		return Object.values(defCatalogs);
	};
}

//****************************************************************************
//:EditAISeg I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISeg.genSaveVO=function(){
		let vo,icon;
		vo=EditObj.prototype.genSaveVO.call(this);
		icon=this.objDef.segIcon||this.objDef.icon;
		vo.icon=icon;
		if(this.objDef.reverseOutlets){
			vo.reverseOutlets=true;
		}
		if(this.isConnector){
			vo.isConnector=true;
		}
		if(this.isNote){
			vo.isNote=true;
		}
		return vo;
	};
	//------------------------------------------------------------------------
	editAISeg.postLoadLink=function(clearLink=false){
		let list,i,n,outlet;
		outlet=this.outlet;
		if(outlet){
			outlet.postLoadLink(clearLink);
		}
		outlet=this.catchlet;
		if(outlet){
			outlet.postLoadLink(clearLink);
		}
		list=this.outletsList;
		if(list){
			n=list.length;
			for(i=0;i<n;i++){
				outlet=list[i];
				outlet.postLoadLink(clearLink);
			}
		}
		list=this.segsList;
		if(list){
			n=list.length;
			for(i=0;i<n;i++){
				list[i].postLoadLink(clearLink);
			}
		}
	};
}

//****************************************************************************
//:EditAISeg Live obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISeg.bindLiveObj=function(liveObj){
		if(this.liveHudObj && this.liveHudObj!==liveObj){
			this.dropLiveObj(this.liveHudObj);
		}
		this.liveHudObj=liveObj;
	};
	
	//------------------------------------------------------------------------
	editAISeg.dropLiveObj=function(liveObj){
		let list,outlet;
		if(liveObj && liveObj!==this.liveHudObj){
			return;
		}
		this.liveHudObj=null;
		outlet=this.outlet;
		if(outlet){
			outlet.dropLiveObj();
		}
		list=this.outletsList;
		if(list){
			for(outlet of list){
				outlet.dropLiveObj();
			}
		}
	};
	
	//------------------------------------------------------------------------
	editAISeg.renderPath=function(){
		let outlet;
		outlet=this.outlet;
		if(outlet){
			outlet.renderPath();
		}
		outlet=this.catchlet;
		if(outlet){
			outlet.renderPath();
		}
		if(this.outletsList){
			for(outlet of this.outletsList){
				outlet.renderPath();
			}
		}
	};
}

//****************************************************************************
//:Link outlets:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISeg.getOutletById=function(idName){
		let outlets,outlet;
		if(idName==="outlet"){
			return this.outlet;
		}else if(idName==="catchlet"){
			return this.catchlet;
		}
		outlets=this.outletsList;
		for(outlet of outlets){
			if(outlet.jaxId===idName || outlet.getAttrVal("id")===idName){
				return outlet;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	editAISeg.getOutlets=function(){
		let list=[];
		let outlet;
		let rev=this.objDef.reverseOutlets||false
		if(!rev){
			outlet=this.outlet;
			if(outlet){
				list.push(outlet);
			}
			outlet=this.catchlet;
			if(outlet){
				list.push(outlet);
			}
		}
		if(this.outletsList){
			for(outlet of this.outletsList){
				list.push(outlet);
			}
		}
		if(rev){
			outlet=this.catchlet;
			if(outlet){
				list.push(outlet);
			}
			outlet=this.outlet;
			if(outlet){
				list.push(outlet);
			}
		}
		return list;
	};
	
	//------------------------------------------------------------------------
	editAISeg.linkOutlet=function(outlet){
		let list;
		list=this.linkedOutlets;
		if(list.indexOf(outlet)>=0){
			return;
		}
		list.push(outlet);
	};
	
	//------------------------------------------------------------------------
	editAISeg.removeLinkedOutlet=function(outlet){
		let list,idx;
		list=this.linkedOutlets;
		idx=list.indexOf(outlet);
		if(idx>=0){
			list.splice(idx,1);
		}
	};
}

//****************************************************************************
//:EditAISeg Editor UI related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISeg.getName=function(){
		return this.idVal.val||"AISEG"+`[${this.objDef.name}]`;
	};
}

//****************************************************************************
//:Scope:
//****************************************************************************
{
	editAISeg.initScope=function(){
		let self,doc,appCfg,ctxObj,ctxPxy,argPxy,globalObj,localVars,inputAttr,resultAttr,willUpdate;
		self=this;
		willUpdate=false;
		this.scopeObj={};
		appCfg=this.prj.objConfig;
		doc=this.doc;
		ctxObj=doc.getAttr("context");
		ctxPxy=doc.contextProxy;
		argPxy=doc.argProxy;
		globalObj=doc.getAttr("globalMockup");
		localVars=doc.getAttr("localVars");
		inputAttr=this.getAttr("mkpInput");
		resultAttr=this.getAttr("mkpResult");
		this.setScopeObj("$ln",appCfg.getAttr("lanCode"),false);
		this.setScopeObj("arguments",argPxy,true);
		this.setScopeObj("context",ctxPxy,false);
		this.setScopeObj("globalContext",globalObj,false);
		this.setScopeObj("localVars",localVars,true);
		if(inputAttr){
			this.setScopeObj("input",()=>inputAttr.val,false);
		}
		if(resultAttr){
			this.setScopeObj("result",()=>resultAttr.val,false);
		}
		function update(){
			if(willUpdate)
				return;
			willUpdate=true;
			callAfter(()=>{
				self.buildScopeEnv();
				self.updateHyperAttrs();
				willUpdate=false;
			});
		}
		globalObj.on("Changed",update);
		ctxObj.on("Changed",update);
		localVars.on("Changed",update);
		if(inputAttr){
			inputAttr.traceOn(update);
		}
		if(resultAttr){
			resultAttr.traceOn(update);
		}
	};
}

//*****************************************************************************
//:Debug trace
//*****************************************************************************
{
	//-------------------------------------------------------------------------
	editAISeg.resetDebugTrace=function(){
		let outlet;
		this.traced=false;
		this.emitChanged();
		//Clear trace-logs
		this.traceLogs && this.traceLogs.clearArray();
		outlet=this.outlet;
		if(outlet){
			outlet.traced=false;
			outlet.emitChanged();
		}
		outlet=this.catchlet;
		if(outlet){
			outlet.traced=false;
			outlet.emitChanged();
		}
		if(this.outletsList){
			for(outlet of this.outletsList){
				outlet.traced=false;
				outlet.emitChanged();
			}
		}
	};
	
	//-------------------------------------------------------------------------
	editAISeg.traceInput=function(input,seqId){
		let logAttr,inputType,logText;
		this.traced=true;
		this.lastTracedInput=input;
		this.emitChanged();
		//Add trace-log:
		logAttr=this.traceLogs.addAttr();
		inputType=typeof(input);
		switch(inputType){
			case "string":
				logText=input;
				break;
			case "object":
				try{
					logText=JSON.stringify(input,null,"\t");
				}catch(err){
					logText=""+input;
				}
				break;
			default:
				logText=""+input;
				break;
		}
		logAttr.getAttr("input").setValByText(logText);
		logAttr.seqId=seqId;
	};
	
	//-------------------------------------------------------------------------
	editAISeg.traceOutlet=function(outletJaxId){
		let outlet,seg;
		outlet=this.outlet;
		if(outlet && outlet.jaxId===outletJaxId){
			outlet.traced=true;
			outlet.emitChanged();
			seg=outlet.linkedSeg;
			while(seg && seg.isConnector){
				outlet=seg.outlet;
				outlet.traced=true;
				outlet.emitChanged();
				seg=outlet.linkedSeg;
			}
			return;
		}
		outlet=this.catchlet;
		if(outlet && outlet.jaxId===outletJaxId){
			outlet.traced=true;
			outlet.emitChanged();
			seg=outlet.linkedSeg;
			while(seg && seg.isConnector){
				outlet=seg.outlet;
				outlet.traced=true;
				outlet.emitChanged();
				seg=outlet.linkedSeg;
			}
			return;
		}
		if(this.outletsList){
			for(outlet of this.outletsList){
				if(outlet.jaxId===outletJaxId){
					outlet.traced=true;
					outlet.emitChanged();
					seg=outlet.linkedSeg;
					while(seg && seg.isConnector){
						outlet=seg.outlet;
						outlet.traced=true;
						outlet.emitChanged();
						seg=outlet.linkedSeg;
					}
					return;
				}
			}
		}
	};

	//-------------------------------------------------------------------------
	editAISeg.traceResult=function(result,seqId){
		let list,attr,inputType,logText;
		list=this.traceLogs.attrList;
		for(attr of list){
			if(attr.seqId===seqId){
				inputType=typeof(result);
				switch(inputType){
					case "string":
						logText=result;
						break;
					case "object":
						try{
							logText=JSON.stringify(result,null,"\t");
						}catch(err){
							logText=""+result;
						}
						break;
					default:
						logText=""+result;
						break;
				}
				attr.getAttr("output").setValByText(logText);
				return;
			}
		}
	};

	//-------------------------------------------------------------------------
	editAISeg.traceLLMInput=function(input,callId){
		let list,attr,resultAttr;
		list=this.traceLogs.attrList;
		for(attr of list){
			if(attr.seqId===callId){
				resultAttr=attr.getAttr("inputLLM");
				if(!resultAttr){
					resultAttr=attr.addAttr({name:"inputLLM",type:"string",editType:"note",extraAttr:true});
				}
				resultAttr.setValByText(""+input);
				return;
			}
		}
	};

	//-------------------------------------------------------------------------
	editAISeg.traceLLMResult=function(result,callId,usage){
		let list,attr,resultAttr,usageAttr;
		list=this.traceLogs.attrList;
		for(attr of list){
			if(attr.seqId===callId){
				resultAttr=attr.getAttr("resultLLM");
				if(!resultAttr){
					resultAttr=attr.addAttr({name:"resultLLM",type:"string",editType:"note",extraAttr:true});
				}
				resultAttr.setValByText(""+result);
				usageAttr=attr.getAttr("usage");
				if(!usageAttr){
					usageAttr=attr.addAttr({name:"usage",type:"auto",extraAttr:true});
				}
				usageAttr.setValByText(JSON.stringify(usage));
				return;
			}
		}
	};

	//-------------------------------------------------------------------------
	editAISeg.traceDebugLog=function(log){
		let list,attr,logId,logAttr;
		list=this.traceLogs.attrList;
		attr=list[list.length-1];
		if(attr){
			logId=attr.attrList.length;
			logAttr=attr.addAttr({name:"log_"+logId,showName:"LOG",type:"string",editType:"note",extraAttr:true});
			if(typeof(log)==="object"){
				logAttr.setValByText(JSON.stringify(log,null,"\t"));
			}else{
				logAttr.setValByText(""+log);
			}
		}
	};
}

//*****************************************************************************
//:Draw call mark:
//*****************************************************************************
{
	let nextCode=1;
	let seg2Code=new Map();
	
	//-------------------------------------------------------------------------
	EditAISeg.clearJumpCode=function(){
		seg2Code.clear();
		nextCode=1;
	};
	
	//-------------------------------------------------------------------------
	EditAISeg.getJumpCode=function(seg){
		let code;
		code=seg2Code.get(seg);
		if(code){
			return code;
		}
		code=""+(nextCode++);
		seg2Code.set(seg,code);
		return code;
	};
}

export {EditAISeg,EditAISegOutlet};
