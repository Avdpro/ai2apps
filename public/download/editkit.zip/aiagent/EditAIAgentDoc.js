import {VFACT} from "/@vfact";
import {EditAttr} from "../EditAttr.js";
import {EditObj,EditObjProxy} from "../EditObj.js";
import {EditDoc,EditDocDef} from "../editdoc/EditDoc.js";
import inherits from "/@inherits";
import pathLib from "/@path";
import {tabNT} from "/@tabos";
let $ln=VFACT.lanCode||"EN";
let DocAIAgent,docAIAgent;
const AISegArrayDef={elementType:"aiseg",allowExtraAttr:1};
const AgentArgDef={
	name:"AgentCallArgument",allowExtraAttr:false,icon:"var_auto.svg",
	attrs:{
		"type":{
			name:"type",showName:(($ln==="CN")?("类型"):/*EN*/("type")),type:"choice",key:1,fixed:1,initVal:"auto",
			vals:[
				["auto","Auto",(($ln==="CN")?("自动类型"):/*EN*/("Auto"))],
				["string","String",(($ln==="CN")?("字符串"):/*EN*/("String"))],
				["integer","Integer",(($ln==="CN")?("整数"):/*EN*/("Integer"))],
				["number","Number",(($ln==="CN")?("数字"):/*EN*/("Number"))],
				["bool","Boolean",(($ln==="CN")?("布尔型"):/*EN*/("Boolean"))],
				["file","File",(($ln==="CN")?("文件"):/*EN*/("File"))],
			],
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("显示名称"):/*EN*/("Show name")),type:"string",key:0,fixed:1,initVal:"",localizable:true,
		},
		"mockup":{
			name:"mockup",showName:(($ln==="CN")?("默认/示例值"):/*EN*/("Default/Mockup")),type:"auto",key:1,fixed:1,initVal:"",
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:"",
		},
		"required":{
			name:"required",showName:(($ln==="CN")?("必填"):/*EN*/("Required")),type:"bool",key:0,fixed:1,initVal:true,
		},
		"enum":{
			name:"enum",showName:(($ln==="CN")?("可取的值"):/*EN*/("Enum")),type:"array",elementType:"auto",key:0,fixed:1,initVal:"",
		},
	},
	listHint:["type","label","mockup","required","enum","desc"],
};
EditObj.regDef("AgentCallArgument",AgentArgDef);

const getKindSpec=async function(obj,pptName,dv){
	let kind,topDv,findObj,kindSpec,res,caps;
	topDv=dv.topDataView;
	if(topDv){
		findObj=topDv.getEditObj();
		kind=findObj.kind;
		res=await tabNT.makeCall("AhGetAgentKindSpec",{kind:kind});
		if(res && res.code==200 && res.spec){
			return res.spec;
		}
	}
	return null;
};

const getKindCaps=async function(obj,pptName,dv){
	let kindSpec,caps;
	kindSpec=await getKindSpec(obj,pptName,dv);
	if(kindSpec){
		caps=Array.from(Object.keys(kindSpec.caps||[]));
		return caps;
	}
};
const getKindFilters=async function(obj,pptName,dv){
	let kindSpec,caps,args,capKey,cap;
	kindSpec=await getKindSpec(obj,pptName,dv);
	if(kindSpec){
		caps=kindSpec.caps;
		args=[];
		for(capKey in caps){
			cap=caps[capKey];
			if(cap.kind==="arg"){
				args.push(capKey);
			}
		}
		return args;
	}
};

const getKindRanks=async function(obj,pptName,dv){
	let kindSpec,ranks;
	kindSpec=await getKindSpec(obj,pptName,dv);
	if(kindSpec){
		ranks=kindSpec.ranks;
		return Array.from(Object.keys(ranks));
	}
};

const DocAIAgentDef={
	name:"DocAIAgent",
	icon:"gears.svg",allowExtraAttr:0,navi:"prj",
	constructFunc:DocAIAgent,
	exporter:"AIAgent",
	attrs:{
		...EditDocDef.attrs,//basic attr: path
		"agent":{
			name:"agent",showName:(($ln==="CN")?("AI智能体"):/*EN*/("AI Agent")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:"doc",
			newAttrMode:"GearArg",watchTree:false,
		},
		"showName":{
			name:"showName",showName:(($ln==="CN")?("展示名称"):/*EN*/("Show name")),type:"string",key:1,fixed:1,initVal:"",localizable:true,
		},
		"entry":{
			name:"entry",showName:(($ln==="CN")?("启动入口"):/*EN*/("Entry point")),type:"string",key:1,fixed:1,initVal:"",editType:"choice",
			icon:"ani.svg",rawEdit:false,
			getMenuItems:function(){
				let list,i,n,seg;
				let items=[];
				list=this.owner.segsList;
				n=list.length;
				for(i=0;i<n;i++){
					seg=list[i];
					if(seg.idVal.val){
						items.push({text:seg.idVal.val,valText:seg.idVal.val});
					}
				}
				return items;
			}
		},
		"autoStart":{
			name:"autoStart",showName:(($ln==="CN")?("自动启动"):/*EN*/("Auto start")),type:"bool",key:1,fixed:1,initVal:true,
		},
		"inBrowser":{
			name:"inBrowser",showName:(($ln==="CN")?("在浏览器执行"):/*EN*/("Run in browser")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false
		},
		"debug":{
			name:"debug",showName:(($ln==="CN")?("调试追踪"):/*EN*/("Debug trace")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
		},
		"apiArgs":{
			name:"apiArgs",showName:(($ln==="CN")?("调用参数"):/*EN*/("Arguments")),type:"object",def:"Object",icon:"args.svg",key:1,fixed:1,edit:false,navi:0,
			memberType:"object",memberDef:AgentArgDef,
		},
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",def:"Object",icon:"var_auto.svg",key:1,fixed:1,edit:false,navi:0,
			newAttrMode:"HudLocalVal",watchTree:true
		},
		"context":{
			name:"context",showName:(($ln==="CN")?("上下文"):/*EN*/("Agent context")),type:"object",def:"Object",icon:"db.svg",key:1,fixed:1,navi:0,
			memberType:"object",memberDef:AgentArgDef,
		},
		"globalMockup":{
			name:"globalMockup",showName:(($ln==="CN")?("全局上下文样板"):/*EN*/("Global context mockup")),type:"object",def:"Object",icon:"db.svg",key:1,fixed:1,edit:false,navi:0
		},
		"segs":{
			name:"segs",showName:(($ln==="CN")?("AI片段"):/*EN*/("AI Segments")),type:"array",icon:"array.svg",def:AISegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?("这是一个AI智能体。"):/*EN*/("This is an AI agent.")),
		},
		"exportAPI":{
			name:"exportAPI",showName:(($ln==="CN")?("输出API接口"):/*EN*/("Export as API")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:true,
		},
		"exportAddOn":{
			name:"exportAddOn",showName:(($ln==="CN")?("输出组件"):/*EN*/("Export as Add on")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:true,
		},
		"addOnOpts":{
			name:"addOnOpts",showName:(($ln==="CN")?("插件设置"):/*EN*/("AddOn Options")),type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:{
				title:"AddOn Options",label:"",
				properties:{
					name:{name:"name",label:"Code Name:",type:"string"},
					label:{name:"label",label:"Label:",type:"string"},
					path:{name:"path",label:"Import Path:",type:"string"},
					pathInHub:{name:"pathInHub",label:"Agent Node:",type:"string"},
					chatEntry:{
						name:"chatEntry",label:"Is Chat Entry:",type:"auto",defaultValue:false,
						choices:[
							{text:"Not chat entry",value:false},
							{text:"Entry tool agent",value:"Tool"},
							{text:"Root chat entry agent",value:"Root"},
						]
					},
					isChatApi:{name:"isChatApi",label:"Chat API:",type:"bool",defaultValue:true},
					isRPA:{name:"isRPA",label:"RPA Agent:",type:"bool",defaultValue:false},
					rpaHost:{name:"rpaHost",label:"RPA Host:",type:"string",defaultValue:""},
					segIcon:{name:"segIcon",label:"Icon:",type:"string"},
					catalog:{name:"catalog",label:"Catalog:",type:"string",defaultValue:"AI Call"},
					kind:{
						name:"kind",label:"Kind:",type:"string",defaultValue:"chat",
						choices:[
							{text:"Chat/LLM",value:"chat"},
							{text:"Image",value:"image"},
							{text:"Video",value:"video"},
							{text:"RPA",value:"rpa"},
							{text:"Text to speach",value:"tts"},
							{text:"Automatic speech recognition",value:"asr"},
							{text:"Code",value:"code"},
							{text:"Translate",value:"translate"},
							{text:"3D",value:"3d"},
							{text:"Search",value:"search"},
							{text:"Extract",value:"extract"},
							{text:"Moderate",value:"moderate"},
						]
					},
					capabilities:{
						name:"capabilities",label:"Capabilities:",type:"array",
						element:{
							"type":"string","label":'###:',"choices":[],
							getChoices:getKindCaps
						}
					},
					filters:{
						type:"array",label:"Filter:",initLength:0,
						element:{
							"type":"object","label":'###:',
							"class":{
								label:"Filter",
								properties:{
									key:{
										type:"string",label:"Key:",initValue:"","choices":[],
										getChoices:getKindFilters
									},
									value:{
										type:"auto",label:"Value:",initValue:"",
									}
								}
							}
						}
					},
					metrics:{
						type:"object",label:"Rank metrics:",initLength:0,
						"class":{
							label:"Rank metrics",
							properties:{
								quality:{
									type:"auto",label:"Quality:",initValue:5,
									desc:(($ln==="CN")?("质量，值域0～10，7相当于高水平人类"):/*EN*/("Quality, range 0~10, 7 equals a high-level human"))
								},
								costPerCall:{
									type:"auto",label:"Cost per call:",initValue:0,
									desc:(($ln==="CN")?("单次调用开销，美元为单位"):/*EN*/("Cost per call, in USD"))
								},
								costPer1M:{
									type:"auto",label:"Cost tokens:",initValue:5,
									desc:(($ln==="CN")?("每百万token开销，美元为单位"):/*EN*/("Cost per million tokens, in USD"))
								},
								speed:{
									type:"auto",label:"Speed:",initValue:5,
									desc:(($ln==="CN")?("调用速度，值域0～10，10代表即时/实时响应，0代表单次响应10分钟或更久"):/*EN*/("Invocation speed, range 0~10. 10 represents instant/real-time response, 0 means a single response takes 10 minutes or longer."))
								},
								size:{
									type:"auto",label:"Size:",initValue:0,
									desc:(($ln==="CN")?("模型尺寸，以MB为单位。"):/*EN*/("Model size, in MB."))
								},
							}
						}
					},
					meta:{name:"meta",label:"Meta:",type:"auto"},
				},
				newObject(){return VFACT.newUITemplateObj(this)},
			},
		},
	},
	objAttrs:{
		getLocalizableObjs(){
			return [this.getAttr("localVars"),this.getAttr("context"),this.getAttr("globalMockup"),this.segsVal]
		}
	}
};
//****************************************************************************
//:EditAIAgentDoc:
//****************************************************************************
DocAIAgent=function(owner,def,init){
	let self,objDef,app,args,context;
	self=this;
	EditDoc.call(this,owner,def,true);
	app=this.prj.app;
	this.isAIAgentDoc=true;
	objDef=this.objDef;
	//Agent dummy:
	this.agentVal=this.getAttr("agent");
	this.agentVal.getEditRootPpts=this.getEditRootPpts.bind(this);

	args=this.arguments=this.getAttr("apiArgs");
	//add argPxy:
	this.argProxy=new Proxy(new EditObjProxy(args),{
		get:function(tgt,key){
			var attr;
			if(key==="%EditObj"){
				return args;
			}
			if(key==="selfObj"){
				return ()=>{return args};
			}
			if(key===Symbol.toPrimitive){
				return ()=>"{EditObjAttr}";
			}
			attr=args.getAttr(key);
			if(attr){
				return attr.getAttrVal("mockup");
			}
			return undefined;
		},
		set:function(tgt,key,val){
			throw new Error(`Can not set attrib "${key}" on Agent arguments proxy.`);
		}
	});
	
	//Context:
	context=this.context=this.getAttr("context");
	//add ctxPxy:
	this.contextProxy=new Proxy(new EditObjProxy(context),{
		get:function(tgt,key){
			var attr;
			if(key==="%EditObj"){
				return context;
			}
			if(key==="selfObj"){
				return ()=>{return args};
			}
			if(key===Symbol.toPrimitive){
				return ()=>"{EditObjAttr}";
			}
			attr=context.getAttr(key);
			if(attr){
				return attr.getAttrVal("mockup");
			}
			return undefined;
		},
		set:function(tgt,key,val){
			throw new Error(`Can not set attrib "${key}" on Agent context proxy.`);
		}
	});
	
	
	//Sub segs:
	this.segsVal=this.getAttr("segs");
	this.segsList=this.segsVal.attrList;
	this.naviState={
		hotItem:null
	};
	function OnAgentExec(jaxId,name){
		if(jaxId===self.jaxId){
			self.resetDebugTrace();
		}
	}
	function OnAgentEnd(jaxId,name){
	}
	function OnSegExec(agentId,orgSegJaxId,outletJaxId,execSegJaxId,input,newSeqId){
		if(agentId===self.jaxId){
			self.traceSegExec(orgSegJaxId,outletJaxId,execSegJaxId,input,newSeqId);
		}
	}
	function OnSegEnd(agentId,segJaxId,result,orgSeqId){
		if(agentId===self.jaxId){
			self.traceSegEnd(segJaxId,result,orgSeqId);
		}
	}
	function OnSegCallLLMResult(agentId,segJaxId,result,callId,usage){
		if(agentId===self.jaxId){
			self.traceSegLLMResult(segJaxId,result,callId,usage);
		}
	}
	function OnSegCallLLMInput(agentId,segJaxId,input,callId){
		if(agentId===self.jaxId){
			self.traceSegLLMInput(segJaxId,input,callId);
		}
	}
	function OnAIDebugLog(agentId,segJaxId,log){
		if(agentId===self.jaxId){
			self.traceDebugLog(segJaxId,log);
		}
	}
	function updateTrace(){
		if(self.debugAttr.val){
			app.on("AIAgentExec",OnAgentExec);
			app.on("AIAgentEnd",OnAgentEnd);
			app.on("AISegExec",OnSegExec);
			app.on("AISegEnd",OnSegEnd);
			app.on("AISegCallLLMInput",OnSegCallLLMInput);
			app.on("AISegCallLLMResult",OnSegCallLLMResult);
			app.on("AIDebugLog",OnAIDebugLog);
		}else{
			self.resetDebugTrace();
			app.off("AIAgentExec",OnAgentExec);
			app.off("AIAgentEnd",OnAgentEnd);
			app.off("AIAISegExec",OnSegExec);
			app.off("AISegEnd",OnSegEnd);
			app.off("AISegCallLLMInput",OnSegCallLLMInput);
			app.off("AISegCallLLMResult",OnSegCallLLMResult);
			app.off("AIDebugLog",OnAIDebugLog);
		}
	}
	this.debugAttr=this.getAttr("debug");
	this.debugAttr.traceOn(updateTrace);
	updateTrace();
};
inherits(DocAIAgent,EditDoc);
docAIAgent=DocAIAgent.prototype;
EditDoc.regDocDef("DocAIAgent",DocAIAgentDef);
DocAIAgentDef.constructFunc=DocAIAgent;

//****************************************************************************
//:I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.loadFromCodeSaveVO=function(vo){
		let list,i,n,seg;
		EditDoc.prototype.loadFromCodeSaveVO.call(this,vo);
		list=this.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			seg.postLoadLink();
		}
		if(this.dataDoc){
			this.dataDoc.on("Blured",()=>{this.OnDocBlur();});
		}
		return vo;
	};
}

//****************************************************************************
//:Seg access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.runOnAllSegs=function(func,...args){
		let seg;
		for(seg of this.segsList){
			func(seg,...args);
		}
	};
}

//****************************************************************************
//:Edit hud:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.findSeg=function(jaxId,segsList){
		let seg,findSeg;
		segsList=segsList||this.segsList;;
		for(seg of segsList){
			if(seg.jaxId===jaxId){
				return seg;
			}
			if(seg.segsList){
				findSeg=this.findSeg(jaxId,seg.segsList);
				if(findSeg){
					return findSeg;
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	docAIAgent.dropSegLiveObjs=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.dropLiveObj();
		}
	};
	
	//-----------------------------------------------------------------------
	docAIAgent.renderPath=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.renderPath();
		}
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.getEditRootPpts=function(){
		let list=[];
		if(this.path.endsWith(".js")){
			list.push({attr:this.getAttr("inBrowser")});
		}
		list.push({obj:this.getAttr("apiArgs"),open:true});
		list.push({obj:this.getAttr("localVars"),open:true});
		list.push({obj:this.getAttr("globalMockup")});
		list.push({obj:this.getAttr("context"),open:true});
		list.push({attr:this.getAttr("entry")});
		list.push({attr:this.getAttr("showName")});
		list.push({attr:this.getAttr("exportAPI")});
		list.push({attr:this.getAttr("exportAddOn")});
		list.push({attr:this.getAttr("addOnOpts")});
		list.push({attr:this.getAttr("debug")});
		list.push({attr:this.getAttr("desc")});
		return list;
	};

	//------------------------------------------------------------------------
	docAIAgent.getNaviDocRoot=function(){
		let list=[];
		list.push(this.agentVal);
		list.push(this.segsVal);
		return list;
	};

	//------------------------------------------------------------------------
	docAIAgent.naviDocReady=function(){
		let naviBox,treeBox,state,obj;
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let selected,obj,node;
			obj=state.hotItem;
			if(obj){
				this.prj.setEditSubObj(obj);
			}
		}
	};

	//------------------------------------------------------------------------
	docAIAgent.OnDocBlur=function(){
		let naviBox,treeBox,state;
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let node;
			treeBox=naviBox.treeBox;
			node=treeBox.hotNode;
			state.hotItem=node?node.nodeObj:null;
		}
	};
}

//****************************************************************************
//:Debug trace:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.getSegByJaxId=function(jaxId){
		let list,seg;
		list=this.segsList;
		for(seg of list){
			if(seg.jaxId===jaxId){
				return seg;
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	docAIAgent.resetDebugTrace=function(){
		let seg;
		for(seg of this.segsList){
			seg.resetDebugTrace();
		}
	};
	
	//-----------------------------------------------------------------------
	docAIAgent.traceSegExec=function(seg1Id,outletId,seg2Id,input,newSeqId){
		let seg1,seg2;
		seg1=this.getSegByJaxId(seg1Id);
		seg2=this.getSegByJaxId(seg2Id);
		if(seg1){
			seg1.traceOutlet(outletId);
		}
		if(seg2){
			seg2.traceInput(input,newSeqId);
		}
	};
	
	//-----------------------------------------------------------------------
	docAIAgent.traceSegEnd=function(segId,result,orgSeqId){
		let seg;
		seg=this.getSegByJaxId(segId);
		if(seg){
			seg.traceResult(result,orgSeqId);
		}
	};
	
	//-----------------------------------------------------------------------
	docAIAgent.traceSegLLMInput=function(segId,input,callId){
		let seg;
		seg=this.getSegByJaxId(segId);
		if(seg){
			seg.traceLLMInput(input,callId);
		}
	};

	//-----------------------------------------------------------------------
	docAIAgent.traceSegLLMResult=function(segId,result,callId,usage){
		let seg;
		seg=this.getSegByJaxId(segId);
		if(seg){
			seg.traceLLMResult(result,callId,usage);
		}
	};
	
	//-----------------------------------------------------------------------
	docAIAgent.traceDebugLog=function(segId,log){
		let seg;
		seg=this.getSegByJaxId(segId);
		if(seg){
			seg.traceDebugLog(log);
		}
	};
}

export {DocAIAgent,AgentArgDef};