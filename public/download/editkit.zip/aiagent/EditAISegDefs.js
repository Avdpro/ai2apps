import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditAISeg,EditAISegOutlet} from "./EditAISeg.js";
import {AgentArgDef} from "./EditAIAgentDoc.js";
import {tabNT} from "/@tabos/tabos_nt.js";
import {webFetch} from "/@tabos/utils/webAPI.js";
import pathLib from "/@path";
const $ln=VFACT.lanCode;
const app=VFACT.app;
const updateContextAttr={
	name:"context",showName:(($ln==="CN")?("更新上下文"):/*EN*/("Update context")),type:"object",def:"Object",icon:"idcard.svg",key:1,fixed:1,edit:1,
	attrs:{
		"cast":{
			name:"cast",showName:(($ln==="CN")?("变量映射"):/*EN*/("Variable Mapping")),type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:function(attrObj){
				let doc,seg,ctx,template,ppts,list,attr,ao;
				seg=attrObj.owner;
				doc=seg.doc;
				ctx=doc.context;
				ppts={};
				ao=seg.objDef.attrOutlets||["input","result"];
				ao=ao.map(item=>{return typeof(item==="string")?{text:item,value:item}:item;});
				list=ctx.attrList;
				for(attr of list){
					ppts[attr.name]={type:"string",label:attr.name+": ",choices:ao};
				}
				template={title:attrObj.def.showName,label:"",properties:ppts};
				return template;
			}
		}
	}
};
const updateGlobalAttr={
	name:"global",showName:(($ln==="CN")?("更新全局上下文"):/*EN*/("Update global context")),type:"object",def:"Object",icon:"idcard.svg",key:1,fixed:1,edit:1,
	attrs:{
		"cast":{
			name:"cast",showName:(($ln==="CN")?("变量映射"):/*EN*/("Variable Mapping")),type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:function(attrObj){
				let doc,seg,ctx,template,ppts,list,attr,ao;
				seg=attrObj.owner.owner;
				doc=seg.doc;
				ctx=doc.getAttr("globalMockup");
				ppts={};
				ao=attrObj.objDef.attrOutlets||["input","result"];
				ao=ao.map(item=>{return typeof(item==="string")?{text:item,value:item}:item;});
				list=ctx.attrList;
				for(attr of list){
					ppts[attr.name]={type:"string",label:attr.name+": ",choices:ao};
				}
				template={title:attrObj.def.showName,label:"",properties:ppts};
				return template;
			}
		}
	}
};

const SegOutletDef={
	name:"AISegOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Result",
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("输出节点。"):/*EN*/("Outlet.")),
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(SegOutletDef);
EditAISegOutlet.SegOutletDef=SegOutletDef;
const SegOutletArrayDef={elementType:"aioutlet",elementDef:"AISegOutlet",allowExtraAttr:1};
EditAISegOutlet.SegOutletArrayDef=SegOutletArrayDef;

const FlowOutletDef={
	name:"AIFlowOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		...SegOutletDef.attrs,
		"output":{
			name:"output",showName:(($ln==="CN")?("输出内容"):/*EN*/("Output")),type:"string",key:1,fixed:1,initVal:"",export:false,localizable:true,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
		},
		"context":updateContextAttr,
		"global":updateGlobalAttr,
	},
	listHint:[
		"id","output","codes","context","global",
	],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(FlowOutletDef);
const FlowOutletArrayDef={elementType:"aioutlet",elementDef:FlowOutletDef,allowExtraAttr:1};
EditAISegOutlet.FlowOutletDef=FlowOutletDef;

const ConditionOutletDef={
	name:"AIConditionOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		...FlowOutletDef.attrs,
		"condition":{
			name:"condition",showName:(($ln==="CN")?("判断条件"):/*EN*/("Condition")),type:"string",key:1,fixed:1,initVal:"",export:false,
		},
	},
	listHint:[
		"id","condition","output","codes","context","global","desc",
	],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(ConditionOutletDef);
EditAISegOutlet.ConditionOutletDef=ConditionOutletDef;
const CoditionOutletArrayDef={elementType:"aioutlet",elementDef:ConditionOutletDef,allowExtraAttr:1};
EditAISegOutlet.CoditionOutletArrayDef=CoditionOutletArrayDef;

const AgentAskOutletDef={
	name:"AIAgentAskOutlet",icon:"outlet.svg",
	attrs:{
		...FlowOutletDef.attrs,
		"id":{...FlowOutletDef.attrs.id,initVal:"Ask"},
		"desc":{...FlowOutletDef.attrs.desc,initVal:(($ln==="CN")?("回复智能体执行时提出问题的路径"):/*EN*/("The path taken when replying to the agent's query"))},
	},
	listHint:[
		"id","output","codes","desc",
	],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(AgentAskOutletDef);
EditAISegOutlet.AgentAskOutletDef=AgentAskOutletDef;
const AgentAskOutletArrayDef={elementType:"aioutlet",elementDef:AgentAskOutletDef,allowExtraAttr:"1"};
EditAISegOutlet.AgentAskOutletArrayDef=AgentAskOutletArrayDef;

const CodeOutletDef={
	name:"CodOutlet",icon:"outlet.svg",
	attrs:{
		...FlowOutletDef.attrs,
		"id":{...FlowOutletDef.attrs.id,initVal:"Outlet"},
	},
	listHint:[
		"id","output","codes","desc",
	],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(CodeOutletDef);
EditAISegOutlet.CodeOutletDef=CodeOutletDef;
const CodeOutletArrayDef={elementType:"aioutlet",elementDef:CodeOutletDef,allowExtraAttr:1};
EditAISegOutlet.CodeOutletArrayDef=CodeOutletArrayDef;


const SampleOutletDef={
	name:"AISampleOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Sample",
		},
		"input":{
			name:"input",showName:(($ln==="CN")?("执行条件"):/*EN*/("Condition")),type:"auto",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",export:false,
		},
		"key":{
			name:"key",showName:(($ln==="CN")?("结果项名称"):/*EN*/("Result key")),type:"string",initVal:"",key:1,fixed:1,edit:1,
		},
		"survey":{
			name:"survey",showName:(($ln==="CN")?("记录结果"):/*EN*/("Survey")),type:"bool",initVal:true,key:1,fixed:1,edit:1,rawEdit:false,export:false,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?("输出节点。"):/*EN*/("Condition outlet.")),
		}
	},
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(SampleOutletDef);
const SampleOutletArrayDef={elementType:"aioutlet",elementDef:SampleOutletDef,allowExtraAttr:1};

//------------------------------------------------------------------------
const ButtonOutletDef={
	name:"AIButtonOutlet",allowExtraAttr:false,icon:"outlet.svg",
	attrs:{
		...SegOutletDef.attrs,
		"text":{
			name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",initVal:"Button",key:1,fixed:1,edit:1,export:false,localizable:true,
		},
		"result":{
			name:"result",showName:(($ln==="CN")?("输出"):/*EN*/("Result")),type:"string",initVal:"",key:1,fixed:1,edit:1,export:false,localizable:true,
		},
		"icon":{
			name:"icon",showName:(($ln==="CN")?("图标"):/*EN*/("Icon")),type:"file",isURL:true,initVal:"/~/-tabos/shared/assets/hudbox.svg",key:0,fixed:1,
		},
		"emoji":{
			name:"emoji",showName:(($ln==="CN")?("表情符号"):/*EN*/("Emoji")),type:"string",initVal:"",key:0,fixed:1,
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
		},
		"context":updateContextAttr,
		"global":updateGlobalAttr,
	},
	listHint:[
		"id","text","result","icon","emoji","codes","context","global","desc"
	],
	objAttrs:{
		isAIOutlet:true
	}
};
EditAISegOutlet.regDef(ButtonOutletDef);
const ButtonOutletArrayDef={
	elementType:"aioutlet",elementDef:ButtonOutletDef,allowExtraAttr:3,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{...ButtonOutletDef.attrs.id,initVal:"Button1"},
					"text":{...ButtonOutletDef.attrs.text,initVal:"OK"},
				},
			}
		},
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{...ButtonOutletDef.attrs.id,initVal:"Button2"},
					"text":{...ButtonOutletDef.attrs.text,initVal:"Cancel"},
				},
			}
		},
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{...ButtonOutletDef.attrs.id,initVal:"Button3"},
					"text":{...ButtonOutletDef.attrs.text,initVal:""},
				},
			}
		},
	]
};
const MenuOutletArrayDef={
	elementType:"aioutlet",elementDef:ButtonOutletDef,allowExtraAttr:1,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item1"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",initVal:"Item 1",key:1,fixed:1,edit:1,rawEdit:false,export:false,localizable:true,},
				}
			}
		},
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item2"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",initVal:"Item 2",key:1,fixed:1,edit:1,rawEdit:false,export:false,localizable:true,},
				}
			}
		},
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Item3"},
					"text":{name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",initVal:"Item 3",key:1,fixed:1,edit:1,rawEdit:false,export:false,localizable:true,},
				}
			}
		},
	]
};
const CallAgentOutletArrayDef={
	elementType:"aioutlet",elementDef:ButtonOutletDef,allowExtraAttr:1,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...ButtonOutletDef,
				attrs:{
					...ButtonOutletDef.attrs,
					"id":{...ButtonOutletDef.attrs.id,initVal:"Ask"},
					"text":{...ButtonOutletDef.attrs.text,initVal:"OK"},
				},
			}
		}
	]
};

const SegTraceLogDef={
	name:"AISegTraceLog",allowExtraAttr:false,icon:"chat.svg",
	attrs:{
		"input":{name:"input",showName:"Input",type:"auto",key:1,fixed:1,initVal:"",editType:"note",readOnly:true},
		"output":{name:"output",showName:"Output",type:"auto",key:1,fixed:1,initVal:"",editType:"note",readOnly:true},
	},
	objAttrs:{
		getName(){
			return (($ln==="CN")?("调用记录"):/*EN*/("Call log"));
		}
	}
};
EditObj.regDef("AISegTraceLog",SegTraceLogDef);
const TraceLogArrayDef={icon:"files.svg",elementType:"object",elementDef:SegTraceLogDef,allowExtraAttr:false};

//------------------------------------------------------------------------
//Preset message for LLM Call Seg
const AIPresetMsgDef={
	name:"AIPresetMsg",allowExtraAttr:false,icon:"chat.svg",
	attrs:{
		"role":{
			name:"role",showName:"Role",type:"choice",key:1,fixed:1,initVal:"user",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
			],valueType:"string"
		},
		"content":{name:"content",showName:"Content",type:"string",key:1,fixed:1,initVal:"",editType:"note",localizable:true},
	},
	objAttrs:{
		getName(){
			return (($ln==="CN")?("预置消息"):/*EN*/("Preset message"));
		}
	}
};
EditObj.regDef("AIPresetMsg",AIPresetMsgDef);
const AIPresetArrayDef={icon:"files.svg",elementType:"object",elementDef:AIPresetMsgDef,allowExtraAttr:true};

//------------------------------------------------------------------------
//Preset message for LLM Call Seg
const GPTCheatDef={
	name:"GPTCheat",allowExtraAttr:false,icon:"gas.svg",
	attrs:{
		"prompt":{
			name:"prompt",showName:"Prompt",type:"string",key:1,fixed:1,initVal:"",
		},
		"reply":{name:"reply",showName:"Reply",type:"string",key:1,fixed:1,initVal:"",localizable:true},
	},
	objAttrs:{
		getName(){
			return (($ln==="CN")?("GPT Cheat"):/*EN*/("GPT Cheat"));
		}
	}
};
EditObj.regDef("GPTCheat",GPTCheatDef);
const GPTCheatArrayDef={icon:"array.svg",elementType:"object",elementDef:GPTCheatDef,allowExtraAttr:true};

//------------------------------------------------------------------------
//Process message:
const ProcessMsgDef={
	name:"ProcessMsg",allowExtraAttr:false,icon:"hudstate.svg",
	attrs:{
		"text":{
			name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",key:1,fixed:1,initVal:"",
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
				["log","Log","Log"],
			],valueType:"string"
		},
		"roleText":{
			name:"roleText",showName:(($ln==="CN")?("角色文本"):/*EN*/("Role Text")),type:"string",key:1,fixed:0,initVal:"",
		},
		"codes":{
			name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
			info:(($ln==="CN")?("是否在组件内包含额外的自定义代码，通常在进入、离开组件的时候，用于处理输入、输出数据等。"):/*EN*/("Whether there is additional custom code inside the seg, usually used to handle input, output data when entering or leaving the seg."))
		},
	},
	objAttrs:{
		getName(){
			return (($ln==="CN")?("进度消息"):/*EN*/("Process message"));
		}
	}
};
EditObj.regDef("ProcessMsg",ProcessMsgDef);


const SegObjBaseAttr={
	"id":{
		name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,
		checkAttrText:function(text){
			let curSeg,seg,obj,segList;
			if(!text){
				return true;//Can clear
			}
			curSeg=obj=this.owner;
			while(obj && !obj.segsVal){
				obj=obj.owner;
			}
			if(!obj){
				return true;//??
			}
			segList=obj.segsList;
			for(seg of segList){
				if(seg.attrHash.id.val===text && seg!==curSeg){
					window.alert((($ln==="CN")?("这个 ID 已被其它组建占用."):/*EN*/("This ID is used by other seg.")));
					return false;
				}
			}
			return true;
		}
	},
	"viewName":{
		name:"viewName",showName:(($ln==="CN")?("显示名称"):/*EN*/("View Name")),type:"string",key:1,fixed:1,initVal:"",localizable:true,export:false,edit:false
	},
	"label":{
		name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"",localizable:true,export:false,edit:false
	},
	"x":{
		name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
	},
	"y":{
		name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
	},
	"desc":{
		name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,initVal:(($ln==="CN")?("这是一个AISeg。"):/*EN*/("This is an AISeg.")),export:false,
	},
	"codes":{
		name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
		info:(($ln==="CN")?("是否在组件内包含额外的自定义代码，通常在进入、离开组件的时候，用于处理输入、输出数据等。"):/*EN*/("Whether there is additional custom code inside the seg, usually used to handle input, output data when entering or leaving the seg."))
	},
	"mkpInput":{
		name:"mkpInput",showName:(($ln==="CN")?("输入(样板)"):/*EN*/("Mockup input")),type:"string",initVal:"$$input$$",key:1,fixed:1,edit:1,rawEdit:false,export:false,
	},
	"mkpResult":{
		name:"mkpResult",showName:(($ln==="CN")?("输出(样板)"):/*EN*/("Mockup result")),type:"string",initVal:"$$result$$",key:0,fixed:1,edit:1,rawEdit:false,export:false,
	},
	"traceLogs":{
		name:"traceLogs",showName:"Trace logs",type:"array",def:TraceLogArrayDef,key:1,fixed:1,save:false
	},
	"segMark":{
		name:"segMark",showName:(($ln==="CN")?("开发标记"):/*EN*/("Dev. mark")),type:"choice",initVal:"",edit:false,key:1,fixed:1,export:false,
		vals:[
			["","None","None"],
			["check_fat.svg","Checked","Checked"],
			["working.svg","Working","Working"],
			["flag.svg","Flag","Flag"],
			["event.svg","Notify","Notify"],
			["faces.svg","Review","Review"],
			["lab.svg","Test","Test"],
			["run.svg","Run","Run"],
			["pin.svg","Pin","Pin"],
			["lint_bug.svg","Bug","Bug"],
			["link.svg","Link","Link"],
			["trash.svg","Trash","Trash"],
		]
	},
};
EditAISeg.SegObjBaseAttr=SegObjBaseAttr;
const SegObjShellAttr={
	...SegObjBaseAttr,
	"context":updateContextAttr,
	"global":updateGlobalAttr,
};
EditAISeg.SegObjShellAttr=SegObjShellAttr;

//************************************************************************
//:Define catalogs:
//************************************************************************
EditAISeg.regCatalog({
	name:"Common",showName:(($ln==="CN")?("常用"):/*EN*/("Common"))
});

EditAISeg.regCatalog({
	name:"AI Call",showName:(($ln==="CN")?("AI 调用"):/*EN*/("AI Call"))
});

EditAISeg.regCatalog({
	name:"Interactive",showName:(($ln==="CN")?("交互/输出"):/*EN*/("Interactive"))
});

EditAISeg.regCatalog({
	name:"Flow",showName:(($ln==="CN")?("流程控制"):/*EN*/("Flow Control"))
});

EditAISeg.regCatalog({
	name:"Code",showName:(($ln==="CN")?("代码"):/*EN*/("Code"))
});

//************************************************************************
//:Define segs:
//************************************************************************
//------------------------------------------------------------------------
//:AISeg that ask user to input chat:
EditAISeg.regDef({
	name:"askChat",showName:(($ln==="CN")?("聊天输入"):/*EN*/("User Chat")),icon:"chat.svg",catalog:["Common","Interactive"],
	attrs:{
		...SegObjShellAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:0,fixed:1,edit:false,initVal:"Please input",localizable:true,
		},
		"tip":{
			name:"tip",showName:(($ln==="CN")?("提示文本"):/*EN*/("Tip text")),type:"string",key:1,fixed:1,initVal:"",localizable:true,
		},
		"tipRole":{
			name:"tipRole",showName:(($ln==="CN")?("提示角色"):/*EN*/("Tip role")),type:"choice",key:1,fixed:1,initVal:"assistant",localizable:true,
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
			],valueType:"string"
		},
		"placeholder":{
			name:"placeholder",showName:(($ln==="CN")?("占位提示"):("Placeholder")),type:"string",initVal:"",hideVal:1,key:1,fixed:1,localizable:true
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("默认输入文本"):("Init text")),type:"string",initVal:"",hideVal:1,key:1,fixed:1,localizable:true
		},
		"file":{
			name:"file",showName:(($ln==="CN")?("允许文件"):/*EN*/("Allow file")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"showText":{
			name:"showText",showName:(($ln==="CN")?("在对话中显示"):/*EN*/("Show in chat")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
		},
		"askUpward":{
			name:"askUpward",showName:(($ln==="CN")?("询问上级Agent"):/*EN*/("Ask upward")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:false,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","tip","tipRole","placeholder","text","showText","file","askUpward","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that call a LLM / GPT:
let sysLLMPlatforms={};
let callLLM={
	name:"callLLM",showName:(($ln==="CN")?("调用LLM"):/*EN*/("Call LLM")),icon:"llm.svg",catalog:["Common","AI Call"],
	attrs:{
		...SegObjShellAttr,
		"platform":{
			name:"platform",showName:(($ln==="CN")?("AI平台"):/*EN*/("Platform")),type:"choice",key:1,fixed:1,initVal:"OpenAI",
			getMenuItems:async function(){
				let res,list;
				res=await tabNT.makeCall("AIGetPlatforms",{});
				if(!res||res.code!==200){
					return [
						["OpenAI","OpenAI","OpenAI"],
						["Google","Google","Google"],
						["Claude","Claude","Claude"],
						["Ollama","Ollama","Ollama"],
					].map((item)=>{
						return {text:item[2],valText:item[1],value:item[0]};
					});
				}
				list=res.platforms;
				return list.map((item)=>{
					return {text:item,valText:item,value:item};
				});
			},
			valueType:"string"
		},
		"mode":{
			name:"mode",showName:(($ln==="CN")?("AI模型"):/*EN*/("Mode")),type:"choice",key:1,fixed:1,initVal:"gpt-3.5-turbo",
			getMenuItems:async function(){
				let platform;
				platform=this.owner.getAttrVal("platform");
				let res=await tabNT.makeCall("AIGetModels",{platform:platform});
				if(res && res.code===200){
					let list=res.models;
					list=list.map((item)=>{
						return {text:item.label,valText:item.model,value:item.model};
					});
					return list;
				}
				switch(platform){
					default:
					case "OpenAI":{
						return [
							["gpt-3.5-turbo","GPT-3.5","GPT-3.5"],
							["gpt-3.5-turbo-16k","GPT-3.5-16K","GPT-3.5-16K"],
							["gpt-3.5-turbo-1106","GPT-3.5 Turbo","GPT-3 Turbo 16K"],
							["gpt-4","GPT-4","GPT-4"],
							["gpt-4-turbo-preview","GPT-4 Turbo Preview","GPT-4 Turbo Preview"],
							["gpt-4-1106-preview","GPT-4 Turbo","GPT-4 Turbo"],
						].map((item)=>{
							return {text:item[2],valText:item[1],value:item[0]};
						});
					}
					case "Google":{
						return [
							["gemini-pro","Gemini Pro","Gemini Pro"],
						].map((item)=>{
							return {text:item[2],valText:item[1],value:item[0]};
						});
					}
					case "Claude":{
						return [
							["claude-3-sonnet-20240229","Claude 3 Sonnet","Claude 3 Sonnet"],
							["claude-3-opus-20240229","Claude 3 Opus","Claude 3 Opus"],
						].map((item)=>{
							return {text:item[2],valText:item[1],value:item[0]};
						});
					}
				}
			},
			vals:[
				["gpt-3.5-turbo","GPT-3.5","GPT-3.5"],
				["gpt-3.5-turbo-16k","GPT-3.5-16K","GPT-3.5-16K"],
				["gpt-3.5-turbo-1106","GPT-3.5 Turbo","GPT-3 Turbo 16K"],
				["gpt-4","GPT-4","GPT-4"],
				["gpt-4-turbo-preview","GPT-4 Turbo Preview","GPT-4 Turbo Preview"],
				["gpt-4-1106-preview","GPT-4 Turbo","GPT-4 Turbo"],
				["gemini-pro","Gemini Pro","Gemini Pro"],
				["claude-3-sonnet-20240229","Claude 3 Sonnet","Claude 3 Sonnet"],
				["claude-3-opus-20240229","Claude 3 Opus","Claude 3 Opus"],
			],valueType:"string"
		},
		"system":{
			name:"system",showName:(($ln==="CN")?("系统设定"):/*EN*/("System Prompt")),type:"string",key:1,fixed:1,initVal:"You are a smart assistant.",editType:"note",localizable:true,
		},
		"temperature":{
			name:"temperature",showName:"Temperature",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.05,minVal:0,maxVal:2,valFixDigit:2
		},
		"maxToken":{
			name:"maxToken",showName:"MaxToken",type:"int",editType:"range",key:1,fixed:1,editMode:"range",step:50,minVal:0,maxVal:36000,initVal:2000,valFixDigit:0,
			getMaxVal:function(){
				let model=this.owner.getAttrVal("mode");
				switch(model){
					case "gpt-3.5-turbo":
						return 4096;
					case "gpt-3.5-turbo-16k":
						return 16*1024;
					case "gpt-4":
						return 8*1024;
					case "gpt-4-32K":
						return 32*1024;
					case "gpt-4-1106-preview":
						return 4*1024;
				}
				return 32*1024;
			}
		},
		"topP":{
			name:"topP",showName:"Top P",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:1.0,initVal:1,valFixDigit:2,
		},
		"fqcP":{
			name:"fqcP",showName:"Frequency penalty",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:2.0,initVal:0,valFixDigit:2,
		},
		"prcP":{
			name:"prcP",showName:"Presence penalty",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:2.0,initVal:0,valFixDigit:2,
		},
		"messages":{
			name:"messages",showName:(($ln==="CN")?("预置对话"):/*EN*/("Messages")),key:1,fixed:1,initVal:"",
			type:"array",def:AIPresetArrayDef,
		},
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示(Prompt)"):/*EN*/("Prompt")),type:"string",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",editType:"note",
		},
		"seed":{
			name:"seed",showName:(($ln==="CN")?("种子"):/*EN*/("Seed")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"secret":{
			name:"secret",showName:(($ln==="CN")?("隐藏过程"):/*EN*/("secret")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:false,
		},
		"allowCheat":{
			name:"allowCheat",showName:(($ln==="CN")?("使用GPT Cheat"):/*EN*/("Use GPT Cheat")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:false,
		},
		"GPTCheats":{
			name:"GPTCheats",showName:(($ln==="CN")?("GPT Cheat"):/*EN*/("GPT Cheat")),type:"array",def:GPTCheatArrayDef,fixed:1,key:1
		},
		"shareChatName":{
			name:"shareChatName",showName:(($ln==="CN")?("共享对话"):/*EN*/("Share Messages")),type:"string",key:1,fixed:1,initVal:"",
			info:"把对话内容作为 Agent 的`上下文变量`，这样可以在多个LLM组件中共享对话过程。",
		},
		"keepChat":{
			name:"keepChat",showName:(($ln==="CN")?("记忆对话"):/*EN*/("Keep history")),type:"choice",key:1,fixed:1,initVal:0,rawEdit:false,
			vals:[
				[0,"No",(($ln==="CN")?("不记录"):/*EN*/("No"))],
				[4,"4 messages",(($ln==="CN")?("最近的4条"):/*EN*/("4 messages"))],
				[10,"10 messages",(($ln==="CN")?("最近的10条"):/*EN*/("10 messages"))],
				[20,"20 messages",(($ln==="CN")?("最近的20条"):/*EN*/("20 messages"))],
				[50,"50 messages",(($ln==="CN")?("最近的50条"):/*EN*/("50 messages"))],
				[200,"All messages",(($ln==="CN")?("全部记录"):/*EN*/("All messages"))],
			],valueType:"int"
		},
		"clearChat":{
			name:"clearChat",showName:(($ln==="CN")?("精简对话"):/*EN*/("Shorten message")),type:"choice",key:1,fixed:1,initVal:2,rawEdit:false,
			info:(($ln==="CN")?("在清理记忆的时候，删除多少条对话"):/*EN*/("When clearing memory, delete how many conversations")),
			vals:[
				[2,"2",(($ln==="CN")?("最早的2条"):/*EN*/("Top 2 messages"))],
				[6,"6 messages",(($ln==="CN")?("最早的6条"):/*EN*/("Top 6 messages"))],
				[10,"10 messages",(($ln==="CN")?("最早的10条"):/*EN*/("Top 10 messages"))],
				[20,"20 messages",(($ln==="CN")?("最早的20条"):/*EN*/("Top 20 messages"))],
			],valueType:"int"
		},
		"inputPrefix":{
			name:"inputPrefix",showName:(($ln==="CN")?("输入前缀修饰"):/*EN*/("Prompt prefix")),type:"string",key:0,fixed:1,initVal:"",edit:false,
		},
		"inputPostfix":{
			name:"inputPostfix",showName:(($ln==="CN")?("输入后缀修饰"):/*EN*/("Prompt postfix")),type:"string",key:0,fixed:1,initVal:"",edit:false,
		},
		"apiFiles":{
			name:"apiFiles",showName:(($ln==="CN")?("GPT API函数文件组"):/*EN*/("GPT API Files")),type:"array",def:"FileArray",fixed:1,key:1
		},
		"parallelFunction":{
			name:"parallelFunction",showName:(($ln==="CN")?("平行函数调用"):/*EN*/("Parallel Function")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:false,
			info:"OpenAI实验功能，目前只有部分模型支持，请参考OpenAI的说明。"
		},
		"responseFormat":{
			name:"responseFormat",showName:(($ln==="CN")?("回复格式"):/*EN*/("Response format")),type:"choice",fixed:1,key:1,initVal:"text",rawEdit:false,
			vals:[
				["text","text","Text"],
				["json_object","json_object","JSON"],
			],valueType:"string"
		},
		"formatDef":{
			name:"formatDef",showName:(($ln==="CN")?("JSON格式"):/*EN*/("Arguments")),type:"choice",key:1,fixed:1,initVal:"",rawEdit:false,
			vals:[[null,"null","null"]],
			val2ShowText(val){
				let tmp;
				if(val===null){
					return null;
				}
				tmp=VFACT.getEditUITemplate(val);
				if(tmp){
					return tmp.label||tmp.name;
				}
				return val;
			},
			getMenuItems:function(attrObj){
				let items=[{text:"null",valText:"null"}];
				let tmps=VFACT.getEditUITemplates();
				for(let tmpName in tmps){
					let tmp=tmps[tmpName];
					if(tmp instanceof Function){
						tmp=tmp();
					}
					if(tmp){
						items.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
					}
				}
				return items;
			}
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,export:false,readOnly:true,
			initVal:(($ln==="CN")?("执行一次LLM调用。"):/*EN*/("Excute a LLM call.")),
		},
		"process":{
			name:"process",showName:"Process",type:"object",def:ProcessMsgDef,key:0,fixed:1
		}
	},
	listHint:[
		"id","viewName","mkpInput","platform","mode",
		{name:"parameter",showName:(($ln==="CN")?("调用参数"):("Call Parameters")),attrs:["maxToken","temperature","topP","fqcP","prcP","seed",]},
		"system","messages","prompt",
		{
			name:"advanced",showName:(($ln==="CN")?("高级设置"):("Advanced Settgins")),
			attrs:["responseFormat","formatDef","shareChatName","secret","keepChat","clearChat","apiFiles","parallelFunction","allowCheat","GPTCheats","context","global",]
		},
		"process","codes","desc","traceLogs",
	]
};
EditAISeg.regDef(callLLM);

//------------------------------------------------------------------------
//:AISeg that output text content to user:
EditAISeg.regDef({
	name:"output",showName:(($ln==="CN")?("文本输出"):/*EN*/("Output")),icon:"hudtxt.svg",catalog:["Common","Interactive"],
	attrs:{
		...SegObjShellAttr,
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
				["log","Log","Log"],
			],valueType:"string"
		},
		"channel":{
			name:"channel",showName:(($ln==="CN")?("通道"):/*EN*/("Channel")),type:"choice",key:1,fixed:1,initVal:"Chat",
			vals:[
				["Chat","Chat","Chat"],
				["Process","Process","Process"],
			],valueType:"string"
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("输出内容"):/*EN*/("Content")),type:"string",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",localizable:true,
			usage:`"text"属性是是显示的内容，可以用"#"开头的代码。例如：要直接显示input的内容："#input"；如果input是一个对象想展示内容：#JSON.stringify(input)。`
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","role","text","channel","codes","context","global","desc",
	],
	genAttrs:["id","role","text"],
});

//------------------------------------------------------------------------
//:AISSeg that read content of image:
EditAISeg.regDef({
	name:"aiVision",showName:(($ln==="CN")?("AI识图"):/*EN*/("AI Vision")),icon:"yulan.svg",catalog:["AI Call"],
	attrs:{
		...SegObjShellAttr,
		"mode":{
			name:"mode",showName:(($ln==="CN")?("AI模型"):/*EN*/("Mode")),type:"choice",key:1,fixed:1,initVal:"gpt-4o",
			vals:[
				["gpt-4o","GPT-4o","GPT-4o"],
			],valueType:"string"
		},
		"temperature":{
			name:"temperature",showName:"Temperature",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.05,minVal:0,maxVal:2,valFixDigit:2
		},
		"maxToken":{
			name:"maxToken",showName:"MaxToken",type:"int",editType:"range",key:1,fixed:1,editMode:"range",step:50,minVal:0,maxVal:36000,initVal:2000,
		},
		"topP":{
			name:"topP",showName:"Top P",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:1.0,initVal:1,
		},
		"fqcP":{
			name:"fqcP",showName:"Frequency penalty",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:2.0,initVal:0,
		},
		"prcP":{
			name:"prcP",showName:"Presence penalty",type:"number",editType:"range",key:1,fixed:1,editMode:"range",step:0.02,minVal:0,maxVal:2.0,initVal:0,
		},
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示"):/*EN*/("Prompt")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("描述一下这幅图片"):/*EN*/("Describe this image")),editType:"note",
		},
		"seed":{
			name:"seed",showName:(($ln==="CN")?("种子"):/*EN*/("Seed")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"secret":{
			name:"secret",showName:(($ln==="CN")?("隐藏过程"):/*EN*/("secret")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,export:false,readOnly:true,
			initVal:(($ln==="CN")?("执行一次LLM调用。"):/*EN*/("Excute a LLM call.")),
		},
		"image":{
			name:"image",showName:(($ln==="CN")?("图像URL"):/*EN*/("Image URL")),type:"file",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",isURL:true,
		},
	},
	listHint:[
		"id","viewName","mkpInput","image","mode","maxToken",
		{
			name:"parameter",showName:(($ln==="CN")?("调用参数"):("Call Parameters")),
			attrs:["temperature","topP","fqcP","prcP"]
		},
		"prompt","seed","secret",
		"codes","context","global","desc","traceLogs",
	]
});

//------------------------------------------------------------------------
//:AISeg that draw a picture:
EditAISeg.regDef({
	name:"aiDraw",showName:(($ln==="CN")?("用AI绘制"):/*EN*/("AI Draw")),icon:"var_rgb.svg",catalog:["AI Call"],
	attrs:{
		...SegObjShellAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("需求描述"):/*EN*/("Prompt")),type:"string",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",
		},
		"seed":{
			name:"seed",showName:(($ln==="CN")?("种子"):/*EN*/("Seed")),type:"string",key:1,fixed:1,initVal:"",
		},
		"mode":{
			name:"mode",showName:(($ln==="CN")?("AI模型"):/*EN*/("Mode")),type:"choice",key:1,fixed:1,initVal:"dall-e-3",
			vals:[
				["gpt-image-1","GPT Image 1","GPT Image 1"],
				["dall-e-3","DALL-E 3","DALL-E 3"],
				["dall-e-2","DALL-E 2","DALL-E 2"],
			],valueType:"string"
		},
		"showImage":{
			name:"showImage",showName:(($ln==="CN")?("显示结果"):/*EN*/("Show result")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
		},
		"size":{
			name:"size",showName:(($ln==="CN")?("图片尺寸"):/*EN*/("Image Size")),type:"choice",key:1,fixed:1,initVal:"1024x1024",
			vals:[
				["1024x1024","1024x1024","1024x1024"],
				["1792x1024","1792x1024","1792x1024"],
				["1024x1792","1024x1792","1024x1792"],
				["256x256","256x256","256x256"],
				["512x512","512x512","512x512"],
			],valueType:"string"
		},
		"imgLabel":{
			name:"imgLabel",showName:(($ln==="CN")?("图片说明"):/*EN*/("Image Label")),type:"string",key:1,fixed:1,initVal:"AI Picture:",localizable:true,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		//Advanced:
		"method":{
			name:"method",showName:(($ln==="CN")?("操作"):/*EN*/("Method")),type:"choice",key:1,fixed:1,initVal:"Draw",rawEdit:false,
			vals:[
				["Draw","Draw",(($ln==="CN")?("绘制"):/*EN*/("Draw"))],
				["Edit","Edit",(($ln==="CN")?("编辑"):/*EN*/("Edit"))],
				["Variation","Variation",(($ln==="CN")?("衍生图片"):/*EN*/("Create variation"))],
			],valueType:"string"
		},
		"image":{
			name:"image",showName:(($ln==="CN")?("原图像"):/*EN*/("Original image")),type:"file",key:0,fixed:1,initVal:undefined,isURL:true,
		},
		"mask":{
			name:"mask",showName:(($ln==="CN")?("编辑遮罩"):/*EN*/("Edit mask")),type:"file",key:0,fixed:1,initVal:undefined,isURL:true,
		},
		"background":{
			name:"background",showName:(($ln==="CN")?("背景"):/*EN*/("Background")),type:"choice",key:0,fixed:1,initVal:"auto",rawEdit:false,
			vals:[
				["auto","Auto",(($ln==="CN")?("自动"):/*EN*/("Auto"))],
				["transparent","Transparent",(($ln==="CN")?("透明"):/*EN*/("Transparent"))],
				["opaque","Opaque",(($ln==="CN")?("不透明"):/*EN*/("Opaque"))],
			],valueType:"string"
		},
		"output_format":{
			name:"output_format",showName:(($ln==="CN")?("输出格式"):/*EN*/("Output format")),type:"choice",key:0,fixed:1,initVal:"png",rawEdit:false,
			vals:[
				["png","PNG",(($ln==="CN")?("PNG"):/*EN*/("PNG"))],
				["jpeg","JPEG",(($ln==="CN")?("JPEG"):/*EN*/("JPEG"))],
				["webp","WEBP",(($ln==="CN")?("WEBP"):/*EN*/("WEBP"))],
			],valueType:"string"
		},
		"output_compression":{
			name:"output_compression",showName:(($ln==="CN")?("输出压缩质量"):/*EN*/("Output Compression")),type:"int",key:0,fixed:1,initVal:100,
		},
		"quality":{
			name:"quality",showName:(($ln==="CN")?("绘制质量"):/*EN*/("Draw Quality")),type:"choice",key:0,fixed:1,initVal:"auto",rawEdit:false,
			vals:[
				["auto","Auto",(($ln==="CN")?("自动"):/*EN*/("Auto"))],
				["high","High",(($ln==="CN")?("高"):/*EN*/("High"))],
				["medium","Medium",(($ln==="CN")?("中"):/*EN*/("Medium"))],
				["low","Low",(($ln==="CN")?("低"):/*EN*/("Low"))],
				["hd","HD",(($ln==="CN")?("高(DallE-3)"):/*EN*/("High(DallE-3)"))],
				["standard","Standard",(($ln==="CN")?("标准(DallE-2/3"):/*EN*/("Standard(DallE-2/3)"))],
			],valueType:"string"
		},
		"moderation":{
			name:"moderation",showName:(($ln==="CN")?("监督"):/*EN*/("Moderation")),type:"choice",key:0,fixed:1,initVal:"auto",rawEdit:false,
			vals:[
				["auto","Auto",(($ln==="CN")?("自动"):/*EN*/("Auto"))],
				["low","Low",(($ln==="CN")?("低"):/*EN*/("Low"))],
			],valueType:"string"
		},
	},
	listHint:[
		"id","viewName","mkpInput","mode","prompt","size","showImage","imgLabel",
		{
			name:"Advanced",showName:(($ln==="CN")?("高级设置"):("Advanced")),
			attrs:["method","seed","image","mask","background","moderation","quality","output_format","output_compression"]
		},
		"codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg TTS
EditAISeg.regDef({
	name:"aiTTS",showName:(($ln==="CN")?("文本朗读"):/*EN*/("TTS")),icon:"sound.svg",catalog:["AI Call"],
	attrs:{
		...SegObjShellAttr,
		"mode":{
			name:"mode",showName:(($ln==="CN")?("AI模型"):/*EN*/("AI Model")),type:"choice",key:1,fixed:1,initVal:"tts-1",
			vals:[
				["tts-1","Open AI TTS-1","Open AI TTS-1"],
				["tts-1-hd","TBD-1-HD","Open TTS-1 HD"],
			],valueType:"string"
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("朗读文本"):("Text to read")),type:"string",initValText:"#input",initVal:"$$input$$",hideVal:1,key:1,fixed:1,localizable:true
		},
		"voice":{
			name:"voice",showName:(($ln==="CN")?("播音员"):/*EN*/("Voice")),type:"choice",key:1,fixed:1,initVal:"alloy",
			vals:[
				["alloy","Alloy","Alloy"],
				["echo","Echo","Echo"],
				["fable","Fable","Fable"],
				["onyx","Onyx","Onyx"],
				["nova","Nova","Nova"],
				["shimmer","Shimmer","Shimmer"],
			],valueType:"string"
		},
		"ttsLabel":{
			name:"ttsLabel",showName:(($ln==="CN")?("提示文本"):("Tip Text")),type:"string",initVal:(($ln==="CN")?("语音:"):/*EN*/("Audio:")),hideVal:1,key:1,fixed:1,localizable:true
		},
		"showBlock":{
			name:"showBlock",showName:(($ln==="CN")?("显示对话"):("Show in chat")),type:"bool",initVal:true,hideVal:1,key:1,fixed:1
		},
		"autoPlay":{
			name:"autoPlay",showName:(($ln==="CN")?("自动播放"):("Auto play")),type:"bool",initVal:true,hideVal:1,key:1,fixed:1
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","mode","text","voice","showBlock","ttsLabel","autoPlay","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that show image to user
EditAISeg.regDef({
	name:"image",showName:(($ln==="CN")?("图片输出"):/*EN*/("Image")),icon:"hudimg.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"text":{
			name:"text",showName:(($ln==="CN")?("提示文本"):("Tip text")),type:"string",initVal:(($ln==="CN")?("图片:"):/*EN*/("Image:")),hideVal:1,key:1,fixed:1,localizable:true
		},
		"image":{
			name:"image",showName:(($ln==="CN")?("图像URL"):/*EN*/("Image URL")),type:"file",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",isURL:true,
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
				["log","Log","Log"],
			],valueType:"string"
		},
		"sizeLimit":{
			name:"sizeLimit",showName:(($ln==="CN")?("尺寸限制"):/*EN*/("Size limit")),type:"auto",key:1,fixed:1,initVal:undefined
		},
		"codeDraw":{name:"codeDraw",showName:(($ln==="CN")?("自定义绘制代码"):/*EN*/("Custom draw code")),type:"bool",rawEdit:false,initVal:false,key:0,fixed:1},
		"format":{
			name:"format",showName:(($ln==="CN")?("压缩文件格式"):/*EN*/("File format")),type:"choice",key:1,fixed:1,initVal:"image/jpeg",rawEdit:false,
			vals:[
				["image/jpeg","JEPG","JPEG"],
				["image/png","PNG","PNG"]
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","text","image","role","sizeLimit","format","codeDraw","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that ask user to input:
//EditAISeg.regDef({
//	name:"askText",showName:(($ln==="CN")?("文本输入"):/*EN*/("Input Text")),icon:"edit.svg",catalog:["Interactive"],
//	attrs:{
//		...SegObjShellAttr,
//		"inputType":{
//			name:"inputType",showName:(($ln==="CN")?("输入形式"):("Input type")),type:"choice",
//			vals:(($ln==="CN")?([["text","Text","文本"],["password","Password","密码"]]):/*EN*/([["text","Text","Text"],["password","Password","Password"]])),
//			initVal:"text",hideVal:1,key:1,fixed:1,valueType:"string"
//		},
//		"prompt":{
//			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:1,fixed:1,initVal:"Please input",localizable:true,
//		},
//		"placeholder":{
//			name:"placeholder",showName:(($ln==="CN")?("占位提示"):("Placeholder")),type:"string",initVal:"",hideVal:1,key:1,fixed:1,localizable:true
//		},
//		"text":{
//			name:"text",showName:(($ln==="CN")?("默认输入文本"):("Init text")),type:"string",initVal:"",hideVal:1,key:1,fixed:1,localizable:true
//		},
//		"memo":{
//			name:"memo",showName:(($ln==="CN")?("多行输入"):/*EN*/("Multi-line")),type:"bool",key:1,fixed:1,initVal:false,
//		},
//		"outlet":{
//			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
//		},
//	},
//	listHint:[
//		"id","viewName","mkpInput","inputType","prompt","placeholder","text","memo","codes","context","global","desc",
//	]
//});

const showSilentMenu=async function(attr,sender,line,box){
	let app,seg,items,outlets,idName,item;
	app=VFACT.app;
	items=[{text:"Default",outlet:""}];
	seg=attr.owner;
	outlets=seg.outletsList;
	for(let outlet of outlets){
		idName=outlet.getAttrVal("id");
		items.push({text:idName,outlet:idName});
	}
	item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{items:items,hud:sender});
	if(item){
		box.setAttrByText(attr,item.outlet);
	}
};

//------------------------------------------------------------------------
//:AISeg that ask user to confirm:
EditAISeg.regDef({
	name:"askConfirm",showName:(($ln==="CN")?("按钮询问"):/*EN*/("Query Confirm")),icon:"help.svg",catalog:["Common","Interactive"],
	attrs:{
		...SegObjBaseAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:1,fixed:1,initVal:"Please confirm",localizable:true,
		},
		"outlets":{
			name:"outlets",showName:"Buttons",type:"array",def:ButtonOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"silent":{
			name:"silent",showName:"Silent",type:"bool",fixed:1,key:1,initVal:false,
			info:(($ln==="CN")?("是否静默，静默时不会向用户提问，从而不会中断智能体执行"):/*EN*/("When silent is true, agent will not ask user, so won't break/pause the execution flow."))
		},
		"silentOutlet":{
			name:"silentOutlet",showName:"Silent outlet",type:"choice",fixed:1,key:0,initVal:"",
			vals:[],
			showMenu:showSilentMenu,
			info:(($ln==="CN")?("静默时选择的按钮，默认为第一个按钮"):/*EN*/("Button outlet chosen in silent. Default (empty) value will use 1st button's outlet."))
		},
		//"withChat":{
		//	name:"withChat",showName:(($ln==="CN")?("允许输入"):/*EN*/("Allow input")),type:"bool",key:1,fixed:1,initVal:false,
		//},
		//"placeholder":{
		//	name:"placeholder",showName:(($ln==="CN")?("输入提示"):/*EN*/("Placeholder")),type:"string",key:0,fixed:1,initVal:"",localizable:true,
		//},
		"countdown":{
			name:"countdown",showName:(($ln==="CN")?("倒计时"):/*EN*/("Countdown")),type:"choice",fixed:1,key:0,initVal:false,
			vals:[
				[false,"None","None"],
				[5,"5","5s"],
				[10,"10","10s"],
				[30,"30","30s"],
			]
		}
	},
	listHint:[
		"id","viewName","mkpInput","prompt",/*"withChat","placeholder",*/"silent","silentOutlet","countdown","codes","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that ask user to choose from items(menu):
EditAISeg.regDef({
	name:"askMenu",showName:(($ln==="CN")?("菜单询问"):/*EN*/("Menu Query")),icon:"menu.svg",catalog:["Interactive"],reverseOutlets:true,
	attrs:{
		...SegObjBaseAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:1,fixed:1,initVal:"Please confirm",localizable:true,
		},
		"multi":{
			name:"multi",showName:(($ln==="CN")?("多选"):/*EN*/("Multi-select")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"withChat":{
			name:"withChat",showName:(($ln==="CN")?("允许输入"):/*EN*/("Allow input")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"placeholder":{
			name:"placeholder",showName:(($ln==="CN")?("输入提示"):/*EN*/("Placeholder")),type:"string",key:0,fixed:1,initVal:"",localizable:true,
		},
		"outlet":{
			name:"outlet",showName:"ChatInput",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"ChatInput",
				},
				"codes":{
					name:"codes",showName:(($ln==="CN")?("使用代码"):/*EN*/("Use Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,export:false,
				},
			},
		},
		"outlets":{
			name:"outlets",showName:"Buttons",type:"array",def:MenuOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"silent":{
			name:"silent",showName:"Silent",type:"bool",fixed:1,key:1,initVal:false,
			info:(($ln==="CN")?("是否静默，静默时不会向用户提问，从而不会中断智能体执行"):/*EN*/("When silent is true, agent will not ask user, so won't break/pause the execution flow."))
		},
		"silentOutlet":{
			name:"silentOutlet",showName:"Silent outlet",type:"choice",fixed:1,key:0,initVal:"",
			vals:[],
			showMenu:showSilentMenu,
			info:(($ln==="CN")?("静默时选择的按钮，默认为第一个选项"):/*EN*/("Menu item chosen in silent. Default (empty) value will use 1st item's outlet."))
		},
		"countdown":{
			name:"countdown",showName:(($ln==="CN")?("倒计时"):/*EN*/("Countdown")),type:"choice",fixed:1,key:0,initVal:false,
			vals:[
				[false,"None","None"],
				[5,"5","5s"],
				[10,"10","10s"],
				[30,"30","30s"],
			]
		}
	},
	listHint:[
		"id","viewName","mkpInput","prompt","multi","withChat","placeholder","silent","silentOutlet","countdown","codes","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that ask user to choose a file:
EditAISeg.regDef({
	name:"askFile",showName:(($ln==="CN")?("打开文件"):/*EN*/("Open File")),icon:"folder.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:1,fixed:1,initVal:"Please confirm",localizable:true,
		},
		"path":{
			name:"path",showName:(($ln==="CN")?("默认路径"):("Default path")),type:"file",initVal:"",hideVal:1,key:1,fixed:1
		},
		"fileSys":{
			name:"fileSys",showName:(($ln==="CN")?("文件系统"):("File system")),type:"choice",initVal:"native",hideVal:1,key:1,fixed:1,
			vals:[
				["tabos","tabos",(($ln==="CN")?("网页内Tab-OS文件系统"):/*EN*/("Tab-OS in browser"))],
				["native","naive",(($ln==="CN")?("硬件环境文件系统"):/*EN*/("Device file system"))],
			],valueType:"string"
		},
		"filter":{
			name:"filter",showName:(($ln==="CN")?("文件类型"):("File filter")),type:"string",initVal:"",hideVal:1,key:1,fixed:1,isURL:true
		},
		"read":{
			name:"read",showName:(($ln==="CN")?("读出内容"):/*EN*/("Read content")),type:"choice",key:1,fixed:1,initVal:"No",
			vals:[
				["No","No",(($ln==="CN")?("不读出内容，输出URL"):/*EN*/("No read, use URL as result"))],
				["Text","Text",(($ln==="CN")?("作为文本读出"):/*EN*/("Read as Text"))],
				["JSON","JSON",(($ln==="CN")?("作为JSON对象读出"):/*EN*/("Read as JSON object"))],
				["Data","Data",(($ln==="CN")?("作为数据读出"):/*EN*/("Read as ArrayBuffer"))],
				["Base64","Base64",(($ln==="CN")?("作为 Base64 数据读出"):/*EN*/("Read as Base64 Data"))],
				["DataURL","DataURL",(($ln==="CN")?("作为 DataURL 读出"):/*EN*/("Read as DataURL"))],
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","prompt","fileSys","path","filter","read","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that ask user to record an audio:
EditAISeg.regDef({
	name:"askAudio",showName:(($ln==="CN")?("录音"):/*EN*/("Record Audio")),icon:"voice.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"prompt":{
			name:"prompt",showName:(($ln==="CN")?("提示文本"):/*EN*/("Prompt text")),type:"string",key:1,fixed:1,initVal:"Please confirm",localizable:true,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","prompt","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that ask user to choose a file:
EditAISeg.regDef({
	name:"askEditObj",showName:(($ln==="CN")?("编辑对象"):/*EN*/("Edit Object")),icon:"rename.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"text":{
			name:"text",showName:(($ln==="CN")?("提示文本"):("Tip text")),type:"string",initVal:"Please input:",hideVal:1,key:1,fixed:1,localizable:true
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
			],valueType:"string"
		},
		"data":{
			name:"data",showName:(($ln==="CN")?("数据"):("Data")),type:"auto",initVal:"$$input$$",initValText:"#input",key:1,fixed:1
		},
		"template":{
			name:"template",showName:(($ln==="CN")?("模版"):("Template")),type:"choice",key:1,fixed:1,navi:"doc",
			"vals":[],valueType:"string",
			val2ShowText(val){
				let tmp;
				if(val===null){
					return null;
				}
				tmp=VFACT.getEditUITemplate(val);
				if(tmp){
					return tmp.label||tmp.name;
				}
				return val;
			},
			getMenuItems(){
				let list,tmps,tmpName,tmp;
				list=[{text:"None",valText:`null`}];
				tmps=VFACT.getEditUITemplates();
				for(tmpName in tmps){
					tmp=tmps[tmpName];
					if(tmp instanceof Function){
						tmp=tmp();
					}
					if(tmp){
						list.push({text:tmp.label||tmp.name,valText:`"${tmpName}"`});
					}
				}
				return list;
			}
		},
		"editData":{
			name:"editData",showName:(($ln==="CN")?("编辑数据"):("Edit Data")),type:"bool",initVal:true,key:1,fixed:1
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","text","role","data","template","editData","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg path connect:
const connectorDef={
	name:"connector",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowleft.svg",segIcon:"arrowright.svg",catalog:["Common","Flow"],
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"New AI Seg",export:false,edit:false,
		},
		"x":{
			name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"y":{
			name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"outlet":{
			name:"outlet",showName:"Outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Outlet",
				},
			},
		},
		"dir":{
			name:"dir",showName:(($ln==="CN")?("方向"):("Direction")),type:"choice",
			vals:(($ln==="CN")?([["L2R","L2R","左至右"],["R2L","R2L","右至左"],["T2B","T2B","上至下"],["B2T","B2T","下至上"]]):/*EN*/([["L2R","L2R","Left to right"],["R2L","R2L","Right to left"],["T2B","T2B","Top to bottom"],["B2T","B2T","Bottom to top"]])),
			initVal:"R2L",hideVal:1,key:1,fixed:1,valueType:"string"
		},
	},
	listHint:[
		"dir"
	],
	objAttrs:{
		isConnector:true,
		getName(){
			return (($ln==="CN")?("连接器"):/*EN*/("Connector"));
		}
	},
};
EditAISeg.regDef(connectorDef);
EditAISeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorL",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowright.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"L2R"}
}));
EditAISeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorT",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowdown.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"T2B"}
}));
EditAISeg.regDef(EditObj.deriveDef(connectorDef,{
	name:"connectorB",showName:(($ln==="CN")?("连接器"):/*EN*/("Connector")),icon:"arrowup.svg",segIcon:"arrowright.svg",catalog:["Flow"],
},{
	"dir":{initVal:"B2T"}
}));

//------------------------------------------------------------------------
//:AISeg that make branch/switch based on input:
EditAISeg.regDef({
	name:"brunch",showName:(($ln==="CN")?("条件分支"):/*EN*/("Branch")),icon:"condition.svg",catalog:["Common","Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",showName:"Default",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Default",
				},
				"output":{
					name:"output",showName:(($ln==="CN")?("输出内容"):/*EN*/("Output")),type:"string",key:1,fixed:1,initVal:"",export:false,localizable:true,
				}
			},
		},
		"outlets":{
			name:"outlets",showName:"Switches",type:"array",def:CoditionOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		}
	},
	listHint:[
		"id","viewName","mkpInput","codes","desc",
	],
	attrOutlets:["input"]
});

//------------------------------------------------------------------------
//:AISeg that pause a while:
EditAISeg.regDef({
	name:"sleep",showName:(($ln==="CN")?("等待时间"):/*EN*/("Wait")),icon:"wait.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"time":{
			name:"time",showName:(($ln==="CN")?("等待时间(毫秒)"):/*EN*/("Wait time(ms)")),type:"int",key:1,fixed:1,initVal:1000
		},
		"outlet":{
			name:"outlet",showName:"Default",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","time","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that make loop on an array:
EditAISeg.regDef({
	name:"loopArray",showName:(($ln==="CN")?("遍历数组"):/*EN*/("Array Loop")),icon:"loop_array.svg",catalog:["Flow"],
	attrs:{
		...SegObjShellAttr,
		"loopArray":{
			name:"loopArray",showName:"Loop Target",type:"auto",key:1,fixed:1,rawEdit:false,initVal:"$$input$$",initValText:"#input",
		},
		"method":{
			name:"method",showName:"Method",type:"choice",key:1,fixed:1,rawEdit:false,initVal:"forEach",
			vals:[
				["forEach","forEach","For each"],
				["asyncForEach","asyncForEach","Async For each"],
				["find","find","Find element"],
				["findIndex","findIndex","Find element index"],
				["allOf","allOf","All of"],
				["anyOf","anyOf","Any of"],
				["map","map","Map"],
				["filter","filter","Filter"],
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",showName:"Looper (n)",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Looper",
				},
			},
		},
		"catchlet":{
			name:"catchlet",showName:"After Loop",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		},
	},
	listHint:[
		"id","viewName","mkpInput","loopArray","method","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that make survey based on input and summary it:
EditAISeg.regDef({
	name:"summary",showName:(($ln==="CN")?("扩散/摘要"):/*EN*/("Summary")),icon:"summary.svg",catalog:["Flow"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",showName:"Summary",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Summary",
				},
			},
		},
		"async":{
			name:"async",showName:(($ln==="CN")?("并行执行"):/*EN*/("Async execute")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"outlets":{
			name:"outlets",showName:"Samples",type:"array",def:SampleOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"format":{
			name:"format",showName:(($ln==="CN")?("输出格式"):("Output format")),type:"choice",
			vals:(($ln==="CN")?([["Object","Object","对象"],["JSON","JSON","JSON"],["Text","Text","文本"]]):/*EN*/([["Object","Object","Object"],["JSON","JSON","JSON"],["Text","Text","Plain text"]])),
			initVal:"JSON",hideVal:1,key:1,fixed:1,valueType:"string"
		},
	},
	listHint:[
		"id","viewName","mkpInput","format","async","codes","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that catch error in sub-flow:
EditAISeg.regDef({
	name:"tryCatch",showName:(($ln==="CN")?("捕获异常"):/*EN*/("Catch Error")),icon:"trycatch.svg",catalog:["Flow"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",showName:"Try",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Try",
				},
			},
		},
		"catchlet":{
			name:"catchlet",showName:"Catch",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Catch",
				},
			},
		}
	},
	listHint:[
		"id","viewName","mkpInput","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that use a code seg:
EditAISeg.regDef({
	name:"code",showName:(($ln==="CN")?("代码片段"):/*EN*/("Code Seg")),icon:"tab_css.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"outlets":{
			name:"outlets",showName:"Switches",type:"array",def:CodeOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"codes":{
			name:"codes",type:"string",initVal:"",key:1,fixed:1,edit:false,save:false,
		},
		"result":{
			name:"result",showName:(($ln==="CN")?("输出"):/*EN*/("Result")),type:"string",key:1,fixed:1,initVal:"$$input$$",initValText:"#input",
		},
		"process":{
			name:"process",showName:"Process",type:"object",def:ProcessMsgDef,key:0,fixed:1
		}
	},
	listHint:[
		"id","viewName","mkpInput","result","process","context","global","desc",
	],
	genAttrs:["id","codes"],
});

//------------------------------------------------------------------------
//:AISeg that call a function in file:
EditAISeg.regDef({
	name:"function",showName:(($ln==="CN")?("文件函数调用"):/*EN*/("Function")),icon:"func.svg",catalog:["Code"],
	attrs:{
		...SegObjShellAttr,
		"source":{
			name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"file",key:1,fixed:1,initVal:"",
		},
		"function":{
			name:"function",showName:(($ln==="CN")?("函数名"):/*EN*/("Function name")),type:"string",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","source","function","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that call a pre-defined AI Agent
EditAISeg.regDef({
	name:"aiBot",showName:(($ln==="CN")?("调用AI-Agent"):/*EN*/("Call AI Agent")),icon:"agent.svg",catalog:["Common","Code"],
	attrs:{
		...SegObjShellAttr,
		"agentNode":{
			name:"agentNode",showName:(($ln==="CN")?("智能体节点"):/*EN*/("Agent node")),type:"string",key:false,fixed:1,initVal:"",
		},
		"source":{
			name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"file",key:1,fixed:1,initVal:"",
			openMenu:async function(attrObj,btn,line,editBox){
				let segAttr,agentList,items,item;
				segAttr=attrObj.owner;
				if(!segAttr.getAttrVal("mcp")){
					return false;
				}
				agentList=["call1","call2","call3"];
				if(!items.length){
					items.push({text:"No API",enable:false});
				}else{
					for(let api of agentList){
						items.push({text:api,code:api});
					}
				}
				item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
					items:items,hud:btn
				});
				if(!item){
					return true;// User cancel:
				}
				editBox.setAttrByText(attrObj,item.code);
				return true;
			}
		},
		"argument":{
			name:"argument",showName:(($ln==="CN")?("调用参数"):/*EN*/("argument")),type:"hyperObj",key:1,fixed:1,initVal:"$$input$$",initValText:"#{}#>input",
			template:async function(obj){
				let path,md,ext;
				path=obj.getAttrVal("source");
				if(path){
					let def,ppts,defPpts,pptName,pptDef;
					if(path[0]==="/" && path[1]!=="/" && path[1]!=="@"){
						path="/~"+path;
					}
					ext=pathLib.extname(path);
					if(ext===".js"){
						try{
							md=await import(path+`?time=${Date.now()}`);
						}catch(err){
							try{
								let code,pos,pos2,mk1,mk2,func;
								code=await (await fetch(path)).text();
								mk1=`//#CodyExport>>>`;
								mk2=`//#CodyExport<<<`;
								pos=code.indexOf(mk1);
								if(pos>0){
									pos2=code.indexOf(mk2);
									if(pos2>pos){
										code=code.substring(pos+mk1.length,pos2);
										code+="\nreturn {api:ChatAPI};"
									}
									try{
										func=new Function("VFACT",code);
										code=func(VFACT);
										if(code.api){
											md={ChatAPI:code.api};
										}
									}catch(err){
										//window.alert(`Import ${path} error: can't parse API def.`);
										app.showStateText(`Import ${path} error: can't parse API def.`);
										throw Error("Can't find API def");
									}

								}
							}catch(err){
								console.error(err);
								//window.alert(`Import ${path} error: `+err);
								app.showStateText(`Import ${path} error: `+err);
								throw err;
							}
						}
						if((!md.ChatAPI) || (!md.ChatAPI[0]) || (!md.ChatAPI[0].def)){
							//window.alert(`Import ${path} error: can't find API def.`);
							app.showStateText(`Import ${path} error: can't find API def.`);
							throw Error("Can't find API def");
						}
					}else if(ext===".py"){
						let code,pos,pos2,mk1,mk2,func;
						code=await (await fetch(path)).text();
						mk1=`""">>>CodyExport`;
						mk2=`>>>CodyExport"""`;
						pos=code.indexOf(mk1);
						if(pos>0){
							pos2=code.indexOf(mk2);
							if(pos2>pos){
								code=code.substring(pos+mk1.length,pos2);
							}
							try{
								func=new Function("VFACT",code);
								code=func(VFACT);
								if(code.api){
									md={ChatAPI:code.api};
								}
							}catch(err){
								//window.alert(`Import ${path} error: can't parse API def.`);
								app.showStateText(`Import ${path} error: can't parse API def.`);
								throw Error("Can't find API def");
							}
							
						}
						//TODO: Code this:
					}
					if(!md){
						return;
					}
					def=md.ChatAPI[0].def;
					ppts={};
					defPpts=def.parameters.properties;
					for(pptName in defPpts){
						pptDef=defPpts[pptName];
						ppts[pptName]={
							type:"auto",label:`${pptName}:`,
							desc:`type: ${pptDef.type}. ${pptDef.description}`
						};
					}
					return{
						title:pathLib.basename(path),label:"",
						properties:ppts
					};
				}else{
					return{
						title:"No argument for this agent",label:"",
						properties:{}
					};
				}
			}
		},
		"secret":{
			name:"secret",showName:(($ln==="CN")?("隐藏过程"):/*EN*/("secret")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"outlets":{
			name:"outlets",showName:"Switches",type:"array",def:AgentAskOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,export:false,
			initVal:(($ln==="CN")?("调用其它AI Agent，把调用的结果作为输出"):/*EN*/("Call AI Agent, use it's output as result")),
		},
		"process":{
			name:"process",showName:"Process",type:"object",def:ProcessMsgDef,key:0,fixed:1
		}
	},
	listHint:[
		"id","viewName","mkpInput","agentNode","source","secret","argument","process","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that call MCP Tools
EditAISeg.regDef({
    name:"MCP",showName:(($ln==="CN")?("调用MCP"):/*EN*/("Call AI Agent")),icon:"mcp.svg",catalog:["Common","Code"],
    attrs:{
        ...SegObjShellAttr,

        "server":{
            name:"server",showName:(($ln==="CN")?("MCP 服务地址"):/*EN*/("MCP Server Address")),type:"string",key:true,fixed:1,initVal:"",
        },
        "tool":{
            name:"tool",showName:(($ln==="CN")?("工具"):/*EN*/("Tool")),type:"file",key:1,fixed:1,initVal:"",
            showMenu:async function(attrObj,btn,line,editBox){
                let segAttr,agentList,items,item;
                items=[];
                segAttr=attrObj.owner;
                /* get tool list */
                let response, tools, url;
                url=segAttr.getAttrVal("server");
                if(url.endsWith("/")){
                    response = await webFetch(url + "tools/cached");
                }else{
                    response = await webFetch(url+ "/tools/cached");
                }
                tools = await response.json();
                tools = tools.tools;
                if(tools.length === 0){
                    if(url.endsWith("/")){
                        response = await webFetch(url + "tools");
                    }else{
                        response = await webFetch(url+ "/tools");
                    }
                    tools = await response.json();
                    tools = tools.tools
                }
                agentList=tools.map(item => item.name);
                if(!agentList.length){
                    items.push({text:"No API",enable:false});
                }else{
                    for(let api of agentList){
                        items.push({text:api,code:api});
                    }
                }
                item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
                    items:items,hud:btn
                });
                if(!item){
                    return true;// User cancel:
                }
                editBox.setAttrByText(attrObj,"/"+item.code);
                return true;
            }
        },
        "argument":{
            name:"argument",showName:(($ln==="CN")?("调用参数"):/*EN*/("argument")),type:"hyperObj",key:1,fixed:1,initVal:"$$input$$",initValText:"#{}#>input",
            template:async function(obj){
                let path,md,ext,mcp;
                mcp=true;
                path=obj.getAttrVal("tool");
                if(path){
                    let def,ppts,defPpts,pptName,pptDef;
                    if(mcp){
                        let url, response, tools;
                        url=obj.getAttrVal("server");
                        /*TODO 优化 改为http请求*/
                        if(url.endsWith("/")){
                            response = await webFetch(url + "tools/cached");
                        }else{
                            response = await webFetch(url+ "/tools/cached");
                        }
                        tools = await response.json();
                        tools = tools.tools;
                        let tool2schema = {};
                        for(let key in tools){
                            tool2schema[tools[key].name] = tools[key].input_schema.properties;
                        }
                        let input_schema = tool2schema[path.slice(1)];
                        defPpts=input_schema;
                        ppts={};
                    }
                    for(pptName in defPpts){
                        pptDef=defPpts[pptName];
                        ppts[pptName]={
                            type:"auto",label:`${pptName}:`,
                            desc:`type: ${pptDef.type}. ${pptDef.description || pptDef.title}`
                        };
                    }
                    return{
                        title:pathLib.basename(path),label:"",
                        properties:ppts
                    };
                }else{
                    return{
                        title:"No argument for this agent",label:"",
                        properties:{variable:{type:"auto",label:"sss",desc:"ssss"}}
                    };
                }
            }
        },
        "outlet":{
            name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
        },
        "desc":{
            name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",editType:"note",key:1,fixed:1,export:false,
            initVal:(($ln==="CN")?("调用MCP 工具，把调用的结果作为输出"):/*EN*/("Call MCP Tools, use its output as result")),
        },
    },
    listHint:[
        "id","viewName","mkpInput","server","tool","argument","codes","context","global","desc",
    ]
});

//------------------------------------------------------------------------
//:WebCall
EditAISeg.regDef({
	name:"webCall",showName:(($ln==="CN")?("调用网络API"):/*EN*/("Call WEB API")),icon:"web.svg",catalog:["Code"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("调用URL"):/*EN*/("Call URL")),type:"string",key:1,fixed:1,initVal:"",
		},
		"method":{
			name:"method",showName:(($ln==="CN")?("请求方法"):/*EN*/("Request Method")),type:"choice",key:1,fixed:1,initVal:"POST",
			vals:[
				["GET","GET","GET"],
				["POST","POST","POST"],
				["PUT","PUT","PUT"],
				["DELETE","DELETE","DELETE"],
			],valueType:"string"
		},
		"argMode":{
			name:"argMode",showName:(($ln==="CN")?("参数传递方法"):/*EN*/("Arguments embeding")),type:"choice",key:1,fixed:1,initVal:"JSON",rawEdit:false,
			vals:[
				["URL","URL","URL"],
				["JSON","JOSN","JSON in body"],
				["TEXT","Text","String"],
			],valueType:"string"
		},
		"format":{
			name:"format",showName:(($ln==="CN")?("结果格式"):/*EN*/("Result format")),type:"choice",key:1,fixed:1,initVal:"JSON",rawEdit:false,
			vals:[
				["JSON","JOSN","Parse to JSON"],
				["TEXT","Text","Keep raw string"],
			],valueType:"string"
		},
		"args":{
			name:"args",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call arguments")),type:"object",def:"Object",key:1,fixed:1
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("调用文本"):/*EN*/("Call text")),type:"string",key:1,fixed:1,initVal:"",
		},
		"timeout":{
			name:"timeout",showName:(($ln==="CN")?("超时限制"):/*EN*/("Timeout")),type:"int",key:1,fixed:1,initVal:30000,
		},
		"headers":{
			name:"headers",showName:(($ln==="CN")?("HTTP 头参数"):/*EN*/("HTTP Header")),type:"object",def:"Object",key:1,fixed:1
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","url","method","headers","argMode","args","text","format","timeout","codes","context","global","desc",
	]
});

//------------------------------------------------------------------------
//:AISeg that exec a UI block defined in file:
EditAISeg.regDef({
	name:"askUIBlock",showName:(($ln==="CN")?("UI片段"):/*EN*/("UI Block")),icon:"hudview.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"source":{
			name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"file",key:1,fixed:1,initVal:"",
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("提示文本"):("Tip text")),type:"string",initVal:"Please input:",hideVal:1,key:1,fixed:1,localizable:true
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","text","source","role","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that exec a UI Dialog defined in file:
EditAISeg.regDef({
	name:"askUIDlg",showName:(($ln==="CN")?("对话框"):/*EN*/("UI Dialog")),icon:"idcard.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"source":{
			name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"file",key:1,fixed:1,initVal:"",
		},
		"callArg":{
			name:"callArg",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call argument")),type:"auto",key:1,fixed:1,initVal:"$$input$$",initValText:"#input",
		},
		"role":{
			name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"choice",key:1,fixed:1,initVal:"assistant",
			vals:[
				["user","User","User"],
				["assistant","Assistant","Assistant"],
				["system","System","System"],
				["event","Event","Event"],
				["log","Log","Log"],
			],valueType:"string"
		},
		"tip":{
			name:"tip",showName:(($ln==="CN")?("提示文本"):/*EN*/("Tip text")),type:"string",key:1,fixed:1,initVal:"",localizable:true
		},
		"showResult":{
			name:"showResult",showName:(($ln==="CN")?("显示结果"):/*EN*/("Show result")),type:"bool",key:1,fixed:1,initVal:"",
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","source","callArg","role","tip","showResult","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that exec a UI Dialog defined in file:
EditAISeg.regDef({
	name:"askUIView",showName:(($ln==="CN")?("用户界面视图"):/*EN*/("UI View")),icon:"huddock.svg",catalog:["Interactive"],
	attrs:{
		...SegObjShellAttr,
		"source":{
			name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"file",key:1,fixed:1,initVal:"",
		},
		"callArg":{
			name:"callArg",showName:(($ln==="CN")?("调用参数"):/*EN*/("Call argument")),type:"auto",key:1,fixed:1,initVal:"$$input$$",initValText:"#input",
		},
		"package":{
			name:"package",showName:(($ln==="CN")?("代码库"):/*EN*/("Package")),type:"string",key:0,fixed:1,initVal:""
		},
		"tip":{
			name:"tip",showName:(($ln==="CN")?("提示文本"):/*EN*/("Tip text")),type:"string",key:1,fixed:1,initVal:"",localizable:true
		},
		"withChat":{
			name:"withChat",showName:(($ln==="CN")?("允许输入"):/*EN*/("With chat")),type:"bool",key:1,fixed:1,initVal:true,
		},
		"showChats":{
			name:"showChats",showName:(($ln==="CN")?("显示聊天内容"):/*EN*/("Show chats")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"file":{
			name:"file",showName:(($ln==="CN")?("允许文件"):/*EN*/("Allow file")),type:"bool",key:1,fixed:1,initVal:false,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"outlet":{
			name:"outlet",showName:"Default",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Chat",
				},
				"output":{
					name:"output",showName:(($ln==="CN")?("输出内容"):/*EN*/("Output")),type:"string",key:1,fixed:1,initVal:"",export:false,localizable:true,
				}
			},
		},
		"outlets":{
			name:"outlets",showName:"Commands",type:"array",def:CoditionOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc",
		}
	},
	listHint:[
		"id","viewName","mkpInput","source","callArg","package","withChat","showChats","tip","file","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that save data or agent-context to JSON object/file
EditAISeg.regDef({
	name:"save",showName:(($ln==="CN")?("保存数据"):/*EN*/("Save data")),icon:"dbsave.svg",catalog:["Code"],
	attrs:{
		...SegObjShellAttr,
		"location":{
			name:"location",showName:(($ln==="CN")?("存储位置"):/*EN*/("Save location")),type:"choice",key:1,fixed:1,initVal:"Local",
			vals:[
				["Local","Local",(($ln==="CN")?("Tab-OS 文件"):/*EN*/("Tab-OS file"))],
				["Hub","Hub",(($ln==="CN")?("Agent-Hub 文件"):/*EN*/("Save to Agent-Hub"))],
			],valueType:"string",rawEdit:false
		},
		"fileName":{
			name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("FileName")),type:"string",key:1,fixed:1,initVal:"",
		},
		"target":{
			name:"target",showName:(($ln==="CN")?("存储内容"):/*EN*/("Save target")),type:"choice",key:1,fixed:1,initVal:"Input",rawEdit:false,
			vals:[
				["Context","Context",(($ln==="CN")?("对话上下文"):/*EN*/("Session context"))],
				["Input","Input",(($ln==="CN")?("本组件输入内容"):/*EN*/("Input"))],
			],valueType:"string"
		},
		"format":{
			name:"format",showName:(($ln==="CN")?("存储格式"):/*EN*/("Save format")),type:"choice",key:1,fixed:1,initVal:"JSON",rawEdit:false,
			vals:[
				["JSON","JSON",(($ln==="CN")?("作为JSON存储"):/*EN*/("Save to JSON"))],
				["CJSON","CJSON",(($ln==="CN")?("紧凑的JSON"):/*EN*/("Save to compact JSON"))],
				["Data","Data",(($ln==="CN")?("作为数据存储"):/*EN*/("Save as data"))],
				["Text","Text",(($ln==="CN")?("作为文本存储"):/*EN*/("Save as Text"))],
				["Base642Data","Base642Data",(($ln==="CN")?("把Base64内容存储为数据"):/*EN*/("Base64 save as data"))],
				["DataURL2Data","DataURL2Data",(($ln==="CN")?("把DataURL内容存储为数据"):/*EN*/("DataURL save as data"))],
			],valueType:"string"
		},
		"saveContext":{
			name:"saveContext",showName:(($ln==="CN")?("保存上下文项目"):/*EN*/("Save context")),type:"array",def:"StringArray",icon:"idcard.svg",key:1,fixed:1,edit:1,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","location","fileName","target","format","saveContext","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg that load data or agent-context from JSON object/file
EditAISeg.regDef({
	name:"load",showName:(($ln==="CN")?("读出数据"):/*EN*/("Load data")),icon:"dbload.svg",catalog:["Code"],
	attrs:{
		...SegObjShellAttr,
		"fileName":{
			name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("FileName")),type:"string",key:1,fixed:1,initVal:"",
		},
		"read":{
			name:"read",showName:(($ln==="CN")?("读出内容"):/*EN*/("Read content")),type:"choice",key:1,fixed:1,initVal:"Context",rawEdit:false,
			vals:[
				["Context","Context",(($ln==="CN")?("读出对话上下文"):/*EN*/("Read session context"))],
				["Text","Text",(($ln==="CN")?("作为文本读出"):/*EN*/("Read as Text"))],
				["JSON","JSON",(($ln==="CN")?("作为JSON对象读出"):/*EN*/("Read as JSON object"))],
				["Data","Data",(($ln==="CN")?("作为数据读出"):/*EN*/("Read as ArrayBuffer"))],
				["Base64","Base64",(($ln==="CN")?("作为 Base64 数据读出"):/*EN*/("Read as Base64 Data"))],
				["DataURL","DataURL",(($ln==="CN")?("作为 DataURL 读出"):/*EN*/("Read as DataURL"))],
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","viewName","mkpInput","fileName","read","context","global","desc","codes",
	]
});

//------------------------------------------------------------------------
//:AISeg fix arguments:
EditAISeg.regDef({
	name:"fixArgs",showName:(($ln==="CN")?("修正参数"):/*EN*/("Fix arguments")),icon:"args.svg",catalog:["Code"],
	attrs:{
		...SegObjBaseAttr,
		"smartAsk":{
			name:"smartAsk",showName:(($ln==="CN")?("使用智能询问"):/*EN*/("Smart ask")),type:"bool",key:1,fixed:0,initVal:false,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		},
	},
	listHint:["id","viewName","smartAsk","desc","codes"]
});

//------------------------------------------------------------------------
//:AISeg jumper or wrapper:
EditAISeg.regDef({
	name:"jumper",showName:(($ln==="CN")?("飞线"):/*EN*/("Jumper")),icon:"arrowupright.svg",catalog:["Flow","Code"],
	attrs:{
		...SegObjBaseAttr,
		"seg":{
			name:"seg",showName:(($ln==="CN")?("跳转目标"):/*EN*/("Jump to")),type:"string",key:1,fixed:1,initVal:"",editType:"choice",
			icon:"flag.svg",rawEdit:false,
			getMenuItems:function(){
				let list,i,n,seg;
				let items=[];
				list=this.owner.doc.segsList;
				n=list.length;
				for(i=0;i<n;i++){
					seg=list[i];
					if(seg.idVal.val){
						items.push({text:seg.idVal.val,valText:seg.jaxId});
					}
				}
				return items;
			},
			val2ShowText:function(val){
				let list,i,n,seg;
				if(!val){
					return "NA";
				}
				list=this.owner.doc.segsList;
				n=list.length;
				for(i=0;i<n;i++){
					seg=list[i];
					if(seg.idVal.val===val){
						return val;
					}
					if(seg.jaxId===val){
						return seg.idVal.val;
					}
				}
				return "NA";
			}
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Next",
				},
			},
		},
	},
	listHint:["id","viewName","seg","codes","desc"],
	objAttrs:{
		isJumper:true
	}
});

//------------------------------------------------------------------------
//:AISeg comment on canvas:
const noteDef={
	name:"note",showName:(($ln==="CN")?("注释"):/*EN*/("Note")),icon:"memo.svg",catalog:["Common","Flow"],
	attrs:{
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"x":{
			name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"y":{
			name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,export:false,edit:false,
		},
		"from":{
			name:"from",showName:(($ln==="CN")?("来自"):/*EN*/("From")),type:"string",key:1,fixed:1,initVal:"",export:false,edit:false,
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("注释"):/*EN*/("Comment")),type:"string",editType:"note",key:1,fixed:1,markdown:true,
			initVal:(($ln==="CN")?("这是一个注释。"):/*EN*/("This is a comment.")),export:false,
		},
	},
	listHint:[
		"id","desc"
	],
	objAttrs:{
		isNote:true,
		getName(){
			return (($ln==="CN")?("注释: "+this.idVal.val):/*EN*/("Note: "+this.idVal.val));
		}
	},
};
EditAISeg.regDef(noteDef);


export {SegOutletDef};

