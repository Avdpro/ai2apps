import {VFACT} from "/@vfact"

let topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT||VFACT;
const classReg=topVFACT.classRegs;


let LayoutCell,layoutCell;
const CELL_W=250;
const CELL_H=80;
const TRACK_H=40;
const TRACKOFFSET_C=CELL_W*0.5;
const TRACKOFFSET_L1=CELL_W*0.6;
const TRACKOFFSET_L2=CELL_W*0.1;
const TRACKOFFSET_R1=CELL_W*1.25;
const TRACKOFFSET_R2=-CELL_W*0.25;

//****************************************************************************
//:LayoutCell
//****************************************************************************
{
	LayoutCell=function(seg,parent){
		this.seg=seg;
		this.seg.$layout=this;
		this.parent=parent;
		this.children=[];
		this.childHeight=1;
		this.cellBlock={x:0,y:0,w:0,h:0};
		this.topCell=parent?parent.topCell:this;
		if(!parent){
			this.genChildren();
			console.log("Layout:");
			console.log(this);
		}
	};
	
	layoutCell=LayoutCell.prototype={};
	
	//------------------------------------------------------------------------
	layoutCell.genChildren=function(){
		let seg,children,segDef,segObjDef,rev;
		let outlets,outlet,list,sub,subNum;
		children=this.children;
		seg=this.seg;
		segDef=seg.def;
		segObjDef=seg.objDef;
		outlets=seg.getOutlets();
		for(outlet of outlets){
			this.packOutlet(outlet);
		}
		subNum=0;
		for(sub of children){
			sub.genChildren();
			subNum+=sub.childHeight||1;
		}
		this.childHeight=subNum||1;
	};
	
	//------------------------------------------------------------------------
	layoutCell.packOutlet=function(outlet){
		let nextSeg,cell;
		nextSeg=outlet.getLinkedSeg();
		if(!nextSeg || !nextSeg.$needLayout){
			return;
		}
		if(nextSeg.$layout){//Already in cell:
			return;
		}
		cell=new LayoutCell(nextSeg,this);
		this.children.push(cell);
	};
	
	//------------------------------------------------------------------------
	layoutCell.layout=function(canvas){
		let seg,x,y,w,h,cellBlock,children,sub;
		if(!canvas){
			canvas={x:0,y:0,layoutedSegs:[]};
		}
		seg=this.seg;
		canvas.layoutedSegs.push(seg);
		cellBlock=this.cellBlock;
		w=CELL_W;
		h=CELL_H*this.childHeight;
		cellBlock.x=canvas.x;
		cellBlock.y=canvas.y;
		cellBlock.w=w;
		cellBlock.h=h;
		children=this.children;
		canvas.x=cellBlock.x+w;
		for(sub of children){
			sub.layout(canvas);
			canvas.y+=sub.cellBlock.h;
		}
		seg.setAttrByText("x",""+cellBlock.x);
		seg.setAttrByText("y",""+(cellBlock.y+cellBlock.h*0.5));
		canvas.x=cellBlock.x;
	};
	
	//------------------------------------------------------------------------
	layoutCell.refinePaths=function(canvas){
		let seg,outlets,paths,rev,outlet,nextSeg,nextCell;
		let cellBlock,nextBlock,sub,i,n;
		seg=this.seg;
		cellBlock=this.cellBlock;
		outlets=seg.getOutlets();
		n=outlets.length;
		for(i=0;i<n;i++){
			outlet=outlets[i];
			nextSeg=outlet.getLinkedSeg();
			if(nextSeg){
				nextCell=nextSeg.$layout;
				if(nextCell){
					nextBlock=nextCell.cellBlock;
					if(cellBlock.x+cellBlock.w!==nextBlock.x){
						this.jumpPath(canvas,outlet,nextSeg,i,n);
					}
				}
			}
		}
		for(sub of this.children){
			sub.refinePaths(canvas);
		}
	};
	
	//----------------------------------------------------------------------------
	layoutCell.jumpPath=function(canvas,outlet,nextSeg,idx,num){
		let topCell,topBlock,seg,cellBlock,nextCell,nextBlock;
		let topCenterY,outletY,trackId,trackY;
		let prj,EditAISeg,segDef;
		EditAISeg=classReg.EditAISeg;
		seg=this.seg;
		prj=seg.prj;
		topCell=this.topCell;
		topBlock=topCell.cellBlock;
		cellBlock=this.cellBlock;
		nextCell=nextSeg.$layout;
		nextBlock=nextCell.cellBlock;
		//First, up or down?
		topCenterY=topBlock.y+topBlock.h*0.5;
		outletY=cellBlock.y+((idx+0.5)/num)*cellBlock.h;

		if(outletY<topCenterY){
			//this is top
			trackId=canvas.topTracks++;
			trackY=topBlock.y-(trackId+0.5)*TRACK_H;
		}else{
			//this is bottom:
			trackId=canvas.btmTracks++;
			trackY=topBlock.y+topBlock.h+(trackId+0.5)*TRACK_H;
		}

		segDef=EditAISeg.getDef("connector");
		if(cellBlock.x===nextBlock.x){
			let seg1X,seg1;
			//Add one route seg:
			seg1X=cellBlock.x+TRACKOFFSET_C;
			seg1=prj.editAttr_AddFlowSeg(seg.owner,segDef,seg1X,trackY);
			//Remove old seg 
			prj.editAttr_LinkSeg(outlet,null,true);
			//Link to seg1:
			prj.editAttr_LinkSeg(outlet,seg1,true);
			canvas.layoutedSegs.push(seg1);
		}else if(cellBlock.x>nextBlock.x){
			let seg1X,seg2X;
			let seg1,seg2;
			//This is a jump backward path, add 2 segs:
			seg1X=cellBlock.x+TRACKOFFSET_L1;
			seg2X=nextBlock.x+TRACKOFFSET_L2;
			//Add two segs:
			seg1=prj.editAttr_AddFlowSeg(seg.owner,segDef,seg1X,trackY);
			seg2=prj.editAttr_AddFlowSeg(seg.owner,segDef,seg2X,trackY);
			//Link new segs and nextSeg:
			prj.editAttr_LinkSeg(seg1.outlet,seg2,true);
			prj.editAttr_LinkSeg(seg2.outlet,nextSeg,true);
			//Remove old seg 
			prj.editAttr_LinkSeg(outlet,null,true);
			//Link to seg1:
			prj.editAttr_LinkSeg(outlet,seg1,true);
			canvas.layoutedSegs.push(seg1,seg2);
		}else{
			let seg1X,seg2X;
			let seg1,seg2;
			//This is a jump forward path, add 2 segs:
			seg1X=cellBlock.x+TRACKOFFSET_R1;
			seg2X=nextBlock.x+TRACKOFFSET_R2;
			//Add two segs:
			seg1=prj.editAttr_AddFlowSeg(seg.owner,segDef,seg1X,trackY);
			seg2=prj.editAttr_AddFlowSeg(seg.owner,segDef,seg2X,trackY);
			//Link new segs and nextSeg:
			prj.editAttr_LinkSeg(seg1.outlet,seg2,true);
			prj.editAttr_LinkSeg(seg2.outlet,nextSeg,true);
			//Remove old seg 
			prj.editAttr_LinkSeg(outlet,null,true);
			//Link to seg1:
			prj.editAttr_LinkSeg(outlet,seg1,true);
			canvas.layoutedSegs.push(seg1,seg2);
		}
	};
}

//----------------------------------------------------------------------------
function layoutSegs(newSegs,allSegs){
	let rootSegs,seg,canvas,x,y,maxY,preSeg,cell;
	rootSegs=[];
	for(seg of newSegs){
		seg.$needLayout=true;
		seg.$layout=null;
	}
	//Find the most Y value
	maxY=0;
	for(seg of allSegs){
		if(!seg.$needLayout){
			y=seg.getAttrVal("y");
			if(y>maxY){
				maxY=y;
			}
		}
	}
	canvas={x:100,y:maxY+CELL_H};
	
	//Init layout cell trees:
	for(seg of newSegs){
		if(!seg.$layout){
			//Find the parent seg of this seg, and use it's x and y:
			preSeg=seg.linkedOutlets[0];
			if(preSeg){
				maxY=canvas.y;
				x=seg.getAttrVal("x");
				y=seg.getAttrVal("y");
				if(x>0 && y>0){
					canvas.x=x+CELL_W*0.5;
					canvas.y=y+CELL_H;
				}
				cell=new LayoutCell(seg,null);
				canvas.y=Math.max(canvas.y,maxY);
			}else{
				cell=new LayoutCell(seg,null);
				rootSegs.push(seg);
			}
		}
	}

	for(seg of rootSegs){
		canvas.layoutedSegs=[];
		canvas.topTracks=0;
		canvas.btmTracks=0;
		seg.$layout.layout(canvas);
		seg.$layout.refinePaths(canvas);
		if(canvas.topTracks>0){
			let seg,y,dy;
			dy=canvas.topTracks*TRACK_H;
			for(seg of canvas.layoutedSegs){
				y=seg.getAttrVal("y")+dy;
				seg.setAttrByText("y",""+y);
			}
		}
		canvas.y+=(canvas.topTracks+canvas.btmTracks)*TRACK_H;
	}

	//Clear layout info:
	for(seg of newSegs){
		delete seg.$needLayout;
		delete seg.$layout;
	}
};



export {layoutSegs};
