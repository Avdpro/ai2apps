import pathLib from "/@path";
import inherits from "/@inherits";
import {VFACT} from "/@vfact";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {EditDocExporter,genAttrValText,genLocalizeValText,genLocalizeValTextPy} from "../exporters/EditDocExporter.js";
import {CdyCoder} from "../exporters/CoderPython.js";
import {DocClassExporter} from "../exporters/DocClassExporter.js";

var DocPyAgentExporter,docPyAgentExporter;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
let segTypeExporters={};
//****************************************************************************
//Export doc to code text, all edit-object will be export as VO-Object
DocPyAgentExporter=function(prj){
	EditDocExporter.call(this,prj);
	this.isPython=true;
};
DocPyAgentExporter.segTypeExporters=segTypeExporters;
EditDocExporter.regExporter("AIAgent",DocPyAgentExporter);
inherits(DocPyAgentExporter,EditDocExporter);
docPyAgentExporter=DocPyAgentExporter.prototype;
if(VFACT.classRegs){
	VFACT.classRegs.DocPyAgentExporter=DocPyAgentExporter;
}

//----------------------------------------------------------------------------
let exportDebug=false;
docPyAgentExporter.isExportDebug=function(){
	return exportDebug;
};

function genArgShowName(argVal,isPython){
	let attrLabel;
	attrLabel=argVal.getAttr("label");
	if(!attrLabel || !attrLabel.valText){
		return "undefined";
	}
	if(attrLabel.localize){
		if(isPython){
			return genLocalizeValTextPy(attrLabel);
		}else{
			return genLocalizeValText(attrLabel);
		}
	}
	return `"${attrLabel.val}"`;
}

//----------------------------------------------------------------------------
docPyAgentExporter.export=function(editDoc,opts){
	let list,i,n,coder,exportObjs,subStates;
	let path,baseName,exportName;
	opts=opts||{};
	subStates=[];
	exportObjs=[];
	this.coder=coder=new CdyCoder();
	coder.packText("#Auto genterated by Cody");
	coder.newLine();
	exportDebug=editDoc.getAttr("debug").val;
	path=editDoc.getAttr("path").val;
	baseName=pathLib.basename(path);
	{
		let pos=baseName.indexOf(".");
		exportName=(pos>0)?(baseName.substring(0,pos)):baseName;
		exportObjs.push(exportName);
	}

	//Imports:
	{
		coder.packText(`import os`,0);
		coder.newLine();
		coder.packText(`import json`,0);
		coder.newLine();
		coder.packText(`import base64`,0);
		coder.newLine();
		coder.packText(`import urllib.parse`,0);
		coder.newLine();
		coder.packText(`import importlib`,0);
		coder.newLine();
		coder.packText(`from session import trimJSON`,0);
		coder.newLine();
	}
	coder.beginDocObjTagBlcok(editDoc,"MoreImports");
	coder.endDocObjTagBlcok(editDoc,"MoreImports",0);
	//coder.packText(`__Ln="EN"#Active language`,0);
	coder.newLine();
	coder.packText(`true=True`,0);
	coder.newLine();
	coder.packText(`false=False`,0);
	coder.newLine();
	coder.packText(`undefined=None`,0);
	coder.newLine();
	coder.packText(`pathLib= os.path`,0);
	coder.newLine();
	coder.packText(`agentURL= pathLib.abspath(__file__)`,0);
	coder.newLine();
	coder.packText(`basePath=pathLib.dirname(agentURL)`,0);
	coder.newLine();

	//Arguments template:
	{
		let args,arg,attr;
		coder.newLine();
		args=editDoc.getAttr("apiArgs").attrList;
		if(args.length>0){
			coder.packText("argsTemplate={");
			coder.indentMore();coder.newLine();
			{
				coder.packText(`"properties":{`);coder.indentMore();coder.newLine();
				{
					for(arg of args){
						coder.packText(`"${arg.name}":{`);coder.indentMore();coder.newLine();
						{
							coder.packText(`"name":"${arg.name}","type":"${arg.getAttrVal("type")}",`);coder.newLine();
							attr=arg.getAttr("label");
							if(attr && attr.valText){
								coder.packText(`"label":"${arg.getAttrVal("label")}",`);coder.newLine();
							}
							attr=arg.getAttr("required");
							if(attr && attr.valText){
								coder.packText(`"required":${!!arg.getAttrVal("required")},`);coder.newLine();
							}
							coder.packText(`"defaultValue":${JSON.stringify(arg.getAttrVal("mockup"))},`);coder.newLine();
							coder.packText(`"desc":"${arg.getAttrVal("desc")}",`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();coder.packText("},");coder.newLine();
					}
					coder.eatPreComa();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText("},");coder.newLine();
				coder.beginDocObjTagBlcok(editDoc,"ArgsView");
				coder.endDocObjTagBlcok(editDoc,"ArgsView",0);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText("}");coder.newLine();
			coder.newLine();
		}
	}

	coder.beginDocObjTagBlcok(editDoc,"StartDoc");
	coder.endDocObjTagBlcok(editDoc,"StartDoc",0);

	//Export Major hud-gear:
	{
		let exportObj,attr,localVars,seg0,segNames;
		exportObj=editDoc;
		coder.packText("##----------------------------------------------------------------------------");
		coder.newLine();
		coder.packText(`async def ${exportName}(session):`);
		{
			coder.indentMore();
			coder.newLine();
			//Add exec-arguments:
			{
				let args=editDoc.getAttr("apiArgs").attrList;
				if(args.length>0){
					let arg;
					for(arg of args){
						coder.packText(`${arg.name}=None`);coder.newLine();
					}
					coder.newLine();
				}else{
					coder.packText("execInput=None");coder.newLine();
				}
			}
			coder.packText("context, globalContext = None, None");coder.newLine();
			coder.packText("self = None");coder.newLine();
			coder.packText(`__Ln = session.language or "CN"`);coder.newLine();
			seg0=exportObj.segsList[0];
			//named segs
			{
				let i,n;
				segNames=[];
				exportObj.runOnAllSegs((seg)=>{
					let name=seg.getAttr("id").val;
					if(name && varNameRegex.test(name)){
						segNames.push(name);
					}else if(!seg.isConnector){
						segNames.push("SEG"+seg.jaxId);
					}
				},false);
				n=segNames.length;
				if(n){
					let name,names,count;
					names={};
					coder.maybeNewLine();
					coder.packText(``);
					count=0;
					for(i=0;i<n;i++){
						name=segNames[i];
						if(!names[name]){
							if(i>0){
								coder.packText(`, `);
							}
							coder.packText(name);
							names[name]=1;
							count++;
						}
					}
					coder.packText(` = `);
					for(i=0;i<count;i++){
						if(i>0){
							coder.packText(`, `);
						}
						coder.packText("None");
					}
					coder.newLine();
				}else{
					coder.newLine();
				}
			}
			//Add localVars;
			localVars=editDoc.getAttr("localVars").attrList;
			if(localVars.length>0){
				for(attr of localVars){
					this.genLocalVar(attr,subStates);
				}
				coder.newLine();
			}
			coder.beginDocObjTagBlcok(exportObj,"LocalVals");
			coder.endDocObjTagBlcok(exportObj,"LocalVals",0);
			coder.newLine();
			coder.newLine();
			{
				let args=editDoc.getAttr("apiArgs").attrList;
				coder.packText("def parseAgentArgs(input):");coder.indentMore();	coder.newLine();
				{
					if(args.length>0){
						let arg;
						coder.packText(`nonlocal `);
						for(arg of args){
							coder.packText(`${arg.name},`);
						}
						coder.eatPreComa();coder.newLine();
						coder.packText("if isinstance(input, dict):");
						coder.indentMore();	coder.newLine();
						{
							for(arg of args){
								coder.packText(`${arg.name}=input.get("${arg.name}")`);coder.newLine();
							}
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText("else:");
						coder.indentMore();coder.newLine();
						{
							for(arg of args){
								coder.packText(`${arg.name}=None`);coder.newLine();
							}
						}
						coder.indentLess();coder.maybeNewLine();
					}else{
						coder.packText("execInput=input");coder.newLine();
					}
					coder.beginDocObjTagBlcok(editDoc,"ParseArgs");
					coder.endDocObjTagBlcok(editDoc,"ParseArgs",0);
				}
				coder.indentLess();coder.maybeNewLine();coder.maybeNewLine();
				coder.newLine();
			}
			coder.beginDocObjTagBlcok(exportObj,"PreContext");
			coder.endDocObjTagBlcok(exportObj,"PreContext",0);
			coder.packText("globalContext = session.globalContext");
			coder.maybeNewLine();
			//Context:
			{
				let stateObj=editDoc.getAttr("context");
				if(stateObj.attrList.length>0){
					coder.packText("context = ");
					this.genContextObjSeg(editDoc.getAttr("context"),false,"ExCtxAttrs");
					coder.eatPreComa();
					coder.newLine();
				}else{
					coder.packText("context = {}");
					coder.newLine();
				}
			}
			coder.beginDocObjTagBlcok(exportObj,"PostContext");
			coder.endDocObjTagBlcok(exportObj,"PostContext",0);
			coder.packText("_agent,agent,segs = None, None, {}");coder.newLine();
			coder.newLine();
			
			//Export segs:
			{
				let segsList,seg;
				segsList=exportObj.segsList;
				for(seg of segsList){
					this.exportSeg(seg);
				}
			}
			
			//Export agent 
			if(seg0){
				let entrySeg=null;
				{
					let segName=exportObj.getAttrVal("entry");
					let list=exportObj.segsVal.attrList;
					if(segName){
						for(let seg of list){
							if(seg.idVal.val===segName){
								entrySeg=seg;
								break;
							}
						}
					}
				}
				entrySeg=entrySeg||seg0;
				let segName=entrySeg.getAttr("id").val;
				segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+entrySeg.jaxId);

				//Exec function:
				coder.packText(`async def execAgent(input):`);
				/*let args=editDoc.getAttr("apiArgs").attrList;
				if(args.length>0){
					let arg;
					for(arg of args){
						coder.packText(`${arg.name}, `);
					}
					coder.eatPreSpace();
					coder.eatPreComa();
					coder.packText(`):`);
				}else{
					coder.packText(`input):`);
				}*/
				//TODO: Add parse args code:
				coder.indentMore();				
				coder.newLine();
				{
					coder.packText(`result = None`);coder.newLine();
					coder.packText(`parseAgentArgs(input)`);coder.newLine();
					coder.beginDocObjTagBlcok(exportObj,"PreEntry");
					coder.endDocObjTagBlcok(exportObj,"PreEntry",0);
					coder.packText(`result = {"seg":${segName},"input":input}`);coder.newLine();
					coder.beginDocObjTagBlcok(exportObj,"PostEntry");
					coder.endDocObjTagBlcok(exportObj,"PostEntry",0);
					coder.packText(`return result`);
				}
				coder.indentLess();				
				coder.maybeNewLine();
				
				coder.packText("_agent = agent = {");
				coder.indentMore();				
				coder.newLine();
				{
					coder.packText(`"isAIAgent": true,`);
					coder.newLine();
					coder.packText(`"session": session,`);
					coder.newLine();
					coder.packText(`"name": "${exportName}",`);
					coder.newLine();
					coder.packText(`"url": agentURL,`);
					coder.newLine();
					coder.packText(`"baseDir": basePath,`);
					coder.newLine();
					coder.packText(`"autoStart": ${exportObj.getAttrVal("autoStart")},`);
					coder.newLine();
					if(exportDebug){
						coder.packText(`"jaxId": "${editDoc.jaxId}",`);
						coder.newLine();
					}
					coder.packText(`"context": context,`);
					coder.newLine();
					coder.packText(`"livingSeg": None,`);
					coder.newLine();
					coder.packText(`"execChat": execAgent,`);
					coder.newLine();
					coder.beginDocObjTagBlcok(exportObj,"MoreAgentAttrs");
					coder.endDocObjTagBlcok(exportObj,"MoreAgentAttrs",0);
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText("}");
				coder.newLine();
			}
			

			coder.beginDocObjTagBlcok(exportObj,"PostAgent");
			coder.endDocObjTagBlcok(exportObj,"PostAgent",0);
			coder.packText("return agent");
			coder.indentLess();
			coder.maybeNewLine();
		}
		coder.maybeNewLine();

		coder.beginDocObjTagBlcok(exportObj,"ExCodes");
		coder.endDocObjTagBlcok(exportObj,"ExCodes",0);
		coder.newLine();
	}

	if(editDoc.getAttrVal("exportAPI")){
		let addOnOpts,segName,showName,segIcon,catalog,agentPath;
		addOnOpts=editDoc.getAttrVal("addOnOpts")||{};
		coder.packText(`ChatAPI=[{`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"def":{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`"name": "${exportName}",`);coder.newLine();
				coder.packText(`"description": ${JSON.stringify(editDoc.getAttrVal("desc"))},`),coder.newLine();
				coder.packText(`"parameters":{`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`"type": "object",`);coder.newLine();
					coder.packText(`"properties":{`);
					coder.indentMore();
					coder.newLine();
					{
						let list,i,n,attr,enumAttr;
						list=editDoc.getAttr("apiArgs").attrList;
						n=list.length;
						for(i=0;i<n;i++){
							attr=list[i];
							coder.packText(`"${attr.name}":{"type":"${attr.getAttrVal("type")}","description":${JSON.stringify(attr.getAttrVal("desc"))},`);
							enumAttr=attr.getAttr("enum");
							if(enumAttr && enumAttr.attrList.length>0){
								coder.packText(`"enum":[`);
								for(attr of enumAttr.attrList){
									coder.packText(JSON.stringify(attr.val));
									coder.packText(",");
								}
								coder.eatPreComa();
								coder.packText(`]`);
							}
							coder.eatPreComa();
							coder.packText(`},`);
							coder.newLine();
						}
					}
					coder.eatPreComa();
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);
					coder.newLine();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`},`);
			coder.newLine();
			if(addOnOpts.path){
				coder.packText(`"path": ${JSON.stringify(addOnOpts.path)},`);coder.newLine();
			}
			if(addOnOpts.label && !addOnOpts.label.startsWith("#>")){
				coder.packText(`"label": ${JSON.stringify(addOnOpts.label)},`);coder.newLine();
			}
			if(addOnOpts.isRPA){
				coder.packText(`"isRPA": true,`);coder.newLine();
				coder.packText(`"rpaHost": ${JSON.stringify(addOnOpts.rpaHost)},`);coder.newLine();
			}
			coder.packText(`"agent": ${exportName}`);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}]`);
		coder.newLine();
	}else{
		coder.packText(`ChatAPI=None`);coder.newLine();
	}

	//------------------------------------------------------------------------
	//export
	coder.newLine();
	coder.packText(`default=${exportObjs[0]}`);coder.newLine();
	coder.packText(`__all__=["default",`);
	n=exportObjs.length;
	for(i=0;i<n;i++){
		coder.packText(`"`+exportObjs[i]+`"`);
		coder.packText(",");
	}
	coder.eatPreComa();
	coder.packText(`,"ChatAPI"]`);
	coder.newLine();
	
	coder.packText(`""">>>CodyExport`);coder.newLine();
	//------------------------------------------------------------------------
	//API list:
	coder.packText(`let ChatAPI,Exports;`);coder.newLine();
	if(editDoc.getAttrVal("exportAPI")){
		let addOnOpts,segName,showName,segIcon,catalog,agentPath;
		addOnOpts=editDoc.getAttrVal("addOnOpts")||{};
		coder.packText(`ChatAPI=[{`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`def:{`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`name: "${exportName}",`);coder.newLine();
				coder.packText(`description: ${JSON.stringify(editDoc.getAttrVal("desc"))},`),coder.newLine();
				coder.packText(`parameters:{`);
				coder.indentMore();
				coder.newLine();
				{
					coder.packText(`type: "object",`);coder.newLine();
					coder.packText(`properties:{`);
					coder.indentMore();
					coder.newLine();
					{
						let list,i,n,attr,enumAttr;
						list=editDoc.getAttr("apiArgs").attrList;
						n=list.length;
						for(i=0;i<n;i++){
							attr=list[i];
							coder.packText(`${attr.name}:{type:"${attr.getAttrVal("type")}",description:${JSON.stringify(attr.getAttrVal("desc"))},`);
							enumAttr=attr.getAttr("enum");
							if(enumAttr && enumAttr.attrList.length>0){
								coder.packText(`enum:[`);
								for(attr of enumAttr.attrList){
									coder.packText(JSON.stringify(attr.val));
									coder.packText(",");
								}
								coder.eatPreComa();
								coder.packText(`]`);
							}
							coder.eatPreComa();
							coder.packText(`},`);
							coder.newLine();
						}
					}
					coder.eatPreComa();
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`}`);
					coder.newLine();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`}`);
				coder.newLine();
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`},`);
			coder.newLine();
			if(addOnOpts.path){
				coder.packText(`path: ${JSON.stringify(addOnOpts.path)},`);coder.newLine();
			}
			if(addOnOpts.pathInHub){
				let nodeName,agentName;
				let hubPath=addOnOpts.pathInHub;
				let pts=hubPath.split("@");
				if(pts>1){
					nodeName=pts[0];
					agentName=pts[1];
				}else{
					nodeName=hubPath;
					agentName=pathLib.basename(editDoc.path);
				}
				if(nodeName && agentName){
					coder.packText(`agentNode: ${JSON.stringify(nodeName)},`);coder.newLine();
					coder.packText(`agentName: ${JSON.stringify(agentName)},`);coder.newLine();
				}
			}
			if(addOnOpts.label){
				let label;
				label=addOnOpts.label;
				if(label.startsWith(">#")){
					//label=label.substring(2);
				}else{
					label=JSON.stringify(addOnOpts.label);
					coder.packText(`label: ${label},`);coder.newLine();
				}
			}
			if(addOnOpts.isChatApi===false){
				coder.packText(`isChatApi: false,`);coder.newLine();
			}else{
				coder.packText(`isChatApi: true,`);coder.newLine();
			}
			if(addOnOpts.isRPA){
				coder.packText(`isRPA: true,`);coder.newLine();
				//coder.packText(`rpaHost: ${JSON.stringify(addOnOpts.rpaHost)},`);coder.newLine();
			}
			if(addOnOpts.chatEntry){
				coder.packText(`chatEntry: ${JSON.stringify(addOnOpts.chatEntry)},`);coder.newLine();
			}
			if(addOnOpts.capabilities){
				coder.packText(`capabilities: ${JSON.stringify(addOnOpts.capabilities)},`);coder.newLine();
			}
			if(addOnOpts.meta){
				coder.packText(`meta: ${JSON.stringify(addOnOpts.meta)},`);coder.newLine();
			}
			if(addOnOpts.segIcon){
				coder.packText(`icon: ${JSON.stringify(addOnOpts.segIcon)},`);coder.newLine();
			}
			coder.packText(`agent: true`);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}];`);
		coder.newLine();
	}
	//------------------------------------------------------------------------
	//Agent Add-On:
	if(editDoc.getAttrVal("exportAddOn")){
		coder.newLine();
		coder.packText(`//:Export Edit-AddOn:`);coder.newLine();
		coder.packText(`const DocPyAgentExporter=VFACT.classRegs.DocPyAgentExporter;`);coder.newLine();
		coder.packText(`if(DocPyAgentExporter){`);coder.indentMore();coder.newLine();
		{
			let addOnOpts,segName,showName,segIcon,catalog,agentPath;
			addOnOpts=editDoc.getAttrVal("addOnOpts")||{};
			segName=addOnOpts.name||exportName;
			showName=addOnOpts.label||segName;
			{
				if(showName.startsWith(">#")){
					showName=showName.substring(2);
				}else{
					showName=JSON.stringify(showName);
				}
			}
			segIcon=addOnOpts.segIcon||"agent.svg";
			catalog=addOnOpts.catalog||"AI Call";
			agentPath=addOnOpts.path||(""+pathLib.basename(editDoc.dataDoc.path));
			coder.packText(`const $ln=VFACT.lanCode;`);coder.newLine();
			coder.packText(`const EditAttr=VFACT.classRegs.EditAttr;`);coder.newLine();
			coder.packText(`const EditAISeg=VFACT.classRegs.EditAISeg;`);coder.newLine();
			coder.packText(`const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;`);coder.newLine();
			coder.packText(`const SegObjShellAttr=EditAISeg.SegObjShellAttr;`);coder.newLine();
			coder.packText(`const SegOutletDef=EditAISegOutlet.SegOutletDef;`);coder.newLine();
			coder.packText(`const docPyAgentExporter=DocPyAgentExporter.prototype;`);coder.newLine();
			coder.packText(`const packExtraCodes=docPyAgentExporter.packExtraCodes;`);coder.newLine();
			coder.packText(`const packResult=docPyAgentExporter.packResult;`);coder.newLine();
			coder.packText(`const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;`);coder.newLine();
			coder.newLine();
			//Seg def:
			coder.packText(`EditAISeg.regDef({`);coder.indentMore();coder.newLine();
			{
				let list,attr,i,n;
				coder.packText(`name:"${segName}",showName:${showName},icon:"${segIcon}",catalog:["${catalog}"],`);coder.newLine();
				coder.packText(`attrs:{`);coder.indentMore();coder.newLine();
				{
					coder.packText(`...SegObjShellAttr,`);coder.newLine();
					//Pack arguments:
					list=editDoc.getAttr("apiArgs").attrList;
					n=list.length;
					for(i=0;i<n;i++){
						attr=list[i];
						coder.packText(`"${attr.name}":{name:"${attr.name}",showName:${genArgShowName(attr)},type:"${attr.getAttrVal("type")}",key:1,fixed:1,initVal:${JSON.stringify(attr.getAttrVal("mockup"))}},`);
						coder.newLine();
					}
					coder.packText(`"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`},`);coder.newLine();
				coder.packText(`listHint:["id",`);
				for(i=0;i<n;i++){
					attr=list[i];
					coder.packText(`"${attr.name}",`);
				}
				coder.packText(`"codes","desc"],`);coder.newLine();
				coder.packText(`desc:${JSON.stringify(editDoc.getAttrVal("desc"))}`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`});`);coder.newLine();
			coder.newLine();
			
			//Export seg function:
			this.exportAgentSeg(editDoc,segName,agentPath);
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}`);
		coder.newLine();
	}
	coder.newLine();
	
	coder.maybeNewLine();
	coder.packText(`return {api:ChatAPI,export:Exports};`);
	coder.maybeNewLine();
	coder.packText(`>>>CodyExport"""`);coder.newLine();

	return coder.genDocText();
};

//----------------------------------------------------------------------------
docPyAgentExporter.genLocalVar=function(attr,subStates=null){
	let coder=this.coder;
	coder.packText(`${attr.name} = `);
	this.genAttrStatement(attr);
	coder.newLine();
};

//----------------------------------------------------------------------------
docPyAgentExporter.exportSeg=function(seg){
	let typeName,funcName,func;
	typeName=seg.objDef.name;
	funcName="export_"+typeName;
	func=this[funcName]||segTypeExporters[typeName];
	if(func){
		func.call(this,seg);
	}
};

//----------------------------------------------------------------------------
docPyAgentExporter.genContextObjSeg=function(editObj,exSeg){
	let coder=this.coder;
	coder.packText("{");
	coder.indentMore();
	coder.newLine();
	{
		let list,i,n,attr;
		list=editObj.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.objDef && attr.objDef.name==="AgentCallArgument"){
				coder.packText(`"${attr.name}":`);
				this.genInObjSegAttr(attr.getAttr("mockup"),false);
				coder.maybeNewLine();
			}else if(attr.def.export!==false) {
				this.genInObjSegAttr(attr);
				coder.maybeNewLine();
			}
		}
		if(exSeg){
			coder.beginDocObjTagBlcok(editObj,exSeg);
			coder.endDocObjTagBlcok(editObj,exSeg);
		}else{
			coder.eatPreComa();
		}
	}
	coder.indentLess();
	coder.maybeNewLine();
	coder.packText("}");
};

//----------------------------------------------------------------------------
docPyAgentExporter.exportAgentSeg=function(editDoc,name,path){
	let coder;
	coder=this.coder;
	coder.packText(`DocPyAgentExporter.segTypeExporters["${name}"]=`);coder.newLine();
	coder.packText(`function(seg){`);coder.indentMore();coder.newLine();
	{
		coder.packText('let coder=this.coder;');coder.newLine();
		coder.packText('let segName=seg.idVal.val;');coder.newLine();
		coder.packText('let exportDebug=this.isExportDebug();');coder.newLine();
		coder.packText('segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);');coder.newLine();
		coder.packText('coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);');coder.newLine();
		coder.packText('coder.indentMore();coder.newLine();');coder.newLine();
		coder.packText("{");coder.indentMore();coder.newLine();
		let list,attr,i,n;
		coder.packText("coder.packText(`result=None`);coder.newLine();");coder.newLine();
		coder.packText("coder.packText(`args={}`);coder.newLine();");coder.newLine();
		//Pack arguments:
		list=editDoc.getAttr("apiArgs").attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			coder.packText(`coder.packText("args['${attr.name}']=");this.genAttrStatement(seg.getAttr("${attr.name}"));coder.newLine();`);coder.newLine();
		}
		coder.packText('this.packExtraCodes(coder,seg,"PreCodes");');coder.newLine();
		//Call agent:
		coder.packText(`coder.packText(\`result= await session.pipeChat(${JSON.stringify(path)},args,false)\`);coder.newLine();`);coder.newLine();
		coder.packText('this.packExtraCodes(coder,seg,"PostCodes");');coder.newLine();
		//Result:
		coder.packText('this.packResult(coder,seg,seg.outlet);');coder.newLine();
		coder.indentLess();coder.maybeNewLine();coder.packText("}");
		coder.newLine();
		coder.packText('coder.indentLess();coder.maybeNewLine();');coder.newLine();
		coder.packText(`coder.packText(\`segs["\${segName}"]=\${segName}={\`);`);coder.newLine();
		coder.packText('coder.indentMore();coder.newLine();');coder.newLine();
		coder.packText(`coder.packText(\`"name":"\${segName}",\`);coder.newLine()`);coder.newLine();
		coder.packText(`coder.packText(\`"exec":\${segName}_exec,\`);coder.newLine()`);coder.newLine();
		coder.packText(`coder.packText(\`"jaxId":"\${seg.jaxId}\",\`);coder.newLine()`);coder.newLine();
		coder.packText(`coder.packText(\`"url":"\${segName}@\"+agentURL\`);coder.newLine()`);coder.newLine();
		coder.packText('coder.indentLess();coder.maybeNewLine();coder.packText("}");coder.newLine();');coder.newLine();
		coder.packText('coder.newLine();');coder.newLine();
	}
	coder.indentLess();coder.maybeNewLine();coder.packText(`};`);coder.newLine();
};

//****************************************************************************
//:Export typed segs
//****************************************************************************
{
	//------------------------------------------------------------------------
	function packResult(coder,seg,outlet,valName="result",applyCatch=true){
		let nextSeg,segName,outletId,catchlet;
		catchlet=applyCatch?seg.catchlet:null;
		outletId="";
		if(outlet){
			outletId=outlet.jaxId;
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(catchlet){
				let catchletId,catchSeg,catchName;
				catchletId=catchlet.jaxId;
				catchSeg=catchlet.getLinkedSeg();
				if(catchSeg){
					catchName=catchSeg.idVal.val||(("SEG")+catchSeg.jaxId);
					catchName=(catchName &&varNameRegex.test(catchName))?catchName:("SEG"+catchName.jaxId);
				}else{
					catchName="null";
				}
				if(exportDebug){
					coder.packText(`return {"seg":${segName},"result":(${valName}),"preSeg":"${seg.jaxId}","outlet":"${outletId}","catchSeg":${catchName},"catchlet":"${catchletId}"}`);
				}else{
					coder.packText(`return {"seg":${segName},"result":(${valName},"catchSeg":${catchName})}`);
				}
			}else{
				if(exportDebug){
					coder.packText(`return {"seg":${segName},"result":(${valName}),"preSeg":"${seg.jaxId}","outlet":"${outletId}"}`);
				}else{
					coder.packText(`return {"seg":${segName},"result":(${valName})}`);
				}
			}
		}else{
			coder.packText(`return {"result":${valName}}`);
		}
	}
	docPyAgentExporter.packResult=packResult;
	
	//------------------------------------------------------------------------
	function packSegCall(coder,outlet,valName="input",isAsync=false){
		let nextSeg,segName;
		if(outlet){
			nextSeg=outlet.getLinkedSeg();
		}
		if(nextSeg){
			segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
			segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
			if(isAsync){
				coder.packText(`session.execAISeg(agent,${segName},(${valName}))`);
			}else{
				coder.packText(`await session.execAISeg(agent,${segName},(${valName}))`);
			}
		}else{
			coder.packText(`${valName}`);
		}
	}
	docPyAgentExporter.packSegCall=packSegCall;
	
	//------------------------------------------------------------------------
	function packExtraCodes(coder,seg,mark="Codes"){
		let codes=seg.getAttr("codes");
		if(codes){
			codes=!!codes.val;
		}
		if(codes){
			coder.beginDocObjTagBlcok(seg,mark);
			coder.endDocObjTagBlcok(seg,mark,0);
		}
	}
	docPyAgentExporter.packExtraCodes=packExtraCodes;

	//------------------------------------------------------------------------
	function packUpdateContext(coder,seg){
		let ctxAttr=seg.getAttr("context");
		let castAttr,castObj,key,value;
		if(!ctxAttr||!ctxAttr.attrList){
			return;
		}
		castAttr=ctxAttr.getAttr("cast");
		if(castAttr){
			let keys;
			castObj=castAttr.valText;
			try{
				castObj=JSON.parse(castObj);
			}catch(err){
				castObj=null;
			}
			if(castObj){
				keys=Object.keys(castObj);
				if(keys.length>0){
					for(key of keys){
						value=""+castObj[key];
						if(value){
							if(value.startsWith("#")){
								value=value.substring(1);
							}
							coder.packText(`context["${key}"]=${value};`);coder.newLine();
						}
					}
					return;
				}
			}
			return;
		}
		
		if(ctxAttr.attrList.length>0){
			coder.packText(`context.update(`);this.genAttrStatement(ctxAttr);coder.packText(`)`);
			coder.newLine();
		}
	}
	docPyAgentExporter.packUpdateContext=packUpdateContext;
	
	//------------------------------------------------------------------------
	function packUpdateGlobal(coder,seg){
		let ctxAttr=seg.getAttr("global");
		if(!ctxAttr||ctxAttr.attrList){
			return;
		}
		if(ctxAttr.attrList.length>0){
			coder.packText(`globalContext.update(`);this.genAttrStatement(ctxAttr);coder.packText(`)`);
			coder.newLine();
		}
	}
	docPyAgentExporter.packUpdateGlobal=packUpdateGlobal;
	
	//------------------------------------------------------------------------
	docPyAgentExporter.export_tryCatch=
	docPyAgentExporter.export_code=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let resultVal=seg.getAttr("result");
		let outlets=seg.outletsList;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`nonlocal segs`);coder.newLine();
			coder.packText(`result=`);
			if(resultVal){
				this.genAttrStatement(resultVal);
			}else{
				coder.packText("input");
			}
			coder.newLine();
			if(outlets && outlets.length>0){
				let i,n,outlet,nextSeg,nextSegName;
				coder.packText(`outlets={`);coder.indentMore();coder.newLine();
				{
					n=outlets.length;
					for(i=0;i<n;i++){
						outlet=outlets[i];
						let nextSeg=outlet.getLinkedSeg();
						if(nextSeg){
							nextSegName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
							nextSegName=(nextSegName &&varNameRegex.test(nextSegName))?nextSegName:("SEG"+nextSeg.jaxId);
							coder.packText(`"${outlet.getAttrVal("id")}": segs["${nextSegName}"],`);
						}
					}
				}
				coder.eatPreComa();coder.indentLess();coder.maybeNewLine();coder.packText(`};`);
			}
			coder.maybeNewLine();
			coder.beginDocObjTagBlcok(seg,"Code");
			coder.endDocObjTagBlcok(seg,"Code",0);
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_function=function(seg){
		let resultVal=seg.getAttr("result");
		let sourcePath=seg.getAttr("source").val;
		let funcName=seg.getAttr("function").val;
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`result=None`);
			coder.maybeNewLine();
			coder.packText(`md=await session.importFile("${sourcePath}")`);coder.newLine();
			coder.packText(`func=getattr(md,"${funcName}")`);coder.newLine();
			coder.packText(`result= await func(agent,input)`);coder.newLine();
			if(resultVal){
				coder.packText(`result=`);
				this.genAttrStatement(resultVal);
				coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg);
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_callLLM=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let keepNum=seg.getAttrVal("keepChat");
		let docPath=pathLib.dirname(seg.doc.path);
		let apiList,apiFiles;
		let prefixTxt=seg.getAttrValText("inputPrefix");
		let postfixTxt=seg.getAttrValText("inputPostfix");
		let clearNum=seg.getAttrVal("clearChat");
		let allowCheat=seg.getAttrVal("allowCheat");
		let hasCode=seg.getAttrVal("codes");
		let shareChatName=seg.getAttrVal("shareChatName");
		let parallelFunction=seg.getAttrVal("parallelFunction");
		let responseFormat=seg.getAttrVal("responseFormat");
		
		apiFiles=seg.getAttr("apiFiles").attrList;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`prompt=None`);coder.newLine();
			if(hasCode){
				coder.packText(`result=None`);coder.newLine();
			}else{
				coder.packText(`result=None`);coder.newLine();
			}
			packExtraCodes(coder,seg,"Input");coder.newLine();
			//Call options:
			coder.packText(`opts={`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`"mode":`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`,`);coder.newLine();
				coder.packText(`"maxToken":`);this.genAttrStatement(seg.getAttr("maxToken"));coder.packText(`,`);coder.newLine();
				coder.packText(`"temperature":`);this.genAttrStatement(seg.getAttr("temperature"));coder.packText(`,`);coder.newLine();
				coder.packText(`"topP":${seg.getAttrVal("topP")},`);coder.newLine();
				coder.packText(`"fqcP":${seg.getAttrVal("fqcP")},`);coder.newLine();
				coder.packText(`"prcP":${seg.getAttrVal("prcP")},`);coder.newLine();
				coder.packText(`"secret":`);this.genAttrStatement(seg.getAttr("secret"));coder.packText(`,`);coder.newLine();
				coder.packText(`"responseFormat":`);this.genAttrStatement(seg.getAttr("responseFormat"));coder.packText(`,`);coder.newLine();
				if(apiFiles.length>0){
					coder.packText(`"apis":${segName}["apis"],`);coder.newLine();
					if(parallelFunction){
						coder.packText(`"parallelFunction":true,`);coder.newLine();
					}
				}
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`}`);
			coder.newLine();
			
			if(shareChatName){
				coder.packText(`chatMem=context.get("${shareChatName}",[])`);coder.newLine();
			}else{
				coder.packText(`chatMem=${segName}.get("messages",[])`);coder.newLine();
			}
			
			coder.packText(`seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(``);coder.newLine();
			coder.packText(`if(seed):`);
			coder.indentMore();coder.newLine();
			coder.packText(`opts.seed=seed`);
			coder.indentLess();coder.newLine();

			coder.packText(`messages=[`);
			coder.indentMore();
			coder.newLine();
			{
				let list,i,n,attr;
				//System message:
				coder.packText(`{"role":"system","content":`);this.genAttrStatement(seg.getAttr("system"));coder.packText(`},`);coder.newLine();
				list=seg.getAttr("messages").attrList;
				n=list.length;
				for(i=0;i<n;i++){
					attr=list[i];
					coder.packText(`{"role":"${attr.getAttrVal("role")}","content":`);this.genAttrStatement(attr.getAttr("content"));coder.packText(`},`);coder.newLine();
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`]`);
			coder.maybeNewLine();
			if(seg.getAttrVal("keepChat")){
				coder.packText(`messages.extend(chatMem)`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PrePrompt");
			coder.packText(`prompt=`);this.genAttrStatement(seg.getAttr("prompt"));	coder.newLine();
			coder.packText(`if(prompt):`);
			coder.indentMore();	coder.newLine();
			coder.packText(`if not isinstance(prompt,str):`);
			coder.indentMore();	coder.newLine();
			coder.packText(`prompt=json.dumps(prompt,indent=4)`);
			coder.indentLess();	coder.newLine();
			coder.packText(`messages.append({"role":"user","content":prompt})`);
			coder.indentLess();	coder.newLine();
			packExtraCodes(coder,seg,"PreCall");
			if(allowCheat){
				coder.packText(`result=${segName}['cheats'][input];`);
				coder.newLine();
				coder.packText(`if !result:`);
				coder.indentMore();
				coder.newLine();
				{
					if(hasCode){
						coder.packText(`result=(await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)) if (not result) else result`);coder.newLine();
					}else{
						coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)`);coder.newLine();
					}
				}
				coder.indentLess();
				coder.newLine();
				coder.newLine();
			}else{
				if(hasCode){
					coder.packText(`result=(await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)) if (not result) else result`);coder.newLine();
				}else{
					coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)`);coder.newLine();
				}
			}
			if(keepNum>0){
				coder.packText(`chatMem.append({"role":"user","content":prompt})`);coder.newLine();
				coder.packText(`chatMem.append({"role":"assistant","content":result})`);coder.newLine();
				if(keepNum<200){
					coder.packText(`if len(chatMem)>${keepNum}:`);
					coder.indentMore();
					coder.newLine();
					{
						coder.packText(`removedMsgs=chatMem[${clearNum}:]`);
						coder.newLine();
						coder.packText(`del chatMem[:${clearNum}]`);
						packExtraCodes(coder,seg,"PostClear");
					}
					coder.indentLess();
					coder.maybeNewLine();
				}
			}
			if(responseFormat==="json_object"){
				coder.maybeNewLine();
				coder.packText(`result=trimJSON(result)`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCall");
			//Result:
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();

		if(keepNum>0 && shareChatName){
			coder.packText(`context["${shareChatName}"]=context["${shareChatName}"] if("${shareChatName}" in context) else []`);
		}
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			if(keepNum>0){
				if(!shareChatName){
					coder.packText(`"messages":[],`);coder.newLine();
				}
			}
			if(allowCheat){
				coder.packText(`"cheats":{`);
				coder.indentMore();
				coder.newLine();
				{
					let cheat;
					let list=seg.getAttr("GPTCheats").attrList;
					for(cheat of list){
						coder.maybeNewLine();
						coder.packText(`${JSON.stringify(cheat.getAttrVal("prompt"))}:${JSON.stringify(cheat.getAttrVal("reply"))},`);
					}
					coder.eatPreComa();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.packText(`},`);
				coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		
		if(apiFiles.length>0){//TODO: Choose in funcation-call or toolCalls:
			let i,n,path;
			n=apiFiles.length;
			coder.packText(`${segName}["apis"]=await session.loadAISegAPIs([`);
			for(i=0;i<n;i++){
				path=apiFiles[i].val;
				if(path){
					if(!path.startsWith("/@")){
						path=pathLib.relative(docPath,path);
						if(path[0]!=="."&&path[0]!=="/"){
							path="./"+path;
						}
					}
					coder.packText(`"${path}",`);
				}
			}
			coder.eatPreComa();
			coder.packText(`])`);
			coder.newLine();
		}
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_aiVision=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlet=seg.outlet;
		let secret=seg.getAttrVal("secret");
		let hasCode=seg.getAttrVal("codes");
		let imageAttr=seg.getAttr("image");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`prompt=None`);coder.newLine();
			coder.packText(`result=None`);coder.newLine();
			packExtraCodes(coder,seg,"Input");coder.newLine();
			coder.packText(`imageURL=`);this.genAttrStatement(imageAttr);coder.newLine();
			//Call options:
			coder.packText(`opts={`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`"mode":`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`,`);coder.newLine();
				coder.packText(`"maxToken":`);this.genAttrStatement(seg.getAttr("maxToken"));coder.packText(`,`);coder.newLine();
				coder.packText(`"temperature":`);this.genAttrStatement(seg.getAttr("temperature"));coder.packText(`,`);coder.newLine();
				coder.packText(`"topP":${seg.getAttrVal("topP")},`);coder.newLine();
				coder.packText(`"fqcP":${seg.getAttrVal("fqcP")},`);coder.newLine();
				coder.packText(`"prcP":${seg.getAttrVal("prcP")},`);coder.newLine();
				coder.packText(`"secret":`);this.genAttrStatement(seg.getAttr("secret"));coder.packText(`,`);coder.newLine();
			}
			coder.eatPreComa();
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`}`);
			coder.newLine();

			coder.packText(`seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(seed!=None):opts["seed"]=seed`);coder.newLine();

			coder.packText(`messages=[];`);
			coder.maybeNewLine();
			packExtraCodes(coder,seg,"PrePrompt");
			coder.packText(`prompt=`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`;`);coder.newLine();
			coder.packText(`if(prompt!=None):`);
			coder.indentMore();
			coder.newLine();
			if(imageAttr && imageAttr.valText){
				coder.packText(`messages.append({"role":"user","content":[{"type":"text","text":prompt},{"type":"image_url","image_url":{"url":imageURL}}]});`);coder.newLine();
			}
			coder.indentLess();
			coder.newLine();
			packExtraCodes(coder,seg,"PreCall");
			if(hasCode){
				coder.packText(`if(result==None):result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)`);
			}else{
				coder.packText(`result=await session.callSegLLM("${segName}@"+agentURL,opts,messages,true)`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PostCall");
			//Result:
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docPyAgentExporter.export_aiBot=function(seg){
		let resultAttr=seg.getAttr("result");
		let sourcePathTxt=seg.getAttr("source").valText;
		let isCodeSource=sourcePathTxt[0]==="#";
		let sourcePath=seg.getAttrVal("source")||"";
		let agentNodeValTxt=seg.getAttrValText("agentNode");
		let agentNodeVal=seg.getAttrVal("agentNode");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let secret=seg.getAttrVal("secret");
		let outlets=seg.outletsList;
		let asklet=outlets[0];
		let askSegName="null";
		if(asklet){
			let nextSeg=asklet.getLinkedSeg();
			if(nextSeg){
				askSegName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
				askSegName=(askSegName &&varNameRegex.test(askSegName))?askSegName:("SEG"+nextSeg.jaxId);
			}
		}
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		if(sourcePath){
			if(sourcePath[0]==="/" && sourcePath[1]!=="@" && sourcePath[1]!=="~"){
				sourcePath=pathLib.relative(docPath,sourcePath);
				if(sourcePath[0]!=="."&&sourcePath[0]!=="/"){
					sourcePath="./"+sourcePath;
				}
			}
		}

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`nonlocal segs`);coder.newLine();
			coder.packText(`result=None`);coder.newLine();
			coder.packText(`sourcePath=pathLib.join(basePath,"${sourcePath}")`);coder.newLine();
			coder.packText(`arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.newLine();
			coder.packText(`agentNode=(`);this.genAttrStatement(seg.getAttr("agentNode"));coder.packText(`) or None`);coder.newLine();
			if(agentNodeValTxt&&(agentNodeValTxt[0]==="#" || agentNodeVal)){
				coder.packText(`sourcePath=`);this.genAttrStatement(seg.getAttr("source"));coder.newLine();
			}else{
				if(isCodeSource){
					coder.packText(`sourcePath=(`);this.genAttrStatement(seg.getAttr("source"));coder.packText(`) or ""`);coder.newLine();
					coder.packText(`sourcePath=sourcePath[0]==="/"?sourcePath:pathLib.join(basePath,"../"+sourcePath)`);
				}else{
					coder.packText(sourcePath[0]==="/"?`let sourcePath="${sourcePath}"`:`sourcePath=pathLib.join(basePath,"${sourcePath}")`);coder.newLine();
				}
			}
			coder.packText(`opts={"secrect":${secret},"fromAgent":_agent,"askUpwardSeg":segs.get("${askSegName}",None)}`);coder.newLine();
			packExtraCodes(coder,seg,"Input");
			coder.packText(`result= await session.callAgent(agentNode,sourcePath,arg,opts)`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret})`);coder.newLine();
			if(resultAttr){
				coder.packText(`result=`);
				this.genAttrStatement(resultAttr);
				coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"Ouput");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docPyAgentExporter.export_MCP=function(seg){
		let resultAttr=seg.getAttr("result");
		let toolTxt=seg.getAttr("tool").valText;
		let isCodeSource=toolTxt[0]==="#";
		let toolPath=seg.getAttrVal("tool")||"";
		let serverValTxt=seg.getAttrValText("server");
		let serverAttr=seg.getAttr("server");
		let serverVal=seg.getAttrVal("server");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let askSegName="null";
		let params = {tool_name:toolPath, tool_args:seg.getAttr("argument")};
		if(!serverVal.endsWith("/")) serverVal = serverVal + "/";
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`nonlocal segs`);coder.newLine();
			coder.packText(`result=None`);coder.newLine();
			coder.packText(`tool=pathLib.join(basePath,"${toolPath}")`);coder.newLine();
			coder.packText(`arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.newLine();
			coder.packText(`server=(`);this.genAttrStatement(serverAttr);coder.packText(`) or None`);coder.newLine();
			packExtraCodes(coder,seg,"Input");
			coder.packText(`import requests`);coder.newLine();
			coder.packText(`result=requests.post("${serverVal + "execute"}", json={"tool_name":"${toolPath.slice(1)}", "tool_args":arg}).json()`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret})`);coder.newLine();
			if(resultAttr){
				coder.packText(`result=`);
				this.genAttrStatement(resultAttr);
				coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"Ouput");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	docPyAgentExporter.export_AutoAPI=function(seg){
		let resultAttr=seg.getAttr("result");
		let toolTxt=seg.getAttr("tool").valText;
		let isCodeSource=toolTxt[0]==="#";
		let toolPath=seg.getAttrVal("tool")||"";
		let serverValTxt=seg.getAttrValText("server");
		let serverAttr=seg.getAttr("server");
		let serverVal=seg.getAttrVal("server");
		let docPath=pathLib.dirname(seg.doc.path);
		let coder=this.coder;
		let rawName=seg.idVal.val;
		let segName=rawName;
		let askSegName="null";
		if(!serverVal.endsWith("/")) serverVal = serverVal + "/";
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`nonlocal segs`);coder.newLine();
			coder.packText(`result=None`);coder.newLine();
			coder.packText(`tool="${toolPath}"`);coder.newLine();
			coder.packText(`arg=`);this.genAttrStatement(seg.getAttr("argument"));coder.newLine();
			coder.packText(`server=(`);this.genAttrStatement(serverAttr);coder.packText(`) or None`);coder.newLine();
			packExtraCodes(coder,seg,"Input");
			coder.packText(`import requests`);coder.newLine();
			coder.packText(`result=requests.post("${serverVal + "dynamic"}" + tool, json=arg).json()`);coder.newLine();
			//coder.packText(`result= await session.pipeChat(sourcePath,arg,${secret})`);coder.newLine();
			if(resultAttr){
				coder.packText(`result=`);
				this.genAttrStatement(resultAttr);
				coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"Ouput");
			//Result:
			packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	

	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_brunch=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlets=seg.outletsList;
		let outlet,condition;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`result=input`);coder.newLine();
			packExtraCodes(coder,seg,"Start");
			for(outlet of outlets){
				condition=outlet.getAttr("condition");
				if(condition){
					condition=condition.valText;
				}
				if(condition){
					if(condition[0]==="#"){
						let pos;
						pos=condition.lastIndexOf("#>");
						if(pos>0){
							condition=condition.substring(pos+2);
						}else{
							condition=condition.substring(1);
						}
					}
					coder.packText(`if ${condition}:`);
				}else{
					coder.packText(`if input=="${outlet.idVal.val}":`);
				}
				coder.indentMore();
				coder.newLine();
				{
					if(outlet.getAttrValText("output")){
						coder.packText(`output=`);this.genAttrStatement(outlet.getAttr("output")||outlet.getAttr("output"));coder.newLine();
						packExtraCodes(coder,outlet);
						this.packUpdateContext(coder,outlet);
						this.packUpdateGlobal(coder,outlet);
						packResult(coder,seg,outlet,"output");
						coder.newLine();
					}else{
						packExtraCodes(coder,outlet);
						//TODO:Fix this:
						this.packUpdateContext(coder,outlet);
						this.packUpdateGlobal(coder,outlet);
						packResult(coder,seg,outlet,"input");
						coder.newLine();
					}
				}
				coder.indentLess();coder.maybeNewLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"Post");
			//Result:
			coder.packText(`#default/else:`);
			coder.newLine();
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_summary=function(seg){
		let format=seg.getAttr("format").val;
		let coder=this.coder;
		let segName=seg.idVal.val;
		let asyncMode=seg.getAttrVal("async");
		let outlets=seg.outletsList;
		let outlet,isSurvey,hasCode,nextSeg,count;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`sumVO={}`);coder.newLine();
			if(asyncMode){
				coder.packText(`pmsList=[]`);coder.newLine();
			}
			coder.packText(`result=None`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			count=0;
			for(outlet of outlets){
				isSurvey=!!outlet.getAttr("survey").val;
				hasCode=outlet.getAttrVal("codes");
				nextSeg=outlet.getLinkedSeg();
				count++;
				if(nextSeg){
					if(asyncMode){
						coder.packText(`def task${count}():`);
						coder.indentMore();
						coder.newLine();
						{
							if(isSurvey){
								coder.packText(`sumVO["${outlet.idVal.val}"]=`);
							}
							packSegCall(coder,outlet,"input");
							if(hasCode){
								packExtraCodes(coder,outlet,"PostCodes");
							}
						}
						coder.indentLess();
						coder.maybeNewLine();
						coder.packText(`pmsList.append(task${count}())`);
						coder.newLine();
					}else{
						if(hasCode){
							packExtraCodes(coder,outlet,"PreCodes");
						}
						if(isSurvey){
							coder.packText(`sumVO["${outlet.idVal.val}"]=`);
						}
						packSegCall(coder,outlet,"input");
						if(hasCode){
							packExtraCodes(coder,outlet,"PostCodes");
						}
						coder.newLine();
					}
				}
			}
		}
		if(asyncMode){
			coder.packText(`await asyncio.gather(*pmsList)`);
			coder.newLine();
		}
		packExtraCodes(coder,seg,"PostCodes");
		if(format==="Text"){
			coder.packText(`result=""`);coder.newLine();
			coder.packText(`for(key value in sumVO.items()):`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result+=key+": "+value+"\n"`);
			}
			coder.indentLess();
			coder.maybeNewLine();
		}else{
			coder.packText(`result=json.dumps(sumVO,indent="\\t")`);coder.newLine();
		}
		this.packUpdateContext(coder,seg);
		this.packUpdateGlobal(coder,seg);
		packExtraCodes(coder,seg);
		packResult(coder,seg,seg.outlet,"result");
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	//Pyton: done
	docPyAgentExporter.export_loopArray=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let method=seg.getAttrVal("method");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			switch(method){
				default:{
					coder.packText(`result=input`);coder.newLine();
					break;
				}
				case "asyncForEach":{
					coder.packText(`result=None`);coder.newLine();
					coder.packText(`tasks=[]`);coder.newLine();
					break;
				}
				case "findIndex":
				case "find":{
					coder.packText(`result=None`);coder.newLine();
					break;
				}
				case "allOf":{
					coder.packText(`result=true`);coder.newLine();
					break;
				}
				case "anyOf":{
					coder.packText(`result=false`);coder.newLine();
					break;
				}
				case "anyOf":{
					coder.packText(`result=false`);coder.newLine();
					break;
				}
				case "map":
				case "filter":{
					coder.packText(`result=[]`);coder.newLine();
					break;
				}
			}
			coder.packText(`list=`);this.genAttrStatement(seg.getAttr("loopArray"));coder.packText(``);coder.newLine();
			coder.packText(`i,n,item,loopR=None,None,None,None`);coder.newLine();
			packExtraCodes(coder,seg,"PreLoop");
			coder.packText(`n=len(list)`);coder.newLine();
			coder.packText(`for i in range(n):`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`item=list[i]`);coder.newLine();
				packExtraCodes(coder,seg,"InLoopPre");
				switch(method){
					case "forEach":{
						coder.packText(`loopR=`);
						packSegCall(coder,seg.outlet,"item");coder.newLine();
						coder.packText(`if loopR=="break":`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`break`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						break;
					}
					case "asyncForEach":{
						coder.packText("tasks.push(");packSegCall(coder,seg.outlet,"item",true);coder.packText(")");coder.newLine();
						coder.indentLess();coder.maybeNewLine();
						break;
					}
					case "find":{
						coder.packText(`if(`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`):`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=item`);coder.newLine();
							coder.packText(`break`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						break;
					}
					case "findIndex":{
						coder.packText(`if(`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`):`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=i`);coder.newLine();
							coder.packText(`break`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						break;
					}
					case "allOf":{
						coder.packText(`if(not (`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`)):`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=false`);coder.newLine();
							coder.packText(`break`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						break;
					}
					case "anyOf":{
						coder.packText(`if(not (`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`)):`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result=true`);coder.newLine();
							coder.packText(`break`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						break;
					}
					case "map":{
						coder.packText(`result.append(`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`)`);coder.newLine();
						break;
					}
					case "filter":{
						coder.packText(`if(`);
						packSegCall(coder,seg.outlet,"item");
						coder.packText(`):`);
						coder.indentMore();
						coder.newLine();
						{
							coder.packText(`result.append(item);`);
						}
						coder.indentLess();
						coder.maybeNewLine();
						break;
					}
				}
				packExtraCodes(coder,seg,"InLoopPost");
			}
			coder.indentLess();
			coder.maybeNewLine();
			switch(method){
				case "asyncForEach":{
					coder.packText(`result=await asyncio.gather(*tasks)`);coder.newLine();
					break;
				}
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.catchlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_output=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let roleAttr=seg.getAttr("role");
		let contentAttr=seg.getAttr("text");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`result=input`);coder.newLine();
			coder.packText(`channel=`);this.genAttrStatement(seg.getAttr("channel"));coder.packText(``);coder.newLine();
			coder.packText(`opts={"txtHeader":_agent.get("name",_agent.get("showName",None)),"channel":channel}`);coder.newLine();
			coder.packText(`role=`);this.genAttrStatement(roleAttr);coder.packText(``);coder.newLine();
			coder.packText(`content=`);this.genAttrStatement(contentAttr);coder.packText(``);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`await session.addChatText(role,content,opts)`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: Done
	docPyAgentExporter.export_image=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let roleAttr=seg.getAttr("role");
		let textAttr=seg.getAttr("text");
		let imageAttr=seg.getAttr("image");
		let limitAttr=seg.getAttr("sizeLimit");
		let formatTag=seg.getAttrVal("format");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`result=input`);coder.newLine();
			coder.packText(`role=`);this.genAttrStatement(roleAttr);coder.packText(``);coder.newLine();
			coder.packText(`content=`);this.genAttrStatement(textAttr);coder.packText(``);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(!limitAttr.valText || limitAttr.valText==="0"){
				coder.packText(`await session.addChatText(role,content,{"image":`);this.genAttrStatement(imageAttr);coder.packText(`})`);coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			if(limitAttr.valText && limitAttr.valText!=="0"){
				coder.packText(`result=await session.resizeImage(result,${limitAttr.val},"${formatTag==="image/jpeg"?"JPEG":"PNG"}")`);coder.newLine();
				coder.packText(`await session.addChatText(role,content,{"image":result})`);coder.newLine();
			}
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_askChat=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`tip=`);this.genAttrStatement(seg.getAttr("tip"));coder.newLine();
			coder.packText(`tipRole=`);this.genAttrStatement(seg.getAttr("tipRole"));coder.newLine();
			coder.packText(`prompt=`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(``);coder.newLine();
			coder.packText(`placeholder=`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(``);coder.newLine();
			coder.packText(`allowFile=(`);this.genAttrStatement(seg.getAttr("file"));coder.packText(`) or False`);coder.newLine();
			coder.packText(`askUpward=(`);this.genAttrStatement(seg.getAttr("askUpward"));coder.packText(`) or False`);coder.newLine();
			coder.packText(`text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(``);coder.newLine();
			coder.packText(`result=""`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`if askUpward and tip:`);coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await session.askUpward(_agent,tip)`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`else:`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if tip:`);coder.indentMore();coder.newLine();
				{
					coder.packText(`await session.addChatText(tipRole,tip,{})`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`result=await session.askChatInput({"type":"input","prompt":prompt,"placeholder":placeholder,"text":text,"allowFile":allowFile})`);coder.newLine();
				if(seg.getAttrVal("showText")){
					coder.packText(`if isinstance(result, str):`);coder.indentMore();coder.newLine();
					{
						coder.packText(`await session.addChatText("user",result,{})`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();coder.packText(`elif result.get("assets",None) and result.get("prompt",None):`);coder.indentMore();coder.newLine();
					{
						coder.packText(`assets_text = "- - -\\n".join(map(str, result.get('assets', [])))`);coder.newLine();
						coder.packText(`await session.addChatText("user",f"{result.get('prompt')}\\n- - -\\n{assets_text}",{"render":True})`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();coder.packText(`else:`);coder.indentMore();coder.newLine();
					{
						coder.packText(`await session.addChatText("user",getattr(result,"text",None) or getattr(result,"prompt", None) or result)`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docPyAgentExporter.export_askText=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let inputType=(`);this.genAttrStatement(seg.getAttr("inputType"));coder.packText(`)||"text";`);coder.newLine();
			coder.packText(`let prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`)||input;`);coder.newLine();
			coder.packText(`let placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`);`);coder.newLine();
			coder.packText(`let text=(`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`);`);coder.newLine();
			coder.packText(`let resultText="";`);coder.newLine();
			coder.packText(`let result="";`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`[resultText,result]=await session.askUserRaw({type:"input",inputType:inputType,prompt:prompt,placeholder:placeholder,text:text});`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_askConfirm=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let withChat=seg.getAttrVal("withChat");
		let outlets=seg.outletsList;
		let outlet,resultVal;
		let silentOutlet=seg.getAttrVal("silentOutlet");
		FindOutlet:{
			let i,n;
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				if(outlet && outlet.getAttrVal("id")==silentOutlet){
					silentOutlet=outlet;
					break FindOutlet;
				}
			}
			silentOutlet=outlets[0];
		}
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`) or input`);coder.newLine();
			if(silentOutlet){
				coder.packText(`silent=`);this.genAttrStatement(seg.getAttr("silent"));coder.packText(``);coder.newLine();
			}
			coder.packText(`placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`) or ""`);coder.newLine();
			outlet=outlets[0];
			if(outlet){
				coder.packText(`button1=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`) or "OK"`);coder.newLine();
			}else{
				coder.packText(`button1="OK"`);coder.newLine();
			}
			outlet=outlets[1];
			if(outlet){
				coder.packText(`button2=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`) or "Cancel"`);coder.newLine();
			}else{
				coder.packText(`button2="Cancel"`);coder.newLine();
			}
			outlet=outlets[2];
			if(outlet){
				coder.packText(`button3=(`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`) or ""`);coder.newLine();
			}else{
				coder.packText(`button3=""`);coder.newLine();
			}
			coder.packText(`result="";`);coder.newLine();
			coder.packText(`value=0;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(silentOutlet){
				outlet=silentOutlet;
				coder.packText(`if silent:`);coder.indentMore();coder.newLine();
				{
					coder.packText(`result=`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(``);coder.newLine();
					packExtraCodes(coder,outlet,"Silent");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();
			}
			coder.packText(`result,value=await session.askUserRaw({"type":"confirm","prompt":prompt,"button1":button1,"button2":button2,"button3":button3,"withChat":${withChat},"placeholder":placeholder})`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			
			outlet=outlets[0];
			if(outlet){
				coder.packText(`if(value==1):`);
				coder.indentMore();coder.newLine();
				coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`) or result`);coder.newLine();
				packResult(coder,seg,outlet,"result");coder.newLine();
				coder.indentLess();coder.maybeNewLine();
			}
			
			outlet=outlets[2];
			if(outlet){
				coder.packText(`if(value==2):`);
				coder.indentMore();coder.newLine();
				coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`) or result`);coder.newLine();
				packResult(coder,seg,outlet,"result");coder.newLine();
				coder.indentLess();coder.maybeNewLine();
			}
			
			outlet=outlets[1];
			if(outlet){
				coder.packText(`result=(`);this.genAttrStatement(outlet.getAttr("result"));coder.packText(`) or result`);coder.newLine();
				packResult(coder,seg,outlet,"result");
				coder.newLine();
			}
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_askMenu=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let outlets=seg.outletsList;
		let multiAttr=seg.getAttr("multi");
		let withChat=seg.getAttrVal("withChat");
		let outlet,i,n,nextSeg;

		let silentOutlet=seg.getAttrVal("silentOutlet");
		FindOutlet:{
			n=outlets.length;
			for(i=0;i<n;i++){
				outlet=outlets[i];
				if(outlet && outlet.getAttrVal("id")==silentOutlet){
					silentOutlet=outlet;
					break FindOutlet;
				}
			}
			silentOutlet=outlets[0];
		}
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`) or input`);coder.newLine();
			coder.packText(`countdown=(`);this.genAttrStatement(seg.getAttr("countdown"));coder.packText(`) or 0`);coder.newLine();
			coder.packText(`placeholder=(`);this.genAttrStatement(seg.getAttr("placeholder"));coder.packText(`) or ""`);coder.newLine();
			if(silentOutlet){
				coder.packText(`silent=(`);this.genAttrStatement(seg.getAttr("silent"));coder.packText(`) or False;`);coder.newLine();
			}
			coder.packText(`items=[`);coder.newLine();
			coder.indentMore();
			{
				let iconAttr,emojiAttr;
				n=outlets.length;
				for(i=0;i<n;i++){
					outlet=outlets[i];
					coder.maybeNewLine();
					emojiAttr=outlet.getAttr("emoji");
					iconAttr=outlet.getAttr("icon");
					if(emojiAttr && emojiAttr.val){
						coder.packText(`{"emoji":`);this.genAttrStatement(emojiAttr);coder.packText(` or "/~/-tabos/shared/assets/hudbox.svg","text":`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,"code":${i}},`);
					}else if(iconAttr){
						coder.packText(`{"icon":`);this.genAttrStatement(iconAttr);coder.packText(`or "/~/-tabos/shared/assets/hudbox.svg","text":`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,"code":${i}},`);
					}else{
						coder.packText(`{"icon":"/~/-tabos/shared/assets/hudbox.svg","text":`);this.genAttrStatement(outlet.getAttr("text"));coder.packText(`,"code":${i}},`);
					}
				}
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`]`);
			coder.newLine();
			
			if(silentOutlet){
				outlet=silentOutlet;
				coder.packText(`if silent:`);coder.indentMore();coder.newLine();
				{
					coder.packText(`result=`);this.genAttrStatement(outlet.getAttr("result"));coder.newLine();
					packExtraCodes(coder,outlet,"Silent");
					this.packUpdateContext(coder,outlet);
					this.packUpdateGlobal(coder,outlet);
					packResult(coder,seg,outlet,"result");
				}
				coder.indentLess();coder.maybeNewLine();
			}

			coder.packText(`result=""`);coder.newLine();
			coder.packText(`item=None`);coder.newLine();
			coder.packText(`multi=`);this.genAttrStatement(multiAttr);coder.packText(``);coder.newLine();
			coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result,item=await session.askUserRaw({"type":"menu","prompt":prompt,"multiSelect":multi,"items":items,"withChat":${withChat?"True":"False"},"placeholder":placeholder,"countdown":countdown})`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			if(n>0){
				coder.packText(`if(multi):`);
				coder.indentMore();
				coder.newLine();
				{
					FindSeg:{
						for(i=0;i<n;i++){
							outlet=outlets[i];
							nextSeg=outlet.getLinkedSeg();
							if(nextSeg){
								packResult(coder,seg,outlet,"result");
								break FindSeg;
							}
						}
						coder.packText(`pass`);
					}
				}
				coder.indentLess();
				coder.newLine();

				coder.newLine();
				for(i=0;i<n;i++){
					outlet=outlets[i];
					coder.maybeNewLine();
					coder.packText(`if(item["code"]==${i}):`);
					coder.indentMore();coder.newLine();
					{
						packExtraCodes(coder,outlet,"");
						packResult(coder,seg,outlets[i],"result");
					}
					coder.indentLess();
					coder.newLine();
				}
			}
			coder.maybeNewLine();
			outlet=seg.getAttr("outlet");
			packExtraCodes(coder,seg,"FinCodes");
			packResult(coder,seg,outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_askAudio=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`) or input`);coder.newLine();
			coder.packText(`result=""`);coder.newLine();
			coder.packText(`audioData=None`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result,audioData=await session.askUserRaw({"type":"audio","prompt":prompt})`);coder.newLine();
			coder.packText(`audioData=await session.readFile(audioData,"data")`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"audioData");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_aiDraw=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let modeAttr=seg.getAttr("mode");
		let promptAttr=seg.getAttr("prompt");
		let sizeAttr=seg.getAttr("size");
		let labelAttr=seg.getAttr("imgLabel");
		let method=seg.getAttrVal("method");
		let imageAttr=seg.getAttr("image");
		let maskAttr=seg.getAttr("mask");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`callVO=None`);coder.newLine();
			coder.packText(`result=input`);coder.newLine();
			coder.packText(`revisedPrompt=""`);coder.newLine();
			coder.packText(`rsp=None`);coder.newLine();
			coder.packText(`dataURL=None`);coder.newLine();
			coder.packText(`mode=`);this.genAttrStatement(modeAttr);coder.packText(``);coder.newLine();
			coder.packText(`prompt=`);this.genAttrStatement(promptAttr);coder.packText(``);coder.newLine();
			coder.packText(`size=`);this.genAttrStatement(sizeAttr);coder.packText(``);coder.newLine();
			coder.packText(`label=`);this.genAttrStatement(labelAttr);coder.packText(``);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`seed=`);this.genAttrStatement(seg.getAttr("seed"));coder.packText(``);coder.newLine();
			if(method==="Edit"||method==="Variation"){
				coder.packText(`imageURL=`);this.genAttrStatement(imageAttr);coder.newLine();
			}
			if(method==="Edit"){
				coder.packText(`maskURL=`);this.genAttrStatement(maskAttr);coder.newLine();
			}
			if(method==="Edit"){
				coder.packText(`callVO={"model":mode,"image":imageURL,"prompt":prompt,"size":size}`);coder.newLine();
				coder.packText(`if(maskURL){callVO["mask"]=maskURL;}`);coder.newLine();
				coder.packText(`if(seed):callVO["seed"]=seed`);coder.newLine();
				coder.packText(`rsp=await session.callAIDraw(callVO)`);coder.newLine();
			}else if(method==="Variation"){
				coder.packText(`callVO={"model":mode,"image":imageURL,"size":size}`);coder.newLine();
				coder.packText(`if(seed):callVO["seed"]=seed`);coder.newLine();
				coder.packText(`rsp=await session.callAIDraw(callVO)`);coder.newLine();
			}else{
				coder.packText(`callVO={"model":mode,"prompt":prompt,"size":size}`);coder.newLine();
				coder.packText(`if(seed):callVO["seed"]=seed`);coder.newLine();
				coder.packText(`rsp=await session.callAIDraw(callVO)`);coder.newLine();
			}
			
			//coder.packText(`console.log(rsp)`);coder.newLine();
			coder.packText(`if(rsp["code"]==200):`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result=rsp["img"]`);coder.newLine();
				coder.packText(`dataURL=f"data:image/jpeg;base64,{result}"`);coder.newLine();
				if(seg.getAttrVal("showImage")){
					coder.packText(`await session.addChatText("assistant",label,{"image":dataURL})`);coder.newLine();
				}
				coder.packText(`result=dataURL`);
			}
			coder.indentLess();
			coder.maybeNewLine();
			coder.packText(`else:`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`raise Exception("Error "+rsp["code"]+": "+(rsp["info"] or ""))`);
			}
			coder.indentLess();
			coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_askFile=
	docPyAgentExporter.export_askText=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let pathAttr=seg.getAttr("path");
		let filterAttr=seg.getAttr("filter");
		let inputTypeAttr=seg.getAttr("inputType");
		let placeholderAttr=seg.getAttr("placeholder");
		let textAttr=seg.getAttr("textAttr");
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			if(inputTypeAttr){
				coder.packText(`inputType=(`);this.genAttrStatement(inputTypeAttr);coder.packText(`) or "text"`);coder.newLine();
			}
			coder.packText(`prompt=(`);this.genAttrStatement(seg.getAttr("prompt"));coder.packText(`) or input`);coder.newLine();
			if(placeholderAttr){
				coder.packText(`placeholder=(`);this.genAttrStatement(placeholderAttr);coder.packText(`)`);coder.newLine();
			}
			if(textAttr){
				coder.packText(`text=(`);this.genAttrStatement(textAttr);coder.packText(`)`);coder.newLine();
			}
			coder.packText(`resultText=""`);coder.newLine();
			coder.packText(`fileData=None`);coder.newLine();
			coder.packText(`enc=None`);coder.newLine();
			coder.packText(`base=None`);coder.newLine();
			coder.packText(`ext=None`);coder.newLine();
			coder.packText(`fileSys="${seg.getAttr("fileSys").val}"`);coder.newLine();
			coder.packText(`result=""`);coder.newLine();
			if(pathAttr){
				coder.packText(`path=(`);this.genAttrStatement(pathAttr);coder.packText(`)`);coder.newLine();
				coder.packText(`filter=(`);this.genAttrStatement(filterAttr);coder.packText(`)`);coder.newLine();
			}
			packExtraCodes(coder,seg,"PreCodes");
			if(pathAttr){
				let readAttrVal=seg.getAttrVal("read");
				coder.packText(`resultText,result=await session.askUserRaw({"type":"input","prompt":prompt,"text":"","path":path,"file":fileSys,"filter":filter})`);coder.newLine();
				switch(readAttrVal){
					case "Text":
						coder.packText(`fileData=await session.readFile(result,"text")`);coder.newLine();
						coder.packText(`result=fileData`);coder.newLine();
						break;
					case "Data":
						coder.packText(`fileData=await session.readFile(result,"data")`);coder.newLine();
						coder.packText(`result=fileData`);coder.newLine();
						break;
					case "JSON":
						coder.packText(`fileData=await session.readFile(result,"text")`);coder.newLine();
						coder.packText(`result=json.load(fileData);`);coder.newLine();
						break;
					case "Base64":
						coder.packText(`fileData=await session.readFile(result,"data")`);coder.newLine();
						coder.packText(`result=base64.b64encode(fileData).decode()`);coder.newLine();
						break;
					case "DataURL":
						coder.packText(`base, ext = pathLib.splitext(resultText)`);coder.newLine();
						coder.packText(`fileData=await session.readFile(result,"data")`);coder.newLine();
						coder.packText(`result=base64.b64encode(fileData).decode()`);coder.newLine();
						{
							coder.packText(`if(ext==".jpg"):`);
							coder.indentMore();
							coder.newLine();
								coder.packText(`result="data:image/jpeg;base64,"+result`);coder.newLine();
							coder.indentLess();
							coder.newLine();
							coder.packText(`elif(ext==".png"):`);
							coder.indentMore();
							coder.newLine();
								coder.packText(`result="data:image/png;base64,"+result`);coder.newLine();
							coder.indentLess();
							coder.newLine();
							coder.packText(`elif(ext==".txt"):`);
							coder.indentMore();
							coder.newLine();
								coder.packText(`result="data:text/plain;base64,"+result`);coder.newLine();
							coder.indentLess();
							coder.newLine();
							coder.packText(`else:`);
							coder.indentMore();
							coder.newLine();
								coder.packText(`result="data:application/octet-stream;base64,"+result`);coder.newLine();
							coder.indentLess();
						}
						coder.newLine();
						break;
				}
			}else{
				coder.packText(`resultText,result=await session.askUserRaw({"type":"input","inputType":inputType,"prompt":prompt,"placeholder":placeholder,"text":text});`);coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	docPyAgentExporter.export_askEditObj=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`role=`);this.genAttrStatement(seg.getAttr("role"));coder.newLine();
			coder.packText(`text=`);this.genAttrStatement(seg.getAttr("text"));coder.newLine();
			coder.packText(`template=`);this.genAttrStatement(seg.getAttr("template"));coder.newLine();
			coder.packText(`data=`);this.genAttrStatement(seg.getAttr("data"));coder.newLine();
			coder.packText(`edit=`);this.genAttrStatement(seg.getAttr("editData"));coder.newLine();
			coder.packText(`resultText=""`);coder.newLine();
			coder.packText(`result=""`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			/*coder.packText(`if isinstance(template,str):`);coder.indentMore();coder.newLine();
			{
				coder.packText(`template=VFACT.getEditUITemplate(template) or VFACT.getUITemplate(template)`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();coder.newLine();*/
			coder.maybeNewLine();
			coder.packText(`inputVO={"template":template,"data":data,"options":{edit:edit}};`);coder.newLine();
			
			coder.packText(`[resultText,result]=await session.askUserRaw({"type":"object","text":text,"object":data,"template":template,"role":role,"edit":edit});`);coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_aiTTS=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let modeAttr=seg.getAttr("mode");
		let inputAttr=seg.getAttr("text");
		let voiceAttr=seg.getAttr("voice");
		let labelAttr=seg.getAttr("ttsLabel");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`callVO=None`);coder.newLine();
			coder.packText(`result=input`);coder.newLine();
			coder.packText(`rsp=None`);coder.newLine();
			coder.packText(`mode=`);this.genAttrStatement(modeAttr);coder.packText(``);coder.newLine();
			coder.packText(`text2Read=`);this.genAttrStatement(inputAttr);coder.packText(``);coder.newLine();
			coder.packText(`voice=`);this.genAttrStatement(voiceAttr);coder.packText(``);coder.newLine();
			coder.packText(`label=`);this.genAttrStatement(labelAttr);coder.packText(``);coder.newLine();
			coder.packText(`showBlock=`);this.genAttrStatement(seg.getAttr("showBlock"));coder.packText(``);coder.newLine();
			coder.packText(`autoPlay=`);this.genAttrStatement(seg.getAttr("autoPlay"));coder.packText(``);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`callVO={"model":mode,"input":text2Read,"voice":voice};`);coder.newLine();
			coder.packText(`rsp=await session.callAITTS(callVO);`);coder.newLine();
			coder.packText(`if(rsp["code"]==200):`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result=rsp["mp3"]`);coder.newLine();
				coder.packText(`if(autoPlay):`);
				coder.packText(`await session.addChatText("assistant",label,{"audio":result,"autoPlay":autoPlay});`);coder.newLine();
			}
			coder.indentLess();
			coder.packText(`else:`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`raise Exception("Error "+rsp.code+": "+(rsp["info"] if("info" in rsp) else ""))`);
			}
			coder.indentLess();
			coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_webCall=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let urlAttr=seg.getAttr("url");
		let methodAttr=seg.getAttr("method");
		let headerAttr=seg.getAttr("headers");
		let textAttr=seg.getAttr("text");
		let imageAttr=seg.getAttr("image");
		let argMode=seg.getAttrVal("argMode");
		let timeout=seg.getAttrVal("timeout");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`callVO=None`);coder.newLine();
			coder.packText(`result=input`);coder.newLine();
			coder.packText(`rsp=None`);coder.newLine();
			coder.packText(`url=`);this.genAttrStatement(urlAttr);coder.packText(``);coder.newLine();
			coder.packText(`method=`);this.genAttrStatement(methodAttr);coder.packText(``);coder.newLine();
			coder.packText(`headers=`);this.genAttrStatement(headerAttr);coder.packText(``);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			switch(argMode){
				case "URL":{
					let list,i,n,attr,key,value;
					coder.packText(`if(url.indexOf("&")<0&&url.indexOf("?")<0):`);coder.newLine();
					coder.indentMore();coder.newLine();
						coder.packText(`url+="?"`);
					coder.indentLess();coder.newLine();
					coder.packText(`else:`);
					coder.indentMore();coder.newLine();
						coder.packText(`url+="&"`);
					coder.indentLess();coder.newLine();
									
					coder.packText(`url+=`);
					list=seg.getAttr("args").attrList;
					n=list.length;
					for(i=0;i<n;i++){
						attr=list[i];
						key=attr.name;
						if(i!==0){
							coder.packText(`+"&"+`);
						}
						coder.packText(`urllib.parse.quote("${key}")+"="+urllib.parse.quote(`);this.genAttrStatement(attr);coder.packText(`)`);
					}
					coder.packText(``);coder.newLine();
					coder.packText(`callVO={"url":url,"method":method,"headers":headers}`);coder.newLine();
					break;
				}
				case "JSON":{
					coder.packText(`json=`);this.genAttrStatement(seg.getAttr("args"));coder.packText(``);coder.newLine();
					coder.packText(`callVO={"url":url,"method":method,"argMode":"JSON","headers":headers,"json":json}`);coder.newLine();
					break;
				}
				case "TEXT":{
					coder.packText(`text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(``);coder.newLine();
					coder.packText(`callVO={"url":url,"method":method,"argMode":"TEXT","headers":headers,"text":text}`);coder.newLine();
					break;
				}
			}
			packExtraCodes(coder,seg,"AboutCall");
			coder.packText(`rsp=await session.webCall(callVO,true,${timeout})`);coder.newLine();
			coder.packText(`if(rsp["code"]==200):`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`result=rsp["data"]`);
			}
			coder.indentLess();
			coder.newLine();
			coder.packText(`else:`);
			coder.indentMore();
			coder.newLine();
			{
				coder.packText(`raise Exception("Error "+rsp.get("code")+": "+(rsp.get("info") if("info" in rsp) else ""))`);
			}
			coder.indentLess();
			coder.newLine();
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_save=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let loc=seg.getAttrVal("location");
		let ctxAttr=seg.getAttr("saveContext");
		let fileAttr=seg.getAttr("fileName");
		let target=seg.getAttrVal("target");
		let attrList=ctxAttr.attrList;
		let i,n,attr,attrName;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		if(target==="Context"){
			coder.maybeNewLine();
			coder.packText(`saveVO={"context":{}}`);coder.newLine();
			coder.packText(`ctxVO=saveVO.context`);coder.newLine();
			coder.packText(`result=saveVO`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				attrName=attr.val;
				coder.packText(`ctxVO["${attrName}"]=context["${attrName}"] if("${attrName}" in context) else None`);coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"PostCodes");
			if(fileAttr.valText){
				coder.indentMore();coder.newLine();
				if(loc==="Hub"){
					coder.packText(`content=json.dumps(saveVO, indent="\t")`);coder.newLine();
					coder.packText(`fileName=pathLib.basename(`);this.genAttrStatement(fileAttr);coder.packText(`)`);coder.newLine();
					packExtraCodes(coder,seg,"SaveData");
					coder.packText(`await session.saveHubFile(fileName,content)`);coder.newLine();
				}else{
					coder.packText(`content=json.dumps(saveVO, indent="\t")`);coder.newLine();
					coder.packText(`fileName=`);this.genAttrStatement(fileAttr);coder.newLine();
					packExtraCodes(coder,seg,"SaveData");
					coder.packText(`await session.writeFile(fileName,content,"utf8")`);coder.newLine();
				}
				coder.indentLess();
				coder.maybeNewLine();
				coder.newLine();
			}				
			packExtraCodes(coder,seg,"FinCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}else{
			let saveFormat=seg.getAttrVal("format");
			let isText;
			coder.packText(`fileName=`);this.genAttrStatement(fileAttr);coder.packText(`;`);coder.newLine();
			coder.packText(`content=input`);coder.newLine();
			coder.packText(`result=content`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(loc==="Hub"){
				coder.packText(`fileName=pathLib.basename(fileName)`);coder.newLine();
				packExtraCodes(coder,seg,"SaveData");
				coder.packText(`result=await session.saveHubFile(fileName,content)`);coder.newLine();
			}else{
				switch(saveFormat){
					default:
					case "Data":
						break;
					case "JSON":
						coder.packText(`content=json.dumps(content, indent="\t")`);coder.newLine();
						break;
					case "CJSON":
						coder.packText(`content=json.dumps(content)`);coder.newLine();
						break;
					case "Text":
						coder.packText(`content=""+content`);coder.newLine();
						break;
					case "Base642Data":
						coder.packText(`content=base64.b64decode(content)`);coder.newLine();
						break;
					case "DataURL2Data":
						coder.packText(`content=content.split(",")[1]`);coder.newLine();
						coder.packText(`content=base64.b64decode(content)`);coder.newLine();
						break;
				}
				packExtraCodes(coder,seg,"SaveData");
				if(isText){
					coder.packText(`await session.writeFile(fileName,content,"text");`);coder.newLine();
				}else{
					coder.packText(`await session.writeFile(fileName,content,"data");`);coder.newLine();
				}
			}
			packExtraCodes(coder,seg,"FinCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};

	//------------------------------------------------------------------------
	//Python: done
	docPyAgentExporter.export_load=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let fileAttr=seg.getAttr("fileName");
		let readTarget=seg.getAttrVal("read");
		let i,n,attr,attrName;
		
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);

		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`content=None`);coder.newLine();
			coder.packText(`result=None`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			if(fileAttr.valText){
				{
					coder.packText(`fileName=`);this.genAttrStatement(fileAttr);coder.packText(``);coder.newLine();
					coder.packText(`try:`);
					coder.indentMore();
					coder.newLine();
					{
						switch(readTarget){
							case "Context":
							case "JSON":
								coder.packText(`content=await session.readFile(fileName,"text")`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content = json.loads(content)`);coder.newLine();
								break;
							case "Text":
								coder.packText(`content=await session.readFile(fileName,"text")`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								break;
							case "Data":
								coder.packText(`content=await session.readFile(fileName,"data")`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								break;
							case "Base64":
								coder.packText(`content=await session.readFile(fileName,"data")`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content=base64.b64encode(content).decode()`);coder.newLine();
								break;
							case "DataURL":
								coder.packText(`content=await session.readFile(fileName,"data")`);coder.newLine();
								packExtraCodes(coder,seg,"LoadData");
								coder.packText(`content=base64.b64encode(content).decode()`);coder.newLine();
								coder.packText(`base, ext = pathLib.splitext(fileName)`);coder.newLine();
								coder.packText(`if (ext==".jpg"):`);
								coder.indentMore();
								coder.newLine();
								coder.packText(`content="data:image/jpeg;base64,"+content`);coder.newLine();
								coder.indentLess();
								coder.newLine();
								coder.packText(`elif (ext==".png"):`);
								coder.indentMore();
								coder.newLine();
								coder.packText(`content="data:image/png;base64,"+content`);coder.newLine();
								coder.indentLess();
								coder.newLine();
								coder.packText(`elif (ext==".txt"):`);
								coder.indentMore();
								coder.newLine();
								coder.packText(`content="data:text/plain;base64,"+content`);coder.newLine();
								coder.indentLess();
								coder.newLine();
								coder.packText(`else:`);
								coder.indentMore();
								coder.newLine();
								coder.packText(`content="data:application/octet-stream;base64,"+content`);coder.newLine();
								coder.indentLess();
								coder.newLine();
								break;
						}
					}
					coder.indentLess();
					coder.maybeNewLine();
					coder.packText(`except Exception as e:`);
					coder.indentMore();
					coder.newLine();
					{
						coder.packText(`context=None`);coder.newLine();
					}
					coder.indentLess();
					coder.maybeNewLine();
				}
				coder.newLine();
			}				
			if(readTarget==="Context"){
				packExtraCodes(coder,seg,"PreMerge");
				coder.packText(`if(content and content.context):context.update(content.context)`);coder.newLine();
				packExtraCodes(coder,seg,"PostCodes");
				coder.packText(`result=content`);coder.newLine();
			}else{
				coder.packText(`result=content`);coder.newLine();
			}
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packExtraCodes(coder,seg,"FinCodes");
			//Result:
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
	//------------------------------------------------------------------------
	//Python: todo
	docPyAgentExporter.export_jumper=function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let editDoc=seg.doc;
		let resultVal=seg.getAttr("result");
		let docArgs=editDoc.getAttr("apiArgs").attrList;
		let jumpTarget=seg.getAttrVal("seg");
		let argAttr,argName;
		let outlet=seg.outlet;
		let nextSeg,outletId;

		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		
		coder.packText(`async def ${segName}_exec(input):#//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`result=input`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			
			if(outlet){
				outletId=outlet.jaxId;
				nextSeg=outlet.getLinkedSeg();
			}
			coder.maybeNewLine();
			if(nextSeg){
				coder.packText(`result=(await ${jumpTarget}(input)).get("result")`);
				coder.maybeNewLine();
				packExtraCodes(coder,seg,"PostCodes");
				coder.maybeNewLine();
				segName=nextSeg.idVal.val||(("SEG")+nextSeg.jaxId);
				segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+nextSeg.jaxId);
				if(exportDebug){
					coder.packText(`return {"seg":${segName},"result":result,"preSeg":"${seg.jaxId}","outlet":"${outletId}"}`);
				}else{
					coder.packText(`return {"seg":${segName},"result":result}`);
				}
			}else{
				if(exportDebug){
					coder.packText(`return {"seg":${jumpTarget},"result":result,"preSeg":"${seg.jaxId}","outlet":"${outletId}"}`);
				}else{
					coder.packText(`return {"seg":${jumpTarget},"result":result}`);
				}
			}
			coder.maybeNewLine();
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`segs["${segName}"]=${segName}={`);
		coder.indentMore();
		coder.newLine();
		{
			coder.packText(`"exec":${segName}_exec,`);coder.newLine();
			if(exportDebug){
				coder.packText(`"name":"${segName}",`);coder.newLine();
				coder.packText(`"jaxId":"${seg.jaxId}",`);coder.newLine();
			}
			coder.packText(`"url":"${segName}@"+agentURL`);coder.newLine();
		}
		coder.indentLess();
		coder.maybeNewLine();
		coder.packText(`}`);
		coder.newLine();
		coder.newLine();
	};
	
}
