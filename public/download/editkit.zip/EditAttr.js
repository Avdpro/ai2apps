import {makeObjEventEmitter,makeNotify} from "/@events";
import inherits from "/@inherits";
import pathLib from "/@path";
import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;
//****************************************************************************
//:EditAttr
//****************************************************************************
let EditAttr,editAttr
{
	//------------------------------------------------------------------------
	EditAttr=function(owner,def,init=true){
		this.owner=owner;
		this.name=def.name;
		this.def=def;
		this.val=undefined;
		this.valText="";
		this.arrayVal=0;
		this.comment=null;
		this.hyper=false;
		this.trace=false;
		this.localize=false;
		//this.editMode; Edit-UI mode in edtior
		if(init){
			let valText;
			if("initValText" in def){
				valText=this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
					if(valText[0]==="#"||valText.startsWith("${")){
						this.hyper=true;
					}
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else if("initVal" in def){
				this.val=def.initVal;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	editAttr=EditAttr.prototype={};
	
	//************************************************************************
	//:Attr type related:
	//************************************************************************
	let typeRegs={};
	{
		//--------------------------------------------------------------------
		EditAttr.regType=EditAttr.regAttrType=function(name,typeFunc){
			typeRegs[name]=typeFunc;
		};

		//--------------------------------------------------------------------
		EditAttr.getType=EditAttr.getAttrType=function(name){
			let typeFunc=typeRegs[name];
			if(!typeFunc){
				console.error(`Can't find attr type: ${name}`);
			}
			return typeFunc;
		};

		//--------------------------------------------------------------------
		EditAttr.getTypes=EditAttr.getAttrTypes=function(){
			return {...typeRegs};
		};
	}
	
	//************************************************************************
	//:Attr class related:
	//************************************************************************
	let classRegs={};
	{
		//--------------------------------------------------------------------
		EditAttr.regClass=EditAttr.regClassType=function(name,editClass){
			classRegs[name]=editClass;
		};

		//--------------------------------------------------------------------
		EditAttr.getClass=EditAttr.getClassType=function(name){
			return classRegs[name];
		};

		//--------------------------------------------------------------------
		EditAttr.getClasses=EditAttr.getClassTypes=function(){
			return {...classRegs};
		};

		//--------------------------------------------------------------------
		EditAttr.getClassList=EditAttr.getClassTypeList=function(){
			return Object.values(classRegs);
		};
	}
	
	//------------------------------------------------------------------------
	//New attr by owner and def
	EditAttr.newAttr=function(owner,def,init){
		let type=def.type;
		let attrFunc=typeRegs[type]||EditAttr;
		if(attrFunc.getDef && def.def){
			let objDef;
			objDef=def.def;
			if(typeof(objDef)==="string"){
				objDef=attrFunc.getDef(objDef);
				if(!objDef){
					console.error(`Can't find obj-def "${def.def}" of attr type "${type}"`);
					return null;
				}
			}
			if(objDef){
				attrFunc=objDef.constructFunc||attrFunc;
			}
		}
		if(!attrFunc){
			return null;
		}
		return new attrFunc(owner,def,init);
	};
	
	//------------------------------------------------------------------------
	//Create and load an attr from voAttr, add the attr to owner with name
	EditAttr.loadFromVO=function(owner,attrVO,name,attrsVO){
		let ownerType,ownerObjDef,def,attr;
		ownerType=owner.def.type;
		if(ownerType==="array"){
			def={name:name,extraAttr:true};
			def.type=attrVO.type||"auto";
			def.def=attrVO.def;
			attr=EditAttr.newAttr(owner,def,false);
		}else{
			ownerObjDef=owner.objDef;
			def=owner.getAttrDef(name);
			if(def && (def!==ownerObjDef.attrs[name])){
				def={fixed:0,...def,extraAttr:true,key:0}
			}
			if(!def){
				def={name:name,type:attrVO.type,extraAttr:true};
				def.def=attrVO.def;
				if(attrVO.editMode){
					def.editMode=attrVO.editMode;
				}
				if(attrVO.editType){
					def.editType=attrVO.editType;
				}
			}
			if(def.type==="converter"){
				def.convert(owner,attrVO,attrsVO);
				return null;
			}
			attr=EditAttr.newAttr(owner,def,false);
		}
		if(attr){
			attr.loadFromVO(attrVO);
		}
		return attr;
	};
	
	//------------------------------------------------------------------------
	EditAttr.getObjDef=function(attrType,defName){
		let attrFunc=typeRegs[attrType]||EditAttr;
		if(attrFunc.getDef && defName){
			let objDef;
			objDef=defName;
			if(typeof(objDef)==="string"){
				objDef=attrFunc.getDef(objDef);
				if(!objDef){
					console.error(`Can't find obj-def "${def.def}" of attr type "${type}"`);
					return null;
				}
				return objDef;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	//Set val by text, this function shold only be called by owner
	editAttr.setValByText=function(text){
		let hyperCode,oldVal,pos,oldText;
		if(this.checkChange && (this.checkChange(text)===false)){
			return;
		}
		oldVal=this.val;
		oldText=this.valText;
		this.valText=text;
		try{
			if(text.startsWith("#")){
				this.hyper=true;
				this.trace=false;
				pos=text.indexOf("#>",1);
				if(pos>0){
					hyperCode=text.substring(1,pos);
				}else{
					hyperCode=text.substring(1);
				}
				this.val=this.owner.execHyperAttr(hyperCode);
			}else if(text.startsWith("${")){
				let pos=text.lastIndexOf("}");
				if(pos<0){
					throw new Error(`Hyper code incomplete: ${text}`);
				}
				hyperCode=text.substring(2,pos);
				this.hyper=true;
				this.trace=(text[pos+1]===",");
				this.val=this.owner.execHyperAttr(hyperCode);
			}else{
				this.hyper=false;
				this.trace=false;
				this.val=this.text2Val(text);
			}
		}catch(err){
			if(this.owner && this.owner.doc){
				console.log(`In ${this.owner.doc.getAttr("path").val}`);
			}
			console.warn(`EditAttr.setAttrByText ${err}: >>> ${text} <<<$`);
			EditAttr.lastSetValError=err;
			return false;
		}
		if(oldText!==text || oldVal!==this.val){
			this.emitChanged();
		}
		return true;
	};
	
	//------------------------------------------------------------------------
	//Convert text to val:
	editAttr.text2Val=function(text){
		if(text===""){
			return undefined;
		}
		try{
			return JSON.parse(text);
		}catch(err){
			return text;//Deal like a string?
		}
	};
	
	//------------------------------------------------------------------------
	//Convert val to text:
	editAttr.val2Text=function(val){
		if(val===undefined){
			return "";
		}
		return JSON.stringify(val);
	};

	//------------------------------------------------------------------------
	//Convert val to text:
	editAttr.val2ShowText=function(val){
		let text,pos;
		let def=this.def;
		if(def.val2ShowText){
			return def.val2ShowText.call(this,val);
		}
		if(val===undefined){
			return "";
		}
		text=JSON.stringify(val);
		return text;
	};

	//------------------------------------------------------------------------
	editAttr._genSaveVO=function(){
		let def=this.def;
		let attrVO;
		attrVO={};
		attrVO.type=def.type;
		attrVO.valText=this.valText;
		if(this.localize){
			attrVO.localize={...this.localize};
		}
		if(def.extraAttr){
			if(def.editMode){
				attrVO.editMode=def.editMode;
			}
			if(def.editType){
				attrVO.editType=def.editType;
			}
		}
		if(this.comment){
			attrVO.comment=this.comment;
		}
		if(def.localizable){
			attrVO.localizable=true;
		}
		return attrVO;
	};
	
	//------------------------------------------------------------------------
	editAttr.genSaveVO=function(){
		let def=this.def;
		if(def.extraAttr || this.comment || this.localize){
			return this._genSaveVO();
		}
		return this.valText;
	};
	
	//------------------------------------------------------------------------
	editAttr.loadFromVO=function(voAttr){
		if(typeof(voAttr)==="string"){
			this.setValByText(voAttr);
		}else{
			if(voAttr.localizable){
				this.def.localizable=true;
			}
			if(voAttr.localize){
				this.localize={...voAttr.localize};
			}
			if("comment" in voAttr){
				this.comment=voAttr.comment;
			}
			if("editMode" in voAttr){
				this.editMode=voAttr.editMode;
			}
			this.setValByText(voAttr.valText);
		}
	};

	//------------------------------------------------------------------------
	//Emit a attr-change notify
	editAttr.emitChanged=editAttr.emitAttrChange=function(){
		this.emit && this.emit("Changed");
		this.emitNotify && this.emitNotify("Changed");
		if(this.watchTree){
			this.owner.emitChanged();
		}
	};
	
	//------------------------------------------------------------------------
	editAttr.onChange=function(callback){
		if(!this.emit){
			makeObjEventEmitter(this);
		}
		this.on("Changed",callback);
	}
	
	//------------------------------------------------------------------------
	editAttr.offChange=function(callback){
		this.off("Changed",callback);
	}
	
	//------------------------------------------------------------------------
	editAttr.traceOn=function(callback){
		if(!this.emitNotify){
			makeNotify(this);
		}
		this.onNotify("Changed",callback);
	};
	
	//------------------------------------------------------------------------
	editAttr.traceOff=function(callback){
		this.offNotify("Changed",callback);
	};

	//------------------------------------------------------------------------
	editAttr.cloneAttrToObj=function(tgtObj,defOpts,opts){
		let def,valText,attr;
		if(tgtObj.getAttr(this.name)){
			return null;
		}
		def={...this.def,...defOpts};
		attr=tgtObj.addAttr(def);
		if(!tgtObj.setValByText(this.valText)){
			valText=this.val2Text(this.val);
			tgtObj.setValByText(this.valText);
		}
		if(this.localize){
			tgtObj.localize={...this.localize};
		}
		return attr;
	};
	
	//------------------------------------------------------------------------
	editAttr.isHideExport=function(){
		let def,valText;
		if(this.hyper){
			return false;
		}
		def=this.def;
		if(def.checkHide){
			return def.checkHide(this);
		}
		if("hideVal" in def){
			if(def.hideVal===this.val){
				return true;
			}
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	editAttr.genAttrDef=function(name,showName,key=true,fixed=true){
		let def,vo;
		vo={
			name:name||this.name,
			showName:showName||this.showName||this.name,
			type:this.def.type,
			key:key,fixed:fixed,
			initVal:this.val
		};
		if(this.hyper){
			vo.initValText=this.valText;
		}
		def=this.def;
		if(def.localizable){
			vo.localizable=true;
		}
		if(def.editType){
			vo.editType=def.editType;
		}
		if(def.editMode){
			vo.editMode=def.editMode;
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	editAttr.updateGenedAttrDef=function(attrDef){
		attrDef.initVal=this.val;
		attrDef.localizable=this.def.localizable;
	};
	
	//------------------------------------------------------------------------
	editAttr.setLocalize=function(loc){
		if((!!this.localize)===(!!loc)){
			return;
		}
		if(loc){
			if(typeof(loc)==="object" && ("EN" in loc)){
				this.localize=loc;
			}else{
				this.localize={"EN":this.valText};
			}
		}else{
			this.localize=false;//Will use current valText as valText
		}
		this.emitChanged();
	};
	
	//------------------------------------------------------------------------
	editAttr.setLocaleText=function(lanCode,text){
		if(!this.localize)
			return;
		this.localize[lanCode]=text;
	};
	
	//------------------------------------------------------------------------
	editAttr.applyLanguage=function(lanCode){
		//TODO: Is this function needed?
		let text;
		if(!this.localize)
			return;
	};
	
	//------------------------------------------------------------------------
	editAttr.setComment=function(comment){
		if(comment!==this.comment){
			this.comment=comment;
			this.emitChanged();
		}
	};
	
	//------------------------------------------------------------------------
	//editAttr.exportCode=function(){return exportCode};//

}

//****************************************************************************
//:Integer Edit attr:
//****************************************************************************
var EditIntAttr,editIntAttr;
{
	EditIntAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal||0;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditIntAttr,EditAttr);
	editIntAttr=EditIntAttr.prototype;
	EditAttr.regAttrType("int",EditIntAttr);
	editIntAttr.text2Val=function(text){
		let val;
		if(text===""){
			return 0;
		}
		val=JSON.parse(text);
		if(!Number.isInteger(val)){
			if(Number.isFinite(val)){
				val=Math.trunc(val);
			}else{
				val=this.def.initVal||0;
			}
		}
		return val;
	};
}

//****************************************************************************
//:Number(float) Edit attr:
//****************************************************************************
var EditNumberAttr,editNumberAttr;
{
	EditNumberAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal||0;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditNumberAttr,EditAttr);
	editNumberAttr=EditNumberAttr.prototype;
	EditAttr.regAttrType("number",EditNumberAttr);
	EditAttr.regAttrType("float",EditNumberAttr);
	EditAttr.regAttrType("real",EditNumberAttr);

	editNumberAttr.text2Val=function(text){
		let val;
		if(text===""){
			return this.def.initVal||0;;
		}
		val=JSON.parse(text);
		if(!Number.isFinite(val)){
			val=this.def.initVal||0;
		}
		return val;
	};
}

//****************************************************************************
//:String Edit attr:
//****************************************************************************
var EditStringAttr,editStringAttr;
{
	EditStringAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal||"";
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditStringAttr,EditAttr);
	editStringAttr=EditStringAttr.prototype;
	EditAttr.regAttrType("string",EditStringAttr);
	editStringAttr.text2Val=function(text){
		return ""+text;
	};
	editStringAttr.val2Text=function(val){
		return ""+val;
	};
	//------------------------------------------------------------------------
	//Convert val to text:
	editStringAttr.val2ShowText=function(val){
		let text,pos;
		let def=this.def;
		if(def.val2ShowText){
			return def.val2ShowText.call(this,val);
		}
		if(val===undefined){
			return "";
		}
		text=""+val;
		text=text.replaceAll("\n","\\n");
		return text;
	};
}

//****************************************************************************
//:Boolean Edit attr:
//****************************************************************************
var EditBoolAttr,editBoolAttr;
{
	EditBoolAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		if(init){
			if("initValText" in def){
				if("initVal" in def){
					this.valText=def.initValText;
					this.val=def.initVal;
				}else{
					this.setValByText(def.initValText);
				}
			}else{
				this.val=def.initVal||false;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditBoolAttr,EditAttr);
	editBoolAttr=EditBoolAttr.prototype;
	EditAttr.regAttrType("bool",EditBoolAttr);
	editBoolAttr.text2Val=function(text){
		let val;
		if(text===""){
			return this.def.initVal||false;
		}
		val=JSON.parse(text);
		return !!val;
	};

	//------------------------------------------------------------------------
	//Convert val to text:
	editBoolAttr.val2ShowText=function(val){
		const vals=this.def.vals||(($ln==="CN")?(["否","是"]):/*EN*/(["false","true"]));
		let def=this.def;
		if(def.val2ShowText){
			return def.val2ShowText.call(this,val);
		}
		if(val===undefined){
			return "";
		}
		if(val===true){
			return vals[1];
		}
		if(val===false){
			return vals[0];
		}
		val=!!val;
		val=val?1:0;
		return `${vals[val]}(${JSON.stringify(val)})`;
	};
}

//****************************************************************************
//:RGBColor/RGBAColor Edit attr:
//****************************************************************************
var EditRGBAttr,editRGBAttr;
var EditRGBAAttr,editRGBAAttr;
{
	EditRGBAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		this.arrayVal=1;
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal?def.initVal.slice(0):[0,0,0];
				this.valText=this.val2Text(this.val);
			}
		}else{
			this.val=def.initVal?def.initVal.slice(0):[0,0,0];
			this.valText=this.val2Text(this.val);
		}
	};
	inherits(EditRGBAttr,EditAttr);
	editRGBAttr=EditRGBAttr.prototype;
	EditAttr.regAttrType("colorRGB",EditRGBAttr);
	let colorTextChecker=/#([a-f0-9]{3}){1,2}\b/i;
	//------------------------------------------------------------------------
	//Set color text is a bit tricky than normal val:
	editRGBAttr.setValByText=function(text){
		let hyperCode,oldVal,val,pos,oldText
		oldText=this.valText;
		oldVal=[this.val[0],this.val[1],this.val[2]];
		this.valText=text;
		try{
			if(text.startsWith("#")){
				if(colorTextChecker.test(text)){
					this.hyper=false;
					this.trace=false;
					val=this.text2Val(text);
					this.val[0]=val[0];
					this.val[1]=val[1];
					this.val[2]=val[2];
				}else{
					this.hyper=true;
					this.trace=false;
					pos=text.indexOf("#>",1);
					if(pos>0){
						hyperCode=text.substring(1,pos);
					}else{
						hyperCode=text.substring(1);
					}
					val=this.owner.execHyperAttr(hyperCode);
					if(typeof(val)==="string"){
						this.hyper=false;
						this.trace=false;
						val=this.text2Val(text);
						this.val[0]=val[0];
						this.val[1]=val[1];
						this.val[2]=val[2];
						if(val[3]>0){
							this.val[3]=val[3];
						}
						if(val[4]>0||val[4]<0){
							this.val[4]=val[4];
						}
					}else if(Array.isArray(val)){
						this.val[0]=val[0];
						this.val[1]=val[1];
						this.val[2]=val[2];
						if(val[3]>0){
							this.val[3]=val[3];
						}
						if(val[4]>0||val[4]<0){
							this.val[4]=val[4];
						}
					}else{
						let initVal;
						initVal=this.def.initVal||[0,0,0];
						this.val[0]=initVal[0];
						this.val[1]=initVal[1];
						this.val[2]=initVal[2];
					}
				}
			}else if(text.startsWith("${")){
				let pos=text.lastIndexOf("}");
				if(pos<0){
					throw new Error(`Hyper code incomplete: ${text}`);
				}
				hyperCode=text.substring(2,pos);
				this.hyper=true;
				this.trace=(text[pos+1]===",");
				val=this.owner.execHyperAttr(hyperCode);
				if(typeof(val)==="string"){
					this.hyper=false;
					this.trace=false;
					val=this.text2Val(text);
					this.val[0]=val[0];
					this.val[1]=val[1];
					this.val[2]=val[2];
					if(val[3]>0){
						this.val[3]=val[3];
					}
					if(val[4]>0||val[4]<0){
						this.val[4]=val[4];
					}
				}else if(Array.isArray(val)){
					this.val[0]=val[0];
					this.val[1]=val[1];
					this.val[2]=val[2];
					if(val[3]>0){
						this.val[3]=val[3];
					}
					if(val[4]>0||val[4]<0){
						this.val[4]=val[4];
					}
				}else{
					let initVal;
					initVal=this.def.initVal||[0,0,0];
					this.val[0]=initVal[0];
					this.val[1]=initVal[1];
					this.val[2]=initVal[2];
				}
			}else{
				this.hyper=false;
				this.trace=false;
				val=this.text2Val(text);
				this.val[0]=val[0];
				this.val[1]=val[1];
				this.val[2]=val[2];
				if(val[3]>0){
					this.val[3]=val[3];
				}
				if(val[4]>0||val[4]<0){
					this.val[4]=val[4];
				}
			}
		}catch(err){
			//No change here:
			this.val[0]=oldVal[0];
			this.val[1]=oldVal[1];
			this.val[2]=oldVal[2];
			return;
		}
		if(oldText!==text || oldVal[0]!==this.val[0] || oldVal[1]!==this.val[1]||oldVal[2]!==this.val[2]){
			this.emitChanged();
			//this.emitNotify && this.emitNotify("Change");
		}
	};
	//------------------------------------------------------------------------
	editRGBAttr.text2Val=function(text){
		let r,g,b,val;
		if(text.startsWith("rgb(")){
			let pts;
			text=text.trim().substring(4,text.length-1);
			pts=text.split(",");
			r=parseInt(pts[0]);
			g=parseInt(pts[1]);
			b=parseInt(pts[2]);
			val=[r,g,b];
		}else if(text.startsWith("[")){
			let pts,x;
			text=text.trim().substring(1,text.length-1);
			if(text[0]==="["){
				val=JSON.parse("["+text+"]");
			}else{
				pts=text.split(",");
				r=parseInt(pts[0]);
				g=parseInt(pts[1]);
				b=parseInt(pts[2]);
				val=[r,g,b];
				x=parseFloat(pts[3]);
				if(x>0){
					val[3]=x;
					x=parseInt(pts[4]);
					if(x>0 || x<0){
						val[4]=x;
					}
				}
			}
		}else if(text.startsWith("#")){
			let pts;
			text=text.substring(1).trim();
			if(text.length===3){
				r=parseInt(text.substring(0,1),16)*16+15;
				g=parseInt(text.substring(1,2),16)*16+15;
				b=parseInt(text.substring(2,3),16)*16+15;
			}else if(text.length===6){
				r=parseInt(text.substring(0,2),16);
				g=parseInt(text.substring(2,4),16);
				b=parseInt(text.substring(4,6),16);
			}
			val=[r,g,b];
		}
		return val;
	};
	editRGBAttr.val2Text=function(val){
		let r,g,b;
		r=val[0];r=r>255?255:(r<0?0:r);r=Math.trunc(r);
		g=val[1];g=g>255?255:(g<0?0:g);g=Math.trunc(g);
		b=val[2];b=b>255?255:(b<0?0:b);b=Math.trunc(b);
		return `[${r},${g},${b}]`;
	};
	//------------------------------------------------------------------------
	editRGBAttr.isHideExport=function(){
		let def,valText,hideVal,val;
		if(this.hyper){
			return false;
		}
		def=this.def;
		if("hideVal" in def){
			hideVal=def.hideVal;
			val=this.val;
			if(val[0]===hideVal[0]&&val[1]===hideVal[1]&&val[2]===hideVal[2]){
				return true;
			}
		}
		return false;
	};
	

	//************************************************************************
	//Color RGBA Attr:
	//************************************************************************
	EditRGBAAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		this.arrayVal=1;
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal?def.initVal.slice(0):[0,0,0,1];
				this.valText=this.val2Text(this.val);
			}
		}else{
			this.val=def.initVal?def.initVal.slice(0):[0,0,0,1];
			this.valText=this.val2Text(this.val);
		}
		if(Array.isArray(this.val)){
			this.color=this.val;
		}else{
			this.color=[255,255,255,1];
		}
		this.gnt=null;
	};
	inherits(EditRGBAAttr,EditAttr);
	editRGBAAttr=EditRGBAAttr.prototype;
	EditAttr.regAttrType("colorRGBA",EditRGBAAttr);
	//------------------------------------------------------------------------
	//Set color text is a bit tricky than normal val:
	editRGBAAttr.setValByText=function(text){
		let hyperCode,valColor,oldColor,oldVal,val,pos,oldText;
		oldText=this.valText;
		oldVal=this.val;
		valColor=this.color;
		oldColor=[valColor[0],valColor[1],valColor[2],valColor[3]];
		this.valText=text;
		try{
			if(text.startsWith("#")){
				if(colorTextChecker.test(text)){
					this.hyper=false;
					this.trace=false;
					val=this.text2Val(text);
					valColor[0]=val[0];
					valColor[1]=val[1];
					valColor[2]=val[2];
					valColor[3]=val[3];
					this.val=valColor;
					this.arrayVal=1;
				}else{
					this.hyper=true;
					this.trace=false;
					pos=text.indexOf("#>",1);
					if(pos>0){
						hyperCode=text.substring(1,pos);
					}else{
						hyperCode=text.substring(1);
					}
					val=this.owner.execHyperAttr(hyperCode);
					if(typeof(val)==="string"){
						val=this.text2Val(val);
						if(Array.isArray(val)){
							valColor[0]=val[0];
							valColor[1]=val[1];
							valColor[2]=val[2];
							valColor[3]=val[3];
							this.val=valColor;
							this.gnt=null;
							this.arrayVal=1;
						}else{
							valColor[0]=255;valColor[1]=255;valColor[2]=255;valColor[3]=1;
							this.gnt=val;
							this.val=this.gnt;
							this.arrayVal=0;
						}
					}else if(Array.isArray(val)){
						let l;
						l=val[4];
						if(l>=0){
							l=l>100?100:l;
							val[0]=(255-val[0])*l/100+val[0];
							val[1]=(255-val[1])*l/100+val[1];
							val[2]=(255-val[2])*l/100+val[2];
						}else if(l<0){
							l=l<-100?-100:l;
							val[0]=val[0]*(100+l)/100;
							val[1]=val[1]*(100+l)/100;
							val[2]=val[2]*(100+l)/100;
						}
						valColor[0]=val[0];
						valColor[1]=val[1];
						valColor[2]=val[2];
						valColor[3]=val[3];
						this.val=valColor;
						this.arrayVal=1;
					}else{
						let initVal;
						initVal=this.def.initVal||[0,0,0];
						valColor[0]=initVal[0];
						valColor[1]=initVal[1];
						valColor[2]=initVal[2];
						valColor[3]=initVal[3];
						this.val=valColor;
						this.arrayVal=1;
					}
				}
			}else if(text.startsWith("${")){
				let pos=text.lastIndexOf("}");
				if(pos<0){
					throw new Error(`Hyper code incomplete: ${text}`);
				}
				hyperCode=text.substring(2,pos);
				this.hyper=true;
				this.trace=(text[pos+1]===",");
				val=this.owner.execHyperAttr(hyperCode);
				if(typeof(val)==="string"){
					val=this.text2Val(val);
					if(Array.isArray(val)){
						valColor[0]=val[0];
						valColor[1]=val[1];
						valColor[2]=val[2];
						valColor[3]=val[3];
						this.val=valColor;
						this.gnt=null;
						this.arrayVal=1;
					}else{
						valColor[0]=255;valColor[1]=255;valColor[2]=255;valColor[3]=1;
						this.gnt=val;
						this.val=this.gnt;
						this.arrayVal=0;
					}
				}else if(Array.isArray(val)){
					let l;
					l=val[4];
					if(l>=0){
						l=l>100?100:l;
						val[0]=(255-val[0])*l/100+val[0];
						val[1]=(255-val[1])*l/100+val[1];
						val[2]=(255-val[2])*l/100+val[2];
					}else if(l<0){
						l=l<-100?-100:l;
						val[0]=val[0]*(100+l)/100;
						val[1]=val[1]*(100+l)/100;
						val[2]=val[2]*(100+l)/100;
					}
					valColor[0]=val[0];
					valColor[1]=val[1];
					valColor[2]=val[2];
					valColor[3]=val[3];
					this.val=valColor;
					this.gnt=null;
					this.arrayVal=1;
				}else{
					let initVal;
					initVal=this.def.initVal||[0,0,0];
					valColor[0]=initVal[0];
					valColor[1]=initVal[1];
					valColor[2]=initVal[2];
					valColor[3]=initVal[3];
					this.val=valColor;
					this.gnt=null;
					this.arrayVal=1;
				}
			}else{
				this.hyper=false;
				this.trace=false;
				val=this.text2Val(text);
				if(Array.isArray(val)){
					valColor[0]=val[0];
					valColor[1]=val[1];
					valColor[2]=val[2];
					valColor[3]=val[3];
					this.val=valColor;
					this.gnt=null;
					this.arrayVal=1;
				}else{
					valColor[0]=255;valColor[1]=255;valColor[2]=255;valColor[3]=1;
					this.gnt=val;
					this.val=this.gnt;
					this.arrayVal=0;
				}
			}
		}catch(err){
			//No change here:
			valColor[0]=oldColor[0];
			valColor[1]=oldColor[1];
			valColor[2]=oldColor[2];
			valColor[3]=oldColor[3];
			this.val=oldVal;
			this.arrayVal=Array.isArray(oldVal);
			return;
		}
		if(oldText!==text || oldColor[0]!==valColor[0] || oldColor[1]!==valColor[1]||oldColor[2]!==valColor[2]||oldColor[3]!==valColor[3]){
			this.emitChanged();
		}
	};
	
	//------------------------------------------------------------------------
	editRGBAAttr.text2Val=function(text){
		let r,g,b,a,l,val;
		if(text.indexOf("-gradient(")>0){
			return text;
		}else if(text.startsWith("rgb(")){
			let pts;
			text=text.trim().substring(4,text.length-1);
			pts=text.split(",");
			r=parseInt(pts[0]);
			g=parseInt(pts[1]);
			b=parseInt(pts[2]);
			val=[r,g,b,1];
		}else if(text.startsWith("rgba(")){
			let pts;
			text=text.trim().substring(5,text.length-1);
			pts=text.split(",");
			r=parseInt(pts[0]);
			g=parseInt(pts[1]);
			b=parseInt(pts[2]);
			a=parseFloat(pts[3]);a=a>=0?a:this.def.initVal[3];
			val=[r,g,b,a];
		}else if(text.startsWith("[")){
			let pts;
			text=text.trim().substring(1,text.length-1);
			pts=text.split(",");
			r=parseInt(pts[0]);
			g=parseInt(pts[1]);
			b=parseInt(pts[2]);
			a=parseFloat(pts[3]);a=a>=0?a:this.def.initVal[3];
			l=pts[4]?parseInt(pts[4]):0;
			if(l>0){
				l=l>100?100:l;
				r=(255-r)*l/100+r;
				g=(255-g)*l/100+g;
				b=(255-b)*l/100+b;
			}else if(l<0){
				l=l<-100?-100:l;
				r=r*(100+l)/100;
				g=g*(100+l)/100;
				b=b*(100+l)/100;
			}
			val=[r,g,b,a];
		}else if(text.startsWith("#")){
			let pts;
			text=text.substring(1).trim();
			if(text.length===3){
				r=parseInt(text.substring(0,1),16)*16+15;
				g=parseInt(text.substring(1,2),16)*16+15;
				b=parseInt(text.substring(2,3),16)*16+15;
			}else if(text.length===6){
				r=parseInt(text.substring(0,2),16);
				g=parseInt(text.substring(2,4),16);
				b=parseInt(text.substring(4,6),16);
			}
			val=[r,g,b,1];
		}
		return val;
	};

	//------------------------------------------------------------------------
	editRGBAAttr.val2Text=function(val){
		let r,g,b,a;
		if(Array.isArray(val)){
			r=val[0];r=r>255?255:(r<0?0:r);r=Math.trunc(r);
			g=val[1];g=g>255?255:(g<0?0:g);g=Math.trunc(g);
			b=val[2];b=b>255?255:(b<0?0:b);b=Math.trunc(b);
			a=val[3];a=a>1?1:(a<0?0:a);a=a.toFixed(2);
			return `[${r},${g},${b},${a}]`;
		}else if(typeof(val)==="string"){
			return val;
		}
	};
	
	//------------------------------------------------------------------------
	editRGBAAttr.isHideExport=function(){
		let def,valText,hideVal,val;
		if(this.hyper){
			return false;
		}
		def=this.def;
		if("hideVal" in def){
			hideVal=def.hideVal;
			val=this.val;
			if(val[0]===hideVal[0]&&val[1]===hideVal[1]&&val[2]===hideVal[2]&&val[3]===hideVal[3]){
				return true;
			}
		}
		return false;
	};
}

//****************************************************************************
//:Choice Edit attr:
//****************************************************************************
var EditChoiceAttr,editChoiceAttr;
{
	EditChoiceAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditChoiceAttr,EditAttr);
	editChoiceAttr=EditChoiceAttr.prototype;
	EditAttr.regAttrType("choice",EditChoiceAttr);

	//------------------------------------------------------------------------
	editChoiceAttr.text2Val=function(text){
		let i,n,val;
		let vals=this.def.vals;
		let textVal;
		try{
			textVal=JSON.parse(text);	
		}catch(err){
			textVal=text;
		}
		if(vals){
			n=vals.length;
			for(i=0;i<n;i++){
				val=vals[i];
				if(text===val[1]){
					return val[0];
				}
				if(text===val[0]){
					return val[0];
				}
			}
		}
		return textVal;
	};
	
	//------------------------------------------------------------------------
	editChoiceAttr.val2Text=function(val){
		let i,n,item;
		let vals=this.def.vals;
		if(vals){
			n=vals.length;
			for(i=0;i<n;i++){
				item=vals[i];
				if(val===item[0]){
					return item[1];
				}
			}
		}
		return JSON.stringify(val);	
	};

	//------------------------------------------------------------------------
	editChoiceAttr.genAttrDef=function(name,showName,icon,key=true,fixed=true){
		return {
			name:name||this.name,
			type:this.def.type,
			showName:showName||this.showName||this.name,
			icon:icon,
			key:key,fixed:fixed,
			vals:[...this.def.vals],
			initVal:this.val
		};
	};
	
	//------------------------------------------------------------------------
	editChoiceAttr.updateGenedAttrDef=function(attrDef){
		attrDef.initVal=this.val;
		attrDef.vals=[...this.def.vals];
	};

	//------------------------------------------------------------------------
	//Convert val to text:
	editChoiceAttr.val2ShowText=function(val){
		let def=this.def;
		let i,n,item;
		let vals=def.vals;
		if(def.val2ShowText){
			return def.val2ShowText.call(this,val);
		}
		if(val===undefined){
			return "";
		}
		if(vals){
			n=vals.length;
			for(i=0;i<n;i++){
				item=vals[i];
				if(val===item[0]){
					return item[2]||item[1];
				}
			}
		}
		return JSON.stringify(val);	
	};
}

//****************************************************************************
//:File Edit attr:
//****************************************************************************
var EditFileAttr,editFileAttr,EditURLAttr;
{
	EditFileAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		this.isPath=1;
		this.isURL=def.isURL;
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal||"";
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditFileAttr,EditAttr);
	EditAttr.regAttrType("path",EditFileAttr);
	EditAttr.regAttrType("file",EditFileAttr);
	EditAttr.regAttrType("image",EditFileAttr);
	EditAttr.regAttrType("fileDir",EditFileAttr);
	editFileAttr=EditFileAttr.prototype;

	//------------------------------------------------------------------------
	editFileAttr.text2Val=function(text){
		let rootPath,doc,prj;
		if(text[0]==="/"){
			if(this.isURL && text[1]!=="~" && text[1]!=="@"){
				return "/~"+text;
			}
			return text;
		}
		if(text){
			prj=this.owner.prj;
			rootPath=prj.path;
			if(!rootPath){
				rootPath="/";
			}
			text=pathLib.join(rootPath,text);
			if(this.isURL){
				text="/~"+text;
			}
			return text;
		}
		return "";
	};

	//------------------------------------------------------------------------
	editFileAttr.val2Text=function(val){
		let rootPath,doc,prj;
		if(!val.startsWith("/")){
			return val;
		}
		if(val){
			doc=this.owner.doc;
			prj=this.owner.prj;
			if(doc && doc.path){
				rootPath=pathLib.dirname(doc.path);
			}
			rootPath=rootPath||prj.path;
			if(!rootPath){
				rootPath="/";
			}
			return pathLib.relative(val,rootPath);
		}
		return "";
	};
	
	//------------------------------------------------------------------------
	editFileAttr.exportCode=function(docType){
		let path=this.valText;
		if(this.isURL){
			if(path[0]==="/"&& path[1]!=="@" &&path[1]!=="~"){
				path="/~"+path;
			}
		}
		return `"${path}"`;
	};

	//------------------------------------------------------------------------
	//------------------------------------------------------------------------
	EditURLAttr=function(owner,def,init){
		EditFileAttr.call(this,owner,def,false);
		this.isURL=true;
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal||"";
				this.valText=this.val2Text(this.val);
			}
		}
	};
	EditAttr.regAttrType("url",EditURLAttr);
	inherits(EditURLAttr,EditFileAttr);
}

//****************************************************************************
//:Length attr
//****************************************************************************
var EditLengthAttr,editLengthAttr;
{
	EditLengthAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		this.directText=false;
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditLengthAttr,EditAttr);
	editLengthAttr=EditLengthAttr.prototype;
	EditAttr.regAttrType("length",EditLengthAttr);
	
	//------------------------------------------------------------------------
	editLengthAttr.val2ShowText=function(){
		let val,valType;
		let def=this.def;
		if(def.val2ShowText){
			return def.val2ShowText.call(this,val);
		}
		val=this.val;
		if(val===undefined||val===""){
			return (($ln==="CN")?("自适应"):/*EN*/("auto"));
		}else if(this.hyper){
			return `${this.valText}=${val}`
		}else{
			valType=typeof(val);
			if(valType==="string"){
				return this.valText;
			}else if(valType==="number"){
				return ""+val;
			}
			return JSON.stringify(val);
		}
	};

	//------------------------------------------------------------------------
	let chk0=/(^")|(^')|(^`)/;//Is an JSON string?
	let chk1=/^-?\d+(\.\d+)?%$/;//aa% expression
	let chk11=/FW|FH/;//FW/FH expression
	let chk2=/(^\d\dpx*)|(^\d\d*$)/;//100px or 100
	let chk3=/^\d\d*%[ ]*[+-][ ]*\d\d*$/;//aa%+b
	let chk4=/^calc\([.0-9\+\-\*\/\%\s\w]+\)$/;//calc(100% + 100px)
	editLengthAttr.text2Val=function(text){
		let val;
		if(text===""){
			text='""';
		}
		text=text.trim();
		
		if(chk0.test(text)){
			val=JSON.parse(text);
			this.directText=true;
			return val;
		}else if(chk1.test(text)){
			val=text;//VFACT supports this
			this.directText=true;
		}else if(chk11.test(text)){
			val=text;//VFACT supports this
			this.directText=false;
		}else if(chk2.test(text)){
			val=parseInt(text);
			this.directText=true;
		}else if(chk3.test(text)){
			text=text.replace("+"," + ");
			text=text.replace("-"," - ");
			val=`>calc(${text}px)`;//Make it calc(...)
			this.directText=true;
		}else if(chk4.test(text)){
			val=">"+text;//HTML calc(...)
			this.directText=true;
		}else if(text[0]===">"){
			val=text;//raw HTML expression
			this.directText=true;
		}else{
			val=JSON.parse(text);
			if(typeof(val)==="string"){
				this.directText=false;
				return val;
			}else{
				if(!Number.isInteger(val)){
					if(Number.isFinite(val)){
						val=Math.trunc(val);
						this.directText=false;
					}else{
						val=this.def.initVal||0;
						this.directText=false;
					}
				}
			}
		}
		return val;
	};

	//------------------------------------------------------------------------
	editLengthAttr.exportCode=function(docType){
		if(docType==="vfact"){
			let val=this.val;
			if(typeof(val)==="string"){
				if(val[0]===">"){//Raw HTML value?
					return JSON.stringify(val);
				}
				if(!val){
					return `""`
				}
				if(this.directText){
					return JSON.stringify(val);
				}
				return `(FW,FH)=>(${val})`
			}
			if(val===undefined){
				val="";
			}
			return JSON.stringify(val);
		}else{
			return JSON.stringify(this.val);
		}
	};
}

//****************************************************************************
//:Hyper object attr
//****************************************************************************
let EditHyperObjAttr,editHyperObjAttr;
{
	function cvtObj(obj,owner){
		let attrName,attr,attrType,pos,hyperCode;
		for(attrName in obj){
			attr=obj[attrName];
			attrType=typeof(attr);
			switch(attrType){
				case "string":{
					if(attr.startsWith("#")){
						pos=attr.indexOf("#>",1);
						if(pos>0){
							hyperCode=attr.substring(1,pos);
						}else{
							hyperCode=attr.substring(1);
						}
						obj[attrName]=owner.execHyperAttr(hyperCode);
					}
					break;
				}
				case "object":{
					cvtObj(attr,owner);
					break;
				}
			}
		}
	}
	//------------------------------------------------------------------------
	EditHyperObjAttr=function(owner,def,init){
		EditAttr.call(this,owner,def,false);
		this.hyperText="";
		if(init){
			if("initValText" in def){
				this.valText=def.initValText;
				if("initVal" in def){
					this.val=def.initVal;
				}else{
					this.val=this.text2Val(this.valText);
				}
			}else{
				this.val=def.initVal;
				this.valText=this.val2Text(this.val);
			}
		}
	};
	inherits(EditHyperObjAttr,EditAttr);
	editHyperObjAttr=EditHyperObjAttr.prototype;
	EditAttr.regAttrType("hyperObj",EditHyperObjAttr);
	
	//------------------------------------------------------------------------
	editHyperObjAttr.setValByText=function(text){
		let midJSON;
		this.valText=text;
		if(text===""){
			this.hyperText="";
			this.val=undefined;
			this.hyper=false;
			return;
		}
		try{
			midJSON=JSON.parse(text);
		}catch(err){
			midJSON={};
		}
		if(typeof(midJSON)==="object"){
			cvtObj(midJSON,this.owner);
			this.hyperText=JSON.stringify(midJSON);
			this.hyper=true;
		}else{
			this.hyper=false;
			this.hyperText=text;
		}
		this.val=midJSON;
		this.emitChanged();
	};

	
	//------------------------------------------------------------------------
	editHyperObjAttr.text2Val=function(text){
		let midJSON;
		midJSON=JSON.parse(text);
		cvtObj(midJSON);
		return midJSON;
	};
	
	//------------------------------------------------------------------------
	editHyperObjAttr.exportValText=function(attr){
		let code="";
		function genCode(obj){
			let attrName,attr,attrType,isObjArray;
			isObjArray=Array.isArray(obj);
			if(isObjArray){
				code+="[";
				for(attrName in obj){
					attr=obj[attrName];
					attrType=typeof(attr);
					switch(attrType){
						case "string":
							if(attr.startsWith("#")){
								let pos=attr.indexOf("#>");
								if(pos>0){
									code+=`"${attr.substring(pos+2)},`;
								}else{
									code+=`"${attr.substring(1)},`;
								}
							}else{
								code+=`"${JSON.stringify(attr)},`;
							}
							break;
						case "object":
							genCode(attr);
							code+=",";
							break;
						default:
							code+=`${JSON.stringify(attr)},`;
							break;
					}
				}
				if(code.endsWith(",")){
					code=code.substring(0,code.length-1);
				}
				code+="]";
			}else{
				code+="{";
				for(attrName in obj){
					attr=obj[attrName];
					attrType=typeof(attr);
					switch(attrType){
						case "string":
							if(attr.startsWith("#")){
								let pos=attr.indexOf("#>");
								if(pos>0){
									code+=`"${attrName}":${attr.substring(pos+2)},`;
								}else{
									code+=`"${attrName}":${attr.substring(1)},`;
								}
							}else{
								code+=`"${attrName}":${JSON.stringify(attr)},`;
							}
							break;
						case "object":
							code+=`"${attrName}":`;
							genCode(attr);
							code+=",";
							break;
						default:
							code+=`"${attrName}":${JSON.stringify(attr)},`;
							break;
					}
				}
				if(code.endsWith(",")){
					code=code.substring(0,code.length-1);
				}
				code+="}";
			}
			return code;
		}
		if(this.hyper){
			let text,obj;
			text=this.valText;
			if(text.startsWith("#")){
				let pos;
				pos=text.indexOf("#>");
				if(pos>0){
					return text;
				}
				return text.substring(1);
			}
			obj=JSON.parse(text);
			return "#"+genCode(obj);
		}
		return this.valText===""?"null":this.valText;
	};
}
export {EditAttr};

