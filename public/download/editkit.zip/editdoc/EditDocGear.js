import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import pathLib from "/@path";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {} from "../EditClass.js";
import {EditDoc,EditDocDef} from "./EditDoc.js";
import {EditHudObj} from "../edithud/EditHudObj.js";
import {EditHudGear} from "../edithud/EditHudGear.js";
import {EditHudFace} from "../edithud/EditHudObjFace.js";
import {EditFlowSeg} from "../segflow/EditFlowSeg.js";
import {} from "../segflow/EditFlowSegDef.js";
import {} from "../edithud/EditFaceTag.js";

var DocHudGear,docHudGear;
var deviceScreens={
	"iPhone 320x480":[320,480],
	"iPhone 375x750":[375,750],
	"iPad 768x1024":[768,1024],
	"iPad 1024x768":[1024,768],
	"Desktop 800x600":[800,600],
	"Desktop 1200x900":[1200,900]
};
const $ln=VFACT.lanCode;
//****************************************************************************
//:Constructor
DocHudGear=function(owner,def,init){
	let objDef,hudDef,self,gearStub,prjCfg,framework;
	self=this;
	EditDoc.call(this,owner,def,true);
	objDef=this.objDef;
	hudDef=objDef.hudDef;
	hudDef=EditHudObj.getDef(hudDef);
	if(!hudDef){
		console.error(`Can't create HudGear with hud type: ${objDef.hudDef}`);
		throw new Error(`Can't create HudGear with hud type: ${objDef.hudDef}`);
	}
	prjCfg=this.prj.config;
	framework=prjCfg.framework;
	if(framework!=="vfact"){
		this.genLibJS=true;
	}

	//Sub segs:
	this.segsVal=this.getAttr("segs");
	this.segsList=this.segsVal.attrList;
	this.segsVal.on("AttrAdd",this.OnSegAdd);
	this.segsVal.on("AttrInsert",this.OnSegInsert);
	this.segsVal.on("AttrRemove",this.OnSegRemove);

	this.addImportObj("appCfg",this.prj.path+"/cfg/appCfg.js");
	{
		let willUpdateLiveObj=false;
		//Mockup States:
		this.mockupStates=this.getAttr("mockupStates");
		//Create args:
		this.createArgs=this.getAttr("createArgs");
		this.createArgs.onNotify("Changed",()=>{
			let def=this.exposedGearDef;
			if(def){
				EditHudGear.updateGearArgs(def,self);
			}
		});
		//TODO: Can be merged with upper codes?
		this.createArgs.on("Changed",()=>{
			let updateLiveObj=0;
			if(!willUpdateLiveObj){
				willUpdateLiveObj=1;
				updateLiveObj=1;
			}
			this.buildScopeEnv();
			this.localVars.muteEmit("Changed");
			this.localVars.updateHyperAttrs();
			this.localVars.unmuteEmit("Changed");

			this.buildScopeEnv();
			this.stateObj.muteEmit("Changed");
			this.stateObj.updateHyperAttrs();
			this.stateObj.unmuteEmit("Changed");

			this.buildScopeEnv();
			this.hudObj.updateHyperAttrs();
			if(updateLiveObj && this.hudObj.liveEdObj){
				willUpdateLiveObj=0;
				this.hudObj.rebuildLiveObj();
			}
		});
		//Local variables:
		this.localVars=this.getAttr("localVars");
		this.localVars.onNotify("Changed",()=>{
			let updateLiveObj=0;
			if(!willUpdateLiveObj){
				willUpdateLiveObj=1;
				updateLiveObj=1;
			}
			this.buildScopeEnv();
			this.stateObj.muteEmit("Changed");
			this.stateObj.updateHyperAttrs();
			this.stateObj.unmuteEmit("Changed");

			this.buildScopeEnv();
			this.hudObj.updateHyperAttrs();
			if(updateLiveObj && this.hudObj.liveEdObj){
				willUpdateLiveObj=0;
				this.hudObj.rebuildLiveObj();
			}
		});
		//StateObj:
		this.stateObj=this.getAttr("state");
		this.stateObj.onNotify("Changed",()=>{
			let updateLiveObj=0;
			let def=this.exposedGearDef;
			if(def){
				EditHudGear.updateGearArgs(def,self);
			}
			if(!willUpdateLiveObj){
				willUpdateLiveObj=1;
				updateLiveObj=1;
			}
			this.buildScopeEnv();
			this.hudObj.updateHyperAttrs();
			if(updateLiveObj && this.hudObj.liveEdObj){
				willUpdateLiveObj=0;
				this.hudObj.rebuildLiveObj();
			}
		});
	}
	
	this.onNotify("Changed",()=>{
		let def=this.exposedGearDef;
		if(def){
			EditHudGear.updateGearArgs(def,self);
		}
	});
		
	this.gearName=this.getAttr("gearName");
	this.gearIcon=this.getAttr("gearIcon");
	this.gearCatalog=this.getAttr("gearCatalog");
	this.gearW=this.getAttr("gearW");
	this.gearH=this.getAttr("gearH");
	this.oneHud=this.getAttr("oneHud");
	
	this.dataModel=this.getAttr("model");

	this.hudObj=this.addAttr({
		name:"hud",showName:"Component",type:"hudobj",def:hudDef,key:1,fixed:1,edit:1,save:1,navi:"doc",
	});
	Object.defineProperty(this.hudObj,"allowExtraAttr",{
		get:function(){
			return self.oneHud.val?false:true;
		}
	});
	
	//Generate exposed attrs-list attr
	{
		let baseAttrs=this.hudObj.properties.objDef.attrs;
		let attrName,expAttrs;
		expAttrs={};
		for(attrName in baseAttrs){
			if(baseAttrs[attrName].edit!==false && baseAttrs[attrName].gearExpose!==false ){
				expAttrs[attrName]={
					name:attrName,type:"bool",key:1,fixed:1,initVal:false,rawEdit:false
				};
			}
		}
		expAttrs["id"].initVal=expAttrs["x"].initVal=expAttrs["y"].initVal=expAttrs["display"].initVal=expAttrs["position"].initVal=true;
		expAttrs["id"].edit=expAttrs["x"].edit=expAttrs["y"].edit=expAttrs["display"].edit=expAttrs["position"].edit=false;
		this.exposeGear=this.addAttr({
			name:"exposeGear",showName:(($ln==="CN")?("作为组件导出"):/*EN*/("Expose as Gear")),type:"bool",key:1,fixed:1,rawEdit:false,
		});
		this.exposeGear.onChange(()=>{
			this.updateGearExpose();
		});

		this.exposeTemplate=this.addAttr({
			name:"exposeTemplate",showName:(($ln==="CN")?("导出为模版"):/*EN*/("Expose as Template")),type:"bool",key:1,fixed:1,initVal:false,rawEdit:false,
		});
		this.exposeTemplate.onChange(()=>{
			this.updateTemplateExpose();
		});

		this.exposeAttrs=this.addAttr({
			name:"exposeAttrs",showName:(($ln==="CN")?("组件的属性"):/*EN*/("Exposed Properties")),type:"object",key:1,fixed:1,edit:1,save:1,
			def:{
				name:"exposeAttrs",icon:"disk.svg",attrs:expAttrs
			}
		});
		this.exposeAttrs.onNotify("Changed",()=>{
			let def=this.exposedGearDef;
			if(def){
				EditHudGear.updateGearArgs(def,self);
			}
		});
		this.exposeStateAttrs=this.addAttr({
			name:"exposeStateAttrs",showName:(($ln==="CN")?("状态属性导出"):/*EN*/("Exposed State Properties")),type:"array",key:1,fixed:1,edit:1,save:1,
			def:"StringArray"
		});
		this.exposeStateAttrs.onNotify("Changed",()=>{
			let def=this.exposedGearDef;
			if(def){
				EditHudGear.updateGearArgs(def,self);
			}
		});
	}
	
	this.initScope();
	
	//Overload data-model dummy's edit items:
	this.dataModel.getEditRootPpts=function(){
		if(self.hudObj.curFace){
			return [];
		}
		return [
			{attr:this.prj.docApp.attrLocalize},
			{attr:this.prj.docApp.attrLanguage},
			{obj:self.getAttr("mockupStates"),open:true},
			{obj:self.getAttr("createArgs"),open:true},
			{obj:self.getAttr("localVars"),open:true},
			{obj:self.getAttr("state"),open:true},
		];
	};
	
	//Faces entry:
	this.faceTags=this.getAttr("faceTags");
	this.faceTags.onNotify("Changed",()=>{
		let def=this.exposedGearDef;
		if(def){
			EditHudGear.updateGearArgs(def,self);
		}
	});
	this.curFaceTag=null;
	this.faceStateObj=null;
	this.facePlaying=false;
	
	//Edit env:
	let editEnv;
	editEnv=this.editEnv=this.getAttr("editEnv");
	this.tgtDevice=editEnv.getAttr("device");
	this.scrW=editEnv.getAttr("screenW");
	this.scrH=editEnv.getAttr("screenH");
	this.bgColor=editEnv.getAttr("bgColor");
	this.bgChecker=editEnv.getAttr("bgChecker");
	editEnv.on("Changed",(attr)=>{
		let idx,size;
		if(attr===this.tgtDevice){
			idx=this.tgtDevice.val;
			size=deviceScreens[idx];
			if(size){
				this.scrW.setValByText(""+size[0]);
				this.scrH.setValByText(""+size[1]);
				this.emitNotify("DeviceChanged");
			}
		}else if(attr===this.scrW || attr===this.scrH){
			this.tgtDevice.setValByText("Custom Size");
			this.emitNotify("DeviceChanged");
		}else if(attr===this.bgColor){
			this.emitNotify("DeviceChanged");
		}else if(attr===this.bgChecker){
			this.emitNotify("DeviceChanged");
		}
	});
	/*self.getNaviDocRoot=function(){
		return [editEnv,self.getAttr("editObjs"),self.faceTags,self.hudObj];
	};*/
	self.getEditRootPpts=editEnv.getEditRootPpts=function(){
		let list=[
			{attr:this.prj.docApp.attrLocalize},
			{attr:this.prj.docApp.attrLanguage},
			{obj:editEnv,open:true},
			//{attr:self.getAttr("exportTarget")},
			{
				group:1,name:"AI",showName:(($ln==="CN")?("AI"):/*EN*/("AI")),
				attrs:[
					self.getAttr("exposeToAI"),self.getAttr("descAI"),self.getAttr("exposeTree2AI"),
				],
				open:true
			},
			{
				group:1,name:"Expose",showName:(($ln==="CN")?("导出"):/*EN*/("Expose")),
				attrs:[
					self.exposeTemplate,self.exposeGear,
					self.gearCatalog,self.gearName,self.gearIcon,self.getAttr("previewImg"),
					self.gearW,self.gearH,self.getAttr("fixPose"),self.getAttr("description"),self.exposeAttrs,self.exposeStateAttrs
				],
				open:false
			},
		];
		return list;
	};

	this.exposedGearDef=null;
	
	//ForgeEditState:
	this.forgeState={
		devicePos:[80,80],
		zoom:1,
	};
	this.naviState={
		selected:[],
		hotItem:null
	};
	
	//Is current loading?
	this.loadingGear=false;
};

inherits(DocHudGear,EditDoc);
docHudGear=DocHudGear.prototype;

const mockupObjDef={
	name:"MockupObj",icon:"class.svg",attrs:{},allowExtraAttr:1,attrType:"mockState",attrTypeDef:"mockState"
};
const FlowSegArrayDef={elementType:"flowseg",allowExtraAttr:1};

var genDocHudDef=function(defName,baseHudType){
	return {
		name:defName,
		hudDef:baseHudType,
		icon:"gears.svg",allowExtraAttr:0,navi:"prj",
		constructFunc:DocHudGear,
		exporter:"Gear",
		attrs:{
			"editEnv":{
				name:"editEnv",showName:(($ln==="CN")?("设计设定"):/*EN*/("Design Profile")),type:"object",icon:"array.svg",key:1,fixed:1,edit:1,navi:"doc",
				def:{
					icon:"phone.svg",
					attrs:{
						"device":{
							name:"device",showName:(($ln==="CN")?("目标设备"):/*EN*/("Target Device")),type:"choice",initVal:"Custom Size",key:1,fixed:1,edit:1,rawEdit:false,
							vals:[
								["Custom Size","Custom Size"],
								["iPhone 320x480","iPhone 320x480"],
								["iPhone 375x750","iPhone 375x750"],
								["iPad 768x1024","iPad 768x1024"],
								["iPad 1024x768","iPad 1024x768"],
								["Desktop 800x600","Desktop 800x600"],
								["Desktop 1200x900","Desktop 1200x900"],
							],
							info:"Target device screen profile",
						},
						"screenW":{
							name:"screenW",showName:(($ln==="CN")?("屏幕宽度"):/*EN*/("Screen Width")),type:"int",initVal:375,key:1,fixed:1,edit:1,
							info:"Target device screen width",
						},
						"screenH":{
							name:"screenH",showName:(($ln==="CN")?("屏幕高度"):/*EN*/("Screen Height")),type:"int",initVal:750,key:1,fixed:1,edit:1,
							info:"Target device screen height",
						},
						"bgColor":{
							name:"bgColor",showName:(($ln==="CN")?("背景"):/*EN*/("Background")),type:"colorRGB",initVal:[255,255,255],key:1,fixed:1,edit:1,
							info:"Edit device background color",
						},
						"bgChecker":{
							name:"bgChecker",showName:(($ln==="CN")?("棋盘背景"):/*EN*/("Checker Background")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false,
							info:"Apply checker background patten, useful to edit translucent UI or components",
						}
					}
				},
			},
			...EditDocDef.attrs,//basic attr: path
			"model":{
				name:"model",showName:(($ln==="CN")?("数据模型"):/*EN*/("Data Model")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
				newAttrMode:"GearArg",watchTree:false
			},
			"createArgs":{
				name:"createArgs",showName:(($ln==="CN")?("构造参数"):/*EN*/("Arguments")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
				newAttrMode:"GearArg",watchTree:true
			},
			"editObjs":{
				name:"editObjs",showName:"DataClass",type:"object",icon:"array.svg",key:1,fixed:1,edit:false,navi:"doc",
				def:{
					attrs:{},
					attrType:"objclass",attrTypeDef:"ObjClass",
					allowExtraAttr:1
				}
			},
			"localVars":{
				name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0,
				newAttrMode:"HudLocalVal",watchTree:true
			},
			"oneHud":{
				name:"oneHud",type:"bool",initVal:false,key:1,fixed:1,edit:false,navi:0
			},
			"state":{
				name:"state",showName:(($ln==="CN")?("组件状态对象"):/*EN*/("Component state")),type:"object",def:"StateObj",key:1,fixed:1,edit:false,navi:0,watchTree:true
			},
			"segs":{
				name:"segs",showName:(($ln==="CN")?("逻辑设计"):/*EN*/("Logic Flow")),type:"array",icon:"condition.svg",def:FlowSegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
			},
			"exportTarget":{
				name:"exportTarget",showName:(($ln==="CN")?("导出目标"):/*EN*/("Export target")),type:"choice",initVal:"jax",key:1,fixed:1,edit:1,rawEdit:false,
				vals:[
					["vfact","VFACT document"],
					["react","React document"],
					["vue","VUE document"],
					["nxt","Nxt document"],
				]
			},
			"gearName":{
				name:"gearName",showName:(($ln==="CN")?("组件名称"):/*EN*/("Gear name")),exportName:"showName",type:"string",initVal:"",key:1,fixed:1,localizable:true
			},
			"gearIcon":{
				name:"gearIcon",showName:(($ln==="CN")?("组件图标"):/*EN*/("Gear icon")),type:"string",initVal:"gears.svg",key:1,fixed:1,
			},
			"gearW":{
				name:"gearW",showName:(($ln==="CN")?("组件初始宽度"):/*EN*/("Gear init width")),type:"int",initVal:100,key:1,fixed:1,
			},
			"gearH":{
				name:"gearH",showName:(($ln==="CN")?("组件初始高度"):/*EN*/("Gear init height")),type:"int",initVal:100,key:1,fixed:1,
			},
			"gearCatalog":{
				name:"gearCatalog",showName:(($ln==="CN")?("组件分类"):/*EN*/("Gear catalog")),type:"string",initVal:"",key:1,fixed:1,
			},
			"description":{
				name:"description",showName:(($ln==="CN")?("描述说明"):/*EN*/("Description")),exportName:"desc",type:"string",initVal:"",key:1,fixed:1,localizable:true
			},
			"fixPose":{
				name:"fixPose",showName:(($ln==="CN")?("固定状态"):/*EN*/("Fix Pose")),type:"bool",initVal:false,key:1,fixed:1,rawEdit:false,
			},
			"previewImg":{
				name:"previewImg",showName:(($ln==="CN")?("预览"):/*EN*/("Preview")),type:"string",initVal:"",key:1,fixed:1,
			},
			"faceTags":{
				name:"faceTags",showName:(($ln==="CN")?("预设外观"):/*EN*/("Faces")),type:"object",key:1,fixed:1,edit:false,navi:"doc",
				def:{name:"FaceTags",icon:"faces.svg",attrs:{},attrType:"facetag",attrTypeDef:"FaceTag",allowExtraAttr:1,objAttrs:{isFaceTags:1}}
			},
			"mockupStates":{
				name:"mockupStates",showName:(($ln==="CN")?("模拟样本"):/*EN*/("Mockup States")),icon:"ghost.svg",
				type:"object",def:mockupObjDef,key:1,fixed:1,edit:false,navi:0,
			},
			"exposeToAI":{
				name:"exposeToAI",showName:(($ln==="CN")?("输出AI信息"):/*EN*/("Expose to AI")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
			},
			"descAI":{
				name:"descAI",showName:(($ln==="CN")?("组件AI说明"):/*EN*/("AI Description")),type:"string",initVal:"",key:1,fixed:1,localizable:true
			},
			"exposeTree2AI":{
				name:"exposeTree2AI",showName:(($ln==="CN")?("向AI输出控件树"):/*EN*/("Expose UI-Tree to AI")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false,
			},
		},
		objAttrs:{
			getLocalizableObjs(){
				return [this.getAttr("localVars"),this.getAttr("state"),this.hudObj,this.segsList]
			}
		}
	};
}

//Basic HudDocDef:
EditDoc.regDocDef("GearHud",genDocHudDef("GearHud","hud"));
EditDoc.regDocDef("GearBox",genDocHudDef("GearBox","box"));
EditDoc.regDocDef("GearText",genDocHudDef("GearText","text"));
EditDoc.regDocDef("GearButton",genDocHudDef("GearButton","button"));
EditDoc.regDocDef("GearImage",genDocHudDef("GearImage","image"));
EditDoc.regDocDef("GearEdit",genDocHudDef("GearEdit","edit"));
//Containers:
EditDoc.regDocDef("UIView",genDocHudDef("UIView","view"));
EditDoc.regDocDef("UIDock",genDocHudDef("UIDock","dock"));
EditDoc.regDocDef("GearFlexBoxH",genDocHudDef("GearFlexBoxH","FlexBoxH"));
EditDoc.regDocDef("GearFlexBoxV",genDocHudDef("GearFlexBoxV","FlexBoxV"));
EditDoc.regDocDef("GearFlexBoxHR",genDocHudDef("GearFlexBoxHR","FlexBoxHR"));
EditDoc.regDocDef("GearFlexBoxVR",genDocHudDef("GearFlexBoxVR","FlexBoxVR"));
EditDoc.regDocDef("GearGridBox",genDocHudDef("GearGridBox","GridBox"));
EditDoc.regDocDef("GearListBox",genDocHudDef("GearListBox","ListBox"));
EditDoc.regDocDef("GearTreeBox",genDocHudDef("GearTreeBox","TreeBox"));

//****************************************************************************
//:Hud access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docHudGear.runOnAllHuds=function(func,hasGearSlot,...args){
		this.hudObj.runOnAllHuds(func,hasGearSlot,...args);
	};
}

//****************************************************************************
//:Faces:
//****************************************************************************
{
	let facePlaySeq=1;
	//------------------------------------------------------------------------
	docHudGear.getFaceTag=function(tagName){
		let list,attr;
		let pos=tagName.indexOf("@");
		if(pos<0){
			list=this.faceTags.attrList;
			for(attr of list){
				if(attr.jaxId===tagName){
					return attr;
				}
			}
		}else{
			let ownerTag,timeTag;
			ownerTag=tagName.substring(pos+1);
			timeTag=tagName.substring(0,pos);
			ownerTag=this.getFaceTag(ownerTag);
			if(!ownerTag){
				return null;
			}
			list=ownerTag.faceTimes.attrList;
			for(attr of list){
				if(attr.jaxId===timeTag){
					return attr;
				}
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	docHudGear.getFaceTagByName=function(tagName){
		let list,attr;
		let pos=tagName.indexOf("@");
		if(pos<0){
			list=this.faceTags.attrList;
			for(attr of list){
				if(attr.name===tagName){
					return attr;
				}
			}
		}else{
			let ownerTag,timeTag;
			ownerTag=tagName.substring(pos+1);
			timeTag=tagName.substring(0,pos);
			ownerTag=this.getFaceTagByName(ownerTag);
			if(!ownerTag){
				return null;
			}
			list=ownerTag.faceTimes.attrList;
			for(attr of list){
				if(attr.getName(attr)===tagName){
					return attr;
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	docHudGear.enterFaceEdit=function(faceTag){
		let faceState;
		if(this.curFaceTag===faceTag){
			return;
		}
		if(this.curFaceTag){
			this.emit("FaceSwitch");
		}else{
			this.faceStateObj=this.stateObj.getJSObj();
			this.setScopeObj("state",this.faceStateObj,false);
		}
		this.curFaceTag=faceTag;
		faceState=faceTag.getAttr("state");
		if(faceState){
			Object.assign(this.faceStateObj,faceState.getJSObj());
		}
		this.hudObj.enterFaceEdit(faceTag,true,true);
		this.emit("FaceOn",faceTag);
	};
	
	//------------------------------------------------------------------------
	docHudGear.exitFaceEdit=function(updateAttr){
		if(!this.curFaceTag){
			return;
		}
		this.setScopeObj("state",this.stateObj,false);
		this.faceStateObj=null;
		//TODO: Update hyper attr?
		this.curFaceTag=null;
		this.hudObj.exitFaceEdit(updateAttr);
		this.emit("FaceOff");
	};
	
	//------------------------------------------------------------------------
	docHudGear.updateFaceState=function(faceTag){
		let faceState;
		faceState=faceTag.getAttr("state");
		if(faceState){
			Object.assign(this.faceStateObj,faceState.getJSObj());
			this.hudObj.updateFaceState(faceTag);
		}
	};
	
	//------------------------------------------------------------------------
	docHudGear.playFaceTag=function(faceTag){
		let liveObj,tagVO,time,faceState;
		if(this.facePlaying){
			return;
		}
		if(this.curFaceTag===faceTag){
			return;
		}
		if(!this.faceStateObj){
			this.faceStateObj=this.stateObj.getJSObj();
			this.setScopeObj("state",this.faceStateObj,false);
		}
		faceState=faceTag.getAttr("state");
		if(faceState){
			Object.assign(this.faceStateObj,faceState.getJSObj());
		}
		this.curFaceTag=faceTag;
		//TODO: Deal with face-state-change:
		//this.hudObj.enterFaceEdit(faceTag,false);
		this.hudObj.updateFaceState(faceTag,true);
		liveObj=this.hudObj.liveEdObj;
		if(!liveObj){
			return;
		}
		if(!liveObj.faces){
			liveObj.faces={};
		}
		this.facePlaying=facePlaySeq++;
		tagVO=faceTag.genFaceCSS(this.hudObj,this.facePlaying);
		liveObj.faces[faceTag.name]=tagVO.faceVO;
		liveObj.showFace(faceTag.name);
		if(tagVO.maxTime>0 || tagVO.aniNum>0){
			time=tagVO.maxTime+200;
			this.emit("PlayFaceStart");
			this.facePlayTimer=window.setTimeout(()=>{
				this.facePlayTimer=null;
				this.facePlaying=0;
				console.log("Face play end.");
				this.emit("PlayFaceFin");
				this.hudObj.enterFaceEdit(this.curFaceTag,false,true);
			},time);
		}else{
			this.facePlayTimer=null;
			this.facePlaying=0;
			this.hudObj.enterFaceEdit(faceTag,false,true);
			this.emit("PlayFaceFin");
		}
	};
	
	//------------------------------------------------------------------------
	docHudGear.switchPlayFaceTag=function(faceTag,seq){
		if(seq!==this.facePlaying){
			return;
		}
		if(this.curFaceTag===faceTag){
			return;
		}
		this.curFaceTag=faceTag;
		this.emit("PlayFace",faceTag);
		this.hudObj.enterFaceEdit(faceTag,false,false);
	};
	
	//------------------------------------------------------------------------
	docHudGear.cancelFacePlay=function(){
		if(!this.facePlaying){
			return;
		}
		facePlaySeq++;
		if(this.facePlayTimer){
			window.clearTimeout(this.facePlayTimer);
			this.facePlayTimer=null;
		}
		this.hudObj.exitFaceEdit(false);
		this.hudObj.rebuildLiveObj();
		this.facePlaying=0;
		this.curFaceTag=null;
		this.emit("PlayFaceCancel",);
	};
}

//****************************************************************************
//:Scope:
//****************************************************************************
{
	docHudGear.initScope=function(){
		let appCfg,stateObj;
		this.scopeObj={};
		appCfg=this.prj.objConfig;
		stateObj=this.stateObj;
		this.setScopeObj("appCfg",appCfg,false);
		this.setScopeObj("$ln",appCfg.getAttr("lanCode"),false);
		this.setScopeObj("state",stateObj,false);
		this.setScopeObj("txtSize",appCfg.getAttr("txtSize"),false);
		this.setScopeObj("cfgColor",appCfg.getAttr("color"),false);
		this.setScopeObj("cfgSize",appCfg.getAttr("size"),false);
		this.setScopeObj("mockups",EditAttr.mockups,false);
		this.setScopeObj("callArgs",this.createArgs,true);
		this.setScopeObj("localVars",this.localVars,true);

		//TODO: Add more scope: app,appData,cfgText...
	};
}

//****************************************************************************
//:I/O
//****************************************************************************
{
	//--------------------------------------------------------------------
	//Load content from vo embed in code
	docHudGear.loadFromCodeSaveVO=function(vo){
		let ret;
		this.loadingGear=1;
		this.muteNotify();
		ret=EditObj.prototype.loadFromVO.call(this,vo);
		this.hudObj.OnThisHudAdd();
		this.unmuteNotify();
		this.loadingGear=0;
		this.updateGearExpose();
		this.updateTemplateExpose();
		let def=this.exposedGearDef;
		if(def){
			EditHudGear.updateGearArgs(def,this);
		}
		this.updateHyperAttrs(true);
		if(this.dataDoc){
			this.dataDoc.on("Blured",()=>{this.OnDocBlur();});
		}
		//Link seg/outlets
		{
			let list,i,n,seg;
			list=this.segsList;
			n=list.length;
			for(i=0;i<n;i++){
				seg=list[i];
				seg.postLoadLink();
				seg.inGearDoc=true;
			}
		}
		//Link events/segs:
		this.hudObj.runOnAllHuds((hud)=>{
			let list,i,n,funcObj,jaxId,seg;
			list=hud.functions.attrList;
			for(funcObj of list){
				jaxId=funcObj.getAttrVal("seg");
				seg=this.getEntrySeg(jaxId);
				if(seg){
					funcObj.entrySeg=seg;
				}else{
					funcObj.setAttrByText("seg","");
				}
			}
		});
		return ret;
	};
	
	//--------------------------------------------------------------------
	docHudGear.scanImports=function(){
		let attrList,attr;
		this.imports={};
		this.addImportObj("appCfg",this.prj.path+"/cfg/appCfg.js");
		attrList=this.attrList;
		for(attr of attrList){
			if(attr.attrList){
				this.scanObjImports(attr);
			}
		}
	};
}

//****************************************************************************
//:Screen, background color:
//****************************************************************************
{
}

//****************************************************************************
//:Live Hud access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docHudGear.genHudCSS=function(){
		let cssVO,stateObj,hudState,ppts;
		stateObj=this.stateObj;
		hudState={};
		cssVO=this.hudObj.genHudCSS(false);
		cssVO.faces={};//Make sure faces entry so we can have a jaxId-Map on this hudObj.
		return cssVO;
	};
}

//****************************************************************************
//:Gear
//****************************************************************************
{
	//------------------------------------------------------------------------
	docHudGear.updateGearCatalog=function(){
		let gearDef,oldCatalog,catalog;
		gearDef=this.exposedGearDef;
		if(!gearDef){
			return;
		}
		oldCatalog=gearDef.catalog;
		catalog=this.gearCatalog.val;
		if(catalog!==oldCatalog){
			let expose;
			expose=!!this.exposeGear.val;
			gearDef.catalog=catalog;
			if(oldCatalog){
				EditHudObj.regCatalogHudDef(oldCatalog,gearDef.name,null);//Remove old entry:
			}
			if(expose && catalog){
				EditHudObj.regCatalogHudDef(catalog,gearDef.name,gearDef);//Register new entry:
			}
		}
	};

	//------------------------------------------------------------------------
	docHudGear.updateTemplateExpose=function(){
		let expose,templateDef,self;
		if(this.loadingGear){
			return;
		}
		self=this;
		templateDef=this.exposedTemplateDef;
		expose=!!this.exposeTemplate.val;
		if(expose){
			if(!templateDef){
				templateDef=this.exposedTemplateDef={
					template:true,
					name:"Template"+this.jaxId,
					internal:true,
					path:this.path,
					get info(){
						return self.getAttr("description").val||self.path;
					},
					get icon(){
						return self.gearIcon.val||"gears.svg";
					},
					get showName(){
						let name,extName;
						name=self.gearName.val;
						if(name){
							return name;
						}
						name=self.getName();
						extName=pathLib.extname(name);
						name=name.substring(0,name.length-extName.length);
						return name;
					},
				};
			}
			templateDef.isExposed=1;
			EditHudObj.regCatalogHudDef(this.owner.name==="docGears"?"GearTemplates":"ViewTemplates",templateDef.name,templateDef);
		}else{
			if(templateDef){
				templateDef.isExposed=0;
				EditHudObj.regCatalogHudDef(this.owner.name==="docGears"?"GearTemplates":"ViewTemplates",templateDef.name,null);
			}
		}
	};
	
	//------------------------------------------------------------------------
	docHudGear.updateGearExpose=function(){
		let expose,gearDef,catalog;
		if(this.loadingGear){
			return;
		}
		gearDef=this.exposedGearDef;
		expose=!!this.exposeGear.val;
		if(expose){
			if(!gearDef){
				gearDef=this.exposedGearDef=EditHudGear.genInteralGearDef(this);
			}
			gearDef.isExposed=1;
			EditHudObj.regCatalogHudDef("Gears",gearDef.name,gearDef);
			EditHudObj.regHudDef(gearDef.name,gearDef);
			catalog=gearDef.catalog;
			if(catalog){
				EditHudObj.regCatalogHudDef(catalog,gearDef.name,gearDef);
			}
		}else{
			if(gearDef){
				gearDef.isExposed=0;
				EditHudObj.regCatalogHudDef("Gears",gearDef.name,null);
				EditHudObj.regHudDef(gearDef.name,null);
				catalog=gearDef.catalog;
				if(catalog){
					EditHudObj.regCatalogHudDef(catalog,gearDef.name,null);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	docHudGear.gearCSSFunction=function(argObj){
		let callArgs,orgAttrs,tgtAttrHash,callArgObj,attr,tgtAttr;
		let hudObj,liveObj,cssVO;
		let stateObj,exposeStateAttrs,hudState;
		
		function addStatePpt(pptName){
			let attr;
			attr=stateObj.getAttr(pptName);
			if(attr){
				Object.defineProperty(cssVO,"$$"+pptName,{
					get: function () {
						return hudState[pptName];
					},
					set: function (v) {
						hudState[pptName]=v;
					},
					enumerable: true,
				});
			}
		}

		stateObj=this.stateObj;
		callArgObj={};
		callArgs=this.getAttr("createArgs");
		orgAttrs=callArgs.attrList;
		tgtAttrHash=argObj.attrHash;
		for(attr of orgAttrs){
			tgtAttr=tgtAttrHash[attr.name];
			if(tgtAttr){
				callArgObj[attr.name]=tgtAttr.selfProxy?tgtAttr:tgtAttr.val;
			}else{
				callArgObj[attr.name]=attr.selfProxy?attr:attr.val;
			}
		}
		hudObj=this.hudObj;
		liveObj=hudObj.liveEdObj;
		hudObj.dropLiveObj();//Disable update liveEdObj
		this.setScopeObj("callArgs",callArgObj,true);
		this.localVars.updateHyperAttrs(true);
		stateObj.updateHyperAttrs(true);
		//hudObj.updateHyperAttrs(true);
		this.updateHyperAttrs(true);
		exposeStateAttrs=this.exposeStateAttrs.attrList;
		if(exposeStateAttrs.length){
			let attrList,attr;
			attrList=stateObj.attrList;
			hudState={};
			for(attr of attrList){
				hudState[attr.name]=attr.val;
			}
			hudState=VFACT.flexState(hudState);
			this.setScopeObj("state",hudState,false);
			//Use hyper mode:
			cssVO=hudObj.genHudCSS(true);
			cssVO.hudState=hudState;
			//append exposed state attrs:
			if(stateObj && exposeStateAttrs){
				let pptName,ppt,exStatePpts,statePpts;
				exStatePpts=exposeStateAttrs;
				statePpts=stateObj.attrHash;
				for(pptName of exStatePpts){
					addStatePpt(pptName.val);
				}
			}
			this.setScopeObj("state",stateObj,false);
		}else{
			cssVO=hudObj.genHudCSS(false);
		}
		//Face support:
		{
			let faceTags,faces,faceTag,faceName,i,n;
			faceTags=this.faceTags.attrList;
			n=faceTags.length;
			if(n>0){
				faces={};
				for(i=0;i<n;i++){
					faceTag=faceTags[i];
					faceName=faceTag.name;
					faces[faceName]=faceTag.genFaceCSS(this.hudObj);
				}
				cssVO.faces=faces;
			}
		}
		this.setScopeObj("callArgs",callArgs,true);
		this.updateHyperAttrs(true);
		if(liveObj){
			hudObj.bindLiveObj(liveObj);
		}
		return cssVO;
	};
	
	//------------------------------------------------------------------------
	docHudGear.genGearSlotsDef=function(){
		let defVO={};
		let rootHud=this.hudObj;
		function checkHud(editHud){
			let exposeAttr,contentLayout=0;
			exposeAttr=editHud.getAttr("exposeContainer");
			if(editHud.properties){
				contentLayout=editHud.properties.getAttr("contentLayout");
				if(contentLayout){
					contentLayout=contentLayout.val;
				}
			}
			if(exposeAttr && exposeAttr.val){
				let name;
				if(editHud===rootHud){
					name="Contents";
				}else{
					name=editHud.properties.getAttr("id").val||"[Slot]";
				}
				defVO["Slot"+editHud.jaxId]={
					icon:"pin.svg",name:"Slot"+editHud.jaxId,showName:name,type:"gearcontainer",editJaxId:editHud.jaxId,key:1,fixed:1,
					contentLayout:contentLayout,
				};
			}
		}
		rootHud.runOnAllHuds(checkHud,false);
		return defVO;
	};
}

//****************************************************************************
//:Flow seg:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docHudGear.createNewFunctionSeg=function(funcObj){
		let dataDoc,hud,editor,segCanvas,newSeg,idName,name,funcName,baseName,idx;
		let funcArgs,arg,argName;
		dataDoc=this.dataDoc;
		editor=dataDoc.editBox;
		if(editor){
			editor.setSubEditMode("SEG");
			editor.setEditMode("Gear");
		}
		hud=funcObj.owner.owner;
		segCanvas=editor.getSubEditor("SEG");
		newSeg=segCanvas.createSeg("Entry");
		idName=hud.properties.getAttrVal("id")||"";
		if(idName){
			idName=idName.substring(0,1).toLowerCase()+idName.substring(1);
		}else{
			idName=hud.objDef.name;
			idName=idName.substring(0,1).toLowerCase()+idName.substring(1);
		}
		funcName=funcObj.def.name;
		funcName=baseName=idName+funcName;
		idx=1;
		while(this.getEntrySegByName(funcName)){
			funcName=baseName+(idx++);
		}
		newSeg.setAttrByText("id",funcName);
		
		//Init args:
		newSeg.addCallArg("sender",{type:"auto",initVal:null});
		funcArgs=funcObj.getAttr("callArgs").attrList;
		for(arg of funcArgs){
			argName=arg.name;
			newSeg.addCallArg(argName,arg.def);
		}
		return newSeg;
	};
	
	//------------------------------------------------------------------------
	docHudGear.getEntrySeg=function(jaxId){
		let seg,findSeg,segsList;
		segsList=this.segsList;;
		for(seg of segsList){
			if(seg.jaxId===jaxId){
				return seg;
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	docHudGear.getEntrySegByName=function(name){
		let seg,findSeg,segsList;
		segsList=this.segsList;;
		for(seg of segsList){
			if(seg.getAttrVal("id")===name){
				return seg;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	docHudGear.findSeg=function(jaxId,segsList){
		let seg,findSeg;
		segsList=segsList||this.segsList;;
		for(seg of segsList){
			if(seg.jaxId===jaxId){
				return seg;
			}
			if(seg.segsList){
				findSeg=this.findSeg(jaxId,seg.segsList);
				if(findSeg){
					return findSeg;
				}
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	docHudGear.dropSegLiveObjs=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.dropLiveObj();
		}
	};
	
	//-----------------------------------------------------------------------
	docHudGear.renderPath=function(){
		let segsList,seg;
		segsList=this.segsList;
		for(seg of segsList){
			seg.renderPath();
		}
	};
	
	//-----------------------------------------------------------------------
	docHudGear.OnSegAdd=function(seg){
		seg.inGearDoc=true;		
	};

	//-----------------------------------------------------------------------
	docHudGear.OnSegInsert=function(seg){
		seg.inGearDoc=true;		
	};

	//-----------------------------------------------------------------------
	docHudGear.OnSegRemove=function(seg){
		seg.inGearDoc=false;
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docHudGear.OnLanguageChange=function(){
		this.updateHyperAttrs(true);
		this.hudObj.rebuildLiveObj();
	};
	
	//------------------------------------------------------------------------
	docHudGear.OnDocFocus=function(){
		let hudObj;
		hudObj=this.hudObj;
		hudObj.OnDocFocus();
	};

	//------------------------------------------------------------------------
	docHudGear.getNaviDocRoot=function(){
		let config,attrHash;
		let list=[];
		config=this.prj.config;
		attrHash=this.attrHash;
		list.push(attrHash["editEnv"]);
		list.push(this.dataModel);
		if(config.allowFace){
			list.push(attrHash["faceTags"]);
		}
		list.push(this.hudObj);
		list.push(attrHash["segs"]);
		return list;
	};
	//------------------------------------------------------------------------
	docHudGear.naviDocFocus=function(){
		this.exitFaceEdit(true);
	};
	
	//------------------------------------------------------------------------
	docHudGear.naviDocReady=function(){
		let naviBox,treeBox,state,obj;
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let selected,obj,node;
			obj=state.hotItem;
			if(obj){
				this.prj.setEditSubObj(obj);
			}
		}
	};

	//------------------------------------------------------------------------
	docHudGear.OnDocBlur=function(){
		let naviBox,treeBox,state,obj;
		this.exitFaceEdit(false);
		state=this.naviState;
		naviBox=this.prj.getBoxNaviDoc();
		if(naviBox){
			let selected,node;
			treeBox=naviBox.treeBox;
			selected=Array.from(treeBox.selected);
			state.selected.splice(0);
			for(node of selected){
				obj=node.nodeObj;
				if(obj instanceof EditHudObj){
					state.selected.push(node.nodeObj);
				}
			}
			node=treeBox.hotNode;
			state.hotItem=node?node.nodeObj:null;
		}
	};
}

export {DocHudGear,genDocHudDef};




