var EditAtom,editAtom;
EditAtom=function(doc){
	this.doc=doc;
};
editAtom=EditAtom.prototype={};

//----------------------------------------------------------------------------
EditAtom.funcAtom=function(doc,exec,undo,redo){
	let atom;
	atom={
		doc:doc,exec:exec,undo:undo,redo:redo
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.setAttrByText=function(obj,attr,text){
	let atom,locLan;
	atom={
		doc:obj.doc,
		obj:obj,
		oldText:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			atom.oldText=attr.valText;
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				locLan=obj.prj.curLanguage;
				attr.setLocaleText(locLan,text);
			}
			obj.setAttrByText(attr,text);
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				attr.setLocaleText(locLan,atom.oldText);
				if(locLan===obj.prj.curLanguage){
					obj.setAttrByText(attr,atom.oldText);
				}
			}else{
				obj.setAttrByText(attr,atom.oldText);
			}
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				attr.setLocaleText(locLan,text);
				if(locLan===obj.prj.curLanguage){
					obj.setAttrByText(attr,text);
				}
			}else{
				obj.setAttrByText(attr,text);
			}
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.setAttrLocObj=function(obj,attr,locObj){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldLocs:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			atom.oldText=attr.valText;
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				atom.oldLocs={...attr.localize};
				Object.assign(attr.localize,locObj);
				//Update attrText
				let curLan=obj.prj.curLanguage;
				if(curLan in attr.localize){
					obj.setAttrByText(attr,attr.localize[curLan]);
				}else{
					obj.setAttrByText(attr,attr.localize["EN"]);
				}
			}else{
				console.warn(`Attr is not localized: ${attr.name}`);
			}
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				attr.localize=atom.oldLocs;
			}else{
				console.warn(`Attr is not localized: ${attr.name}`);
			}
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				Object.assign(attr.localize,locObj);
				let curLan=obj.prj.curLanguage;
				if(curLan in attr.localize){
					obj.setAttrByText(attr,attr.localize[curLan]);
				}else{
					obj.setAttrByText(attr,attr.localize["EN"]);
				}
			}else{
				console.warn(`Attr is not localized: ${attr.name}`);
			}
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.addAttr=function(obj,attrDef){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		attr:null,
		exec:()=>{
			atom.attr=obj.addAttr(attrDef);
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",atom.attr);
			obj.removeAttr(atom.attr);
		},
		redo:()=>{
			obj.addAttr(atom.attr);
			obj.prj.emit("ShowEditAttr",atom.attr);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.insertAttr=function(obj,attr,idx){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		attr:attr,
		attrIdx:idx,
		exec:()=>{
			obj.insertAttr(attr,idx);
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.removeAttr(atom.attr);
		},
		redo:()=>{
			obj.insertAttr(attr,idx);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.removeAttr=function(obj,attr){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		attrIdx:-1,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			atom.attrIdx=obj.attrs.getAttrIdx(attr);
			obj.removeAttr(attr);
			return 1;
		},
		undo:()=>{
			obj.insertAttr(attr,atom.attrIdx);
			obj.prj.emit("ShowEditAttr",attr);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.removeAttr(attr);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.renameAttr=function(obj,attr,newName){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldName:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			obj.prj.emit("ShowEditAttr",attr);
			atom.oldName=attr.name;
			obj.renameAttr(attr,newName);
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.renameAttr(attr,atom.oldName);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.renameAttr(attr,newName);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.commentAttr=function(obj,attr,comment){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldComment:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			obj.prj.emit("ShowEditAttr",attr);
			atom.oldComment=attr.comment;
			attr.setComment(comment);
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			attr.setComment(atom.oldComment);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			attr.setComment(comment);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.moveUpAttr=function(obj,attr){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldName:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			obj.prj.emit("ShowEditAttr",attr);
			return obj.moveUpAttr(attr);
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.moveDownAttr(attr);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.moveUpAttr(attr);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.moveDownAttr=function(obj,attr){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldName:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			obj.prj.emit("ShowEditAttr",attr);
			return obj.moveDownAttr(attr);
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.moveUpAttr(attr);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			obj.moveDownAttr(attr);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.replaceAttr=function(obj,newAttr){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		newAttr:newAttr,
		oldAttr:null,
		exec:()=>{
			atom.oldAttr=obj.getAttr(newAttr.name);
			obj.prj.emit("ShowEditAttr",newAttr);
			return obj.replaceAttr(newAttr);
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",newAttr);
			obj.replaceAttr(atom.oldAttr);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",atom.oldAttr);
			obj.replaceAttr(atom.newAttr);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.localizeAttr=function(obj,attr){
	let atom;
	atom={
		doc:obj.doc,
		obj:obj,
		oldLoc:null,
		exec:()=>{
			if(typeof(attr)==="string"){
				attr=obj.getAttr(attr);
			}
			atom.oldloc=attr.localize;
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				let text;
				if("EN" in attr.localize){
					text=attr.localize.EN;
				}else{
					text=attr.valText;
				}
				attr.setLocalize(false);
				attr.setValByText(text);
			}else{
				attr.setLocalize(true);
			}
			return 1;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			attr.setLocalize(atom.oldLoc);
			if(attr.localize){
				let curLan=obj.prj.curLanguage;
				if(curLan in attr.localize){
					attr.setValByText(attr.localize[curLan]);
				}
			}
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",attr);
			if(attr.localize){
				let text;
				if("EN" in attr.localize){
					text=attr.localize.EN;
				}else{
					text=attr.valText;
				}
				attr.setLocalize(false);
				attr.setValByText(text);
			}else{
				attr.setLocalize(true);
			}
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.applyAttrObj=function(obj,curAttr,newAttr){
	let atom,curSaveVO,newSaveVO;
	atom={
		doc:obj.doc,
		obj:obj,
		newAttr:newAttr,
		oldAttr:null,
		exec:()=>{
			if(typeof(curAttr)==="string"){
				curAttr=obj.getAttr(curAttr);
			}
			curSaveVO=curAttr.genSaveVO();
			newSaveVO=newAttr.genSaveVO();
			newSaveVO.jaxId=curSaveVO.jaxId;
			atom.oldAttr=obj.getAttr(curAttr.name);
			obj.prj.emit("ShowEditAttr",curAttr);
			curAttr.loadFromVO(newSaveVO);
			obj.emitChanged(obj);
			return true;
		},
		undo:()=>{
			obj.prj.emit("ShowEditAttr",curAttr);
			curAttr.loadFromVO(curSaveVO);
			obj.emitChanged(obj);
		},
		redo:()=>{
			obj.prj.emit("ShowEditAttr",curAttr);
			curAttr.loadFromVO(newSaveVO);
			obj.emitChanged(obj);
		}
	};
	return atom;
};

//----------------------------------------------------------------------------
EditAtom.applyMockupState=function(mockupState){
	let doc,atom,docCreateArgs,docStateObj;
	let curCreateArgsVO,curStateObjVO,newCreateArgsVO,newStateObjVO;
	doc=mockupState.doc;
	docCreateArgs=doc.createArgs;
	docStateObj=doc.stateObj;
	atom={
		doc:doc,
		mockup:mockupState,
		exec:()=>{
			curCreateArgsVO=docCreateArgs.genSaveVO();
			curStateObjVO=docStateObj.genSaveVO();
			doc.prj.emit("ShowEditAttr",curCreateArgsVO);
			doc.prj.emit("ShowEditAttr",curStateObjVO);
			mockupState.applyMockup();
			newCreateArgsVO=docCreateArgs.genSaveVO();
			newStateObjVO=docStateObj.genSaveVO();
			docCreateArgs.emit("Changed");
			return true;
		},
		undo:()=>{
			doc.prj.emit("ShowEditAttr",docCreateArgs);
			doc.prj.emit("ShowEditAttr",docStateObj);
			docCreateArgs.loadFromVO(curCreateArgsVO);
			docStateObj.loadFromVO(curStateObjVO);
			docCreateArgs.emit("Changed");
		},
		redo:()=>{
			doc.prj.emit("ShowEditAttr",docCreateArgs);
			doc.prj.emit("ShowEditAttr",docStateObj);
			docCreateArgs.loadFromVO(newCreateArgsVO);
			docStateObj.loadFromVO(newStateObjVO);
			docCreateArgs.emit("Changed");
		}
	};
	return atom;
};

export {EditAtom};
