import {tabFS} from "/@tabos";
import pathLib from "/@path";
import inherits from "/@inherits";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {mergeCodeWithSeg} from "../exporters/codesegs.js";
import {EditDocExporter} from "../exporters/EditDocExporter.js";

//****************************************************************************
//:Imported document:
//****************************************************************************
let EditDocImport,editDocImport;
{
	EditDocImport=function(path){
		this.path=path;
		this.items={};
	};
	editDocImport=EditDocImport.prototype={};

	//------------------------------------------------------------------------
	editDocImport.addItem=function(name){
		let items=this.items;
		let stub;
		stub=items[name];
		if(stub){
			if(name!==stub.obj){
				console.error(`Import different obj with same name: "${name}", ${this.path}`);
				throw new Error(`Import different obj with same name: "${name}", ${this.path}`);
			}
			stub.refCount+=1;
		}else{
			stub=items[name]={obj:name,refCount:1};
		}
	};
	
	//------------------------------------------------------------------------
	editDocImport.addClass=function(classObj){
		//TODO: Code this:
	};

	//------------------------------------------------------------------------
	editDocImport.addGear=function(gearObj){
		//TODO: Code this:
	};

	//------------------------------------------------------------------------
	editDocImport.subItem=function(name){
		let items=this.items;
		let stub=items[name];
		if(stub){
			stub.refCount-=1;
			if(!stub.refCount){
				delete items[name];
			}
		}
	};
	
	//------------------------------------------------------------------------
	editDocImport.isUsed=function(){
		return Object.keys(this.items).length>0;
	};
}

//****************************************************************************
//:Source code file:
//****************************************************************************
let EditDoc, editDoc,EditDocDef;
{
	EditDoc=function(owner,def,init){
		let self=this;
		let localVars,editObjs;
		this.doc=this;
		EditObj.call(this,owner,def,false);
		this.dataDoc=null;
		this.gotoMarkAfterUpdateDoc=null;//If not null, will goto the line-mark after update docCodes
		this.imports={};
		this.missingCodeSegs={};
		this.lastGenCode=null;
		this.localVars=null;
		this.genLibJS=false;
		if(init){
			this.attrs.ensureKeys();
			this.objReady();
		}
		this.editState={};
		
		//Shortcut for access path:
		Object.defineProperty(this, 'path', {
			get: function () {
				let attr=this.getAttr("path");
				if(attr){
					return attr.val;
				}
				return "";
			},
			set: function (v) {
				return v;
			},
			enumerable: true
		});
		this.onNotify("UpdateCode",()=>{
			self.maybeUpdateDocText(false);
		});
	};
	
	EditDocDef={
		icon:"file.svg",allowExtraAttr:0,
		name:"EditDoc",
		attrs:{
			"path":{name:"path",type:"file",key:1,fixed:1,edit:false,save:false,navi:0},
			"editObjs":{name:"editObjs",type:"object",key:1,fixed:1,edit:true,navi:0}
		}
	};
	
	inherits(EditDoc,EditObj);
	editDoc=EditDoc.prototype;
	EditAttr.regAttrType("docfile",EditDoc);
	EditAttr.regAttrType("doc",EditDoc);
	var docDefRegs={};
	
	EditDoc.regDef=EditDoc.regDocDef=function(name,def){
		docDefRegs[name]=def;
	};
	EditDoc.getDef=EditDoc.getDocDef=function(name){
		return docDefRegs[name];
	};
	EditDoc.regDocDef("DocFile",EditDocDef);
	//Register docs-obj-type for project's doc-groups (like ui/gear/data...).
	EditObj.regObjectDef("DocsObj",{
		name:"DocsObj",attrs:{},attrType:"docfile",attrTypeDef:"DataDoc",allowExtraAttr:1
	});
	
	//************************************************************************
	//:Imports
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Check if a (path) doc file has already been imported by this doc (or docs it imports).
		editDoc.hasImported=function(path,deep=0){
			let docHash,imports,stub,docPath,doc;
			docHash=this.prj.liveDocs;
			imports=this.imports;
			stub=imports[path];
			if(deep>10){
				return false;
			}
			if(stub && stub.isUsed()){
				return true;
			}
			imports=Object.values(imports);
			for(stub of imports){
				if(stub.isUsed()){
					docPath=stub.path;
					doc=docHash[docPath];
					if(doc){
						if(doc.hasImported(path,deep+1)){
							return true;
						}
					}
				}
			}
			return false;
		};
		
		//--------------------------------------------------------------------
		editDoc.addImportClass=function(classObj,path){
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		editDoc.addImportGear=function(gearObj){
			let stub,path,gearName;
			path=gearObj.objDef.source;
			gearName=gearObj.objDef.importName;
			stub=this.imports[path];
			if(!stub){
				stub=new EditDocImport(path);
				this.imports[path]=stub;
			}
			stub.addItem(gearName);
		};
		
		//--------------------------------------------------------------------
		editDoc.addImportSource=function(importSource){
			let stub,path,importName;
			path=importSource.path;
			if(path instanceof Function){
				path=path(this);
			}
			importName=importSource.name;
			stub=this.imports[path];
			if(!stub){
				stub=new EditDocImport(path);
				this.imports[path]=stub;
			}
			stub.addItem(importName);
		};
		
		//--------------------------------------------------------------------
		editDoc.addImportObj=function(editObj,path){
			let stub;
			stub=this.imports[path];
			if(!stub){
				stub=new EditDocImport(path);
				this.imports[path]=stub;
			}
			stub.addItem(editObj);
		};
		
		//--------------------------------------------------------------------
		editDoc.subImportObj=function(editObj,path){
			let stub;
			let attrList,attr;
			stub=this.imports[path];
			if(stub){
				stub.subItem(editObj);
			}
		};
		
		//--------------------------------------------------------------------
		editDoc.scanImports=function(){
			let attrList,attr;
			this.imports={};
			attrList=this.attrList;
			for(attr of attrList){
				if(attr.attrList){
					this.scanObjImports(attr);
				}
			}
		};
		
		//--------------------------------------------------------------------
		editDoc.scanObjImports=function(obj){
			let attrList,attr,objClass,doc,path,name;
			if(obj.def.type==="classobj"){
				objClass=obj.objClass;
				doc=objClass.doc;
				if(doc!==this){
					this.addImportClass(objClass);
				}
			}else if(obj.def.type==="hudobj" && obj.gearFunc){
				this.addImportGear(obj);
			}else if(obj.objDef && obj.objDef.importSource){
				let s=obj.objDef.importSource;
				if(Array.isArray(s)){
					for(let item of s){
						this.addImportSource(item);
					}
				}else{
					this.addImportSource(s);
				}
			}
			attrList=obj.attrList;
			for(attr of attrList){
				if(attr.attrList){
					this.scanObjImports(attr);
				}
			}
		};
	}

	//************************************************************************
	//Edit history,Undo/Redo
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Start a edit action:
		editDoc.startEditAction=function(){
			let prj;
			prj=this.prj;
			if(this.curEditAction){
				this.curEditAction.deep+=1;
				return;
				//throw new Error(`Can't start new EditAction.`);
			}
			this.curEditAction={
				doc:this,editor:null,
				attrObj:null,
				naviObj:prj.curEditSubObj,
				atoms:[],
				deep:1,
			};
			if(this.curFaceTag){
				this.curEditAction.faceTag=this.curFaceTag;
			}
			return this.curEditAction;
		};
		
		//--------------------------------------------------------------------
		editDoc.endEditAction=function(action){
			let editor;
			if(action){
				if(action!==this.curEditAction){
					throw new Error("No EditAction to end");
				}
			}else{
				action=this.curEditAction;
			}
			if(!action){
				console.warn("No EditAction to end");
				//throw new Error("No EditAction to end");
				return;
			}
			action.deep-=1;
			if(action.deep>0){
				return;
			}
			if(!action.atoms || !action.atoms.length){
				//No atom, skip this action
				this.curEditAction=null;
				return;
			}
			
			//Add this action to CodeMirror's history:
			editor=this.dataDoc.editBox;
			if(editor){
				editor.addCodyEditAction(this.curEditAction);
			}
			action.postNaviObj=this.prj.curEditSubObj;
			//Fin:
			this.curEditAction=null;
			this.emitNotify("UpdateCode");
		};
		
		//--------------------------------------------------------------------
		editDoc.execEditAtom=function(atom){
			try{
				if(atom.exec()){
					//Add atom to action:
					this.curEditAction.atoms.push(atom);
					return true;
				}
			}catch(err){
				console.log("Execute EditAtom error, in action:");
				console.log(this.curEditAction);
				console.log("on atom:");
				console.log(atom);
				console.error(err);
				this.curEditAction=null;
				this.emitNotify("UpdateCode");
				return false;
			}
			return false;
		};
		
		//--------------------------------------------------------------------
		editDoc.undo=function(action){
			let atoms,atom,i,n,naviObj,faceTag,postNaviObj;
			faceTag=action.faceTag;
			if(faceTag){
				this.enterFaceEdit(faceTag);
			}else{
				this.exitFaceEdit && this.exitFaceEdit();
			}
			postNaviObj=action.postNaviObj;
			this.prj.setEditSubObj(postNaviObj);
			if(postNaviObj){
			}
			atoms=action.atoms;
			n=atoms.length;
			for(i=n-1;i>=0;i--){
				atom=atoms[i];
				atom.undo();
			}
			naviObj=action.naviObj;
			if(naviObj && naviObj!==postNaviObj){
				this.prj.setEditSubObj(naviObj);
			}
			this.emitNotify("UpdateCode");
		};
		
		//--------------------------------------------------------------------
		editDoc.redo=function(action){
			let atoms,atom,i,n,naviObj,faceTag;
			faceTag=action.faceTag;
			if(faceTag){
				this.enterFaceEdit(faceTag);
			}else{
				this.exitFaceEdit && this.exitFaceEdit();
			}
			naviObj=action.naviObj;
			if(naviObj){
				this.prj.setEditSubObj(naviObj);
			}
			atoms=action.atoms;
			n=atoms.length;
			for(i=0;i<n;i++){
				atom=atoms[i];
				atom.redo();
			}
			this.emitNotify("UpdateCode");
		};
	}
	
	//************************************************************************
	//:I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Overwrite to save just path:
		editDoc.genSaveVO=function(){
			let prj,rootPath,path;
			prj=this.prj;
			rootPath=prj.path;
			let vo={};
			{
				let exportType,orgDef;
				exportType=true;
				if(!this.def.extraAttr && this.owner){
					orgDef=this.owner.getAttrDef(this.name);
					if(orgDef && orgDef.key && this.def.type===orgDef.type){
						exportType=false;
					}
				}
				if(exportType){
					vo.type=this.def.type||"object";
					vo.def=this.objDef.name;
				}
			}
			//vo.type=this.def.type||"object";
			//vo.def=this.objDef.name;
			vo.jaxId=this.jaxId;
			//vo.editVersion=this.editVersion;
			path=this.getAttr("path").val;
			if(path.startsWith(rootPath)){
				path=path.substring(rootPath.length+1);
			}
			vo.path=path;
			return vo;
		};
		
		//--------------------------------------------------------------------
		//Overwrite to load path
		editDoc.loadFromVO=function(vo){
			let path,rootPath,prj;
			prj=this.prj;
			rootPath=prj.path;
			path=vo.path;
			if(!path.startsWith("/")){
				path=rootPath+"/"+path;
			}
			this.muteNotify();
			this.attrs.ensureKeys();
			this.objReady();
			this.setAttrByText("path",path);
			this.prj.addDocToLoad(this);
			this.unmuteNotify();
		};
		
		//--------------------------------------------------------------------
		//Load content from vo embed in code
		editDoc.loadFromCodeSaveVO=function(vo){
			let ret;
			this.muteNotify();
			ret=EditObj.prototype.loadFromVO.call(this,vo);
			this.unmuteNotify();
			if(this.dataDoc){
				this.dataDoc.on("Blured",()=>{this.OnDocBlur && this.OnDocBlur();});
			}
			return ret;
		};

		//--------------------------------------------------------------------
		//Gen content-vo to embed in code:
		editDoc.genCodeSaveVO=function(){
			return EditObj.prototype.genSaveVO.call(this);
		};

		//--------------------------------------------------------------------
		//Load doc content with DataDoc:
		editDoc.loadDoc=async function(){
			let self,isNewDoc;
			let prj,dataPrj,dataDocs,dataDoc,selfProxy,docText,codyVO,path,prjPath;
			//console.log(`Load edit doc: ${this.path}`);
			self=this;
			selfProxy=this.selfProxy;
			prj=this.prj;
			dataPrj=prj.dataPrj;
			dataDocs=prj.dataDocs;
			path=selfProxy.path;
			//console.log(`Load doc: ${path}`);
			if(path.startsWith(dataPrj.path)){
				prjPath=path.substring(dataPrj.path.length+1);
			}
			dataDoc=await dataDocs.loadDoc(path);
			if(!dataDoc){
				isNewDoc=1;
				dataDoc=await dataDocs.newDoc(path,true);//Load it in slient mode:
				if(!dataDoc){
					return false;//File is not exist.
				}
			}
			this.dataDoc=dataDoc;
			dataDoc.codyDoc=this;
			dataDoc.stayInMem=true;//Make sure the doc won't be released when close tab.
			dataDoc.on("UpdateDoc",(willSave)=>{
				if(willSave){
					self.scanImports();
					self.updateDocText(false);
				}else{
					self.maybeUpdateDocText();
				}
			});
			dataDoc.onNotify("Saved",()=>{self.postSave()});
			//build imports when about save doc:
			dataDoc.on("AboutSave",()=>{
				dataDoc.saveText+="\n"+self.genSaveText();
			});
			dataDoc.on("AboutLoadModified",()=>{
				let docText,codyMark,pos;
				prj.emitNotify("DocModifiedOutSide");
				docText=dataDoc.saveText;//This is the text will be loaded:
				codyMark="\n\/\*\Cody Project Doc*/";
				pos=docText.indexOf(codyMark);
				if(pos<0){
					console.warn(`Doc ${selfProxy.path} has no Cody mark`);
					return false;
				}
				dataDoc.saveText=docText.substring(0,pos);
			});
			dataDoc.getSaveAsText=this.getSaveAsText.bind(this);
			if(isNewDoc){
				docText=self.updateDocText();
				docText+="\n"+self.genSaveText();
			}else{
				docText=dataDoc.getDocText();
			}
			let fileExt=dataDoc.fileExt;
			//Locate doc mark and read saved VO:
			if(fileExt===".js"||fileExt===".mjs"){
				let pos,pos2,codeText,codyMark,codyText,editText;
				codyMark="\n\/\*\Cody Project Doc*/";
				pos=docText.indexOf(codyMark);
				if(pos<0){
					console.warn(`Doc ${selfProxy.path} has no Cody mark`);
					return false;
				}
				editText=docText.substring(0,pos);
				pos+=codyMark.length;
				codyText=docText.substring(pos);
				codyText=codyText.replaceAll("\n//","\n");
				let segMark1="\/\*\#{Doc*/";
				let segMark2="/*Doc\}\#\*\/";
				pos=codyText.indexOf(segMark1);
				if(pos>0){
					pos2=codyText.lastIndexOf(segMark2);
					if(pos2>0){
						codyText=codyText.substring(pos+segMark1.length,pos2);
					}else{
						console.error(`Doc ${selfProxy.path}'s cody mark "/*Doc}#*/" missing`);
						throw new Error(`Doc ${selfProxy.path}'s cody mark "/*Doc}#*/" missing`);
					}
				}
				try{
					codyVO=JSON.parse(codyText);
				}catch(err){
					console.error(err);
					codyVO=null;
				}
				dataDoc.setDocText(editText);
			}else if(fileExt===".py"){
				let pos,pos2,codeText,codyMark,codyText,editText;
				codyMark="\n#Cody Project Doc\n";
				pos=docText.indexOf(codyMark);
				if(pos<0){
					console.warn(`Doc ${selfProxy.path} has no Cody mark`);
					return false;
				}
				editText=docText.substring(0,pos);
				pos+=codyMark.length-1;//Keep last \n
				codyText=docText.substring(pos);
				codyText=codyText.replaceAll("\n#","\n");
				try{
					codyVO=JSON.parse(codyText);
				}catch(err){
					console.error(err);
					codyVO=null;
				}
				dataDoc.setDocText(editText);
			}
			if(!codyVO){
				console.error(`Doc ${path}'s CodyVO parse failed.`);
				throw new Error(`Doc ${path}'s CodyVO parse failed.`);
			}
			this.loadFromCodeSaveVO(codyVO);
			this.prj.liveDocs[path]=this;
			return true;
		};

		//--------------------------------------------------------------------
		editDoc.maybeUpdateDocText=function(undo=true){
			let dataDoc,editor;
			dataDoc=this.dataDoc;
			editor=dataDoc.editBox;
			if(editor){
				if(editor.maybeUpdateCode && (editor.maybeUpdateCode()===false)){
					return;
				}
				this.updateDocText(undo);
				if(this.gotoMarkAfterUpdateDoc!==null){
					editor.gotoLine(this.gotoMarkAfterUpdateDoc);
					this.gotoMarkAfterUpdateDoc=null;
				}
			}else{
				this.updateDocText(undo);
			}
		};

		//--------------------------------------------------------------------
		editDoc.genSaveText=function(){
			let saveVO,saveVOText,pretty,fileExt;
			fileExt=this.dataDoc.fileExt;
			pretty=this.getAttrVal("prettySaveVO")||this.prj.prettySaveVO;
			saveVO=this.genCodeSaveVO();
			if(fileExt===".py"){
				if(pretty){
					saveVOText="#Cody Project Doc\n"+JSON.stringify(saveVO,null,"\t");
				}else{
					saveVOText="#Cody Project Doc*/\n"+JSON.stringify(saveVO);
				}
				saveVOText=saveVOText.replaceAll("\n","\n#");
			}else{
				if(pretty){
					saveVOText="\/\*\Cody Project Doc*/\n"+JSON.stringify(saveVO,null,"\t");
				}else{
					saveVOText="\/\*\Cody Project Doc*/\n"+JSON.stringify(saveVO);
				}
				saveVOText=saveVOText.replaceAll("\n","\n//");
			}
			return saveVOText;
		};
		
		//--------------------------------------------------------------------
		editDoc.updateDocText=function(undo=true){
			let genText,text,saveVO,saveVOText,dataDoc,docText;
			genText=this.genExportText();
			dataDoc=this.dataDoc;
			if(!dataDoc){
				return genText;
			}
			if(genText===this.lastGenCode){
				return ;
			}
			docText=dataDoc.getDocText();
			text=mergeCodeWithSeg(genText,docText,this.missingCodeSegs,dataDoc.fileExt===".py");
			dataDoc.setDocText(text,undo);
			this.lastGenCode=genText;
			return text;
		};
		
		//--------------------------------------------------------------------
		editDoc.genExportText=function(){
			let exporterFunc,exporter,text,saveVO,saveVOText;
			exporterFunc=this.objDef.exporter;
			if(typeof(exporterFunc)==="string"){
				let name=exporterFunc;
				exporterFunc=EditDocExporter.getExporter(name);
				if(!exporterFunc){
					console.error("Can't find exporter: "+name);
					return "";
				}
			}
			exporter=new exporterFunc(this.prj);
			text=exporter.export(this,{});
			return text;
		};
		
		//--------------------------------------------------------------------
		editDoc.getExporter=function(codeName){
			return EditDocExporter.getExporter(codeName);
		};
		
		//--------------------------------------------------------------------
		editDoc.postSave=async function(){
			let path,dirPath,baseName,ext,libJSPath,code;
			if(!this.genLibJS){
				return;
			}
			if(this.exposeGear && this.exposeGear.val){
				let exporterFunc,exporter;				
				exporterFunc=EditDocExporter.getExporter("LibJS");
				if(!exporterFunc){
					console.error("Can't find exporter: LibJS");
					code="";
				}
				exporter=new exporterFunc(this.prj);
				code=exporter.export(this,{fixExt:true});
				
				path=this.path;
				dirPath=pathLib.dirname(path);
				baseName=pathLib.basename(path);
				ext=pathLib.extname(path);
				if(ext!==".js"){
					baseName=baseName.substring(0,baseName.length-ext.length)+".js";
				}
				libJSPath=pathLib.join(dirPath,"lib",baseName);
				code=code.replaceAll(`} from "../`,`} from "../../`);
				await tabFS.writeFile(libJSPath,code,"utf8");
			}
		};

		//--------------------------------------------------------------------
		editDoc.saveDoc=async function(){
			if(this.dataDoc){
				return await this.dataDoc.saveDoc();
			}
		};
		
		//--------------------------------------------------------------------
		editDoc.getSaveAsText=function(path){
			let orgPath,orgName,orgJaxId,baseName,newName,newJaxId,pos;
			let code,editObjs,editObj;
			orgPath=this.path;
			orgName=this.name;
			orgJaxId=this.jaxId;
			
			baseName=pathLib.basename(path);
			pos=baseName.lastIndexOf(".");
			if(pos>0){
				newName=baseName.substring(0,pos);
			}else{
				newName=baseName;
			}
			newJaxId=EditObj.genObjId();
			
			this.setAttrByText("path",path);
			this.name=newName;
			editObjs=this.attrHash.editObjs;
			if(editObjs){
				editObj=this.attrHash.editObjs.attrList[0];
				if(editObj){
					editObj.name=newName;
				}
			}

			
			try{
				let genText,docText,dataDoc;
				dataDoc=this.dataDoc;
				genText=this.genExportText();
				docText=this.getDocText();
				//Merge codesegs:
				code=mergeCodeWithSeg(genText,docText,this.missingCodeSegs,dataDoc.fileExt===".py");
				//Append project info:
				code+="\n"+this.genSaveText();
			}catch(err){
				this.name=orgName;
				this.setAttrByText("path",orgPath);
				if(editObj){
					editObj.name=orgName;
				}
				throw err;						
			}
			code=code.replaceAll(orgJaxId,newJaxId);
			this.name=orgName;
			editObj.name=orgName;
			this.setAttrByText("path",orgPath);
			return code;
		};
		
		//--------------------------------------------------------------------
		editDoc.getDocText=function(){
			return this.dataDoc?this.dataDoc.getDocText():"";
		};
		
		//--------------------------------------------------------------------
		editDoc.mergeTextBlock=function(textBlock,undo){
			let genText,text,saveVO,saveVOText,dataDoc,docText;
			genText=this.genExportText();
			dataDoc=this.dataDoc;
			if(!dataDoc){
				return genText;
			}
			docText=dataDoc.getDocText();
			text=mergeCodeWithSeg(genText,docText,this.missingCodeSegs,dataDoc.fileExt===".py");
			text=mergeCodeWithSeg(docText,textBlock,this.missingCodeSegs,dataDoc.fileExt===".py");
			dataDoc.setDocText(text,undo);
			this.lastGenCode=genText;
			return text;
		};
	}
	
	//************************************************************************
	//Editor ui-interactive:
	//************************************************************************
	{
		editDoc.getName=function(){
			let path;
			if(this.def.showName){
				return this.def.showName;
			}
			path=this.getAttr("path").val;
			if(path){
				return pathLib.basename(path);
			}
			return this.name;
		};
	}
	
	//************************************************************************
	//Localize related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Get all localizable objects in this doc for translate/list item.
		editDoc.getLocalizableObjs=function(){
			return [];
		};
	}
	
	//------------------------------------------------------------------------
	editDoc.OnDocFocus=function(){
		//Do nothing in generic document.
	};
}

export {EditDoc,EditDocDef};