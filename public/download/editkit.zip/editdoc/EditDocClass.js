import {EditDoc,EditDocDef} from "./EditDoc.js";
import {} from "../EditClass.js";
import pathLib from "/@path";

var ObjDataClassDef={
};

var DocDataClassDef={
	name:"DataDoc",
	icon:"file.svg",allowExtraAttr:0,navi:"prj",edit:false,
	exporter:"DataClass",
	attrs:{
		...EditDocDef.attrs,
		"editObjs":{
			name:"editObjs",type:"object",icon:"array.svg",key:1,fixed:1,edit:false,navi:"doc",
			def:{
				attrs:{},allowExtraAttr:1,attrType:"objclass",attrTypeDef:"ObjClass",
			},
			getName:(obj)=>{
				let path;
				path=obj.owner.selfProxy.path;
				return pathLib.basename(path);
			},
		}
	},
	OnCreate(){
		let localVars,editObjs;
		this.localVars=localVars=this.getAttr("localVars");
		this.editObjs=editObjs=this.getAttr("editObjs");
		if(localVars && editObjs){
			this.scopeObj={};
			this.setScopeObj("localVars",localVars,true);
			this.localVars.onNotify("Changed",()=>{
				this.buildScopeEnv();
				editObjs.updateHyperAttrs();
			});
		}
		//Init scope:
		let appCfg;
		this.scopeObj={};
		appCfg=this.prj.objConfig;
		this.setScopeObj("appCfg",appCfg,false);
		this.setScopeObj("$ln",appCfg.getAttr("lanCode"),false);
	},
	objAttrs:{
		naviState:{},
		getEditRootPpts:function(){
			return null;
		},
		getNaviDocRoot:function(){
			return this.getAttr("editObjs");
		},
		scanImports:function(){
			let attrList,attr;
			this.imports={};
			this.addImportObj("appCfg",this.prj.path+"/cfg/appCfg.js");
			attrList=this.attrList;
			for(attr of attrList){
				if(attr.attrList){
					this.scanObjImports(attr);
				}
			}
		},
		naviDocReady:function(){
			let naviBox,treeBox,state,obj;
			state=this.naviState;
			naviBox=this.prj.getBoxNaviDoc();
			if(naviBox){
				let selected,obj,node;
				obj=state.hotItem;
				if(obj){
					this.prj.setEditSubObj(obj);
				}
			}
		},
		OnDocBlur:function(){
			let naviBox,treeBox,state,obj;
			state=this.naviState;
			naviBox=this.prj.getBoxNaviDoc();
			if(naviBox){
				let node;
				treeBox=naviBox.treeBox;
				node=treeBox.hotNode;
				state.hotItem=node?node.nodeObj:null;
			}
		}
	}
};
EditDoc.regDocDef("DataDoc",DocDataClassDef);