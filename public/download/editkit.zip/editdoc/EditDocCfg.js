import {VFACT} from "/@vfact";
import pathLib from "/@path";
import {EditDoc,EditDocDef} from "./EditDoc.js";
const $ln=VFACT.lanCode;
var DocAppCfgDef={
	name:"appCfg",
	icon:"config.svg",allowExtraAttr:0,
	exporter:"DocCfg",
	attrs:{
		"localVars":{
			name:"localVars",showName:(($ln==="CN")?("局部变量"):/*EN*/("Local variables")),type:"object",icon:"object.svg",key:1,fixed:1,navi:false,
			def:{
				allowExtraAttr:true,
				attrs:{
					darkMode:{name:"darkMode",showName:(($ln==="CN")?("暗夜模式"):/*EN*/("Dark Mode")),type:"bool",key:1,fixed:1,initVal:false},
				}
			}
		},
		...EditDocDef.attrs,
		"editObjs":{
			name:"editObjs",type:"object",icon:"array.svg",key:1,fixed:1,edit:false,navi:"doc",
			def:{
				attrs:{
					"appCfg":{
						name:"appCfg",showName:(($ln==="CN")?("App配置"):/*EN*/("App Config")),icon:"config.svg",type:"object",key:1,fixed:1,edit:true,navi:"doc",
						def:{
							allowExtraAttr:1,icon:"config.svg",
							attrs:{
								darkMode:{name:"darkMode",showName:(($ln==="CN")?("暗夜模式"):/*EN*/("Dark Mode")),type:"bool",key:1,fixed:1,initValText:"#darkMode",edit:false},
								"version":{name:"version",showName:(($ln==="CN")?("版本"):/*EN*/("Version")),type:"string",initVal:"0.0.1",fixed:1,key:1,edit:true,navi:false},
								"txtSize":{
									name:"txtSize",showName:(($ln==="CN")?("字体大小"):/*EN*/("Font Size")),type:"object",fixed:1,key:1,edit:true,navi:false,
									attrs:{
										"small":{name:"small",type:"int",initVal:12,fixed:1,key:1,edit:1,navi:false},
										"mid":{name:"mid",type:"int",initVal:16,fixed:1,key:1,edit:1,navi:false},
										"big":{name:"big",type:"int",initVal:20,fixed:1,key:1,edit:1,navi:false},
									}
								},
								"size":{name:"size",showName:(($ln==="CN")?("预设尺寸"):/*EN*/("Preset Sizes")),type:"object",fixed:1,key:1,edit:true,navi:false},
								"color":{
									name:"color",showName:(($ln==="CN")?("预设颜色"):/*EN*/("Preset Colors")),type:"object",fixed:1,key:1,edit:true,navi:false,
									//TODO: Add window, text, color
								}
							}
						}
					}
				}
			},
			getName:(obj)=>{
				let path;
				path=obj.owner.selfProxy.path;
				return pathLib.basename(path);
			},
		},
	},
	OnCreate(){
		let localVars,editObjs,cfgObj;
		this.localVars=localVars=this.getAttr("localVars");
		this.editObjs=editObjs=this.getAttr("editObjs");
		this.configObj=cfgObj=editObjs.getAttr("appCfg");
		if(localVars && editObjs){
			this.scopeObj={};
			this.setScopeObj("localVars",localVars,true);
			this.localVars.onNotify("Changed",()=>{
				this.buildScopeEnv();
				editObjs.updateHyperAttrs();
				cfgObj.emitObjChange();
			});
		}
	},
	objAttrs:{
		OnLanguageChange:function(){
			this.emitNotify("UpdateCode");
		},
		getNaviSubList:function(mode){
			if(mode==="doc"){
				return null;//[this.getAttr("editObjs").getAttr("appCfg")];
			}
			return null;
		},
		getEditRootPpts:function(){
			return [
				{attr:this.prj.docApp.attrLocalize},
				{attr:this.prj.docApp.attrLanguage},
				{obj:this.getAttr("localVars"),open:true},
				{obj:this.getAttr("editObjs").getAttr("appCfg"),open:true}
			];
		}
	}
};
EditDoc.regDocDef("AppCfg",DocAppCfgDef);