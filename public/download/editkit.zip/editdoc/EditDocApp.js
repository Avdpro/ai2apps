import {tabFS} from "/@tabos";
import pathLib from "/@path";
import {EditDoc,EditDocDef} from "./EditDoc.js";
import {mergeCodeWithSeg} from "../exporters/codesegs.js";
import {} from "../edithud/EditHudFont.js";//Ensure Font type register.
import {VFACT} from "/@vfact";

const $ln=VFACT.lanCode;
var DocAppDef={
	name:"app",
	icon:"app.svg",allowExtraAttr:0,
	exporter:"DocApp",
	attrs:{
		"path":EditDocDef.attrs.path,
		"fonts":{
			name:"fonts",showName:(($ln==="CN")?("字体"):/*EN*/("Fonts")),type:"object",def:"Fonts",key:1,fixed:1,edit:false,navi:"prj",
			objAttrs:{
				getEditRootPpts:function(){
					return [
						{obj:this,open:true}
					];
				}
			}
		},
		"exportTarget":{
			name:"exportTarget",showName:(($ln==="CN")?("导出目标"):/*EN*/("Export target")),type:"choice",initVal:"vfact",key:1,fixed:1,edit:false,rawEdit:false,
			vals:[
				["vfact","VFACT document"],
				["react","React document"],
				["vue","VUE document"],
				["nxt","Nxt document"],
			]
		},
		"localize":{
			name:"localize",showName:(($ln==="CN")?("多语言集"):/*EN*/("Localize")),type:"array",def:"StringArray",key:1,fixed:1,save:true,initAttrVOs:[{type:"string",valText:"EN"}],icon:"web.svg"
		},
		"language":{
			name:"language",showName:(($ln==="CN")?("语言"):/*EN*/("Language")),type:"string",key:1,fixed:1,save:true,initVal:"EN",icon:"language.svg",hyperEdit:false,editType:"language",rawEdit:false,
		},
		"inlinePreloads":{name:"inlinePreloads",showName:(($ln==="CN")?("内联预加载"):/*EN*/("Inline Preloads")),type:"bool",initVal:true,key:0,fixed:0},
		"useTabOS":{name:"useTabOS",showName:"Tab-OS App",type:"bool",initVal:false,key:1,fixed:1},
		"title":{name:"title",showName:(($ln==="CN")?("标题"):/*EN*/("Title")),type:"string",initVal:"Tab-OS App",key:1,fixed:1},
		"bgColor":{name:"bgColor",showName:(($ln==="CN")?("背景"):/*EN*/("Background")),type:"colorRGB",initVal:[255,255,255],key:1,fixed:1},
		"icon":{name:"icon",showName:(($ln==="CN")?("App图标"):/*EN*/("App Icon")),type:"file",initVal:undefined,key:1,fixed:1},
		"fullScreen":{name:"fullScreen",showName:(($ln==="CN")?("全屏"):/*EN*/("Full Screen")),type:"bool",initVal:false,key:1,fixed:1},
		"multiTouch":{name:"multiTouch",showName:(($ln==="CN")?("多点触控"):/*EN*/("Multi touch")),type:"bool",initVal:false,key:1,fixed:1},
		"location":{name:"location",showName:(($ln==="CN")?("地点位置"):/*EN*/("Location")),type:"bool",initVal:false,key:1,fixed:1},
		"camera":{name:"camera",showName:(($ln==="CN")?("使用相机"):/*EN*/("Use Camera")),type:"bool",initVal:false,key:1,fixed:1},
		"photo":{name:"photo",showName:(($ln==="CN")?("访问相册"):/*EN*/("Photo Album")),type:"bool",initVal:false,key:1,fixed:1},
		"notification":{name:"notification",showName:(($ln==="CN")?("使用通知"):/*EN*/("Use Notification")),type:"bool",initVal:false,key:1,fixed:1},
		"contacts":{name:"contacts",showName:(($ln==="CN")?("访问通讯录"):/*EN*/("Access Contacts")),type:"bool",initVal:false,key:1,fixed:1},
		"payment":{name:"payment",showName:(($ln==="CN")?("付款"):/*EN*/("Payment")),type:"bool",initVal:false,key:1,fixed:1},
	},
	listHint:[
		"title","bgColor","icon","useTabOS","language","localize",
		{name:"capability",showName:(($ln==="CN")?("系统能力"):/*EN*/("Capabilities")),attrs:["fullScreen","multiTouch","location","photo","camera","notification","contacts","payment"],open:0},
	],	
	getName:(obj)=>{
		return "app.js";
	},
	OnCreate:function(){
		let localVars,editObjs;
		let attr;

		this.localVars=localVars=this.getAttr("localVars");
		this.editObjs=editObjs=this.getAttr("editObjs");
		if(localVars && editObjs){
			this.scopeObj={};
			this.setScopeObj("localVars",localVars,true);
			this.localVars.onNotify("Changed",()=>{
				this.buildScopeEnv();
				editObjs.updateHyperAttrs();
			});
		}

		attr=this.attrLocalize=this.getAttr("localize");
		if(!attr.attrList.length){
			attr.addAttr({type:"string",fixed:true,key:true});
			attr.setAttrByText(0,"EN");
		}else{
			if(!attr.getAttrVal(0)){
				attr.setAttrByText(0,"EN");
			}
		}
		attr.traceOn(()=>{
			if(this.doc && this.doc.dataDoc && this.doc.dataDoc.saveDoc){
				this.doc.dataDoc.saveDoc();
			}
		});
		attr=this.attrLanguage=this.getAttr("language");
		attr.traceOn(()=>{
			let prj=this.prj;
			prj.curLanguage=attr.val;
			prj.emit("Language",attr.val);
		});
		this.prj.curLanguage=attr.val;
	},
	objAttrs:{
		getNaviSubList:function(mode){
			if(mode==="doc"){
				return [this.getAttr("fonts")];
			}
			return [];
		},
		getEditRootPpts:function(){
			return [
				{obj:this,open:true},
				{obj:this.getAttr("fonts"),open:true}
			];
		},
		postSave:async function(){
			let exporterFunc,code,orgCode,exporter;
			let path,dirPath,baseName,htmlPath;
			//Export HTML:
			exporterFunc=this.getExporter("HTML");
			if(!exporterFunc){
				console.error("Can't find exporter: HTML");
				code="";
				return;
			}
			exporter=new exporterFunc(this.prj);
			code=exporter.export(this,{});
		
			path=this.path;
			dirPath=pathLib.dirname(path);
			baseName=pathLib.basename(path);
			htmlPath=pathLib.join(dirPath,"app.html");
			//Load and merge codes:
			try{
				orgCode=await tabFS.readFile(htmlPath,"utf8");
			}catch(err){
				orgCode=null;
			}
			if(orgCode){
				code=mergeCodeWithSeg(code,orgCode,null);
			}
			await tabFS.writeFile(htmlPath,code,"utf8");
		}
	}
};
EditDoc.regDocDef("App",DocAppDef);
export {DocAppDef};