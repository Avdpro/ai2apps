import inherits from "/@inherits";
import {makeObjEventEmitter} from "/@events";
import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";

const DefMockState={
	name:"MockState",icon:"class.svg",allowExtraAttr:false,
	attrs:{
		"createArgs":{
			name:"createArgs",type:"object",def:"Object",
			key:1,fixed:1,edit:false,navi:0,
		},
		"stateObj":{
			name:"stateObj",type:"object",def:"Object",
			key:1,fixed:1,edit:false,navi:0,
		},
	}
};

var EditMockupState,editMockupState;
//****************************************************************************
//Face tag in HudGearDoc:
EditMockupState=function(owner,def,init){
	let self,doc,docCreateArgs,docStateObj,saveVO;
	EditObj.call(this,owner,def,true);
	self=this;
	this.icon="class.svg";
	doc=this.doc;
	docCreateArgs=doc.createArgs;
	docStateObj=doc.stateObj;
	this.createArgs=this.getAttr("createArgs");
	this.stateObj=this.getAttr("stateObj");
	this.editOnAdd=false;
	this.isMockupState=true;
	if(init){
		saveVO=docCreateArgs.genSaveVO();
		this.createArgs.loadFromVO(saveVO);
		saveVO=docStateObj.genSaveVO();
		this.stateObj.loadFromVO(saveVO);
	}
};
inherits(EditMockupState,EditObj);
editMockupState=EditMockupState.prototype;
EditAttr.regAttrType("mockState",EditMockupState);
EditMockupState.getDef=function(){
	return DefMockState;
};

//----------------------------------------------------------------------------
editMockupState.applyMockup=function(){
	let doc,docCreateArgs,docStateObj,saveVO;
	function apply(objFrm,objTo){
		let srcList,tgtHash,i,n,srcAttr,tgtAttr,attrName;
		srcList=objFrm.attrList;
		tgtHash=objTo.attrHash;
		n=srcList.length;
		for(i=0;i<n;i++){
			srcAttr=srcList[i];
			attrName=srcAttr.name;
			tgtAttr=tgtHash[attrName];
			if(!tgtAttr || tgtAttr.type!==srcAttr.type){
				continue;
			}
			if(srcAttr instanceof EditObj){
				apply(srcAttr,tgtAttr);
			}else{
				//Better this way, can including localiztion info.
				tgtAttr.loadFromVO(srcAttr.genSaveVO());
			}
		}
	}
	doc=this.doc;
	docCreateArgs=doc.createArgs;
	docStateObj=doc.stateObj;
	//Apply createArg
	docCreateArgs.muteNotify();
	docCreateArgs.muteEmit();
	apply(this.createArgs,docCreateArgs);
	docCreateArgs.unmuteEmit();
	docCreateArgs.unmuteNotify();
	//Apply stateObj:
	docStateObj.muteNotify();
	docStateObj.muteEmit();
	apply(this.stateObj,docStateObj);
	docStateObj.unmuteEmit();
	docStateObj.unmuteNotify();
};

export default EditMockupState;
export {EditMockupState};
