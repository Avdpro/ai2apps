import {tabFS} from "/@tabos";
import pathLib from "/@path";
import terser from "/@terser/cokemake-plugin.js";
import terserRorllup from "/@terser/rollup-plugin.js";
//----------------------------------------------------------------------------
//Make dev with HRM:
let dist={
	steps:[
		{
			action:"clean",
			dirs:["dist"]
		},
		{
			action:"copy",
			files:{
				"/editkit/disk.json":"dist/"
			},
		},
		{
			action:"clean",
			dirs:["/editkit"]
		},
		/*{
			action:"rollup",
			config:{
				input:["./EditAddOn.js","./EditAIAddOn.js","./EditAIPythonAddOn.js","./EditBackEndAddOn.js","./ReactAddOn.js","./DlgChooseSeg.js","./DlgNewClass.js"],
				external:[/\/@/],
				output:{
					format:"es",
					exportDir:"dist",
				},
				plugins:[
					terserRorllup()
				]
			}
		},*/
		{
			action:"copy",
			dirs:{
				".":"/editkit",
				"dist":"/editkit",
			},
			copy:async function(srcPath,dstPath,vo){
				let ext;
				ext=pathLib.extname(srcPath);
				if(ext===".js"){
					let text,pos;
					text=await tabFS.readFile(srcPath,"utf8");
					try{
						pos=text.lastIndexOf("\/\*Cody Project Doc\*\/");
						if(pos>0){
							text=text.substring(0,pos);
						}
						//text=await terser(text,null);
						await tabFS.writeFile(dstPath,text,"utf8");
					}catch(err){
						return false;
					}
					return true;
				}
				return false;
			}
		},
		/*
		{
			action:"copy",
			dirs:{
				"dist":"/editkit",
				"ai":"/editkit/ai",
				"cfg":"/editkit/cfg",
				"assets":"/editkit/assets",
				"docs":"/editkit/docs",
			},
			files:{
				"exporters/PackPreview.js":"/editkit/exporters/",
				"license.txt":"/editkit/",
			}
		},*/
		{
			action:"clean",
			dirs:["dist"]
		},
		/*
		{
			action:"copy",
			dirs:{
				"cfg":"/editkit/cfg",
				"docs":"/editkit/docs",
				"editdoc":"/editkit/editdoc",
				"edithud":"/editkit/edithud",
				"exporters":"/editkit/exporters",
				"forge":"/editkit/forge",
				"text":"/editkit/text",
			},
			files:{
				"EditAddOn.js":"/editkit/",
				"EditArray.js":"/editkit/",
				"EditAttr.js":"/editkit/",
				"EditClass.js":"/editkit/",
				"EditFunction.js":"/editkit/",
				"EditObj.js":"/editkit/",
				"EditPrj.js":"/editkit/",
				"ReactAddOn.js":"/editkit/",
				"dist/disk.json":"/editkit/",
			}
		},
		{
			action:"copy",
			dirs:{
				"ui":"/editkit/ui",
			},
			copy:async function(srcPath,dstPath,vo){
				let ext;
				ext=pathLib.extname(srcPath);
				if(ext===".js"){
					let text,pos;
					text=await tabFS.readFile(srcPath,"utf8");
					try{
						pos=text.lastIndexOf("\/\*Cody Project Doc\*\/");
						if(pos>0){
							text=text.substring(0,pos);
						}
						text=await terser(text,null);
						await tabFS.writeFile(dstPath,text,"utf8");
					}catch(err){
						return false;
					}
					return true;
				}
				return false;
			}
		},*/
	],
	options:{
	}
};
export default dist;
export {dist};

