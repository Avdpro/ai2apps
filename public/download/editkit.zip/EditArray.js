import {EditAttr} from "./EditAttr.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {EditObjProxy} from "./EditObj.js";
import inherits from "/@inherits";

//****************************************************************************
//:Edit attrs Array;
//****************************************************************************
let EditAttrArray,editAttrArray;
{
	EditAttrArray=function(owner,elementType,listName){
		this.owner=owner;
		this.elementType=elementType||{type:"auto"};
		this.listName=listName||"Array";
		this.attrList=[];
	};
	editAttrArray=EditAttrArray.prototype={};
	
	editAttrArray.initArrayAttrs=function(){
		let attrVOs,i,n,attr,attrList;
		attrVOs=this.owner.objDef.initAttrVOs||this.owner.objDef.attrs;
		if(!attrVOs){
			return;//No default
		}
		if(this.attrList.length>0){
			return;//Array already has contents
		}
		attrList=this.attrList;
		n=attrVOs.length;
		for(i=0;i<n;i++){
			attr=EditAttr.loadFromVO(this.owner,attrVOs[i],i);
			if(attr){
				attr.name=attr.def.name=attrList.length;
				attrList.push(attr);
			}
		}
	};
	
	//************************************************************************
	//:Attr access:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAttrArray.getelementType=function(){
			return this.elementType;
		};

		//--------------------------------------------------------------------
		editAttrArray.getAttr=function(index){
			return this.attrList[index];
		};

		//--------------------------------------------------------------------
		editAttrArray.getAttrVal=function(index){
			let attr=this.attrList[index];
			if(!attr){
				return undefined;
			}
			return attr.val;
		};

		//--------------------------------------------------------------------
		editAttrArray.getAttrValText=function(index){
			let attr=this.attrList[index];
			if(!attr){
				return undefined;
			}
			return attr.valText;
		};

		//--------------------------------------------------------------------
		editAttrArray.setAttrByText=function(index,valText,create=false){
			let attr;
			if(index instanceof EditAttr){
				attr=index;
			}else{
				attr=this.attrList[index];
			}
			if(!attr){
				if(!create){
					throw new Error(`Attr index: ${index} not exist for set.`);
				}
				attr=this.addAttrByDef(null);
			}
			attr.setValByText(valText);
			this.owner.emit(this.listName+"Changed",attr);
			this.owner.emitChanged();
		};
		
		//--------------------------------------------------------------------
		editAttrArray.getAttrByIdx=function(attrIdx){
			return this.attrList[attrIdx];
		};

		//--------------------------------------------------------------------
		editAttrArray.getAttrIdx=function(attr){
			let list,i,n;
			list=this.attrList;
			n=list.length;
			for(i=0;i<n;i++){
				if(list[i]===attr){
					return i;
				}
			}
			return -1;
		};

		//--------------------------------------------------------------------
		editAttrArray.addAttrItem=function(attr){
			let idx;
			if(attr.owner!==this.owner){
				throw new Error("addAttrItem invalid attr owner");
			}
			idx=this.attrList.length;
			attr.name=idx;
			attr.def.name=idx;
			this.attrList.push(attr);
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged();
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrArray.addAttrByDef=function(attrDef){
			let attr,idx;
			idx=this.attrList.length;
			attrDef=attrDef||this.elementType;
			if(typeof(attrDef)==="string"){
				attrDef={type:attrDef,extraAttr:true};
			}else{
				attrDef={...attrDef};
			}
			attrDef.name=idx;
			attr=EditAttr.newAttr(this.owner,attrDef,true);
			this.attrList.push(attr);
			this.owner.emit(this.listName+"Add",attr,idx);
			this.owner.emitChanged();
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrArray.addAttrBySaveVO=function(saveVO){
			let attr,idx;
			idx=this.attrList.length;
			attr=EditAttr.loadFromVO(this.owner,saveVO,name);
			attr.def.name=idx;
			this.attrList.push(attr);
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged();
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrArray.removeAttr=function(index){
			let attrList,attr,attrDef;
			attrList=this.attrList;
			if(index instanceof EditAttr){
				index=this.getAttrIdx(index);
			}
			if(index>attrList.length || index<0 || !attrList[index]){
				throw new Error(`Attr index: ${index} not exist for remove`);
			}
			attr=attrList[index];
			if(!attr){
				return false;
			}
			attrDef=attr.def;
			attrList.splice(index,1);
			//attr.release();
			for(let i=index,n=attrList.length;i<n;i++){
				attrList[i].name=i;
				attrList[i].def.name=i;
				attrList[i].emitAttrChange();
			}
			this.owner.emit(this.listName+"Remove",attr,index);
			this.owner.emitChanged();
			return true;
		};

		//--------------------------------------------------------------------
		editAttrArray.insertAttrAt=function(attrObj,idx){
			var attrList;
			attrList=this.attrList;
			if(idx>=0 && idx<attrList.length){
				attrList.splice(idx,0,attrObj);
			}else{
				attrList.push(attrObj);
			}
			for(let i=idx,n=attrList.length;i<n;i++){
				attrList[i].name=i;
				attrList[i].def.name=i;
				attrList[i].emitAttrChange();
			}
			this.owner.emit(this.listName+"Insert",attrObj,idx);
			this.owner.emitChanged();
		};

		//--------------------------------------------------------------------
		editAttrArray.attrCanMoveUp=function(idx){
			let attrList,preAttr,attr;
			attrList=this.attrList;
			if(idx<=0){
				return false;
			}
			attr=attrList[idx];
			preAttr=attrList[idx-1];
			if(attr && preAttr){
				return true;
			}
			return false;
		};

		//--------------------------------------------------------------------
		editAttrArray.attrCanMoveDown=function(idx){
			let attrList,attr,nextAttr;
			attrList=this.attrList;
			if(idx instanceof EditAttr){
				idx=this.getAttrIdx(idx);
			}
			if(idx<0||idx>=attrList.length){
				return false;
			}
			attr=attrList[idx];
			nextAttr=attrList[idx+1];
			if(attr && nextAttr){
				return true;
			}
			return false;
		};

		//--------------------------------------------------------------------
		editAttrArray.moveUpAttr=function(idx){
			let attrList,preAttr,attr;
			attrList=this.attrList;
			if(idx instanceof EditAttr){
				idx=this.getAttrIdx(idx);
			}
			if(idx<=0){
				return false;
			}
			attr=attrList[idx];
			preAttr=attrList[idx-1];
			this.attrList.splice(idx,1);
			this.attrList.splice(idx-1,0,attr);
			if(attr){
				attr.name=idx-1;attr.def.name=idx-1;
				attr.emitAttrChange();
			}
			if(preAttr){
				preAttr.name=idx;preAttr.def.name=idx;
				preAttr.emitAttrChange();
			}
			this.owner.emit(this.listName+"MoveUp",attr,idx-1);
			this.owner.emitChanged();
			return true;
		};

		//--------------------------------------------------------------------
		editAttrArray.moveDownAttr=function(idx){
			let attrList,attr,nextAttr;
			attrList=this.attrList;
			if(idx instanceof EditAttr){
				idx=this.getAttrIdx(idx);
			}
			if(idx<0||idx>=attrList.length-1){
				return false;
			}
			attr=attrList[idx];
			nextAttr=attrList[idx+1];
			this.attrList.splice(idx,1);
			this.attrList.splice(idx+1,0,attr);
			if(attr){
				attr.name=idx+1;attr.def.name=idx+1;
				attr.emitAttrChange();
			}
			if(nextAttr){
				nextAttr.name=idx;nextAttr.def.name=idx;
				nextAttr.emitAttrChange();
			}
			this.owner.emit(this.listName+"MoveDown",attr,idx+1);
			this.owner.emitChanged();
			return true;
		};
	}

	//************************************************************************
	//I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAttrArray.genSaveVO=function(){
			let attrList,i,n,attr;
			let vo=[];
			attrList=this.attrList;
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				//Make sure name is correct:
				attr.def.name=i;
				attr.name=i;
				vo[i]=attr.genSaveVO();
			}
			return vo;
		};

		//--------------------------------------------------------------------
		editAttrArray.loadFromVO=function(voAttrs){
			let attr;
			let attrList,i,n;
			attrList=this.attrList;
			if(voAttrs.length>=0){
				attrList.splice(voAttrs.length);
			}
			if(attrList.length){
				n=voAttrs.length;
				for(i=0;i<n;i++){
					attr=attrList[i];
					if(attr){
						attr.loadFromVO(voAttrs[i]);
					}else{
						attr=EditAttr.loadFromVO(this.owner,voAttrs[i],i);
						attrList[i]=attr;
					}
					attr.name=attr.def.name=i;
				}
			}else{
				n=voAttrs.length;
				for(i=0;i<n;i++){
					attr=EditAttr.loadFromVO(this.owner,voAttrs[i],i);
					if(attr){
						attr.name=attr.def.name=attrList.length;
						attrList.push(attr);
					}
				}
			}
		};
	}
}

//****************************************************************************
//:Edit Array attr;
//****************************************************************************
let EditArray,editArray;
{
	//------------------------------------------------------------------------
	//Edit object-attr stub base:
	EditArray=function(owner,def,init){
		var self=this;
		let objDef;
		EditAttr.call(this,owner,def,false);
		this.isReady=false;
		makeObjEventEmitter(this);
		makeNotify(this);
		objDef=def.def||"Array";
		this.prj=owner?owner.prj:(this.prj||null);
		if(!objDef){
			console.error(`EditObjAttr: missing Object-Def.`);
			throw new Error(`EditObjAttr: missing Object-Def.`);
		}
		if(typeof(objDef)==="string"){
			objDef=EditArray.getDef(objDef);
			if(!objDef){
				console.error(`Object def: ${def.def} not found.`);
				throw new Error(`Object def: ${def.def} not found.`);
			}
		}
		this.objDef=objDef;
		this.attrs=new EditAttrArray(this,objDef.elementType,"Attr");
		this.attrList=this.attrs.attrList;
		//Coded properties:
		let objDoc;
		Object.defineProperty(this,'doc',{
			get:function(){
				if(objDoc===undefined){
					if(owner){
						return owner.doc;
					}
					return null;
				}
				return objDoc;
			},
			set:function(v){
				objDoc=v;
			},
			enumerable: true
		});
		let selfProxy;
		Object.defineProperty(this,'selfProxy',{
			get:function(){
				if(!selfProxy){
					selfProxy=new Proxy(new EditObjProxy(this),{
						get:function(tgt,key){
							var attr;
							if(key==="%EditObj"){
								return self;
							}
							if(key===Symbol.toPrimitive){
								return ()=>"{EditArrayAttr}";
							}
							if(key>=0){
								attr=self.attrs.getAttr(key);
								if(attr.selfProxy) {
									return attr.selfProxy;
								}else if(attr instanceof EditAttr){
									return attr.val;
								}
								if(attr===undefined){
									console.log("Can't find attr: ",key);
								}
							}
							if(key==="length"){
								return self.attrList.length;
							}
							return undefined;
						},
						set:function(tgt,key,val){
							throw new Error(`Can not set attrib "${key}" on EditObjProxy.`);
						}
					});
				}
				return selfProxy;
			},
			enumerable: true
		});
		Object.defineProperty(this,'attrList',{
			get:function(){
				return this.attrs.attrList;
			},
			enumerable: true
		});
		Object.defineProperty(this,'attrHash',{
			get:function(){
				return this.attrs.attrList;
			},
			enumerable: true
		});
		if(def.objAttrs){
			Object.assign(this,def.objAttrs);
		}
		if(objDef.objAttrs){
			Object.assign(this,objDef.objAttrs);
		}
		this.editAttrState={open:0};
		if(init){
			this.attrs.initArrayAttrs();
			this.objReady();
		}
	};
	inherits(EditArray,EditAttr);
	editArray=EditArray.prototype;
	EditAttr.regAttrType("array",EditArray);
	
	let arrayDefRegs={};
	//------------------------------------------------------------------------
	EditArray.regArrayDef=EditArray.regDef=function(name,def){
		arrayDefRegs[name]=def;
	};
	
	//------------------------------------------------------------------------
	EditArray.getDef=EditArray.getArrayDef=function(name){
		return arrayDefRegs[name];
	};
	
	//------------------------------------------------------------------------
	editArray.objReady=function(){
		if(this.isReady)
			return;
		if(this.objDef.OnCreate){
			this.objDef.OnCreate.call(this);
		}
		this.isReady=true;
	};
	
	//************************************************************************
	//Attr related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editArray.getAttr=function(index){
			return this.attrList[index];
		};

		//--------------------------------------------------------------------
		editArray.getAttrDef=function(name){
			return null;
		};

		
		//--------------------------------------------------------------------
		editArray.setAttrByText=function(attrName,text,create=false){
			return this.attrs.setAttrByText(attrName,text,create);
		};

		//--------------------------------------------------------------------
		editArray.getAttrIdx=function(attrName){
			return this.attrs.getAttrIdx(attrName);
		};
		
		//--------------------------------------------------------------------
		editArray.getAttrByIdx=function(idx){
			return this.attrs.getAttrByIdx(idx);
		};
		
		//--------------------------------------------------------------------
		editArray.addAttr=function(attrDef){
			if(attrDef instanceof EditAttr){
				return this.attrs.addAttrItem(attrDef);
			}
			if(!attrDef){
				let def;
				let elmtDef,elmtType;
				let objDef=this.objDef;
				def=this.def;
				elmtDef=objDef.elementDef||def.elementDef;
				elmtType=objDef.elementType||def.elementType;
				if(elmtType){
					attrDef={type:objDef.elementType,extraAttr:true};
					if(elmtDef){
						attrDef.def=elmtDef;
					}
				}else if(elmtDef){
					attrDef={...elmtDef};
				}else{
					attrDef={type:"auto",extraAttr:true};
				}
			}
			return this.attrs.addAttrByDef(attrDef);
		};
		
		//--------------------------------------------------------------------
		editArray.addAttrBySaveVO=function(attrName,saveVO){
			//attrName will be ignored:
			return this.attrs.addAttrBySaveVO(saveVO);
		};
		

		//--------------------------------------------------------------------
		editArray.insertAttr=function(attr,index){
			return this.attrs.insertAttrAt(attr,index);
		};

		//--------------------------------------------------------------------
		editArray.removeAttr=function(attrName){
			return this.attrs.removeAttr(attrName);
		};

		//--------------------------------------------------------------------
		editArray.moveUpAttr=function(attrName){
			return this.attrs.moveUpAttr(attrName);
		};

		//--------------------------------------------------------------------
		editArray.moveDownAttr=function(attrName){
			return this.attrs.moveDownAttr(attrName);
		};
		
		//--------------------------------------------------------------------
		editArray.cloneAttrToObj=function(tgtObj,defOpts,opts){
			let vo;
			vo=this.genSaveVO();
			tgtObj.addAttrBySaveVO(vo,this.name);
		};
		
		//--------------------------------------------------------------------
		editArray.clearArray=function(){
			let attr;
			attr=this.attrList[0];
			while(attr){
				this.removeAttr(0);
				attr=this.attrList[0];
			}
		};
	}
	
	//************************************************************************
	//I/O related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editArray.loadFromVO=function(voAttr){
			let voAttrs;
			this.muteNotify();
			voAttrs=voAttr.attrs;
			this.attrs.loadFromVO(voAttrs);
			this.unmuteNotify();
		};
		
		//--------------------------------------------------------------------
		editArray.genSaveVO=function(){
			let attrList;
			let vo={};
			
			{
				let exportType,orgDef;
				exportType=true;
				if(!this.def.extraAttr && this.owner){
					orgDef=this.owner.getAttrDef(this.name);
					if(orgDef && orgDef.key && this.def.type===orgDef.type){
						exportType=false;
					}
				}
				if(exportType){
					vo.type=this.def.type||"array";
					vo.def=this.objDef.name;
				}
			}
			//vo.type=this.def.type||"array";
			//vo.def=this.objDef.name;
			attrList=this.attrs;
			vo.attrs=attrList.genSaveVO();
			return vo;
		};

		//--------------------------------------------------------------------
		editArray.postLoad=function(){
			let attrList,attr;
			attrList=this.attrList;
			for(attr of attrList){
				attr.postLoad && attr.postLoad();
			}
		};
	}
	
	//************************************************************************
	//Scope / dynamic val related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editArray.updateHyperAttrs=function(){
			let attrList,i,n,attr;
			let curLan,loc,lanTxt;
			attrList=this.attrList;
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				if(attr.updateHyperAttrs){
					attr.updateHyperAttrs();
				}else{
					loc=attr.localize;
					if(loc){
						lanTxt=loc[curLan]||loc["EN"];
						attr.setValByText(lanTxt);
					}else if(attr.hyper){
						attr.setValByText(attr.valText);
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		//Execute hyer attr code:
		editArray.execHyperAttr=function(code){
			return this.owner.execHyperAttr(code);
		};
		
		//--------------------------------------------------------------------
		//Generate a Hyper-Attr-Function:
		editArray.genHyperAttrFunc=function(code){
			return this.owner.genHyperAttrFunc(code);
		};

		//--------------------------------------------------------------------
		editArray.getScopeVal=function(valName){
			let owner=this.owner;
			if(owner && owner.getScopeVal){
				return owner.getScopeVal(valName);
			}
			return undefined;
		};
		
		//--------------------------------------------------------------------
		editArray.getScopeValNames=function(){
			let owner=this.owner;
			if(owner && owner.getScopeValNames){
				return owner.getScopeValNames();
			}
			return [];
		};
	}
	
	//************************************************************************
	//TabEditor interactive:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editArray.getEditRootPpts=function(){
			return null;
		};
		
		//--------------------------------------------------------------------
		editArray.getNaviSubList=function(){
			return this.attrList.slice(0);
		};
		
		//--------------------------------------------------------------------
		editArray.getEditSubPpts=function(){
			return this.attrList.slice(0);
		};
	}
	
	//------------------------------------------------------------------------
	editArray.getJSObj=function(deep=0,maxDeep=5){
		let list,i,n,attr;
		let jsObj=[];
		deep+=1;
		if(deep>=maxDeep){
			return jsObj;
		}
		list=this.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.getJSObj){
				jsObj[i]=attr.getJSObj(deep,maxDeep);
			}else{
				jsObj[i]=attr.val;
			}
		}
		return jsObj;
	};
	
	//------------------------------------------------------------------------
	editArray.genAttrDef=function(name,showName,icon,key=true,fixed=true){
		let objDef,attrsDef;
		objDef={
			type:"array",
			name:name,
			showName:showName||name,
			icon:icon,
			def:{
				initAttrVOs:this.attrs.genSaveVO()
			},
			key:key,fixed:fixed
		};
		return objDef;
	};
	
	//------------------------------------------------------------------------
	editArray.updateGenedAttrDef=function(attrDef){
		attrDef.def.initAttrVOs=this.attrs.genSaveVO();
	};
	
	//------------------------------------------------------------------------
	editArray.getScopeValTip=function(code){
		return null;
	};
}

//****************************************************************************
//Common VO Object def:
//****************************************************************************
EditArray.regArrayDef("Array",{
	name:"Array",icon:"array.svg",allowExtraAttr:1
});
EditArray.regArrayDef("AutoArray",{
	name:"AutoArray",icon:"array.svg",elementType:"auto",allowExtraAttr:1
});
EditArray.regArrayDef("FlatArray",{
	name:"FlatArray",icon:"array.svg",allowExtraAttr:1,flatObj:true
});
EditArray.regArrayDef("IntArray",{
	name:"IntArray",icon:"array.svg",elementType:"int",allowExtraAttr:1
});
EditArray.regArrayDef("NumberArray",{
	name:"NumberArray",icon:"array.svg",elementType:"number",allowExtraAttr:1
});
EditArray.regArrayDef("StringArray",{
	name:"StringArray",icon:"array.svg",elementType:"string",allowExtraAttr:1
});
EditArray.regArrayDef("BoolArray",{
	name:"BoolArray",icon:"array.svg",elementType:"bool",allowExtraAttr:1
});
EditArray.regArrayDef("RGBArray",{
	name:"RGBArray",icon:"array.svg",elementType:"colorRGB",allowExtraAttr:1
});
EditArray.regArrayDef("RGBAArray",{
	name:"RGBAArray",icon:"array.svg",elementType:"colorRGBA",allowExtraAttr:1
});
EditArray.regArrayDef("FileArray",{
	name:"FileArray",icon:"array.svg",elementType:"file",allowExtraAttr:1
});
export {EditArray};
