//Auto genterated by Cody
import {VFACT} from "/@vfact";
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1G9QH48EU0;"
/*#{StartDoc*/
VFACT.loadConfig("TabOS-Config");
if(VFACT.lanCode===null){
	let userLanguages = navigator.languages || [navigator.language || navigator.userLanguage];
	let userLanguage = userLanguages[0];
	let languageCode = userLanguage.substring(0, 2).toUpperCase();
	switch(languageCode){
		case "ZH":
			languageCode="CN";
			break;
	}
	VFACT.lanCode=languageCode;
}
/*}#StartDoc*/
let darkMode=false;
darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;
VFACT.darkMode=darkMode;
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
/*#{StartObj*/
/*}#StartObj*/
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1G9QH48EU2"
	"darkMode":darkMode,"version":"0.0.1",
	"txtSize":{
		"small":12,"smallMid":14,"mid":16,"smallBig":18,"big":20,"smallLarge":24,"large":28,"smallLarger":32,"larger":36,"smallHuge":42,"huge":48,"bigHuge":56,
		"smallHuger":64,"huger":72,"bigHuger":80
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20,"naviLineH":28,"attrLineH":28,"cardLineH":48,"headerH":30,"footerH":25
	},
	"color":{
		"primary":[13,110,253,1],"fontPrimary":[255,255,255,1],"fontPrimarySub":[13,110,253,1,80],"fontPrimaryLit":[13,110,253,1,50],"secondary":[108,117,125,1],
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[108,117,125,1,80],"fontSecondaryLit":[108,117,125,1,50],"body":[255,255,255,1],"fontBody":[0,0,0,1],
		"fontBodySub":[80,80,80,1],"fontBodyLit":[180,180,180,1],"lineBody":[0,0,0,1],"lineBodySub":[80,80,80,1],"lineBodyLit":[180,180,180,1],"lineBodyThin":[220,220,220,1],
		"success":[0,128,0,1],"fontSuccess":[255,255,255,1],"fontSuccessSub":[0,128,0,1,80],"fontSuccessLit":[0,128,0,1,50],"warning":[255,128,12,1],"fontWarning":[255,255,255,1],
		"fontWarningSub":[255,128,12,1,80],"fontWarningLit":[255,128,12,1,50],"fontDisable":[255,255,255,1],"fontDisableSub":[200,200,200,1,80],"disable":[200,200,200,1],
		"fontDisableLit":[200,200,200,1,50],"error":[240,0,0,1],"fontError":[255,255,255,1],"fontErrorSub":[240,0,0,1,80],"fontErrorLit":[240,0,0,1,50],"iconBtnOver":[13,110,253,1,80],
		"iconBtnDown":[13,110,253,1,60],"iconBtnUp":[255,255,255,0],"hot":[220,240,255,1],"iconFace":[50,50,50,1],"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))",
		"gntSelected":"linear-gradient(to right, rgba(180,180,180,1), 50%, rgba(180,180,180,0.1))","gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(180,180,180,0.1))",
		"gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))","gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))",
		"tool":[240,240,240,1],"fontTool":[0,0,0,1,-100],"fontToolSub":[240,240,240,1,-60],"fontToolLit":[82.32,82.32,82.32,1,-30],"gntLine":"linear-gradient(to right, rgba(80,80,80,1), 50%, rgba(80,80,80,0.1))",
		"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))","gntTarget":"linear-gradient(to right, rgba(255,100,255,1), 50%, rgba(255,0,255,0.5))",
		"head":[230,230,230,1],"footer":[220,220,220,1],"tabTrack":[180,185,190,1]
	},
	"sharedAssets":"/~/-tabos/shared/assets","assetsDir":"/@editkit/assets",
	"desktopColors":{
		"0":[220,220,220,1],"1":[50,100,160,1],"2":[220,150,80,1],"3":[50,110,55,1],"4":[255,255,255,1]
	},
	"desktopColorIdx":0,
	"dockerColors":{
		"0":[82,94,107,1],"1":[198,77,13,1],"2":[15,107,34,11]
	},
	"dockerColor":{
		"0":82,"1":94,"2":107,"3":1
	},
	"lanCode":"CN",
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.lanCode=VFACT.lanCode===null?"EN":(VFACT.lanCode||"EN");
VFACT.lanCode=appCfg.lanCode;
if(!VFACT.appCfg){
	VFACT.appCfg=appCfg;
	window.jaxAppCfg=appCfg;
}
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=VFACT.appCfg||window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};

/*#{EndDoc*/
/*}#EndDoc*/

export{appCfg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "appCfg",
//	"jaxId": "1G9QH48EU0",
//	"editVersion": 4,
//	"attrs": {
//		"localVars": {
//			"type": "object",
//			"jaxId": "1G9QH48EU6",
//			"editVersion": 4,
//			"attrs": {
//				"darkMode": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G9QH48EU1",
//			"editVersion": 1,
//			"attrs": {
//				"appCfg": {
//					"type": "object",
//					"jaxId": "1G9QH48EU2",
//					"editVersion": 22,
//					"attrs": {
//						"darkMode": "#darkMode",
//						"version": "0.0.1",
//						"txtSize": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU3",
//							"editVersion": 15,
//							"attrs": {
//								"small": {
//									"type": "auto",
//									"valText": "12"
//								},
//								"smallMid": {
//									"type": "auto",
//									"valText": "14"
//								},
//								"mid": {
//									"type": "auto",
//									"valText": "16"
//								},
//								"smallBig": {
//									"type": "auto",
//									"valText": "18"
//								},
//								"big": {
//									"type": "auto",
//									"valText": "20"
//								},
//								"smallLarge": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"large": {
//									"type": "auto",
//									"valText": "28"
//								},
//								"smallLarger": {
//									"type": "auto",
//									"valText": "32"
//								},
//								"larger": {
//									"type": "auto",
//									"valText": "36"
//								},
//								"smallHuge": {
//									"type": "auto",
//									"valText": "42"
//								},
//								"huge": {
//									"type": "auto",
//									"valText": "48"
//								},
//								"bigHuge": {
//									"type": "auto",
//									"valText": "56"
//								},
//								"smallHuger": {
//									"type": "auto",
//									"valText": "64"
//								},
//								"huger": {
//									"type": "auto",
//									"valText": "72"
//								},
//								"bigHuger": {
//									"type": "auto",
//									"valText": "80"
//								}
//							}
//						},
//						"size": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU4",
//							"editVersion": 18,
//							"attrs": {
//								"menuLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"pathLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"dockerW": {
//									"type": "auto",
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"type": "auto",
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"type": "auto",
//									"valText": "20"
//								},
//								"naviLineH": {
//									"type": "int",
//									"valText": "28"
//								},
//								"attrLineH": {
//									"type": "int",
//									"valText": "28"
//								},
//								"cardLineH": {
//									"type": "int",
//									"valText": "48"
//								},
//								"headerH": {
//									"type": "int",
//									"valText": "30"
//								},
//								"footerH": {
//									"valText": "25"
//								}
//							}
//						},
//						"color": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH48EU5",
//							"editVersion": 147,
//							"attrs": {
//								"primary": {
//									"type": "auto",
//									"valText": "[13,110,253,1]"
//								},
//								"fontPrimary": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"type": "auto",
//									"valText": "[13,110,253,1,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "auto",
//									"valText": "[13,110,253,1,50]"
//								},
//								"secondary": {
//									"type": "auto",
//									"valText": "[108,117,125,1]"
//								},
//								"fontSecondary": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"type": "auto",
//									"valText": "[108,117,125,1,80]"
//								},
//								"fontSecondaryLit": {
//									"type": "auto",
//									"valText": "[108,117,125,1,50]"
//								},
//								"body": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontBody": {
//									"type": "auto",
//									"valText": "[0,0,0,1]"
//								},
//								"fontBodySub": {
//									"type": "auto",
//									"valText": "[80,80,80,1]"
//								},
//								"fontBodyLit": {
//									"type": "auto",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBody": {
//									"type": "auto",
//									"valText": "[0,0,0,1]"
//								},
//								"lineBodySub": {
//									"type": "auto",
//									"valText": "[80,80,80,1]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBodyThin": {
//									"type": "colorRGBA",
//									"valText": "[220,220,220,1]"
//								},
//								"success": {
//									"type": "auto",
//									"valText": "[0,128,0,1]"
//								},
//								"fontSuccess": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"type": "auto",
//									"valText": "[0,128,0,1,80]"
//								},
//								"fontSuccessLit": {
//									"type": "auto",
//									"valText": "[0,128,0,1,50]"
//								},
//								"warning": {
//									"type": "auto",
//									"valText": "[255,128,12,1]"
//								},
//								"fontWarning": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"type": "auto",
//									"valText": "[255,128,12,1,80]"
//								},
//								"fontWarningLit": {
//									"type": "auto",
//									"valText": "[255,128,12,1,50]"
//								},
//								"fontDisable": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontDisableSub": {
//									"type": "auto",
//									"valText": "[200,200,200,1,80]"
//								},
//								"disable": {
//									"type": "auto",
//									"valText": "[200,200,200,1]"
//								},
//								"fontDisableLit": {
//									"type": "auto",
//									"valText": "[200,200,200,1,50]"
//								},
//								"error": {
//									"type": "auto",
//									"valText": "[240,0,0,1]"
//								},
//								"fontError": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								},
//								"fontErrorSub": {
//									"type": "auto",
//									"valText": "[240,0,0,1,80]"
//								},
//								"fontErrorLit": {
//									"type": "auto",
//									"valText": "[240,0,0,1,50]"
//								},
//								"iconBtnOver": {
//									"type": "auto",
//									"valText": "[13,110,253,1,80]"
//								},
//								"iconBtnDown": {
//									"type": "auto",
//									"valText": "[13,110,253,1,60]"
//								},
//								"iconBtnUp": {
//									"type": "auto",
//									"valText": "[255,255,255,0]"
//								},
//								"hot": {
//									"type": "auto",
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"type": "auto",
//									"valText": "[50,50,50,1]"
//								},
//								"gntFocus": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))\""
//								},
//								"gntSelected": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(180,180,180,1), 50%, rgba(180,180,180,0.1))\""
//								},
//								"gntSelect": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(180,180,180,0.1))\""
//								},
//								"gntDlgHeader": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))\""
//								},
//								"gntHotText": {
//									"type": "auto",
//									"valText": "\"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))\""
//								},
//								"tool": {
//									"type": "auto",
//									"valText": "[240,240,240,1]"
//								},
//								"fontTool": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-100]"
//								},
//								"fontToolSub": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-60]"
//								},
//								"fontToolLit": {
//									"type": "auto",
//									"valText": "[240,240,240,1,-30]"
//								},
//								"gntLine": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(80,80,80,1), 50%, rgba(80,80,80,0.1))"
//								},
//								"gntLineBreak": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))\""
//								},
//								"gntTarget": {
//									"type": "colorRGBA",
//									"valText": "#\"linear-gradient(to right, rgba(255,100,255,1), 50%, rgba(255,0,255,0.5))\""
//								},
//								"head": {
//									"valText": "[230,230,230,1]"
//								},
//								"footer": {
//									"valText": "[220,220,220,1]"
//								},
//								"tabTrack": {
//									"valText": "[180,185,190,1]"
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "auto",
//							"valText": "\"/~/-tabos/shared/assets\""
//						},
//						"assetsDir": {
//							"type": "auto",
//							"valText": "\"/@editkit/assets\""
//						},
//						"desktopColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH52120",
//							"editVersion": 5,
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[220,220,220,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[50,100,160,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[220,150,80,1]"
//								},
//								"3": {
//									"type": "auto",
//									"valText": "[50,110,55,1]"
//								},
//								"4": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								}
//							}
//						},
//						"desktopColorIdx": {
//							"type": "auto",
//							"valText": "0"
//						},
//						"dockerColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9QH52121",
//							"editVersion": 3,
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[82,94,107,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[198,77,13,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[15,107,34,11]"
//								}
//							}
//						},
//						"dockerColor": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GMFI9OUF0",
//							"editVersion": 8,
//							"attrs": {
//								"0": {
//									"valText": "82"
//								},
//								"1": {
//									"valText": "94"
//								},
//								"2": {
//									"valText": "107"
//								},
//								"3": {
//									"valText": "1"
//								}
//							}
//						},
//						"lanCode": {
//							"valText": "\"CN\""
//						}
//					}
//				}
//			}
//		}
//	}
//}