var app=null;
var mainUI=null;

var DataClassAICommands={
	init(_app,_mainUI){
		app=_app;
		mainUI=_mainUI;
		app.aiChat.registerHandler(this);
	},
	//DataAIChatAPI:
	getAIChatCommands(){
		let cmdList;
		cmdList=[];
		if(!app)
			return cmdList;
		cmdList.push(this.cmdNewDataClass);
		return cmdList;
	},
	//------------------------------------------------------------------------
	//Commands:
	//------------------------------------------------------------------------
	cmdNewDataClass:{
		command:"NewDataClass",
		desc:"创建一个新的数据模型/模版",
		closeChat:true,
		callback:async function(cmdVO,chatDlg){
			let prjView;
			if(chatDlg){
				await chatDlg.close();
			}
			console.log("Command: will create new DataClass");
			prjView=await app.naviView.showView("NaviPrj");
			if(prjView){
				prjView.execChatCommand(cmdVO);
			}
		}
	}
};

export default {
	DataClassAICommands:DataClassAICommands,
};