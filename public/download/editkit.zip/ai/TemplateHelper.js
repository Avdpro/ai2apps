//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HROQPFR80MoreImports*/
/*}#1HROQPFR80MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HROQPFR80StartDoc*/
/*}#1HROQPFR80StartDoc*/
//----------------------------------------------------------------------------
let TemplateHelper=async function(session){
	let context,globalContext;
	let self;
	let AskTip,AskInfo,GenObject,ShowObject,CheckObjectOK,AskModifyO,AskGenTemplate,GenTbyO;
	/*#{1HROQPFR80LocalVals*/
	/*}#1HROQPFR80LocalVals*/
	
	/*#{1HROQPFR80PreContext*/
	/*}#1HROQPFR80PreContext*/
	globalContext=session.globalContext;
	context={
		"target":"Object","mockup":{},"desc":"",
		/*#{1HROQPFR84ExCtxAttrs*/
		/*}#1HROQPFR84ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HROQPFR80PostContext*/
	/*}#1HROQPFR80PostContext*/
	let agent,segs={};
	segs["AskTip"]=AskTip=async function(input){//:1HROQV6HQ0
		let result=input;
		let role="assistant";
		let content=(($ln==="CN")?("请给出要生存的数据对象类的描述（例如：“网站用户注册信息”）"):("Please provide a description of the data object class to be generated (e.g. 'Website user registration information')"));
		session.addChatText(role,content);
		return {seg:AskInfo,result:(result),preSeg:"1HROQV6HQ0",outlet:"1HROQV6HR0"};
	};
	AskTip.jaxId="1HROQV6HQ0"
	AskTip.url="AskTip@"+agentURL
	
	segs["AskInfo"]=AskInfo=async function(input){//:1HROQV6HR4
		let prompt=((($ln==="CN")?("描述:"):("Description:")))||input;
		let placeholder=("");
		let text=("");
		let result="";
		/*#{1HROQV6HR4PreCodes*/
		/*}#1HROQV6HR4PreCodes*/
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		/*#{1HROQV6HR4PostCodes*/
		context.desc=result;
		/*}#1HROQV6HR4PostCodes*/
		return {seg:GenObject,result:(result),preSeg:"1HROQV6HR4",outlet:"1HROQV6HR5"};
	};
	AskInfo.jaxId="1HROQV6HR4"
	AskInfo.url="AskInfo@"+agentURL
	
	segs["GenObject"]=GenObject=async function(input){//:1HROQV6HS0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenObject.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are an AI agent that generate mockup JSON object, based on user's description.\nIn each chat round, you generate or modify already generated JSON based on user prompt.\nFor example: \nuser: login info data\nyou: \n{\n\t\"email\":\"user@mail.com\",\n    \"password\":\"password\"\n}\nImportant: your output should be a mocked object instance, don't include other contents like choice or description of centain propery."},
		];
		messages.push(...chatMem);
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("GenObject@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>10){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:ShowObject,result:(result),preSeg:"1HROQV6HS0",outlet:"1HROQV6HS1"};
	};
	GenObject.jaxId="1HROQV6HS0"
	GenObject.url="GenObject@"+agentURL
	GenObject.messages=[];
	
	segs["ShowObject"]=ShowObject=async function(input){//:1HRORO50B2
		let result=input;
		let role="assistant";
		let content=(($ln==="CN")?("这是根据你的提示生成/修改后的数据对象样例: \n```\n"+JSON.stringify(input,null,"\t")+"\n```\n"):("Here is the mockup data object based on your prompt:\n```\n"+JSON.stringify(input,null,"\t")+"\n```\n"));
		session.addChatText(role,content);
		return {seg:CheckObjectOK,result:(result),preSeg:"1HRORO50B2",outlet:"1HRORO50B3"};
	};
	ShowObject.jaxId="1HRORO50B2"
	ShowObject.url="ShowObject@"+agentURL
	
	segs["CheckObjectOK"]=CheckObjectOK=async function(input){//:1HRORO50B4
		let prompt=((($ln==="CN")?("当前模型样本需要修改吗？"):("Is current mockup need modification?")))||input;
		let button1=("Modify")||"OK";
		let button2=("Done")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){
			result=("Modify")||result;
			/*#{1HROR4HRD0Btn1*/
			/*}#1HROR4HRD0Btn1*/
			return {seg:AskModifyO,result:(result),preSeg:"1HRORO50B4",outlet:"1HROR4HRD0"};
		}
		result=(input)||result;
		/*#{1HROR4HRD1Btn2*/
		/*}#1HROR4HRD1Btn2*/
		return {seg:AskGenTemplate,result:(result),preSeg:"1HRORO50B4",outlet:"1HROR4HRD1"};
	
	};
	CheckObjectOK.jaxId="1HRORO50B4"
	CheckObjectOK.url="CheckObjectOK@"+agentURL
	
	segs["AskModifyO"]=AskModifyO=async function(input){//:1HRORO50B8
		let prompt=("How to modify?")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:GenObject,result:(result),preSeg:"1HRORO50B8",outlet:"1HRORO50B9"};
	};
	AskModifyO.jaxId="1HRORO50B8"
	AskModifyO.url="AskModifyO@"+agentURL
	
	segs["AskGenTemplate"]=AskGenTemplate=async function(input){//:1HRRENOD70
		let prompt=((($ln==="CN")?("是否为你生成数据对象模版？"):("Do you like generate the Data-Object-Template for you?")))||input;
		let button1=((($ln==="CN")?("生成"):("Generate")))||"OK";
		let button2=("No, thanks")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){
			result=(input)||result;
			/*#{1HRREJ2V70Btn1*/
			/*}#1HRREJ2V70Btn1*/
			return {seg:GenTbyO,result:(result),preSeg:"1HRRENOD70",outlet:"1HRREJ2V70"};
		}
		result=(input)||result;
		/*#{1HRREJ2V71Btn2*/
		result={target:"Object",result:result};
		/*}#1HRREJ2V71Btn2*/
		return {result:result};
	
	};
	AskGenTemplate.jaxId="1HRRENOD70"
	AskGenTemplate.url="AskGenTemplate@"+agentURL
	
	segs["GenTbyO"]=GenTbyO=async function(input){//:1HRQLTPI80
		let prompt;
		let result=null;
		/*#{1HRQLTPI80Input*/
		/*}#1HRQLTPI80Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenTbyO.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:(($ln==="CN")?("你是一个把数据对象样本转化为“数据对象展示描述（DataObj-View-Desc）”JSON的AI Agent。\n## “数据对象展示描述（DataObj-View-Desc）”是一个JSON对象包含以下成员变量：\n- name:\n类型：字符串。内容：数据对象类名称，必须符合JS变量名规范。\n- properties:\n类型：对象。内容：数据对象的成员变量的“变量展示描述（DataVal-View-Desc）”\n- desc：\n类型：字符串。内容：数据对象类的描述\n\n## “变量展示描述（DataVal-View-Desc）”是一个JSON对象，包含以下成员变量\n- name:\n类型：字符串。内容：成员变量名称，必须符合JS变量名规范。\n- type:\n类型：字符串。内容：成员变量的类型，可以选择的类型包括：\"auto\", \"int\", \"number\", \"string\", \"bool\", \"object\", \"array\"。\n- label:\n类型：字符串。内容：用于展示的，更容易阅读的显示名字，不必遵循变量名规范。\n- desc:\n类型：字符串。内容：数据变量的描述。\n- readOnly:\n类型：布尔。内容：数据变量是否不可编辑。可无，默认为false。\n- required:\n类型：布尔。内容：数据变量是否必填。可无，默认为false。\n- placeHolder:\n类型：字符串。内容：编辑占位符。可无，默认为false。\n- choices:\n类型：数组。内容：该变量可能选择的值列表。可无，默认为空。\n- ranged:\n类型：布尔。内容：数据变量值是否有范围。可无，默认为false。\n- rangeMin:\n类型：数字。内容：数据变量值范围的最小值。可无。\n- rangeMax:\n类型：数字。内容：数据变量值范围的最大值。可无。\n- inputType: \n类型：字符串。内容：编辑变量时的类型，可以取的值有：\"password\", \"date\", \"time\", \"month\"。可无\n\n## 对话的输入是“对象描述”和一个“数据对象的样本（mockup）”。你的输出是 DataObj-View-Desc 的JSON。"):("You are an AI Agent that converts data object samples into a JSON representation of 'DataObj-View-Desc'.\n## 'DataObj-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Data object class name, must comply with JS variable naming conventions..\n- properties:\nType: Object. Content: 'DataVal-View-Desc' of data object members.\n- desc:\nType: String. Content: Description of the data object class.\n\n## 'DataVal-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Member variable name, must comply with JS variable naming conventions.\n- type:\nType: String. Content: Type of the member variable, available types include: 'auto', 'int', 'number', 'string', 'bool', 'object', 'array'.\n- label:\nType: String. Content: Display name for easier readability, does not need to follow variable naming conventions.\n- desc:\nType: String. Content: Description of the data variable.\n- readOnly:\nType: Boolean. Content: Whether the data variable is not editable. Optional, default is false.\n- required:\nType: Boolean. Content: Whether the data variable is required. Optional, default is false.\n- placeHolder:\nType: String. Content: Edit placeholder. Optional, default is false.\n- choices:\nType: Array. Content: List of possible values for the variable. Optional, default is empty.\n- ranged:\nType: Boolean. Content: Whether the data variable value has a range. Optional, default is false.\n- rangeMin:\nType: Number. Content: Minimum value of the data variable range. Optional.\n- rangeMax:\nType: Number. Content: Maximum value of the data variable range. Optional.\n- inputType:\nType: string. Content: The value's editing type, can be: \"password\", \"date\", \"time\" and \"month\". Optional.\n\n\n## The input of the conversation is 'object description' and a 'data object sample (mockup)'. Your output is the JSON of DataObj-View-Desc."))},
		];
		/*#{1HRQLTPI80PrePrompt*/
		/*}#1HRQLTPI80PrePrompt*/
		prompt="DataObj description: "+context.desc+"\n"+"DataObj mockup: \n"+JSON.stringify(input,null,"\t");
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1HRQLTPI80PreCall*/
		/*}#1HRQLTPI80PreCall*/
		result=(result===null)?(await session.callSegLLM("GenTbyO@"+agentURL,opts,messages,true)):result;
		result=trimJSON(result);
		/*#{1HRQLTPI80PostCall*/
		result={target:"Template",result:result};
		/*}#1HRQLTPI80PostCall*/
		return {result:result};
	};
	GenTbyO.jaxId="1HRQLTPI80"
	GenTbyO.url="GenTbyO@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"TemplateHelper",
		url:agentURL,
		autoStart:true,
		jaxId:"1HROQPFR80",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HROQPFR80PreEntry*/
			if(typeof(input)==="string"){
				context.target=input||"Object";
				context.mockup={};
			}else if(input){
				context.target=input.target||"Object";
				context.mockup=input.mockup||{};
			}
			/*}#1HROQPFR80PreEntry*/
			result={seg:AskTip,"input":input};
			/*#{1HROQPFR80PostEntry*/
			/*}#1HROQPFR80PostEntry*/
			return result;
		},
		/*#{1HROQPFR80MoreAgentAttrs*/
		/*}#1HROQPFR80MoreAgentAttrs*/
	};
	/*#{1HROQPFR80PostAgent*/
	/*}#1HROQPFR80PostAgent*/
	return agent;
};
/*#{1HROQPFR80ExCodes*/
/*}#1HROQPFR80ExCodes*/


export default TemplateHelper;
export{TemplateHelper};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HROQPFR80",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HROQPFR81",
//			"attrs": {
//				"TemplateHelper": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HROQPFR90",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HROQPFR91",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HROQPFR92",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HROQPFR93",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HROQPFR82",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HROQV6HQ0",
//					"attrs": {
//						"id": "AskTip",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "210",
//						"context": {
//							"jaxId": "1HROQV6HT0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HROQV6HT1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "Please provide a description of the data object class to be generated (e.g. 'Website user registration information')",
//							"localize": {
//								"EN": "Please provide a description of the data object class to be generated (e.g. 'Website user registration information')",
//								"CN": "请给出要生存的数据对象类的描述（例如：“网站用户注册信息”）"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1HROQV6HR0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HROQV6HR4"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HROQV6HR4",
//					"attrs": {
//						"id": "AskInfo",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "210",
//						"context": {
//							"jaxId": "1HROQV6HU0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HROQV6HU1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"prompt": {
//							"type": "string",
//							"valText": "Description:",
//							"localize": {
//								"EN": "Description:",
//								"CN": "描述:"
//							},
//							"localizable": true
//						},
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1HROQV6HR5",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HROQV6HS0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HROQV6HS0",
//					"attrs": {
//						"id": "GenObject",
//						"label": "New AI Seg",
//						"x": "530",
//						"y": "210",
//						"context": {
//							"jaxId": "1HROQV6HU2",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HROQV6HU3",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": "You are an AI agent that generate mockup JSON object, based on user's description.\nIn each chat round, you generate or modify already generated JSON based on user prompt.\nFor example: \nuser: login info data\nyou: \n{\n\t\"email\":\"user@mail.com\",\n    \"password\":\"password\"\n}\nImportant: your output should be a mocked object instance, don't include other contents like choice or description of centain propery.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HROQV6HS1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HRORO50B2"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "10 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HRORO50B2",
//					"attrs": {
//						"id": "ShowObject",
//						"label": "New AI Seg",
//						"x": "760",
//						"y": "210",
//						"context": {
//							"jaxId": "1HRORO50F0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRORO50F1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "#\"Here is the mockup data object based on your prompt:\\n```\\n\"+JSON.stringify(input,null,\"\\t\")+\"\\n```\\n\"",
//							"localize": {
//								"EN": "#\"Here is the mockup data object based on your prompt:\\n```\\n\"+JSON.stringify(input,null,\"\\t\")+\"\\n```\\n\"",
//								"CN": "#\"这是根据你的提示生成/修改后的数据对象样例: \\n```\\n\"+JSON.stringify(input,null,\"\\t\")+\"\\n```\\n\""
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1HRORO50B3",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HRORO50B4"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1HRORO50B4",
//					"attrs": {
//						"id": "CheckObjectOK",
//						"label": "New AI Seg",
//						"x": "1000",
//						"y": "210",
//						"context": {
//							"jaxId": "1HRORO50F2",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRORO50F3",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": {
//							"type": "string",
//							"valText": "Is current mockup need modification?",
//							"localize": {
//								"EN": "Is current mockup need modification?",
//								"CN": "当前模型样本需要修改吗？"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HROR4HRD0",
//									"attrs": {
//										"id": "Modify",
//										"text": "Modify",
//										"result": "Modify",
//										"codes": "true"
//									},
//									"linkedSeg": "1HRORO50B8"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HROR4HRD1",
//									"attrs": {
//										"id": "Done",
//										"text": "Done",
//										"result": "#input",
//										"codes": "true"
//									},
//									"linkedSeg": "1HRRENOD70"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HRORO50B8",
//					"attrs": {
//						"id": "AskModifyO",
//						"label": "New AI Seg",
//						"x": "1260",
//						"y": "120",
//						"context": {
//							"jaxId": "1HRORO50F8",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRORO50F9",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "How to modify?",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1HRORO50B9",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HRORO50F10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HRORO50F10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1410",
//						"y": "40",
//						"outlet": {
//							"jaxId": "1HRORO50F11",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HRORO50F12"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HRORO50F12",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "560",
//						"y": "40",
//						"outlet": {
//							"jaxId": "1HRORO50F13",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HROQV6HS0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1HRRENOD70",
//					"attrs": {
//						"id": "AskGenTemplate",
//						"label": "New AI Seg",
//						"x": "1260",
//						"y": "290",
//						"context": {
//							"jaxId": "1HRRENODA0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRRENODA1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": {
//							"type": "string",
//							"valText": "Do you like generate the Data-Object-Template for you?",
//							"localize": {
//								"EN": "Do you like generate the Data-Object-Template for you?",
//								"CN": "是否为你生成数据对象模版？"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HRREJ2V70",
//									"attrs": {
//										"id": "Generate",
//										"text": {
//											"type": "string",
//											"valText": "Generate",
//											"localize": {
//												"EN": "Generate",
//												"CN": "生成"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "true"
//									},
//									"linkedSeg": "1HRQLTPI80"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HRREJ2V71",
//									"attrs": {
//										"id": "No",
//										"text": "No, thanks",
//										"result": "#input",
//										"codes": "true"
//									}
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRQLTPI80",
//					"attrs": {
//						"id": "GenTbyO",
//						"label": "New AI Seg",
//						"x": "1540",
//						"y": "200",
//						"context": {
//							"jaxId": "1HRQLTPIE0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRQLTPIE1",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": {
//							"type": "string",
//							"valText": "You are an AI Agent that converts data object samples into a JSON representation of 'DataObj-View-Desc'.\n## 'DataObj-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Data object class name, must comply with JS variable naming conventions..\n- properties:\nType: Object. Content: 'DataVal-View-Desc' of data object members.\n- desc:\nType: String. Content: Description of the data object class.\n\n## 'DataVal-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Member variable name, must comply with JS variable naming conventions.\n- type:\nType: String. Content: Type of the member variable, available types include: 'auto', 'int', 'number', 'string', 'bool', 'object', 'array'.\n- label:\nType: String. Content: Display name for easier readability, does not need to follow variable naming conventions.\n- desc:\nType: String. Content: Description of the data variable.\n- readOnly:\nType: Boolean. Content: Whether the data variable is not editable. Optional, default is false.\n- required:\nType: Boolean. Content: Whether the data variable is required. Optional, default is false.\n- placeHolder:\nType: String. Content: Edit placeholder. Optional, default is false.\n- choices:\nType: Array. Content: List of possible values for the variable. Optional, default is empty.\n- ranged:\nType: Boolean. Content: Whether the data variable value has a range. Optional, default is false.\n- rangeMin:\nType: Number. Content: Minimum value of the data variable range. Optional.\n- rangeMax:\nType: Number. Content: Maximum value of the data variable range. Optional.\n- inputType:\nType: string. Content: The value's editing type, can be: \"password\", \"date\", \"time\" and \"month\". Optional.\n\n\n## The input of the conversation is 'object description' and a 'data object sample (mockup)'. Your output is the JSON of DataObj-View-Desc.",
//							"localize": {
//								"EN": "You are an AI Agent that converts data object samples into a JSON representation of 'DataObj-View-Desc'.\n## 'DataObj-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Data object class name, must comply with JS variable naming conventions..\n- properties:\nType: Object. Content: 'DataVal-View-Desc' of data object members.\n- desc:\nType: String. Content: Description of the data object class.\n\n## 'DataVal-View-Desc' is a JSON object that includes the following properties:\n- name:\nType: String. Content: Member variable name, must comply with JS variable naming conventions.\n- type:\nType: String. Content: Type of the member variable, available types include: 'auto', 'int', 'number', 'string', 'bool', 'object', 'array'.\n- label:\nType: String. Content: Display name for easier readability, does not need to follow variable naming conventions.\n- desc:\nType: String. Content: Description of the data variable.\n- readOnly:\nType: Boolean. Content: Whether the data variable is not editable. Optional, default is false.\n- required:\nType: Boolean. Content: Whether the data variable is required. Optional, default is false.\n- placeHolder:\nType: String. Content: Edit placeholder. Optional, default is false.\n- choices:\nType: Array. Content: List of possible values for the variable. Optional, default is empty.\n- ranged:\nType: Boolean. Content: Whether the data variable value has a range. Optional, default is false.\n- rangeMin:\nType: Number. Content: Minimum value of the data variable range. Optional.\n- rangeMax:\nType: Number. Content: Maximum value of the data variable range. Optional.\n- inputType:\nType: string. Content: The value's editing type, can be: \"password\", \"date\", \"time\" and \"month\". Optional.\n\n\n## The input of the conversation is 'object description' and a 'data object sample (mockup)'. Your output is the JSON of DataObj-View-Desc.",
//								"CN": "你是一个把数据对象样本转化为“数据对象展示描述（DataObj-View-Desc）”JSON的AI Agent。\n## “数据对象展示描述（DataObj-View-Desc）”是一个JSON对象包含以下成员变量：\n- name:\n类型：字符串。内容：数据对象类名称，必须符合JS变量名规范。\n- properties:\n类型：对象。内容：数据对象的成员变量的“变量展示描述（DataVal-View-Desc）”\n- desc：\n类型：字符串。内容：数据对象类的描述\n\n## “变量展示描述（DataVal-View-Desc）”是一个JSON对象，包含以下成员变量\n- name:\n类型：字符串。内容：成员变量名称，必须符合JS变量名规范。\n- type:\n类型：字符串。内容：成员变量的类型，可以选择的类型包括：\"auto\", \"int\", \"number\", \"string\", \"bool\", \"object\", \"array\"。\n- label:\n类型：字符串。内容：用于展示的，更容易阅读的显示名字，不必遵循变量名规范。\n- desc:\n类型：字符串。内容：数据变量的描述。\n- readOnly:\n类型：布尔。内容：数据变量是否不可编辑。可无，默认为false。\n- required:\n类型：布尔。内容：数据变量是否必填。可无，默认为false。\n- placeHolder:\n类型：字符串。内容：编辑占位符。可无，默认为false。\n- choices:\n类型：数组。内容：该变量可能选择的值列表。可无，默认为空。\n- ranged:\n类型：布尔。内容：数据变量值是否有范围。可无，默认为false。\n- rangeMin:\n类型：数字。内容：数据变量值范围的最小值。可无。\n- rangeMax:\n类型：数字。内容：数据变量值范围的最大值。可无。\n- inputType: \n类型：字符串。内容：编辑变量时的类型，可以取的值有：\"password\", \"date\", \"time\", \"month\"。可无\n\n## 对话的输入是“对象描述”和一个“数据对象的样本（mockup）”。你的输出是 DataObj-View-Desc 的JSON。"
//							},
//							"localizable": true
//						},
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#\"DataObj description: \"+context.desc+\"\\n\"+\"DataObj mockup: \\n\"+JSON.stringify(input,null,\"\\t\")",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRQLTPI81",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				}
//			]
//		},
//		"entry": "AskTip",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HROQPFR83",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HROQPFR84",
//			"attrs": {
//				"target": {
//					"type": "string",
//					"valText": "Object"
//				},
//				"mockup": {
//					"type": "auto",
//					"valText": "#{}"
//				},
//				"desc": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1HROQPFR85",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HROQPFR86",
//			"attrs": {}
//		}
//	}
//}