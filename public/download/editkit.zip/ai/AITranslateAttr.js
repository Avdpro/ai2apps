import {esprima} from "/@tabos/utils/esprima.mjs";
import {EditAttr} from "../EditAttr.js";

const aiMessagesLead=[
	{
		role:"system",
		content:"You are a JS code localizer"
	},
	{
		role:"user",
		content:`translate code, 
JS syntax should be kept
IMPORTANT: All null properties should be translated!!
\`\`\`
[
	{
		EN:"open",
		CN:null,
	},
	{
		CN:\`这是第\${num}个\`,
		EN:null,	
	},
	{
		EN:side+"is red",
		CN:null,
	},
]
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`
[
	{
		EN:"open",
		CN:"打开",
	},
	{
		CN:\`这是第\${num}个\`,
		EN:\`This is no. \${num}\`,
	},
	{
		EN:side+"is red",
		CN:side+"是红色",
	},
]
\`\`\``
	},
];

//----------------------------------------------------------------------------
async function aiLocalizeAttr(app,aiChat,chatDlg,localizeObj,baseLan){
	let orgCode,valMode,postFix,newObj;
	let messages,resVO,message,aiCode,ast;
	function packBaseLan(){
		let text=localizeObj[baseLan];
		let code;
		if(text.startsWith("${")){
			let pos;
			valMode="${";
			pos=text.lastIndexOf("}");
			if(pos>0){
				code=text.substring(2,pos);
				postFix=text.substring(pos);
			}else{
				code=text.substring(2);
				postFix="";
			}
		}else if(text.startsWith("#")){
			valMode="#"
			code=text.substring(2);
		}else{
			valMode="";
			code=JSON.stringify(text);
		}
		return `${baseLan}:${code}`
	}
	//Generate orgCode:
	{
		orgCode="{\n";
		orgCode+=`\t${packBaseLan()},\n`;
		for(let lanCode in localizeObj){
			if(lanCode!==baseLan){
				orgCode+=`\t${lanCode}:null,\n`;
			}
		}
		orgCode+="}";
	}	
	messages=[...aiMessagesLead];
	messages.push({
		role:"user",
		content:`translate code, \nJS syntax should be kept\nIMPORTANT: All null properties should be translated!!\n\`\`\`\n${orgCode}\n\`\`\``
	});
	resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
	message=resVO.message;
	resVO=aiChat.parseCodes(message);
	if(!resVO.codes || !resVO.codes[0]){
		return;
	}
	newObj={};
	aiCode=resVO.codes[0][1];
	aiCode="x="+aiCode;
	try{
		let ppts,ppt,lanCode,text;
		ast=esprima.parse(aiCode,{ range: true });
		ppts=ast.body[0].expression.right.properties;
		for(ppt of ppts){
			lanCode=ppt.key.name;
			text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
			switch(valMode){
				case "${":
					text="${"+text+postFix;
					break;
				case "#":
					text="#"+text;
					break;
				default:
					try{
						text=JSON.parse(text);
					}catch(err){
						text=text.substring(1,text.length-1);
					}
					break;
			}
			newObj[lanCode]=text;
		}
	}catch(err){
		return null;
	}
	console.log(ast);
	console.log(newObj);
	return newObj;
};

//----------------------------------------------------------------------------
async function aiLocalizeDoc(app,aiChat,chatDlg,editDoc,baseLan){
	//TODO: Code this:
};

//----------------------------------------------------------------------------
async function aiLocalizeCode(app,aiChat,chatDlg,code,locLans,baseLan){
	//TODO: Code this:
};

export{aiLocalizeAttr,aiLocalizeDoc,aiLocalizeCode};