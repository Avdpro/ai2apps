import {tabFS} from "/@tabos";
import pathLib from "/@path";
//----------------------------------------------------------------------------
//Make dev with HRM:
let dist={
	steps:[
		{
			action:"copy",
			dirs:{
				"/editkit/disk.json":"dist/"
			},
		},
		{
			action:"clean",
			dirs:["/editkit"],
		},
		{
			action:"copy",
			dirs:{
				"cfg":"/editkit/cfg",
				"docs":"/editkit/docs",
				"editdoc":"/editkit/edithud",
				"edithud":"/editkit/edithud",
				"exporters":"/editkit/exporters",
				"forge":"/editkit/forge",
				"text":"/editkit/text",
				"ui":"/editkit/ui",
			},
			files:{
				"EditAddOn.js":"/edit/",
				"EditArray.js":"/edit/",
				"EditAttr.js":"/edit/",
				"EditClass.js":"/edit/",
				"EditFunction.js":"/edit/",
				"EditObj.js":"/edit/",
				"EditPrj.js":"/edit/",
				"ReactAddOn.js":"/edit/",
				"dist/disk.json":"/edit/",
			},
			copy:async function(srcPath,dstPath,vo){
				let ext;
				ext=pathLib.extname(srcPath);
				if(ext===".js"){
					let text,pos;
					text=await tabFS.readFile(srcPath,"utf8");
					pos=text.lastIndexOf("