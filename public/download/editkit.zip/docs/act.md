# Absolute Components Tree
Use an JavaScript Object define a UI components hierarchical tree.

## Common Component Properties 

### Component access:

**type**:

- **type**: string, objDef
- **default**: "obj"

**id**:

- **type**: string, function
- **default**: ""
- **trace**: no

**hashId/ jaxId**:

- **type**: string
- **default**: ""
- **trace**: no

**attched**:

- **type**: bool
- **default**: undefined
- when attched===false, system should skip create this element.

### Component position and size:

**x**: 

- **type**: number, function(FW:number,FH:number):number, string 
- **default**: 0
- **trace**: yes

**y**: 

- **type**: number, function(FW:number,FH:number):number, string
- **default**: 0
- **trace**: yes

**z**: 

- **type**: int
- **default**: undefined
- **trace**: yes

**w**: 

- **type**: number, function(FW:number,FH:number):number, string
- **default**: 0
- **trace**: yes

**h**: 

- **type**: number, function(FW:number,FH:number):number, string
- **default**: 0
- **trace**: yes

**position**: 

- **type**: string-choice: ["absolute", "relative"]
- **default**: "absolute"
- **trace**: no

**traceSize**: trace element size. Trigger auto-layout and emmit change when changed.

- **type**: bool
- **default**: false
- **trace**: no

### Hierarchy

**(def) children**: children element-def array:

- **type**: array of element def
- **default**: undefined
- **trace**: no

**(runtime) children**: children element array:

- **type**: array of element def
- **default**: undefined
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) parent**: parent element

- **type**: element
- **default**: null
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) firstChild**: first child element

- **type**: element
- **default**: null
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) lastChild**: last child element

- **type**: element
- **default**: null
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) previousSibling**: previous sibling element

- **type**: element
- **default**: null
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) nextSibling**: next sibling element

- **type**: element
- **default**: null
- **read**: yes
- **write**: no
- **trace**: no

**(runtime) appendChild(childElement)**: 

- **childElement**: element
- **result**: element: the childElement

**(runtime) removeChild(childElement)**: 

- **childElement**: element
- **result**: element: the childElement

**(runtime) insertBefore(childElement)**: 

- **childElement**: element
- **result**: bool

**(runtime) replaceChild(childElement)**: 

- **childElement**: element
- **result**: bool

**(runtime) hasChild(childElement)**: 

- **childElement**: element
- **result**: bool

### Layout

**display**: 

- **type**: bool, function, string-choice:["on", "off"]
- **default**: true
- **trace**: yes

**overflow**:

- **type**: bool, function, string-choice:["hidden", "visible", "scroll", "auto"], array: [x-overflow, y-overflow]
- **default**: "visible"
- **trace**: yes

**anchorX**: 

- **type**: int-choice:[0, 1, 2], string-choice: ["left", "center", "right"]
- **default**: 0
- **trace**: yes

**anchorY**: 

- **type**: int-choice:[0, 1, 2], string-choice: ["top", "center", "buttom"]
- **default**: 0
- **trace**: yes

**autoLayout**: 

- **type**: bool
- **default**: false
- **trace**: yes

**contentLayout**:

- **type**: string-choice: ["block","flex-x", "flex-y", "grid", "grid-x", "grid-y", "flex-xr", "flex-yr", "grid-xr", "grid-yr"]
- **default**: "block"
- **trace**: yes

**subAlign**:
- **type**: ichoice:[0,1,2,3,4,5]/[]
- **default**: 0
- **trace**: yes

**gridConfig**: grid config string when "conentLayout" is *gird-\**
- **type**: string
- **default** ""
- **trace**: false

**margin**:

- **type**: int, int-array, undefined,null
- **default**: undefined
- **trace**: yes

**padding**:

- **type**: int, int-array,undefined,null
- **default**: undefined
- **trace**: yes

### Appearence

**transformOrigin**

- **type**: string, "[x-origin] [y-origin]"
    - **x-origin**: left center right
    - **y-origin**: top center bottom
- **default**: "center center"
- **trace**: yes

**alpha**:
- **type**: number,function,string
- **default**: 1

**rotate**:
- **type**: number,function,string
- **default**: 0

**scale**
- **type**: number,function,array\*
- **default**: 1

**filter**
- **type**: string,function,undefined
- **default**: ""

### Interactive

**uiEvent**:

- **type**: int, string-choice:["treeOff","Off","On"]
- **default**: 1

**cursor**:
- **type**: string
- **default**: undefined

**OnCreate()**
- **type**: function():void
- **default**: undefined

**OnFree()**
- **type**: function():void
- **default**: undefined

**OnSize()**
- **type**: function():void
- **default**: undefined

**OnClick(e)**

- **type**: function(event):int
- **default**: undefined

**OnTreeClick(e)**

- **type**: function(event):int
- **default**: undefined

**OnMouseInOut(e,isIn)**

- **type**: function(event,isIn:bool):int
- **default**: undefined

### Faces Define/ Access

**faces**:

- **type**: object
- **default**: undefined

**face**:
- **type**: string
- **default**: ""

## Box Component Properties:

**background**

**border** 

**borderStyle**

**borderColor**

**corner** 

**shadow** 

**shadowX** 

**shadowY** 

**shadowColor** 

**shadowBlur** 

**shadowSpread** 


## Text Component Properties:

**color** 

**font** 

**fontSize** 

**charGap** 

**lineGap** 

**alignH** 

**alignV** 

**wrap** 

**ellipsis** 

**bold/ weight** 

**italic** 

**underline** 

**select** 

**autoSize** 

**shadow** 

**shadowX** 

**shadowY** 

**shadowColor** 

**shadowBlur** 

## Button Comonent Properties:

**enable**

**drag**

**OnDragStart**

**OnDrag**

**OnDragEnd**

## Image Component Properties:

**image**

**autoSize**

**fitSize**

**repeat**

**imgScale**

**alignX**

**alignY**

**img3x3**

**img3x3Size**






