## Edit Project

### Properties

- **editPrj.dataPrj**
TabEditor's **DataPrj** object.

- **editPrj.dataDocs**  
TabEditor's **DataDocs** object.

- **editPrj.path**  
Project's root-dir path, this is taken from the **dataPrj**

- **editPrj.liveDocs:** 
The path-to-editDoc hash object.

- **editPrj.curNaviDoc**  
Current focused **EditDoc** object.

- **editPrj.curEditRootObj:**  
Current focused **EditObj** object. This object should be root-object of the **_TBXEditObjAttr_**

- **editPrj.docConfig:**  
The **appCfg.js**'s EditDoc object.

- **editPrj.docConfig:**  
The **appCfg.js**'s edit-config-object instance.

### Methods

- **_getName()_**
- **_getNaviSubList(mode)_**

- **_getEditRootPpts()_**

### Events
- **"FocusEditObj", _(newEditObj)=>{...}_**  
Fired when editPrj.curEditRootObj changes to a new **EditObj**

- **"BlurEditObj", _(newEditObj)=>{...}_**  
Fired when editPrj.curEditRootObj changes to null
