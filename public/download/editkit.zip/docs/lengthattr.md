# Length Attribute Expression
Length attributes are used in ACT-Tree for component position and size. There are several expression type supported:

## Number
A number expression that defines a length attribute.  

**Example:**  
x:20  
y:-100  
w:300  
h:1024 

**Framework Support:**  
|VFACT| |React| |VUE| |HTML| |iOS Native| |Android Native|
|:-: |-|:-:|-|:-:|-|:-:|-|:-:|-|:-:|
|Yes | |Yes| |Yes| |Yes| |Yes| |Yes|

## Percentage
A percentage number that defines a length attribute value via parent corresponding size value.  

**Example:**  
x: 20%  
y: -10%  
w: 50%  
h: 12.5%  

**Framework Support:**  
|VFACT| |React| |VUE| |HTML| |iOS Native| |Android Native|
|:-: |-|:-:|-|:-:|-|:-:|-|:-:|-|:-:|
|Yes | |Yes| |Yes| |Yes| |Yes| |Yes|

## Percentage and delta
A percentage number and a delta value. The percentage number defines a length attribute value via parent corresponding size value. The delta value defines the offset value from that percentage value.  

**Example:**  
x: 20%+10  
y: -10%-5  
w: 50%+20  
h: 12.5%-3  

**Framework Support:**  
|VFACT| |React| |VUE| |HTML| |iOS Native| |Android Native|
|:-: |-|:-:|-|:-:|-|:-:|-|:-:|-|:-:|
|Yes | |Yes| |Yes| |Yes| |Yes| |Yes|


## FW / FH Expression
An code-expression to calcaulate length value. It can contain variables **FW** and **FH**. **FW** is the number value of parent component width and **FH** is the number value of parent component height.

**Example:**  
x: FW*20%  
y: FH-50  
w: FW-appCfg.size.appBorder  
h: FH>500?500:FH  
w: Math.min(FW,FH)  
h: Math.floor(FW/3+FH/7)

**Framework Support:**  
|VFACT| |React| |VUE| |HTML| |iOS Native| |Android Native|
|:-: |-|:-:|-|:-:|-|:-:|-|:-:|-|:-:|
|Yes | |No| |No| |No| |Yes| |Yes|

## Web calc(...) Expression
An web-css-code-expression to calcaulate length value. It follows web css standard.

**Example:**  
x: calc(50% + 10px)  
y: calc(50% + 2*10px)
w: calc(50% - 2*3px + 10%*0.5)
h: calc(100%/3)

**Framework Support:**  
|VFACT| |React| |VUE| |HTML| |iOS Native| |Android Native|
|:-: |-|:-:|-|:-:|-|:-:|-|:-:|-|:-:|
|Yes | |Yes| |Yes| |Yes| |No| |No|

