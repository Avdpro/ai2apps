## EditAttr
### Overview
EditAttr is the base class of **EditSystem**'s editable object attribute. It's property **val** represent the attribute's value. It's property **valText** represent the attribute's editing text. To change attribute's value, use **setValByText** function.

### Constructor EditAttr(owner,def,init=true)
- **owner:** EditObj which own this attribute.

- **def:** EditAttr-Def-Obj

- **init:** Init attribute's val/valText property with default value.

### Properties
- owner: The owner (EditObj) of this attribute.

- def: The EditAttr-def-object of this attribute.
- name: Name of the attribute.
- val: The attribute's current value.
- valText: The show/edit-text of this attribute's value (this.val).
- hyper: Indicates if this attribute's value is a code-seg (thi.valText starts with '${' or '#').
- comment: Editable comment of this attribute. May be showed at exported-codes.
- arraryVal: Indicates if the attribute's value suppose to be a array (like ColorRGBA).
### Static Methods
- **EditAttr.createAttr(owner,def,init):**  
Create a new attr on **_owner_** object based on **_def_**. if **_init_** is true, init the attribute with default val/valText.

- **EditAttr.loadFromVO(owner,savedVO,name):**  
**_EditAttr.loadAttr(owner,savedVO,name)_:**  
Load **owner** EditObj's **name** attr from **saveVO**.

- **EditAttr.regAttrType(name,typeConstructor):**  
**_EditAttr.regType(name,typeConstructor)_:**  
Register a attribute type.

- **EditAttr.getAttrType(name):**  
**_EditAttr.getType(name):_**  
Get a registered attribute type constructor.

- **_EditAttr.getTypes()_:**  
Get all registered attribute type constructors in an object. The object's property-key is type-name, property-value is type constructor.

- **EditAttr.regClassType(name,editClass):**  
**_EditAttr.regClass(name,editClass):_**  
Register a edited-object-class.

- **EditAttr.getClassType(name):**  
**_EditAttr.getClass(name):_**  
Get a registered edited-object-class.

- **EditAttr.getClassTypeList():**  
**_EditAttr.getClasses():_**  
Get all registered edited-object-classes.

### Object Methods
- **editAttr.emitAttrChange():**  
**_editAttr.emitChanged()_:**  
Call this function to notify attr changes, this function will check the condition if this attribute is been traced.

- **editAttr.setValByText(text):**  
Set the attribute's value by text. At most cases, attribute's value should be changed by this way. It ensure the **_editAttr.val_** and **_editAttr.valText_** are synced.  
This function returns **true** when success, otherwise, **false**.

- **editAttr.text2Val(text):**  
Calculate value of text for this attribute.  
This function returns the attribute-value of given text.

- **editAttr.val2Text(val):**.
Convert value to show/edit text for this attribute.  
This function returns text-presentation of the given value.

- **editAttr.onChange(callback):**  
Trace this attribute's change **event**. 

- **editAttr.offChange(callback):**  
Cancel trace this attribute's change **event**. 

- **editAttr.traceOn(callback):**  
Trace this attribute's change **notify**. 

- **editAttr.traceOff(callback):**  
Cancel trace this attribute's change **notify**. 

- **editAttr.cloneAttrToObj(tgtObj,**_exDefOpts_,_opts_**)**:  
Clone this attrubte to another **editObj**

### Events, notifys and hookers
- **_checkChange(newValText)_: Hooker**  
When set, this hooker will be called before the attr changes by new val-text. If this function returns **false** the change will be aborted.

- **_getName()_: Hooker**  
When set, the function's return value should be the user-visual name when editor ui show this atribute's name.

- **"Changed": event and notify**  
Fires after the attribute has been changed.

### Built-in attribute types:
**auto**, **int**, **string** **number**(**float**, **real**), **bool**, **colorRGB**, **colorRGBA**, **choice**, **file**(**image**, **fileDir**) **length**

