## Edit Object Attribute Def 
### Properties
- **name**  
String, name (in code) of the attribute.

- **type**
String, type of the attr.

- **editType**
String, edit-type-hint for editor-ui.

- **rawEdit**  
Boolean, when set to _false_, the attr can not be edit as text (thus, can't be hyper).

- **showName:**  
**showName(attr):**  
String or function (returns a string) for show attribute's name in editor-ui.

- **def:**  
Edit Object Def, can be an EditObj-Def object, or a string,

- **exportName**  
**exportName(attr,docType)**  
String or function

- **initVal**

- **initValText**

- **hideVal**

- **vals** (for _choice_ type)


- **key**

- **fixed**

- **edit**


### Methods:

- **exportName(attr,docType)**  

- **exportValText(attr, docType)**
