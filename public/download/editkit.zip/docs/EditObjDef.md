## Edit Object Def 
### Properties
- **name?**

- **showName?**

- **icon**

- **attrs** 

- **allowExtraAttr**

- **majorEditAttr**

- **constructFunc**

- **navi**

- **naviMultiSel**

- **exportName**  
**exportName(attr,docType)**

- **initVal**

- **initValText**

- **hideVal**

- **vals** (for _choice_ type)

- **objAttrs**: Attributes will be added to the Edit-Object-Instance

- **key**

- **fixed**

- **edit**

- **listHint**  
The edit-box show hint array. This defines how attribute edit lines are layouted (order/group) in **EditObjAttrBox**.
    - **group**

- **newAttrMode: ("arg", "localVar", "obj", "hudPpt", "classPpt")**  
New attr mode, this is hint for the DlgNewAttr to show attr-type-list to user


### Methods:

- **getName(obj)**

- **exportName(attr,docType)**  

- **exportValText(attr, docType)**
