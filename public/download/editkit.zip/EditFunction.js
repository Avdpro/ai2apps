import {EditAttr} from "./EditAttr.js";
import {EditObj} from "./EditObj.js";
import {EditArray} from "./EditArray.js";
import {ExportObj} from "./exporters/ExportObj.js";
import inherits from "/@inherits";
var EditFunction,editFunction;
var EditFunctionDef={
	name:"Function",
	icon:"func.svg",allowExtraAttr:0,
	attrs:{
		"callArgs":{
			name:"callArgs",type:"object",def:"Object",key:1,fixed:1,
			newAttrMode:"arg",
		},
		"mockupResult":{name:"mockupResult",type:"auto",initVal:0,key:0,fixed:1},
		"mockupCode":{name:"mockupCode",type:"string",initVal:"return 0;",key:0,fixed:0},
	}
};
function makeArgumentsDef(args){
	let attrs,i,n;
	attrs={};
	n=args.length;
	for(i=0;i<n;i++){
		attrs[args[i]]={name:args[i],type:"auto",key:1,fixed:1};
	}
	return {
		icon:"func.svg",allowExtraAttr:0,
		attrs:{
			"callArgs":{
				name:"callArgs",showName:"Arguments",type:"object",key:1,fixed:1,
				def:{
					attrs:attrs
				}
			},
			"seg":{
				name:"seg",type:"string",key:1,fixed:1,initVal:""
			},
		},
		getMenuItems:function(){
			//TODO: get menu items:
		},
		objAttrs:{
			startEdit(attr,attrLine){
				let doc,editBox;
				doc=attr.doc;
				if(doc && doc.dataDoc){
					editBox=doc.dataDoc.editBox;
					if(editBox){
						editBox.focus();
						editBox.gotoLine(attr.jaxId);
						doc.gotoMarkAfterUpdateDoc=attr.jaxId;//This is ensure code foucsed after add this attr.
					}
				}
			}
		}
	};
};
//----------------------------------------------------------------------------
EditFunction=function(prj,def,init){
	let objDef=def.def;
	if(!objDef){
		if(def.arguments){
			def={...def,def:makeArgumentsDef(def.arguments)};
		}else{
			def={...def,fixed:1,def:EditFunctionDef};
		}
	}
	EditObj.call(this,prj,def,true);
	this.isFunction=1;
	objDef=this.objDef;
	if(typeof(objDef)==="string"){
		objDef=EditFunction.getDef(objDef);
		if(!objDef){
			throw new Error(`Function def ${def.def} not found.`)
		}
	}
	this.callArgs=this.getAttr("callArgs");	
	this.initScope();
	this.mockupResult=this.getAttr("mockupResult");	
	this.mockupCode=this.getAttr("mockupCode");
	this.entrySeg=null;
	this.funcProxy=function(...args){
		let code=this.getAttr("mockupCode");
		if(code){
			let mockupFunc=0;
			let argNames;
			let argList=this.callArgs.attrList;
			argNames=[];
			for(let arg of argList){
				argNames.push(arg.name);
			}
			code=code.val;
			try{
				mockupFunc=new Function(...argNames,code);
				return mockupFunc.call(null,...args);//TODO: set this?
			}catch(err){
				console.error(`EditFunction mockup code exec error: ${err}`);
				console.error(`mockup code:`);
				console.error(code);
			}
		}
		if(this.mockupResult){
			return this.mockupResult.val;
		}
	};
};
inherits(EditFunction,EditObj);
editFunction=EditFunction.prototype;

var functionDefRegs={};
EditFunction.regFunctionDef=function(name,def){
	functionDefRegs[name]=def;
};
EditFunction.getDef=EditFunction.getFunctionDef=function(name){
	return functionDefRegs[name];
};
EditAttr.regAttrType("function",EditFunction);
EditAttr.regAttrType("fixedFunc",EditFunction);
EditFunction.regFunctionDef("Function",EditFunctionDef);

var functionsObjDef={
	name:"Functions",icon:"func.svg",attrs:{},attrType:"function",attrTypeDef:"Function",allowExtraAttr:1
};
EditObj.regObjectDef("Functions",functionsObjDef);

//----------------------------------------------------------------------------
editFunction.initScope=function(){
	let callArgs,mret,mcode;
	this.scopeObj={};
	this.setScopeObj("appCfg",this.prj.objConfig,false);
	callArgs=this.getAttr("callArgs");
	this.setScopeObj("callArgs",callArgs,true);
	mret=this.getAttr("mockupResult");
	mcode=this.getAttr("mockupCode");
	callArgs.on("ObjChanged",()=>{
		this.scopeObjVsn++;
		if(mret && mret.hyper){
			mret.setValByText(mret.valText);
		}
		if(mcode && mcode.hyper){
			mcode.setValByText(mcode.valText);
		}
	});
};

export {EditFunction}
