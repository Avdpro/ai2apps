import {EditAttr} from "./EditAttr.js";
import inherits from "/@inherits";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {esprima} from "/@tabos/utils/esprima.mjs";

//****************************************************************************
//Proxy-base-class of edit obj's proxy
//****************************************************************************
var EditObjProxy;
{
	var EditObjProxy=function(obj){
		this.obj=obj;
	};
	EditObjProxy.prototype={};
}

//****************************************************************************
//:Edit attrs list;
//****************************************************************************
let EditAttrList, editAttrList;
{
	EditAttrList=function(owner,defAttrs,listName="Attr"){
		this.owner=owner;
		this.defAttrs=defAttrs;
		this.listName=listName;
		this.attrList=[];
		this.attrHash={};
	};
	editAttrList=EditAttrList.prototype={};
	
	//************************************************************************
	//:Attr access:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAttrList.getAttrDef=function(attrName){
			return this.defAttrs[attrName];
		};

		//--------------------------------------------------------------------
		editAttrList.getAttr=function(attrName){
			return this.attrHash[attrName];
		};

		//--------------------------------------------------------------------
		editAttrList.getAttrVal=function(attrName){
			let attr=this.attrHash[attrName];
			if(!attr){
				return undefined;
			}
			return attr.val;
		};

		//--------------------------------------------------------------------
		editAttrList.getAttrValText=function(attrName){
			let attr=this.attrHash[attrName];
			if(!attr){
				return undefined;
			}
			return attr.valText;
		};

		//--------------------------------------------------------------------
		editAttrList.getAttrIdx=function(attrName){
			if(typeof(attrName)==="string"){
				return this.attrList.findIndex(item=>item.name===attrName);
			}
			return this.attrList.indexOf(attrName);
		};

		//--------------------------------------------------------------------
		editAttrList.getAttrByIdx=function(attrIdx){
			return this.attrList[attrIdx];
		};

		//--------------------------------------------------------------------
		editAttrList.addAttrItem=function(attr){
			let name;
			if(attr.owner!==this.owner){
				throw new Error("addAttrItem invalid attr owner");
			}
			name=attr.name;
			if(this.attrHash[name]){
				throw new Error(`Attr ${name} is already exist.`);
			}
			this.attrList.push(attr);
			this.attrHash[name]=attr;
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged(attr);
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrList.addAttrByDef=function(attrDef,attrName=null){
			let attr,name;
			name=attrName||attrDef.name;
			attr=this.attrHash[name];
			if(attr){
				throw new Error(`Attr ${name} is already exist.`);
			}
			attr=EditAttr.newAttr(this.owner,attrDef,true);
			this.attrList.push(attr);
			this.attrHash[name]=attr;
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged(attr);
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrList.addAttrBySaveVO=function(name,saveVO){
			let attr;
			attr=this.attrHash[name];
			if(attr){
				throw new Error(`Attr ${name} is already exist.`);
			}
			attr=EditAttr.loadFromVO(this.owner,saveVO,name);
			this.attrList.push(attr);
			this.attrHash[attr.name]=attr;
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged(attr);
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrList.addExtraAttr=function(attrName,type){
			let attr,attrDef;
			attr=this.getAttr(attrName);
			if(attr){
				throw new Error(`Attr ${attrName} is already exist.`);
			}
			attrDef=this.getAttrDef(attrName);
			if(attrDef){
				throw new Error(`Attr ${attrName} can not be extra.`);
			}
			attrDef={name:attrName,type:type||"auto",extraAttr:true};
			attr=EditAttr.newAttr(this.owner,attrDef,true);
			this.attrList.push(attr);
			this.attrHash[attrName]=attr;
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Add",attr);
			this.owner.emitChanged(attr);
			return attr;
		};

		//--------------------------------------------------------------------
		editAttrList.setAttrByText=function(attrName,valText,create=false){
			let attr,def;
			if(attrName instanceof EditAttr){
				attr=attrName;
			}else{
				attr=this.attrHash[attrName];
			}
			if(!attr){
				if(!create){
					throw new Error(`Attr "${attrName} not exist for set"`);
				}
				def=this.defAttrs[attrName];
				if(def){
					attr=this.addAttrByDef(def);
				}else{
					def=this.owner.getAttrDef(attrName);
					if(def){
						def={...def,extraAttr:true,key:0};
						attr=this.addAttrByDef(def);
					}else{
						attr=this.addExtraAttr(attrName,"auto");
					}
				}
			}
			attr.setValByText(valText);
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Changed",attr);
			this.owner.emitChanged(attr);
		};
		
		//--------------------------------------------------------------------
		editAttrList.assignAttr=function(attrName,val,create=false){
			let attr,def,valText;
			if(attrName instanceof EditAttr){
				attr=attrName;
			}else{
				attr=this.attrHash[attrName];
			}
			if(!attr){
				if(!create){
					throw new Error(`Attr "${attrName} not exist for set"`);
				}
				def=this.defAttrs[attrName];
				if(def){
					attr=this.addAttrByDef(def);
				}else{
					attr=this.addExtraAttr(attrName,"auto");
				}
			}
			valText=attr.val2Text(val);
			attr.setValByText(valText);
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Changed",attr);
			this.owner.emitChanged(attr);
			return attr;
		};
		
		//--------------------------------------------------------------------
		editAttrList.removeAttr=function(attrName,force=false){
			let attrList,attrHash,attr,attrDef;
			attrHash=this.attrHash;
			attrList=this.attrList;
			if(attrName instanceof EditAttr){
				attr=attrName;
				attrName=attrName.name;
			}else{
				attr=attrHash[attrName];
			}
			if(!attr){
				return false;
			}
			attrDef=attr.def;
			if(attrDef.key && !force){
				return false;
			}
			delete attrHash[attrName];
			for(let i=0,n=attrList.length;i<n;i++){
				if(attrList[i]===attr){
					attrList.splice(i,1);
					this.owner.editVersion++;
					this.owner.emit(this.listName+"Remove",attr);
					this.owner.emitChanged(attr);
					return;
				}
			}
			return true;
		};

		//--------------------------------------------------------------------
		editAttrList.insertAttrAt=function(attrObj,idx){
			var attr,attrs,name;
			name=attrObj.name;
			attrs=this.attrHash;
			attr=attrs[name];
			if(attr){
				throw new Error(`EditAttrList.insertAttrAt: Error: attr ${name} already exists!.`);
			}
			attrs[name]=attrObj;
			if(idx>=0){
				this.attrList.splice(idx,0,attrObj);
			}else{
				idx=this.attrList.length;
				this.attrList.push(attrObj);
			}
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Insert",attrObj,idx);
			this.owner.emitChanged(attr);
			return true;
		};
		
		//--------------------------------------------------------------------
		editAttrList.replaceAttr=function(newAttr,oldAttr){
			let attrHash,attrList,attrIdx,attrName;
			attrHash=this.attrHash;
			attrList=this.attrList;
			attrName=newAttr.name;
			if(!oldAttr){
				oldAttr=attrName;
			}
			if(oldAttr instanceof EditAttr){
				attrIdx=attrList.indexOf(oldAttr);
			}else{
				oldAttr=attrHash[oldAttr];
				attrIdx=attrList.indexOf(oldAttr);
			}
			if(attrIdx<0){
				throw new Error(`Can't find attr ${attrName} to be replaced.`);
			}
			if(oldAttr.name!=newAttr.name){
				throw new Error(`Replace attr must with same name :"${attrName}" vs "${oldAttr.name}".`);
			}
			attrHash[attrName]=newAttr;
			attrList.splice(attrIdx,1,newAttr);
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Replace",newAttr,oldAttr);
			this.owner.emitChanged(newAttr);
			return true;
		};

		//--------------------------------------------------------------------
		editAttrList.renameAttr=function(attrName,newName){
			let attr,attrDef,attrHash;
			attrHash=this.attrHash;
			if(attrName instanceof EditAttr){
				attr=attrName;
				attrName=attr.name;
				if(attr.owner!==this.owner){
					throw new Error(`Rename wrong attr: ${attrName}`);
				}
			}else{
				attr=attrHash[attrName];
			}
			if(!attr){
				throw new Error(`EditAttrList.renameAttr: attr ${attrName} is not exist.`);
			}
			attrDef=attr.def;
			if(!attrDef.extraAttr){
				throw new Error(`EditAttrList.renameAttr: attr ${attrName} can not be renamed.`);
			}
			if(attrHash[newName]){
				throw new Error(`EditAttrList.renameAttr: attr new name ${newName} is invalid.`);
			}
			attr.name=newName;
			attrDef.name=newName;
			delete attrHash[attrName];
			attrHash[newName]=attr;
			if("editVersion" in attr){
				attr.editVersion++;
			}
			attr.emitChanged();
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Rename",attr,attrName,newName);
			this.owner.emitChanged(attr);
			return true;
		};
		
		//--------------------------------------------------------------------
		editAttrList.attrCanMoveUp=function(attrName){
			let attrList,preAttr,attr;
			let idx=this.getAttrIdx(attrName);
			attrList=this.attrList;
			if(idx<=0){
				return false;
			}
			attr=attrList[idx];
			preAttr=attrList[idx-1];
			if(preAttr.def.fixed){
				return false;
			}
			if(attr.def.fixed){
				return false;
			}
			return true;
		};

		//--------------------------------------------------------------------
		editAttrList.attrCanMoveDown=function(attrName){
			let attrList,attr;
			let idx=this.getAttrIdx(attrName);
			attrList=this.attrList;
			if(idx<0||idx>=attrList.length){
				return false;
			}
			attr=attrList[idx];
			if(attr.def.fixed){
				return false;
			}
			return true;
		};

		//--------------------------------------------------------------------
		editAttrList.moveUpAttr=function(attrName){
			let attrList,preAttr,attr;
			let idx=this.getAttrIdx(attrName);
			attrList=this.attrList;
			if(idx<=0){
				return false;
			}
			attr=attrList[idx];
			preAttr=attrList[idx-1];
			if(preAttr.def.fixed){
				return false;
			}
			if(attr.def.fixed){
				return false;
			}
			this.attrList.splice(idx,1);
			this.attrList.splice(idx-1,0,attr);
			this.owner.editVersion++;
			this.owner.emit(this.listName+"MoveUp",attr,idx);
			this.owner.emitChanged(attr);
			return true;
		};

		//--------------------------------------------------------------------
		editAttrList.moveDownAttr=function(attrName){
			let attrList,attr;
			let idx=this.getAttrIdx(attrName);
			attrList=this.attrList;
			if(idx<0||idx>=attrList.length-1){
				return false;
			}
			attr=attrList[idx];
			if(attr.def.fixed){
				return false;
			}
			this.attrList.splice(idx,1);
			this.attrList.splice(idx+1,0,attr);
			this.owner.editVersion++;
			this.owner.emit(this.listName+"MoveDown",attr,idx);
			this.owner.emitChanged(attr);
			return true;
		};
		
		//--------------------------------------------------------------------
		editAttrList._clear=function(){
			let attrList,attrHash,name;
			attrList=this.attrList;
			this.attrList.splice(0);
			attrHash=this.attrHash;
			for(name in attrHash){
				delete attrHash[name];
			}
			this.owner.editVersion++;
			this.owner.emit(this.listName+"Clear");
			this.owner.emitChanged(attr);
			return true;
		};
	}

	//************************************************************************
	//I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editAttrList.genSaveVO=function(){
			let attrList,i,n,attr;
			let vo={};
			attrList=this.attrList;
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				if(attr.def.save!==false){
					vo[attr.name]=attr.genSaveVO();
				}
			}
			return vo;
		};

		//--------------------------------------------------------------------
		editAttrList.loadFromVO=function(voAttrs){
			let owner,name,attr,val;
			let attrList,attrHash;
			owner=this.owner;
			attrList=this.attrList;
			attrHash=this.attrHash;
			for(name in voAttrs){
				attr=attrHash[name];
				if(attr){
					attr.loadFromVO(voAttrs[name]);
					if(owner.isScopeObj(attr)){
						owner.scopeEnvVsn=0;
					}
				}else{
					val=voAttrs[name];
					if(val){
						attr=EditAttr.loadFromVO(owner,voAttrs[name],name,voAttrs);
						if(attr){
							this.attrList.push(attr);
							this.attrHash[attr.name]=attr;
						}
					}
				}
			}
			this.ensureKeys();
		};

		//--------------------------------------------------------------------
		editAttrList.ensureKeys=function(){
			let attrHash,defAttrs,attrDef;
			defAttrs=Object.values(this.defAttrs);
			attrHash=this.attrHash;
			for(attrDef of defAttrs){
				if(attrDef.key && !attrHash[attrDef.name]){
					this.addAttrByDef(attrDef);
				}
			}
		};

		//--------------------------------------------------------------------
		editAttrList.ensureOnlyKeys=function(){
			let attrHash,attrList,attr,defAttrs,attrDef,name;
			let i,n,owner,orgVsn;
			owner=this.owner;
			defAttrs=this.defAttrs;
			attrList=this.attrList;
			attrHash=this.attrHash;
			n=attrList.length;
			orgVsn=owner.editVersion
			for(i=0;i<n;i++){
				attr=attrList[i];
				name=attr.name;
				attrDef=defAttrs[name];
				if(!attrDef || !attrDef.key){
					attrList.splice(i,1);
					delete attrHash[name];
					n--;i--;
					owner.editVersion++;
					owner.emit(this.listName+"Remove",attr);
				}
			}
			if(owner.editVersion!==orgVsn){
				owner.emitChanged();
			}
		};
	}
}


//****************************************************************************
//:Edit Object attr;
//****************************************************************************
let EditObj, editObj;
{
	var curTimeHashTime=0,curTimeHashCnt=0;
	var forceNewJaxId=0;
	//------------------------------------------------------------------------
	//Edit object stub base:
	EditObj=function(owner,def,init){
		var self=this;
		let objDef,defAttrs,objDefAttrs,baseDef;
		EditAttr.call(this,owner,def,false);

		this.isReady=false;
		//EditObj always fires emit and notify
		makeObjEventEmitter(this);
		makeNotify(this);
		if(!this.doc){
			this.doc=owner?owner.doc:null;
		}
		this.prj=owner?owner.prj:(this.prj||null);
		objDef=def.def||"Object";
		if(typeof(objDef)==="string"){
			let typeFunc;
			typeFunc=EditAttr.getAttrType(def.type)||EditObjAttr;
			objDef=typeFunc.getDef(objDef);
			if(!objDef){
				console.error(`Object def: ${def.def} not found.`);
				throw new Error(`Object def: ${def.def} not found.`);
			}
		}
		this.objDef={...objDef};
		
		//--------------------------------------------------------------------
		//Scope for hyper-attrs:
		this.scopeObj=null;
		this.scopeObjVsn=0;
		this.scopeEnvVsn=0;
		
		this.editVersion=0;
		if("watchTree" in def){
			this.watchTree=def.watchTree;
		}else if("watchTree" in objDef){
			this.watchTree=objDef.watchTree;
		}else{
			this.watchTree=owner?(owner.watchTree||false):false;
		}
		
		objDefAttrs=objDef.attrs;
		baseDef=objDef.baseDef;
		if(baseDef){
			baseDef=EditObj.getObjectDef(baseDef);
			if(!baseDef){
				console.error(`Object base-def: ${baseDef.baseDef} not found.`);
				throw new Error(`Object base-def: ${baseDef.baseDef} not found.`);
			}
			objDefAttrs={...baseDef.attrs,...objDefAttrs};
		}
		defAttrs=def.attrs;
		if(defAttrs){
			if(objDefAttrs===objDef.attrs){
				objDefAttrs={...objDefAttrs,...defAttrs};
			}else{
				Object.assign(objDefAttrs,defAttrs);
			}
		}
		if(def.objAttrs){
			Object.assign(this,def.objAttrs);
		}
		if(objDef.objAttrs){
			Object.assign(this,objDef.objAttrs);
		}
		this.attrs=new EditAttrList(this,objDefAttrs,"Attr");
		//Coded properties:
		let objId=null;
		Object.defineProperty(this, 'jaxId', {
			get: function () {
				if(!objId){
					objId=EditObj.genObjId();
				}
				return objId;
			},
			set: function (v) {
				if(objId && !forceNewJaxId && objId!==v){
					console.error("EditObjAttr.jaxId can be set only once!");
					//throw "EditObjAttr.jaxId can be set only once!";
					return objId;
				}
				if(forceNewJaxId||!v){
					objId=EditObj.genObjId();
				}else{
					objId=v;
				}
				return objId;
			},
			enumerable: true
		});
		this.applyJaxId=(newId)=>{
			if(forceNewJaxId||!newId){
				objId=EditObj.genObjId();
			}else{
				objId=newId;
			}
		};
		let selfProxy;
		Object.defineProperty(this,'selfProxy',{
			get:function(){
				if(!selfProxy){
					selfProxy=new Proxy(new EditObjProxy(this),{
						get:function(tgt,key){
							var attr;
							if(key==="%EditObj"){
								return self;
							}
							if(key==="selfObj"){
								return ()=>{return self};
							}
							if(key===Symbol.toPrimitive){
								return ()=>"{EditObjAttr}";
							}
							attr=self.attrs.getAttr(key);
							if(attr){
								if(attr.selfProxy) {
									return attr.selfProxy;
								}else if(attr instanceof EditAttr){
									return attr.val;
								}
							}
							return undefined;
						},
						set:function(tgt,key,val){
							console.warn(Error(`Can not set attrib "${key}" on EditObjProxy.`));
							return true;
						}
					});
				}
				return selfProxy;
			},
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(this,'attrList',{
			get:function(){
				return this.attrs.attrList;
			},
			enumerable: true
		});
		Object.defineProperty(this,'attrHash',{
			get:function(){
				return this.attrs.attrHash;
			},
			enumerable: true
		});
		this.getName=this.getName||this.def.getName;
		this.editAttrState={
			open:0,
			openGroup:{}
		};
		if(init){
			this.attrs.ensureKeys();
			defAttrs=def.initAttrs;
			if(defAttrs){
				let attrName,stub,attr,stubType;
				for(attrName in defAttrs){
					stub=defAttrs[attrName];
					attr=this.getAttr(attrName);
					stubType=typeof(stub);
					if(attr){
						if(stubType==="object" && ("val" in stub)){
							let text;
							attr.val=stub.val;
							text=stub.valText;
							if(text!==undefined){
								attr.valText=text;
								attr.hyper=text.startsWith("#")||text.startsWith("${");
							}else{
								attr.valText=JSON.stringify(attr.val);
								attr.hyper=false;
							}
						}else if(stubType==="string"){
							attr.setValByText(stub);
						}
					}else{
						if(stubType==="string"){
							this.setAttrByText(attrName,stub,true);
						}else{
							this.addAttr(stub);
						}
					}
				}
			}
			this.objReady();
		}
	};
	inherits(EditObj,EditAttr);
	editObj=EditObj.prototype;
	EditAttr.regAttrType("object",EditObj);
	EditAttr.regAttrType("uistate",EditObj);
	
	//------------------------------------------------------------------------
	EditObj.genObjId=function () {
		var time,hash;
		time=Date.now();
		hash=Number(time).toString(32);
		if(time===curTimeHashTime){
			curTimeHashCnt++;
		}else{
			curTimeHashCnt=0;
		}
		hash+=""+curTimeHashCnt;
		curTimeHashTime=time;
		return hash.toUpperCase();
	};

	//------------------------------------------------------------------------
	EditObj.forceNewJaxId=function(f){
		if(f){
			forceNewJaxId++;
		}else{
			forceNewJaxId--;
			if(forceNewJaxId<0){
				throw new Error(`forceNewJaxId call unmatched.`);
			}
		}
	};

	let objectDefRegs={};
	//------------------------------------------------------------------------
	EditObj.regDef=EditObj.regObjectDef=function(name,def){
		objectDefRegs[name]=def;
	};
	
	//------------------------------------------------------------------------
	EditObj.getDef=EditObj.getObjectDef=function(name){
		return objectDefRegs[name];
	};
	
	//------------------------------------------------------------------------
	EditObj.deriveDef=function(def,newDef,attrs){
		let orgInitVals,defAttrs,attrName,orgAttrDef;
		if(typeof(def)==="string"){
			def=EditObj.getDef(def);
		}
		if(!def){
			return null;
		}
		def={...def,...newDef};
		if(attrs){
			def.attrs=defAttrs={...def.attrs};
			for(attrName in attrs){
				orgAttrDef=defAttrs[attrName];
				if(orgAttrDef){
					defAttrs[attrName]={...orgAttrDef,...attrs[attrName]};
				}else{
					defAttrs[attrName]=attrs[attrName];
				}
			}
		}
		return def;
	};
	
	//------------------------------------------------------------------------
	//Make sure items in list aren't children related
	EditObj.cutTree=function(list){
		let tgtList,i,n;
		tgtList=[];
		function isChild(fobj,cobj){
			let obj;
			obj=cobj;
			while(obj){
				if(obj===fobj){
					return true;
				}
				obj=obj.owner;
			}
			return false;
		}
		function checkObj(edHudObj){
			let i,n,chkObj,isAdded;
			n=tgtList.length;
			for(i=0;i<n;i++){
				chkObj=tgtList[i];
				if(isChild(chkObj,edHudObj)){
					return;
				}
				if(isChild(edHudObj,chkObj)){
					if(!isAdded){
						tgtList[i]=edHudObj;
						isAdded=1;
					}else{
						tgtList.splice(i,1);
						n--;i--;
					}
				}
			}
			if(!isAdded){
				tgtList.push(edHudObj);
			}
		}
		n=list.length;
		for(i=0;i<n;i++){
			checkObj(list[i]);
		}
		return tgtList;
	};
	
	//------------------------------------------------------------------------
	editObj.objReady=function(){
		if(this.isReady)
			return;
		if(this.objDef.OnCreate){
			this.objDef.OnCreate.call(this);
		}
		this.isReady=true;
	};
	
	//************************************************************************
	//Attr related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editObj.getAttr=function(attrName){
			return this.attrHash[attrName];
		};
		
		//--------------------------------------------------------------------
		editObj.getAttrDef=function(name){
			return this.objDef.attrs[name];
		};

		//--------------------------------------------------------------------
		editObj.setAttrByText=function(attrName,text,create=false){
			return this.attrs.setAttrByText(attrName,text,create);
		};
		
		//--------------------------------------------------------------------
		editObj.getAttrVal=function(attrName){
			return this.attrs.getAttrVal(attrName);
		};
		
		//--------------------------------------------------------------------
		editObj.getAttrValText=function(attrName){
			return this.attrs.getAttrValText(attrName);
		};

		//--------------------------------------------------------------------
		editObj.assignAttr=function(name,val,create){
			return this.attrs.assignAttr(name,val,create);
		};
		
		//--------------------------------------------------------------------
		editObj.assignObject=function(obj,create){
			let name;
			for(name in obj){
				this.attrs.assignAttr(name,obj[name],create);
			}
		};
		
		//--------------------------------------------------------------------
		editObj.getAttrByIdx=function(idx){
			return this.attrs.getAttrByIdx(idx);
		};

		//--------------------------------------------------------------------
		editObj.getAttrIdx=function(attrName){
			return this.attrs.getAttrIdx(attrName);
		};
		
		//--------------------------------------------------------------------
		editObj.addAttr=function(attrDef){
			if(attrDef instanceof EditAttr){
				return this.attrs.addAttrItem(attrDef);
			}
			/*if(typeof(attrDef)==="string"){
				let name=attrDef;
				attrDef=this.getAttrDef(name);
				if(!attrDef){
					attrDef={name:name,type:"auto",extraAttr:true};
				}
			}*/
			return this.attrs.addAttrByDef(attrDef);
		};
		
		//--------------------------------------------------------------------
		editObj.addAttrBySaveVO=function(attrName,saveVO){
			return this.attrs.addAttrBySaveVO(attrName,saveVO);
		};
		
		//--------------------------------------------------------------------
		editObj.addProtoAttr=function(attr){
			attr.cloneAttrToObj(this,{key:1,fromProto:1});
		};

		//--------------------------------------------------------------------
		editObj.insertAttr=function(attr,index){
			return this.attrs.insertAttrAt(attr,index);
		};

		//--------------------------------------------------------------------
		editObj.replaceAttr=function(newAttr){
			return this.attrs.replaceAttr(newAttr);
		};

		//--------------------------------------------------------------------
		editObj.removeAttr=function(attrName,force=false){
			return this.attrs.removeAttr(attrName,force);
		};

		//--------------------------------------------------------------------
		editObj.renameAttr=function(attrName,newName){
			return this.attrs.renameAttr(attrName,newName);
		};

		//--------------------------------------------------------------------
		editObj.moveUpAttr=function(attrName){
			return this.attrs.moveUpAttr(attrName);
		};

		//--------------------------------------------------------------------
		editObj.moveDownAttr=function(attrName){
			return this.attrs.moveDownAttr(attrName);
		};
		
		//--------------------------------------------------------------------
		editObj.emitChanged=editObj.emitObjChange=function(subAttr){
			this.editVersion++;
			this.emit && this.emit("Changed",subAttr);
			this.emitNotify && this.emitNotify("Changed");
			if(this.watchTree && this.owner){
				this.owner.emitChanged(this);
			}
		};
		
		//--------------------------------------------------------------------
		editObj.cloneAttrToObj=function(tgtObj,defOpts,opts){
			let vo;
			if(tgtObj.getAttr(this.name)){
				return null;
			}
			vo=this.genSaveVO();
			vo.jaxId=EditObj.genObjId();
			tgtObj.addAttrBySaveVO(vo,this.name);
		};
		
		//--------------------------------------------------------------------
		editObj.findAttrPath=function(attrObj){
			let path,curObj,attrOwner;
			if(!attrObj){
				return null;
			}
			path=[attrObj.name];
			curObj=attrObj;
			do{
				attrOwner=attrObj.owner;
				if(attrOwner===this){
					return path;
				}else if(!attrOwner){
					//No such child in tree:
					return null;
				}else{
					path.unshift(attrOwner.name);
				}
				attrObj=attrOwner;
			}while(curObj);
		};
		
		//--------------------------------------------------------------------
		editObj.getAttrByPath=function(path){
			let attrName,curObj;
			if(!path){
				return null;
			}
			if(typeof(path)==="string"){
				path=path.split(".");
			}
			curObj=this;
			for(attrName of path){
				if(!curObj || !curObj.getAttr){
					return null;
				}
				curObj=curObj.getAttr(attrName);
			}
			return curObj;
		};
	}

	//************************************************************************
	//I/O related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editObj.loadFromVO=function(vo){
			let voAttrs;
			this.muteNotify();
			this.muteEmit();
			this.applyJaxId(vo.jaxId||null);
			this.editVersion=vo.editVersion||0;
			voAttrs=vo.attrs;
			this.attrs.loadFromVO(voAttrs);
			this.unmuteEmit();
			this.unmuteNotify();
			this.objReady();
		};
		
		//--------------------------------------------------------------------
		editObj.genSaveVO=function(){
			let attrList;
			let vo={};
			{
				let exportType,orgDef;
				exportType=true;
				if(this.def.type==="aioutlet"){
					exportType=true;
				}
				if(!this.def.extraAttr && this.owner){
					orgDef=this.owner.getAttrDef(this.name);
					if(orgDef && orgDef.key && this.def.type===orgDef.type){
						exportType=false;
					}
				}
				if(exportType){
					vo.type=this.def.type||"object";
					vo.def=this.objDef.name;
				}
			}
			vo.jaxId=this.jaxId;
			//vo.editVersion=this.editVersion;
			attrList=this.attrs;
			vo.attrs=attrList.genSaveVO();
			return vo;
		};
		
		//--------------------------------------------------------------------
		editObj.postLoad=function(){
			let attrList,attr;
			attrList=this.attrList;
			for(attr of attrList){
				attr.postLoad && attr.postLoad();
			}
		};
	}
	
	//************************************************************************
	//Scope / dynamic val related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editObj.isScopeObj=function(obj){
			let objSet;
			objSet=this.scopeObjSet;
			if(!objSet){
				return false;
			}
			return objSet.has(obj);
		};

		//--------------------------------------------------------------------
		editObj.setScopeObj=function(name,obj,expand=false){
			let objSet;
			if(!this.scopeObj){
				console.error(`Can't set scope obj on this object`);
				throw new Error(`Can't set scope obj on this object`);
			}
			objSet=this.scopeObjSet;
			if(!objSet){
				this.scopeObjSet=objSet=new Set();
			}
			this.scopeObj[name]={obj:obj,expand:!!expand};
			this.scopeObjVsn+=1;
			objSet.add(obj);
		};
		
		//--------------------------------------------------------------------
		editObj.updateHyperAttrs=function(force=false){
			let attrList,attrHash,i,n,attr,attrName;
			let curLan,loc,lanTxt;
			curLan=this.prj.curLanguage;
			attrHash=this.attrHash;
			if(force && this.scopeObj){
				this.buildScopeEnv();
			}
			attrList=this.attrList;
			n=attrList.length;
			for(i=0;i<n;i++){
				attr=attrList[i];
				if(attr.updateHyperAttrs){
					attr.updateHyperAttrs(force);
				}else{
					loc=attr.localize;
					if(loc){
						lanTxt=loc[curLan]||loc["EN"];
						attr.setValByText(lanTxt);
					}else if(attr.hyper){
						attr.setValByText(attr.valText);
					}
				}
			}
		};
		
		//--------------------------------------------------------------------
		editObj.buildScopeEnv=function(){
			let funcArgs,callArgs,scopeMap,scopeObj,name,stub,obj,attr,attrDef,mockup;
			let func,nameIdxes,nameIdx,val;
			funcArgs=[];
			callArgs=[];//null for this
			nameIdxes={};
			//scopeMap={};
			scopeObj=this.scopeObj;
			if(scopeObj){
				for(name in scopeObj){
					stub=scopeObj[name];
					obj=stub.obj;
					if(stub.expand){
						let attrName;
						if(obj instanceof EditObj){
							let attrs=obj.attrs.attrHash;
							for(attrName in attrs){
								nameIdx=nameIdxes[attrName];
								if(!(nameIdx>=0)){
									nameIdx=funcArgs.length;
									funcArgs.push(attrName);
								}
								attr=attrs[attrName];
								attrDef=attr.def;
								if(attrDef.type==="classobj"){
									//push the mockupObj:
									mockup=attr.mockup.val;
									if(mockup && mockup.selfProxy){
										mockup=mockup.selfProxy;
									}
									val=mockup||null;
								}else if(attr.selfProxy){
									val=attr.selfProxy;
								}else{
									val=attr.val;
								}
								if(nameIdx>=0){
									callArgs[nameIdx]=val;
								}else{
									callArgs.push(val);
								}
							}
						}else if(obj instanceof EditObjProxy){
							let pxyObj=obj["%EditObj"];
							for(attrName in pxyObj.attrHash){
								nameIdx=nameIdxes[attrName];
								if(!(nameIdx>=0)){
									nameIdx=funcArgs.length;
									funcArgs.push(attrName);
								}
								attr=obj[attrName];
								if(nameIdx>=0){
									callArgs[nameIdx]=attr?(attr.selfProxy||attr):attr;
								}else{
									callArgs.push(attr?(attr.selfProxy||attr):attr);
								}
							}
						}else{
							for(attrName in obj){
								nameIdx=nameIdxes[attrName];
								if(!(nameIdx>=0)){
									nameIdx=funcArgs.length;
									funcArgs.push(attrName);
								}
								attr=obj[attrName];
								if(nameIdx>=0){
									callArgs[nameIdx]=attr?(attr.selfProxy||attr):attr;
								}else{
									callArgs.push(attr?(attr.selfProxy||attr):attr);
								}
							}
						}
					}else{
						nameIdx=nameIdxes[name];
						if(!(nameIdx>=0)){
							nameIdx=funcArgs.length;
							funcArgs.push(name);
						}
						if(obj instanceof EditObj){
							val=obj.selfProxy;
							callArgs.push(obj.selfProxy);
						}else{
							val=obj;
							callArgs.push(obj);
						}
						if(nameIdx>=0){
							callArgs[nameIdx]=val;
						}else{
							callArgs.push(val);
						}
					}
				}
			}else{
				callArgs=funcArgs=[];
			}
			this.scopeFuncArgs=funcArgs;
			this.scopeCallArgs=callArgs;
			this.scopeEnvVsn=this.scopeObjVsn;
		};

		//--------------------------------------------------------------------
		//Execute hyer attr code:
		editObj.execHyperAttr=function(code){
			let funcArgs,callArgs,scopeObj,name,stub,obj;
			let func,arg,i,n;
			if(!this.scopeObj){
				let owner=this.owner;
				if(owner && owner.execHyperAttr){
					return owner.execHyperAttr(code);
				}
			}
			funcArgs=this.scopeFuncArgs;
			if(!funcArgs || this.scopeEnvVsn!==this.scopeObjVsn){
				this.buildScopeEnv();
				funcArgs=this.scopeFuncArgs;
			}
			try{
				callArgs=[...this.scopeCallArgs];
				func=new Function(...funcArgs,`return (${code});`);
				n=callArgs.length;
				for(i=0;i<n;i++){
					arg=callArgs[i];
					if(arg instanceof Function){
						callArgs[i]=arg();
					}
				}
				return func.apply(null,callArgs);
			}catch(err){
				if(this.doc){
					console.log(`In ${this.doc.getAttr("path").val}:`);
				}
				console.warn(`Hyper code ${err}: >>> ${code} <<<`);
				return undefined;
			}
		};
		
		//--------------------------------------------------------------------
		//Generate a Hyper-Attr-Function:
		editObj.genHyperAttrFunc=function(code){
			let funcArgs,callArgs,scopeObj,name,stub,obj;
			let func;
			if(!this.scopeObj){
				let owner=this.owner;
				if(owner && owner.genHyperAttrFunc){
					return owner.genHyperAttrFunc(code);
				}
			}
			if(!this.scopeFuncArgs || this.scopeEnvVsn!==this.scopeObjVsn){
				this.buildScopeEnv();
			}
			funcArgs=[...this.scopeFuncArgs];
			callArgs=[...this.scopeCallArgs];
			return function(){
				try{
					func=new Function(...funcArgs,`return (${code});`);
					return func.call(null,...callArgs);
				}catch(err){
					console.error(err);
					return undefined;
				}
			};
		};

		//--------------------------------------------------------------------
		editObj.getScopeVal=function(valName){
			let idx;
			if(!this.scopeObj){
				let owner=this.owner;
				if(owner && owner.getScopeVal){
					return owner.getScopeVal(valName);
				}
			}
			if(!this.scopeFuncArgs || this.scopeEnvVsn!==this.scopeObjVsn){
				this.buildScopeEnv();
			}
			idx=this.scopeFuncArgs.indexOf(valName);
			if(idx>=0){
				return this.scopeCallArgs[idx];
			}
			return undefined;
		};
		
		//--------------------------------------------------------------------
		editObj.getScopeValNames=function(){
			if(!this.scopeObj){
				let owner=this.owner;
				if(owner && owner.getScopeValNames){
					return owner.getScopeValNames();
				}
			}
			if(!this.scopeFuncArgs || this.scopeEnvVsn!==this.scopeObjVsn){
				this.buildScopeEnv();
			}
			return [...this.scopeFuncArgs];
		};
		
		//--------------------------------------------------------------------
		editObj.getScopeValTip=function(code){
			let tokens,pos,token,pathList,tipList,scopeObj,valTip,i,n,valName;
			if(!code){
				return [...this.getScopeValNames(),""];
			}
			pathList=[];
			tipList=null;
			try{
				tokens = esprima.tokenize(code);
			}catch(err){
				return null;
			}
			pos=tokens.length-1;
			//First, get pathList:
			token=tokens[pos--];
			FindPath:{
				if(token.type==="Punctuator" && token.value==="."){
					pathList.unshift("");
				}else if(token.type==="Identifier"){
					pathList.unshift(token.value);
				}else{
					return null;
				}
				do{
					token=tokens[pos--];
					if(token){
						if(token.type==="Identifier"){
							pathList.unshift(token.value);
						}else if(token.type==="Punctuator"){
							if(token.value!=="."){
								break;
							}
						}else{
							break;
						}
					}else{
						break;
					}
				}while(1);
			}
			if(pathList.length>0){
				valTip=pathList.pop();
			}
			scopeObj=this;
			n=pathList.length;
			if(n>0){
				valName=pathList.shift();
				scopeObj=scopeObj.getScopeVal(valName);
				n--;
				for(i=0;i<n;i++){
					valName=pathList[i];
					scopeObj=scopeObj[valName];
					if(!scopeObj){
						break;
					}
				}
			}
			//Get tip list:
			if(scopeObj){
				let attrs;
				if(scopeObj===this){
					attrs=this.getScopeValNames();
				}else if(scopeObj instanceof EditObjProxy){
					scopeObj=scopeObj["%EditObj"];
					attrs=Object.keys(scopeObj.attrHash);
				}else if(scopeObj instanceof EditObj){
					attrs=Object.keys(scopeObj.attrHash);
				}else{
					attrs=Object.keys(scopeObj);
				}
				if(valTip){
					tipList=attrs.filter((item)=>{return item.startsWith(valTip);});
				}else{
					tipList=[...attrs];
				}
			}else{
				return null;
			}
			if(tipList.length>0){
				return [...tipList,valTip];
			}
			return null;
		};
	}
	
	//************************************************************************
	//TabEditor interactive related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		editObj.getLiveVal=function(){
			return `{${this.objDef.name||"EditObjAttr"}}`;
		};

		//--------------------------------------------------------------------
		editObj.getAttrLiveVal=function(attrName){
			let attr;
			if(!(attrName instanceof EditAttr)){
				attr=this.attrHash[attrName];
			}else{
				attr=attrName;
			}
			if(attr.getLiveVal){
				return attr.getLiveVal();
			}
			if("val" in attr){
				return attr.val;
			}
			return "???";
		};
		
		//--------------------------------------------------------------------
		editObj.getNaviDocRoot=function(){
			return this;
		};
		
		//--------------------------------------------------------------------
		editObj.getNaviSubList=function(mode){
			let slist,tlist,i,n,attr,navi;
			tlist=[];
			slist=this.attrs.attrList;
			n=slist.length;
			for(i=0;i<n;i++){
				attr=slist[i];
				navi=attr.def.navi;
				if(!navi && attr.objDef){
					navi=attr.objDef.navi;
				}
				if(navi && navi===mode){
					tlist.push(attr);
				}
			}
			return tlist.length?tlist:null;
		};
		
		//--------------------------------------------------------------------
		editObj.getEditRootPpts=function(){
			if(this.def.edit===false){
				return null;
			}
			return [{obj:this,open:1}];
		};

		//--------------------------------------------------------------------
		let subChkVsn=1;
		editObj.getEditSubPpts=function(){
			let list,stub,objDef,attrsDef,attrDef,groupAttrs;
			let attrList,attr,attrHash,hasHint;
			attrList=this.attrList;
			attrHash=this.attrHash;
			objDef=this.objDef;
			attrsDef=objDef.attrs;
			subChkVsn+=1;
			list=this.objDef.listHint;
			hasHint=!!list;
			list=list?[...list]:[];
			for(stub of list){
				if(stub instanceof Object){
					groupAttrs=stub.attrs;
					for(attrDef of groupAttrs){
						attrDef=attrsDef[attrDef];
						attr=attrHash[attrDef.name];
						if(attr){
							attr.def.fixed=subChkVsn;
						}
					}
				}else{
					attrDef=attrsDef[stub];
					attr=attrHash[attrDef.name];
					if(attr){
						attr.def.fixed=subChkVsn;
					}else{
						attrDef.fixed=subChkVsn;
					}
				}
			}
			if(hasHint){
				for(attr of attrList){
					attrDef=attr.def;
					if(attrDef.fixed===subChkVsn){
						attrDef.fixed=1;
					}else{
						if(attr.def.edit!==false || attr.def.extraAttr){
							list.push(attr.name);
						}
					}
				}
			}else{
				for(attr of attrList){
					attrDef=attr.def;
					if(attrDef.fixed===subChkVsn){
						attrDef.fixed=1;
					}else{
						if(attr.def.edit!==false){
							list.push(attr.name);
						}
					}
				}
			}
			return list;
		};
		
		//--------------------------------------------------------------------
		editObj.naviPrjFocus=function(){
		};

		//--------------------------------------------------------------------
		editObj.naviPrjReady=function(){
		};

		//--------------------------------------------------------------------
		editObj.naviPrjBlur=function(){
		};

		//--------------------------------------------------------------------
		editObj.naviDocFocus=function(){
		};

		//--------------------------------------------------------------------
		editObj.naviDocReady=function(){
		};

		//--------------------------------------------------------------------
		editObj.naviDocBlur=function(){
		};
	}

	//------------------------------------------------------------------------
	editObj.exportCode=function(mode=""){
		let jsObj,code;
		jsObj=this.getJSObj(0,5,mode==="gearTypeAttr");
		code=JSON.stringify(jsObj);
		if(mode==="gearTypeAttr"){
			let pos0,pos1,pos2,seg;
			pos0=0;
			do{
				pos1=code.indexOf(`"#<<`,pos0);
				pos2=code.indexOf(`>>#"`,pos0);
				if(pos1>=0 && pos2>pos1){
					seg=code.substring(pos1,pos2+4);
					seg=JSON.parse(seg);
					code=code.substring(0,pos1)+seg.substring(3,seg.length-3)+code.substring(pos2+4);
					pos0=pos1;
				}else{
					pos0=-1;
				}
			}while(pos0>=0);
		}
		return code;
	};
	
	//------------------------------------------------------------------------
	editObj.getJSObj=function(deep=0,maxDeep=5,applyHyper=false){
		let list,i,n,attr,valText,pos;
		let jsObj={};
		deep+=1;
		if(deep>=maxDeep){
			return jsObj;
		}
		list=this.attrList;
		n=list.length;
		for(i=0;i<n;i++){
			attr=list[i];
			if(attr.getJSObj){
				jsObj[attr.name]=attr.getJSObj(deep,maxDeep,applyHyper);
			}else{
				if(applyHyper){
					valText=attr.valText;
					if(valText.startsWith("#")){
						pos=valText.lastIndexOf("#>");
						if(pos>0){
							jsObj[attr.name]=(`#<<${valText.substring(pos+2)}>>#`);
						}else{
							jsObj[attr.name]=(`#<<${valText.substring(1)}>>#`);
						}
					}else if(valText.startsWith("${")){
						pos=valText.lastIndexOf("}");
						if(pos>0){
							let traceText,code;
							code=`$P(()=>(${valText.substring(2,pos)})`;
							traceText=valText.substring(pos+1);
							code+=`${traceText.startsWith(",")?traceText:""})`;
							jsObj[attr.name]=`#<<${code}>>#`;
						}else{
							jsObj[attr.name]=`#<<$P(()=>(${valText.substring(2)}))>>#`;
						}
					}else{
						jsObj[attr.name]=attr.val;
					}
				}else{
					jsObj[attr.name]=attr.val;
				}
			}
		}
		return jsObj;
	};
	
	//------------------------------------------------------------------------
	editObj.genAttrDef=function(name,showName,icon,key=true,fixed=true){
		let objDef,attrsDef;
		objDef={
			type:"object",
			name:name,
			showName:showName||name,
			icon:icon,
			def:{
				attrs:this.genEditObjAttrsDef()
			},
			key:key,fixed:fixed
		};
		return objDef;
	};
	
	//------------------------------------------------------------------------
	editObj.genEditObjAttrsDef=function(){
		let attrsDef,attrList,i,n;
		let attrObj,attrName;
		attrsDef={};
		attrList=this.attrList;
		n=attrList.length;
		for(i=0;i<n;i++){
			attrObj=attrList[i];
			attrName=attrObj.name;
			attrsDef[attrName]=attrObj.genAttrDef(attrName,attrObj.def.showName||attrName,attrObj.def.icon,true,true);
		}
		return attrsDef;
	};
	
	//------------------------------------------------------------------------
	editObj.updateGenedAttrDef=function(attrDef){
		let tgtDef,orgDef,orgAttrs,tgtAttrs,tgtAttrHash,tgtAttr,name,orgAttrDef,tgtAttrDef,tgtAttrType,orgAttrType;
		let i,n;
		orgDef=attrDef.def;
		tgtDef=this.objDef;
		orgAttrs=orgDef.attrs;
		tgtAttrs=this.attrList;
		tgtAttrHash=this.attrHash;
		n=tgtAttrs.length;
		for(i=0;i<n;i++){
			tgtAttr=tgtAttrs[i];
			name=tgtAttr.name;
			tgtAttrDef=tgtAttr.def;
			orgAttrDef=orgAttrs[name];
			tgtAttrType=tgtAttrDef.type;
			if(!orgAttrDef){
				orgAttrDef=tgtAttr.genAttrDef(tgtAttr.name);
				orgAttrs[name]=orgAttrDef;
			}else{
				delete orgAttrs[name];//Make sure orders:
				orgAttrType=orgAttrDef.type;
				if(orgAttrType===tgtAttrDef.type){
					if(tgtAttr.updateGenedAttrDef){
						tgtAttr.updateGenedAttrDef(orgAttrDef);
					}else{
						orgAttrDef.initVal=tgtAttr.val;
					}
				}else{
					orgAttrDef=tgtAttr.genAttrDef(tgtAttr.name);
				}
				orgAttrs[name]=orgAttrDef;
			}
		}
		for(name in orgAttrs){
			if(!tgtAttrHash[name]){
				orgAttrDef=orgAttrs[name];
				delete orgAttrs[name];
				orgAttrDef.key=false;
				orgAttrDef.fixed=false;
			}
		}
	};
	
	//------------------------------------------------------------------------
	editObj.syncWithDef=function(addUnkey=false,removeMissed=false,removeUnkey=false){
		let objDef,defAttrs,attrHash,attrName,attrDef,attr,attrs,attrList,attrIndex,orgIndex;
		attrs=this.attrs;
		attrHash=this.attrHash;
		attrList=this.attrList;
		objDef=this.objDef;
		defAttrs=objDef.attrs;

		//First, check attrs for remove or update:
		{
			for(attrName in attrHash){
				attr=attrHash[attrName];
				attrDef=defAttrs[attrName];
				if(!attrDef){
					if(removeMissed){
						attrs.removeAttr(attrName,true);
					}else{
						//Not remove, but move this attr to end of attrList
						attrIndex=attrList.indexOf(attr);
						attrList.splice(attrIndex,1);
						attrList.push(attr);
					}
				}else{
					if(removeUnkey && !attrDef.key){
						attrs.removeAttr(attrName,true);
					}else if(attrDef!==attr.def){
						let valText,val,newAttr;
						if(attrDef.type==="array" && attr.def.type==="array" && attrDef.def.elementType===attr.objDef.elementType){
							//Stay same...
						}else{
							valText=attr.valText;val=attr.val;
							orgIndex=attrList.indexOf(attr);
							attrs.removeAttr(attrName,true);
							if(attrDef.key){
								newAttr=attrs.addAttrByDef(attrDef);
								attrIndex=attrList.indexOf(newAttr);
								attrList.splice(attrIndex,1);
								attrList.splice(orgIndex,0,newAttr);
							}
							if(attrDef.type===attr.def.type){
								newAttr.setValByText(valText);
							}
						}
					}else if(attrDef.type!==attr.def.type){
						let newAttr;
						orgIndex=attrList.indexOf(attr);
						attrs.removeAttr(attrName,true);
						if(attrDef.key){
							newAttr=attrs.addAttrByDef(attrDef);
							attrIndex=attrList.indexOf(newAttr);
							attrList.splice(attrIndex,1);
							attrList.splice(orgIndex,0,newAttr);
						}
					}else{
						if(attr.syncWithDef){
							attr.syncWithDef(addUnkey,removeMissed,removeUnkey);
						}
					}
				}
			}
		}

		//Add missing key attrs and make sure attr indexes:
		attrIndex=0;
		for(attrName in defAttrs){
			attrDef=defAttrs[attrName];
			attr=attrHash[attrName];
			if(attr){
				if(attrList[attrIndex]!==attr){
					//Adjust attr-index
					orgIndex=attrList.indexOf(attr);
					attrList.splice(orgIndex,1);
					attrList.splice(attrIndex,0,attr);
				}
				attrIndex++;
			}else{
				if(attrDef.key || addUnkey){
					//Add this attr at current attrIndex:
					attr=attrs.addAttrByDef(attrDef);
					orgIndex=attrList.indexOf(attr);
					attrList.splice(orgIndex,1);
					attrList.splice(attrIndex,0,attr);
					attrIndex++;
				}
			}
		}
	};
}

//----------------------------------------------------------------------------
//Reigster basic EditObj types:
EditObj.regObjectDef("Object",{
	name:"Object",icon:"object.svg",attrs:{},allowExtraAttr:1
});
EditObj.regObjectDef("StateObj",{
	name:"StateObj",icon:"hudstate.svg",attrs:{},allowExtraAttr:1
});
EditObj.regObjectDef("FlatObj",{
	name:"FlatObj",icon:"object.svg",attrs:{},allowExtraAttr:1,flatObj:true
});

export {EditAttrList,EditObj,EditObjProxy};

