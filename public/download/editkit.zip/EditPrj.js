import pathLib from "/@path";
import inherits from "/@inherits";
import {tabFS} from "/@tabos";
import {EditDoc} from "./editdoc/EditDoc.js";
import {EditAttr} from "./EditAttr.js";
import {EditObj} from "./EditObj.js";
import {EditArray} from "./EditArray.js";
import {EditAtom} from "./editdoc/EditAtom.js";
import {ExportObj} from "./exporters/ExportObj.js";
import {EditHudGear} from "./edithud/EditHudGear.js";
import {} from "./edithud/EditGearContainer.js";
import {EditHudObj} from "./edithud/EditHudObj.js";
import {} from "./edithud/EditHudAni.js";
import {exportTemplate} from "./exporters/DocTemplateExporter.js";
import {makeObjEventEmitter} from "/@events";
import {} from "./editdoc/EditDocs.js"; 
import {} from "./editdoc/EditMockupState.js";
import {$P,VFACT,callAfter} from "/@vfact";
import {EditDocExporter} from "./exporters/EditDocExporter.js";
const $ln=VFACT.lanCode;
//----------------------------------------------------------------------------
let EditPrjObjDef={
	name:"EditPrj",
	allowExtraAttr:0,
	attrs:{
		"externGearLibs":{
			name:"externGearLibs",showName:(($ln==="CN")?("导入的组件库"):/*EN*/("Imports")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:"prj",save:false,icon:"lib.svg",
			objAttrs:{
				isExternGearLibs:1,
				getNaviSubList:function(){
					return this.attrList.slice(0);
				}
			}
		},
		"cssFiles":{
			name:"cssFiles",showName:(($ln==="CN")?("预加载文件"):/*EN*/("Preload Files")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:"prj",save:false,icon:"files.svg",
			objAttrs:{
				isCSSFiles:1,
				getNaviSubList:function(){
					return this.attrList.slice(0);
				}
			}
		},
		"docConfig":{
			name:"docConfig",icon:"config.svg",showName:(($ln==="CN")?("App配置"):/*EN*/("App Config")),type:"docfile",def:"AppCfg",key:1,fixed:1,edit:false,navi:"prj",save:false
		},
		//"docTextLib":{name:"docTextLib",type:"docfile",def:"DocFile",key:1,fixed:1,edit:false,navi:1},
		"docDatas":{name:"docDatas",showName:(($ln==="CN")?("数据模块"):/*EN*/("Data Modules")),icon:"folder.svg",type:"object",def:"DocsObj",docType:"DataDoc",dir:"data",key:1,fixed:1,edit:false,navi:"prj"},
		"docGears":{name:"docGears",showName:(($ln==="CN")?("界面组件"):/*EN*/("UI Components")),icon:"folder.svg",type:"object",def:"DocsObj",docType:"hud",dir:"ui",key:1,fixed:1,edit:false,navi:"prj"},
		"docViews":{name:"docViews",showName:(($ln==="CN")?("UI 视图"):/*EN*/("UI Views")),icon:"folder.svg",type:"object",def:"DocsObj",docType:"view",dir:"ui",key:1,fixed:1,edit:false,navi:"prj"},
		"docApp":{
			name:"docApp",icon:"app.svg",showName:(($ln==="CN")?("App入口"):/*EN*/("Application Entry")),type:"docfile",def:"App",key:1,fixed:1,edit:false,navi:"prj",save:false
		},
		"docExternGears":{
			name:"docExternGears",type:"object",def:"Object",key:1,fixed:1,edit:false,save:false,
		},
		"docDataTemplates":{
			name:"docDataTemplates",type:"object",def:"Object",key:1,fixed:1,edit:false,save:false,
		},
		"docGearTemplates":{
			name:"docGearTemplates",type:"object",def:"Object",key:1,fixed:1,edit:false,save:false,
		},
		"docViewTemplates":{
			name:"docViewTemplates",type:"object",def:"Object",key:1,fixed:1,edit:false,save:false,
		},
		"language":{
			name:"language",type:"string",key:1,fixed:1,edit:false,save:false,initVal:"EN",icon:"web.svg"
		}
	}
};
let EditPrjAttrDef={
	name:"EditPrj",icon:"prj.svg",showName:(($ln==="CN")?("Cody 项目工程"):/*EN*/("Cody Project")),type:"object",def:EditPrjObjDef,key:1,fixed:1,
};

let EditPrj,editPrj;

//----------------------------------------------------------------------------
EditPrj=function(dataPrj){
	let dataDocs;
	this.prj=this;
	EditObj.call(this,null,EditPrjAttrDef,true);
	EditPrj.instance=this;
	this.dataPrj=dataPrj;
	this.app=dataPrj.app;
	this.config={
		framework:"vfact",//"vfact","vreact","v2ue",
		allowDynamicAttr:true,
		allowFace:true,
		allowFaceReplaceTraceAttr:true,
		allowDataClassInUI:true,
		vfactGearLibFile:false,
	};
	dataPrj.codyPrj=this;
	dataDocs=this.dataDocs=dataPrj.docs;
	dataPrj.editorOpts.lockCodySegs=true;//Lock code-segs
	
	this.liveDocs={};
	
	this.curNaviDoc=null;
	this.curEditRootObj=null;
	this.curEditSubObj=null;

	this.path=dataPrj.path;

	this.docConfig=this.getAttr("docConfig");
	this.objConfig=this.docConfig.getAttr("editObjs").getAttr("appCfg");

	this.docApp=this.getAttr("docApp");
	
	this.docDataTemplates=this.getAttr("docDataTemplates");
	this.docGearTemplates=this.getAttr("docGearTemplates");
	this.docViewTemplates=this.getAttr("docViewTemplates");
	
	this.externGearLibs=this.getAttr("externGearLibs");
	
	this.preloads=this.getAttr("cssFiles");
	
	this.prettySaveVO=true;
	
	dataPrj.on("SavePrj",()=>{
		this.savePrj();
	});
	dataDocs.on("FocusDoc",(doc)=>{
		this.dataDocFocused(doc);
	});
	dataDocs.on("BlurDoc",(doc)=>{
		this.dataDocBlured(doc);
	});
	
	this.onNotify("DocModifiedOutSide",()=>{
		window.alert("CodyEdit-managed document changed outside it's editor. You may need restart TabStudio to apply the correct changes.");
	});
	
	this.on("Language",()=>{
		let curDoc,editDoc;
		curDoc=dataDocs.hotDoc;
		if(curDoc){
			editDoc=curDoc.editDoc||curDoc.codyDoc;//TODO: Which one indeed?
			if(editDoc){
				if(editDoc.OnLanguageChange){
					editDoc.OnLanguageChange();
				}else{
					editDoc.updateHyperAttrs(true);
				}
			}
		}
	});
	
	this.docsToLoad=[];
};
EditPrj.instance=null;
EditPrj.boxNaviPrj=null;
EditPrj.boxNaviDoc=null;
EditPrj.boxEditObj=null;
EditPrj.docExporters={
	app:null,
	appCfg:null,
	dataClass:null,
	gear:null
};
window.EditPrj=EditPrj;

makeObjEventEmitter(EditPrj);
inherits(EditPrj,EditObj);
editPrj=EditPrj.prototype;

//****************************************************************************
//:Editor UI related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editPrj.focusDoc=function(doc){
		let dataDoc;
		dataDoc=doc.dataDoc;
		this.dataDocs.focusDoc(dataDoc);
	};
	
	//------------------------------------------------------------------------
	editPrj.setEditRootObj=function(newObj){
		let oldObj;
		oldObj=this.curEditRootObj;
		if(oldObj===newObj){
			return;
		}
		this.curEditRootObj=newObj;
		this.setEditSubObj(newObj);
		if(newObj){
			newObj.updateHyperAttrs(true);
		}
		this.emit("EditRootObj",newObj||null,oldObj);
	};
	
	//------------------------------------------------------------------------
	editPrj.selectEditSubObjList=function(list){
		this.emit("SelectSubObjList",list);
	};

	//------------------------------------------------------------------------
	editPrj.selectEditSubObj=function(newObj,cf=false){
		this.emit("SelectSubObj",newObj,cf);
	};

	//------------------------------------------------------------------------
	editPrj.setEditSubObj=function(newObj,addSelect=false){
		let oldObj;
		oldObj=this.curEditSubObj;
		if(oldObj===newObj){
			return;
		}
		this.curEditSubObj=newObj;
		this.emit("EditSubObj",newObj,oldObj,addSelect);
	};
	
	//------------------------------------------------------------------------
	editPrj.deselectEditSubObj=function(obj){
		let oldObj;
		oldObj=this.curEditSubObj;
		if(oldObj===obj){
			this.curEditSubObj=null;
		}
		this.emit("DeslectSubObj",obj,this.curEditSubObj);
	};
	
	//------------------------------------------------------------------------
	editPrj.dataDocFocused=function(dataDoc){
		let doc;
		doc=dataDoc.codyDoc||null;
		if(this.curFocusDoc===doc){
			return;
		}
		this.curNaviDoc=doc;
		this.setEditRootObj(doc);
		this.emit("FocusDoc",doc);
	};

	//------------------------------------------------------------------------
	editPrj.dataDocBlured=function(dataDoc){
		let doc=dataDoc.codyDoc||null;
		if(!doc){
			return;
		}
		if(this.curFocusDoc!==doc){
			return;
		}
		this.curNaviDoc=null;
	};
	//TODO: Code this:
}

//****************************************************************************
//:Edit attr related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editPrj.editAttr_CanImportDoc=function(doc,importPath){
		let docPath,importDoc;
		this.updateDocIndex();
		docPath=doc.getAttr("path").val;
		if(docPath===importPath){
			return false;
		}
		importDoc=this.liveDocs[importPath];
		if(importDoc){
			if(importDoc.hasImported(docPath)){
				return `${docPath} can't import ${importPath}, becuase ${importPath} or it's imported source file already imported ${docPath}`;
			}
			if(importDoc.docIndex>doc.docIndex){
				return `${docPath} can't import ${importPath}, becuase in your project, ${docPath} is loaded earlier than ${importPath}. Re-arrange file order in poject pannel and try again.`;
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_AddAttr=function(obj,def){
		let doc=obj.doc;
		let atom;
		let act=doc.startEditAction();
		{
			atom=EditAtom.addAttr(obj,def);
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return atom.attr;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_AddClipAttr=function(obj,attrVO,name){
		let newAttr,doc,atom;
		doc=obj.doc;
		if(attrVO.type==="clipAttr"){
			let act=doc.startEditAction();
			{
				//Add attr with new name:
				let def;
				def={...attrVO.def,initValText:attrVO.valText,initVal:attrVO.val};
				def.name=name;
				atom=EditAtom.addAttr(obj,def);
				doc.execEditAtom(atom);
				newAttr=atom.attr;

				//Set attr:
				//doc.execEditAtom(EditAtom.setAttrByText(obj,newAttr,attrVO.valText));
			}
			doc.endEditAction(act);
		}else if(attrVO.type==="clipObject"){
			let saveVO=attrVO.saveVO;
			let act=doc.startEditAction();
			{
				EditObj.forceNewJaxId(1);
				newAttr=EditAttr.loadFromVO(obj,saveVO,name);
				EditObj.forceNewJaxId(0);
				atom=EditAtom.addAttr(obj,newAttr);
				doc.execEditAtom(atom);
			}
			doc.endEditAction(act);
		}
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_SetAttrByText=function(obj,attr,text){
		let attrDef,execSetTextAtom;
		let doc=obj.doc;
		attrDef=attr.def;
		if(attrDef.checkAttrText && !(attrDef.checkAttrText.call(attr,text))){
			return;
		}
		let act=doc.startEditAction();
		{
			execSetTextAtom=attr.execSetTextAtom||attrDef.execSetTextAtom;
			if(execSetTextAtom){
				execSetTextAtom(EditAtom,doc,obj,attr,text);
			}else{
				doc.execEditAtom(EditAtom.setAttrByText(obj,attr,text));
			}
		}
		doc.endEditAction(act);
		return 1;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_setHudsAttrByText=function(huds,attrPath,text){
		let attr,attrDef,execSetTextAtom;
		let doc,hud,act;
		huds=Array.isArray(huds)?huds:[huds];
		hud=huds[0];
		if(!hud){
			return false;
		}
		doc=hud.doc;
		act=doc.startEditAction();
		for(hud of huds){
			attr=hud.getAttrByPath(attrPath);
			if(attr){
				attrDef=attr.def;
				if(attrDef.checkAttrText && !(attrDef.checkAttrText.call(attr,text))){
					continue;
				}
				execSetTextAtom=attr.execSetTextAtom||attrDef.execSetTextAtom;
				if(execSetTextAtom){
					execSetTextAtom(EditAtom,doc,attr.owner,attr,text);
				}else{
					doc.execEditAtom(EditAtom.setAttrByText(attr.owner,attr,text));
				}
			}
		}
		doc.endEditAction(act);
		return true;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_StartMoveHud=function(doc){
		doc.startEditAction();
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_MoveOneHud=function(hudObj,txtX,txtY,txtW,txtH){
		let doc=hudObj.doc;
		let ppts;
		ppts=hudObj.properties;
		if(txtX!==null){
			doc.execEditAtom(EditAtom.setAttrByText(ppts,"x",txtX));
		}
		if(txtY!==null){
			doc.execEditAtom(EditAtom.setAttrByText(ppts,"y",txtY));
		}
		if(!hudObj.isHudGear){
			if(txtW!==null){
				doc.execEditAtom(EditAtom.setAttrByText(ppts,"w",txtW));
			}
			if(txtH!==null){
				doc.execEditAtom(EditAtom.setAttrByText(ppts,"h",txtH));
			}
		}else{
			let attr,args;
			args=hudObj.createArgs;
			if(txtW!==null){
				//Find w-attr-control:
				attr=ppts.getAttr("w")||args.getAttr("w")||args.getAttr("width");
				if(attr){
					doc.execEditAtom(EditAtom.setAttrByText(attr.owner,attr.name,txtW));
				}
			}
			if(txtH!==null){
				//Find h-attr-control:
				attr=ppts.getAttr("h")||args.getAttr("h")||args.getAttr("height");
				if(attr){
					doc.execEditAtom(EditAtom.setAttrByText(attr.owner,attr.name,txtH));
				}
			}
		}
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_EndMoveHud=function(doc){
		doc.endEditAction();
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_AddSubHud=function(obj,def,x,y,pfw=0,pfh=0,pfId=""){
		let attr;
		let doc,importDoc,docPath;
		doc=obj.doc;
		docPath=doc.getAttr("path").val;
		importDoc=def.source;
		if(importDoc){//Check imports:
			if(importDoc===docPath){
				return null;
			}
			importDoc=this.liveDocs[importDoc];
			if(importDoc && importDoc.hasImported(docPath)){
				return null;
			}
		}
		let act=doc.startEditAction();
		{
			let atom,cntLayoutAttr;
			//Adjust child's position and x,y based on owner's content-layout:
			if(obj.isHudObj){
				cntLayoutAttr=obj.properties.getAttr("contentLayout");
				cntLayoutAttr=cntLayoutAttr?cntLayoutAttr.val:"";
			}else if(obj.isGearSlot){
				cntLayoutAttr=obj.def.contentLayout;
			}else{
				cntLayoutAttr=null;
			}
			atom=EditAtom.addAttr(obj.subHuds,{type:"hudobj",def:def,navi:"doc"});
			doc.execEditAtom(atom);
			attr=atom.attr;
			if(attr){
				if(def.fixPose){
					if(cntLayoutAttr){
						attr.properties.setAttrByText("position","relative");
					};
				}else{
					//Adjust position 
					if(cntLayoutAttr){
						attr.properties.setAttrByText("position","relative");
						attr.properties.setAttrByText("x","0");
						attr.properties.setAttrByText("y","0");
					}else{
						if(Number.isFinite(x) && Number.isFinite(y)){
							attr.properties.setAttrByText("x",""+x);
							attr.properties.setAttrByText("y",""+y);
						}
					}
					if(pfId){
						if(attr.properties.getAttr("id")){
							attr.properties.setAttrByText("id",pfId);
						}
					}
					//Adjust size:
					if(pfw||pfh){
						if(attr.properties.getAttr("w")){
							attr.properties.setAttrByText("w",""+pfw);
						}else if(attr.getAttrDef("w")){
							attr.properties.setAttrByText("w",""+pfw,true);
						}else if(attr.createArgs){
							if(attr.createArgs.getAttr("w")){
								attr.createArgs.setAttrByText("w",""+pfw);
							}else if(attr.createArgs.getAttr("width")){
								attr.createArgs.setAttrByText("width",""+pfw);
							}else if(attr.createArgs.getAttr("sizeW")){
								attr.createArgs.setAttrByText("sizeW",""+pfw);
							}else if(attr.createArgs.getAttr("size")){
								attr.createArgs.setAttrByText("size",""+pfw);
							}
						}
						if(attr.properties.getAttr("h")){
							attr.properties.setAttrByText("h",""+pfh);
						}else if(attr.getAttrDef("h")){
							attr.properties.setAttrByText("h",""+pfh,true);
						}else if(attr.createArgs){
							if(attr.createArgs.getAttr("h")){
								attr.createArgs.setAttrByText("h",""+pfh);
							}else if(attr.createArgs.getAttr("height")){
								attr.createArgs.setAttrByText("height",""+pfh);
							}else if(attr.createArgs.getAttr("sizeH")){
								attr.createArgs.setAttrByText("sizeH",""+pfh);
							}
						}
					}else if(def.withFillType){
						switch(def.curEditFillType){
							case "size_all":
								attr.properties.setAttrByText("w",`100%`);
								attr.properties.setAttrByText("h",`100%`);
								attr.properties.setAttrByText("x","0");
								attr.properties.setAttrByText("y","0");
								break;
							case "size_w":
								attr.properties.setAttrByText("w",`100%`);
								attr.properties.setAttrByText("x","0");
								break;
							case "size_h":
								attr.properties.setAttrByText("h",`100%`);
								attr.properties.setAttrByText("y","0");
								break;
						}
					}
				}
			}
		}
		doc.endEditAction(act);
		return attr;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_PasteHud=function(curObj){
		let doc,savedList,hudAttr,subHuds,atom,newHuds;
		savedList=EditPrj.copiedHudItems;
		if(!savedList || !savedList.length){
			return;
		}
		newHuds=[];
		doc=curObj.doc;
		subHuds=curObj.subHuds;
		let act=doc.startEditAction();
		{
			let i,n,vo,len;
			len=subHuds.attrList.length;
			n=savedList.length;
			for(i=0;i<n;i++){
				vo=savedList[i];
				if(vo instanceof EditHudObj){
					vo.owner=subHuds;
					atom=EditAtom.addAttr(subHuds,vo);
					doc.execEditAtom(atom);
					newHuds.push(vo);
					savedList[i]=vo.genSaveVO();//Replace with copied save-vo
				}else{
					//This is copied item:
					EditObj.forceNewJaxId(1);
					hudAttr=EditAttr.loadFromVO(subHuds,savedList[i],i);
					hudAttr.def.navi="doc";
					EditObj.forceNewJaxId(0);
					atom=EditAtom.addAttr(subHuds,hudAttr);
					doc.execEditAtom(atom);
					newHuds.push(hudAttr);
				}
			}
		}
		doc.endEditAction(act);
		return newHuds;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_RenameAttr=function(obj,attr,text){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			doc.execEditAtom(EditAtom.renameAttr(obj,attr,text));
		}
		doc.endEditAction(act);
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_CommentAttr=function(obj,attr,text){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			doc.execEditAtom(EditAtom.commentAttr(obj,attr,text));
		}
		doc.endEditAction(act);
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_ResetAttrType=function(obj,attr,newType){
		let doc=obj.doc;
		let newAttr,oldDef,def,valText;
		valText=attr.valText;
		oldDef=attr.def;
		if(attr.key){
			return 0;
		}
		if(attr.attrList){
			return 0;
		}
		if(typeof(newType)==="object"){
			def={...oldDef,...newType,name:attr.name};
		}else{
			def={...oldDef,name:attr.name,type:newType};
		}
		newAttr=EditAttr.newAttr(obj,def,false);
		if(!newAttr){
			return;
		}
		newAttr.setValByText(valText);
		let act=doc.startEditAction();
		{
			doc.execEditAtom(EditAtom.replaceAttr(obj,newAttr));
			//doc.execEditAtom(EditAtom.setAttrByText(obj,newAttr,valText));
		}
		doc.endEditAction(act);
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_RemoveAttr=function(obj,attr){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			doc.execEditAtom(EditAtom.removeAttr(obj,attr));
		}
		if(attr===this.curEditSubObj){
			this.setEditSubObj(null);
			//this.curEditSubObj=null;
		}
		doc.endEditAction(act);
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_RemoveAttrList=function(attrList){
		let doc,obj,attr;
		if(!attrList || !attrList.length){
			return 0;
		}
		doc=attrList[0].owner.doc;
		let act=doc.startEditAction();
		{
			for(attr of attrList){
				obj=attr.owner;
				doc.execEditAtom(EditAtom.removeAttr(obj,attr));
				if(attr===this.curEditSubObj){
					this.setEditSubObj(null);
					//this.curEditSubObj=null;
				}
			}
		}
		doc.endEditAction(act);
		return 1;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_MoveUpAttr=function(obj,attr){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			if(Array.isArray(attr)){
				let list=attr;
				for(attr of list){
					if(!doc.execEditAtom(EditAtom.moveUpAttr(obj,attr))){
						doc.endEditAction();
						return 0;
					}
				}
			}else{
				doc.execEditAtom(EditAtom.moveUpAttr(obj,attr));
			}
		}
		doc.endEditAction(act);
		return 1;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_MoveDownAttr=function(obj,attr){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			if(Array.isArray(attr)){
				let list=attr;
				for(attr of list){
					if(!doc.execEditAtom(EditAtom.moveDownAttr(obj,attr))){
						doc.endEditAction();
						return 0;
					}
				}
			}else{
				doc.execEditAtom(EditAtom.moveDownAttr(obj,attr));
			}
		}
		doc.endEditAction(act);
		return 1;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_LocalizeAttr=function(obj,attr){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			doc.execEditAtom(EditAtom.localizeAttr(obj,attr));
		}
		doc.endEditAction(act);
		return 1;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_SetAttrLocalize=function(obj,attr,locObj){
		let doc=obj.doc;
		let act=doc.startEditAction();
		{
			if(!attr.localize){
				doc.execEditAtom(EditAtom.localizeAttr(obj,attr));
			}
			doc.execEditAtom(EditAtom.setAttrLocObj(obj,attr,locObj));
		}
		doc.endEditAction(act);
		return 1;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_applyMockupState=function(mockup){
		let doc,atom;
		doc=mockup.doc;
		let act=doc.startEditAction();
		{
			atom=EditAtom.applyMockupState(mockup);
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return true;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_syncMockupState=function(attr){
		let def,mockName,newAttr;
		mockName=attr.name;
		def={name:mockName,type:"mockState"};
		let doc=attr.doc;
		let atom;
		newAttr=EditAttr.newAttr(doc.mockupStates,def,true);
		let act=doc.startEditAction();
		{
			atom=EditAtom.applyAttrObj(attr.owner,attr,newAttr);
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return attr;
	};
}

//****************************************************************************
//:Edit flow segs:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editPrj.editAttr_AddFlowSeg=function(segs,def,x,y){
		let attr;
		let doc;
		doc=segs.doc;
		let act=doc.startEditAction();
		{
			let atom,segType;
			segType=segs.def.def.elementType;
			//Adjust child's position and x,y based on owner's content-layout:
			atom=EditAtom.addAttr(segs,{type:segType,def:def,navi:"doc"});
			doc.execEditAtom(atom);
			attr=atom.attr;
			if(Number.isFinite(x) && Number.isFinite(y)){
				attr.setAttrByText("x",""+x);
				attr.setAttrByText("y",""+y);
			}
		}
		doc.endEditAction(act);
		return attr;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_AddFlowOutlet=function(outlets,def){
		let attr;
		let doc;
		doc=outlets.doc;
		let act=doc.startEditAction();
		{
			let atom;
			//Adjust child's position and x,y based on owner's content-layout:
			atom=EditAtom.addAttr(outlets,{type:"aioutlet",def:def,navi:"doc"});
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return attr;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_MoveFlowSeg=function(seg,x,y,multiDrag=false){
		let doc,act;
		doc=seg.doc;
		if(!multiDrag){
			act=doc.startEditAction();
		}
		{
			let attrDef,execSetTextAtom;
			attrDef=seg.def;
			execSetTextAtom=seg.execSetTextAtom||attrDef.execSetTextAtom;
			if(execSetTextAtom){
				execSetTextAtom(EditAtom,doc,seg,"x",""+x);
				execSetTextAtom(EditAtom,doc,seg,"y",""+y);
			}else{
				doc.execEditAtom(EditAtom.setAttrByText(seg,"x",""+x));
				doc.execEditAtom(EditAtom.setAttrByText(seg,"y",""+y));
			}
		}
		if(!multiDrag){
			doc.endEditAction(act);
		}
		return seg;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_PasteFlowSeg=function(segs,vo,x,y){
		let doc,savedList,atom,newSeg;
		//TODO:Choose paste target:
		doc=segs.doc;
		let act=doc.startEditAction();
		{
			//This is copied item:
			EditObj.forceNewJaxId(1);
			newSeg=EditAttr.loadFromVO(segs,vo);
			newSeg.postLoadLink(true);
			newSeg.def.navi="doc";
			newSeg.setAttrByText("x",""+x);
			newSeg.setAttrByText("y",""+y);
			EditObj.forceNewJaxId(0);
			atom=EditAtom.addAttr(segs,newSeg);
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return newSeg;
	};

	//------------------------------------------------------------------------
	editPrj.editAttr_PasteAIOutlet=function(curObj,vo){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_LinkSeg=function(outlet,toSeg,render){
		let doc;
		doc=outlet.doc;
		let act=doc.startEditAction();
		{
			let atom,exec,undo,redo,oldSeg;
			toSeg=toSeg||null;
			oldSeg=outlet.linkedSeg||null;
			exec=redo=()=>{
				if(oldSeg){
					oldSeg.removeLinkedOutlet(outlet);
				}
				outlet.linkedSeg=toSeg;
				if(toSeg){
					toSeg.linkOutlet(outlet);
				}
				if(render){
					outlet.renderPath();
				}
				render=true;
				return true;
			};
			undo=()=>{
				if(toSeg){
					toSeg.removeLinkedOutlet(outlet);
				}
				outlet.linkedSeg=oldSeg;
				if(oldSeg){
					oldSeg.linkOutlet(outlet);
				}
				if(render){
					outlet.renderPath();
				}
				return true;
			}
			atom=EditAtom.funcAtom(doc,exec,undo,redo);
			doc.execEditAtom(atom);
		}
		doc.endEditAction(act);
		return true;
	};
	
	//------------------------------------------------------------------------
	editPrj.editAttr_UnkinkSeg=function(fromOutlet){
		//TODO: Code this:
	};

}

//****************************************************************************
//:I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	editPrj.savePrj=async function(){
		let path,vo;
		path=pathLib.join(this.path,"cody.project.json");
		vo=await this.genSaveVO();
		await tabFS.writeFile(path,JSON.stringify(vo,null,"\t"),"utf8");

		//Save gears.json:
		path=pathLib.join(this.path,"gears.json");
		vo=this.genGearsExportVO();
		await tabFS.writeFile(path,JSON.stringify(vo,null,"\t"),"utf8");
		let docApp=this.docApp.dataDoc;
		if(docApp.isChanged()){
			docApp.saveDoc();
		}
	};
	
	//------------------------------------------------------------------------
	editPrj.genSaveVO=function(){
		let saveVO,exGearLibs,docs,doc,files;
		saveVO=EditObj.prototype.genSaveVO.call(this);
		exGearLibs=this.getAttr("externGearLibs").attrHash;
		exGearLibs=Object.keys(exGearLibs);
		saveVO.externGearLibs=exGearLibs;
		files=this.getAttr("cssFiles").attrList;
		files=files.filter((item)=>{return !item.def.external}).map((item)=>{return item.attrPath});
		saveVO.preloadFiles=files;
		//TODO: Localize
		return saveVO;
	};
	
	//------------------------------------------------------------------------
	editPrj.genGearsExportVO=function(){
		let config,framework,docList,doc,vo,expose,gearDef,rootPath,path,docType,libJSPath;
		let saveVO,gearIdxes,tempVO;
		let datas,editClasses,i,n,classObj,briefVO;
		let exGearLibs,files,docApp,fonts,fontList,fontAttr,fontURL;
		rootPath=this.path;
		config=this.config;
		framework=config.framework;
		saveVO={
			version:"1.0.0",
			libs:null,
			preloads:null,
			fonts:null,
			datas:{},
			views:{},
			gears:{},
			gearIndexes:{
			},
			templates:{}
		};
		//Export fonts:
		docApp=this.docApp;
		fontList=docApp.getAttr("fonts").attrList;
		if(fontList.length>0){
			fonts=[];
			for(fontAttr of fontList){
				fontURL=fontAttr.fontURL.val;
				if(fontURL.startsWith("/~/")){
					if(fontURL.substring(2).startsWith(this.path)){
						fontURL=fontURL.substring(this.path.length+3);
					}
				}else if(fontURL.startsWith(this.path)){
					fontURL=fontURL.substring(this.path.length+1);
				}
				fonts.push({name:fontAttr.name,url:fontURL});
			}
			saveVO.fonts=fonts;
		}
		
		
		//Export all libs used:
		exGearLibs=this.getAttr("externGearLibs").attrHash;
		exGearLibs=Object.keys(exGearLibs);
		saveVO.libs=exGearLibs;
		
		//Export all preload files:
		files=this.getAttr("cssFiles").attrList;
		files=files.map((item)=>{return item.attrPath});
		saveVO.preloads=files;
		
		//Export all DataClass and mockups:
		datas=saveVO.datas;
		docList=this.getAttr("docDatas").attrList;
		for(doc of docList){
			editClasses=doc.getAttr("editObjs").attrList;
			n=editClasses.length;
			for(i=0;i<n;i++){
				classObj=editClasses[i];
				if(classObj.getAttrVal("exportClass")){
					briefVO=classObj.genBriefSaveVO();
					datas[classObj.name]=briefVO;
				}
			}
		}
		
		//Exposed gears:
		gearIdxes=saveVO.gearIndexes;
		tempVO=saveVO.templates;
		vo=saveVO.gears;
		docList=this.getAttr("docGears").attrList;
		docList=docList.concat(this.getAttr("docViews").attrList);
		for(doc of docList){
			docType=doc.getAttr("exportTarget");
			path=doc.getAttr("path").val;
			if(path.startsWith(rootPath)){
				path=path.substring(rootPath.length+1);
				if(framework==="vfact"){
					libJSPath=path;
				}else{
					let dirPath,baseName,ext;
					dirPath=pathLib.dirname(path);
					baseName=pathLib.basename(path);
					ext=pathLib.extname(path);
					if(ext!==".js"){
						baseName=baseName.substring(0,baseName.length-ext.length)+".js";
					}
					libJSPath=pathLib.join(dirPath,"lib",baseName);
				}
				//Gear idx:
				gearIdxes["Gear"+doc.jaxId]={
					path:libJSPath,
					expose:expose
				};
				//Gear expose
				expose=doc.exposeGear&&doc.exposeGear.val;
				if(expose){
					gearDef=doc.exposedGearDef;
					if(gearDef){
						vo[gearDef.importName]={
							name:gearDef.importName,
							path:libJSPath,
							icon:gearDef.icon,
							showName:gearDef.showName||gearDef.importName,
							catalog:gearDef.catalog||""
						}
					}
				}
				//Template expose:
				expose=doc.exposeTemplate&&doc.exposeTemplate.val;
				if(expose){
					let info,name,icon,showName;
					info=doc.getAttr("description").val||"";
					icon=doc.getAttr("gearIcon").val||"gears.svg";
					name=pathLib.basename(path,".js");
					showName=doc.getAttr("gearName").val||name;
					tempVO[path]={
						template:true,
						name:"Template"+doc.jaxId,
						showName:showName,
						path:path,
						description:info,
						icon:icon,
						catalog:doc.owner.name==="docGears"?"GearTemplates":"ViewTemplates",
					};
				}
			}
		}
		
		//Exposed flow functions:
		
		//TODO: export exposed templates, datas:
		return saveVO;
	};

	//------------------------------------------------------------------------
	editPrj.loadPrj=async function(){
		let path,text,vo,prjCfg;
		let codyPath;
		prjCfg=this.dataPrj.prjConfig.editKit||{};
		path=this.path;
		Object.assign(this.config,prjCfg);
		codyPath=pathLib.join(path,"cody.project.json");
		//Set file/dir path:
		this.docConfig.setAttrByText("path",pathLib.join(path,"cfg/appCfg.js"));
		this.docApp.setAttrByText("path",pathLib.join(path,"app.js"));
		try{
			text=await tabFS.readFile(codyPath,"utf8");
		}catch(err){
			//Empty Project? create dirs and basic files:
			await tabFS.newDir(pathLib.join(path,"cfg"));
			await tabFS.newDir(pathLib.join(path,"text"));
			await tabFS.newDir(pathLib.join(path,"ui"));
			//Key file: appCfg.js
			await this.docConfig.loadDoc();
			await this.docConfig.saveDoc();
			await this.docApp.loadDoc();
			await this.docApp.saveDoc();
			return this.savePrj();
		}
		vo=JSON.parse(text);
		await this.loadFromVO(vo);
		this.postLoad();
		this.updateHyperAttrs();
		this.emit("PrjLoaded");
	};

	//------------------------------------------------------------------------
	editPrj.addDocToLoad=function(doc){
		this.docsToLoad.push(doc);
	};
	
	//------------------------------------------------------------------------
	editPrj.loadFromVO=async function(vo){
		let doc,lib,libs,def,stub,docs,dataPrj,files,path;
		dataPrj=this.dataPrj;
		this.muteNotify();
		//TODO: load localize info first?
		//load config:
		doc=this.docConfig;
		await doc.loadDoc();
		
		//Load extern gearLibs:
		libs=vo.externGearLibs;
		if(libs){
			for(lib of libs){
				dataPrj.emit("LoadInfo",(($ln==="CN")?(`加载外部库: ${lib}`):/*EN*/(`Loading external lib: ${lib}`)));
				def=await this.addExternGearLib(lib,false);
			}
		}
		
		//Load preload files:
		files=vo.preloadFiles;
		if(files){
			for(path of files){
				if(!path.startsWith("/")){
					path=this.path+"/"+path;
				}
				await this.addPreloadFile(path);
			}
		}
		
		//Load from vo, all doc will register it's cody:
		EditObj.prototype.loadFromVO.call(this,vo);
		
		//Load doc objects:
		docs=this.docsToLoad;
		for(doc of docs){
			dataPrj.emit("LoadInfo",(($ln==="CN")?(`正在加载文档：${doc.path}`):/*EN*/(`Loading document: ${doc.path}`)));
			await doc.loadDoc();
		};

		doc=this.docApp;
		await doc.loadDoc();
		
		this.unmuteNotify();
	};
}

//****************************************************************************
//Add new doc, load doc, load extern gear lib:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Add/import a new DataDoc file:
	editPrj.addDataDocFile=async function(owner,fileName,path,isImport=false){
		let def,docDef,fullPath,dataDoc,editDoc;
		if(path.startsWith(this.path)){
			path=path.substring(this.path.length+1);
		}
		owner=owner||this.getAttr("docDatas");
		docDef=owner.def.docType||owner.objDef.docDef||"DataDoc";
		def={name:fileName,type:"docfile",def:docDef,extraAttr:1,navi:"prj"};
		editDoc=owner.addAttr(def);
		if(editDoc){
			editDoc.setAttrByText("path",path);
			await editDoc.loadDoc();
			//Add default class:
			if(!isImport){
				let editObjs,name;
				name=pathLib.basename(fileName).substring(0,fileName.indexOf("."));
				editObjs=editDoc.getAttr("editObjs");
				def={name:name,type:"objclass",def:"ObjClass",key:1,fixed:1};
				editObjs.addAttr(def);
				editDoc.updateDocText(false);
				await editDoc.saveDoc();
			}
			this.savePrj();
		}
		fullPath=pathLib.join(this.path,path);
		this.liveDocs[fullPath]=editDoc;
		dataDoc=editDoc.dataDoc;
		if(dataDoc){
			let dataDocs=this.dataDocs;
			dataDocs.emit("NewDoc",dataDoc);
			dataDocs.focusDoc(dataDoc);
		}
		return editDoc;
	};
	
	//------------------------------------------------------------------------
	//Add new or load existing component or ui-view:
	editPrj.addHudDocFile=async function(owner,fileName,path,baseHudDef,oneHud){
		let def,docAttr,docDef,hudType,dataDoc;
		if(baseHudDef){
			if(baseHudDef.template){
				//Generate templated new file:
				await exportTemplate(baseHudDef.path,path,baseHudDef.internal);
				return await this.addHudDocFile(owner,fileName,path,null,null);
			}else{
				hudType=baseHudDef.name;
				docDef=baseHudDef.gearDocDef||"GearHud";
				def={name:fileName,type:"docfile",def:docDef,extraAttr:oneHud?0:1,navi:"prj"};
				docAttr=owner.addAttr(def);
				if(docAttr){
					docAttr.setAttrByText("path",path);
					if(oneHud){
						docAttr.setAttrByText("oneHud","true");
					}
					await docAttr.loadDoc();
					await docAttr.saveDoc();
					this.savePrj();
					if(!path.startsWith("/")){
						path=pathLib.join(this.path,path);
					}
					this.liveDocs[path]=docAttr;
					dataDoc=docAttr.dataDoc;
					if(dataDoc){
						let dataDocs=this.dataDocs;
						dataDocs.emit("NewDoc",dataDoc);
						dataDocs.focusDoc(dataDoc);
					}
					return docAttr;
				}
			}
		}else{
			let code,pos,pos2,defText;
			code=await tabFS.readFile(path,"utf8");
			if(!code){
				return false;
			}
			pos=code.indexOf("\/\*Cody Project Doc\*\/");
			if(pos<0){
				return false;
			}
			pos=code.indexOf('"def":',pos);
			if(pos<0){
				return false;
			}
			pos2=code.indexOf('",',pos);
			if(pos2<0){
				return false;
			}
			defText=code.substring(pos+'"def":'.length,pos2+1);
			docDef=JSON.parse(defText.trim());
			docDef=docDef||"GearHud";
			def={name:fileName,type:"docfile",def:docDef,extraAttr:1,navi:"prj"};
			docAttr=owner.addAttr(def);
			if(docAttr){
				let doc;
				docAttr.setAttrByText("path",path);
				await docAttr.loadDoc();
				await docAttr.saveDoc();
				this.savePrj();
				//OpenDoc:
				doc=await this.dataDocs.openDoc(path);
				if(doc){
					this.dataDocs.focusDoc(doc);
				}
				//EditPrj.emit("NewDoc",docAttr);
				return true;
			}
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	editPrj.addExternGearLib=async function(pkgName,savePrj=true){
		let res,prjJSON,gearsJSON,tmpJSON,name,def,path,cnt;
		let tmpAttrDef,tmpAttr,newTemps=[];
		let datasJSON,classVO;
		let libs,files,fonts;
		let libVersion=null;
		
		console.log("addExternGearLib: "+pkgName);
		
		function mergeCfgObj(orgObj,objAttr){
			let proxy,objProxy;
			let attrName,attr;
			for(attrName in orgObj){
				attr=objAttr.getAttr(attrName);
				if(!attr){
					objAttr.addAttr({name:attrName,type:"auto",initVal:orgObj[attrName],key:1});
				}
			}
			objProxy=objAttr.selfProxy;
			proxy=new Proxy(orgObj,{
				get:function(tgt,key){
					var attr;
					if(key===Symbol.toPrimitive){
						return ()=>"{object}";
					}
					attr=objProxy[key];
					if(attr!==undefined){
						return attr;
					}
					return orgObj[key];
				},
				set:function(tgt,key,val){
					throw new Error(`Can not set attrib "${key}" on EditObjProxy.`);
				}
			});
			return proxy;
		};
		if(!pkgName.startsWith("/@")){
			pkgName="/@"+pkgName;
		}
		
		if(this.getAttr("externGearLibs").getAttr(pkgName)){
			//Already loaded...
			return true;
		}
		res=await fetch(`${pkgName}/gears.json`);
		if(!res.ok){
			return false;
		}
		prjJSON=await res.json();
		libVersion=prjJSON.version||null;
		
		//load libs:
		libs=prjJSON.libs;
		if(libs){
			for(path of libs){
				await this.addExternGearLib(path,false);
			}
		}
		
		//load fonts:
		fonts=prjJSON.fonts;
		if(fonts){
			let docApp,fontsAttr,fontVO,attrDef,fontAttr,fontPath;
			docApp=this.docApp;
			fontsAttr=docApp.getAttr("fonts");
			for(fontVO of fonts){
				fontPath=fontVO.url;
				if(!fontPath.startsWith("/")){
					fontPath=`${pkgName}/${fontPath}`;
				}
				fontAttr=fontsAttr.getAttr(fontVO.name);
				if(!fontAttr){
					//Add this font
					attrDef={name: fontVO.name, key:1, fixed:1, type: 'font', def: 'Font'};
					fontAttr=fontsAttr.addAttr(attrDef);
					fontAttr.fontURL.setValByText(fontPath);
				}else{
					//Check URL:
					if(fontAttr.fontURL.val!==fontPath){
						console.log("Found duplicated font name: "+fontVO.name);
						console.log(`Font path: "${fontPath}" vs "${fontAttr.fontURL.val}"`);
					}
				}
			}
		}
		
		//load preload files:
		files=prjJSON.preloads;
		if(files){
			for(path of files){
				if(path[0]!=="/"){
					path=pathLib.join(pkgName,path);
				}
				this.addPreloadFile(path,true);
			}
		}
		
		//First, appy config:
		{
			let cfgMod,cfgObj,orgObj,appCfg,prjAttr,cfgProxy,orgAttr,cfgAttr;
			appCfg=this.docConfig.getAttr("editObjs").getAttr("appCfg");
			cfgMod=await import(pkgName+"/cfg/appCfg.js");
			cfgObj=cfgMod.appCfg;
			
			cfgProxy=new Proxy(cfgObj,{
				get:function(tgt,key){
					let attr;
					if(key===Symbol.toPrimitive){
						return ()=>"{object}";
					}
					attr=appCfg.getAttr(key);
					if(attr){
						return attr.selfProxy||attr.val;
					}
					return cfgObj[key];
				},
				set:function(tgt,key,val){
					cfgObj[key]=val;
					return val;
				}
			});
			cfgObj.proxyCfg(cfgProxy);
			
			//Merge major cfg items:
			for(name in cfgObj){
				orgAttr=cfgObj[name];
				cfgAttr=appCfg.getAttr(name);
				if(typeof(orgAttr)==="object"){
					if(!cfgAttr){
						cfgAttr=appCfg.addAttr({name:name,type:"object",def:"Object",key:0,fixed:0});
					}
					if(cfgAttr.def.type==="object"){
						cfgObj[name]=mergeCfgObj(orgAttr,cfgAttr);
					}
				}else if(typeof(orgAttr)==="function"){
					//Do nothing					
				}else{
					if(!cfgAttr){
						appCfg.addAttr({name:name,type:"auto",initVal:orgAttr,key:0,fixed:0});
					}
				}
			}
		}
		
		//Load DataClass:
		datasJSON=prjJSON.datas;
		for(name in datasJSON){
			classVO=datasJSON[name];
			this.addExternDataClass(name,classVO,datasJSON);
		}
		
		cnt=0;
		gearsJSON=prjJSON.gears;
		if(libVersion===null){
			//Old CCEdit lib, add gears:
			for(name in gearsJSON){
				def=gearsJSON[name];
				path=def.path;
				path=path.replace("ui/lib/","ui/");
				if(path){
					await this.addExternGear(`${pkgName}/${path}`,pkgName);
					cnt++;
				}
			}
		}else{
			//Add gears:
			for(name in gearsJSON){
				def=gearsJSON[name];
				path=def.path;
				if(path){
					await this.addExternGear(`${pkgName}/${path}`,pkgName);
					cnt++;
				}
			}
		}
		//add gear templates
		tmpJSON=prjJSON.templates;
		for(name in tmpJSON){
			def=tmpJSON[name];
			await this.addExternTemplate(pkgName,def);
			cnt++;
		}
		//TODO: add data templates:
		
		//update extern lib attr:
		if(cnt>0){
			let cfgMod,cfgObj,orgObj,appCfg,prjAttr,cfgProxy,orgAttr,cfgAttr;
			
			prjAttr=this.getAttr("externGearLibs").addAttr({
				name:pkgName,showName:pkgName,type:"object",extraAttr:1,edit:false,
				def:{
					attrs:{
						path:{name:"path",type:"string",initVal:pkgName,key:1,fixed:1}
					}
				}
			});
			if(savePrj){
				this.savePrj();
			}
			prjAttr.libPath=pkgName;
			prjAttr.gearHash=prjJSON.gearIndexes;
			
			for(let tmp of newTemps){
				tmp.lib=prjAttr;
			}
			return true;
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	editPrj.addExternDataClass=function(className,classVO,datasJSON){
		EditAttr.loadFromVO(this,classVO,className,datasJSON);
	};
	
	//------------------------------------------------------------------------
	editPrj.addExternGear=async function(path,pkgPath){
		let def;
		def=await EditHudGear.genExteralGearDef(path);
		if(def){
			def.pkgPath=pkgPath;
			if(def.previewImg){
				if(def.previewImg==="false"){
					def.previewImg=false;
				}else{
					def.previewImg=pathLib.join(pkgPath,"assets",def.previewImg);
				}
			}
			if(def.catalog){
				EditHudObj.regCatalogHudDef(def.catalog,def.name,def);
			}
			EditHudObj.regCatalogHudDef("ExternGears",def.name,def);
			EditHudObj.regHudDef(def.name,def);
			{
				let name,dirName,baseName;
				name=def.name;
				dirName=pathLib.dirname(name);
				baseName=pathLib.basename(name);
				name=pathLib.join(dirName,"lib",baseName);
				EditHudObj.regHudDef(name,def);
			}
			//TODO:
			this.getAttr("docExternGears").addAttr({name:path,showName:pathLib.basename(path),type:"path",initVal:path,navi:"prj",extraAttr:1});
		}
	};
	
	//------------------------------------------------------------------------
	editPrj.addExternTemplate=async function(pkgPath,def){
		//console.log("Add template: "+def.path);
		def.path=pathLib.join(pkgPath,def.path);
		def.template=true;
		EditHudObj.regCatalogHudDef(def.catalog,def.name,def);
	};

	//------------------------------------------------------------------------
	editPrj.loadDocFile=async function(path){
		if(!path.startsWith(this.path)){
			return null;
		}
	};
	
	//------------------------------------------------------------------------
	editPrj.loadExternDocFile=async function(path){
		//TODO: load file content
	};
	
	//------------------------------------------------------------------------
	editPrj.addPreloadFile=async function(path,external){
		let attrPath,cssListAttr,attrName,attrDef,attr;
		let ext;
		if(path.startsWith(this.path)){
			attrPath=path.substring(this.path.length+1);
		}else{
			attrPath=path;
		}
		if(path[0]==="/" && path[1]!=="/" && path[1]!=="@" && path[1]!=="~"){
			path="/~"+path;
		}
		ext=pathLib.extname(path).toLowerCase();
		cssListAttr=this.getAttr("cssFiles");
		attrName=path;
		if(cssListAttr.getAttr(attrName)){
			return;
		}
		attrDef={
			name:path,showName:pathLib.basename(path),type:"object",edit:false,external:!!external,
			def:{
				icon:"file.svg",
				attrs:{
					path:{name:path,type:"string",initVal:attrPath,edit:false}
				},
				objAttrs:{
					loadURL:path,attrPath:attrPath,isImportFile:(ext===".css")
				}
			}
		};
		if(ext===".css"){		
			await VFACT.appendCSS(path);
		}else if(ext===".js"){
			await VFACT.appendScript(path);
		}
		attr=cssListAttr.addAttr(attrDef);
	};
	
	//------------------------------------------------------------------------
	editPrj.reloadCSSFile=async function(attrObj){
		let ext,url;
		url=attrObj.loadURL;
		if(!url){
			return;
		}
		ext=pathLib.extname(url).toLowerCase();
		if(ext===".css"){		
			await VFACT.appendCSS(`${url}?tag=${Date.now()}`);
		}else if(ext===".js"){
			await VFACT.appendScript(`${url}?tag=${Date.now()}`);
		}
	};
}

//****************************************************************************
//Utility functions
//****************************************************************************
{
	//------------------------------------------------------------------------
	editPrj.getDocInPrj=function(docPath){
		let doc,docList;
		doc=this.liveDocs[docPath];
		if(doc)
			return doc;
		doc=this.docConfig;
		if(doc.path===docPath){
			return doc;
		}
		docList=this.getAttr("docDatas").attrList;
		for(doc of docList){
			if(doc.path===docPath){
				return doc;
			}
		}
		docList=this.getAttr("docGears").attrList;
		for(doc of docList){
			if(doc.path===docPath){
				return doc;
			}
		}
		docList=this.getAttr("docViews").attrList;
		for(doc of docList){
			if(doc.path===docPath){
				return doc;
			}
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	editPrj.getBoxNaviDoc=function(){
		return EditPrj.boxNaviDoc;
	};

	//------------------------------------------------------------------------
	editPrj.getBoxNaviPrj=function(){
		return EditPrj.boxNaviPrj;
	};
	
	//------------------------------------------------------------------------
	editPrj.updateDocIndex=function(){
		let docIndex,docList,doc;
		docIndex=0;
		this.getAttr("docConfig").docIndex=docIndex++;
		docList=this.getAttr("docDatas").attrList;
		for(doc of docList){
			doc.docIndex=docIndex++;
		}
		docList=this.getAttr("docGears").attrList;
		for(doc of docList){
			doc.docIndex=docIndex++;
		}
		docList=this.getAttr("docViews").attrList;
		for(doc of docList){
			doc.docIndex=docIndex++;
		}
	};
}
export default EditPrj;
export {EditPrj,EditPrjObjDef};
